/** SOURCE ONLY v2. Pure data projection; no solver, SDK, Core, CAD or private reads.
 * Root runs the CLI after its operational guard and actual candidate collection.
 * Partial compact profile: routed owners plus explicit pending working material.
 * Interior path coordinates use the captured CPU COMPONENT origin, never its pin XY.
 * Whole mixed traces have no inherited C31 or native physical qualification.
 * Importing this module has no I/O. Exported projection does not assign raw IDs.
 */
type Row = Record<string, any>
type XY = { x: number; y: number }
type Wire = XY & { route_type: "wire"; layer: string; width: number }
type Via = XY & { route_type: "via"; from_layer: string; to_layer: string; layers: string[]; via_diameter: number; via_hole_diameter: number }
type Vertex = Wire | Via
type PathItem = string | XY
const IDS = Array.from({ length: 49 }, (_, i) => i)
const LAYERS = ["top", "inner1", "inner2", "bottom"]
const EXPECTED = IDS.map(i => `source_trace_${i}`)
const EPS = 1e-8
const CAPTURED_RAW_CORE_SHA = "d2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607"
function check(value: unknown, message: string): asserts value { if (!value) throw new Error(message) }
function near(a: XY, b: XY) { return Math.hypot(a.x - b.x, a.y - b.y) <= EPS }
function equal(a: unknown, b: unknown) { return JSON.stringify(a) === JSON.stringify(b) }
function scalar(value: unknown, target: number) { return typeof value === "number" && Math.abs(value - target) <= EPS }
function sameSet(a: string[], b: string[]) { return Array.isArray(a) && Array.isArray(b) && a.length === b.length && new Set(a).size === a.length && a.every(x => b.includes(x)) }
function xy(point: XY): XY { return { x: point.x, y: point.y } }
function one<T>(rows: T[], message: string): T { check(rows.length === 1, message); return rows[0] }
function viaSelector(name: string, layer: string) { return `.${name} > port.${layer}` }


/** Cover one held nonzero Top segment by a union of same-owner collinear Top
 * edges. Positions are measured in mm along the held segment, so EPS remains
 * a coordinate tolerance even for long/short segments. No geometry is moved. */
function topSegmentCoverage(a: Wire, b: Wire, joined: Row): Row {
  const length = Math.hypot(b.x - a.x, b.y - a.y)
  check(length > 0 && Number.isFinite(length), "Nonzero finite held Top segment required")
  const ux = (b.x - a.x) / length, uy = (b.y - a.y) / length
  const intervals: Array<[number, number]> = []
  for (let i = 1; i < joined.route.length; i++) {
    const p = joined.route[i - 1], q = joined.route[i]
    if (p.route_type !== "wire" || q.route_type !== "wire" || p.layer !== "top" || q.layer !== "top") continue
    if (!Number.isFinite(p.x) || !Number.isFinite(p.y) || !Number.isFinite(q.x) || !Number.isFinite(q.y)) continue
    if (!Number.isFinite(p.width) || !Number.isFinite(q.width) || p.width < a.width - EPS || q.width < b.width - EPS) continue
    const crossP = Math.abs((p.x - a.x) * uy - (p.y - a.y) * ux)
    const crossQ = Math.abs((q.x - a.x) * uy - (q.y - a.y) * ux)
    if (crossP > EPS || crossQ > EPS) continue
    const first = (p.x - a.x) * ux + (p.y - a.y) * uy
    const last = (q.x - a.x) * ux + (q.y - a.y) * uy
    const lo = Math.max(0, Math.min(first, last)), hi = Math.min(length, Math.max(first, last))
    if (hi >= lo && hi >= 0 && lo <= length) intervals.push([lo, hi])
  }
  intervals.sort((a, b) => a[0] - b[0] || a[1] - b[1])
  let coveredUntil = 0
  for (const [lo, hi] of intervals) {
    if (lo > coveredUntil + EPS) break
    coveredUntil = Math.max(coveredUntil, hi)
    if (coveredUntil >= length - EPS) break
  }
  return { covered: intervals.length > 0 && coveredUntil >= length - EPS, heldLengthMm: length, coveredUntilMm: coveredUntil, intervalCount: intervals.length }
}

/** A connection_name is the canonical owner. A noncanonical source_trace_id
 * may name its original local Source branch and remains mapping provenance;
 * two distinct canonical owners are always a conflict. */
function workingOwner(trace: Row): string {
  const owner = trace.connection_name ?? trace.source_trace_id
  check(typeof owner === "string" && EXPECTED.includes(owner), "Unknown nonreference working trace owner")
  if (EXPECTED.includes(trace.source_trace_id)) check(trace.source_trace_id === owner, "Conflicting canonical working trace connection/source owner")
  return owner
}

export interface ProjectionInput {
  input: Row
  candidate: Row
  contacts: Row
  proof: Row
  proposal: Row
  namespace?: string
  parentSource33BBinding?: Row
  candidateBinding?: Row
  rawCore: Row[]
  rawCoreBinding: Row
}

/** Project routed45..49 owners and preserve all pending working material.
 * Wire runs become pcbPaths; every actual transition becomes one fullspan via.
 * The authoritative numeric selectors come from the unchanged source proposal,
 * bound to captured original numeric pads by the builder's public contacts packet.
 * New Core IDs remain future evidence after an actual source render.
 */
export function projectPartialMixedJoined(packet: ProjectionInput): Row {
  const { input: suppliedInput, candidate, contacts, proof, proposal } = packet
  check(Array.isArray(packet.rawCore) && packet.rawCoreBinding?.sha256 === CAPTURED_RAW_CORE_SHA && typeof packet.rawCoreBinding.path === "string", "Exact captured public Source33B raw Core binding required; CLI verifies immutable bytes")
  const cpuSource = one<Row>(packet.rawCore.filter(r => r.type === "source_component" && r.name === "U_SOC"), "Exactly one captured U_SOC source component")
  const cpuPcb = one<Row>(packet.rawCore.filter(r => r.type === "pcb_component" && r.source_component_id === cpuSource.source_component_id), "Exactly one captured CPU pcb component matched by actual source component ID")
  check(typeof cpuSource.source_component_id === "string" && typeof cpuPcb.pcb_component_id === "string" && Number.isFinite(cpuPcb.center?.x) && Number.isFinite(cpuPcb.center?.y) && scalar(cpuPcb.rotation, 0) && cpuPcb.layer === "top", "Captured CPU component origin/rotation must be real and unchanged")
  const originXY = xy(cpuPcb.center)
  const pcbPathCoordinateFrame: Row = { kind: "CAPTURED_CPU_COMPONENT_ORIGIN", componentName: "U_SOC", originXY, rotationDegrees: 0, capturedOriginalSourceComponentId: cpuSource.source_component_id, capturedOriginalPcbComponentId: cpuPcb.pcb_component_id, rawCoreBinding: structuredClone(packet.rawCoreBinding), freshCoreDerived: false, capturedIdsAreProvenanceOnly: true, formula: "worldXY = capturedCpuComponentOriginXY + pcbPathInteriorXY; CPU rotation is zero" }
  const input = structuredClone(suppliedInput)
  const namespace = packet.namespace ?? "V_RUN_PARTIAL"
  check(/^[A-Za-z][A-Za-z0-9_]*$/.test(namespace), "Invalid stable via namespace")
  check(proof.releaseMode === "ALL49_FRESH_DOGBONES" && proof.profile === "current-ti-compact-intersection" && proof.coordinatedDogboneReleaseApplied === true, "Requires all49 fresh dogbone release proof")
  check(proof.fixedTraceCount === 165 && proof.obstacleCount === 1298 && proof.connectionMetadataCount === 49 && proof.routingSubsetCount === 49, "Unexpected all49 fixed scene")
  check(sameSet(proof.selectedConnections, EXPECTED) && sameSet(contacts.selectedConnections, EXPECTED), "Original49 ownership mismatch")
  check(proof.releasedEndpointViaIds.length === 98 && proof.releasedTopStubIds.length === 98 && proof.removedCarrierBodyPcbTraceIds.length === 36 && sameSet(proof.removedCarrierIntermediateViaIds, ["pcb_via_227", "pcb_via_228", "pcb_via_229"]), "Explicit release roster mismatch")
  check(proof.fixedFullspanEndpointViaIds.length === 0 && proof.heldCarrierBodyPcbTraceIds.length === 0 && proof.heldCarrierIntermediateViaIds.length === 0, "No old signal geometry may remain held")
  check(input.layerCount === 4 && equal(input.allowedLayers, LAYERS) && input.allowBlindAndBuriedVias === false, "Requires physical four-layer fullspan-only stack")
  check(scalar(input.minViaPadDiameter, .4572) && scalar(input.minViaHoleDiameter, .254) && scalar(input.minTraceWidth, .1016), "Original via and trace dimensions required")
  check(input.connections.length === 49 && sameSet(input.connections.map((c: Row) => c.name), EXPECTED), "Exact full49 input metadata required")
  check(Array.isArray(proof.referenceTraceIds) && proof.referenceTraceIds.length === 165 && new Set(proof.referenceTraceIds).size === 165, "Exact original165 reference identities required")
  const referenceIds = new Set(proof.referenceTraceIds)
  input.traces = input.traces.filter((t: Row) => referenceIds.has(t.pcb_trace_id))
  check(input.traces.length === 165 && input.obstacles.length === 1298 && sameSet(input.traces.map((t: Row) => t.pcb_trace_id), proof.referenceTraceIds), "Input fixed reference counts and identities differ from proof")
  // A common scene may carry variable owned working approaches and handoffs.
  // The source projection always anchors each whole route at its numeric pads.
  for (const request of input.connections) {
    const c = one<Row>(contacts.connections.filter((r: Row) => r.name === request.name && r.selected === true), "One genuine numeric contact owner")
    request.pointsToConnect = [0, 1].map(side => {
      const e = one<Row>(c.endpoints.filter((e: Row) => e.side === side), "One genuine numeric side")
      return { x: e.numericPcbPort.x, y: e.numericPcbPort.y, layer: "top", pointId: e.numericPcbPort.pcb_port_id, pcb_port_id: e.numericPcbPort.pcb_port_id }
    })
  }
  check(input.obstacles.filter((o: Row) => typeof o.circuitJsonMetadata?.pcb_via_id === "string").length === 129, "Exactly129 fixed reference barrel obstacles required")
  check(candidate.full49FanoutInput !== undefined || candidate.input !== undefined, "Mixed v2 requires an explicit independent working foundation in candidate.full49FanoutInput or candidate.input; joined traces alone cannot prove held-material preservation")
  const candidateScene = candidate.full49FanoutInput ?? candidate.input
  const dormantInventories = [candidate.dormantWorkingBarrels, candidateScene.dormantWorkingBarrels].filter(value => value !== undefined)
  check(dormantInventories.every(value => Array.isArray(value)), "Dormant working barrel inventories must be explicit arrays when supplied")
  check(dormantInventories.every(value => value.length === 0), "Dormant working barrels cannot be omitted from Source replay: explicitly remove only the owner's unused working barrels via retargetGeneratedEscape and revalidate the current scene, or use a future separate preservation inventory")
  check(equal(candidateScene.obstacles, input.obstacles) && equal(candidateScene.bounds, input.bounds) && equal(candidateScene.outline, input.outline) && equal(candidateScene.allowedLayers, input.allowedLayers), "Mixed candidate fixed board/reference metadata differs from compact source input")
  check(equal(candidateScene.buses, input.buses) && equal(candidateScene.differentialPairs, input.differentialPairs) && candidateScene.connections.length === 49 && sameSet(candidateScene.connections.map((c: Row) => c.name), EXPECTED), "Mixed candidate preserves original full49 memberships and compact rules")
  check(Array.isArray(candidateScene.traces) && equal(candidateScene.traces.filter((t: Row) => referenceIds.has(t.pcb_trace_id)), input.traces), "Mixed candidate must preserve all165 original reference paths exactly")
  const explicitJoined = candidate.joinedNumericPadTraces ?? candidate.joinedTraces
  const traces: Row[] = explicitJoined ?? candidate.traces?.slice(input.traces.length)
  check(Array.isArray(traces) && traces.length >= 45 && traces.length <= 49 && new Set(traces.map((t: Row) => t.connection_name)).size === traces.length && traces.every(t => EXPECTED.includes(t.connection_name)), "Partial-profile45..49 unique joined numeric-pad traces required")
  if (!explicitJoined) check(candidate.traces.length === 165 + traces.length && equal(candidate.traces.slice(0, 165), input.traces), "Bare partial candidate must append complete routed owners to165 references")
  const routedOwnerIds = EXPECTED.filter(sid => traces.some(t => t.connection_name === sid))
  const pendingOwnerIds = EXPECTED.filter(sid => !routedOwnerIds.includes(sid))
  check(packet.candidateBinding && /^[0-9a-f]{64}$/.test(packet.candidateBinding.sha256), "Explicit actual candidate SHA256 binding required; CLI verifies immutable bytes")
  const candidatePhysicalReports = candidate.finalScenePhysicalReports ?? []
  check(candidate.allSavedCarriersCurrentSceneQualified === true && Array.isArray(candidatePhysicalReports) && candidatePhysicalReports.length === traces.length && sameSet(candidatePhysicalReports.map((r: Row) => r.owner), routedOwnerIds) && candidatePhysicalReports.every((r: Row) => r.passed === true), "Input routed-owner current-scene report inventory required; report qualification is not inherited by Source")
  // Independently derive omissions from actual post-retarget working material,
  // not a possibly absent or stale dormantWorkingBarrels metadata array.
  const workingTraces: Row[] = candidateScene.traces.filter((t: Row) => !referenceIds.has(t.pcb_trace_id))
  const workingViaMatches: Row[] = [], workingTopStubCoverage: Row[] = []
  for (const working of workingTraces) {
    const owner = workingOwner(working)
    check(Array.isArray(working.route), `${owner}: working route array required`)
    if (pendingOwnerIds.includes(owner)) continue // Explicitly reconstructed below, never silently omitted.
    const joined = one<Row>(traces.filter(t => t.connection_name === owner), `${owner}: unique complete joined trace`)
    check(Array.isArray(joined.route), `${owner}: complete joined route required`)
    for (let index = 0; index < working.route.length; index++) {
      const p = working.route[index], previous = working.route[index - 1]
      check((p.route_type === "wire" || p.route_type === "via") && Number.isFinite(p.x) && Number.isFinite(p.y), `${owner}: unsupported/nonfinite working material`)
      if (previous && previous.route_type !== p.route_type) check(near(previous, p), `${owner}: working via handoff must be colocated; implicit nonzero transition material is unsupported`)
      if (p.route_type === "via") {
        check(sameSet(p.layers, LAYERS) && scalar(p.via_diameter, .4572) && scalar(p.via_hole_diameter, .254), `${owner}: working barrel must preserve exact fullspan .4572/.254 material`)
        const joinedEventIndices = joined.route.flatMap((q: Row, i: number) => q.route_type === "via" && near(p, q) && sameSet(q.layers, LAYERS) && scalar(q.via_diameter, p.via_diameter) && scalar(q.via_hole_diameter, p.via_hole_diameter) ? [i] : [])
        check(joinedEventIndices.length > 0, `${owner}: omitted working barrel at ${p.x},${p.y}; explicitly retarget only this owner's unused Top branch and revalidate the changed physical foundation, or use a future preservation inventory`)
        workingViaMatches.push({ owner, workingTraceIdentityForMappingOnly: working.pcb_trace_id, routeIndex: index, xy: xy(p), joinedEventIndices, physicalFromToLabelsNotUsedForMaterialMatching: true })
      } else {
        check(LAYERS.includes(p.layer) && scalar(p.width, .1016), `${owner}: working wire physical layer/width changed`)
        if (previous?.route_type === "wire") {
          check(previous.layer === p.layer, `${owner}: working wire changes layer without an actual barrel event`)
          if (p.layer === "top" && (p.x !== previous.x || p.y !== previous.y)) {
            const coverage = topSegmentCoverage(previous, p, joined)
            check(coverage.covered, `${owner}: omitted held nonzero Top stub segment ${index - 1}->${index}; preserve its collinear split-union coverage in the same-owner complete joined Top route`)
            workingTopStubCoverage.push({ owner, workingTraceIdentityForMappingOnly: working.pcb_trace_id, startRouteIndex: index - 1, endRouteIndex: index, a: xy(previous), b: xy(p), ...coverage })
          }
        }
      }
    }
  }
  const workingMaterialAudit = { explicitIndependentFoundation: true, referenceIdsExcludedExactly: [...referenceIds], workingTraceCount: workingTraces.length, checkedWorkingViaEventCount: workingViaMatches.length, checkedNonzeroWorkingTopSegmentCount: workingTopStubCoverage.length, omittedWorkingBarrelCount: 0, omittedWorkingTopStubCount: 0, coordinateToleranceMm: EPS, workingViaMatches, workingTopStubCoverage, physicalQualificationInherited: false }
  const originalLogicals: Row[] = proposal.all49OriginalLogicalTraces
  const branches: Row[] = proposal.all98NumericOwnedSignalBranches
  check(originalLogicals.length === 49 && branches.length === 98, "Exact current33B source metadata required")
  const expectedBuses = structuredClone(proof.literalOldRuleBuses)
  check(Array.isArray(expectedBuses), "Original literal bus declarations required")
  for (const bus of expectedBuses) {
    if (bus.busId === "DDR_BYTE0") bus.maxLength = 11.8
    if (bus.busId === "DDR_BYTE1") bus.maxLength = 14.2
    if (bus.busId === "DDR_COMMAND_CLOCK") { bus.minLength = 20.95; bus.maxLength = 22.29 }
  }
  check(equal(input.buses, expectedBuses) && equal(input.buses, proof.effectiveBuses), "Preserve all original bus rules except the requested absolute-length intersections")
  for (const [id, count, maximum] of [["DDR_BYTE0", 11, 11.8], ["DDR_BYTE1", 11, 14.2], ["DDR_COMMAND_CLOCK", 26, 22.29]] as const) {
    const bus = one<Row>(input.buses.filter((b: Row) => b.busId === id), `${id}: one original bus required`)
    check(bus.connectionNames.length === count && scalar(bus.maxLength, maximum) && scalar(bus.maxLengthSkew, .635), `${id}: exact cohort bounds required`)
    if (id === "DDR_COMMAND_CLOCK") check(scalar(bus.minLength, 20.95), "CA minimum20.95 required")
  }
  const reset = one<Row>(input.buses.filter((b: Row) => b.busId === "DDR_RESET"), "One original RESET rule required")
  check(sameSet(reset.connectionNames, ["source_trace_10"]) && reset.minLength === undefined && reset.maxLength === undefined, "RESET must retain no absolute bound")
  const pairs = input.differentialPairs
  check(equal(pairs, [
    { connectionNames: ["source_trace_15", "source_trace_16"], lengthTolerance: .127, traceGap: .12 },
    { connectionNames: ["source_trace_28", "source_trace_27"], lengthTolerance: .127, traceGap: .12 },
    { connectionNames: ["source_trace_33", "source_trace_34"], lengthTolerance: .127, traceGap: .12 },
  ]), "All3 original .127 pair rules and .12 coupling gaps must remain unchanged")
  const oldBranches = branches.filter(b => EXPECTED.includes(b.originalSourceTraceId))
  check(oldBranches.length === 98, "Exactly98 old branch declarations required")
  const intermediate = proposal.intermediateCarrierVias.filter((v: Row) => EXPECTED.includes(v.originalSourceTraceId))
  check(intermediate.length === 3 && sameSet(intermediate.map((v: Row) => v.originalSourceTraceId), ["source_trace_20", "source_trace_21", "source_trace_17"]), "Exactly3 old intermediate barrels required")
  const removeViaNames = [...oldBranches.map(b => b.viaName), ...intermediate.map((v: Row) => v.viaName)]
  const removeLocalTraceNames = oldBranches.map(b => b.traceName)
  check(new Set(removeViaNames).size === 101 && new Set(removeLocalTraceNames).size === 98, "Exact unique old source suppression identities required")
  const removeInnerPortRegistrations: Row[] = structuredClone(proposal.added52RealInnerLayerPorts)
  check(removeInnerPortRegistrations.length === 52 && removeInnerPortRegistrations.every((p: Row) => removeViaNames.includes(p.viaName) && /^inner[12]$/.test(p.layer)) && new Set(removeInnerPortRegistrations.map((p: Row) => `${p.viaName}:${p.layer}`)).size === 52, "All52 exact old inner registrations must be removed")
  const parentViaNames = new Set<string>([...branches.map(b => b.viaName), ...proposal.intermediateCarrierVias.map((v: Row) => v.viaName)])
  const newVias: Row[] = [], replacedOriginals: Row[] = [], innerPortRegistrations: Row[] = []
  const projectedGeometry: Row[] = [], lengths = new Map<string, number>()
  const auxiliaryLocalTraces: Row[] = [], pendingOwnerApproaches: Row[] = []
  for (const sid of EXPECTED) {
    const trace = traces.find((t: Row) => t.connection_name === sid)
    if (trace) check(trace.type === "pcb_trace" && Array.isArray(trace.route) && trace.route.length >= 2, `${sid}: pcb_trace route required`)
    const contact = one<Row>(contacts.connections.filter((c: Row) => c.name === sid && c.selected === true), `${sid}: exact fresh contacts required`)
    check(contact.endpoints.length === 2, `${sid}: two numeric endpoints required`)
    const ends = [0, 1].map(side => {
      const e = one<Row>(contact.endpoints.filter((e: Row) => e.side === side), `${sid}: side${side} contact required`)
      const b = one<Row>(oldBranches.filter(b => b.originalSourceTraceId === sid && b.side === side), `${sid}: side${side} source branch required`)
      check(typeof b.numericSelector === "string" && /^(U_SOC|U_RAM)\.pin\d+$/.test(b.numericSelector), `${sid}: original numeric selector required`)
      check(near(e.numericPcbPort, b.padXY) && e.numericPad.pcb_port_id === e.numericPcbPort.pcb_port_id, `${sid}: source selector and actual numeric pad differ`)
      return { ...e, selector: b.numericSelector }
    })
    check(/^U_SOC\.pin\d+$/.test(ends[0].selector), `${sid}: every route must use the real CPU selector as its component-frame anchor`)
    const capturedCpuPort = one<Row>(packet.rawCore.filter(r => r.type === "pcb_port" && r.pcb_port_id === ends[0].numericPcbPort.pcb_port_id), `${sid}: captured CPU numeric port in same pinned raw Core`)
    check(capturedCpuPort.pcb_component_id === cpuPcb.pcb_component_id && near(capturedCpuPort, ends[0].numericPcbPort), `${sid}: numeric CPU selector belongs to the captured coordinate-frame component`)
    const original = one<Row>(originalLogicals.filter(t => t.originalSourceTraceId === sid), `${sid}: original logical trace required`)
    check(original.from === ends[0].selector && original.to === ends[1].selector, `${sid}: original logical numeric selectors differ`)
    const request = one<Row>(input.connections.filter((c: Row) => c.name === sid), `${sid}: original request required`)
    check(request.pointsToConnect.length === 2 && request.pointsToConnect.every((p: Row, side: number) => p.layer === "top" && p.pointId === p.pcb_port_id && p.pcb_port_id === ends[side].numericPcbPort.pcb_port_id && near(p, ends[side].numericPcbPort)), `${sid}: genuine numericTop request mismatch`)
    check(input.traces.every((t: Row) => t.connection_name !== sid && t.source_trace_id !== sid), `${sid}: old branch/body copper remains in fixed scene`)
    if (!trace) {
      const owned = workingTraces.filter(t => workingOwner(t) === sid)
      check(owned.length === 2, `${sid}: pending owner must retain exactly two current working branches`)
      const usedSides = new Set<number>()
      for (const branch of owned) {
        check(typeof branch.pcb_trace_id === "string" && Array.isArray(branch.route) && branch.route.length > 0, `${sid}: exact pending branch identity/route required`)
        const branchRoute: Vertex[] = structuredClone(branch.route)
        const side = one<number>([0, 1].filter(side => branchRoute[0].route_type === "wire" && (branchRoute[0] as Wire).layer === "top" && near(branchRoute[0], ends[side].numericPcbPort)), `${sid}: pending branch must start at exactly one authentic numeric Top pad`)
        check(!usedSides.has(side), `${sid}: duplicate pending numeric side`); usedSides.add(side)
        const terminalEvents = branchRoute.flatMap((p, index) => p.route_type === "via" ? [{ p, index }] : [])
        check(terminalEvents.length <= 1, `${sid}: pending local branch supports at most one explicit terminal barrel`)
        const topPoints: XY[] = []
        let sawVia = false
        for (let index = 0; index < branchRoute.length; index++) {
          const p = branchRoute[index], previous = branchRoute[index - 1]
          check(Number.isFinite(p.x) && Number.isFinite(p.y), `${sid}: nonfinite pending working material`)
          if (p.route_type === "wire") {
            check(LAYERS.includes(p.layer) && scalar(p.width, .1016), `${sid}: pending wire dimensions/layer changed`)
            if (!sawVia) { check(p.layer === "top", `${sid}: pending non-Top copper before barrel unsupported`); topPoints.push(xy(p)) }
            else check(near(p, terminalEvents[0].p), `${sid}: pending nonzero non-Top material must not be omitted`)
            if (previous?.route_type === "wire") check(previous.layer === p.layer, `${sid}: pending implicit layer change`)
          } else {
            check(p.route_type === "via" && !sawVia, `${sid}: unsupported pending primitive`)
            const before = branchRoute[index - 1], after = branchRoute[index + 1]
            check(before?.route_type === "wire" && after?.route_type === "wire" && near(before, p) && near(after, p) && before.layer !== after.layer && p.from_layer === before.layer && p.to_layer === after.layer, `${sid}: pending barrel must join actual colocated active wires`)
            check(sameSet(p.layers, LAYERS) && scalar(p.via_diameter, .4572) && scalar(p.via_hole_diameter, .254), `${sid}: pending barrel physical material changed`)
            sawVia = true
          }
        }
        let viaName: string | null = null
        if (terminalEvents.length) {
          const { p, index } = terminalEvents[0]
          viaName = `${namespace}_${sid}_PENDING_${side}`
          check(!parentViaNames.has(viaName) && !newVias.some(v => v.name === viaName), `${sid}: pending via source namespace collision`)
          const declaration = { name: viaName, originalSourceTraceId: sid, orderedViaIndex: side, routeVertexIndex: index, role: "PENDING_ENDPOINT", x: p.x, y: p.y, fromLayer: "top", toLayer: "bottom", layers: [...LAYERS], outerDiameter: .4572, holeDiameter: .254, tented: "top_and_bottom_tented", innerLayers: ["inner1", "inner2"], activeTransition: null, currentUntraveledTerminalEvent: structuredClone(p), originalEvent: structuredClone(p), pendingCarrier: true, futureFreshIds: null }
          newVias.push(declaration)
          for (const layer of declaration.innerLayers) innerPortRegistrations.push({ viaName, layer, xy: xy(p), originalSourceTraceId: sid, numericSelector: ends[0].selector, futureFreshIds: null })
          workingViaMatches.push({ owner: sid, workingTraceIdentityForMappingOnly: branch.pcb_trace_id, routeIndex: index, xy: xy(p), pendingDeclarationName: viaName, joinedEventIndices: [], preservedAsRealUntraveledPendingBarrel: true, physicalFromToLabelsNotUsedForMaterialMatching: true })
        }
        const topLength = topPoints.slice(1).reduce((sum, p, i) => sum + Math.hypot(p.x - topPoints[i].x, p.y - topPoints[i].y), 0)
        let sourceDeclarationName: string | null = null
        if (topLength > 0) {
          check(viaName !== null && near(topPoints.at(-1)!, terminalEvents[0].p), `${sid}: a pending nonzero Top stub requires its actual terminal barrel; unsupported unanchored stub must not be dropped`)
          sourceDeclarationName = `T_${namespace}_${sid}_PENDING_${side}`
          check(!removeLocalTraceNames.includes(sourceDeclarationName) && !auxiliaryLocalTraces.some(t => t.name === sourceDeclarationName), `${sid}: auxiliary source name collision`)
          const fromSelector = ends[side].selector, toSelector = viaSelector(viaName, "top"), relativeAnchorSelector = ends[0].selector, relativeAnchorXY = xy(originXY), relative = topPoints.slice(1, -1).map(p => ({ x: p.x - relativeAnchorXY.x, y: p.y - relativeAnchorXY.y }))
          auxiliaryLocalTraces.push({ name: sourceDeclarationName, owner: sid, originalSourceTraceId: sid, branchId: branch.pcb_trace_id, side, fromSelector, toSelector, thicknessMm: .1016, layer: "top", absolutePoints: structuredClone(topPoints), absoluteTopWireRoute: structuredClone(branchRoute.slice(0, topPoints.length)), relativeAnchorSelector, relativeAnchorXY, relativeAnchorKind: "CPU_COMPONENT_ORIGIN", afterRouteProps: { pcbPaths: [[fromSelector, ...relative, toSelector]], pcbPathRelativeTo: relativeAnchorSelector }, planarLengthMm: topLength, futureFreshIds: null })
          const materialTrace = { route: topPoints.map(p => ({ ...p, route_type: "wire", layer: "top", width: .1016 })) }
          for (let index = 1; index < topPoints.length; index++) if (topPoints[index].x !== topPoints[index - 1].x || topPoints[index].y !== topPoints[index - 1].y) {
            const a = materialTrace.route[index - 1] as Wire, b = materialTrace.route[index] as Wire, coverage = topSegmentCoverage(a, b, materialTrace)
            check(coverage.covered, `${sid}: pending Top source coverage unresolved`)
            workingTopStubCoverage.push({ owner: sid, workingTraceIdentityForMappingOnly: branch.pcb_trace_id, startRouteIndex: index - 1, endRouteIndex: index, a: xy(a), b: xy(b), pendingSourceDeclarationName: sourceDeclarationName, ...coverage })
          }
        }
        pendingOwnerApproaches.push({ owner: sid, originalSourceTraceId: sid, branchId: branch.pcb_trace_id, side, originalBranch: structuredClone(branch), sourceDeclarationName, auxiliaryTraceNames: sourceDeclarationName ? [sourceDeclarationName] : [], viaNames: viaName ? [viaName] : [], actualTerminalLayer: branchRoute.at(-1)!.route_type === "wire" ? (branchRoute.at(-1)! as Wire).layer : null, pendingCarrier: true, physicalQualificationInherited: false })
      }
      check(usedSides.size === 2, `${sid}: both pending numeric sides preserved`)
      replacedOriginals.push({ originalSourceTraceId: sid, logicalName: original.name, fromSelector: original.from, toSelector: original.to, thicknessMm: .1016, afterRouteProps: { pcbPaths: [], pcbPathRelativeTo: ends[0].selector }, wholePlanarMm: null, physicalPathCount: 0, newPhysicalViaCount: 0, pendingPhysicalViaCount: pendingOwnerApproaches.filter(p => p.owner === sid).reduce((sum, p) => sum + p.viaNames.length, 0), routeStatus: "PENDING_NO_CARRIER_ROUTE", pending: true })
      continue
    }
    let route: Vertex[] = structuredClone(trace.route)
    const originalDirection = near(route[0], ends[0].numericPcbPort) && near(route.at(-1)!, ends[1].numericPcbPort)
    if (!originalDirection) {
      check(near(route[0], ends[1].numericPcbPort) && near(route.at(-1)!, ends[0].numericPcbPort), `${sid}: joined route does not terminate on both actual numeric pads`)
      route = route.toReversed().map(p => p.route_type === "via" ? { ...p, from_layer: p.to_layer, to_layer: p.from_layer } : p)
    }
    check((trace.curvedSegments ?? []).every((index: number) => Number.isInteger(index) && index >= 1 && index < route.length), `${sid}: invalid curved-segment provenance index`)
    check(trace.coupledSection == null || (Array.isArray(trace.coupledSection) && trace.coupledSection.length === 2 && trace.coupledSection.every((index: number) => Number.isInteger(index) && index >= 0 && index < route.length) && trace.coupledSection[0] < trace.coupledSection[1]), `${sid}: invalid coupling provenance indices`)
    const canonicalCurvedSegmentEnds: number[] = (trace.curvedSegments ?? []).map((index: number) => originalDirection ? index : route.length - index).sort((a: number, b: number) => a - b)
    const canonicalCoupledSection: number[] | null = trace.coupledSection ? (originalDirection ? [...trace.coupledSection] : [route.length - 1 - trace.coupledSection[1], route.length - 1 - trace.coupledSection[0]]) : null
    check(route[0].route_type === "wire" && (route[0] as Wire).layer === "top" && route.at(-1)!.route_type === "wire" && (route.at(-1)! as Wire).layer === "top", `${sid}: numeric endpoints must be Top wire vertices`)
    const ownerVias: Row[] = [], paths: PathItem[][] = [], runs: Row[] = []
    let runPoints: XY[] = [], runVertexIndices: number[] = [], runLayer = "top", startSelector = ends[0].selector, total = 0, preservedDuplicateWireVertices = 0
    function finishRun(endSelector: string) {
      check(runPoints.length >= 2, `${sid}: wire run has no nonzero segment`)
      const runLength = runPoints.slice(1).reduce((sum, p, i) => sum + Math.hypot(p.x - runPoints[i].x, p.y - runPoints[i].y), 0)
      check(runLength > EPS, `${sid}: zero-length wire run`)
      const relative = runPoints.slice(1, -1).map(p => ({ x: p.x - originXY.x, y: p.y - originXY.y }))
      paths.push([startSelector, ...relative, endSelector])
      const curveEndsInRun = canonicalCurvedSegmentEnds.filter(index => runVertexIndices.includes(index) && runVertexIndices.includes(index - 1))
      const coupledVertexIndicesInRun = canonicalCoupledSection ? runVertexIndices.filter(index => index >= canonicalCoupledSection[0] && index <= canonicalCoupledSection[1]) : []
      runs.push({ layer: runLayer, startSelector, endSelector, relativeAnchorSelector: ends[0].selector, relativeAnchorXY: xy(originXY), relativeAnchorKind: "CPU_COMPONENT_ORIGIN", absolutePoints: structuredClone(runPoints), planarLengthMm: runLength, canonicalRouteVertexIndices: [...runVertexIndices], originalRouteVertexIndices: runVertexIndices.map(index => originalDirection ? index : route.length - 1 - index), curvedSegmentEndIndicesInRun: curveEndsInRun.map(index => runVertexIndices.indexOf(index)), coupledVertexIndicesInRun: coupledVertexIndicesInRun.map(index => runVertexIndices.indexOf(index)), annotationsAreProvenanceOnly: true })
      total += runLength
    }
    for (let index = 0; index < route.length; index++) {
      const p = route[index]
      check(Number.isFinite(p.x) && Number.isFinite(p.y), `${sid}: nonfinite vertex`)
      if (p.route_type === "wire") {
        check(LAYERS.includes(p.layer) && scalar(p.width, .1016), `${sid}: physical layer and .1016 width required`)
        if (runPoints.length === 0) runLayer = p.layer
        check(p.layer === runLayer, `${sid}: layer change without actual via event`)
        if (runPoints.length && near(p, runPoints.at(-1)!)) preservedDuplicateWireVertices++
        runPoints.push(xy(p)); runVertexIndices.push(index)
        continue
      }
      check(p.route_type === "via", `${sid}: unsupported routing primitive`)
      const before = route[index - 1], after = route[index + 1]
      check(before?.route_type === "wire" && after?.route_type === "wire" && near(before, p) && near(after, p), `${sid}: via event must join colocated wire vertices`)
      check(before.layer !== after.layer && p.from_layer === before.layer && p.to_layer === after.layer, `${sid}: active via transition differs from wire layers`)
      check(sameSet(p.layers, LAYERS) && scalar(p.via_diameter, .4572) && scalar(p.via_hole_diameter, .254), `${sid}: explicit fullspan .4572/.254 event required`)
      const eventIndex = ownerVias.length, name = `${namespace}_${sid}_${eventIndex}`
      check(!parentViaNames.has(name) && !newVias.some(v => v.name === name), `${sid}: new source via name collides with existing declaration`)
      const usedInner = [before.layer, after.layer].filter(l => /^inner[12]$/.test(l))
      const innerLayers = [...new Set(usedInner)]
      const declaration: Row = { name, originalSourceTraceId: sid, orderedViaIndex: eventIndex, routeVertexIndex: index, role: "INTERMEDIATE", x: p.x, y: p.y, fromLayer: "top", toLayer: "bottom", layers: [...LAYERS], outerDiameter: .4572, holeDiameter: .254, tented: "top_and_bottom_tented", innerLayers, activeTransition: { fromLayer: before.layer, toLayer: after.layer }, originalEvent: structuredClone(p), futureFreshIds: null }
      ownerVias.push(declaration); newVias.push(declaration)
      for (const layer of innerLayers) innerPortRegistrations.push({ viaName: name, layer, xy: xy(p), originalSourceTraceId: sid, numericSelector: ends[0].selector, futureFreshIds: null })
      finishRun(viaSelector(name, before.layer))
      runPoints = []; runVertexIndices = []; runLayer = after.layer; startSelector = viaSelector(name, after.layer)
    }
    finishRun(ends[1].selector)
    if (ownerVias.length) { ownerVias[0].role = "ENDPOINT"; ownerVias.at(-1)!.role = "ENDPOINT" }
    lengths.set(sid, total)
    replacedOriginals.push({ originalSourceTraceId: sid, logicalName: original.name, fromSelector: original.from, toSelector: original.to, thicknessMm: .1016, afterRouteProps: { pcbPaths: paths, pcbPathRelativeTo: ends[0].selector }, wholePlanarMm: total, physicalPathCount: paths.length, newPhysicalViaCount: ownerVias.length })
    projectedGeometry.push({ originalSourceTraceId: sid, sourcePcbTraceIdForMappingOnly: trace.pcb_trace_id, inputDirectionReversed: !originalDirection, preservedDuplicateWireVertices, canonicalJoinedRoute: route, wireRuns: runs, originalCurvedSegmentsForMappingOnly: trace.curvedSegments ?? null, originalCoupledSectionForMappingOnly: trace.coupledSection ?? null, canonicalCurvedSegmentEnds, canonicalCoupledSection, sourcePcbPathsDoNotClaimCurveOrCouplingAnnotations: true, capturedNumericEndpoints: ends.map(e => ({ selector: e.selector, capturedOriginalNumericPcbPortId: e.numericPcbPort.pcb_port_id, capturedOriginalNumericSourcePortId: e.numericSourcePort.source_port_id, xy: xy(e.numericPcbPort), layer: "top", futureFreshIds: null })) })
  }
  workingMaterialAudit.checkedWorkingViaEventCount = workingViaMatches.length
  workingMaterialAudit.checkedNonzeroWorkingTopSegmentCount = workingTopStubCoverage.length
  const allLengths = [...lengths.values()]
  const busAudits = input.buses.map((bus: Row) => {
    const observedOwners = bus.connectionNames.filter((sid: string) => lengths.has(sid)), missingOwners = bus.connectionNames.filter((sid: string) => !lengths.has(sid)), values = observedOwners.map((sid: string) => lengths.get(sid)!)
    const minimumMm = values.length ? Math.min(...values) : null, maximumMm = values.length ? Math.max(...values) : null, skewMm = values.length ? maximumMm! - minimumMm! : null
    return { busId: bus.busId, connectionNames: [...bus.connectionNames], observedOwners, pendingOwners: missingOwners, completeOwnerRoster: missingOwners.length === 0, minimumMm, maximumMm, skewMm, minLengthMm: bus.minLength ?? null, maxLengthMm: bus.maxLength ?? null, toleranceMm: bus.maxLengthSkew ?? null, observedAbsoluteBoundsSatisfied: values.every((value: number) => (bus.minLength === undefined || value >= bus.minLength - EPS) && (bus.maxLength === undefined || value <= bus.maxLength + EPS)), observedSkewSatisfied: skewMm === null || bus.maxLengthSkew === undefined || skewMm <= bus.maxLengthSkew + EPS, observationsOnly: true, fullCohortQualified: false }
  })
  const pairAudits = pairs.map((pair: Row) => {
    const complete = pair.connectionNames.every((sid: string) => lengths.has(sid)), skewMm = complete ? Math.abs(lengths.get(pair.connectionNames[0])! - lengths.get(pair.connectionNames[1])!) : null
    return { connectionNames: [...pair.connectionNames], completeOwnerRoster: complete, skewMm, lengthToleranceMm: pair.lengthTolerance, traceGapMm: pair.traceGap, observedLengthToleranceSatisfied: complete && skewMm! <= pair.lengthTolerance + EPS, observationsOnly: true, sourcePairQualified: false }
  })
  const heldOriginalCarrierOwners = proposal.selected33BOriginalCarriers.filter((c: Row) => !EXPECTED.includes(c.originalSourceTraceId)).map((c: Row) => c.originalSourceTraceId)
  const replacedPriorCarrierOwners = proposal.selected33BOriginalCarriers.filter((c: Row) => EXPECTED.includes(c.originalSourceTraceId)).map((c: Row) => c.originalSourceTraceId)
  check(replacedPriorCarrierOwners.length === 33 && new Set(replacedPriorCarrierOwners).size === 33 && heldOriginalCarrierOwners.length === 0, "Replace all33B prior body owners")
  const N = newVias.length, I = innerPortRegistrations.length, A = auxiliaryLocalTraces.length
  const routedR = projectedGeometry.reduce((sum, g) => sum + g.wireRuns.length, 0), R = routedR + A
  const pendingN = newVias.filter(v => v.role === "PENDING_ENDPOINT").length, traveledN = N - pendingN
  check(Number.isSafeInteger(N) && N >= 0 && Number.isSafeInteger(I) && I >= 0 && I <= 2 * N && routedR === routedOwnerIds.length + traveledN && replacedOriginals.length === 49 && pendingOwnerApproaches.length === 2 * pendingOwnerIds.length, "Partial routed runs and explicit pending material count mismatch")
  const routedOriginals = replacedOriginals.filter(r => !r.pending), pendingOriginals = replacedOriginals.filter(r => r.pending)
  return {
    scope: "SOURCE33B_PARTIAL_MIXED_JOINED_EDITABLE_PLAN_SOURCE_PROJECTION_ONLY",
    partialLayerProfile: "compact-four-layer-partial", mixedLayerProfile: "compact-four-layer-partial", numericInput: input,
    pcbPathCoordinateFrame, coordinateFrameVersion: 2,
    routedOwnerIds, pendingOwnerIds, routedOriginals, pendingOriginals,
    pendingOwnerApproaches, auxiliaryLocalTraces, pendingApproachSources: auxiliaryLocalTraces,
    originalLogicalRoutesExplicitlyPending: pendingOriginals.map(r => ({ owner: r.originalSourceTraceId, pcbPaths: [], automaticRoutingSuppressed: true })),
    qualificationProvenance: { candidateBinding: structuredClone(packet.candidateBinding), candidateScope: candidate.scope ?? null, inputRoutedOwnerPhysicalQualified: candidate.allSavedCarriersCurrentSceneQualified === true, currentSceneReports: structuredClone(candidatePhysicalReports), inheritedSourceQualification: false, inheritedAll49Qualification: false },
    workingMaterialAudit, omittedWorkingBarrelCount: 0, omittedWorkingTopStubCount: 0,
    dormantWorkingBarrelCount: 0, noDormantWorkingBarrelsOmitted: true,
    physicalRunReports: structuredClone(candidate.physicalRunReports ?? []),
    newViaReports: structuredClone(candidate.newViaReports ?? []),
    mixedPhysicalReportPolicy: "Per-wire-run C31/native/self-clear and new-via reports are retained as diagnostic provenance only; they do not qualify a whole mixed-layer trace or fresh Source geometry",
    wholeMixedTraceC31Qualified: false, wholeMixedTraceNativeQualified: false,
    wholeMixedC31Validated: false, perWireRunPhysicalQualified: false, allThroughViaBarrelsPhysicalQualified: false,
    mixedViaAndBarrelPhysicalQualified: false,
    version: 2, parentSource33BBinding: packet.parentSource33BBinding ?? null,
    replacedOriginals, removeLocalTraceNames, removeViaNames, removeInnerPortRegistrations, newVias, innerPortRegistrations,
    projectedGeometry, replacedPriorCarrierOwners, heldOriginalCarrierOwners,
    sourceRuleIntersections: [{ busName: "DDR_BYTE0", after: { maxLength: 11.8, maxLengthSkew: .635 } }, { busName: "DDR_BYTE1", after: { maxLength: 14.2, maxLengthSkew: .635 } }, { busName: "DDR_COMMAND_CLOCK", after: { minLength: 20.95, maxLength: 22.29, maxLengthSkew: .635 } }],
    sourceRuleBeforePropsPolicy: "Overlay must derive and assert exact actual captured-parent before props, preserving original bus/pair declarations",
    planarAudit: { partial: true, routedOwnerIds, pendingOwnerIds, lengths: Object.fromEntries(lengths), maximumMm: Math.max(...allLengths), minimumMm: Math.min(...allLengths), busAudits, pairAudits, barrelLengthAddedMm: 0, planarBoundsPassed: false, observationsOnly: true, missingOwnersExcludedFromTimingObservations: true, all49TimingQualified: false },
    dynamicCounts: { routedOwners: routedOwnerIds.length, pendingOwners: pendingOwnerIds.length, newViaEvents: N, traveledViaEvents: traveledN, pendingViaEvents: pendingN, newInnerRegistrations: I, routedWireRuns: routedR, auxiliarySourceTraces: A, pendingTopWireRuns: A, projectedWireRuns: R, expectedPcbVias: 129 + N, expectedSourceVias: 129 + N, expectedPcbComponents: 409 + N, expectedSourcePorts: 1419 + 2 * N + I, expectedSourceTraces: 1097 + A, expectedPhysicalTraces: 165 + R, expectedReactElements: 2036 + N + I + A, removedOldInnerRegistrations: 52 },
    originalPairRules: structuredClone(pairs), original49LogicalTracesPreserved: true,
    rawCircuitIdsFabricated: false, originalNumericPadsMoved: false,
    sourceCaptureExecuted: false, sourceCoreExecuted: false, freshCoreDerived: false,
    allThreeOriginalCouplingApisQualified: false, ownNetGraphScreenQualified: false,
    accepted49: false, full49Accepted: false, all49Accepted: false, timingPassed: false, all49Connected: false, electricalTimingQualified: false, fabricationReady: false,
    qualificationRequired: ["editable source capture and full inverse", "fresh Core numeric-pad/barrel graph proof and allheldsourcegeometry", "original all3 coupling APIs", "native18/reference/electrical/CLI/CAD qualification"],
  }
}

// This separate partial-profile entry point never relaxes the frozen full49 projector.
export const projectPartialJoined = projectPartialMixedJoined
export const projectPartialMixedJoinedV2 = projectPartialMixedJoined

async function cli() {
  const args = new Map<string, string>()
  for (let i = 2; i < process.argv.length; i += 2) {
    const key = process.argv[i], value = process.argv[i + 1]
    check(["--caller-intent", "--input", "--candidate", "--candidate-sha", "--contacts", "--proof", "--proposal", "--raw-core", "--raw-core-sha", "--output", "--namespace"].includes(key) && typeof value === "string" && !args.has(key), `Invalid CLI argument ${key}`)
    args.set(key, value)
  }
  check(args.get("--caller-intent") === "ROOT_AUTHORIZED_PROJECT_COMPACT_PARTIAL_MIXED_JOINED_V2", "Root caller intent required before imports")
  for (const key of ["--input", "--candidate", "--candidate-sha", "--contacts", "--proof", "--proposal", "--raw-core", "--raw-core-sha", "--output"]) check(args.has(key), `Requires ${key}`)
  const fs = await import("node:fs/promises"), path = await import("node:path"), crypto = await import("node:crypto")
  const inputs: Row = {}, bindings: Row = {}
  for (const key of ["input", "candidate", "contacts", "proof", "proposal", "raw-core"]) {
    const filename = path.resolve(args.get(`--${key}`)!)
    const text = await fs.readFile(filename, "utf8")
    const property = key === "raw-core" ? "rawCore" : key
    inputs[property] = JSON.parse(text)
    bindings[property] = { path: filename, sha256: crypto.createHash("sha256").update(text).digest("hex"), bytes: Buffer.byteLength(text) }
  }
  check(/^[0-9a-f]{64}$/.test(args.get("--candidate-sha")!) && bindings.candidate.sha256 === args.get("--candidate-sha"), "Exact immutable actual candidate bytes required")
  check(args.get("--raw-core-sha") === CAPTURED_RAW_CORE_SHA && bindings.rawCore.sha256 === CAPTURED_RAW_CORE_SHA, "Exact captured public Core bytes required for component-origin coordinate frame")
  const plan = projectPartialMixedJoined({ ...inputs, namespace: args.get("--namespace"), parentSource33BBinding: bindings.proposal, candidateBinding: bindings.candidate, rawCoreBinding: bindings.rawCore } as ProjectionInput)
  plan.inputBindings = bindings
  const output = path.resolve(args.get("--output")!)
  check(Object.values(bindings).every((b: any) => b.path !== output), "Output must not overwrite any input")
  await fs.mkdir(path.dirname(output), { recursive: true })
  await fs.writeFile(output, `${JSON.stringify(plan, null, 2)}\n`, { flag: "wx" })
  process.stdout.write(`${JSON.stringify({ output, replacedOriginals: plan.replacedOriginals.length, routedOwners: plan.routedOwnerIds.length, pendingOwners: plan.pendingOwnerIds.length, auxiliaryLocalTraces: plan.auxiliaryLocalTraces.length, newVias: plan.newVias.length, planarBoundsPassed: false, full49Accepted: false })}\n`)
}

if ((import.meta as any).main) await cli()
