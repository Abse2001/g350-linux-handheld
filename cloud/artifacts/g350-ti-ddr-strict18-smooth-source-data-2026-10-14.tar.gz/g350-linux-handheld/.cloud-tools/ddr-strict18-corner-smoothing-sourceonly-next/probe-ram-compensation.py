"""Finite retained RAM-only Source28 compensation trials; stdlib geometry only."""
import importlib.util,copy,json,math
from pathlib import Path
HERE=Path(__file__).parent
sp=importlib.util.spec_from_file_location('cornerlib',HERE/'probe-smooth-corners.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
R=.1016
old=m.original['source_trace_28'];p=copy.deepcopy(old['path']);p[1]['x']=1.5;p[2]['y']=13.1;p.pop(5);cpu,arcs,mapping=m.fillet(p,[2,3,4]);target=m.length([m.xy(q)for q in old['path']]);deficit=target-m.length([m.xy(q)for q in cpu]);a,b=map(m.xy,cpu[-2:]);span=math.dist(a,b);u=((b[0]-a[0])/span,(b[1]-a[1])/span)
def withU(s,w,side,h):
 def at(t,z):return m.P((a[0]+u[0]*t-u[1]*z*side,a[1]+u[1]*t+u[0]*z*side))
 raw=[m.P(a),at(s,0),at(s,h),at(s+w,h),at(s+w,0),m.P(b)];out,details,mp=m.fillet(raw,[1,2,3,4]);return cpu[:-2]+out,details
# Exact sampled chord length is the actual copper length, not a circle arc approximation.
events=[];chosen=[]
for s in [.18,.3,.45,.6,.8,1.,1.2,1.4]:
 for w in [.3,.4,.5,.6,.8]:
  if s+w+R>=span:continue
  for side in [1,-1]:
   lo,hi=2*R,.4
   for j in range(45):
    mid=(lo+hi)/2;q,details=withU(s,w,side,mid);delta=m.length([m.xy(v)for v in q])-target
    if delta<0:lo=mid
    else:hi=mid
   h=(lo+hi)/2;q,details=withU(s,w,side,h);records=copy.deepcopy(m.original);records['source_trace_28']['path']=q;selfresult=m.selfcheck(q)
   if not selfresult['clear']:
    events.append({'offsetMm':s,'widthMm':w,'side':side,'depthMm':h,'self':selfresult});continue
   sc=m.screen(records,'source_trace_28');row={'offsetMm':s,'widthMm':w,'side':side,'depthMm':h,'lengthDeltaMm':m.length([m.xy(v)for v in q])-target,'result':sc};events.append(row)
   if sc['physicalViolationCount']==0 and sc['maximumTurnDegrees']<=45.2:chosen.append({**row,'path':q,'cpuArcs':arcs,'ramArcs':details,'cpuOriginalToNewIndexMap':mapping})
result={'scope':'BOUNDED_SOURCE28_RAM_SAMPLED_U_COMPENSATION_PROBES_NO_APP','originalDatasetSha256':m.sha(m.DATA),'originalLengthMm':target,'cpuVirtualTipY':13.1,'cpuLengthDeficitMm':deficit,'trialCount':len(events),'trials':events,'physicallySelfAngleClearCandidateCount':len(chosen),'candidates':chosen,'originalAPIsExecuted':False,'accepted49':False,'fabricationReady':False}
out=HERE/'RAM_COMPENSATION_TRIALS.json';out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'trials':len(events),'candidateCount':len(chosen),'sha256':m.sha(out),'candidates':[{k:r[k]for k in['offsetMm','widthMm','side','depthMm','lengthDeltaMm']}for r in chosen]}))
