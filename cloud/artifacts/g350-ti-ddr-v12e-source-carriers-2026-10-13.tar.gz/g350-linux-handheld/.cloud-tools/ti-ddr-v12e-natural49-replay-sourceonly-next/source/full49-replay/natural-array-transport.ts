/** Transport original naturally solved objects. This never imports a router. */
import { createHash } from "node:crypto"
import { readFileSync, writeFileSync } from "node:fs"
import { resolve } from "node:path"
import identities from "./identity-contract.json"
import bindings from "./replay-bindings.json"
import signals from "./natural-signals.json"

type Point = { x: number; y: number; layer: string; pcb_port_id?: string; pointId?: string }
type Input = { connections: Array<{ name: string; source_trace_id?: string; width?: number; pointsToConnect: Point[] }> }
const nativeNames = new Set(identities.ddrIds)
const nonDdrNames = new Set(identities.nonDdrIdentifiers)
export const ddrRamSelectors = identities.ramSelectors
export const ddrTraceNames = new Set(identities.ddrTraceNames)
export const ddrBusNames = new Set(identities.ddrBusNames)

class ArrayDelivery {
  private listeners: Array<{ event: string; callback: (value: unknown) => void }> = []
  private started = false
  private stopped = false
  constructor(private traces: unknown[]) {}
  on(event: string, callback: (value: unknown) => void) {
    if (!["complete", "error", "progress"].includes(event)) throw Error("Unsupported replay transport event")
    this.listeners.push({ event, callback })
  }
  start() {
    if (this.started) throw Error("Replay array transport advanced twice")
    this.started = true
    queueMicrotask(() => {
      if (this.stopped) return
      for (const listener of this.listeners)
        if (listener.event === "complete") listener.callback({ type: "complete", traces: structuredClone(this.traces) })
    })
  }
  stop() { this.stopped = true }
}

function actualNames(input: Input) {
  if (!Array.isArray(input.connections) || !input.connections.length) throw Error("Missing actual phase input")
  const names = input.connections.map(c => {
    if (!c || typeof c.name !== "string" || !c.name ||
      (c.source_trace_id !== undefined && typeof c.source_trace_id !== "string")) throw Error("Malformed actual phase ownership")
    return c.name
  })
  if (new Set(names).size !== names.length) throw Error("Duplicate actual phase identity")
  return names
}

/** Complete means exact array delivery only. No physical or timing claim. */
export function createNatural49Replay(input: Input) {
  const names = actualNames(input)
  if (names.length !== 49 || names.some(n => !nativeNames.has(n))) throw Error("Exact 49 DDR phase required")
  const raw = readFileSync(resolve(import.meta.dir, "natural-signals.json"))
  if (createHash("sha256").update(raw).digest("hex") !== bindings.signalArraySha256) throw Error("Frozen original signal array changed")
  if (signals.length !== 49 || new Set(signals.map(t => t.source_trace_id)).size !== 49 ||
      signals.some(t => !nativeNames.has(t.source_trace_id) || t.connection_name !== t.source_trace_id)) throw Error("Original signal ownership changed")
  for (const connection of input.connections) {
    if (connection.source_trace_id !== undefined && connection.source_trace_id !== connection.name) throw Error("Ambiguous actual DDR phase ownership")
    const expected = identities.ddrConnections.find(c => c.name === connection.name)
    if (!expected || connection.pointsToConnect.length !== 2 ||
      new Set(connection.pointsToConnect.map(p => p.pcb_port_id)).size !== 2 ||
      connection.width !== expected.width) throw Error("Actual DDR width/endpoint inventory differs")
    for (const point of connection.pointsToConnect) {
      const matches = expected.pointsToConnect.filter(p => p.pcb_port_id === point.pcb_port_id &&
        p.pointId === point.pointId && p.x === point.x && p.y === point.y && p.layer === point.layer)
      if (matches.length !== 1) throw Error("Actual Core endpoint numeric ID/coordinates differ")
    }
  }
  const observation = JSON.stringify({ scope: "ACTUAL_CORE_FULL49_ARRAY_DELIVERY_IDENTITY_ONLY",
    connectionCount: 49, connections: input.connections, originalSignalArraySha256: bindings.signalArraySha256,
    routerCalled: false, accepted49: false, fabricationReady: false }, null, 2) + "\n"
  if (Buffer.byteLength(observation) > 1024 * 1024) throw Error("Bounded phase observation exceeded")
  writeFileSync(resolve(import.meta.dir, "../../run/actual-core-full49-phase-input.json"), observation, { flag: "wx" })
  return new ArrayDelivery(signals)
}

/** Later non-DDR phases deliberately emit no copper; the board stays incomplete. */
export function createUnroutedLaterPhase(input: Input) {
  const names = [...actualNames(input), ...input.connections.flatMap(c => c.source_trace_id === undefined ? [] : [c.source_trace_id])]
  if (names.some(n => nativeNames.has(n) || !nonDdrNames.has(n))) throw Error("Only original non-DDR identities may remain unrouted")
  return new ArrayDelivery([])
}
