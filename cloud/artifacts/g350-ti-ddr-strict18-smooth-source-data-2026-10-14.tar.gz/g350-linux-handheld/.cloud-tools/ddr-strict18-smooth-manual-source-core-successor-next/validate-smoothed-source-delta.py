"""Finite exact successor and Source-prop inverse controls, no app imports."""
import copy,json,hashlib,importlib.util,ast,sys
sys.dont_write_bytecode=True
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=HERE.parent/'ddr-strict18-manual-source-integration-sourceonly-next';OLDCORE=HERE.parent/'ddr-strict18-manual-core-owned-alias-successor-next';GEO=HERE.parent/'ddr-strict18-corner-smoothing-sourceonly-next'
sp=importlib.util.spec_from_file_location('source_stdlib_controls',HERE/'validate-source-proposal.py');v=importlib.util.module_from_spec(sp);sp.loader.exec_module(v)
old=json.loads((BASE/'strict18-source-proposal.json').read_bytes());candidate=json.loads((HERE/'strict18-source-proposal.json').read_bytes());fork=json.loads((HERE/'authorized-all4-routing-input.json').read_bytes());evidence=json.loads((GEO/'UPDATED_AUTHENTIC_PAIR_SECTIONS.json').read_bytes());prior_capture=json.loads((BASE/'run-capture/source-capture.json').read_bytes());changed={'source_trace_15','source_trace_16','source_trace_28'}
def verify(p):
 v.verify(p,fork)
 restored=copy.deepcopy(p)
 for a,b in zip(old['newOriginalSignalChanges'],restored['newOriginalSignalChanges']):
  n=b['originalSourceTraceId'];v.require(a['originalSourceTraceId']==n,'Unchanged owner order')
  if n not in changed:v.require(a==b,'One of thirteen unmodified path declarations changed');continue
  v.require(b['physicalCarrierCoupledSection']==evidence['candidates'][n]['coupledSection'],'Authentic current section indices')
  v.require(b['originalStaticCarrierPath']==evidence['candidates'][n]['path'],'Complete precise current pair path binding')
  v.require(b['carrierLayer']==evidence['candidates'][n]['layer'],'Actual current section layer')
  for key in ['newPcbPaths','originalStaticCarrierPath','expectedCarrierPhysicalRoute']:b[key]=a[key]
  del b['physicalCarrierCoupledSection']
  v.require(a==b,'Changed owner/stub/barrel/selector under narrow three-path inverse')
 v.require(restored['newOriginalSignalChanges']==old['newOriginalSignalChanges'],'Exactly three physical geometry declarations inverse')
 for key in old:
  if key!='inputBindings':v.require(restored[key]==old[key],'Every original Source proposal control/Port/clock/layer/logic field held')
 for key,row in old['inputBindings'].items():
  if key not in ['static18','static18Report']:v.require(p['inputBindings'][key]==row,'Old authenticated evidence changed')
 v.require(p['cornerSmoothingSuccessor']['changedOriginalSourceIds']==sorted(changed),'Exactly three changed owners')
 # Data-only inverse on ACTUAL prior Source capture; no claim this executes React.
 tree=copy.deepcopy(prior_capture['actualSourceTree'])
 def rows(r):return [r]+[x for c in r.get('children',[])for x in rows(c)]
 byname={r.get('props',{}).get('name'):r for r in rows(tree)if r.get('kind')=='literal'and r.get('props',{}).get('name')}
 for b in p['newOriginalSignalChanges']:
  a=next(a for a in old['newOriginalSignalChanges']if a['originalSourceTraceId']==b['originalSourceTraceId']);r=byname[b['originalLogicalTraceName']]
  v.require(r['props']['pcbPaths']==a['newPcbPaths'],'Actual old Source exactly holds old path declaration')
  if b['originalSourceTraceId']in changed:r['props']['pcbPaths']=copy.deepcopy(b['newPcbPaths'])
 # Restore only three emitted path props; no other tree property can differ.
 for a in old['newOriginalSignalChanges']:
  if a['originalSourceTraceId']in changed:byname[a['originalLogicalTraceName']]['props']['pcbPaths']=copy.deepcopy(a['newPcbPaths'])
 v.require(tree==prior_capture['actualSourceTree'],'Data-only predecessor Source tree inverse')
 return True
verify(candidate)
controls=[]
def reject(name,mutate):
 p=copy.deepcopy(candidate);mutate(p)
 try:verify(p)
 except (ValueError,KeyError,IndexError):controls.append({'name':name,'refused':True})
 else:raise AssertionError('Invalid Source successor accepted: '+name)
rowidx={r['originalSourceTraceId']:i for i,r in enumerate(candidate['newOriginalSignalChanges'])}
reject('stale DQS0 shared indices',lambda p:p['newOriginalSignalChanges'][rowidx['source_trace_15']].update(physicalCarrierCoupledSection=[1,18]))
reject('stale DQS1 shared indices',lambda p:p['newOriginalSignalChanges'][rowidx['source_trace_28']].update(physicalCarrierCoupledSection=[5,14]))
reject('alter unrelated owner geometry',lambda p:p['newOriginalSignalChanges'][0]['cpu']['topStub'][0].update(x=999))
reject('alter smoothed real CPU Topstub',lambda p:p['newOriginalSignalChanges'][rowidx['source_trace_15']]['cpu']['topStub'][0].update(x=999))
reject('shift current smoothed physical path',lambda p:p['newOriginalSignalChanges'][rowidx['source_trace_28']]['originalStaticCarrierPath'][1].update(x=999))
reject('drop physical carrier section',lambda p:p['newOriginalSignalChanges'][rowidx['source_trace_16']].pop('physicalCarrierCoupledSection'))
reject('add unrequested changed owner',lambda p:p['cornerSmoothingSuccessor']['changedOriginalSourceIds'].append('source_trace_27'))
reject('change old Source logical evidence',lambda p:p['inputBindings']['signalProposal'].update(sha256='0'*64))
reject('change held clock definition',lambda p:p['existingQualifiedClocksHeld'][0].update(existingClockPcbPropsMustRemainExact=False))
reject('weaken Source pair assertions',lambda p:p.update(originalAll3PairSkewGapAssertionsHeld=False))
# Parse Python source and retain exact executable Source API/SDK delta.
for name in ['author-source-core-successor.py','validate-source-proposal.py','validate-smoothed-source-delta.py']:ast.parse((HERE/name).read_text())
v.require((HERE/'strict18-source-overlay.tsx').read_bytes()==(BASE/'strict18-source-overlay.tsx').read_bytes(),'Owner/Port/suppression/layer implementation byte-identical')
v.require((HERE/'render-strict18-core.ts').read_text().replace(str(HERE),str(BASE))==(OLDCORE/'render-strict18-core.ts').read_text(),'Core exactly two Source import repoints only')
r={'scope':'FINITE_SMOOTHED_THREE_SOURCE_DECLARATION_DELTA_CONTROLS_NO_APP','passed':True,'proposalSha256':v.digest(HERE/'strict18-source-proposal.json'),'geometrySourceManifestSha256':v.digest(GEO/'SOURCE-manifest.json'),'all13UnchangedNewOwnersAnd2OriginalClocksHeld':True,'all32DuplicateSuppressions24InnerPortsAndOriginalLayerInverseHeld':True,'dataOnlyOriginalActualCaptureTreeInverseVerified':True,'actualReactTreeStillRequiresFutureCapture':True,'preciseNewSharedSectionEvidenceBound':True,'core120ControlsUnchangedExceptTwoSourceImports':True,'ownerSourceOverlayByteIdentical':True,'negativeControls':controls,'actualAppImportsOrCalls':0,'accepted49':False,'fabricationReady':False}
out=HERE/'SMOOTHED_DELTA_CONTROLS.json';out.write_text(json.dumps(r,indent=2)+'\n');out.chmod(0o600);print(json.dumps({'negativeControls':len(controls),'sha256':v.digest(out),'applicationsExecuted':False}))
