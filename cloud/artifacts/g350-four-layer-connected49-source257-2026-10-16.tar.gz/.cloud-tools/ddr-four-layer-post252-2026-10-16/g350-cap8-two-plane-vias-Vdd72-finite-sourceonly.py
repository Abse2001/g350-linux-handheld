"""Pure geometry only; actual plane connectivity evidence is Root-owned and not inherited."""
from pathlib import Path
import json,math,hashlib
exec(Path('/tmp/g350-cap8-power-3d-astar-own-terminal-bound-sourceonly.py').read_text().rsplit('\nif __name__',1)[0])
PP=pads(0,7.9,0)
for q in PP:q['radius']=max(q['width'],q['height'])/2;q['holeRadius']=0;q['owner']=q['id'];q['bbox']=bbox(q)
V=[(.420116,7.9),(.420116,7.220116),(.4,7.2)]
G=[(-.420116,7.9),(-1.4,7.9),(-1.6,7.7),(-1.6,7.4)]
G2=[(-.420116,7.9),(-.920116,7.4),(-1.6,7.4)]
def details(Q,path):
 out=[]
 for i,(a,b) in enumerate(zip(path,path[1:])):
  cc=Q.contacts({'x':a[0],'y':a[1]},{'x':b[0],'y':b[1]},'bottom')
  if cc:out.append({'segment':i,'a':a,'b':b,'blockers':cc})
 return out
QV=Query3(objects,'NO_EXISTING_VIA_REPLACED','pcb_smtpad_730');QG=Query3(objects,'NO_EXISTING_VIA_REPLACED','pcb_smtpad_729')
rV=details(QV,V);rG=details(QG,G);rG2=details(QG,G2);vV=QV.via_legal((.4,7.2));vG=QG.via_legal((-1.6,7.4))
# Both new foreign conductors pairwise checked explicitly, actual radii and .2 query widths.
pair=[]
for i,(a,b) in enumerate(zip(V,V[1:])):
 for j,(c,d) in enumerate(zip(G,G[1:])):
  dist=sd({'x':a[0],'y':a[1]},{'x':b[0],'y':b[1]},{'x':c[0],'y':c[1]},{'x':d[0],'y':d[1]})
  if dist<.1+.1+.1016-1e-8:pair.append({'vSegment':i,'gSegment':j,'actual':dist,'required':.3016})
for name,site,path in [('VDDviaAgainstGNDstub',(.4,7.2),G),('GNDviaAgainstVDDstub',(-1.6,7.4),V)]:
 for i,(a,b) in enumerate(zip(path,path[1:])):
  dist=pd({'x':site[0],'y':site[1]},{'x':a[0],'y':a[1]},{'x':b[0],'y':b[1]});need=.1+max(.2286+.1016,.127+.2)
  if dist<need-1e-8:pair.append({'query':name,'segment':i,'actual':dist,'required':need})
landsep=math.hypot(2,.2);drillsep=landsep
R={'scope':'PURE_STDLIB_CAP8_TRANSLATION_AND_TWO_REAL_PLANE_VIA_PROPOSAL_NO_SOURCE_OR_PLANE_ACCEPTANCE','inputPath':scene,'inputSha256':pin,'cpuCycleReport':cp,'cpuCycleSha256':'4737965e5e21b45f642bde94a47c3dfc81150d649dbfd45b1f3a7c06267326ec','finalD12Paths':DP,'capCenter':[0,7.9],'rotation':0,'actualCapPads':PP,'VddBottomPath':V,'GndBottomPath':G,'GndAlternateBottomPath':G2,'VddForeignContacts':rV,'GndForeignContacts':rG,'GndAlternateForeignContacts':rG2,'newStandardFullspanViaSites':[{'rail':'DDR_1V5','x':.4,'y':7.2,'outer_diameter':.4572,'hole_diameter':.254,'layers':L,'allForeignContactsClear':vV},{'rail':'GND','x':-1.6,'y':7.4,'outer_diameter':.4572,'hole_diameter':.254,'layers':L,'allForeignContactsClear':vG}],'newForeignConductorCrossContacts':pair,'newViaPairCenterSeparation':landsep,'newViaPairLandGap':landsep-.4572,'newViaPairDrillGap':drillsep-.254,'ownVddViaToConnectedSmtPadCopperGapMm':7.9-.540004/2-(7.2+.4572/2),'ownVddViaToConnectedSmtPadDrillGapMm':7.9-.540004/2-(7.2+.254/2),'ownVddViaIncidenceRequiresActualSameConnectionAuthority':True,'fixed129ViasHeldLiteral':True,'requiresTwoNewActualPdnSourceComponentsAndNativeVias':True,'actualPlaneIslandContainmentAndViaGraphProofRootOwnedPending':True,'all49Accepted':False,'nativeExecuted':False,'fabricationReady':False}
out='/tmp/g350-cap8-two-plane-vias-Vdd72-finite-report.json';Path(out).write_text(json.dumps(R,indent=2)+'\n');print('VddContacts',[(r['segment'],[(o['owner'],o['id']) for o in r['blockers']]) for r in rV]);print('GndContacts',[(r['segment'],[(o['owner'],o['id']) for o in r['blockers']]) for r in rG]);print('GndAlt',[(r['segment'],[(o['owner'],o['id']) for o in r['blockers']]) for r in rG2]);print('via',vV,vG,'pairs',pair,'ownlandgap',R['ownVddViaToConnectedSmtPadCopperGapMm']);print('sha',hashlib.sha256(Path(out).read_bytes()).hexdigest())
