import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { createHash } from "node:crypto"
import type { SimpleRouteJson } from "../g350-ti-v12d-byte0-top-reset-bottom-public-next/source/lib/types"
const ROOT=import.meta.dir
const sha=(value:string|Uint8Array)=>createHash("sha256").update(value).digest("hex")
assert.deepEqual(process.argv.slice(2),["--run-one-approved"])
assert.equal(process.env.G350_LOCAL_DOGBONE_APPROVED,"1")
const manifestRaw=fs.readFileSync(path.join(ROOT,"SOURCE-manifest.json"))
const manifest=JSON.parse(manifestRaw.toString())
const authRaw=fs.readFileSync(process.env.G350_LOCAL_DOGBONE_AUTH_PATH!)
assert.equal(sha(authRaw),process.env.G350_LOCAL_DOGBONE_AUTH_SHA)
const auth=JSON.parse(authRaw.toString())
assert.equal(auth.authorizedByRoot,true)
assert.equal(auth.scope,manifest.scope)
assert.equal(auth.packetSha256,sha(manifestRaw))
assert.ok(/^[0-9a-f]{32,128}$/.test(auth.approvalToken))
assert.equal(fs.existsSync(path.join(ROOT,"run","result.json")),false)
const raw=fs.readFileSync(manifest.inputPath)
assert.equal(sha(raw),manifest.inputSha256)
const input=JSON.parse(raw.toString()) as SimpleRouteJson
assert.equal(input.connections.length,49)
assert.equal(input.obstacles.length,856)
assert.equal(input.traces?.length,2)
const before=JSON.stringify(input)
const targets=new Map<string,string>()
for(const connection of input.connections){const buses=(input.buses??[]).filter(bus=>bus.connectionNames.includes(connection.name));assert.equal(buses.length,1);assert.equal(buses[0].allowedLayers?.length,1);targets.set(connection.name,buses[0].allowedLayers![0])}
const widths=input.connections.map(c=>(input.buses??[]).find(bus=>bus.connectionNames.includes(c.name))?.traceWidth??c.nominalTraceWidth??c.width??input.minTraceWidth)
const options={targetLayers:targets,viaDiameter:input.minViaPadDiameter??.6,viaHoleDiameter:input.minViaHoleDiameter??.3,traceWidth:Math.max(input.minTraceWidth,...widths),clearance:input.minTraceToPadEdgeClearance??input.defaultObstacleMargin??.075,boardEdgeClearance:input.minBoardEdgeClearance,holeToHoleClearance:input.minViaHoleEdgeToViaHoleEdgeClearance,allowBlindAndBuriedVias:input.allowBlindAndBuriedVias??false}
const {routeAlternateSignalDogbones}=await import("../g350-fanout-source-layer-clearance-fix-next/patched-alternate-signal-dogbones")
const {prepareOriginalLocalEndpointCandidates}=await import("../g350-fanout-source-layer-clearance-fix-next/patched-endpoint-candidates")
const errorInfo=(error:unknown)=>{const message=error instanceof Error?error.message:String(error);return{error:message.slice(0,1024),errorTruncated:message.length>1024}}
const started=performance.now()
const endpointRows:any[]=[]
let candidateApiCalls=0
for(const name of ["source_trace_1","source_trace_12","source_trace_41"]){const connection=input.connections.find(c=>c.name===name)!;assert.ok(connection);const local={...input,connections:[connection],buses:[],differentialPairs:[]};const localBefore=JSON.stringify(local);candidateApiCalls++;try{const result=prepareOriginalLocalEndpointCandidates(local,options);if(!("candidates" in result))throw Error("Endpoint candidate API did not return original task candidates");endpointRows.push({name,returned:true,ports:connection.pointsToConnect.map((p,i)=>({selector:p.port_selector??null,pcbPortId:p.pcb_port_id??null,pointIndex:i,x:p.x,y:p.y,layer:p.layer,candidateCount:result.candidates.filter(c=>c.connectionIndex===i).length,candidateViaPoints:result.candidates.filter(c=>c.connectionIndex===i).map(c=>c.point)})),originalEndpointTasks:result.endpointTasks})}catch(error){endpointRows.push({name,returned:false,...errorInfo(error)})}assert.equal(JSON.stringify(local)===localBefore,true,"Endpoint API input mutated");assert.equal(JSON.stringify(input)===before,true,"Full input mutated")}
const rows:any[]=[]
let calls=0
for(const connection of input.connections){const local={...input,connections:[connection],buses:[],differentialPairs:[]};const localBefore=JSON.stringify(local);const attempts:any[]=[];for(let attempt=0;attempt<4;attempt++){calls++;const stamp=performance.now();try{const result=routeAlternateSignalDogbones(local,options,attempt);const vias=result.traces.flatMap(trace=>trace.route.filter(point=>point.route_type==="via").map(point=>({x:point.x,y:point.y,fromLayer:point.from_layer,toLayer:point.to_layer,layers:point.layers??null})));attempts.push({attempt,returned:true,error:null,elapsedMs:performance.now()-stamp,generatedTraceCount:result.traces.length,generatedConnections:result.connections.length,generatedViaRecords:vias.length,selectedViaPoints:vias})}catch(error){attempts.push({attempt,returned:false,...errorInfo(error),elapsedMs:performance.now()-stamp})}assert.equal(JSON.stringify(local)===localBefore,true,"Original local input mutated");assert.equal(JSON.stringify(input)===before,true,"Original full input mutated")};rows.push({name:connection.name,sourceTraceId:connection.source_trace_id??connection.name,targetLayer:targets.get(connection.name),nativeEndpoints:connection.pointsToConnect.map(p=>({selector:p.port_selector??null,pcbPortId:p.pcb_port_id??null,x:p.x,y:p.y,layer:p.layer})),successfulAttempts:attempts.filter(a=>a.returned).length,otherError:attempts.some(a=>!a.returned&&a.error!=="No collision-free local dogbone assignment"),attempts})}
const whole:any[]=[]
for(let attempt=0;attempt<4;attempt++){const stamp=performance.now();try{const result=routeAlternateSignalDogbones(input,options,attempt);const viaCount=result.traces.flatMap(trace=>trace.route.filter(point=>point.route_type==="via")).length;whole.push({attempt,returned:true,connections:result.connections.length,traces:result.traces.length,generatedViaRecords:viaCount,elapsedMs:performance.now()-stamp})}catch(error){whole.push({attempt,returned:false,...errorInfo(error),elapsedMs:performance.now()-stamp})}assert.equal(JSON.stringify(input)===before,true,"Whole input mutated")}
const result={scope:manifest.scope,diagnosticOnly:true,CoreForwarded:false,placementHypothesisOnly:true,inputSha256:sha(raw),runtimeLibraryManifestSha256:manifest.runtimeLibraryManifestSha256,patchedIndividualCalls:calls,patchedWholeCalls:whole.length,endpointCandidateApiCalls:candidateApiCalls,sourceConnections:49,fullObstaclesPerCall:856,fixedReferencesPerCall:2,originalLocalFallbackShapePreserved:true,originalTaskGeneratorPrefixSha256:manifest.originalTaskGeneratorPrefixSha256,privatePatchedMatcherSha256:manifest.privatePatchedMatcherSha256,inputUnchanged:JSON.stringify(input)===before,targetLayerMap:[...targets],exactOptions:{...options,targetLayers:undefined},zeroIndividualNames:rows.filter(r=>r.successfulAttempts===0).map(r=>r.name),otherErrorNames:rows.filter(r=>r.otherError).map(r=>r.name),everySignalHasSomeIndividualAssignment:rows.every(r=>r.successfulAttempts>0),wholeSomeAssignment:whole.some(a=>a.returned),endpointRows,rows,whole,totalSeconds:(performance.now()-started)/1000,noGridNoNativeChecker:true,accepted49:false,physicalAcceptanceClaimed:false,scopeLimit:"Proposed placement input is not Core-derived. Individual and whole local dogbones are diagnostic only, not CPU-to-RAM routes or physical acceptance; bounded offered-site failure is not global infeasibility."}
const output=JSON.stringify(result,null,2)+"\n"
fs.writeFileSync(path.join(ROOT,"run","result.json"),output,{flag:"wx"})
// Complete diagnostics are preserved before residual success/shape assertions.
assert.ok(Buffer.byteLength(output)<=256*1024)
assert.equal(calls,196);assert.equal(rows.length,49);assert.equal(whole.length,4);assert.equal(candidateApiCalls,3)
assert.equal(result.otherErrorNames.length,0)
assert.equal(endpointRows.every(r=>r.returned),true)
assert.equal(rows.every(r=>r.attempts.every((a:any)=>!a.returned||(a.generatedConnections===1&&a.generatedViaRecords<=2))),true)
assert.equal(whole.every(a=>!a.returned||(a.connections===49&&a.generatedViaRecords<=98)),true)
console.log(JSON.stringify({patchedIndividualCalls:calls,endpointCandidateApiCalls:candidateApiCalls,zeroIndividualNames:result.zeroIndividualNames,whole:whole.map(({elapsedMs,...rest})=>rest),accepted49:false,CoreForwarded:false}))
