#!/usr/bin/env python3
"""SOURCE ONLY. Root-run bounded KiCad10 version/API/CLI-flag observation.
No board is loaded, saved, refilled, edited, or connectivity-qualified.
"""
import argparse
import hashlib
import inspect
import json
import os
from pathlib import Path
import subprocess

def need(v,m):
 if not v:raise ValueError(m)
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--output',type=Path,required=True);args=a.parse_args()
 need(not args.output.exists(),'Fresh preflight output')
 r={'scope':'SOURCE272_KICAD10_PINNED_ROOTFS_VERSION_API_CLI_FLAG_PREFLIGHT_NOT_BOARD_QUALIFICATION',
    'passed':False,'boardLoaded':False,'boardSavedOrRefilled':False,'all49Accepted':False,'fabricationReady':False}
 try:
  import wx
  wx.Log.SetLogLevel(wx.LOG_Error);application=wx.App(False)
  import pcbnew
  version=str(pcbnew.GetBuildVersion() if hasattr(pcbnew,'GetBuildVersion') else pcbnew.Version())
  need(version.startswith('10.0.6'),'Exact prepared KiCad10.0.6')
  api={}
  for cls,name in [(pcbnew.CONNECTIVITY_DATA,'GetConnectedItems'),(pcbnew.BOARD,'BuildConnectivity'),
    (pcbnew.PAD,'GetEffectivePolygon'),(pcbnew.PAD,'GetRoundRectCornerRadius'),(pcbnew.PCB_VIA,'GetWidth'),
    (pcbnew.PCB_VIA,'TopLayer'),(pcbnew.PCB_VIA,'BottomLayer')]:
   method=getattr(cls,name);need(callable(method),'Required public callable')
   try:signature=str(inspect.signature(method))
   except (ValueError,TypeError):signature=None
   api[cls.__name__+'.'+name]={'signature':signature,'doc':method.__doc__}
  constants={n:int(getattr(pcbnew,n)) for n in ['PCB_PAD_T','PCB_TRACE_T','PCB_ARC_T','PCB_VIA_T','F_Cu','In1_Cu','In2_Cu','B_Cu']}
  commands=[]
  for argv in [['/usr/bin/kicad-cli','version'],['/usr/bin/kicad-cli','pcb','drc','--help']]:
   p=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=20,check=False)
   commands.append({'argv':argv,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});need(p.returncode==0,'Public version/help failed')
  need(commands[0]['stdout'].strip().startswith('10.0.6'),'Exact native CLI version')
  help_text=commands[1]['stdout']+'\n'+commands[1]['stderr']
  flags=['--format','--severity-all','--all-track-errors','--exit-code-violations','--output']
  need(all(f in help_text for f in flags),'Required full-DRC flags advertised')
  r.update(passed=True,version=version,api=api,constants=constants,commands=commands,requiredDrcFlags=flags)
 except BaseException as e:r['error']={'type':type(e).__name__,'message':str(e)}
 finally:
  with args.output.open('x') as f:os.fchmod(f.fileno(),0o600);json.dump(r,f,indent=2,allow_nan=False);f.write('\n')
 print(json.dumps({'output':str(args.output),'sha256':hashlib.sha256(args.output.read_bytes()).hexdigest(),'passed':r['passed'],'boardLoaded':False,'fabricationReady':False}))
 need(r['passed'],'KiCad API preflight failed; no board was loaded')
if __name__=='__main__':main()
