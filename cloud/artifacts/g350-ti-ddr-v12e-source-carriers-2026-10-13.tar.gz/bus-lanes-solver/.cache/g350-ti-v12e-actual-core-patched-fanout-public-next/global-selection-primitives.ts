/** Diagnostic-only CJS export observation; exact original calls and callback identity survive. */
type BoundExport = { object: object; name: string; descriptor: PropertyDescriptor; replacement?: Function }
type DomainRow = { index: number; name: string | null; candidates: number }
type PoolRow = {
  serial: number
  domains: DomainRow[] | null
  maxSearchNodes: number | null
  maxSupportChecks: number | null
  originalFailureCallbackPresent: boolean
  initialPrune: "not-observed" | "pending" | "non-null" | "null" | "threw"
  initialSurvivors: number[] | null
  result: "pending" | "assignment" | "null" | "threw" | "other"
  assignmentNames: string[] | null
  elapsedMs: number | null
}
const LIMITS = { names: 49, nameCharacters: 80, domains: 49, candidatesPerDomain: 48, snapshotBytes: 16 * 1024 }
function own(value: unknown, key: string): unknown {
  if (value === null || (typeof value !== "object" && typeof value !== "function")) throw Error("Own original scalar required")
  const descriptor = Object.getOwnPropertyDescriptor(value, key)
  if (!descriptor || !Object.hasOwn(descriptor, "value")) throw Error("Original own data required")
  return descriptor.value
}
function count(value: unknown, maximum = Number.MAX_SAFE_INTEGER): number {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0 || value > maximum) throw Error("Bounded original count required")
  return value
}
function arrayLength(value: unknown, maximum: number): number {
  if (!Array.isArray(value)) throw Error("Original array required")
  return count(own(value, "length"), maximum)
}
/** Module namespaces must be the original writable CJS exports from the bound build. */
export function installGlobalSelectionPrimitives(poolModule: object, pruneModule: object, allKnownNames: readonly string[]) {
  const names = [...new Set(allKnownNames)]
  if (names.length > LIMITS.names || names.some(name => typeof name !== "string" || name.length > LIMITS.nameCharacters)) throw Error("Bounded known owners required")
  const known = new Set(names)
  const bindings: BoundExport[] = []
  for (const [object, name] of [[poolModule, "solveSignalCandidatePool"], [pruneModule, "pruneCandidateDomains"]] as const) {
    const descriptor = Object.getOwnPropertyDescriptor(object, name)
    if (!descriptor || typeof descriptor.value !== "function" || !descriptor.writable || !descriptor.configurable) throw Error("Original writable CJS function export required")
    bindings.push({ object, name, descriptor })
  }
  const totals = { poolCalls: 0, assignments: 0, nullReturns: 0, throws: 0, initialPruneCalls: 0, initialPruneNull: 0, initialPruneNonNull: 0, initialPruneThrows: 0, pruneOutsidePool: 0, additionalPruneInPool: 0, observationErrors: 0, snapshotOverflows: 0 }
  let current: PoolRow | null = null, last: PoolRow | null = null, restored = false
  const nameOf = (candidate: unknown) => {
    if (candidate === null || typeof candidate !== "object") throw Error("Original candidate object required")
    const connection = Object.getOwnPropertyDescriptor(candidate, "connection")
    const carrier = Object.getOwnPropertyDescriptor(candidate, "carrier")
    if (connection && carrier) throw Error("Ambiguous candidate owner shape")
    const name = connection
      ? own(own(candidate, "connection"), "name")
      : own(own(candidate, "carrier"), "connection_name")
    if (typeof name !== "string" || !known.has(name)) throw Error("Known original owner required")
    return name
  }
  const domainsOf = (value: unknown): DomainRow[] => {
    const length = arrayLength(value, LIMITS.domains), result: DomainRow[] = []
    for (let index = 0; index < length; index++) {
      const domain = own(value, String(index)), candidates = arrayLength(domain, LIMITS.candidatesPerDomain)
      result.push({ index, name: candidates ? nameOf(own(domain, "0")) : null, candidates })
    }
    return result
  }
  for (const binding of bindings) {
    const original = binding.descriptor.value
    const replacement = binding.name === "solveSignalCandidatePool"
      ? function(this: unknown, ...args: unknown[]) {
        const prior = current
        const row: PoolRow = { serial: ++totals.poolCalls, domains: null, maxSearchNodes: null, maxSupportChecks: null, originalFailureCallbackPresent: typeof args[4] === "function", initialPrune: "pending", initialSurvivors: null, result: "pending", assignmentNames: null, elapsedMs: null }
        try { row.domains = domainsOf(args[0]); row.maxSearchNodes = count(args[2] === undefined ? 4000 : args[2]); row.maxSupportChecks = count(args[3] === undefined ? 1_000_000 : args[3]) } catch { totals.observationErrors++ }
        current = row
        const started = performance.now()
        try {
          const result = Reflect.apply(original, this, args)
          try {
            if (result === null) { row.result = "null"; totals.nullReturns++ }
            else if (Array.isArray(result)) { row.result = "assignment"; totals.assignments++; const length = arrayLength(result, LIMITS.domains); row.assignmentNames = Array.from({ length }, (_, index) => nameOf(own(result, String(index)))) }
            else { row.result = "other"; totals.observationErrors++ }
          } catch { totals.observationErrors++ }
          return result
        } catch (error) { row.result = "threw"; totals.throws++; throw error }
        finally { if (row.initialPrune === "pending") row.initialPrune = "not-observed"; row.elapsedMs = performance.now() - started; last = row; current = prior }
      }
      : function(this: unknown, ...args: unknown[]) {
        const frame = current?.initialPrune === "pending" ? current : null
        if (frame) { frame.initialPrune = "not-observed"; totals.initialPruneCalls++ }
        else if (current) totals.additionalPruneInPool++
        else totals.pruneOutsidePool++
        try {
          const result = Reflect.apply(original, this, args)
          if (frame) {
            try {
              if (result === null) { frame.initialPrune = "null"; totals.initialPruneNull++ }
              else { frame.initialPrune = "non-null"; totals.initialPruneNonNull++; const length = arrayLength(result, LIMITS.domains); frame.initialSurvivors = Array.from({ length }, (_, index) => arrayLength(own(result, String(index)), LIMITS.candidatesPerDomain)) }
            } catch { totals.observationErrors++ }
          }
          return result
        } catch (error) { if (frame) { frame.initialPrune = "threw"; totals.initialPruneThrows++ } throw error }
      }
    binding.replacement = replacement
    Object.defineProperty(binding.object, binding.name, { ...binding.descriptor, value: replacement })
  }
  return {
    snapshot() {
      const row = last ? { ...last, domains: last.domains?.map(domain => ({ ...domain })) ?? null, initialSurvivors: last.initialSurvivors ? [...last.initialSurvivors] : null, assignmentNames: last.assignmentNames ? [...last.assignmentNames] : null } : null
      const result = { diagnosticOnly: true, accepted49: false, limits: { ...LIMITS }, totals: { ...totals }, activePoolCall: current?.serial ?? null, last: row, exactFailurePayloadObserved: false, backtrackingNodesObserved: false, nullWithoutInitialPruneNullIsUnknown: true, retainedDomains: false, retainedCandidates: false, retainedGeometry: false, weakRefsUsed: false, callbackArgumentsReplaced: false, additionalSolverCalls: 0 }
      if (new TextEncoder().encode(JSON.stringify(result)).byteLength > LIMITS.snapshotBytes) { totals.snapshotOverflows++; return { ...result, last: null, totals: { ...totals } } }
      return result
    },
    restore() {
      if (restored || current) throw Error("Restore once outside original calls")
      for (const binding of bindings) if (own(binding.object, binding.name) !== binding.replacement) throw Error("Observed export changed")
      for (const binding of bindings) Object.defineProperty(binding.object, binding.name, binding.descriptor)
      restored = true
    },
  }
}
