/** Source only until Root explicitly launches; no Core or native import. */
import { Children, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { readFileSync, writeFileSync, existsSync } from "node:fs"
import { createHash } from "node:crypto"
import assert from "node:assert/strict"
import { buildCombinedLocalSource } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-signal96-joint-native-sourceonly-next/combined-source-overlay"
import { buildCombinedClockV11FidelitySource } from "./clock-fidelity-source-overlay"
import proposal from "./clock-fidelity-source-proposal.json"
const [output, ...extra] = process.argv.slice(2)
assert.equal(process.env.G350_CLOCK_FIDELITY_SOURCE_APPROVED, "1")
assert.ok(output && extra.length === 0 && !existsSync(output)); assert.equal(process.versions.bun, "1.3.14")
type Row = { type: string; key: string | null; props: Record<string, unknown>; children: Row[] }
// Mirror the overlay's one recursive clone pass. This retains the actual React
// key contract while normalizing Children.toArray's automatic key prefixes.
function identity(node: ReactNode): ReactNode {
  if (!isValidElement<Record<string, unknown>>(node)) return node
  return cloneElement(node as ReactElement<Record<string, unknown>>, { ...node.props },
    ...Children.toArray(node.props.children as ReactNode).map(identity))
}
function snapshot(node: ReactNode): Row | null {
  if (!isValidElement<Record<string, unknown> & { children?: ReactNode }>(node)) return null
  assert.equal(typeof node.type, "string", "Only actual literal source elements may pass this capture")
  const { children, ...props } = node.props
  return { type: node.type as string, key: node.key, props, children: Children.toArray(children).map(snapshot).filter((r): r is Row => r !== null) }
}
const baselineSource = buildCombinedLocalSource()
const baseline = snapshot(identity(baselineSource.element))!, source = buildCombinedClockV11FidelitySource(), actual = snapshot(source.element)!
function flatten(row: Row): Row[] { return [row, ...row.children.flatMap(flatten)] }
const oldRows = flatten(baseline), rows = flatten(actual)
assert.equal(oldRows.length, 2228); assert.equal(rows.length, 2232)
const rawActual = JSON.stringify(actual)
// Only row props and child arrays change in this inverse; original nested props
// and any component references are kept, rather than coerced through JSON.
function cloneSnapshot(row: Row): Row { return { ...row, props: { ...row.props }, children: row.children.map(cloneSnapshot) } }
const restored = cloneSnapshot(actual), changes = source.exactDeclaredPcbOnlyChanges
const viaNames = new Set(proposal.clockCarriers.flatMap(c => [c.cpu.viaName, c.ram.viaName]))
let removedPorts = 0, inverseClockChanges = 0, inverseTopChanges = 0
for (const row of flatten(restored)) {
  if (viaNames.has(String(row.props.name))) {
    const remove = row.children.filter(c => c.type === "port" && c.props.name === "inner1" && c.props.layer === "inner1")
    assert.equal(remove.length, 1); row.children = row.children.filter(c => c !== remove[0]); removedPorts++
  }
  const change = changes.find(c => c.name === row.props.name)
  if (!change) continue
  if (change.action === "ADD_ORIGINAL_CLOCK_THREE_PCB_PATHS_ONLY") {
    delete row.props.pcbPaths; delete row.props.pcbPathRelativeTo; inverseClockChanges++
  } else {
    row.props.pcbPath = []; inverseTopChanges++
  }
}
assert.equal(removedPorts, 4); assert.equal(inverseClockChanges, 2); assert.equal(inverseTopChanges, 4)
// Stable recursive key comparison; insertion order of restored pcbPath is immaterial.
function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`
  if (value && typeof value === "object") return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical((value as Record<string, unknown>)[k])}`).join(",")}}`
  if (typeof value === "function") return `function:${value.toString()}`
  if (typeof value === "symbol") return `symbol:${String(value)}`
  return JSON.stringify(value) ?? "undefined"
}
assert.equal(canonical(restored), canonical(baseline), "Exact inverse of six PCB-only element changes and four real ports must restore all2228 source definitions")
for (const key of Object.keys(baselineSource).filter(k => k !== "element"))
  assert.equal(canonical((source as Record<string, unknown>)[key]), canonical((baselineSource as Record<string, unknown>)[key]), `Original source metadata: ${key}`)
assert.equal(JSON.stringify(actual), rawActual, "Projection must not mutate actual proposed source")
for (const clock of proposal.clockCarriers) {
  const row = rows.find(r => r.type === "trace" && r.props.name === clock.originalLogicalTraceName)!
  assert.equal(row.props.from, `${clock.cpu.package}.pin${clock.cpu.numericPin}`)
  assert.equal(row.props.to, `${clock.ram.package}.pin${clock.ram.numericPin}`)
  assert.equal(JSON.stringify(row.props.pcbPaths), JSON.stringify(clock.threePcbPaths))
}
const report = {
  scope: "actual-pure-react-clock-fidelity-source-capture",
  proposalSha256: createHash("sha256").update(readFileSync(new URL("./clock-fidelity-source-proposal.json", import.meta.url))).digest("hex"),
  actualPureReactEvaluated: true, originalLiteralCount: 2228, proposedLiteralCount: 2232,
  exactInverseSourceProjectionPassed: true, originalLiteralTypesKeysPropsAndChildOrderCompared: true,
  allOriginalReturnedSourceMetadataCompared: true,
  addedRealLayerPorts: 4, changedPCBOnlyElements: 6, changedPCBProperties: 8,
  original49LogicalEndpointsBusMembershipAndNamedRailsUnchanged: true,
  actualSourceSnapshot: actual, declaredPCBOnlyChanges: changes,
  coreImported: false, coreRendered: false, nativeExecuted: false, cadExecuted: false,
  actualPortMatchesRegistered: false, fullClockLengthNativeQualified: false, accepted49: false, fabricationReady: false,
}
writeFileSync(output, `${JSON.stringify(report, null, 2)}\n`, { flag: "wx", mode: 0o600 })
console.log(JSON.stringify({ scope: report.scope, proposedLiteralCount: 2232, exactInverseSourceProjectionPassed: true, coreRendered: false, output }))
