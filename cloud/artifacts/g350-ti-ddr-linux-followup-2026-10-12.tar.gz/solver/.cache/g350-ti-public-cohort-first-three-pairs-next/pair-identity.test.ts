import { expect, test } from "bun:test"
import { readFileSync } from "node:fs"
import { actualPairLengthReportsByJobIdentity } from "./pair-length-report"
import type { OriginalCapture } from "./identity-order"
import type { SimpleRouteJson, Trace } from "./source/lib/types"

test("sole paired arithmetic entrypoint is stable over all six completion orders and never assumes capped clock length", () => {
  const input = JSON.parse(
    readFileSync(`${import.meta.dir}/input.json`, "utf8"),
  ) as SimpleRouteJson
  const captures: OriginalCapture[] = input.differentialPairs!.map(
    (pair, index) => ({
      jobId: index + 1,
      arguments: [input, pair],
      terminalMethod: index === 2 ? "return" : "next",
      result:
        index === 2
          ? null
          : pair.connectionNames.map(
              (name, rail): Trace => ({
                type: "pcb_trace",
                pcb_trace_id: `MOCK_${name}`,
                connection_name: name,
                route: [
                  {
                    route_type: "wire",
                    x: 0,
                    y: 0,
                    layer: index === 0 ? "bottom" : "top",
                    width: 0.1016,
                  },
                  {
                    route_type: "wire",
                    x: 10 + rail * 0.1,
                    y: 0,
                    layer: index === 0 ? "bottom" : "top",
                    width: 0.1016,
                  },
                ],
              }),
            ),
    }),
  )
  const expected = actualPairLengthReportsByJobIdentity(input, captures)
  const before = JSON.stringify(captures)
  for (const ids of [
    [0, 1, 2],
    [0, 2, 1],
    [1, 0, 2],
    [1, 2, 0],
    [2, 0, 1],
    [2, 1, 0],
  ])
    expect(
      actualPairLengthReportsByJobIdentity(
        input,
        ids.map((id) => captures[id]),
      ),
    ).toEqual(expected)
  expect(expected.map((pair) => pair.completeNaturalBody)).toEqual([
    true,
    true,
    false,
  ])
  expect(expected[2].members).toBeNull()
  expect(JSON.stringify(captures)).toBe(before)
  const changed = structuredClone(captures)
  changed[0].jobId = 2
  expect(() => actualPairLengthReportsByJobIdentity(input, changed)).toThrow()
  const wrong = structuredClone(captures)
  ;(wrong[0].arguments[1] as any).traceGap = 0.13
  expect(() => actualPairLengthReportsByJobIdentity(input, wrong)).toThrow()
})
