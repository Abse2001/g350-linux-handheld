import { expect, test } from "bun:test"
import { BusLanesSolver, type SimpleRouteJson } from "../lib"
import { pairCouplingReports } from "../lib/pair-coupling"
import { pairLengthReports } from "../lib/route-lengths"

const makeFixture = (
  blockedLayers: string[] = ["top"],
): SimpleRouteJson => ({
  layerCount: 4,
  allowedLayers: ["top", "inner1"],
  minTraceWidth: 0.1,
  minTraceToPadEdgeClearance: 0.1,
  bounds: { minX: -6, maxX: 6, minY: -3, maxY: 3 },
  obstacles: [
    {
      center: { x: 0, y: 0 },
      width: 0.3,
      height: 7,
      layers: blockedLayers,
      connectedTo: [],
    },
  ],
  connections: [-0.11, 0.11].map((y, i) => ({
    name: i ? "N" : "P",
    pointsToConnect: [-4, 4].map((x) => ({ x, y, layer: "top" })),
  })),
  differentialPairs: [
    {
      connectionNames: ["P", "N"],
      traceGap: 0.12,
      lengthTolerance: 0.127,
      maxUncoupledLength: 0.01,
    },
  ],
})

const terminalLayers = (layers = ["top", "inner1"]) =>
  new Map([
    ["P", [...layers]],
    ["N", [...layers]],
  ])

const run = (input: SimpleRouteJson, layers = terminalLayers()) => {
  const before = structuredClone(input)
  const solver = new BusLanesSolver(
    input,
    { denseSearch: true, maxSearchIterations: 20000 },
    layers,
  )
  solver.solve()
  expect(input).toEqual(before)
  expect(solver.input.differentialPairs).toEqual(before.differentialPairs)
  return solver
}

const assertClearPair = (solver: BusLanesSolver) => {
  expect(solver.error).toBeNull()
  expect(solver.solved).toBe(true)
  expect(solver.traces).toHaveLength(2)
  expect(
    solver.traces.map((trace) => trace.connection_name).sort(),
  ).toEqual(["N", "P"])
  expect(pairCouplingReports(solver.input, solver.traces)[0].matched).toBe(true)
  const lengths = pairLengthReports(solver.input, solver.traces)[0]
  expect(lengths.matched).toBe(true)
  expect(lengths.skewMm).toBeCloseTo(0, 8)
  for (const member of lengths.lengths)
    expect(member.totalLengthMm).toBeCloseTo(8, 8)
  for (const trace of solver.traces) {
    const connection = solver.input.connections.find(
      (candidate) => candidate.name === trace.connection_name,
    )!
    expect(
      trace.route.every(
        (point) =>
          point.route_type === "wire" &&
          point.layer === "inner1" &&
          point.width === 0.1,
      ),
    ).toBe(true)
    expect(trace.route[0]).toMatchObject(connection.pointsToConnect[0])
    expect(trace.route.at(-1)).toMatchObject(connection.pointsToConnect[1])
  }
}

test("a coupled pair falls back from a blocked layer to a clear available layer", () => {
  assertClearPair(run(makeFixture()))
})

test("a coupled pair can use its sole clear terminal layer", () => {
  const input = makeFixture()
  for (const connection of input.connections)
    for (const point of connection.pointsToConnect) point.layer = "inner1"
  assertClearPair(run(input, terminalLayers(["inner1"])))
})

test("a coupled pair is rejected when every available layer is blocked", () => {
  const solver = run(makeFixture(["top", "inner1"]))
  expect(solver.solved).toBe(false)
  expect(solver.failed).toBe(true)
  expect(solver.failureCode).toBe("no_planar_route")
  expect(solver.traces).toHaveLength(0)
})

test("a coupled pair retains its clear first layer during layer negotiation", () => {
  const input = makeFixture()
  for (const connection of input.connections)
    for (const point of connection.pointsToConnect) point.layer = "inner1"
  assertClearPair(run(input, terminalLayers(["inner1", "top"])))
})
