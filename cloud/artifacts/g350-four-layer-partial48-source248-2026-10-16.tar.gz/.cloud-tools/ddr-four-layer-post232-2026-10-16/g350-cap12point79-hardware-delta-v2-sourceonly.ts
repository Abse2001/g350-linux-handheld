/** Pure Source-only cap12 declaration audit. No I/O, SDK, or geometry execution on import. */
type Row = Record<string, any>
const EPS = 1e-8
export const CAP12_PROFILE = 'CAP12_TRANSLATE_X_0P79_ONLY'
export const CAP12_WORKER_SOURCE_SHA = 'c59dc40e2698664a55e43d809905521df4bc54113516556473ab123ace3cf930'
const need = (ok: unknown, message: string): asserts ok => { if (!ok) throw Error(message) }
const clone = <T>(value: T): T => structuredClone(value)
const canonical = (v: any): string => Array.isArray(v) ? `[${v.map(canonical).join(',')}]` : v && typeof v === 'object'
  ? `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}` : JSON.stringify(v) ?? 'undefined'
const same = (a: unknown, b: unknown) => canonical(a) === canonical(b)
const at = (a: Row, b: Row) => !!a && !!b && Math.hypot(a.x - b.x, a.y - b.y) <= EPS
const one = (rows: Row[], label: string): Row => { need(rows.length === 1, label); return rows[0] }
const xy = (p: Row) => ({ x: p.x, y: p.y })
const planar = (route: Row[]) => route.slice(1).reduce((n, p, i) => n + Math.hypot(p.x - route[i].x, p.y - route[i].y), 0)
const padSpecs = [
  { pad: 'pcb_smtpad_738', port: 'pcb_port_737', oldX: 5.579884, newX: 6.369884 },
  { pad: 'pcb_smtpad_737', port: 'pcb_port_738', oldX: 6.420116, newX: 7.210116 },
]
const referenceSpecs = [
  { id: 'pcb_trace_164', sid: 'source_trace_994', name: 'TI_HS_C_DDR_RAM_12_POWER', pin: 1,
    start: 'pcb_port_737', end: 'pcb_port_1286', via: 'pcb_via_62',
    viaName: 'V_TI_HS_C_DDR_RAM_12_POWER', old: { x: 5.579884, y: 4.7 },
    first: { x: 6.369884, y: 4.7 }, middle: { x: 5.469884, y: 3.8 }, last: { x: 5.2, y: 3.8 } },
  { id: 'pcb_trace_165', sid: 'source_trace_995', name: 'TI_HS_C_DDR_RAM_12_GROUND', pin: 2,
    start: 'pcb_port_738', end: 'pcb_port_1288', via: 'pcb_via_63',
    viaName: 'V_TI_HS_C_DDR_RAM_12_GROUND', old: { x: 6.420116, y: 4.7 },
    first: { x: 7.210116, y: 4.7 }, middle: { x: 6.8, y: 4.289884 }, last: { x: 6.8, y: 3.8 } },
]

/** Construct the only permitted effective projection-input delta from genuine
 * captured rows and a future explicitly SHA-pinned current candidate. This does
 * not edit a raw Circuit JSON array or assign any future Core IDs. */
export function deriveCap12HardwareDelta(raw: Row[], suppliedInput: Row, candidate: Row, candidateBinding: Row): Row {
  need(Array.isArray(raw) && candidateBinding && typeof candidateBinding.path === 'string'
    && /^[a-f0-9]{64}$/.test(candidateBinding.sha256), 'Mandatory actual future candidate path/SHA binding')
  const declaration = candidate.requiredSourceHardwarePlacementDelta
  need(declaration && same(declaration, candidate.cap12PlacementInverse), 'Identical explicit cap12 source/working inverse required')
  need(declaration.name === 'C_DDR_RAM_12' && declaration.source_component_id === 'source_component_136'
    && declaration.pcb_component_id === 'pcb_component_136' && declaration.sourceComponentIdentityUnchanged === true
    && declaration.sourcePlacementAppliedByThisWorker === false && declaration.sourcePlacementMustBeAppliedBeforeSourceNativeCadChecks === true,
    'Exact unrendered cap12 source-placement declaration required')
  const component = one(raw.filter(r => r.type === 'pcb_component' && r.pcb_component_id === 'pcb_component_136'), 'One captured actual cap12 part')
  const source = one(raw.filter(r => r.type === 'source_component' && r.source_component_id === 'source_component_136'), 'One captured actual cap12 source part')
  // A manual via also emits a pcb_component. Distinguish owners by the
  // actual typed source rows, never by a numeric ID suffix or total PCB count.
  const sourceParts = raw.filter(r => r.type === 'source_component')
  const sourceVias = raw.filter(r => r.type === 'source_manually_placed_via')
  const pcbParts = raw.filter(r => r.type === 'pcb_component')
  const partIds = sourceParts.map(r => r.source_component_id)
  const viaIds = sourceVias.map(r => r.source_manually_placed_via_id)
  const pcbIds = pcbParts.map(r => r.pcb_component_id)
  need(sourceParts.length === 280 && sourceVias.length === 230 && pcbParts.length === 510
    && partIds.every(id => typeof id === 'string') && viaIds.every(id => typeof id === 'string')
    && pcbIds.every(id => typeof id === 'string')
    && new Set(partIds).size === 280 && new Set(viaIds).size === 230 && new Set(pcbIds).size === 510
    && partIds.every(id => !viaIds.includes(id))
    && pcbParts.every(r => Number(partIds.includes(r.source_component_id)) + Number(viaIds.includes(r.source_component_id)) === 1)
    && [...partIds, ...viaIds].every(id => pcbParts.filter(r => r.source_component_id === id).length === 1),
    'Exact original typed ownership bijection: 510 PCB components = 280 real source parts + 230 manual vias')
  const capturedOriginalComponentOwnership = { pcbComponents: 510, realSourceParts: 280,
    sourceManuallyPlacedVias: 230, onePhysicalComponentPerTypedSourceOwner: true, unknownOwners: 0 }
  need(source.name === 'C_DDR_RAM_12'
    && component.source_component_id === source.source_component_id && at(component.center, { x: 6, y: 4.7 })
    && component.layer === 'bottom' && component.rotation === 180 && component.display_offset_x === 6,
    'Exact real cap12 source/PCB identity and original Bottom180 placement required')
  const after = clone(component); after.center.x = 6.79; after.display_offset_x = 6.79
  need(same(declaration.before, component) && same(declaration.after, after), 'Only cap12 +0.79 X translation allowed')
  const typedSmtPads: Row[] = [], typedPcbPorts: Row[] = [], obstacleInverses: Row[] = []
  const effective = clone(suppliedInput)
  need(Array.isArray(effective.obstacles) && effective.obstacles.length === 1298 && Array.isArray(effective.traces), 'Genuine compact obstacle/reference input required')
  need(declaration.typedSmtPadInverses?.length === 2 && declaration.typedPcbPortInverses?.length === 2
    && declaration.padObstacleInverses?.length === 2 && declaration.powerReferenceInverses?.length === 2, 'Exact two pads/ports/obstacles/reference inverse roster required')
  for (const spec of padSpecs) {
    const pad = one(raw.filter(r => r.type === 'pcb_smtpad' && r.pcb_smtpad_id === spec.pad), 'One original typed cap12 SMT pad')
    const port = one(raw.filter(r => r.type === 'pcb_port' && r.pcb_port_id === spec.port), 'One original typed cap12 port')
    need(pad.pcb_component_id === component.pcb_component_id && port.pcb_component_id === component.pcb_component_id
      && pad.pcb_port_id === spec.port && at(pad, { x: spec.oldX, y: 4.7 }) && at(port, pad)
      && pad.layer === 'bottom' && same(port.layers, ['bottom']) && pad.shape === 'rect'
      && pad.width === .499999 && pad.height === .540004, 'Captured semantic cap12 pad/port geometry changed')
    const padAfter = { ...clone(pad), x: spec.newX }, portAfter = { ...clone(port), x: spec.newX }
    const pi = one(declaration.typedSmtPadInverses.filter((r: Row) => r.before?.pcb_smtpad_id === spec.pad), 'One declared cap12 SMT inverse')
    const qi = one(declaration.typedPcbPortInverses.filter((r: Row) => r.before?.pcb_port_id === spec.port), 'One declared cap12 port inverse')
    need(same(pi, { before: pad, after: padAfter }) && same(qi, { before: port, after: portAfter }), 'Exact typed pad/port translations only')
    typedSmtPads.push(clone(pi)); typedPcbPorts.push(clone(qi))
    const indices = effective.obstacles.flatMap((r: Row, i: number) => r.circuitJsonMetadata?.pcb_smtpad_id === spec.pad ? [i] : [])
    need(indices.length === 1, 'One genuine cap12 pad obstacle')
    const index = indices[0], beforeObstacle = clone(effective.obstacles[index])
    need(beforeObstacle.componentId === component.pcb_component_id && beforeObstacle.circuitJsonMetadata.pcb_port_id === spec.port
      && at(beforeObstacle.center, pad) && same(beforeObstacle.layers, ['bottom'])
      && beforeObstacle.width === pad.width && beforeObstacle.height === pad.height, 'Exact genuine cap12 obstacle binding')
    const afterObstacle = clone(beforeObstacle); afterObstacle.center.x = spec.newX
    const oi = one(declaration.padObstacleInverses.filter((r: Row) => r.before?.obstacleId === spec.pad), 'One declared cap12 obstacle inverse')
    need(oi.index === index && same(oi.before, beforeObstacle) && same(oi.after, afterObstacle), 'Exact two named obstacle changes only')
    effective.obstacles[index] = afterObstacle; obstacleInverses.push(clone(oi))
  }
  const references: Row[] = []
  for (const spec of referenceSpecs) {
    const captured = one(raw.filter(r => r.type === 'pcb_trace' && r.pcb_trace_id === spec.id), 'One captured cap12 reference path')
    const indices = effective.traces.flatMap((r: Row, i: number) => r.pcb_trace_id === spec.id ? [i] : [])
    need(indices.length === 1, 'One genuine cap12 reference input path')
    const index = indices[0], before = clone(effective.traces[index])
    need(same(before, { ...captured, connection_name: spec.sid }) && captured.source_trace_id === spec.sid
      && before.route.length === 2 && before.route.every((r: Row) => r.route_type === 'wire' && r.layer === 'bottom' && r.width === .2)
      && at(before.route[0], spec.old) && at(before.route[1], spec.last)
      && before.route[0].start_pcb_port_id === spec.start && before.route[1].end_pcb_port_id === spec.end,
      'Exact original .2 Bottom cap12 reference source/port geometry required')
    const afterReference = { ...clone(before), route: [{ ...clone(before.route[0]), ...spec.first },
      { route_type: 'wire', ...spec.middle, layer: 'bottom', width: .2 }, clone(before.route[1])] }
    afterReference.trace_length = planar(afterReference.route)
    const ri = one(declaration.powerReferenceInverses.filter((r: Row) => r.owner === spec.sid), 'One declared cap12 reference inverse')
    need(ri.index === index && same(ri.before, before) && same(ri.after, afterReference)
      && ri.actualStartPort === spec.start && ri.actualFixedEndPort === spec.end && ri.actualFixedEndVia === spec.via
      && ri.bothReferenceNetsPreserved === true, 'Exact two named reference reroutes only')
    const via = one(raw.filter(r => r.type === 'pcb_via' && r.pcb_via_id === spec.via), 'One original fixed cap12 reference via')
    need(at(via, spec.last) && via.outer_diameter === .4572 && via.hole_diameter === .254
      && same(via.layers, ['top', 'inner1', 'inner2', 'bottom']) && via.pcb_port_ids.includes(spec.end), 'Cap12 reference fullspan via is held literally')
    effective.traces[index] = afterReference
    const fromSelector = `C_DDR_RAM_12.pin${spec.pin}`, toSelector = `.${spec.viaName} > port.bottom`
    references.push({ name: spec.name, literalTraceName: spec.name, originalSourceTraceId: spec.sid,
      capturedPcbTraceId: spec.id, fromSelector, toSelector, width: .2, before, after: afterReference,
      absolutePoints: [spec.first, spec.middle, spec.last].map(xy),
      absolutePoints3: [spec.first, spec.middle, spec.last].map(xy), relativeAnchorSelector: 'U_SOC.pin7',
      relativeAnchorXY: { x: 0, y: 20 }, beforeRouteProps: { pcbPath: [] },
      afterRouteProps: { pcbPaths: [[fromSelector, { x: spec.middle.x, y: spec.middle.y - 20 }, toSelector]], pcbPathRelativeTo: 'U_SOC.pin7' } })
  }
  const scene = candidate.full49FanoutInput
  need(scene && same(scene.obstacles, effective.obstacles), 'Candidate obstacles must equal only the two declared cap12 pad changes')
  const ids = suppliedInput.traces.map((r: Row) => r.pcb_trace_id)
  need(ids.length === 165 && new Set(ids).size === 165
    && same(scene.traces.filter((r: Row) => ids.includes(r.pcb_trace_id)), effective.traces), 'Candidate holds163 references and exactly replays both declared cap12 paths')
  const declared = { profile: CAP12_PROFILE, candidateBinding: clone(candidateBinding),
    reviewedWorkerSourceSha256: CAP12_WORKER_SOURCE_SHA,
    capturedOriginalComponentOwnership,
    component: { name: source.name, before: clone(component), after: clone(after), sourceComponent: clone(source),
      sourcePlacement: { before: { pcbX: 6, pcbY: 4.7, layer: 'bottom', pcbRotation: 180 }, after: { pcbX: 6.79, pcbY: 4.7, layer: 'bottom', pcbRotation: 180 } } },
    typedSmtPads, typedPcbPorts, padObstacleInverses: obstacleInverses, references,
    originalDeclaration: clone(declaration), exactPhysicalScope: { componentCount: 280, heldPlacements: 279,
      translatedPlacements: 1, totalLands: 1165, heldLands: 1163, translatedSmtPadsAndPorts: 2,
      totalReferences: 165, heldReferences: 163, reroutedReferences: 2, heldReferenceVias: 129 },
    sourceApplied: false, freshCoreDerived: false, capturedIdsAreMappingProvenanceOnly: true,
    nativeQualified: false, cadQualified: false, all49Accepted: false, fabricationReady: false }
  return { cap12HardwareDelta: declared, effectiveProjectionInput: effective }
}
