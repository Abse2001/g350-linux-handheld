import {Children,cloneElement,isValidElement,type ReactElement,type ReactNode} from "react"
import {readFileSync,writeFileSync} from "node:fs"
import {createHash} from "node:crypto"
import {buildV12eCTiWindowSource} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-c-fresh-ti-window-source-next/v12e-c-fresh-ti-window-overlay"
import {buildJointHsReferenceSource} from "./hs-reference-overlay"
import proposal from "./joint-owner-proposal.json"

/** UNEXECUTED SOURCE: future Root-owned pure React capture before actualCore. */
if(import.meta.main){
 const [output,...extra]=process.argv.slice(2);if(!output||extra.length)throw Error("Usage: bun --smol capture-exact-additions.ts FRESH_OUTPUT_JSON")
 const rows=proposal.owners as Array<Record<string,any>>,selected=rows.filter(r=>r.status==="RAW_JOINT_GEOMETRY_CANDIDATE_PENDING_ACTUAL_SOURCE_CORE_NATIVE")
 const rawBefore=buildV12eCTiWindowSource(),after=buildJointHsReferenceSource()
 function identity(node:ReactNode):ReactNode{if(!isValidElement<Record<string,unknown>>(node))return node;return cloneElement(node as ReactElement<Record<string,unknown>>,{...node.props},...Children.toArray(node.props.children as ReactNode).map(identity))}
 const before={...rawBefore,element:identity(rawBefore.element)}
 let originalElements=0,boards=0,addedElements=0
 function compare(a:ReactNode,b:ReactNode,path:string){
  if(!isValidElement<Record<string,unknown>>(a)||!isValidElement<Record<string,unknown>>(b)){if(JSON.stringify(a)!==JSON.stringify(b))throw Error("Non-element changed: "+path);return}
  originalElements++;if(a.type!==b.type||a.key!==b.key)throw Error("Original type/key changed: "+path)
  const pa={...a.props},pb={...b.props};delete pa.children;delete pb.children
  if(JSON.stringify(pa)!==JSON.stringify(pb))throw Error("Original props changed: "+path)
  const ca=Children.toArray(a.props.children as ReactNode),cb=Children.toArray(b.props.children as ReactNode)
  if(a.type!=="board"&&ca.length!==cb.length)throw Error("Original non-board children changed: "+path)
  if(a.type==="board"){
   boards++;if(cb.length!==ca.length+124)throw Error("Only124 new board child elements required")
   selected.forEach((r,i)=>{
    const via=cb[ca.length+2*i],trace=cb[ca.length+2*i+1]
    if(!isValidElement<Record<string,unknown>>(via)||!isValidElement<Record<string,unknown>>(trace)||via.type!=="via"||trace.type!=="trace")throw Error("Exact new via/trace pair required")
    const vp={...via.props},tp={...trace.props};delete vp.children;delete tp.children
    const expectedV={name:r.viaName,pcbX:r.via.x,pcbY:r.via.y,fromLayer:"top",toLayer:"bottom",outerDiameter:.4572,holeDiameter:.254,connectsTo:`net.${r.referenceNet}`,tented:"top_and_bottom_tented"}
    const expectedT={name:r.traceName,from:`${r.capacitor}.pin${r.numericPin}`,to:`.${r.viaName} > port.bottom`,thickness:.2,pcbPath:[]}
    if(JSON.stringify(vp)!==JSON.stringify(expectedV)||JSON.stringify(tp)!==JSON.stringify(expectedT))throw Error("Unexpected new local-loop source props")
    addedElements+=2
   })
  }
  ca.forEach((c,i)=>compare(c,cb[i],path+"/"+i))
 }
 compare(before.element,after.element,"board")
 if(boards!==1||addedElements!==124||originalElements!==1746)throw Error("Exact original1746 elements plus124 additions required")
 for(const key of ["placementProposal","authoredPolicyProof","referenceCopperCandidates","globalSignalLayerProjection","naturallyDerivedGenericDefaultCap","referenceQualified","TIplaneArrangement","tiWindowProposal"] as const)if(JSON.stringify(after[key])!==JSON.stringify(before[key]))throw Error("Original source metadata changed: "+key)
 const manifest=readFileSync(new URL('./joint-owner-proposal.json',import.meta.url))
 writeFileSync(output,JSON.stringify({scope:"PURE_ACTUAL_REACT_62_HS_TERMINAL_APPEND_ONLY_CAPTURE",actualSourceTreeEvaluated:true,originalElementsCompared:originalElements,addedLiteralViaTraceElements:addedElements,proposalSha256:createHash('sha256').update(manifest).digest('hex'),allOriginalPropsTypesKeysChildrenHeld:true,ram7OriginalElementsHeld:true,all32HsNamesHeld:true,newCoreBuildPerformed:false,newNativeCheckPerformed:false,referenceQualified:false,accepted49:false,fabricationReady:false},null,2)+"\n",{flag:"wx",mode:0o600})
}
