import fs from 'node:fs'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import * as checks from '@tscircuit/checks'
import {g350DdrPhysicalChecks} from '../../scripts/lib/g350-ddr-physical-checks.mjs'
const input='.cloud-tools/ti-ddr-v5-reference-export-next/run/fresh-layout.circuit.json'
const bytes=fs.readFileSync(input)
assert.equal(createHash('sha256').update(bytes).digest('hex'),'98a50b122e6a550c3020c935886d6832dbae34e333ea135e28e9bc555c973d5e')
assert.equal(createHash('sha256').update(fs.readFileSync('node_modules/@tscircuit/checks/dist/index.js')).digest('hex'),'1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc')
const circuit=JSON.parse(bytes)
const results={}
for(const name of [...g350DdrPhysicalChecks,'checkPadPadClearance','checkTracesAreContiguous','checkDanglingTraces','checkPcbTracesOutOfBoard','checkPcbCopperOverKeepout','checkPcbComponentOverlap','checkPcbComponentsOutOfBoard']){
 const start=performance.now();results[name]=checks[name](circuit)
 console.log(JSON.stringify({check:name,errors:results[name].length,seconds:(performance.now()-start)/1000}))
}
const errors=Object.values(results).flat().length
const report={sourceSha256:createHash('sha256').update(bytes).digest('hex'),checksSha256:'1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc',physicalErrors:errors,counts:Object.fromEntries(Object.entries(results).map(([k,v])=>[k,v.length])),results,scope:'Only declared first two bypass traces/vias against full fresh placement. No complete board or DDR connectivity/timing qualification.',ddrSignalsPhysicallyRouted:0,fullBoardQualified:false,referenceContinuityQualified:false,fabricationReady:false}
const output='.cloud-tools/ti-ddr-rule-audit/v5-first-bypass-native-physical.json';assert(!fs.existsSync(output));fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');process.exitCode=errors?1:0
