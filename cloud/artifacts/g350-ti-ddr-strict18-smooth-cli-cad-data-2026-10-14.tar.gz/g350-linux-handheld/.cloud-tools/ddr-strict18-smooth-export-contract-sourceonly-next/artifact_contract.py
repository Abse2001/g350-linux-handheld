"""Stdlib-only immutable artifact/actual Root-stage/Source-owner contract."""
import hashlib,json,math,stat
from pathlib import Path
BOARD=Path('/workspace/g350-linux-handheld')
RAW=BOARD/'.cloud-tools/ddr-strict18-smooth-manual-source-core-successor-next/run-core/raw-core.json'
CONTROLS=RAW.parent/'core-controls.json'
CORE_COLLECTION=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress/strict18-smooth-core-56795-COLLECTED-root.json')
RAW_SHA='371744f3b7ca4ce52e251ec91baacb850768a04e734aef396676439cd0637c54'
CONTROLS_SHA='ce6dbfcf8a52b5e71ed738abd5db46ba2ab887505c59f7dc857df6bdf1892d1d'
CORE_COLLECTION_SHA='8a0e5d76e9c1a85584c8ebf78db4abc438b5d1c94caf0f77b745f07c62755494'
SIGNAL_PROPOSAL=BOARD/'.cloud-tools/ddr-package101-signal96-joint-native-sourceonly-next/signal-source-proposal.json'
SIGNAL_SHA='7430bd5d5201af6e53dde9d07dc38395811adb4e6fc923949d4b4a772c8d304a'

NATIVE_ROOT=BOARD/'.cloud-tools/ddr-strict18-smooth-fresh-native-api-sourceonly-next/run-native'
ACTUAL_NATIVE_COLLECTION={'path':'/workspace/bus-lanes-solver/.cache/root-routing-progress/strict18-smooth-native-api-44382-COLLECTED-root.json','sha256':'e932b6cdea10bfc46e8bc672bfe2767315ed4f992b34c9fb3de360b3ebbf866d'}
ACTUAL_NATIVE_REPORT={'path':str(NATIVE_ROOT/'native18-report.json'),'sha256':'f0241a8e683adaf244f205cbae1fdca3bd439b09a0e91e1f42cd0a10bb8a4b9c'}
ACTUAL_API={'path':str(NATIVE_ROOT/'actual-original-all3-pair-api.json'),'sha256':'579be9ae77ad74a9f1f45e2781e69d0bb76269fcbb835a92fe950fff116deb3e'}
ACTUAL_RESULT={'path':str(NATIVE_ROOT/'result.json'),'sha256':'2df96ad81a0fa05588ab0593a2df8428513b3da693dd17fdcaf63e148e4988fb'}
NATIVE_SOURCE_SHA='3f43f30bfa47c4d1e0696c20f9411f8bd2a1f56119b04fa18f0336d16cea12aa'
BOUND_NATIVE_SHA='a712f501a11f31458a1e54acff7861a5d73cec07db1b0d7d7be2309a9888d8ae'

def require(value,label):
 if not value:raise ValueError(label)
def sha(path):
 digest=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for chunk in iter(lambda:stream.read(1048576),b''):digest.update(chunk)
 return digest.hexdigest()
def regular(path):
 path=Path(path);require(path.is_absolute() and path.is_file() and not path.is_symlink(),'Absolute regular artifact required');return path
def load(binding):
 path=regular(binding['path']);require(path.stat().st_size<=32*1024*1024 and sha(path)==binding['sha256'],'Actual immutable artifact differs');return json.loads(path.read_bytes())
def binding(row):
 path=regular(row['path']);require(sha(path)==row['sha256'] and path.stat().st_size==row['bytes'] and stat.S_IMODE(path.stat().st_mode)==row['mode'],'Source/runtime packet row changed')
def one(rows,label):
 require(len(rows)==1,label+'; matches='+str(len(rows)));return rows[0]
def near(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])<1e-8
def index(raw,kind):
 rows=[r for r in raw if r['type']==kind];out={r[kind+'_id']:r for r in rows};require(len(out)==len(rows),'Unique actual '+kind+' IDs');return out

def collected(row):
 collection=load(row)
 require(collection.get('authorizedByRoot') is True and collection.get('toolSessionCollected') is True and collection.get('passed') is True,'Actual successful Root collection required')
 require(collection.get('toolExitCode')==collection.get('toolWrapperExitCode')==0 and isinstance(collection.get('toolSessionId'),int),'Actual tool wrappers must both exit0')
 post=load({'path':collection['postauditPath'],'sha256':collection['postauditSha256']});execution=post['execution']
 require(collection['execution']==execution and execution['exitCode']==0 and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values()),'Actual owned child/cleanup/OOM success required')
 require(collection['sourceAndDependenciesHeld'] is True and post['sourceAndDependenciesHeld'] is True and post['passed'] is True,'Actual Source/SDK held success required')
 require(post['dependenciesBefore']==post['dependenciesAfter'] and post['solverDependenciesBefore']==post['solverDependenciesAfter'],'Full actual board/solver inventory equality required')
 require(post.get('fabricationReady') is False and post.get('accepted49') is False,'Partial scope must stay explicit')
 return collection,post
def produced(post,row):
 require(any(r['path']==row['path'] and r['sha256']==row['sha256'] for r in post['outputFiles']),'Artifact is not an actual collected stage output');return load(row)

def actual_core():
 collection,post=collected({'path':str(CORE_COLLECTION),'sha256':CORE_COLLECTION_SHA})
 require(collection['sourceManifestSha256']=='deb65c68de4f7852e9ca1f693251574affaab4fb7ce27a07dfd70144e2641707' and collection['coreSourceManifestSha256']=='1159cf6013a1a32820568ae1a2c87e35b9a77176698c07c92a5de803dd2b9dd9','Actual strict18 Source/Core predecessor required')
 raw=produced(post,{'path':str(RAW),'sha256':RAW_SHA});controls=produced(post,{'path':str(CONTROLS),'sha256':CONTROLS_SHA})
 require(controls['freshCoreControlPassed'] is True and len(controls['checks'])==120 and all(c['passed'] is True for c in controls['checks']) and controls['rawCoreSha256']==RAW_SHA,'Actual120 Core controls required')
 return raw,controls

def derive_owned(raw,controls,signal):
 kinds=['pcb_via','pcb_trace','pcb_port','source_port','pcb_component','source_component','source_trace','source_manually_placed_via']
 ix={k:index(raw,k) for k in kinds}
 require([len(ix[k]) for k in ['pcb_via','pcb_trace','pcb_component','source_component']]==[225,279,505,280],'Exact fresh225/279/505/280 inventory')
 tops={r['originalNumericSourcePortId']:r for r in controls['original96TopStubGeometryProjection']};barrels={r['sourceViaName']:r for r in controls['original96SignalBarrelProjection']}
 require(len(tops)==len(barrels)==len(signal['owners'])==96,'Exactly96 real local signal approaches')
 signals=[]
 for owner in signal['owners']:
  projection=tops[owner['originalSourcePortId']];require(projection['exactlyOneTopStub'] and projection['sourceOwnershipHeld'] and len(projection['actualPcbTraceIds'])==1,'One current authentic Top stub')
  via=ix['pcb_via'][barrels[owner['viaName']]['actualViaId']]
  require(barrels[owner['viaName']]['completePhysicalBarrelHeld'] and near(via,owner['viaXY']) and via['outer_diameter']==.4572 and via['hole_diameter']==.254 and via['layers']==['top','inner1','inner2','bottom'] and via['from_layer']=='top' and via['to_layer']=='bottom','Original full-span physical barrel held')
  numeric=one([r for r in ix['pcb_port'].values() if r['source_port_id']==owner['originalSourcePortId']],'Actual numeric PCB port');numeric_source=ix['source_port'][numeric['source_port_id']]
  require(numeric_source['pin_number']==owner['numericPin'] and ix['source_component'][numeric_source['source_component_id']]['name']==owner['package'] and near(numeric,owner['padXY']),'Actual genuine package numeric pad')
  top=one([ix['pcb_port'][p] for p in via['pcb_port_ids'] if ix['pcb_port'][p]['layers']==['top'] and near(ix['pcb_port'][p],via)],'Actual existing Top alias');top_source=ix['source_port'][top['source_port_id']]
  placeholder=ix['pcb_component'][top['pcb_component_id']];source_via=ix['source_manually_placed_via'][top_source['source_component_id']]
  require(top_source['name']=='top' and placeholder['source_component_id']==source_via['source_manually_placed_via_id'] and near(placeholder['center'],via) and placeholder['width']==placeholder['height']==via['outer_diameter'],'Real Source MPV/placeholder ownership')
  local=one([t for t in ix['source_trace'].values() if t.get('name')==owner['traceName']],'One original local Source branch')
  require(set(local['connected_source_port_ids'])=={numeric['source_port_id'],top['source_port_id']},'Authentic numeric-to-own-Top Source branch')
  trace=ix['pcb_trace'][projection['actualPcbTraceIds'][0]];physical_source=ix['source_trace'][trace['source_trace_id']]
  require(len(trace['route'])==2 and all(p['route_type']=='wire' and p['layer']=='top' and p['width']==.1016 for p in trace['route']) and (all(near(a,b) for a,b in zip(trace['route'],owner['topStub'])) or all(near(a,b) for a,b in zip(reversed(trace['route']),owner['topStub']))),'Exact actual owned Topstub geometry')
  require({trace['route'][0].get('start_pcb_port_id'),trace['route'][-1].get('end_pcb_port_id')}=={numeric['pcb_port_id'],top['pcb_port_id']},'Topstub actual endpoint IDs are real numeric/alias owners')
  require(physical_source['subcircuit_connectivity_map_key']==local['subcircuit_connectivity_map_key']==numeric_source['subcircuit_connectivity_map_key']==top_source['subcircuit_connectivity_map_key'],'Actual Source connectivity keys agree')
  signals.append({'originalSourceTraceId':owner['originalSourceTraceId'],'originalNumericSourcePortId':owner['originalSourcePortId'],'actualNumericPcbPortId':numeric['pcb_port_id'],'actualTopPcbPortId':top['pcb_port_id'],'actualViaId':via['pcb_via_id'],'actualPcbTraceId':trace['pcb_trace_id'],'actualPhysicalSourceTraceId':trace['source_trace_id'],'actualLocalSourceTraceId':local['source_trace_id'],'sourceViaOwnerId':source_via['source_manually_placed_via_id']})
 carriers=[];rows=controls['newDirectOriginalSignals']+controls['clocks'];require(len(rows)==18,'Actual16 plus2 direct original carriers')
 for record in rows:
  name=record['originalSourceTraceId'];logical=ix['source_trace'][name];ends=[one([s for s in signals if s['originalNumericSourcePortId']==port],'Actual direct numeric signal endpoint') for port in logical['connected_source_port_ids']]
  require(len(ends)==2 and ends[0]['originalSourceTraceId']==ends[1]['originalSourceTraceId']==name,'Two authentic current endpoints')
  trace_ids=record.get('actualDirectPcbTraceIds',record.get('pcbTraceIds'));require(len(trace_ids)==3 and set(trace_ids)=={t['pcb_trace_id'] for t in ix['pcb_trace'].values() if t['source_trace_id']==name},'All3 actual physical paths belong to original Source ID')
  layer=record.get('carrierLayer','inner1');carrier_id=record.get('actualCarrierPcbTraceId')
  if carrier_id is None:carrier_id=one([i for i in trace_ids if all(p.get('layer')==layer for p in ix['pcb_trace'][i]['route'])],'Actual historical clock carrier')
  require(set(trace_ids)=={carrier_id,ends[0]['actualPcbTraceId'],ends[1]['actualPcbTraceId']},'Actual3 paths exactly CPUstub/carrier/RAMstub')
  trace=ix['pcb_trace'][carrier_id];require(all(p['route_type']=='wire' and p['layer']==layer and p['width']==.1016 for p in trace['route']),'Actual constant-width same-layer carrier')
  anchors=[]
  for end in ends:
   via=ix['pcb_via'][end['actualViaId']];port=one([ix['pcb_port'][p] for p in via['pcb_port_ids'] if ix['pcb_port'][p]['layers']==[layer] and near(ix['pcb_port'][p],via)],'Actual own carrier layer anchor')
   require(ix['source_port'][port['source_port_id']]['source_component_id']==end['sourceViaOwnerId'],'Carrier layer alias has the same genuine Source via owner');anchors.append(port)
  require(trace['route'][0].get('start_pcb_port_id')==anchors[0]['pcb_port_id'] and trace['route'][-1].get('end_pcb_port_id')==anchors[1]['pcb_port_id'],'Actual carrier endpoint IDs bind real same-barrel aliases')
  length=sum(math.hypot(b['x']-a['x'],b['y']-a['y']) for i in trace_ids for a,b in zip(ix['pcb_trace'][i]['route'],ix['pcb_trace'][i]['route'][1:]))
  carriers.append({'originalSourceTraceId':name,'actualDirectPcbTraceIds':trace_ids,'actualCarrierPcbTraceId':carrier_id,'carrierLayer':layer,'actualCpuNumericPcbPortId':ends[0]['actualNumericPcbPortId'],'actualRamNumericPcbPortId':ends[1]['actualNumericPcbPortId'],'actualCpuViaId':ends[0]['actualViaId'],'actualRamViaId':ends[1]['actualViaId'],'actualCpuCarrierLayerPcbPortId':anchors[0]['pcb_port_id'],'actualRamCarrierLayerPcbPortId':anchors[1]['pcb_port_id'],'wholePlanarLengthMm':length})
 require(len({r['originalSourceTraceId'] for r in carriers})==18 and len({r['actualViaId'] for r in signals})==96,'Unique authentic96/18 graph owners')
 segments=sum(a['x']!=b['x'] or a['y']!=b['y'] for trace in ix['pcb_trace'].values() for a,b in zip(trace['route'],trace['route'][1:]))
 return ix,signals,carriers,segments

def validate_all_zero_native_api(collection,post,result,report,api,carriers):
 require(collection['passed'] is True and post['passed'] is True and collection['toolExitCode']==collection['toolWrapperExitCode']==post['execution']['exitCode']==0,'Authentic whole Native/API stage natural0 required')
 require(post['execution']['cleanupOwnedGroupEmpty'] is True and not any(post['execution']['oomDelta'].values()) and post['dependenciesBefore']==post['dependenciesAfter'] and post['solverDependenciesBefore']==post['solverDependenciesAfter'],'Actual all-zero stage collected empty/zeroOOM/SDKheld')
 require(collection['toolSessionId']==44382 and collection['sourceManifestSha256']==post['sourceManifestSha256']==result['sourceManifestSha256']==report['sourceManifestSha256']==NATIVE_SOURCE_SHA,'Authentic actual44382 new source provenance')
 require(collection['packetSha256']==post['packetSha256']==result['packetSha256']==report['packetSha256']==api['packetSha256']==BOUND_NATIVE_SHA,'Exact successful Native/API bound packet')
 require(result['passed'] is True and [(r['phase'],r['exitCode']) for r in result['commands']]==[('native',0),('original3pairAPI',0)],'Both actual Native and original API children must exit0')
 require(result['actualCoreSha256']==api['actualCoreSha256']==RAW_SHA and result['actualCoreControlsSha256']==CONTROLS_SHA,'API/result exact smoothed371/ce6 inputs')
 require(result['actualNativeReportPath']==ACTUAL_NATIVE_REPORT['path'] and result['actualNativeReportSha256']==ACTUAL_NATIVE_REPORT['sha256'] and result['actualOriginal3PairApiReportPath']==ACTUAL_API['path'] and result['actualOriginal3PairApiReportSha256']==ACTUAL_API['sha256'],'Actual Native/API output hashes')
 require(len(report['counts'])==18 and not any(report['counts'].values()) and report['actualNativePairFindings']==[],'Every actual Native physical/manufacturing and all3pair findings0')
 require(api['actualNativeReportPath']==ACTUAL_NATIVE_REPORT['path'] and api['actualNativeReportSha256']==ACTUAL_NATIVE_REPORT['sha256'] and api['allOriginalApiLoaded18ChecksPassed'] is True and api['exactMaterialHeld'] is True,'Actual original private API output must pass')
 require(api['updatedAuthenticPairEvidence']['sha256']=='d95344db6fa0da4527e5b43810471b23d948a6c55589de40661da4222c49cbf3' and api['stale21316IndicesOr068fSource28GeometryUsed'] is False,'New authentic full-path sections, no stale evidence')
 rows=api['continuity'];require(len(rows)==18 and {r['connectionName'] for r in rows}=={c['originalSourceTraceId'] for c in carriers},'All18 actual Source continuity rows required')
 for row in rows:
  carrier=one([c for c in carriers if c['originalSourceTraceId']==row['connectionName']],'API actual Source carrier')
  require(row['actualCarrierPcbTraceId']==carrier['actualCarrierPcbTraceId'] and row['pathVisible'] is True and row['selfClear'] is True and row['conventionalAngles'] is True and row['segmentsVisible'] and all(row['segmentsVisible']),'Every actual path/segment/self/angle predicate must pass')
 for key in ['shared','exterior','coupling','pairLengths']:require(len(api[key])==3 and all(r['matched'] is True for r in api[key]),'All3 actual original '+key+' assertions must pass')
 require(len(api['loadedCohortBusReports'])==3 and all(r['aboveMinimumLength'] is True and r['withinLengthLimit'] is True and r['matched'] is True for r in api['loadedCohortBusReports']),'Actual original loaded-cohort length assertions pass')
 require(api['actualCompleteOriginalSignalCount']==18 and api['expectedMissingOriginalSignalCount']==31 and api['fullOriginalBusRostersAndConstraintsHeld'] is True and api['originalFullDifferentialPairArrayUnchanged'] is True and api['originalPrivateContinuousApiImplementationsUnchanged'] is True,'Partial18/31missing and original full49 rules held')
 require(api['accepted49'] is False and api['fabricationReady'] is False and api['referenceQualified'] is False and api['electricalDelayModelQualified'] is False and api['complete18Accepted'] is False,'No broad qualification from Native/API')

def native_prerequisite(authority,carriers):
 require(authority['actualNativeCollection']==ACTUAL_NATIVE_COLLECTION and authority['actualNativeReport']==ACTUAL_NATIVE_REPORT,'Exact actual44382 all-zero Native/API predecessor required')
 collection,post=collected(authority['actualNativeCollection']);report=produced(post,authority['actualNativeReport'])
 result=produced(post,ACTUAL_RESULT);api=produced(post,ACTUAL_API)
 validate_all_zero_native_api(collection,post,result,report,api,carriers)
 require(report['actualCoreSha256']==RAW_SHA and report['actualCoreControlsSha256']==CONTROLS_SHA and report['checkCount']==18 and report['physicalErrors']==0 and report['physicalCpuRamConnectedCarrierCount']==18 and report['expectedMissingOriginalSignalCount']==31,'Actual Native qualification must cover this exact18 Core')
 require(report['accepted49'] is False and report['fabricationReady'] is False and report['referenceQualified'] is False and report['electricalTimingQualified'] is False,'Native partial/reference/electrical scope must be honest')
 actual=report['actualOwnershipProof']['carriers'];require(len(actual)==18,'Native real18 source-owned graphs required')
 for expected in carriers:
  match=one([r for r in actual if r['originalSourceTraceId']==expected['originalSourceTraceId']],'Native actual matching Source carrier')
  for key,value in expected.items():
   require(abs(match[key]-value)<1e-8 if key=='wholePlanarLengthMm' else (set(match[key])==set(value) if key=='actualDirectPcbTraceIds' else match[key]==value),'Native real graph owner/geometry differs: '+key)
  require(isinstance(match['actualSourceOwnedPhysicalGraph'],dict) and match['actualSourceOwnedPhysicalGraph'].get('physicallyConnected') is True and match['actualSourceOwnedPhysicalGraph'].get('logicalMapAloneNotUsed') is True,'Actual physical graph proof retained')
 return report,post

def authority(row,manifest_sha,scope):
 value=load(row);require(value.get('authorizedByRoot') is True and value.get('scope')==scope and value.get('sourceManifestSha256')==manifest_sha and value.get('actualPreviousScopesCollectedAndEmpty') is True and value.get('noConcurrentRootWorker') is True and value.get('rootFullWorkerReadPassed') is True,'Fresh real Root serial/read authority required');return value
