#!/usr/bin/env python3
"""Independent electrostatic finite-volume estimate, not a factory field solver."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import time

import numpy as np
import scipy
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

assert sys.version_info[:3] == (3, 12, 14)
assert np.__version__ == "2.3.5" and scipy.__version__ == "1.17.0"
EPS0 = 8.8541878128e-12
C = 299792458.0
ZFREE = 1 / (C * EPS0)
ROOT = Path(__file__).resolve().parents[3]
RETAINED = ROOT / ".cloud-tools/ddr-settings-research/calculator-source"


def bind(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def axis(lo, hi, fine_lo, fine_hi, step, critical):
    fine = np.linspace(fine_lo, fine_hi,
                       int(math.ceil((fine_hi - fine_lo) / step)) + 1)
    extra = []
    for start, target, direction in [(fine_lo, lo, -1), (fine_hi, hi, 1)]:
        value, spacing = start, step
        while direction * (target - value) > 0:
            spacing *= 1.14
            value += direction * spacing
            extra.append(max(lo, min(hi, value)))
    return np.unique(np.round(np.concatenate([fine, extra, critical, [lo, hi]]), 12))


def geometry(stack, pair, step_um, box_scale, mask, control=None):
    templ = json.loads((RETAINED / f"JLC04161H-{stack}-template.json").read_text())
    request = next(o for o in json.loads((RETAINED / "prepared-forward-inputs.json").read_text())["requests"]
                   if o["stackup"] == f"JLC04161H-{stack}" and
                   o["model"] == ("DiffEdgeCoupledCoatedMicrostrip1B" if pair else "CoatedMicrostrip1B"))
    h = templ["basicDataList"][1]["dielectricThick"] * 1e-3
    er = templ["basicDataList"][1]["dielectricConstant"]
    w = request["designLowerWidthMm"] * 1e-3
    wt = request["modeledUpperWidthMm"] * 1e-3
    thickness = request["modeledFinishedCopperThicknessMm"] * 1e-3
    gap = (request["designGapMm"] or 0) * 1e-3
    coating_base, coating_top, coating_gap = 0.0254e-3, 0.01524e-3, 0.0254e-3
    coat_er = request["maskModelEr"]
    if control == "microstrip":
        h, w, wt, thickness, er, mask = 0.1e-3, 0.1e-3, 0.1e-3, 0, 4.1, "none"
    centers = [-0.5 * (gap + w), 0.5 * (gap + w)] if pair else [0]
    fine_x = max(abs(v) for v in centers) + w / 2 + 0.045e-3
    xmax, ymax = 1.2e-3 * box_scale, 0.9e-3 * box_scale
    step = step_um * 1e-6
    critical_x = [center + delta for center in centers
                  for delta in [-w / 2, w / 2, -wt / 2, wt / 2, 0]]
    critical_y = [0, h, h + thickness, h + coating_base,
                  h + thickness + coating_top]
    x = axis(-xmax, xmax, -fine_x, fine_x, step, critical_x)
    y = axis(0, ymax, 0, h + thickness + coating_top + 0.035e-3,
             step, critical_y)
    xx, yy = np.meshgrid(x, y)
    owner = np.zeros(xx.shape, dtype=np.int8)
    eps = np.where(yy < h, er, 1.0)
    coating = (yy >= h) & (yy <= h + coating_base)
    if pair:
        coating |= ((xx > centers[0] + w / 2) & (xx < centers[1] - w / 2)
                    & (yy >= h) & (yy <= h + coating_gap))
    for number, center in enumerate(centers, 1):
        if thickness:
            width_at_y = w + (wt - w) * np.clip((yy - h) / thickness, 0, 1)
            copper = ((yy >= h) & (yy <= h + thickness)
                      & (np.abs(xx - center) <= width_at_y / 2 + 1e-15))
        else:
            copper = (np.abs(yy - h) < 1e-15) & (np.abs(xx - center) <= w / 2 + 1e-15)
        owner[copper] = number
        if mask == "stepped":
            coating |= ((np.abs(xx - center) <= w / 2)
                        & (yy >= h) & (yy <= h + thickness + coating_top))
        elif mask == "offset":
            corners = [(center - w / 2, h), (center + w / 2, h),
                       (center + wt / 2, h + thickness),
                       (center - wt / 2, h + thickness)]
            distance2 = np.full(xx.shape, np.inf)
            for a, b in zip(corners, corners[1:] + corners[:1]):
                vx, vy = b[0] - a[0], b[1] - a[1]
                projection = np.clip(((xx - a[0]) * vx + (yy - a[1]) * vy)
                                     / (vx * vx + vy * vy), 0, 1)
                distance2 = np.minimum(distance2, (xx - a[0] - projection * vx) ** 2
                                       + (yy - a[1] - projection * vy) ** 2)
            coating |= (yy >= h) & (distance2 <= coating_top ** 2)
    if mask != "none":
        eps[coating] = coat_er
    fixed = (owner > 0)
    fixed[[0, -1], :] = True
    fixed[:, [0, -1]] = True
    values = np.zeros(xx.shape)
    if pair:
        values[owner == 1], values[owner == 2] = 0.5, -0.5
    else:
        values[owner == 1] = 1
    dims = {"hMm": h * 1e3, "er": er, "wLowerMm": w * 1e3,
            "wUpperMm": wt * 1e3, "copperThicknessMm": thickness * 1e3,
            "gapMm": gap * 1e3 if pair else None, "coatingBaseMm": coating_base * 1e3,
            "coatingTopMm": coating_top * 1e3, "coatingBetweenMm": coating_gap * 1e3,
            "coatingEr": coat_er, "maskProfile": mask,
            "boxHalfWidthMm": xmax * 1e3, "boxHeightMm": ymax * 1e3,
            "nominalFineStepUm": step_um, "gridShape": list(xx.shape)}
    return x, y, eps, owner, fixed, values, dims


def electrostatic(x, y, eps, owner, fixed, values):
    shape = eps.shape
    wx = np.r_[0.5 * (x[1] - x[0]), 0.5 * (x[2:] - x[:-2]),
               0.5 * (x[-1] - x[-2])]
    wy = np.r_[0.5 * (y[1] - y[0]), 0.5 * (y[2:] - y[:-2]),
               0.5 * (y[-1] - y[-2])]
    ex = 2 * eps[:, 1:] * eps[:, :-1] / (eps[:, 1:] + eps[:, :-1])
    ey = 2 * eps[1:, :] * eps[:-1, :] / (eps[1:, :] + eps[:-1, :])
    # Metal has no dielectric permittivity in this perfect-conductor problem.
    # A metal-to-dielectric edge uses only the exterior material coefficient.
    ex = np.where((owner[:, :-1] > 0) & (owner[:, 1:] == 0), eps[:, 1:], ex)
    ex = np.where((owner[:, 1:] > 0) & (owner[:, :-1] == 0), eps[:, :-1], ex)
    ey = np.where((owner[:-1, :] > 0) & (owner[1:, :] == 0), eps[1:, :], ey)
    ey = np.where((owner[1:, :] > 0) & (owner[:-1, :] == 0), eps[:-1, :], ey)
    gx = ex * wy[:, None] / np.diff(x)
    gy = ey * wx[None, :] / np.diff(y)[:, None]
    flat = np.arange(eps.size).reshape(shape)
    edge_a = np.r_[flat[:, :-1].ravel(), flat[:-1, :].ravel()]
    edge_b = np.r_[flat[:, 1:].ravel(), flat[1:, :].ravel()]
    conductance = np.r_[gx.ravel(), gy.ravel()]
    unknown = ~fixed.ravel()
    index = np.full(eps.size, -1)
    index[unknown] = np.arange(np.count_nonzero(unknown))
    a, b = index[edge_a], index[edge_b]
    both = (a >= 0) & (b >= 0)
    ai, bi = a >= 0, b >= 0
    diagonal = np.bincount(a[ai], conductance[ai], minlength=np.count_nonzero(unknown))
    diagonal += np.bincount(b[bi], conductance[bi], minlength=len(diagonal))
    rows = np.r_[np.arange(len(diagonal)), a[both], b[both]]
    cols = np.r_[np.arange(len(diagonal)), b[both], a[both]]
    data = np.r_[diagonal, -conductance[both], -conductance[both]]
    matrix = coo_matrix((data, (rows, cols)), shape=(len(diagonal), len(diagonal))).tocsr()
    voltage = values.ravel().copy()
    rhs = np.zeros(len(diagonal))
    left = ai & ~bi
    right = bi & ~ai
    np.add.at(rhs, a[left], conductance[left] * voltage[edge_b[left]])
    np.add.at(rhs, b[right], conductance[right] * voltage[edge_a[right]])
    start = time.monotonic()
    voltage[unknown] = spsolve(matrix, rhs)
    solve_seconds = time.monotonic() - start
    difference = voltage[edge_a] - voltage[edge_b]
    flux = EPS0 * conductance * difference
    charges = np.bincount(edge_a, flux, minlength=eps.size)
    charges -= np.bincount(edge_b, flux, minlength=eps.size)
    conductor_charge = [float(charges[owner.ravel() == i].sum())
                        for i in range(1, int(owner.max()) + 1)]
    twice_energy = float(EPS0 * np.dot(conductance, difference ** 2))
    boundary_work = float(np.dot(voltage[fixed.ravel()], charges[fixed.ravel()]))
    residual = matrix @ voltage[unknown] - rhs
    return {"twiceEnergyJPerM": twice_energy, "conductorChargesCPerM": conductor_charge,
            "relativeEnergyChargeMismatch": abs(twice_energy - boundary_work) / twice_energy,
            "relativeEquationResidual": float(np.linalg.norm(residual) / max(np.linalg.norm(rhs), 1e-30)),
            "totalChargeCPerM": float(charges.sum()),
            "unknownNodes": len(diagonal), "matrixNonzeros": matrix.nnz,
            "solveSeconds": solve_seconds}


def solve_case(stack, pair, step_um, box_scale, mask, control=None):
    x, y, eps, owner, fixed, values, dims = geometry(stack, pair, step_um, box_scale, mask, control)
    actual = electrostatic(x, y, eps, owner, fixed, values)
    air = electrostatic(x, y, np.ones(eps.shape), owner, fixed, values)
    cap, cap0 = actual["twiceEnergyJPerM"], air["twiceEnergyJPerM"]
    result = {"kind": "differentialOdd" if pair else "single", "dimensions": dims,
              "actual": actual, "air": air, "capacitanceFPerM": cap,
              "vacuumCapacitanceFPerM": cap0, "effectiveEr": cap / cap0,
              "impedanceOhm": 1 / (C * math.sqrt(cap * cap0)),
              "phaseDelayPsPerMmQuasistatic": math.sqrt(cap / cap0) / C * 1e9,
              "notAGroupDelayOrManufacturingGuarantee": True}
    if pair:
        result["oddImpedanceOhm"] = result["impedanceOhm"] / 2
        result["relativeChargeOddSymmetryError"] = abs(sum(actual["conductorChargesCPerM"])) / cap
        result["relativeDiffChargeEnergyError"] = abs(actual["conductorChargesCPerM"][0] - cap) / cap
    return result


def hammerstad_jensen(u, er):
    a = 1 + math.log((u ** 4 + (u / 52) ** 2) / (u ** 4 + 0.432)) / 49 + math.log(1 + (u / 18.1) ** 3) / 18.7
    b = 0.564 * ((er - 0.9) / (er + 3)) ** 0.053
    ee = (er + 1) / 2 + (er - 1) / 2 * (1 + 10 / u) ** (-a * b)
    f = 6 + (2 * math.pi - 6) * math.exp(-(30.666 / u) ** 0.7528)
    zair = ZFREE / (2 * math.pi) * math.log(f / u + math.sqrt(1 + (2 / u) ** 2))
    return {"impedanceOhm": zair / math.sqrt(ee), "effectiveEr": ee,
            "vacuumImpedanceOhm": zair,
            "kind": "Hammerstad/Jensen closed-form approximation for zero-thickness uncoated microstrip; not exact"}


def controls():
    x = np.linspace(0, 1e-3, 51)
    y = np.linspace(0, 0.1e-3, 21)
    xx, yy = np.meshgrid(x, y)
    owner = np.zeros(xx.shape, dtype=np.int8)
    owner[-1, :] = 1
    fixed = np.zeros(xx.shape, dtype=bool)
    fixed[[0, -1], :] = True
    fixed[:, [0, -1]] = True
    values = yy / y[-1]
    plate = electrostatic(x, y, np.full(xx.shape, 4.1), owner, fixed, values)
    expected = EPS0 * 4.1 * (x[-1] - x[0]) / (y[-1] - y[0])
    plate_error = abs(plate["twiceEnergyJPerM"] / expected - 1)
    # Two distinct dielectrics in series; metal interior epsilon is deliberately
    # unphysical to ensure that it cannot affect the exterior-field coefficient.
    series = []
    for step_um in [4, 2, 1, 0.5]:
        sx = np.linspace(0, 1e-3, 21)
        sy = np.unique(np.r_[np.linspace(0, 0.1e-3, int(100 / step_um) + 1), 0.035e-3])
        sxx, syy = np.meshgrid(sx, sy)
        seps = np.where(syy < 0.035e-3, 2.3, 4.1)
        sowner = np.zeros(sxx.shape, dtype=np.int8)
        sowner[-1, :], sowner[0, :] = 1, 2
        seps[sowner > 0] = 123.0
        sfixed = np.zeros(sxx.shape, dtype=bool)
        sfixed[[0, -1], :], sfixed[:, [0, -1]] = True, True
        resistance = 0.035e-3 / 2.3 + 0.065e-3 / 4.1
        svalues = (np.minimum(syy, 0.035e-3) / 2.3
                   + np.maximum(syy - 0.035e-3, 0) / 4.1) / resistance
        answer = electrostatic(sx, sy, seps, sowner, sfixed, svalues)
        exact = EPS0 * 1e-3 / resistance
        series.append({"stepUm": step_um, "actual": answer,
                       "analyticSeriesCapacitanceFPerM": exact,
                       "relativeError": abs(answer["twiceEnergyJPerM"] / exact - 1),
                       "interfaceAtNodeUm": 35,
                       "layerEr": [2.3, 4.1], "metalInteriorErDeliberatelyIrrelevant": 123})
    x, y, eps, owner, fixed, values, dims = geometry("3313", True, 8, 1, "none")
    air = electrostatic(x, y, np.ones(eps.shape), owner, fixed, values)
    homogeneous = electrostatic(x, y, np.full(eps.shape, 4.1), owner, fixed, values)
    scaling_error = abs(homogeneous["twiceEnergyJPerM"] / air["twiceEnergyJPerM"] / 4.1 - 1)
    separate = values.copy()
    separate[owner == 1], separate[owner == 2] = 1, 0
    matrix_case = electrostatic(x, y, np.ones(eps.shape), owner, fixed, separate)
    matrix_diff = (matrix_case["conductorChargesCPerM"][0] - matrix_case["conductorChargesCPerM"][1]) / 2
    diff_error = abs(matrix_diff / air["twiceEnergyJPerM"] - 1)
    microstrip = [solve_case("3313", False, step, 1, "none", "microstrip")
                  for step in [4, 2, 1]]
    analytic = hammerstad_jensen(1, 4.1)
    micro_error = abs(microstrip[-1]["impedanceOhm"] / analytic["impedanceOhm"] - 1)
    passed = (plate_error < 1e-10 and scaling_error < 1e-10 and diff_error < 1e-8
              and series[-1]["relativeError"] < 0.005
              and series[-1]["relativeError"] < series[0]["relativeError"]
              and micro_error < 0.03
              and all(row["actual"]["relativeEquationResidual"] < 1e-8
                      for row in microstrip))
    return {"passed": passed, "parallelPlate": {"actual": plate, "expectedFPerM": expected,
                                                  "relativeError": plate_error},
            "dielectricInterfaceSeriesCapacitorRefinements": series,
            "seriesControlFinestTolerancePercent": 0.5,
            "homogeneousErScalingRelativeError": scaling_error,
            "differentialCapacitanceMatrixNormalizationRelativeError": diff_error,
            "airDifferential": air, "homogeneousDifferential": homogeneous,
            "microstripRefinements": microstrip, "microstripAnalytic": analytic,
            "microstripFinestRelativeErrorAgainstApproximation": micro_error,
            "predeclaredMicrostripApproximationControlTolerancePercent": 3}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--controls", action="store_true")
    parser.add_argument("--stack", choices=["3313", "1080"], default="3313")
    parser.add_argument("--pair", action="store_true")
    parser.add_argument("--step-um", type=float, default=4)
    parser.add_argument("--box-scale", type=float, default=1)
    parser.add_argument("--mask", choices=["offset", "stepped", "none"], default="offset")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert 1 <= args.step_um <= 8 and 1 <= args.box_scale <= 2
    start = time.monotonic()
    inputs = [bind(RETAINED / name) for name in ["prepared-forward-inputs.json",
              "JLC04161H-3313-template.json", "JLC04161H-1080-template.json",
              "CoatedMicrostrip1B-picture.json", "DiffEdgeCoupledCoatedMicrostrip1B-picture.json"]]
    result = controls() if args.controls else solve_case(args.stack, args.pair, args.step_um,
                                                        args.box_scale, args.mask)
    result["runtime"] = {"python": sys.version, "numpy": np.__version__, "scipy": scipy.__version__,
                         "pythonExecutable": sys.executable, "numpyModule": bind(Path(np.__file__)),
                         "scipyModule": bind(Path(scipy.__file__))}
    result["inputBindings"] = inputs
    result["sourceBinding"] = bind(Path(__file__))
    result["wallSeconds"] = time.monotonic() - start
    result["accepted49"] = False
    result["fabricationReady"] = False
    assert inputs == [bind(Path(row["path"])) for row in inputs]
    assert not args.output.exists(), "Preserve prior raw jobs"
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"output": str(args.output), "seconds": result["wallSeconds"],
                      "passedControls": result.get("passed"), "impedanceOhm": result.get("impedanceOhm")}))
    if args.controls and not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
