Resume Source272 from latestSourceVerifiedCheckpoint in PROGRESS.json.
All49 numeric-owned DDR paths are connected. Original .635mm cohort-skew checks
PASS for Byte0 (.5771666935mm) and Byte1 (.5769421603mm). CA still FAILS:
17.4387009342mm skew, only9/26 above the unchanged20.95mm minimum,17 below.
All original49 endpoints, cohort limits and three .127 pair rules remain.

Candidate: /tmp/g350-both-bytes-retimed49-root-20261016-run268/byte0-result.candidate.json
SHA256 fcc50ba7874af9724526a443367f70eeb42bff6179eb07ef8fd3ff929c0c6c77
Raw actual Core272: /tmp/g350-both-bytes-ca9-matched49-core272-raw.json
SHA256 33584d197a1bb45a0dc76ac0a69e7016866a2369f1750c72d5eedc41ef444594
Controls: /tmp/g350-both-bytes-ca9-matched49-core-smol-root-20261016-run272/byte0-result.json
Plan269: /tmp/g350-both-bytes-ca9-matched49-projector-root-20261016-run269/byte0-result.json
Capture270: /tmp/g350-both-bytes-ca9-matched49-capture-root-20261016-run270/byte0-result.json
Fresh Core272 passed35/35 and all49 numeric graphs. Native273 focused16 is
complete: all15 requested geometry checks returned0, with ONE CA bus-skew finding.
Other16 native checks were not rerun. Auth274 authenticated234 real vias, all
foreign via-track results clear with no ambiguous/unknown-owner exemptions.
Four exact batches plus the independent aggregate cover all16 current BREP pours,
234 vias and5097 routed signal-wire segments at .1016mm foreign edge margin.
Both new PDN local contacts passed on CURRENT272 polygons/full-new-land/held
annular witnesses. This is not full DDR reference continuity or own-net proof.

Root-rendered/reviewed PNG/SVG show four layers/all49 and both byte passes plus
the remaining CA failure. Timing/electrical readiness/TI/reference/CAD/default/
fabrication/all49 acceptance remain FALSE. Source264 and older Source257 results
are separate historical branches; no physical/pour/PDN pass is inherited.

Closed260–274 receipts/workers/inputs/logs are saved. Failed262 STEPparse and
failed271 OWNED_RSS_STOP remain failures. Core272's --smol guard bef1 and v3
runtime loader are exact public Sources. All later275/276/277 work is EXCLUDED.
FROZEN at274+current all16 pours/local PDN proof/reviewed plot; later work needs
a NEW saved folder. Root's tracked cloud report and all old folders are untouched.

Restore dependencies in order: Source209 -> Source228 -> Source248 -> Source257,
then this Source272 saved directory/archive. The immutable original OBJ and STEP
assets are already exact board-relative members of Source257; this delta does not
copy or rewrite them. Manifest files are regular /tmp restore targets compatible
with scripts/restore-g350-four-layer-routing-workspace.py --saved-directory
.cloud-tools/ddr-four-layer-post259-v2-2026-10-16. --restore refuses differing local
bytes/modes. V2 obtains solverSourceRoot from the exact pinned Source257 base
manifest; the first frozen post259 snapshot/archive remains unchanged.
Collector never executes that supplied helper, SDK, archive or git.
