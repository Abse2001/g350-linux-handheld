 def inspect29_capture(paths):
  capture,diagnostic=paths['capture'],paths['diagnostic'];r=read_bounded(capture,5242880);d=read_bounded(diagnostic,7340032)
  assert r['scope']=='ACTUAL_ROOT_SOURCE29_CAPTURE_WITH_PARENT26_FULL_INVERSE'and d['scope']=='ACTUAL_SOURCE29_AND_PARENT26_BEFORE_INVERSE_ASSERTIONS'
  for key in('passed','fullInverseSourceTreePassed','actualParent26DeclarationsHeld','original49LogicalTracesHeld','original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse','pureSourceEvaluationExecuted','automaticCoreSrjForThisForkMustNotBeUsed','bothDqs1CoupledViewsRequireFreshOriginalApi'):assert r[key]is True
  for key,value in dict(proposedReactElementCount=2278,previousReactElementCount=2272,genuineNewInnerPortCount=46,exactNewPortDeclarations=6,exactChangedOriginalRouteDeclarations=4,exactChangedLocalSuppressions=6,exactMovedExistingViaCount=1,expectedPhysicalVias=227,expectedPhysicalTraces=292,expectedCarrierPaths=29,missingOriginal49RequestsExpected=20).items():assert r[key]==value
  assert r['movedViaName']=='V_TI_SIGNAL_source_trace_7_1'and r['movedViaCapturedPriorIdProvenanceOnly']is None and r['sourceOnlyProposalSha256']==proposal['promoted29ProposalPin']['sha256']
  assert r['actualDiagnosticPath']==str(diagnostic)and r['actualDiagnosticSha256']==sha(diagnostic)and r['actualSourceTree']==d['actualProposedSource29Tree']
  assert r['actualParent26CapturePin']=={k:proposal['actual48CapturePin'][k]for k in('path','sha256')}
  assert d['actualParent26Tree']==read(proposal['actual48CapturePin']['path'])['actualSourceTree']
  assert d['beforeCounts']['reactElements']==2272 and d['afterCounts']['reactElements']==2278 and d['beforeCounts']['unsupported']==d['afterCounts']['unsupported']==0 and d['inverseChecksExecuted']is False
  for key in('circuitConstructed','coreRendered','all49Accepted','fabricationReady'):assert r[key]is d[key]is False
  for key in('source26QualificationInherited','nativeExecuted','cadExecuted','singleCoupledSectionCoversBoth','referenceQualified','electricalTimingPassed'):assert r[key]is False
  return dict(sourceCapturePin=file_row(capture),sourceDiagnosticPin=file_row(diagnostic),fullSourceInversePassed=True,CoreExecuted=False)

 def inspect29_core(paths,capture_pin):
  raw,controls=paths['raw'],paths['controls'];core=read_bounded(raw,16777216);r=read_bounded(controls,4194304)
  assert isinstance(core,list)and r['scope']=='ROOT_FRESH_EDITABLE_SOURCE_CORE_OWNER_MOVED_227_SOURCE7_SOURCE6_SOURCE18_RESET_REPAIR_29'
  assert r['rawCorePath']==str(raw)and r['rawCoreSha256']==sha(raw)and r['actualCapturePath']==capture_pin['path']and r['actualCaptureSha256']==capture_pin['sha256']
  assert r['freshCoreControlPassed']is True and len(r['checks'])==29 and all(x['passed']is True for x in r['checks'])
  expected={'source_component':280,'source_trace':1195,'pcb_component':507,'pcb_smtpad':1161,'pcb_plated_hole':4,'pcb_hole':2,'pcb_via':227,'source_manually_placed_via':227,'pcb_trace':292,'source_port':1661,'pcb_port':1661,'source_net':98,'source_bus':8,'pcb_keepout':2}
  for kind,count in expected.items():assert sum(row['type']==kind for row in core)==count
  assert len(r['carriers'])==29 and all(x['passed']is True for x in r['carriers'])and len(r['signalTopProjection'])==98 and all(x['passed']is True for x in r['signalTopProjection'])
  assert len(r['original49Projection'])==49 and all(x['passed']is True for x in r['original49Projection'])and len(r['viaProjection'])==227 and all(x['passed']is True for x in r['viaProjection'])
  assert len(r['actualSourcePortMatches']['registrations'])==46 and r['expectedOriginalCarrierCount']==29 and r['expectedMissingOriginalSignalCount']==20 and r['actualNonzeroWireSegmentCount']==1053
  event=r['source3OwnerEvent'];assert event['sourceViaName']=='V_TI_SIGNAL_source_trace_3_0'and event['capturedPriorViaIdProvenanceOnly']=='pcb_via_135'and event['freshIdsDerivedFromActualCore']is True and event['capturedIdAssignedToFreshCore']is False
  vp=event['actualViaProjection'];sp=event['actualTopStubProjection'];cp=event['actualCarrierProjection'];assert vp['passed']is sp['passed']is cp['passed']is True and sp['originalSourceTraceId']==cp['originalSourceTraceId']=='source_trace_3'and sp['side']==0
  via=[v for v in core if v['type']=='pcb_via'and v['pcb_via_id']==vp['actualViaId']];assert len(via)==1 and abs(via[0]['x']-6.2)<1e-8 and abs(via[0]['y']-12.4)<1e-8 and via[0]['layers']==['top','inner1','inner2','bottom']and via[0]['outer_diameter']==.4572 and via[0]['hole_diameter']==.254
  stub=[v for v in core if v['type']=='pcb_trace'and v['pcb_trace_id']==sp['actualPcbTraceId']];assert len(stub)==1 and len(stub[0]['route'])==4 and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in stub[0]['route'])
  moved7=[x for x in r['viaProjection']if x['sourceViaName']=='V_TI_SIGNAL_source_trace_7_1'];stub7=[x for x in r['signalTopProjection']if x['originalSourceTraceId']=='source_trace_7'and x['side']==1];assert len(moved7)==len(stub7)==1 and moved7[0]['passed']is stub7[0]['passed']is True
  via7=[x for x in core if x['type']=='pcb_via'and x['pcb_via_id']==moved7[0]['actualViaId']];assert len(via7)==1 and abs(via7[0]['x']+7.4)<1e-8 and abs(via7[0]['y']-7.8)<1e-8 and via7[0]['layers']==['top','inner1','inner2','bottom']and via7[0]['outer_diameter']==.4572 and via7[0]['hole_diameter']==.254
  top7=[x for x in core if x['type']=='pcb_trace'and x['pcb_trace_id']==stub7[0]['actualPcbTraceId']];assert len(top7)==1 and len(top7[0]['route'])==13 and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in top7[0]['route'])
  for key in('sourceNumericAndPhysicalIdsDerivedWithoutAssignment','pcbRoutingDisabled','authoredPourLiteralsHeldByActualSourceInverse','manualPairSourceBusForkHeld','automaticCoreSrjForThisForkMustNotBeUsed','originalCouplingApisRequiredAgainstFreshActualGeometry'):assert r[key]is True
  for key in('circuitJsonGeometryEdited','parent26ActualQualificationInherited','nativeExecuted','cadExecuted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert r[key]is False
  return dict(rawCorePin=file_row(raw),coreControlsPin=file_row(controls),all29CorePredicatesPassed=True,actualCandidateCarrierCount=29,nativeQualificationPerformed=False)
