"""ONE root-authorized locked tsci source export; no CAD or routing."""
import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
from validate_reference_bypass import validate
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 if sys.argv[1:]!=['--one-approved-source-export'] or os.environ.get('G350_TI_V5_EXPORT_APPROVED')!='1':raise ValueError('Root authorization required before any exporter invocation')
 manifest=json.loads((ROOT/'packet-manifest.json').read_text());raw=(ROOT/'packet-manifest.json').read_bytes();packet=hashlib.sha256(raw).hexdigest()
 if os.environ.get('G350_TI_V5_PACKET_SHA')!=packet:raise ValueError('Root packet binding absent')
 run=ROOT/'run';output=ROOT/manifest['freshOutput'];
 if not run.is_dir() or output.exists() or output.parent.exists():raise ValueError('Fresh exclusive exporter output required')
 started=time.time();command=manifest['originalCommand'];print(json.dumps({'phase':'ORIGINAL_LOCKED_TSCI_SOURCE_EXPORT','command':command,'routingDisabled':True,'cadRequested':False}),flush=True)
 child=subprocess.run(command,cwd=ROOT/'source',env={**os.environ,'G350_REPO_ROOT':'/workspace/g350-linux-handheld'},check=False)
 if child.returncode:raise ValueError('Original tsci source build failed: '+str(child.returncode))
 if not output.is_file() or output.stat().st_mtime<started:raise ValueError('No fresh source output')
 base=json.loads((ROOT/'inputs/base-layout.circuit.json').read_text());compiled=json.loads(output.read_text());table=json.loads((ROOT/'source/lib/am3352/placement/g350-ti-top-bottom-ddr-v5.json').read_text())
 report=validate(base,compiled,table,manifest['planeDeclarations'])
 (run/'fresh-layout.circuit.json').write_bytes(output.read_bytes())
 result={'packetSha256':packet,'sourceBuildExitCode':child.returncode,'originalCommand':command,'sourceOutput':{'path':str(output),'bytes':output.stat().st_size,'sha256':sha(output)},'copiedFreshOutput':{'path':str(run/'fresh-layout.circuit.json'),'sha256':sha(run/'fresh-layout.circuit.json')},'validation':report,'sourceOnlyQualified':True,'sourceDeclarationsAndNineMovesVerified':True,'twoManualReferenceBypassStubsCompiled':True,'autoroutingPerformed':False,'cadPerformed':False,'actualBoardDdr49Accepted':False,'electricalTimingQualified':False,'fabricationReady':False}
 (run/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'sourceOnlyQualified':True,'validation':report}),flush=True)
 return 0
if __name__=='__main__':raise SystemExit(main())
