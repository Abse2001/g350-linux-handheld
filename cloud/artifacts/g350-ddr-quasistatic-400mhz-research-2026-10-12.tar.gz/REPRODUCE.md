This is a proposed research evidence archive; it imports no board copper.
Extract into a NEW ignored directory, then verify every file against bundle-source-manifest.json.
Do not overwrite any frozen project sources or historical raw results.

Initialize the actual managed board environment: cd /workspace/g350-linux-handheld
source cloud/env.sh
Python3.12.14/NumPy2.3.5/SciPy1.17.0 are asserted by the model; package RECORD audit is preserved.
No package install was performed for this research. Existing cloud/python-routing-requirements.txt
preserves the official wheel hashes for auxiliary package reconstruction if needed in a later task.
Use the prepared managed Python3.12.14; a different interpreter must fail closed.

Example fresh local CONTROL reproduction after extraction (no network needed):
source /workspace/g350-linux-handheld/cloud/env.sh
G350_MODEL_RESEARCH=/absolute/path/to/unpacked/project/.cloud-tools/ddr-settings-research/quasistatic-model
python3 "$G350_MODEL_RESEARCH/run-job.py" "$G350_MODEL_RESEARCH/reproduced-controls-execution.json" --controls --output "$G350_MODEL_RESEARCH/reproduced-controls.json"

Example unchanged3313 SINGLE nominal reproduction using a new output path:
python3 "$G350_MODEL_RESEARCH/run-job.py" "$G350_MODEL_RESEARCH/reproduced-3313-single-execution.json" --stack 3313 --step-um 1 --box-scale 2 --mask offset --output "$G350_MODEL_RESEARCH/reproduced-3313-single.json"
For pair mode append --pair. Use --stack 1080 for the second retained template.
All jobs retain the60s/1GiB RSS/1BLAS guard; raw historical output files refuse overwrite.

The old report/command strings record original absolute paths as provenance. Model inputs are read
relative to the copied project root and are self-contained. Compare numerical values/controls,
not entire regenerated JSON hashes containing runtime paths/time. The source-defaults review also
requires a real board Git checkout; do not present this reduced copied project as an editable board.

All results are nominal local electrostatic estimates. See model README/report and independent
review for interface/metal/mask/outer-boundary approximations. No impedance guarantee, electrical
timing pass, accepted49 route, fabrication readiness or exact stackup selection is established.
