#!/usr/bin/env python3
"""SOURCE ONLY. Root-run small MODEL318 increment; never runs SDK/native/CAD.

Build requires the already published exact Source313 archive/manifest. Verify
uses the unchanged generic restorer and no-op workspace helper only after every
existing model/base target and dependency link is authenticated. Source313 stays
the latest editable Source; MODEL318 is a separately labelled model milestone.
"""
import argparse,datetime,gzip,hashlib,json,os,re,shutil,stat,subprocess,sys,tarfile,tempfile
from pathlib import Path,PurePosixPath
BOARD=Path('/workspace/g350-linux-handheld')
BASE=Path('/tmp/g350-source313-portable-increment-20261016')
BASE_REL='.cloud-tools/ddr-four-layer-source313-2026-10-16'
SAVED=Path('/tmp/g350-model318-portable-increment-20261016')
SAVED_REL='.cloud-tools/ddr-four-layer-model318-2026-10-16'
STEM='g350-four-layer-ca17-model318-source313-base-2026-10-16'
BASE_STEM='g350-four-layer-both-bytes-ca16-connected49-source313-2026-10-16'
MODEL_SHA='be1a7d412678c7942b3f3e22a8b4828826c3c90c806ff6257b74cbf528f7f731'
BASE_SHA='8abef05761375014f8a310f9cfcab92d7a5b7da978598fe4a49b1c118658d34d'
BASE_PINS={'PROGRESS.json': '98699140728e17eed957ebd151b4a4902a0603440385cd860cd912731ea7b553', 'README.md': '50e1f3abedbbb264df109f13396de71592088b1cfbd857f43c151456942a26b8', 'WORKSPACE_HASH_INDEX.json': '355676fce02c9eb42a134ebb0cb779621998bc5b5ddd35335519f3fba3de9422', 'WORKSPACE_RESTORE_MANIFEST.json': 'df9b65e530773f88f559679154e2444357a1919ca9c2e483b37fe0a9598ac49d'}
BASE_ARCHIVE_SHA='6204924e3299369cfe4be5e54f983187879f34f983560cef5583b7704a7467ed'
BASE_MANIFEST_SHA='5e866e577fe4f2245cafa0f71416a56e99ffe3f2f7221c603c08490e34b7ff5b'
RESTORER=BOARD/'scripts/restore-g350-routing-evidence.py'
RESTORER_SHA='148bad0fc4132ece5f78f18b05e4bc71d79019312343eda954ed7ca91874a643'
HELPER=BOARD/'scripts/restore-g350-four-layer-routing-workspace.py'
HELPER_SHA='6c5d321a256eadf58697f0f565b5bffa4a55491fce39ed0db7e7675604b6f3cc'
ROWS=[
  {
    "restorePath": "/tmp/g350-source37-three-width-matched49-finite1g-root-20261016-run318/byte0-result.candidate.json",
    "bytes": 13010142,
    "sha256": "be1a7d412678c7942b3f3e22a8b4828826c3c90c806ff6257b74cbf528f7f731",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-source37-three-width-matched49-finite1g-root-20261016-run318/byte0-result.json",
    "bytes": 3246390,
    "sha256": "c4a9e37ab8967b1f1b3c315580fff4c98d01737779f476a45b59c5c9967ebb08",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-source37-three-width-matched49-finite1g-root-20261016-run318/COLLECTED.json",
    "bytes": 2260,
    "sha256": "8769287b89a2fed4bae4b86ef02158194660b019c903c38dbbdbb588d1a02085",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-source37-three-width-matched49-finite1g-root-20261016-run318/owned/execution.json",
    "bytes": 1906,
    "sha256": "e1eddcfd7044ec44686bd2d6fd7bf556752d65cd18ab980852d3e92468d0e48f",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-source37-three-width-matched49-finite1g-root-20261016-run318/owned/child.log",
    "bytes": 461,
    "sha256": "b3c1dc7a0eefd3e41f3f66a8ad86df3300ec826755cef562e8ba47fdc8d9be5f",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-source37-three-width-matched49-finite1g-root-20261016-run318/owned/memory.jsonl",
    "bytes": 260690,
    "sha256": "fea2eddbfad8dfb9d966d50db3a64ab42ae16d592405c45722e9425de02d6bf7",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-actual299-only37-same-two-real-vias-three-width-matched-physical49-v1-sourceonly.ts",
    "bytes": 60079,
    "sha256": "f91d415689aa076641360691259ef32cb337732fd49a581a5bf6acaaff8ca65d",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-actual299-source37-matched21p2-full49-worker-proof.json",
    "bytes": 47233,
    "sha256": "cfd1e3d332a58587df2232898b45299bf61db65fa48a3d845362033c76430d9b",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-actual299-source37-matched21p2-three-width-full49-own-audit-report.json",
    "bytes": 80078,
    "sha256": "3a1e219b8608cb68e2e4cd121cc267936f53e1f9ae6c723755651338f38dbfa4",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-actual299-source37-same-two-vias-I1-finite-trombones-v3-three-width-bank-report.json",
    "bytes": 17708,
    "sha256": "c70a69a2c9e1eb13bf470fed9e0cde30574fc4c82ce8faf50890458e37cd531c",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-actual299-source37-three-width-independent-peer-report.json",
    "bytes": 26360,
    "sha256": "ac458b29a383c9e44c7337c602c662e8059130c90edf1f15f411f76d4a0366ee",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-actual299-source37-three-width-heading-companion-report.json",
    "bytes": 3154,
    "sha256": "f43b37199ca33ffb8f2fc2ce83ff3c8c6af77639d69464e31d7bb65c628c99e4",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-actual284-source37-first-signal-via-SWpoint1-exact-inverse-report.json",
    "bytes": 14149,
    "sha256": "a624a59ef08d6808aa537925e8e8cbaea4517d0ccc9b2c07d57c5452ace414a0",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-actual299-source37-matched21p2-three-width-full49-own-audit-sourceonly.py",
    "bytes": 5749,
    "sha256": "95dfd5acc918a8fa276175ea536a6208ca536fa409c90d22d2b5d53a72c72bda",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-actual299-source37-same-two-vias-I1-finite-trombones-v3-three-width-bank-sourceonly.py",
    "bytes": 6895,
    "sha256": "3f9624bdca278281515380f1177ee2959945f6e4c47280b99d08df804a95babc",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-actual299-source37-three-width-independent-peer-sourceonly.py",
    "bytes": 6042,
    "sha256": "d1471de1fa56bc171a9defd15677cb4a107c01ee755cff6cbfb00c7eabd0d94d",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-actual284-source37-first-signal-via-SWpoint1-exact-inverse-sourceonly.py",
    "bytes": 3880,
    "sha256": "6ca90a825063d5fa58be8cbf651a727b1c775e9ee5da665e280286eeff7ba2b7",
    "mode": 384
  },
  {
    "restorePath": "/tmp/g350-author-actual299-only37-matched-physical49-sourceonly.py",
    "bytes": 14320,
    "sha256": "39bd8c0350caeec1f32662f6fecc9b60afd9275702aa53f6a497e85f98386523",
    "mode": 384
  }
]
META=('README.md','PROGRESS.json','WORKSPACE_RESTORE_MANIFEST.json','WORKSPACE_HASH_INDEX.json')
FALSE={'all49Accepted':False,'fullBoardPassed':False,'nativeBoardPassed':False,'currentPourQualified':False,'fullTimingPassed':False,'electricalTimingQualified':False,'tiQualified':False,'referenceContinuityQualified':False,'cadQualified':False,'defaultBoardPromoted':False,'fabricationReady':False}
def need(v,m):
 if not v:raise ValueError(m)
def regular(p):return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
  os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 return h.hexdigest()
def read(p):return json.loads(p.read_bytes())
def md(p):return {'bytes':p.stat().st_size,'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)}
def exact(p,r):need(regular(p) and md(p)=={k:r[k] for k in ('bytes','sha256','mode')},'Exact bytes/hash/mode '+str(p))
def relative(n):
 p=PurePosixPath(n);need(p.parts and not p.is_absolute() and '..' not in p.parts and str(p)==n and '\\' not in n,'Canonical relative member');return Path(*p.parts)
def write(p,d):
 with p.open('x') as f:os.fchmod(f.fileno(),0o600);json.dump(d,f,indent=2,allow_nan=False);f.write('\n')
def publish(t,p):os.link(t,p);t.unlink()
def source313(a):
 need(a.source313_archive_sha==BASE_ARCHIVE_SHA and a.source313_manifest_sha==BASE_MANIFEST_SHA,'Explicit actual Source313 archive/manifest pins')
 for n,h in BASE_PINS.items():need(regular(BASE/n) and sha(BASE/n)==h,'Frozen Source313 metadata')
 idx,mf,pr=read(BASE/'WORKSPACE_HASH_INDEX.json'),read(BASE/'WORKSPACE_RESTORE_MANIFEST.json'),read(BASE/'PROGRESS.json')
 need(len(idx['files'])==43 and len(mf['files'])==40 and len(mf['baseDependencyRestoreFiles'])==180,'Exact Source31344/40/180 closure')
 need({p.name for p in BASE.iterdir()}=={r['path'] for r in idx['files']}|{'WORKSPACE_HASH_INDEX.json'},'Complete immutable Source313 inventory')
 for r in idx['files']:exact(BASE/relative(r['path']),r)
 targets=[{'baseSavedDirectory':BASE_REL,**r} for r in mf['files']]+mf['baseDependencyRestoreFiles'];need(len(targets)==len({r['restorePath'] for r in targets})==220,'Unique220 base targets')
 for r in targets:exact(Path(r['restorePath']),r)
 ar=BOARD/('cloud/artifacts/'+BASE_STEM+'.tar.gz');mp=ar.with_name(BASE_STEM+'.manifest.json')
 for p,h in [(ar,a.source313_archive_sha),(mp,a.source313_manifest_sha)]:need(re.fullmatch('[0-9a-f]{64}',h) and regular(p) and sha(p)==h,'Explicit actual Source313 archive binding')
 am=read(mp);need(am['scope']=='PORTABLE_SOURCE313_CA16_TI3W_EDITABLE_CONNECTED49_CHECKPOINT' and am['archive']['sha256']==a.source313_archive_sha and am['archive']['bytes']==ar.stat().st_size and am['primaryCandidate']['sha256']==BASE_SHA,'Exact current Source313 portable archive/current299 model')
 need(am['snapshotPins']=={BASE_REL+'/'+n:h for n,h in BASE_PINS.items()} and len(am['files'])==44 and am['workspaceRestoreTargetCount']==40 and am['baseRestoreTargetCount']==180 and am['latestEditableSourceCoreScope']==313,'Pinned complete Source313 archive')
 need(pr['latestEditableSourceCoreScope']==313 and pr['latestEditableSourceSavedDirectory']==BASE_REL and pr['latestSourceVerifiedCheckpoint']['coreScope']==313 and pr['latestSourceVerifiedCheckpoint']['candidateSha256']==BASE_SHA and pr['latestSourceVerifiedCheckpoint']['nativeTotalFindings']==951 and pr['latestSourceVerifiedCheckpoint']['unqualifiedCurrentPourCount']==19,'Actual313 editable qualification boundary, all951 findings/19 unqualified pours retained')
 for dependency in pr['baseArchiveDependenciesInRestoreOrder']:
  for key,h in [('path',dependency['sha256']),('manifest',dependency['manifestSha256'])]:need(regular(BOARD/relative(dependency[key])) and sha(BOARD/relative(dependency[key]))==h,'All prior archive dependencies unchanged')
 required={
 '/tmp/g350-source24-TI3W-foreign34W-matched49-finite1g-root-20261016-run299/byte0-result.candidate.json':BASE_SHA,
 '/tmp/g350-current243-cap8-two-declared-pdn-nodes-Vdd72-descriptor-v2-sourceonly.json':'20e698e6225f7aa0759aa4acf70103c5f90f3894ae94726336e098598b3f3976',
 '/tmp/g350-clock33-shorten-root-20261016-run169/byte0-result.candidate.json':'157b33c88108d5315ad3630ea4f0666ebfb5db0a00376d545299026f05939683',
 '/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json':'d2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607',
 '/tmp/g350-mixed-carrier-physical-four-vias-sourceonly.ts':'cdea6326a318b332ba98bb74bb1c8fd52c3b757bde34d75402558bd6dc86623f',
 '/tmp/g350-current243-cpu-cycle-manual49-cap8-two-planned-PDN-v4-sourceonly.ts':'fd5f61a5593e77a3e669248c1266063c3113f3c427694023a953995ab6e05290'}
 by_path={r['restorePath']:r for r in targets}
 for p,h in required.items():need(p in by_path and by_path[p]['sha256']==h and sha(Path(p))==h,'Every318 literal data/kernel dependency restored by authenticated313 base')
 dep={**am['archive'],'manifest':mp.relative_to(BOARD).as_posix(),'manifestSha256':a.source313_manifest_sha,'mustBeRestoredFirst':True,'payloadCopiedByThisCollector':False}
 return mf,pr,targets,dep

def model_controls():
 for r in ROWS:exact(Path(r['restorePath']),r)
 c,report,receipt,proof,pure,proposal,peer,heading,first=[read(Path(ROWS[i]['restorePath']))for i in (0,1,2,7,8,9,10,11,12)]
 base=read(Path('/tmp/g350-source24-TI3W-foreign34W-matched49-finite1g-root-20261016-run299/byte0-result.candidate.json'))
 owner=lambda t:t.get('connection_name',t.get('source_trace_id'))
 need(c['full49FanoutInput']==base['full49FanoutInput'] and c['heldCarrierTraces']==base['heldCarrierTraces'],'Entire foundation/held6 literal model299/Source313')
 old={owner(t):t for t in base['carrierTraces']};new={owner(t):t for t in c['carrierTraces']}
 need(set(old)==set(new)=={'source_trace_'+str(i)for i in range(49)} and all(new[n]==old[n]for n in old if n!='source_trace_37'),'Only37 body, all48 other bodies literal')
 inv=proof['bodyInverses'];need(len(inv)==1 and inv[0]['owner']=='source_trace_37' and inv[0]['before']==old['source_trace_37'] and inv[0]['after']==new['source_trace_37'] and pure['bodyInverse']==proposal['bodyInverse']=={'before':inv[0]['before'],'after':inv[0]['after']},'Exact37 body inverse/fullpure/proposal binding')
 ev=proof['carrierViaPhysicalEventInverses'];need(len(ev)==2 and ev==pure['carrierViaPhysicalEventInverses'] and [e['before']for e in ev]==[v for v in old['source_trace_37']['route']if v['route_type']=='via'] and [e['after']for e in ev]==[v for v in new['source_trace_37']['route']if v['route_type']=='via'],'Two real carrier fullspan event inverses')
 need(ev[1]['before']==ev[1]['after'] and ev[0]['before']==[v for v in first['bodyInverse']['before']['route']if v['route_type']=='via'][0] and ev[0]['after']==[v for v in first['bodyInverse']['after']['route']if v['route_type']=='via'][0],'Only exact first37 via SW.1; second literal')
 for d in (c,report):
  need(d['all49Connected'] is True and d['allSavedCarriersCurrentSceneQualified'] is True and len(d['finalScenePhysicalReports'])==49 and all(r['passed'] is True and r['joinedNativeGeometryPassed'] is True and r['nativeForeignViaLandGap']['passed'] is True for r in d['finalScenePhysicalReports']),'Fresh model318 all49 physical/native/.15via')
  need(len(d['criticalValidationViews'])==2 and all(v['passed'] is True and v['c31']['solved'] is True and set(v['reports'])=={'bus','pair','shared','coupling','exterior'} and all(len(rs)==3 and all(q['matched'] is True for q in rs) for rs in v['reports'].values()) for v in d['criticalValidationViews']),'Both actual critical views/full5 APIs')
  need(d['byte0PlanarBusSkewPassed'] is True and d['byte1PlanarBusSkewPassed'] is True and d['caCohortPlanarObservation']['minimumPassingCount']==17 and len(d['caCohortPlanarObservation']['minimumFailingOwners'])==9 and d['caCohortPlanarObservation']['fullBusTimingPassed'] is False,'Model318 CA17/bothbytes/fullCAfail')
  q=d['source37ForeignDdrClassSpacingAudit'];need(q['noExceptionWaiversApplied'] is True and q['foreignSubGuidancePairs']==[] and q['sameClass3WCenterlineMm']==.3048 and q['otherDdrClass4WCenterlineMm']==.4064 and q['typicalGuidancePassed'] is True,'Scoped foreign3W/4W proof, no wholeTI claim')
  need(all(d[k] is False for k in ('all49Accepted','matched','nativeExecuted','cadExecuted','freshSourceCoreDerived','fabricationReady')),'Model-only qualification boundary')
 need(len(report['beforeCurrent49PhysicalReports'])==49 and all(r['passed'] is True for r in report['beforeCurrent49PhysicalReports']) and len(report['changedJoinedSignalPhysicalReports'])==1 and all(r['passed'] is True for r in report['changedJoinedSignalPhysicalReports']),'Fresh49 beforecontrols and one complete strong numeric join')
 for key in ('powerReferencePhysicalReports','movedCap8PadFixedCopperPreflight','plannedPdnViaPhysicalReports'):need(len(report[key])==2 and all(r['passed'] is True for r in report[key]),'Actual both retained power/PDN/pad gates '+key)
 need(report['workingBarrelPhysicalJoinAudit']['passed'] is True and report['workingBarrelPhysicalJoinAudit']['dormantWorkingBarrels']==[],'No absent physical working barrel')
 need(receipt['scope']==318 and receipt['execution']['exitCode']==0 and receipt['execution']['cleanupOwnedGroupEmpty'] is True and receipt['execution']['diagnosticStopped'] is False and receipt['sourcePinsUnchanged'] is True and receipt['protectedFilesUnchanged'] is True,'Actual closed318 receipt')
 need(receipt['execution']==read(Path(ROWS[3]['restorePath'])) and receipt['execution']['command'][1]==ROWS[6]['restorePath'] and receipt['execution']['policy']['wallSeconds']==180 and receipt['execution']['policy']['rssBytes']==1024**3 and receipt['execution']['policy']['sharedBytes']==30*1024**3,'Exact actual reviewed worker and bounded1GiB resource closure')
 need(proof['pure37FullProofSha256']==ROWS[8]['sha256'] and pure['proposalSha256']==ROWS[9]['sha256'] and proof['firstViaInverseProposal']['firstViaProposal']['sha256']==ROWS[12]['sha256'] and pure['caMinimumPassingCount']==17 and pure['wholeTiRoutingQualified'] is False,'Frozen pure/proposal/firstvia evidence dependencies')
 need(peer['passedIndependentPurePeer'] is True and peer['reviewedFullProof']['sha256']==ROWS[8]['sha256'] and peer['reviewedHeadingCompanion']['sha256']==ROWS[11]['sha256'] and len(heading['perRunHeadingReports'])==3 and all(r['passed'] is True for r in heading['perRunHeadingReports']) and heading['sameRealTwoFullspanEvents']==ev and heading['preferredFullProof']['sha256']==ROWS[8]['sha256'],'Independent geometric peer and heading companion pass')
 return c,report

def build(a):
 need(not SAVED.exists(),'Fresh model-only staging folder');mf,pr,base_targets,dep=source313(a);c,report=model_controls()
 need(shutil.disk_usage('/tmp').free>sum(r['bytes'] for r in ROWS)+1024**3,'Tmp capacity plus1GiB')
 need(int(Path('/sys/fs/cgroup/memory.current').read_text())+64*1024**2+1024**3<30*1024**3,'Shared30GiB reserve')
 ar=BOARD/('cloud/artifacts/'+STEM+'.tar.gz');mp=ar.with_name(STEM+'.manifest.json')
 need(not ar.exists() and not mp.exists(),'Fresh immutable model archive pair')
 SAVED.mkdir(mode=0o700);rows=[]
 for i,r in enumerate(ROWS+[{'restorePath':str(Path(__file__).resolve()),**md(Path(__file__))}]):
  p=Path(r['restorePath']);n=('MODEL318_OWNED_' if '/owned/' in str(p) else 'MODEL318_')+p.name
  out=SAVED/n
  with p.open('rb') as f,out.open('xb') as g:shutil.copyfileobj(f,g,1048576);os.fchmod(g.fileno(),r['mode'])
  exact(out,r);rows.append({**r,'savedPath':n})
 deps=pr['baseArchiveDependenciesInRestoreOrder']+[dep]
 model={'scope':'MODEL318_ONLY37_I1_MATCHING_FIRST_VIA_SWPOINT1_CA17_BOTH_BYTES_MODEL_PHYSICAL_NO_FRESH_SOURCE','candidateSha256':MODEL_SHA,'savedCandidate':rows[0]['savedPath'],'routedOwners':49,'pendingOwnerIds':[],'all49ModelPhysicalPassed':True,'bothCriticalViewsAndFiveApisPassed':True,'byte0PlanarSkewPassed':True,'byte1PlanarSkewPassed':True,'caMinimumPassingCount':17,'caUnderMinimumCount':9,'caPlanarSkewPassed':False,'source37ForeignDdr3W4WCenterlineSpacingPassed':True,'source37WholeTiQualified':False,'source37WholePlanarLengthMm':21.199999999987046,'first37CarrierViaSwPoint1Declared':True,'sourceCoreReplayExecuted':False,'nativeBoardChecksExecuted':False,'currentPourQualificationPending':True,'currentCadQualificationPending':True,**FALSE}
 common={'scope':model['scope'],'frozenCheckpoint':True,'updatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'latestClosedScopeIncluded':318,'primaryCandidate':model,'primaryModelCandidate':model,'latestSourceVerifiedCheckpoint':pr['latestSourceVerifiedCheckpoint'],'latestEditableSourceSavedDirectory':BASE_REL,'latestEditableSourceCoreScope':313,'model318QualificationInheritedFromSource313':False,'baseArchiveDependency':dep,'baseArchiveDependenciesInRestoreOrder':deps,'laterWorkRequiresNewSavedDirectory':True,**FALSE}
 restore={**common,'solverSourceRoot':mf['solverSourceRoot'],'files':rows,'baseDependencyRestoreFiles':base_targets,'immutableWorkspaceAssets':[],'immutableAssetsRestoredByBaseArchives':mf['immutableAssetsRestoredByBaseArchives']}
 write(SAVED/'WORKSPACE_RESTORE_MANIFEST.json',restore)
 with (SAVED/'README.md').open('x') as f:
  os.fchmod(f.fileno(),0o600);f.write('MODEL318 supplemental branch:49 model paths/both bytes PASS, CA17/26 at minimum;9 short/fullCA skew still FAILS.\nOnly Source37 body and its declared first inline via SW .1 change; all other48 bodies/foundation/critical6 literal model299.\nScoped new37 foreign DDR3W/4W audit has zero exceptions. WholeTI/electrical/fab false.\nLatest editable Source remains313 with its separate951 native findings and19 unqualified pours.\nNo fresh Source/Core/native-board/CAD/pour/PDN qualification is claimed for318.\nRestore209→228→248→257→272-v2→289→Model299→Source313 before this increment.\nExisting generic archive restorer and legacy /tmp workspace helper are compatible.\nNo SDK/application code is executed by this collector/archive author.\n')
 write(SAVED/'PROGRESS.json',{**common,'modelEvidence':rows,'sdkExecutedByCollector':False,'archiveCreatedByOwnStdlib':True})
 index=[{'path':p.name,**md(p)} for p in sorted(SAVED.iterdir())];write(SAVED/'WORKSPACE_HASH_INDEX.json',{'scope':model['scope'],'files':index,'selfExcluded':True,'frozenCheckpoint':True})
 members=[{'path':SAVED_REL+'/'+p.name,'_source':p,**md(p)} for p in sorted(SAVED.iterdir())]
 need(len(members)==23 and len(index)==22 and len(rows)==19,'Exact small23 members/19tmp targets')
 temp=None;durable=None;mt=None
 try:
  fd,n=tempfile.mkstemp(prefix='g350-model318-',suffix='.tar.gz',dir='/tmp');temp=Path(n)
  with os.fdopen(fd,'wb') as output:
   os.fchmod(output.fileno(),0o600)
   with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0,compresslevel=6) as gz:
    with tarfile.open(mode='w|',fileobj=gz,format=tarfile.PAX_FORMAT) as tf:
     for r in members:
      exact(r['_source'],r);info=tarfile.TarInfo(r['path']);info.size=r['bytes'];info.mode=r['mode'];info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
      with r['_source'].open('rb') as f:tf.addfile(info,f)
      exact(r['_source'],r)
   output.flush();os.fsync(output.fileno())
  for r in ROWS:exact(Path(r['restorePath']),r)
  source313(a);actual={'path':ar.relative_to(BOARD).as_posix(),**md(temp)}
  manifest={'schemaVersion':1,'scope':'PORTABLE_MODEL318_CA17_INCREMENT_NOT_FRESH_SOURCE','regularFilesOnly':True,'historicalDataOnly':True,'archive':actual,'files':[{k:v for k,v in r.items() if k!='_source'} for r in members],'inputDirectories':[SAVED_REL],'extraWorkspaceAssetMembers':[],'baseArchiveDependenciesInRestoreOrder':deps,'baseArchivesIncluded':False,'workspaceRestoreTargetCount':19,'baseRestoreTargetCount':220,'snapshotPins':{SAVED_REL+'/'+n:sha(SAVED/n) for n in META},'primaryCandidate':{'path':SAVED_REL+'/'+rows[0]['savedPath'],'sha256':MODEL_SHA},'latestSourceVerifiedCheckpoint':pr['latestSourceVerifiedCheckpoint'],'latestEditableSourceCoreScope':313,'solverSourceRoot':mf['solverSourceRoot'],**FALSE}
  fd,n=tempfile.mkstemp(prefix='.'+mp.name+'.',suffix='.partial',dir=mp.parent);mt=Path(n)
  with os.fdopen(fd,'w') as f:os.fchmod(f.fileno(),0o600);json.dump(manifest,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
  need(shutil.disk_usage(ar.parent).free>temp.stat().st_size+256*1024**2,'Measured model archive plus256MiB durable reserve')
  fd,n=tempfile.mkstemp(prefix='.'+ar.name+'.',suffix='.partial',dir=ar.parent);durable=Path(n)
  with temp.open('rb') as f,os.fdopen(fd,'wb') as g:shutil.copyfileobj(f,g,1048576);os.fchmod(g.fileno(),0o600);g.flush();os.fsync(g.fileno())
  exact(durable,actual);publish(durable,ar);durable=None;publish(mt,mp);mt=None
  print(json.dumps({'archive':str(ar),'archiveSha256':sha(ar),'manifest':str(mp),'manifestSha256':sha(mp),'files':23,'tmpTargets':19,'baseTargets':220,'latestEditableSource':313,'primaryModelScope':318,'sdkExecuted':False,'fabricationReady':False}))
 finally:
  for p in (temp,durable,mt):
   if p is not None and p.exists():p.unlink()

def verify(a):
 _,_,base_targets,_=source313(a);model_controls();ar=BOARD/('cloud/artifacts/'+STEM+'.tar.gz');mp=ar.with_name(STEM+'.manifest.json')
 for p,h in [(ar,a.archive_sha),(mp,a.manifest_sha)]:need(h and re.fullmatch('[0-9a-f]{64}',h) and regular(p) and sha(p)==h,'Actual new model archive/manifest SHA')
 am=read(mp);need(am['scope']=='PORTABLE_MODEL318_CA17_INCREMENT_NOT_FRESH_SOURCE' and am['archive']['sha256']==a.archive_sha and len(am['files'])==23,'Exact MODEL31823-member increment')
 for p,h in [(RESTORER,RESTORER_SHA),(HELPER,HELPER_SHA)]:need(regular(p) and sha(p)==h,'Exact existing restoration Source')
 owned=Path(tempfile.mkdtemp(prefix='g350-model318-smoke-',dir='/tmp'));dest=owned/'extracted';commands=[]
 def run(argv):
  r=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=120,check=False);commands.append({'argv':argv,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});need(r.returncode==0,'Restoration-only verifier');return r.stdout
 try:
  command=[sys.executable,str(RESTORER),str(mp),'--destination',str(dest)]
  need(run(command+['--verify-archive']).strip()=='Verified 23 evidence members; restored 0','Exact verify count')
  need(run(command).strip()=='Verified 23 evidence members; restored 23','Exact isolated23 extraction')
  names={p.relative_to(dest).as_posix() for p in dest.rglob('*') if p.is_file()};need(names=={r['path'] for r in am['files']},'Only exact regular archive members')
  for r in am['files']:exact(dest/relative(r['path']),r)
  for n,h in am['snapshotPins'].items():need(sha(dest/relative(n))==h,'All extracted metadata pins')
  mf=read(dest/SAVED_REL/'WORKSPACE_RESTORE_MANIFEST.json');need(len(mf['files'])==19 and mf['baseDependencyRestoreFiles']==base_targets and mf['latestEditableSourceCoreScope']==313,'Literal220 base restore refs and19 local targets')
  targets=mf['files']+base_targets;need(len(targets)==len({r['restorePath'] for r in targets})==239,'All239 current targets exist before no-op')
  for r in targets:exact(Path(r['restorePath']),r)
  link=Path(mf['solverSourceRoot']).parent/'node_modules';need(link.is_symlink() and link.resolve()==(BOARD.parent/'bus-lanes-solver/node_modules').resolve(),'Existing exact dependency link')
  link_id=(link.lstat().st_dev,link.lstat().st_ino,link.lstat().st_mtime_ns,link.lstat().st_ctime_ns,os.readlink(link))
  result=json.loads(run([sys.executable,str(HELPER),'--saved-directory',str(dest/SAVED_REL),'--restore']));need(result['savedFilesVerified']==19 and result['restoredFiles']==0 and result['mode']=='restore','Existing complete restore branch is zero-write')
  for r in targets:exact(Path(r['restorePath']),r)
  need((link.lstat().st_dev,link.lstat().st_ino,link.lstat().st_mtime_ns,link.lstat().st_ctime_ns,os.readlink(link))==link_id,'Dependency link unchanged')
  source313(a);model_controls();need(sha(ar)==a.archive_sha and sha(mp)==a.manifest_sha,'Archive inputs unchanged')
  shutil.rmtree(dest);write(owned/'REPORT.json',{'scope':'MODEL318_INCREMENT_ISOLATED_EXTRACTION_AND239_TARGET_NOOP_RESTORE_NOT_SOURCE_QUALIFICATION','passed':True,'commands':commands,'archiveSha256':a.archive_sha,'manifestSha256':a.manifest_sha,'isolatedPayloadRemoved':True,'all239ActualTargetsUnchanged':True,'existingHelperRestoreCodePathExecuted':True,'restoredWorkspaceFiles':0,'latestEditableSource':313,'primaryModelScope':318,'sdkExecuted':False,**FALSE})
  print(json.dumps({'report':str(owned/'REPORT.json'),'sha256':sha(owned/'REPORT.json'),'passed':True,'sdkExecuted':False}))
 except BaseException as e:
  write(owned/'FAILURE.json',{'passed':False,'error':str(e),'commands':commands,'isolatedPayloadPreserved':dest.exists(),**FALSE});raise

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['build','verify']);p.add_argument('--source313-archive-sha',required=True);p.add_argument('--source313-manifest-sha',required=True);p.add_argument('--archive-sha');p.add_argument('--manifest-sha');a=p.parse_args()
 (build if a.mode=='build' else verify)(a)
if __name__=='__main__':main()
