"""Nonmutating complete installed board dependency-tree inventory."""
import hashlib,json,os,stat
from pathlib import Path

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def tree(root):
 root=Path(root);items=[]
 for d,dirs,files in os.walk(root,followlinks=False):
  for name in sorted([*dirs,*files]):
   p=Path(d)/name;s=p.lstat();relative=p.relative_to(root).as_posix();row={'path':relative,'mode':stat.S_IMODE(s.st_mode)}
   if stat.S_ISLNK(s.st_mode):
    target=os.readlink(p);resolved=p.resolve();
    if resolved!=root and root not in resolved.parents:raise ValueError('External dependency symlink: '+relative)
    if not resolved.exists():raise ValueError('Broken dependency symlink: '+relative)
    row.update(type='symlink',target=target)
   elif stat.S_ISREG(s.st_mode):row.update(type='file',bytes=s.st_size,sha256=sha(p))
   elif stat.S_ISDIR(s.st_mode):row.update(type='directory')
   else:raise ValueError('Special installed dependency entry: '+relative)
   items.append(row)
 items.sort(key=lambda x:x['path']);digest=hashlib.sha256(json.dumps(items,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 return dict(root=str(root),treeSha256=digest,regularFiles=sum(i['type']=='file' for i in items),regularBytes=sum(i.get('bytes',0) for i in items),symlinks=sum(i['type']=='symlink' for i in items),directories=sum(i['type']=='directory' for i in items),items=items)
