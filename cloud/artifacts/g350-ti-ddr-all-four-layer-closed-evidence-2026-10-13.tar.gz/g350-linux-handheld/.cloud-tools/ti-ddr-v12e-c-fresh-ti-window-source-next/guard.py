"""One original bounded pure fresh TI CA-window React capture; no Core/native/router."""
import argparse,copy,hashlib,importlib.util,json,re,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
import inventory,process_scope
from audit_ti_endpoints import audit
ROOT=Path(__file__).resolve().parent
BOARD=Path('/workspace/g350-linux-handheld')
PARENT=BOARD/'.cloud-tools/ti-ddr-v12e-c-cohort-qualified-input-bridge-next'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def require(v,s):
 if not v:raise ValueError(s)
def checked():
 m=load(ROOT/'CAPTURE-manifest.json')
 for base in [ROOT,ROOT.parent]:
  for name in ['node_modules','.pnp.cjs','.pnp.loader.mjs','.yarn']:require(not (base/name).exists() and not (base/name).is_symlink(),'Unexpected nearest dependency resolver')
 for key,base in [('files',ROOT),('externalFiles',None)]:
  for row in m[key]:
   p=base/row['path'] if base else Path(row['path'])
   require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Frozen member changed: '+str(p))
 spec=importlib.util.spec_from_file_location('g350_actual_parent_c_geometry_bridge',PARENT/'v12e_c_input_provenance.py');parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent)
 proof=parent.verify(m['parentBridgeManifestSha256']);require(proof['freshCircuitSha256']==m['reusedActualCoreGeometrySha256'] and proof['nativePlacementChecks']==17 and proof['nativePlacementErrors']==0,'Original actual E geometry/native17 required')
 audit()
 deps=inventory.tree(BOARD/'node_modules');small={k:deps[k] for k in ['treeSha256','regularFiles','regularBytes','symlinks','directories']};require(small==m['boardDependencyInventory'],'Complete pinned installed board dependencies changed')
 return m,sha(ROOT/'CAPTURE-manifest.json'),small

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--preflight',action='store_true');parser.add_argument('--launch-receipt',type=Path);parser.add_argument('--receipt-sha256');args=parser.parse_args();require(args.preflight!=bool(args.launch_receipt),'Select preflight or exact Root receipt')
 m,packet_sha,before=checked()
 if args.preflight:print(json.dumps({'preflightOnly':True,'packetSha256':packet_sha,'sourceHeld':True,'coreNativeRouterCalls':0}));return 0
 require(re.fullmatch('[0-9a-f]{64}',args.receipt_sha256 or '') and sha(args.launch_receipt)==args.receipt_sha256,'Exact Root receipt hash required');a=load(args.launch_receipt)
 require(a.get('authorizedByRoot') is True and a.get('scope')==m['authorityScope'] and a.get('packetSha256')==packet_sha and a.get('policy')==m['policy'] and re.fullmatch('[0-9a-f]{32,128}',a.get('approvalToken','')),'Exact Root scope/packet/policy required')
 closed_path=Path(a.get('previousPublicClosedPostauditPath',''));closed_sha=a.get('previousPublicClosedPostauditSha256','')
 require(re.fullmatch('[0-9a-f]{64}',closed_sha) and closed_path.resolve()==Path(m['previousActivePublicPostauditPath']) and sha(closed_path)==closed_sha,'Original active Root route must close before capture')
 closed=load(closed_path);require(closed['execution']['cleanupOwnedGroupEmpty'] is True and not any(closed['execution']['oomDelta'].values()) and closed['sourceAndArtifactHeld'] is True,'Previous owned public group must be cleanly empty and source-held')
 require(not (ROOT/'run').exists(),'One exclusive fresh capture only');output=ROOT/'run/actual-final-props.json'
 def before_spawn(memory):require(memory['current']+m['policy']['rssBytes']+m['preforkReserveBytes']<m['policy']['sharedBytes'],'Strict original prefork reserve required')
 execution=process_scope.run_guarded([m['bun'],'--smol',str(ROOT/'capture-v12e-c-ti-window.ts'),str(output)],str(ROOT),ROOT/'run',m['policy'],{},before_spawn=before_spawn)
 after_m,after_sha,after=checked();d=load(output) if output.is_file() else None
 passed=(execution['exitCode']==0 and execution['diagnosticStopped'] is False and execution.get('cleanupOwnedGroupEmpty') is True and not any(execution['oomDelta'].values()) and before==after and packet_sha==after_sha and d is not None)
 if passed:
  derived=load(ROOT/'derived-final-authored-props.json')
  passed=(d['scope']=='PURE_ACTUAL_V12E_C_FRESH_TI_CA_TWO_LENGTH_PROPS_ONLY' and d['actualFinalReactTreeEvaluated'] is True and d['comparedElements']>280 and d['allOtherTreePropsTypesKeysChildrenExactlyHeld'] is True and len(d['changedLengthProps'])==2 and sorted(d['changedLengthProps'],key=lambda x:(x['busId'],x['field']))==sorted(m['twoLengthPropChanges'],key=lambda x:(x['busId'],x['field'])))
  for key in ['placementProposal','authoredPolicyProof','referenceCopperCandidates','globalSignalLayerProjection','naturallyDerivedGenericDefaultCap']:passed=passed and d[key]==derived[key]
  for key in ['referenceQualified','TIplaneArrangement','newCoreBuildPerformed','newNativePlacementCheckPerformed','coreRenderCalled','nativePlacementChecksInvoked','routingSolverInstantiated','accepted49','fabricationReady']:passed=passed and d[key] is False
 report={'passed':passed,'scope':m['authorityScope'],'sourceManifestSha256':packet_sha,'execution':execution,'captureSha256':sha(output) if output.is_file() else None,'boardDependenciesBefore':before,'boardDependenciesAfter':after,'sourceHeld':packet_sha==after_sha,'reusedActualCoreGeometrySha256':m['reusedActualCoreGeometrySha256'],'nativePlacementChecksInheritedNotRerun':True,'newCoreBuildPerformed':False,'newNativePlacementCheckPerformed':False,'referenceQualified':False,'TIplaneArrangement':False,'accepted49':False,'fabricationReady':False}
 with (ROOT/'run/RECEIPT.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
 print(json.dumps({'passed':passed,'captureSha256':report['captureSha256'],'newCoreNativeCalls':0}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
