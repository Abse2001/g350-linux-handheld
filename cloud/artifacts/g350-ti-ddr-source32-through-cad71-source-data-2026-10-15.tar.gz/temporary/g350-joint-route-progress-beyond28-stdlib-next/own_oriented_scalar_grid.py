"""Own bounded A*, with octilinear headings and <=45 degree turns only."""
import heapq,math
DIRS=[(1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1)]
def route(q,g,name,layer,start,goal,startHeading=None,endHeading=None,cap=160000,step=.1,bounds=(-14,-2,10,22)):
 clear,_=q.setup(layer,name);a,z=[tuple(round(x/step)for x in xy)for xy in(start,goal)]
 if not clear(start,start)or not clear(goal,goal):return dict(termination='ENDPOINT_BLOCKED')
 def point(xy):return xy[0]*step,xy[1]*step
 def near_head(a,b):return abs((a-b+4)%8-4)<=1
 def h(xy):
  dx,dy=abs(xy[0]-z[0]),abs(xy[1]-z[1]);return step*(max(dx,dy)+(math.sqrt(2)-1)*min(dx,dy))
 initial=(*a,-1 if startHeading is None else startHeading);cost={initial:0.};heap=[(h(a),0.,initial)];parent={};edges={};expanded=0
 while heap and expanded<cap:
  _,c,u=heapq.heappop(heap)
  if c!=cost.get(u):continue
  x,y,hd=u
  if (x,y)==z and(endHeading is None or near_head(hd,endHeading)):
   path=[goal];cur=u
   while cur!=initial:cur=parent[cur];path.append(point(cur[:2]))
   path[-1]=start;path.reverse();return dict(termination='FOUND',expanded=expanded,points=g.simplify(path),lengthMm=g.plen(path))
  expanded+=1
  for nh,(dx,dy)in enumerate(DIRS):
   if hd!=-1 and not near_head(nh,hd):continue
   v=(x+dx,y+dy,nh);vp=point(v[:2])
   if not(bounds[0]<=vp[0]<=bounds[2]and bounds[1]<=vp[1]<=bounds[3]):continue
   le=c+step*(math.sqrt(2)if dx and dy else 1)
   if le>=cost.get(v,math.inf)-1e-12:continue
   edge=tuple(sorted(((x,y),v[:2])))
   if edge not in edges:edges[edge]=clear(point((x,y)),vp)
   if edges[edge]:cost[v]=le;parent[v]=u;heapq.heappush(heap,(le+h(v[:2]),le,v))
 return dict(termination='CAP'if heap else'EXHAUSTED_FINITE_ORIENTED_GRID',expanded=expanded)
