#!/usr/bin/env python3
"""SOURCE ONLY: Root-run MODEL328 portable increment; no SDK/native/CAD execution.

Build and verify adapt the tested Model318-v2 kernel. Model328's physical-only
snapshot cuts at328; subsequent replay results are excluded. Source313 remains
the editable checkpoint carried in this restore chain, with its own boundaries.
"""
import argparse, datetime, gzip, hashlib, json, os, re, shutil, stat, subprocess, sys, tarfile, tempfile
from pathlib import Path, PurePosixPath

BOARD = Path('/workspace/g350-linux-handheld')
BASE = Path('/tmp/g350-model318-portable-increment-20261016')
BASE_REL = '.cloud-tools/ddr-four-layer-model318-2026-10-16'
BASE_STEM = 'g350-four-layer-ca17-model318-source313-base-2026-10-16'
BASE_ARCHIVE_SHA = 'f7090db168c637688eaaa4b6456a1de83edc0d2e3ead44a2a7458a12ec82ccc6'
BASE_MANIFEST_SHA = '53c4db6ad308559d5ef5f5c991b24d758550e3dcc7b0c8c033656b1231856c15'
BASE_PINS = {'PROGRESS.json': '71295cee8cfa8d6998cfc5df69030b7b3a622d8d00303fce33a1b8a3d0c9e77c', 'README.md': '836d5a52adc190fc501f743d1942390a68a538244bd6be367c7585306582286e', 'WORKSPACE_HASH_INDEX.json': 'a384ef5171a2a0ecc8f975ad6198119309d6c4511f8ca69486214cd028fb12e3', 'WORKSPACE_RESTORE_MANIFEST.json': 'c7f21f5d5d440a01cabbe359e091d958354a92f4f2af7528e02525709f030bbf'}
BASE_CANDIDATE_SHA = 'be1a7d412678c7942b3f3e22a8b4828826c3c90c806ff6257b74cbf528f7f731'
MODEL_SHA = '056cac41c6a654b417f6c088d871b8aab41bdaf1bfd42f570acd9dd42d7a09c8'
PROFILE = Path('/tmp/g350-model328-portable-increment-profile-sourceonly.json')
PROFILE_SHA = '1f6c66420523c3c990afd1f8acc4d3434506b18e981d43fb33bf8d018ef42e69'
SAVED = Path('/tmp/g350-model328-portable-increment-20261017')
SAVED_REL = '.cloud-tools/ddr-four-layer-model328-2026-10-17'
STEM = 'g350-four-layer-ca18-model328-source313-base-2026-10-17'
SCOPE = 'PORTABLE_MODEL328_FOUR_BODY_CA18_INCREMENT_NOT_FRESH_SOURCE'
SOLVER_ROOT = '/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib'
RESTORER = BOARD/'scripts/restore-g350-routing-evidence.py'
RESTORER_SHA = '148bad0fc4132ece5f78f18b05e4bc71d79019312343eda954ed7ca91874a643'
HELPER = BOARD/'scripts/restore-g350-four-layer-routing-workspace.py'
HELPER_SHA = '6c5d321a256eadf58697f0f565b5bffa4a55491fce39ed0db7e7675604b6f3cc'
META = ('README.md', 'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json')
FALSE = dict.fromkeys(('all49Accepted','fullBoardPassed','nativeBoardPassed','currentPourQualified','fullTimingPassed','electricalTimingQualified','tiQualified','referenceContinuityQualified','cadQualified','defaultBoardPromoted','fabricationReady'), False)

def need(value, message):
    if not value:
        raise ValueError(message)

def regular(path):
    return path.is_file() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
        os.posix_fadvise(stream.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return h.hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def md(path):
    return {'bytes': path.stat().st_size, 'sha256': sha(path), 'mode': stat.S_IMODE(path.stat().st_mode)}

def exact(path, row):
    need(regular(path) and md(path) == {key: row[key] for key in ('bytes','sha256','mode')}, 'Exact bytes/hash/mode '+str(path))

def relative(name):
    p = PurePosixPath(name)
    need(p.parts and not p.is_absolute() and '..' not in p.parts and str(p) == name and '\\' not in name, 'Canonical relative member')
    return Path(*p.parts)

def write(path, data):
    with path.open('x') as stream:
        os.fchmod(stream.fileno(), 0o600)
        json.dump(data, stream, indent=2, allow_nan=False)
        stream.write('\n')

def publish(temporary, final):
    os.link(temporary, final)
    temporary.unlink()

def source318(args):
    need(args.model318_archive_sha == BASE_ARCHIVE_SHA and args.model318_manifest_sha == BASE_MANIFEST_SHA, 'Explicit actual Model318 archive pins')
    for name, digest in BASE_PINS.items():
        need(regular(BASE/name) and sha(BASE/name) == digest, 'Frozen Model318 metadata')
    index, manifest, progress = [read(BASE/n) for n in ('WORKSPACE_HASH_INDEX.json','WORKSPACE_RESTORE_MANIFEST.json','PROGRESS.json')]
    need(len(index['files']) == 22 and len(manifest['files']) == 19 and len(manifest['baseDependencyRestoreFiles']) == 220, 'Actual base23/19/220 closure')
    need({p.name for p in BASE.iterdir()} == {r['path'] for r in index['files']} | {'WORKSPACE_HASH_INDEX.json'}, 'Complete immutable Model318 inventory')
    for row in index['files']:
        exact(BASE/relative(row['path']), row)
    targets = [{'baseSavedDirectory': BASE_REL, **r} for r in manifest['files']] + manifest['baseDependencyRestoreFiles']
    need(len(targets) == len({r['restorePath'] for r in targets}) == 239, 'Unique239 actual base targets')
    for row in targets:
        exact(Path(row['restorePath']), row)
    need(manifest['solverSourceRoot'] == SOLVER_ROOT and progress['primaryModelCandidate']['candidateSha256'] == BASE_CANDIDATE_SHA, 'Exact model318 and solver root')
    current = progress['latestSourceVerifiedCheckpoint']
    need(progress['latestEditableSourceCoreScope'] == current['coreScope'] == 313 and current['nativeTotalFindings'] == 951 and current['unqualifiedCurrentPourCount'] == 19, 'Source313 base boundaries retained without later evidence')
    archive = BOARD/('cloud/artifacts/'+BASE_STEM+'.tar.gz')
    metadata = archive.with_name(BASE_STEM+'.manifest.json')
    for path, digest in ((archive,BASE_ARCHIVE_SHA),(metadata,BASE_MANIFEST_SHA)):
        need(regular(path) and sha(path) == digest, 'Actual tested Model318 archive/manifest')
    am = read(metadata)
    need(am['scope'] == 'PORTABLE_MODEL318_CA17_INCREMENT_NOT_FRESH_SOURCE' and am['archive']['sha256'] == BASE_ARCHIVE_SHA and am['archive']['bytes'] == archive.stat().st_size and am['primaryCandidate']['sha256'] == BASE_CANDIDATE_SHA, 'Exact portable base model')
    need(len(am['files']) == 23 and am['workspaceRestoreTargetCount'] == 19 and am['baseRestoreTargetCount'] == 220 and am['snapshotPins'] == {BASE_REL+'/'+n:h for n,h in BASE_PINS.items()}, 'Exact base archive member and metadata bindings')
    for dependency in progress['baseArchiveDependenciesInRestoreOrder']:
        for key, digest in (('path',dependency['sha256']),('manifest',dependency['manifestSha256'])):
            path = BOARD/relative(dependency[key])
            need(regular(path) and sha(path) == digest, 'All prior ordered archive dependencies unchanged')
    dependency = {**am['archive'], 'manifest': metadata.relative_to(BOARD).as_posix(), 'manifestSha256': BASE_MANIFEST_SHA, 'mustBeRestoredFirst': True, 'payloadCopiedByThisCollector': False}
    return manifest, progress, targets, dependency

def model_controls():
    need(regular(PROFILE) and sha(PROFILE) == PROFILE_SHA, 'Frozen bound Model328 profile')
    profile = read(PROFILE)
    rows = profile['artifacts']
    need(len(rows) == len({r['restorePath'] for r in rows}) == len({r['savedPath'] for r in rows}) == 60 and sum(r['bytes'] for r in rows) == 187486374, 'Exact60 payloads/178.8MiB')
    need(profile['cutThroughScope'] == 328 and profile['noLater331332333EvidenceIncluded'] is True, 'This model snapshot cuts at328 only')
    for row in rows:
        need(Path(row['restorePath']).is_absolute() and Path(row['restorePath']).is_relative_to('/tmp') and relative(row['savedPath']).parent == Path('.'), 'Tmp-only targets and flat unique aliases')
        exact(Path(row['restorePath']), row)
    by_name = {r['savedPath']:r for r in rows}
    load = lambda name: read(Path(by_name[name]['restorePath']))
    c, report, receipt = [load('MODEL328_'+n) for n in ('byte0-result.candidate.json','byte0-result.json','COLLECTED.json')]
    need(by_name['MODEL328_byte0-result.candidate.json']['sha256'] == MODEL_SHA and by_name['MODEL328_byte0-result.json']['sha256'] == '2ad2dc434ab273cd48131b897b566820156efacf530a3f196cd661b05ec3a96e', 'Actual closed328 output pins')
    parent = read(Path('/tmp/g350-source37-three-width-matched49-finite1g-root-20261016-run318/byte0-result.candidate.json'))
    owner = lambda trace: trace.get('connection_name',trace.get('source_trace_id'))
    old, new = [{owner(t):t for t in d['carrierTraces']} for d in (parent,c)]
    changed = {'source_trace_'+str(i) for i in (20,23,25,36)}
    need(set(old) == set(new) == {'source_trace_'+str(i) for i in range(49)} and all(old[n] == new[n] for n in old if n not in changed), 'Only four declared bodies; other45 including37 literal')
    for key in ('full49FanoutInput','heldCarrierTraces','cap12PlacementInverse','cap8PlacementInverse','cap8PdnInsertions','sourceReferenceTargetInverses','requiredSourceHardwarePlacementDeltas'):
        need(c[key] == parent[key], 'Entire foundation/critical/hardware/reference invariant '+key)
    inv = c['bodyInverses'][-4:]
    need(c['bodyInverses'][:-4] == parent['bodyInverses'] and {r['owner'] for r in inv} == changed and all(r['before'] == old[r['owner']] and r['after'] == new[r['owner']] for r in inv), 'Complete four-body exact inverse and historical prefix')
    events = lambda t: [r for r in t['route'] if r['route_type'] == 'via']
    need(all(events(new[n]) == events(old[n]) for n in old if n != 'source_trace_25'), 'All old carrier physical via events literal')
    declared = report['declaredNewPhysicalCarrierVias']
    need(len(declared) == 2 and events(old['source_trace_25']) == [] and events(new['source_trace_25']) == [r['after'] for r in declared], 'Only two declared new25 portal events')
    for row in declared:
        event = row['after']
        need(row['before'] is None and row['sourceManuallyPlacedViaId'] is None and row['pcbViaId'] is None and row['pcbPortIds'] is None and row['futureFreshSourceBindingRequired'] is True and event['layers'] == ['top','inner1','inner2','bottom'] and event['via_diameter'] == .4572 and event['via_hole_diameter'] == .254, 'Real fullspan dimensions; future raw identities unassigned')
    need(sum(len(events(t)) for t in c['carrierTraces']) == 19 and len(c['joinedNumericPadTraces']) == 49, 'Actual19 inline events and49 numeric joined routes')
    for data in (c, report):
        need(data['all49Connected'] is True and data['allSavedCarriersCurrentSceneQualified'] is True and len(data['finalScenePhysicalReports']) == 49 and all(r['passed'] is True and r['joinedNativeGeometryPassed'] is True and r['nativeForeignViaLandGap']['passed'] is True for r in data['finalScenePhysicalReports']), 'Actual full49 physical/native geometry/.15 foreign land gates')
        need(len(data['criticalValidationViews']) == 2 and all(v['passed'] is True and v['c31']['solved'] is True and set(v['reports']) == {'bus','pair','shared','coupling','exterior'} and all(len(rs) == 3 and all(r['matched'] is True for r in rs) for rs in v['reports'].values()) for v in data['criticalValidationViews']), 'Both actual DQS1 views/all five original APIs/C31')
        need(data['byte0PlanarBusSkewPassed'] is True and data['byte1PlanarBusSkewPassed'] is True and data['caCohortPlanarObservation']['minimumPassingCount'] == 18 and len(data['caCohortPlanarObservation']['minimumFailingOwners']) == 8 and data['caCohortPlanarObservation']['fullBusTimingPassed'] is False, 'Both full byte cohorts and actual CA18/eight short/fullskew fail')
        need(all(data[k] is False for k in ('all49Accepted','matched','timingPassed','nativeExecuted','cadExecuted','freshSource','freshSourceCoreDerived','fabricationReady')), 'Physical model only; no later replay or qualification inheritance')
    need(len(report['beforeCurrent49PhysicalReports']) == 49 and all(r['passed'] is True for r in report['beforeCurrent49PhysicalReports']) and {r['owner'] for r in report['changedJoinedSignalPhysicalReports']} == changed and all(r['passed'] is True for r in report['changedJoinedSignalPhysicalReports']), 'Actual before49 and four complete numeric joins')
    for key in ('powerReferencePhysicalReports','plannedPdnViaPhysicalReports','movedCap8PadFixedCopperPreflight'):
        need(len(report[key]) == 2 and all(r['passed'] is True for r in report[key]), 'All retained reference/PDN/pad gates '+key)
    need(report['workingBarrelPhysicalJoinAudit']['passed'] is True and report['workingBarrelPhysicalJoinAudit']['dormantWorkingBarrels'] == [], 'No working barrel silently omitted')
    strong = report['changedPreferredSelfActualSdkReports']
    need({r['owner'] for r in strong} == changed and all(r['allNewEdgePairsRecomputed'] is True and r['zeroIntroducedPreferred3WSelfFailures'] is True for r in strong), 'All four fresh SDK self classifications/zero new failures')
    need({r['owner']:r['wholeOwnerPreferred3WSelfPassed'] for r in strong} == {'source_trace_20':True,'source_trace_23':False,'source_trace_25':True,'source_trace_36':False}, 'Retain raw false legacy self booleans')
    run_rows = [q for r in strong for q in r['runs']]
    need(sum(r['actualNonlocalFailureCount'] for r in run_rows) == 12105 and all(r['introducedNonlocalFailureCount'] == 0 and r['allFailureEndpointObjectsLiteral318'] is True and r['allFailureOrderedPairsWereAlsoActual318PreferredFailures'] is True and r['allLocalAuthorityRecomputedFromActualGeometry'] is True for r in run_rows), 'All12105 inherited failures retained; no introduced failure waived')
    need(len(report['changedPreferredSelfCrossRunReports']) == 4 and all(r['passed'] is True for r in report['changedPreferredSelfCrossRunReports']), 'Fresh all distinct same-layer cross-run checks')
    guidance = report['newWireGuidanceAudits']
    need(len(guidance) == 4 and all(r['passedAllSelectedWireGuidance'] is True for r in guidance.values()), 'All new changed wire and all25 guidance gates')
    inherited = report['inheritedGuidanceFailureEvidence']
    need(inherited['allRowsRetainedInPinnedProof'] is True and inherited['whole20IntroducedForeignShortfalls'] == 0 and inherited['whole20ForeignShortfalls'] == 346 and inherited['whole23ForeignShortfalls'] == 169 and inherited['source23PreferredSelfShortfalls'] == 617 and inherited['source36PreferredSelfShortfalls'] == 11488 and inherited['notWaivedOrFiltered'] is True and inherited['fullBoardTiQualified'] is False, 'Inherited foreign/self findings retained; no wholeTI claim')
    # Full51MB main proof and58MB predecessor are already exact-hashed above.
    # Decode only the compact companion, which the actual worker authenticated.
    compact = load('g350-actual318-four-body20-23-25-36-preferred-self-compact-companion-v3-report.json')
    need(compact == report['strongSelfCompanionEvidence'] and compact['mainProofSha256'] == '3629499aaf79d74c300a77692accaba815eee80e3c7ba0ffc8c5358afa27cfeb' and compact['zeroIntroducedPreferredSelfFailuresAllFourOwners'] is True, 'Exact corrected compact evidence; no huge companion JSON decode')
    execution = receipt['execution']
    need(receipt['scope'] == 328 and execution['exitCode'] == 0 and execution['cleanupOwnedGroupEmpty'] is True and execution['diagnosticStopped'] is False and receipt['sourcePinsUnchanged'] is True and receipt['protectedFilesUnchanged'] is True and execution == load('MODEL328_owned_execution.json'), 'Actual closed328 immutable/owned-empty closure')
    need(execution['command'][1] == '/tmp/g350-actual318-four-body20-23-25-36-two-new25-fullspan-strong-self-indexed-physical49-v5-sourceonly.ts' and execution['policy']['wallSeconds'] == 180 and execution['policy']['rssBytes'] == 1024**3 and execution['policy']['sharedBytes'] == 30*1024**3, 'Exact reviewed v5 worker/1GiB bounded SDK run')
    post = load('g350-actual328-root-postcollection-verification-20261017.json')
    need(post['actualRootScope'] == 328 and post['passed'] is True and post['all49PhysicalBeforeAndAfter'] is True and post['fourCompleteChangedNumericJoins'] is True and post['bothCriticalFiveApiC31ViewsPassed'] is True and post['caMinimumPassing'] == 18 and len(post['remainingShortCaOwners']) == 8 and post['twoNewSignalViasRequireFreshSourceBinding'] is True and post['priorSource313PourQualificationNotInherited'] is True, 'Root postcollection semantic proof')
    for row in post['outputs'] + post['allTenCheckedInputsUnchanged']:
        path = Path(row['path'])
        need(regular(path) and path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], 'All Root explicit postcollection inputs unchanged')
    return profile, rows, c, report

def build(args):
    need(not SAVED.exists(), 'Fresh Model328 staging folder')
    base, progress, base_targets, dependency = source318(args)
    profile, payloads, candidate, report = model_controls()
    need(shutil.disk_usage('/tmp').free > profile['plannedPayloadBytes']+1024**3 and int(Path('/sys/fs/cgroup/memory.current').read_text())+256*1024**2+1024**3 < 30*1024**3, 'Tmp payload/shared30GiB plus1GiB reserve')
    archive = BOARD/('cloud/artifacts/'+STEM+'.tar.gz'); metadata = archive.with_name(STEM+'.manifest.json')
    need(not archive.exists() and not metadata.exists(), 'Fresh immutable Model328 archive pair')
    extras = [(PROFILE,'MODEL328_PROFILE.json'),(Path(__file__).resolve(),'MODEL328_PORTABLE_INCREMENT_SOURCE.py')]
    rows = payloads + [{'restorePath':str(p),'savedPath':n,**md(p)} for p,n in extras]
    need(len(rows) == len({r['savedPath'] for r in rows}) == len({r['restorePath'] for r in rows}) == 62 and not ({r['restorePath'] for r in rows} & {r['restorePath'] for r in base_targets}), 'Unique62 local plus239 base targets')
    SAVED.mkdir(mode=0o700)
    for row in rows:
        source, destination = Path(row['restorePath']), SAVED/row['savedPath']
        exact(source,row)
        with source.open('rb') as src, destination.open('xb') as dst:
            shutil.copyfileobj(src,dst,1048576); os.fchmod(dst.fileno(),row['mode'])
        exact(destination,row)
    dependencies = progress['baseArchiveDependenciesInRestoreOrder']+[dependency]
    model = {'scope':'MODEL328_FOUR_BODY_CA18_STRONG_SELF_ZERO_NEW_FAILURES_PHYSICAL_ONLY','candidateSha256':MODEL_SHA,'savedCandidate':'MODEL328_byte0-result.candidate.json','routedOwners':49,'pendingOwnerIds':[],'all49ModelPhysicalPassed':True,'bothCriticalViewsAndFiveApisPassed':True,'byte0PlanarSkewPassed':True,'byte1PlanarSkewPassed':True,'caMinimumPassingCount':18,'caUnderMinimumCount':8,'caPlanarSkewPassed':False,'new25PhysicalFullspanVias':2,'futureFreshSignalIds':None,'zeroIntroducedPreferredSelfFailures':True,'retainedPreferredSelfFailures':12105,'sourceCoreReplayExecuted':False,'nativeBoardChecksExecuted':False,'currentPourQualificationPending':True,'currentCadQualificationPending':True,**FALSE}
    common = {'scope':model['scope'],'frozenCheckpoint':True,'updatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'latestClosedScopeIncluded':328,'laterReplayResultsIncluded':False,'primaryCandidate':model,'primaryModelCandidate':model,'latestSourceVerifiedCheckpoint':progress['latestSourceVerifiedCheckpoint'],'latestEditableSourceSavedDirectory':progress['latestEditableSourceSavedDirectory'],'latestEditableSourceCoreScope':313,'latestSourceVerifiedCheckpointIsOnlyWithinThisRestoreChain':True,'model328QualificationInheritedFromSource313':False,'source313PourSiblingDependencyAdded':False,'baseArchiveDependency':dependency,'baseArchiveDependenciesInRestoreOrder':dependencies,'laterWorkRequiresNewSavedDirectory':True,**FALSE}
    write(SAVED/'WORKSPACE_RESTORE_MANIFEST.json',{**common,'solverSourceRoot':SOLVER_ROOT,'files':rows,'baseDependencyRestoreFiles':base_targets,'immutableWorkspaceAssets':[],'immutableAssetsRestoredByBaseArchives':base['immutableAssetsRestoredByBaseArchives']})
    with (SAVED/'README.md').open('x') as stream:
        os.fchmod(stream.fileno(),0o600); stream.write('MODEL328 physical-only:49 model paths/both11-signal byte cohorts PASS; CA18/26 at minimum,eight short/fullCA skew17.6628187566mm FAILS.\nOnly20/23/25/36 bodies change; two new25 fullspan portals have no fresh raw IDs. All45 other bodies/foundation/critical6/reference/PDN/hardware remain literal318.\nActual328 passes before49/after49,four full numeric joins,both critical views/all5 original APIs/C31 and fresh indexed self checks with zero NEW preferred failures.\nAll12105 retained preferred-self failures and inherited foreign-guidance findings remain unfiltered. WholeTI/electrical/fabrication are false.\nThis snapshot cuts at328. Later331/332/333 or other replay results are excluded. Editable Source313 is the checkpoint carried in this restore chain, with951 native findings and19 unqualified pours; its separate pour sibling is not a dependency or inherited qualification.\nNo fresh Source/Core/native-board/pour/PDN-plane/CAD qualification is claimed for328. Pending Source0 topology notes and failed/unexecuted predecessors remain UNACCEPTED.\nRestore209→228→248→257→272-v2→289→Model299→Source313→Model318, then this increment. The unchanged generic archive restorer and legacy tmp helper remain compatible.\nNo SDK/application code is executed by this helper.\n')
    write(SAVED/'PROGRESS.json',{**common,'modelEvidence':rows,'actualCaObservation':report['caCohortPlanarObservation'],'inheritedGuidanceFindingsRetained':report['inheritedGuidanceFailureEvidence'],'changedSelfSdkSummary':[{'owner':r['owner'],'wholePreferredSelfPassed':r['wholeOwnerPreferred3WSelfPassed'],'zeroIntroducedPreferredSelfFailures':r['zeroIntroducedPreferred3WSelfFailures']} for r in report['changedPreferredSelfActualSdkReports']],'sdkExecutedByCollector':False,'archiveCreatedByOwnStdlib':True})
    index = [{'path':p.name,**md(p)} for p in sorted(SAVED.iterdir())]
    write(SAVED/'WORKSPACE_HASH_INDEX.json',{'scope':model['scope'],'files':index,'selfExcluded':True,'frozenCheckpoint':True})
    members = [{'path':SAVED_REL+'/'+p.name,'_source':p,**md(p)} for p in sorted(SAVED.iterdir())]
    need(len(members) == 66 and len(index) == 65, 'Exact66 members/index65')
    temporary = durable = mt = None
    try:
        fd,name = tempfile.mkstemp(prefix='g350-model328-',suffix='.tar.gz',dir='/tmp'); temporary = Path(name)
        with os.fdopen(fd,'wb') as output:
            os.fchmod(output.fileno(),0o600)
            with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0,compresslevel=6) as gz:
                with tarfile.open(mode='w|',fileobj=gz,format=tarfile.PAX_FORMAT) as tf:
                    for row in members:
                        exact(row['_source'],row); info = tarfile.TarInfo(row['path']); info.size=row['bytes']; info.mode=row['mode']; info.mtime=0; info.uid=info.gid=0; info.uname=info.gname=''
                        with row['_source'].open('rb') as source: tf.addfile(info,source)
                        exact(row['_source'],row)
            output.flush(); os.fsync(output.fileno())
        source318(args); model_controls()
        for row in rows: exact(Path(row['restorePath']),row)
        actual = {'path':archive.relative_to(BOARD).as_posix(),**md(temporary)}
        document = {'schemaVersion':1,'scope':SCOPE,'regularFilesOnly':True,'historicalDataOnly':True,'archive':actual,'files':[{k:v for k,v in r.items() if k!='_source'} for r in members],'inputDirectories':[SAVED_REL],'extraWorkspaceAssetMembers':[],'baseArchiveDependenciesInRestoreOrder':dependencies,'baseArchivesIncluded':False,'workspaceRestoreTargetCount':62,'baseRestoreTargetCount':239,'snapshotPins':{SAVED_REL+'/'+n:sha(SAVED/n) for n in META},'primaryCandidate':{'path':SAVED_REL+'/MODEL328_byte0-result.candidate.json','sha256':MODEL_SHA},'latestSourceVerifiedCheckpoint':progress['latestSourceVerifiedCheckpoint'],'latestEditableSourceCoreScope':313,'laterReplayResultsIncluded':False,'solverSourceRoot':SOLVER_ROOT,**FALSE}
        fd,name = tempfile.mkstemp(prefix='.'+metadata.name+'.',suffix='.partial',dir=metadata.parent); mt=Path(name)
        with os.fdopen(fd,'w') as stream: os.fchmod(stream.fileno(),0o600); json.dump(document,stream,indent=2,allow_nan=False); stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
        need(shutil.disk_usage(archive.parent).free > temporary.stat().st_size+256*1024**2, 'Measured compressed archive plus256MiB durable reserve')
        fd,name = tempfile.mkstemp(prefix='.'+archive.name+'.',suffix='.partial',dir=archive.parent); durable=Path(name)
        with temporary.open('rb') as source,os.fdopen(fd,'wb') as output: shutil.copyfileobj(source,output,1048576); os.fchmod(output.fileno(),0o600); output.flush(); os.fsync(output.fileno())
        exact(durable,actual); publish(durable,archive); durable=None; publish(mt,metadata); mt=None
        print(json.dumps({'archive':str(archive),'archiveSha256':sha(archive),'manifest':str(metadata),'manifestSha256':sha(metadata),'members':66,'tmpTargets':62,'baseTargets':239,'latestEditableSourceWithinThisChain':313,'primaryModelScope':328,'sdkExecuted':False,'fabricationReady':False}))
    finally:
        for path in (temporary,durable,mt):
            if path is not None and path.exists(): path.unlink()

def verify(args):
    _,_,base_targets,_ = source318(args); model_controls()
    archive=BOARD/('cloud/artifacts/'+STEM+'.tar.gz'); metadata=archive.with_name(STEM+'.manifest.json')
    for path,digest in ((archive,args.archive_sha),(metadata,args.manifest_sha)):
        need(digest and re.fullmatch('[0-9a-f]{64}',digest) and regular(path) and sha(path)==digest, 'Explicit actual new archive/manifest pins')
    am=read(metadata); need(am['scope']==SCOPE and am['archive']['sha256']==args.archive_sha and len(am['files'])==66,'Exact Model32866-member increment')
    for path,digest in ((RESTORER,RESTORER_SHA),(HELPER,HELPER_SHA)):
        need(regular(path) and sha(path)==digest,'Unchanged existing restoration source')
    owned=Path(tempfile.mkdtemp(prefix='g350-model328-smoke-',dir='/tmp')); dest=owned/'extracted'; commands=[]
    def run(argv):
        result=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=120,check=False)
        commands.append({'argv':argv,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}); need(result.returncode==0,'Restoration-only subprocess'); return result.stdout.strip()
    try:
        command=[sys.executable,str(RESTORER),str(metadata),'--destination',str(dest)]
        need(run(command+['--verify-archive'])=='Verified 66 evidence members; restored 0','Exact verify count')
        need(run(command)=='Verified 66 evidence members; restored 66','Exact isolated66 extraction')
        need({p.relative_to(dest).as_posix() for p in dest.rglob('*') if p.is_file()}=={r['path'] for r in am['files']},'Only exact regular members')
        for row in am['files']: exact(dest/relative(row['path']),row)
        for name,digest in am['snapshotPins'].items(): need(sha(dest/relative(name))==digest,'All extracted metadata pins')
        mf=read(dest/SAVED_REL/'WORKSPACE_RESTORE_MANIFEST.json')
        need(len(mf['files'])==62 and mf['baseDependencyRestoreFiles']==base_targets and mf['latestEditableSourceCoreScope']==313 and mf['latestClosedScopeIncluded']==328,'Literal239 inherited plus62 local restore rows/cut328')
        targets=mf['files']+base_targets; need(len(targets)==len({r['restorePath'] for r in targets})==301,'All301 existing targets before no-op')
        for row in targets: exact(Path(row['restorePath']),row)
        link=Path(mf['solverSourceRoot']).parent/'node_modules'; need(link.is_symlink() and link.resolve()==(BOARD.parent/'bus-lanes-solver/node_modules').resolve(),'Exact preexisting dependency link')
        before=link.lstat(); link_id=(before.st_dev,before.st_ino,before.st_mode,before.st_mtime_ns,before.st_ctime_ns,os.readlink(link))
        result=json.loads(run([sys.executable,str(HELPER),'--saved-directory',str(dest/SAVED_REL),'--restore']))
        need(result['savedFilesVerified']==62 and result['restoredFiles']==0 and result['mode']=='restore','Actual existing restore code path writes zero files')
        for row in targets: exact(Path(row['restorePath']),row)
        after=link.lstat(); need((after.st_dev,after.st_ino,after.st_mode,after.st_mtime_ns,after.st_ctime_ns,os.readlink(link))==link_id,'Dependency link unchanged')
        source318(args); model_controls(); need(sha(archive)==args.archive_sha and sha(metadata)==args.manifest_sha,'Archive inputs unchanged')
        shutil.rmtree(dest)
        write(owned/'REPORT.json',{'scope':'MODEL328_INCREMENT_ISOLATED_EXTRACTION_AND301_TARGET_NOOP_RESTORE_NOT_SOURCE_QUALIFICATION','passed':True,'commands':commands,'archiveSha256':args.archive_sha,'manifestSha256':args.manifest_sha,'isolatedPayloadRemoved':True,'all301ActualTargetsUnchanged':True,'existingHelperRestoreCodePathExecuted':True,'restoredWorkspaceFiles':0,'latestEditableSourceWithinThisChain':313,'primaryModelScope':328,'laterReplayResultsIncluded':False,'sdkExecuted':False,**FALSE})
        print(json.dumps({'report':str(owned/'REPORT.json'),'sha256':sha(owned/'REPORT.json'),'passed':True,'sdkExecuted':False}))
    except BaseException as error:
        write(owned/'FAILURE.json',{'passed':False,'error':str(error),'commands':commands,'isolatedPayloadPreserved':dest.exists(),**FALSE}); raise

def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('mode',choices=('build','verify')); parser.add_argument('--model318-archive-sha',required=True); parser.add_argument('--model318-manifest-sha',required=True); parser.add_argument('--archive-sha'); parser.add_argument('--manifest-sha'); args=parser.parse_args()
    (build if args.mode=='build' else verify)(args)

if __name__=='__main__':
    main()
