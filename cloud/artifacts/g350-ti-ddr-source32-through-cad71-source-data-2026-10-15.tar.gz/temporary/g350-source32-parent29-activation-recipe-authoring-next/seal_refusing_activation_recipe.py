"""Own stdlib Source/data preparation; never evaluate supplied workers or SDK."""
import pathlib,json,copy,hashlib,stat,difflib,datetime
A=pathlib.Path(__file__).parent;BASE=pathlib.Path('/tmp/g350-source32-intermediate20-21-and-ca45-direct-over29-source-stages-sourceonly-next');D=pathlib.Path('/tmp/g350-source32-strict-parent29-qualification-activation-recipe-sourceonly-next');assert not D.exists();D.mkdir(mode=0o700)
def pin(path):
 p=pathlib.Path(path);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),mode=stat.S_IMODE(s.st_mode))
def read(path,sha=None):
 if sha:assert pin(path)['sha256']==sha
 return json.loads(pathlib.Path(path).read_text())
def save(name,value):
 p=D/name;p.write_text(value if isinstance(value,str)else json.dumps(value,indent=2,allow_nan=False)+'\n');p.chmod(0o600);return pin(p)
m=read(BASE/'SOURCE-manifest.json','b4ceee77b7b3812fd2810bd1a607c316346c4fa16f3cb4dad36cf07a9c4139f2');j=read(BASE/'source32-proposal.json',m['source32ProposalPin']['sha256'])
ROOT=pathlib.Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
paths={'batch53':ROOT/'source29-three-stage-36688-PASS-COLLECTED-root.json','native54':ROOT/'source29-native-90477-PASS-COLLECTED-root.json','api55':ROOT/'source29-api-20574-PASS-COLLECTED-root.json','cli56':ROOT/'source29-cli-59864-PASS-COLLECTED-root.json'}
shas={'batch53':'8495deacf6f81fc567f0bdb2616faba51b79caa4b529bb39451ac1fcdc5c143c','native54':'e415d9f59f13b7820f212e2fdce87dfab61caebe6de8e9db91055e58cb8fa44f','api55':'7a73b2608978f714c05be14432e8a5ca00ba2f2d1493ff5979a6304f14b4cd9d','cli56':'86585a66f64af30b17f9150777491caf169e371822318ec1b3a00eac37bc3215'}
r={name:read(path,shas[name])for name,path in paths.items()};posts={name:pin(row['postauditPath'])for name,row in r.items()}
for name,row in r.items():
 assert posts[name]['sha256']==row['postauditSha256'];post=read(posts[name]['path']);assert post['toolSessionCollected']is False
 assert row['toolSessionCollected']is True and row['toolWrapperExitCode']==row['toolExitCode']==0 and row['passed']is True
 assert all(row[k]is True for k in ['sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','independentlyObservedGuardAbsent']);assert row['independentProcReadErrors']==[]
 assert row.get('independentlyObservedAllOwnedGroupsEmpty',row.get('independentlyObservedOwnedGroupEmpty'))is True
 assert all(row[k]is False for k in ['Source29Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'])
 assert all(row.get(k)==v for k,v in post.items()if k!='toolSessionCollected')
 assert row['dependenciesBefore']['treeSha256']==row['dependenciesAfter']['treeSha256']=='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'
 assert row['solverDependenciesBefore']['treeSha256']==row['solverDependenciesAfter']['treeSha256']=='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
def natural(e):
 assert e['exitCode']==0 and e['diagnosticStopped']is False and e['stopReasons']==[] and e['cleanupOwnedGroupEmpty']is True and len(e['oomDelta'])==3 and all(v==0 for v in e['oomDelta'].values())and e['signalErrorCount']==0
 assert e['pid']==e['pgid']==e['freshLeaderIdentity']['pid']==e['freshLeaderIdentity']['pgid']==e['freshLeaderIdentity']['sid'];assert e['command']==e['freshLeaderIdentity']['argv']
 assert datetime.datetime.fromisoformat(e['endedAt'])>=datetime.datetime.fromisoformat(e['startedAt'])
for name,names in [('batch53',['capture','types','core']),('api55',['projection','api'])]:
 receipt=r[name];assert receipt['orderedPhaseNames']==receipt['expectedPhaseNames']==names and receipt['notAttemptedPhaseNames']==[]
 for i,row in enumerate(receipt['phases']):
  assert row['phase']==names[i] and all(row[k]is True for k in ['passed','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0','sourceAndDependenciesHeld']);natural(row['execution']);assert row['guardIdentityBefore']==row['guardIdentityAfter']==receipt['sameGuardIdentity'];assert read(row['postauditPath'],row['postauditSha256'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
  if i:assert receipt['phases'][i-1]['execution']['endedAt']<=row['execution']['startedAt']and receipt['phases'][i-1]['execution']['pgid']!=row['execution']['pgid']
for name in ['native54','cli56']:natural(r[name]['execution'])
b=r['batch53']['phases'];a=r['api55']['phases'];raw=b[2]['result']['rawCorePin'];controls=b[2]['result']['coreControlsPin'];capture=b[0]['result']['sourceCapturePin'];native=pin(r['native54']['reportPath']);api=a[1]['result']['actualOriginalApiReportPin'];cli=pin(r['cli56']['reportPath']);export=pin(r['cli56']['exportPath']);model=a[0]['result']['actualFresh49Model'];projection=a[0]['result']['actualFresh49ProjectionProof']
assert b[1]['result']['actualPriorCapturePin']==capture;assert raw['sha256']=='bf98e35f464bee13d60fa413f3055af178f2d50735bbeef9a891672ba8fa4e37'
for p in[raw,controls,capture,native,api,cli,export,model,projection]:assert pin(p['path'])==p
native_report=read(native['path']);api_report=read(api['path']);cli_report=read(cli['path']);proj=read(projection['path']);core=read(controls['path'])
assert r['native54']['actualCoreSha256']==r['api55']['actualCoreSha256']==r['cli56']['actualCoreSha256']==raw['sha256'];assert native_report['physicalErrors']==0 and native_report['checkCount']==18 and native_report['physicalCpuRamConnectedCarrierCount']==29 and native_report['actualNativePairFindings']==[]
assert api_report['allOriginalApiLoaded26ChecksPassed']is True and api_report['actualCompleteOriginalSignalCount']==29 and api_report['expectedMissingOriginalSignalCount']==20 and api_report['checkInventory']['primaryPlusSecondaryBooleanPredicates']==131
assert api_report['original49Input']=={k:model[k]for k in('path','sha256')};assert proj['constructorInputSha256']==model['sha256']and proj['actualCoreSha256']==raw['sha256']and proj['actualNativeReportSha256']==native['sha256']
assert cli_report['exportPassed']is True and cli_report['cliExitCode']==0 and cli_report['outputSha256']==export['sha256']and cli_report['actualPhysicalTraceCount']==292 and cli_report['actualSourceSegmentCount']==1053
stagepins=dict(capture=capture,types=pin(b[1]['postauditPath']),core=controls,native=native,originalApi=api,cli=cli,cad=None)
evidence=dict(scope='AUTHENTIC_PARENT29_COLLECTED53_54_55_56_AND_FUTURE57_PARTIAL_GEOMETRY_NOT_AUTHORITY',sourceManifest=j['promotedParent29Source'],sourceProposal=j['parent29Proposal'],nativeApiRuntime=pin('/tmp/g350-source29-promoted-pins-stable-native-fresh49-api-runtime-sourceonly-next/SOURCE-manifest.json'),cliCadRuntime=pin('/tmp/g350-source29-cli-cad-authentic55-runtime-sourceonly-next/SOURCE-manifest.json') if pathlib.Path('/tmp/g350-source29-cli-cad-authentic55-runtime-sourceonly-next/SOURCE-manifest.json').exists() else None,collectionPins={**{name:pin(path)for name,path in paths.items()},'cad57':None},postauditPins={**posts,'cad57':None},stagePins=stagepins,rawCore=raw,coreControls=controls,fresh49Model=model,fresh49ProjectionProof=projection,cliExport=export,historicalReceiptsConferNoRuntimeAuthority=True,onlyPartialParent29GeometryQualificationPermitted=True,referenceQualified=False,electricalTimingPassed=False,all49Accepted=False,fabricationReady=False)
# Locate the exact already-reported CLI/CAD runtime through its source pin, never guess a future artifact.
if evidence['cliCadRuntime']is None or evidence['cliCadRuntime']['sha256']!=r['cli56']['sourceManifestSha256']:
 candidates=[pathlib.Path('/tmp/g350-source29-cli-cad-native-api55-actual-binding-sourceonly-next/SOURCE-manifest.json')]
 for path in candidates:
  if path.exists()and pin(path)['sha256']==r['cli56']['sourceManifestSha256']:evidence['cliCadRuntime']=pin(path);break
if evidence['cliCadRuntime']is None or evidence['cliCadRuntime']['sha256']!=r['cli56']['sourceManifestSha256']:
 # The actual CLI source manifest path is authenticated by its closed56 guard source metadata.
 guard=pathlib.Path('/tmp/g350-source29-cad57-authentic56-root-guard-sourceonly-next/SOURCE-manifest.json');gm=read(guard,'bcaee0d1991635f39e2b587655c146facef22564cd320fcde7f3b122011a6c53')
 def walk(v):
  if isinstance(v,dict):
   if v.get('sha256')==r['cli56']['sourceManifestSha256']and isinstance(v.get('path'),str):yield v
   for x in v.values():yield from walk(x)
  elif isinstance(v,list):
   for x in v:yield from walk(x)
 found=list(walk(gm));assert found;candidate=pin(found[0]['path']);assert candidate['sha256']==r['cli56']['sourceManifestSha256'];evidence['cliCadRuntime']=candidate
assert evidence['cliCadRuntime']['sha256']=='0b22bebe8a7fb6e3704af705494158caa00ad9e460161f1502e289d80b193760'
j['parent29QualificationBindings']=evidence;j['actualParent29Stages']=copy.deepcopy(stagepins);j['actualParent29Qualification']=None;j['actualParent29Capture']=None
j['source32Accepted']=False;j['source32ActualStages']=None;j['actualFreshCore32Ids']=None
pp=save('source32-proposal.json',j)
old=(BASE/'source32.circuit.tsx').read_text();start=old.index('function requireFutureQualifiedParent29(){');end=old.index('\nexport function buildOwnerIntermediate32Source()',start);gate=(A/'strict-parent29-qualifier.ts.fragment').read_text().rstrip();module=old[:start]+gate+old[end:]
module=module.replace('import type { Source32Proposal }','import type { Source32Proposal, Pin, Parent29QualificationBindings }',1)
module=module.replace('import data from "./source32-proposal.json"','import { readFileSync,lstatSync } from "node:fs"\nimport { createHash } from "node:crypto"\nimport data from "./source32-proposal.json"',1)
modpin=save('source32.circuit.tsx',module)
types=(BASE/'source32-types.ts').read_text();types+='\nexport type Parent29QualificationBindings = {\n sourceManifest:Pin;sourceProposal:Pin;nativeApiRuntime:Pin;cliCadRuntime:Pin\n collectionPins:Record<string,Pin|null>;postauditPins:Record<string,Pin|null>;stagePins:Record<string,Pin|null>\n rawCore:Pin;coreControls:Pin;fresh49Model:Pin;fresh49ProjectionProof:Pin;cliExport:Pin\n}\n'
types=types.replace('scope:string; promotedParent29Source:Pin;','scope:string; parent29QualificationBindings:Parent29QualificationBindings; promotedParent29Source:Pin;',1);t=save('source32-types.ts',types)
for name in ['capture-source32.ts','render-source32-core.ts','typecheck-source32.sh']:save(name,(BASE/name).read_text());assert(D/name).read_bytes()==(BASE/name).read_bytes()
future=save('SIX_FINAL_ACTIVATION_METADATA_BINDINGS_STILL_NULL.json',dict(scope='SOURCE_ONLY_FUTURE_FINAL_CAD57_BINDINGS_NO_ROOT_AUTHORITY',sourceProposalPin=pp,strictSourceModulePin=modpin,requiredActual57PinFields=['Root successful collected receipt','matching genuine POSTAUDIT','actual CAD report produced in that exact scope'],sixExactPropertyPaths={'actualParent29Qualification':None,'actualParent29Capture':None,'actualParent29Stages.cad':None,'parent29QualificationBindings.collectionPins.cad57':None,'parent29QualificationBindings.stagePins.cad':None,'parent29QualificationBindings.postauditPins.cad57':None},knownCaptureValueForLaterGenuineActivation=capture,strictFuture57Expected=dict(scope='ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH56_AUTHENTIC_PRIOR_CLOSURES',phase='cad',actualCoreSha256=raw['sha256'],actualCoreControlsSha256=controls['sha256'],cliExportSha256=export['sha256'],physicalCpuRamGraphs=29,physicalVias=227,physicalTracePaths=292,wireSegments=1053,footprints=507,missing=20),actual57Collection=None,actual57Postaudit=None,actual57CadReport=None,RootAuthorityCreated=False,source32Executed=False,fabricationReady=False))
changes=[]
for name in ['source32.circuit.tsx','source32-types.ts','capture-source32.ts','render-source32-core.ts','typecheck-source32.sh']:
 oldtext=(BASE/name).read_text();newtext=(D/name).read_text();steps=[]
 for op,a,b,c,d in difflib.SequenceMatcher(None,oldtext.splitlines(True),newtext.splitlines(True),autojunk=False).get_opcodes():
  if op!='equal':steps.append(dict(parentLineStart=a,parentLineEnd=b,newLineStart=c,newLineEnd=d,old=''.join(oldtext.splitlines(True)[a:b]),new=''.join(newtext.splitlines(True)[c:d])))
 changes.append(dict(parent=pin(BASE/name),successor=pin(D/name),lineOffsetEdits=steps))
 save(name+'.EXACT_PREPARATION_PARENT.delta.patch',''.join(difflib.unified_diff(oldtext.splitlines(True),newtext.splitlines(True),fromfile=str(BASE/name),tofile=str(D/name))))
mapPin=save('EXACT_ACTIVATION_GATE_ONLY_FORWARD_AND_INVERSE_SOURCE_MAPS.json',dict(scope='SOURCE_ONLY_STRICT_GATE_PREPARATION_WITH_NO_GEOMETRY_OR_CHECK_BODY_CHANGE',files=changes))
for f in changes:
 oldtext=pathlib.Path(f['parent']['path']).read_text().splitlines(True);newtext=pathlib.Path(f['successor']['path']).read_text().splitlines(True);value=oldtext[:]
 for e in reversed(f['lineOffsetEdits']):assert ''.join(value[e['parentLineStart']:e['parentLineEnd']])==e['old'];value[e['parentLineStart']:e['parentLineEnd']]=e['new'].splitlines(True)
 assert value==newtext
for k in j:
 if k not in ['parent29QualificationBindings','actualParent29Stages']:assert j[k]==read(BASE/'source32-proposal.json')[k]
controlsPin=save('SOURCE_ONLY_KNOWN53_THROUGH56_DATA_JOIN_AND_REFUSAL_PROOF.json',dict(scope='OWN_STDLIB_DATA_ONLY_PREPARATION_NOT_JS_EVALUATION',knownReceipts={name:pin(path)for name,path in paths.items()},knownPosts=posts,allKnownRootCollectionsNatural0AndHeld=True,postToolSessionCollectedFalseVersusRootTrueHandledExplicitly=True,individualPhasePostFullEquality=True,actual53ThreeChildrenAnd55TwoChildrenSerial=True,actualCoreSha256=raw['sha256'],actualCoreControlsSha256=controls['sha256'],actualNativeReport=native,actualOriginalApiReport=api,actualFreshModel=model,actualFreshProjection=projection,actualCliReport=cli,actualCliExport=export,actual29LegacyApiResultField='allOriginalApiLoaded26ChecksPassed',legacyResultFieldDoesNotRetag29ScopeCountsOrInputs=True,allStageFunctionBodyAndGeometryBytesHeld=True,future57NullAndEntryRefusal=True,RootAuthorityCreated=False,source32Executed=False,accepted=False,fabricationReady=False))
readme=save('README.md','This immutable Source32 activation recipe adds only a strict parent29 data qualifier and known authentic stages53 through56. CAD57 receipt/POST/report and the final qualification/capture gate remain NULL, so both Source32 entrypoints still refuse before parent Source evaluation. It creates no Root execution authority.\n\nThe qualifier checks separate genuine53 capture/types/Core and55 projection/API children, each actual POST and command/group identity, natural exits and empty-owned-group observations; all29 Core/Native graphs,131 original API predicates and bothDQS1 views; exact two-key fresh49 identity; and the CLI report/export. A future57 binding must match the same raw Core/controls/export and prove29 physical CAD graphs,292traces,1053segments,227vias,507footprints,4layers,98local approaches. Historical reports preserve reference/electrical/full49/fabrication false.\n\nOnly the six explicitly listed metadata paths may be filled after genuine successful57 collection; no geometry, routing controls, IDs or previous frozen source is edited. Capture/Core/typecheck workers are byte-identical to b4ce. No SDK, JS, compiler, supplied guard/helper, app or process inspection was performed while authoring.\n')
expanded=m['parent186HeldSourceBindings']+[pin(D/name)for name in ['source32.circuit.tsx','source32-proposal.json','source32-types.ts','capture-source32.ts','render-source32-core.ts']];assert len(expanded)==191
for row in expanded:assert pin(row['path'])==row
manifest={k:copy.deepcopy(v)for k,v in m.items()if k not in ['files','externalFiles']};manifest.update(scope='SOURCE_ONLY_SOURCE32_STRICT_PARENT29_ACTIVATION_RECIPE_WITH_AUTHENTIC53_THROUGH56_AND_NULL57',status='AUTHOR_DONE_REFUSING_FINAL_PARENT29_CAD57_BINDINGS',preservedPreparationManifest=pin(BASE/'SOURCE-manifest.json'),files=[pin(x)for x in sorted(D.iterdir())],externalFiles=[pin(BASE/'SOURCE-manifest.json'),pin(A/'strict-parent29-qualifier.ts.fragment'),pin(__file__),pin('/tmp/g350-source32-declaration-capture-core-independent-peer.json')]+list(evidence['collectionPins'].values())[:-1]+list(posts.values())+[p for p in stagepins.values()if p]+[raw,model,projection,export,evidence['nativeApiRuntime'],evidence['cliCadRuntime']],source32ProposalPin=pp,source32ModulePin=modpin,expandedHeldSourceAndControllerClosure=expanded,expandedHeldSourceAndControllerClosureCount=191,actualParent29Qualification=None,actualParent29Capture=None,actualParent29Stages=j['actualParent29Stages'],futureFinalCad57Receipt=None,futureFinalCad57Postaudit=None,futureFinalCad57Report=None,strictQualifierNotEvaluated=True,noRootAuthority=True)
mp=save('SOURCE-manifest.json',manifest);print(json.dumps(dict(manifest=mp,proposal=pp,module=modpin,types=t,futureSixBindings=future,dataProof=controlsPin,closure=191),indent=2))
