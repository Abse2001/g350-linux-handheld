"""Own stdlib source/data construction only; no supplied workers imported or run."""
import pathlib,json,hashlib,stat,copy,difflib
A=pathlib.Path(__file__).parent
D=pathlib.Path('/tmp/g350-source32-strict-parent29-future60-with-failed57-58-59-recipe-sourceonly-next');assert not D.exists();D.mkdir(mode=0o700)
P=pathlib.Path('/tmp/g350-source32-strict-parent29-activation-recipe-explicit-worker-paths-successor-next/SOURCE-manifest.json');BASE=pathlib.Path('/tmp/g350-source32-strict-parent29-qualification-activation-recipe-sourceonly-next')
def pin(p):
 p=pathlib.Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),mode=stat.S_IMODE(s.st_mode))
def load(p):return json.loads(pathlib.Path(p).read_text())
def save(n,v):
 p=D/n;p.write_text(v if isinstance(v,str)else json.dumps(v,indent=2,allow_nan=False)+'\n');p.chmod(0o600);return pin(p)
assert pin(P)['sha256']=='ed31fa996acd120c458d7b5c2e8ffe0edc64926dc2f893a0125f75f255dbd647';m=load(P);j=load(BASE/'source32-proposal.json');oldj=copy.deepcopy(j);e=j['parent29QualificationBindings'];assert e['collectionPins']['cad57']is e['postauditPins']['cad57']is e['stagePins']['cad']is None
ROOT=pathlib.Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
records={'cad57':('source29-cad-98055-PREFORK-REJECTED-POSTAUDIT-CRASH-COLLECTED-root.json','82597a14e833c17e8fefa329a1fee9871f6ca9850f31e1c76e8e60beb3dba6aa',98055,1),'cad58':('source29-cad-59882-PREFORK-REJECTED-COLLECTED-root.json','05e805f0e478f1ecb107cb0e3e796b0570ebb5e002692ddd1be57a7c46c3e7c1',59882,2),'cad59':('source29-cad-31552-CONTAINER-PRECONDITION-FAILED-COLLECTED-root.json','eeaa517934bf8e47867fc9466fa34cac6be49af954b4a77be6c85be37d8d2550',31552,2)}
failed={};failedpins={};failedposts={};extra=[]
for name,(filename,sha,tool,exitcode)in records.items():
 pp=pin(ROOT/filename);assert pp['sha256']==sha;r=load(pp['path']);failed[name]=r;failedpins[name]=pp
 assert r['toolSessionCollected']is r['authorizedByRoot']is True and r['toolSessionId']==tool and r['toolWrapperExitCode']==r['toolExitCode']==exitcode and r['passed']is False
 assert r['sourceManifestSha256']==e['cliCadRuntime']['sha256'] and r['independentlyObservedAllActuallySpawnedOwnedGroupsEmpty']is True and r['independentlyObservedGuardAbsent']is True
 assert all(r[k]is False for k in['Source29Accepted','accepted49','referenceQualified','electricalTimingPassed','fabricationReady'])
 if name=='cad57':
  assert r['originalPostauditProduced']is False and r['originalCadExitCode']is None and r['completeSdkPostauditHeld']is None and r['cadChildPidOrPgidAllocated']is False and r['cadApplicationInvoked']is False;failedposts[name]=None
  for field,expected in [('zonePinsExecutionPin','zonePinsExecution'),('cadAttemptExecutionPin','unspawnedCadAttemptExecution')]:assert pin(r[field]['path'])==r[field]and load(r[field]['path'])==r[expected];extra.append(r[field])
 else:
  p=pin(r['postauditPath']);assert p['sha256']==r['postauditSha256'];post=load(p['path']);assert post['toolSessionCollected']is False
  assert all(r[k]==v for k,v in post.items()if k!='toolSessionCollected');failedposts[name]=p
  assert r['sourceAndDependenciesHeld']is True and r['workspaceFreeBytesFloorHeld']is True and r['gitMetadataHeld']is True
  assert r['dependenciesBefore']['treeSha256']==r['dependenciesAfter']['treeSha256']=='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'
  assert r['solverDependenciesBefore']['treeSha256']==r['solverDependenciesAfter']['treeSha256']=='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
assert failed['cad58']['cadWrapperSpawned']is False and failed['cad58']['cadExecution']['exitCode']is None and'pid'not in failed['cad58']['cadExecution']and'pgid'not in failed['cad58']['cadExecution']
assert failed['cad59']['actualKiCadLoadBoardPerformed']is failed['cad59']['actualConnectivityDiagnosticPerformed']is False and failed['cad59']['workerFailedBeforeCadBoardLoad']is True and failed['cad59']['rootIndependentlyObservedOwnedContainerAbsent']is True and failed['cad59']['containerCleanupEvidenceActuallyEmpty']is True and failed['cad59']['cadExecution']['exitCode']==2
for key in ['collectionPins','postauditPins']:assert e[key].pop('cad57')is None;e[key]['cad60']=None
e['scope']='AUTHENTIC_PARENT29_COLLECTED53_54_55_56_SEPARATE_FAILED57_58_59_AND_FUTURE60_PARTIAL_GEOMETRY_NOT_AUTHORITY';e['failedCadAttemptPins']=failedpins;e['failedCadAttemptPostPins']=failedposts
pp=save('source32-proposal.json',j)
oldmod=(BASE/'source32.circuit.tsx').read_text();gate_start=oldmod.index('function requireFutureQualifiedParent29(){');gate_end=oldmod.index('\nexport function buildOwnerIntermediate32Source()',gate_start);gate=oldmod[gate_start:gate_end]
for a,b in [('cad57','cad60'),('CAD57','CAD60'),('Genuine57','Genuine60'),('WITH56_AUTHENTIC_PRIOR_CLOSURES','WITH59_AUTHENTIC_PRIOR_CLOSURES'),('successful Source29 stages53 through57','successful Source29 stages53 through56 and CAD60, with failed57/58/59 separately closed')]:gate=gate.replace(a,b)
marker=' const collections:Record<string,Json>={}'
assert gate.count(marker)==1
checks=''' const failed:Record<string,Json>={}
 same(Object.keys(evidence.failedCadAttemptPins).sort(),["cad57","cad58","cad59"],"Exact separate failed CAD attempt roster")
 same(Object.keys(evidence.failedCadAttemptPostPins).sort(),["cad57","cad58","cad59"],"Exact separate failed CAD POST roster")
 const failedTools:Record<string,number>={cad57:98055,cad58:59882,cad59:31552}
 for(const[name,pin]of Object.entries(evidence.failedCadAttemptPins)){
  const r=json(pin),postPin=evidence.failedCadAttemptPostPins[name]
  need(r.authorizedByRoot===true&&r.toolSessionCollected===true&&r.toolSessionId===failedTools[name]&&r.toolWrapperExitCode===(name==="cad57"?1:2)&&r.toolExitCode===r.toolWrapperExitCode&&r.passed===false,"Each failed CAD attempt is an authentic collected failure")
  need(r.sourceManifestSha256===evidence.cliCadRuntime.sha256&&r.independentlyObservedAllActuallySpawnedOwnedGroupsEmpty===true&&r.independentlyObservedGuardAbsent===true,"All actually spawned failed-attempt groups are closed")
  need(r.Source29Accepted===false&&r.accepted49===false&&r.referenceQualified===false&&r.electricalTimingPassed===false&&r.fabricationReady===false,"Failed attempts never qualify Source29")
  if(name==="cad57"){
   need(postPin===null&&r.originalPostauditProduced===false&&r.originalCadExitCode===null&&r.completeSdkPostauditHeld===null&&r.completeSdkPostauditUnavailableBecauseGuardCrashed===true&&r.cadChildPidOrPgidAllocated===false&&r.cadWrapperSpawned===false&&r.cadApplicationInvoked===false,"Failed57 keeps its absent POST/child/complete SDK audit unknown")
   same(json(r.zonePinsExecutionPin),r.zonePinsExecution,"Failed57 original zone execution")
   same(json(r.cadAttemptExecutionPin),r.unspawnedCadAttemptExecution,"Failed57 original unspawned CAD record")
  }else{
   const post=json(postPin)
   need(postPin!==null&&r.postauditPath===postPin.path&&r.postauditSha256===postPin.sha256&&post.toolSessionCollected===false,"Failed attempt retains actual POST distinct from Root collection")
   for(const key of Object.keys(post))if(key!=="toolSessionCollected")same(r[key],post[key],"Failed receipt matches actual POST field "+key)
   need(r.sourceAndDependenciesHeld===true&&r.workspaceFreeBytesFloorHeld===true&&r.gitMetadataHeld===true&&r.dependenciesBefore.treeSha256==="ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2"&&r.dependenciesAfter.treeSha256===r.dependenciesBefore.treeSha256&&r.solverDependenciesBefore.treeSha256==="47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6"&&r.solverDependenciesAfter.treeSha256===r.solverDependenciesBefore.treeSha256,"Failed58/59 retain their actually available SDK and source audits")
  }
  natural(r.zonePinsExecution);failed[name]=r
 }
 const f57=failed.cad57,f58=failed.cad58,f59=failed.cad59
 need(f57.scope==="ROOT_SOURCE29_CAD57_ZONE_ONLY_CAD_PREFORK_REJECTED_POSTAUDIT_CRASH_RECOVERY"&&f57.phase==="cad-prefork-failure"&&f57.unspawnedCadAttemptExecution.exitCode===null&&!Object.hasOwn(f57.unspawnedCadAttemptExecution,"pid")&&!Object.hasOwn(f57.unspawnedCadAttemptExecution,"pgid"),"Failed57 was rejected before a CAD child existed")
 need(f58.scope==="ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH57_AUTHENTIC_PRIOR_CLOSURES"&&f58.cadWrapperSpawned===false&&f58.cadApplicationInvoked===false&&f58.containerInvocationPerformed===false&&f58.cadExecution.exitCode===null&&!Object.hasOwn(f58.cadExecution,"pid")&&!Object.hasOwn(f58.cadExecution,"pgid"),"Failed58 remains a prefork rejection with no CAD process")
 need(f59.scope==="ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH58_AUTHENTIC_PRIOR_CLOSURES"&&f59.cadWrapperSpawned===true&&f59.containerInvocationPerformed===true&&f59.cadDiagnosticWorkerInvoked===true&&f59.actualKiCadLoadBoardPerformed===false&&f59.actualConnectivityDiagnosticPerformed===false&&f59.workerFailedBeforeCadBoardLoad===true&&f59.cadExecution.exitCode===2&&f59.cadExecution.cleanupOwnedGroupEmpty===true&&f59.cadExecution.diagnosticStopped===false&&f59.rootIndependentlyObservedOwnedContainerAbsent===true&&f59.containerCleanupEvidenceActuallyEmpty===true&&f59.outerPostContainerEmptyRemainsNull===true,"Failed59 worker failed before board load; Root container closure is not a fabricated POST pass")
'''
gate=gate.replace(marker,checks+marker);newmod=oldmod[:gate_start]+gate+oldmod[gate_end:];modpin=save('source32.circuit.tsx',newmod)
assert newmod[:gate_start]==oldmod[:gate_start]and newmod[newmod.index('\nexport function buildOwnerIntermediate32Source()'):]==oldmod[gate_end:]
types=(BASE/'source32-types.ts').read_text();a=' collectionPins:Record<string,Pin|null>;postauditPins:Record<string,Pin|null>;stagePins:Record<string,Pin|null>'
b=a+'\n failedCadAttemptPins:Record<string,Pin>;failedCadAttemptPostPins:Record<string,Pin|null>'
assert types.count(a)==1;tp=save('source32-types.ts',types.replace(a,b))
for n in['capture-source32.ts','render-source32-core.ts','typecheck-source32.sh']:save(n,(BASE/n).read_text());assert(D/n).read_bytes()==(BASE/n).read_bytes()
# Geometry and all unrelated proposal fields invert exactly to the preserved recipe.
inverse=copy.deepcopy(j);inverse['parent29QualificationBindings']=copy.deepcopy(oldj['parent29QualificationBindings']);assert inverse==oldj
maps=[]
for n in['source32.circuit.tsx','source32-types.ts','capture-source32.ts','render-source32-core.ts','typecheck-source32.sh','source32-proposal.json']:
 before=(BASE/n).read_text();after=(D/n).read_text();steps=[]
 for tag,a,b,c,d in difflib.SequenceMatcher(None,before.splitlines(True),after.splitlines(True),autojunk=False).get_opcodes():
  if tag!='equal':steps.append(dict(parentLineStart=a,parentLineEnd=b,newLineStart=c,newLineEnd=d,old=''.join(before.splitlines(True)[a:b]),new=''.join(after.splitlines(True)[c:d])))
 v=before.splitlines(True)
 for x in reversed(steps):assert ''.join(v[x['parentLineStart']:x['parentLineEnd']])==x['old'];v[x['parentLineStart']:x['parentLineEnd']]=x['new'].splitlines(True)
 assert ''.join(v)==after;maps.append(dict(parent=pin(BASE/n),successor=pin(D/n),lineOffsetEdits=steps));save(n+'.EXACT_ED31_PARENT.delta.patch',''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(BASE/n),tofile=str(D/n))))
mpin=save('EXACT_ED31_FUTURE60_AND_FAILED57_58_59_FORWARD_INVERSE_MAPS.json',dict(files=maps,all32GeometryDeclarationsAndCorePredicatesHeld=True,proposalInverseOnlyQualificationBindings=True))
cad60=pin('/tmp/g350-source29-cad60-three-phase-posts-after59-sourceonly-next/SOURCE-manifest.json');assert cad60['sha256']=='cc38e0a08e95be057f9f3e10bd301559b5ad3e688921607bcc9d771b9b2cf49f'
future=save('SIX_FINAL_CAD60_ACTIVATION_BINDINGS_STILL_NULL.json',dict(scope='SOURCE_ONLY_FUTURE_SUCCESSFUL_CAD60_REQUIRED_FAILED57_58_59_ARE_SEPARATE_NONQUALIFYING_CLOSURES',requiredFuture60RootGuard=cad60,sourceProposalPin=pp,strictSourceModulePin=modpin,sixExactPropertyPaths={'actualParent29Qualification':None,'actualParent29Capture':None,'actualParent29Stages.cad':None,'parent29QualificationBindings.collectionPins.cad60':None,'parent29QualificationBindings.stagePins.cad':None,'parent29QualificationBindings.postauditPins.cad60':None},expectedFutureScope='ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH59_AUTHENTIC_PRIOR_CLOSURES',knownActual53CaptureForLaterGate=e['stagePins']['capture'],futureActual60Collection=None,futureActual60Postaudit=None,futureActual60CadReport=None,RootAuthorityCreated=False,SDKOrAppsEvaluated=False))
proof=save('SOURCE_ONLY_FAILED57_58_59_DATA_JOINS_AND_NULL60_REFUSAL_PROOF.json',dict(knownSuccessfulParentStageNames=['batch53','native54','api55','cli56'],preservedKnownSuccessfulPins=e['collectionPins'],failedCadAttemptPins=failedpins,failedCadAttemptPostPins=failedposts,allThreeFailuresRootCollectedAndActuallySpawnedGroupsClosed=True,failed57OriginalPostAbsentAndCompleteSdkPostauditUnknownPreserved=True,failed58UnspawnedPidAndExitNullPreserved=True,failed59WorkerExit2BeforePcbnewLoadBoardPreserved=True,failed58And59ActualPostFullEqualityApartToolSessionCollected=True,actual60PassOrReportNotInvented=True,entrypointsStillRefuseBeforeParentSourceEvaluation=True,source32GeometryCoreCaptureTypecheckBodiesHeld=True,qualification=False,RootAuthority=False))
save('README.md','Source-only immutable successor of ed31: authentic successful stages53/54/55/56 are retained; failed57 and58 prefork refusals and failed59 pre-board-load worker failure are separately authenticated without converting unknowns into success. A successful CAD60 collection, its actual POST and its real29-graph report remain NULL. Both entrypoints refuse before parent calls. No geometry, existing barrel, route, rule, predicate, Source capture/Core/typecheck worker or fresh ID changed. Only parent qualification metadata/type and its strict data qualifier changed; no Root execution authority, SDK/helper/app/JS/compiler/process execution or workspace write occurred.\n')
functional=['source32.circuit.tsx','source32-proposal.json','source32-types.ts','capture-source32.ts','render-source32-core.ts'];expanded=m['parent186HeldSourceBindings']+[pin(D/n)for n in functional];assert len(expanded)==191
for r in expanded:assert pin(r['path'])==r
out={k:copy.deepcopy(v)for k,v in m.items()if k not in ['files','externalFiles','futureFinalCad57Receipt','futureFinalCad57Postaudit','futureFinalCad57Report','explicitWorkerPathCorrection']}
out.update(scope='SOURCE_ONLY_SOURCE32_STRICT_PARENT29_FUTURE60_WITH_TRUTHFUL_FAILED57_58_59_CLOSURES',status='AUTHOR_DONE_REFUSING_GENUINE_SUCCESSFUL_CAD60_FINAL_BINDINGS',preservedUnrunFuture57Recipe=pin(P),source32ProposalPin=pp,source32ModulePin=modpin,captureWorkerPin=pin(D/'capture-source32.ts'),coreWorkerPin=pin(D/'render-source32-core.ts'),typecheckWorkerPin=pin(D/'typecheck-source32.sh'),expandedHeldSourceAndControllerClosure=expanded,files=[pin(p)for p in sorted(D.iterdir())],externalFiles=m['externalFiles']+[pin(P),pin(__file__),cad60]+list(failedpins.values())+[p for p in failedposts.values()if p]+extra,futureFinalCad60Receipt=None,futureFinalCad60Postaudit=None,futureFinalCad60Report=None,failedCadAttemptPins=failedpins,failedCadAttemptPostPins=failedposts,actualParent29Qualification=None,actualParent29Capture=None,actualParent29Stages=copy.deepcopy(j['actualParent29Stages']),strictQualifierNotEvaluated=True,RootAuthorityCreated=False,noRootAuthority=True,workspaceWrites=False)
manifest=save('SOURCE-manifest.json',out);print(json.dumps(dict(manifest=manifest,proposal=pp,module=modpin,types=tp,future=future,dataProof=proof,sourceMap=mpin,closure=191),indent=2))
