import datetime,hashlib,json,os
from pathlib import Path
import subprocess,time
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.environ.get('G350_FULL_SOURCE_CHECKS_APPROVED')=='1','delegated authorization missing'
assert sha(ROOT/'preparation.json')==os.environ['G350_CHECK_PREPARATION_SHA'],'preparation differs'
config=json.loads((ROOT/'commands.json').read_bytes())
source=Path(config['sourceDirectory'])
bun='/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
environment={**os.environ,**config['environment']}
checks=[]
for check in config['commands']:
 argv=[bun if value=='bun' else value for value in check['argv']]
 log=Path(check['log']);started=time.monotonic()
 print(json.dumps({'stage':check['stage'],'phase':'start'}),flush=True)
 with log.open('wb') as output:
  process=subprocess.run(argv,cwd=source,env=environment,stdout=output,stderr=subprocess.STDOUT)
 checks.append({'stage':check['stage'],'argv':argv,'exitCode':process.returncode,'seconds':time.monotonic()-started,'logPath':str(log),'logSha256':sha(log)})
 (ROOT/'run/checks-progress.json').write_text(json.dumps(checks,indent=2)+'\n')
 print(json.dumps({'stage':check['stage'],'exitCode':process.returncode}),flush=True)
 if process.returncode!=0:break
result={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceManifestSha256':config['sourceManifestSha256'],'libraryManifestSha256':config['libraryManifestSha256'],'preparationSha256':sha(ROOT/'preparation.json'),'commandsSha256':sha(ROOT/'commands.json'),'checks':checks,'allPassed':len(checks)==3 and all(check['exitCode']==0 for check in checks),'accepted49':False,'productionSourceAdopted':False,'routingExecuted':False}
(ROOT/'run/result.json').write_text(json.dumps(result,indent=2)+'\n')
raise SystemExit(0 if result['allPassed'] else 1)
