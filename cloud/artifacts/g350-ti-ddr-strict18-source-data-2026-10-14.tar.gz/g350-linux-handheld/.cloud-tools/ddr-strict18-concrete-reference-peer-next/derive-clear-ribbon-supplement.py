"""Finite concrete clean-ribbon candidate polygons and independent analytic controls, stdlib only."""
import ast,collections,hashlib,json,math
from pathlib import Path
HERE=Path(__file__).parent
SOURCE=HERE/'derive-current18-reference-layout.py'
# Execute only source script prefix before any output generation, never applications/imports.
module=ast.parse(SOURCE.read_text());cut=next(i for i,n in enumerate(module.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='results' for t in n.targets))
g={'__file__':str(SOURCE)}
exec(compile(ast.Module(body=module.body[:cut],type_ignores=[]),'exact-source-pure-geometry-inventory','exec'),g)
xy,blocked,merge=g['xy'],g['blocked'],g['merge'];r=g['r'];items=g['items'];WIDTH=g['WIDTH'];HALF=g['HALF'];CLEAR=g['CLEAR'];ADJ=g['ADJ']
report_path=HERE/'REFERENCE_LAYOUT_AND_SHADOW_REPORT.json';report=json.loads(report_path.read_bytes());require=g['require'];write=g['write'];sha=g['sha']
require(sha(report_path)=='0620c69b581cf55889f7e52a13b83c10d239d4e97e849e1676096d9f46710731','Exact first report held')
def complement(intervals):
 out=[];prev=0
 for lo,hi in merge(intervals):
  if lo>prev:out.append([prev,lo])
  prev=max(prev,hi)
 if prev<1:out.append([prev,1])
 return out
pieces=[]
for rec in r['records']:
 adj=ADJ[rec['layer']];foreign=[i for i in items if adj in i['layers'] and i['net']!='GND'];prefix=0
 for i,(a,b) in enumerate(zip(rec['path'],rec['path'][1:])):
  a,b=xy(a),xy(b);length=math.dist(a,b)
  if not length:continue
  intervals=[]
  for item in foreign:intervals+=blocked(a,b,item,HALF,CLEAR)
  for lo,hi in complement(intervals):
   # Trim roundoff/tangency boundaries; do not claim mathematical zero margins.
   trim=1e-6/length;lo+=trim;hi-=trim
   if hi<=lo:continue
   start=(a[0]+lo*(b[0]-a[0]),a[1]+lo*(b[1]-a[1]));end=(a[0]+hi*(b[0]-a[0]),a[1]+hi*(b[1]-a[1]));normal=(-(b[1]-a[1])/length*HALF,(b[0]-a[0])/length*HALF)
   polygon=[{'x':p[0]+sgn*normal[0],'y':p[1]+sgn*normal[1]} for p,sgn in [(start,1),(end,1),(end,-1),(start,-1)]]
   pieces.append({'targetSourceTraceId':rec['sourceTraceId'],'signalLayer':rec['layer'],'patchLayer':adj,'groundNetId':'source_net_0','segmentIndex':i,'segmentFractions':[lo,hi],'distanceAlongMainCarrierMm':[prefix+lo*length,prefix+hi*length],'outline':polygon,'halfWidthMm':HALF,'pourClearanceMm':CLEAR,'endsTrimmedMm':1e-6,'actualForeignCopperScreenClear':True,'sameFilledGroundComponentAndRFReferenceQualified':False,'candidateOnly':True})
  prefix+=length
# Independently verify distance semantics of actual main-only capsule intervals.
byid={i['id']:i for i in items};actualchecks=0
for q in report['analyticMainOnlyAndFixedDeficits']:
 rec=next(v for v in r['records'] if v['sourceTraceId']==q['sourceTraceId'])
 for m in q['mainSignalsP12PourClearancePhysicalFootprint']['foreignOwnerMatches']:
  a,b=map(xy,(rec['path'][m['segmentIndex']],rec['path'][m['segmentIndex']+1]));other=byid[m['foreignOwnerId']];c,d=other['a'],other['b'];dx,dy=d[0]-c[0],d[1]-c[1];den=dx*dx+dy*dy
  for lo,hi in m['segmentFractions']:
   t=(lo+hi)/2;p=(a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1]));u=max(0,min(1,((p[0]-c[0])*dx+(p[1]-c[1])*dy)/den)) if den else 0;dist=math.dist(p,(c[0]+u*dx,c[1]+u*dy))
   require(dist<=other['radius']+WIDTH/2+CLEAR+1e-10,'Actual analytic interval midpoint independent distance');actualchecks+=1
caps=g['g']['capsule_intervals'];controls=[]
def test(name,value):require(value,name);controls.append({'name':name,'passed':True})
test('perpendicular_width_and_gap_exact',abs(sum(hi-lo for lo,hi in caps((-1,0),(1,0),(0,-1),(0,1),.2216))-.2216)<1e-12)
test('parallel_beyond_p12_shadow_threshold_clear',caps((0,0),(1,0),(0,.221601),(1,.221601),.2216)==[])
test('parallel_inside_p12_shadow_threshold_blocked',caps((0,0),(1,0),(0,.221599),(1,.221599),.2216)==[[0,1]])
test('parallel_beyond_provisional_half4_threshold_clear',caps((0,0),(1,0),(0,.570801),(1,.570801),.5708)==[])
test('parallel_inside_provisional_half4_threshold_blocked',caps((0,0),(1,0),(0,.570799),(1,.570799),.5708)==[[0,1]])
test('duplicate_intervals_union_not_sum',merge([[.1,.3],[.2,.4],[.1,.3]])==[[.1,.4]])
test('free_piece_complement_full_block_empty',complement([[0,1]])==[])
test('free_piece_complement_preserves_two_gaps',complement([[.2,.4],[.3,.5]])==[[0,.2],[.5,1]])
test('zero_clearance_actual_main_shadows_persist',all(q['mainSignalsZeroPourClearancePhysicalFootprint']['blockedLengthMm']>0 for q in report['analyticMainOnlyAndFixedDeficits'] if q['sourceTraceId'] in ['source_trace_3','source_trace_13','source_trace_2','source_trace_30']))
owner_lands={}
core=g['core'];typeby={}
for row in core:
 typ=row['type']
 if typ in ['pcb_smtpad','pcb_port','source_port','source_component','pcb_trace']:
  typeby.setdefault(typ,{})[row[typ+'_id']]=row
fixed=[]
for q in report['analyticMainOnlyAndFixedDeficits']:
 count=collections.Counter(m['foreignOwnerId'].split(':')[0] for m in q['allFixedAndCurrent18GroundP12Footprint']['foreignOwnerMatches'] if m['foreignBasis']!='CURRENT18_MAIN_SIGNAL')
 entries=[]
 for ident,n in count.most_common(16):
  v={'foreignIdentity':ident,'matchedSegmentOccurrences':n}
  if ident in typeby.get('pcb_smtpad',{}):
   pad=typeby['pcb_smtpad'][ident];port=typeby['pcb_port'][pad['pcb_port_id']];sp=typeby['source_port'][port['source_port_id']];v.update(ownerName=typeby['source_component'][sp['source_component_id']]['name'],numericPin=sp['pin_number'],sourcePortId=sp['source_port_id'],pcbPortId=port['pcb_port_id'],x=pad.get('x'),y=pad.get('y'),shape=pad['shape'])
  elif ident.startswith('local_dogbone_'):
   tr=next(t for t in g['full']['traces'] if t['pcb_trace_id']==ident);sourceid=tr['source_trace_id'];v.update(originalSignalSourceTraceId=sourceid,fullFixedRoute=tr['route'])
  elif ident in typeby.get('pcb_trace',{}):v.update(actualOriginalSourceTraceId=typeby['pcb_trace'][ident]['source_trace_id'])
  entries.append(v)
 fixed.append({'sourceTraceId':q['sourceTraceId'],'adjacentReferenceLayer':q['adjacentNearFaceReferenceLayer'],'allFixedGndBlockedDistanceIntervalsMm':q['allFixedAndCurrent18GroundP12Footprint']['blockedDistanceIntervalsMm'],'majorAuthenticFixedBlockerOwners':entries})
write(HERE/'CLEAR_GND_RIBBON_PIECES_AND_FIXED_OWNER_SUPPLEMENT.json',{'scope':'SOURCEONLY_EXPLICIT_FINITE_WIDTH_CLEAR_GROUND_RECTANGLE_PIECE_CANDIDATES_NOT_CONNECTED_PATCHES','referenceReportPath':str(report_path),'referenceReportSha256':sha(report_path),'candidateRectangles':pieces,'candidateCount':len(pieces),'candidateCountsByTarget':dict(collections.Counter(p['targetSourceTraceId']for p in pieces)),'majorFixedBlockerSourceOwners':fixed,'limits':['Only actual foreign-copper-clear .8mm-wide ribbon pieces are proposed, clipped independently per segment and trimmed1nm at boundaries.','Pieces may be separate islands. No union, ground island membership, connecting bridge, actual fill, RF return or complete continuous coverage is claimed.','Keep original129reference+96signal barrels/1165lands/261fixedtraces and Source net ownership. Existing candidate Groundstitches must be joined by actual qualified new filled copper, not a net name.','Original Inner2 DDR_1V5 owner means any proposed local Inner2 GND pieces require a separate Source fork with power split/cutout and PDN verification.','Input geometry remains exact18; this supplement does not mutate or adopt source routing.'],'actualAppImports':0,'nativeCalls':0,'cadCalls':0,'referenceQualified':False,'electricalTimingQualified':False,'accepted49':False,'fabricationReady':False})
write(HERE/'GEOMETRY_CONTROLS.json',{'scope':'FINITE_PURE_ANALYTIC_LAYOUT_TESTS','controls':controls,'controlCount':len(controls),'actualMainIntervalMidpointIndependentDistanceChecks':actualchecks,'actualAppImports':0,'cadCalls':0,'referenceQualified':False,'accepted49':False,'fabricationReady':False})
print(json.dumps({'supplementSha256':sha(HERE/'CLEAR_GND_RIBBON_PIECES_AND_FIXED_OWNER_SUPPLEMENT.json'),'controlsSha256':sha(HERE/'GEOMETRY_CONTROLS.json'),'candidateCount':len(pieces),'midpointChecks':actualchecks,'controlCount':len(controls)}))
