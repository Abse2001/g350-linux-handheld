"""Independent own stdlib reconstruction; no SDK or author runtime imported."""
exec(open('/tmp/g350-actual260-ca233-compatibility-sourceonly.py').read().split('if __name__')[0])
PR='/tmp/g350-actual318-four-body20-23-25-36-exhaustive-new-wire-TI3W4W-proof-report.json';PS='56e8a547dcf6a643e5e666e3c647c71c8d4f37811e24320773cc1127614ea32f'
def pinned(path,pin):
 b=Path(path).read_bytes();assert hashlib.sha256(b).hexdigest()==pin;return json.loads(b)
pr=pinned(PR,PS);packet=pinned(pr['inputPath'],pr['inputSha256']);assert pr['inputSha256']=='be1a7d412678c7942b3f3e22a8b4828826c3c90c806ff6257b74cbf528f7f731';assert packet['full49FanoutInput']==f
before={owner(t):t for t in packet['carrierTraces']};after=copy.deepcopy(before);ids=['source_trace_20','source_trace_23','source_trace_25','source_trace_36'];assert [x['owner']for x in pr['bodyInverses']]==ids
strict=lambda a,b:json.dumps(a,separators=(',',':'))==json.dumps(b,separators=(',',':'))
for z in pr['bodyInverses']:
 n=z['owner'];assert strict(before[n],z['before']);assert owner(z['after'])==n
 assert strict(z['before']['route'][0],z['after']['route'][0])and strict(z['before']['route'][-1],z['after']['route'][-1]);after[n]=z['after']
assert all(strict(before[n],after[n])for n in before if n not in ids)
baseids={t['pcb_trace_id']for t in p['carrierTraces']};objects=[o for o in BASE if o['id']not in baseids]
for t in after.values():objects+=bodyobjects(t)
scene=Scene(objects);rows=[]
for n,t in after.items():
 cs=scene.contacts(t);assert not cs,(n,cs[:2]);rows.append({'owner':n,'contactCount':len(cs)})
reverse=Scene([o for n in ids for o in bodyobjects(after[n])]);rev=[]
for t in f['traces']:
 cs=reverse.contacts(t);assert not cs,(t['pcb_trace_id'],cs[:2]);rev.append({'pcbTraceId':t['pcb_trace_id'],'contacts':len(cs)})
def split(t):
 out=[];run=[]
 for i,q in enumerate(t['route']):
  if q['route_type']=='wire':run.append((i,q))
  else:
   if run:out.append(run)
   run=[]
 if run:out.append(run)
 return out
def incident(run,c,rad=.381):
 points=[q for i,q in run];isfirst=math.hypot(points[0]['x']-c['x'],points[0]['y']-c['y'])<1e-8;islast=math.hypot(points[-1]['x']-c['x'],points[-1]['y']-c['y'])<1e-8
 if islast:points=list(reversed(points))
 hits=[];exited=False
 for i,(a,b)in enumerate(zip(points,points[1:])):
  d=pd(c,a,b)
  if not(isfirst or islast)or exited:
   if d<rad-1e-8:hits.append({'segment':i,'distance':d})
  if math.hypot(b['x']-c['x'],b['y']-c['y'])>=rad-1e-8:exited=True
 return {'incidentAtNumericOrCarrierEvent':isfirst or islast,'initialContiguousExitFound':exited,'laterOrDisjointRunContacts':hits,'passed':not hits and(exited or not(isfirst or islast))}
own=[];selfrows=[];headings=[]
for n in ids:
 t=after[n];ss=selfreports(t);assert all(z['passedPureMath']for z in ss);selfrows.append({'owner':n,'runs':ss});angles=[]
 for run in split(t):
  aa=[]
  for(a,b)in zip(run,run[1:]):
   a=a[1];b=b[1];dx=b['x']-a['x'];dy=b['y']-a['y'];assert math.hypot(dx,dy)>1e-9
   aa.append(math.degrees(math.atan2(dy,dx)))
  curves=set(t.get('curvedSegments',[]))
  for j,a in enumerate(aa):
   # Retained curve chords use original metadata; all new noncurve segments are octilinear.
   idx=run[j+1][0]
   if idx not in curves:assert abs(a/45-round(a/45))<1e-7,(n,idx,a)
  for a,b in zip(aa,aa[1:]):angles.append(abs((b-a+180)%360-180))
 assert max(angles,default=0)<=45.2+1e-7,(n,max(angles));headings.append({'owner':n,'maxTurnDeg':max(angles,default=0)})
 sites=[q for q in t['route']if q['route_type']=='via']+[q for br in f['traces']if owner(br)==n for q in br['route']if q['route_type']=='via']
 for c in sites:
  rr=[incident(run,c)for run in split(t)];assert all(x['passed']for x in rr),(n,c,rr);own.append({'owner':n,'barrel':{'x':c['x'],'y':c['y']},'runs':rr})
classes={n:r['busId']for r in f['buses']for n in r['connectionNames']};foreignwire=[o for o in objects if o['kind']=='wire'and o['owner']in classes]
def newedges(n):
 old=before[n]['route'];new=after[n]['route'];oldpairs=[(a,b)for a,b in zip(old,old[1:])if a['route_type']==b['route_type']=='wire'and a['layer']==b['layer']]
 return {i for i,(a,b)in enumerate(zip(new,new[1:]))if a['route_type']==b['route_type']=='wire'and a['layer']==b['layer']and not any(strict(a,x)and strict(b,y)for x,y in oldpairs)}
guidance=[]
for n in ids:
 selected=None if n=='source_trace_25'else newedges(n);count=0;bad=[]
 for a in mats(after[n]):
  if a['kind']!='wire'or(selected is not None and a['index']not in selected):continue
  for o in foreignwire:
   if o['owner']==n or not(set(a['layers'])&set(o['layers'])):continue
   count+=1;need=.3048 if classes[n]==classes[o['owner']]else .4064;d=sd(a['a'],a['b'],o['a'],o['b'])
   if d<need-1e-8:bad.append({'candidateIndex':a['index'],'owner':o['owner'],'distance':d,'required':need})
 assert not bad,(n,bad[:3]);guidance.append({'owner':n,'selectedEdges':'ALL'if selected is None else sorted(selected),'sameLayerPairCount':count,'foreignGuidanceViolations':bad})
via25=[q for q in after['source_trace_25']['route']if q['route_type']=='via'];assert len(via25)==2
assert [(v['x'],v['y'])for v in via25]==[(-2.17,7.6656),(-2.8,5.4)]
for v in via25:assert v['via_diameter']==.4572 and v['via_hole_diameter']==.254 and v['layers']==list(L)
def whole(t):return length(t)+sum(length(z)for z in f['traces']if owner(z)==owner(t))
cohorts=[]
for r in f['buses']:
 old=[whole(before[n])for n in r['connectionNames']];new=[whole(after[n])for n in r['connectionNames']];cohorts.append({'busId':r['busId'],'wholeLengths':new,'skew':max(new)-min(new),'minimumPassingCount':sum(x>=r.get('minLength',-math.inf)-1e-7 for x in new),'originalSkewPassed':max(new)-min(new)<=r.get('maxLengthSkew',math.inf)+1e-7})
 if r['busId']in['DDR_BYTE0','DDR_BYTE1']:assert old==new and len(new)==11
ca=next(r for r in cohorts if r['busId']=='DDR_COMMAND_CLOCK');assert ca['minimumPassingCount']==18 and not ca['originalSkewPassed']
for n in ['source_trace_23','source_trace_36']:assert abs(whole(after[n])-whole(before[n]))<1e-12
assert 20.950002<=whole(after['source_trace_25'])<=21.585658 and whole(after['source_trace_20'])<20.95
report={'scope':'INDEPENDENT_OWN_STDLIB_PEER_EXACT318_FOUR_BODY20_23_25_36_ALL49_NATIVE_GEOMETRY_AND_NEW_WIRE_GUIDANCE_ONLY','proofPath':PR,'proofSha256':PS,'inputPath':pr['inputPath'],'inputSha256':pr['inputSha256'],'bodyOwnersChanged':ids,'other45BodiesLiteral':True,'wholeFoundationLiteral':True,'all49ReciprocalRows':rows,'all263ReverseRows':rev,'nativeSelfMath':selfrows,'ownBarrelFirstExitNoReentryAudit':own,'headings':headings,'all25AndAllOtherNewEdgeExhaustive3W4WAudit':guidance,'wholeChangedMm':{n:whole(after[n])for n in ids},'completeCohorts':cohorts,'actualCarrier25ViasPhysicalOnly':via25,'legacyGuidanceFailuresRemainExplicit':{'source20HeldUpperPairs':pr['whole20GuidanceClassification']['retainedOldEdgeFailureCount'],'source36InheritedSelfPairs':len(pr['source36InheritedPreferredSelfFailuresClassified'])},'SDKExecuted':False,'nativeExecuted':False,'sourceCoreDerived':False,'all49Accepted':False,'fullBoardTIQualification':False,'timingPassed':False,'fabricationReady':False,'independentPurePeerPassed':True}
out=Path('/tmp/g350-actual318-four-body20-23-25-36-independent-pure-peer-report.json');out.open('x').write(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'all49ForeignZero':True,'all263ReverseZero':True,'allNewWireGuidanceZero':True,'whole':report['wholeChangedMm'],'CAcount':ca['minimumPassingCount']}))
