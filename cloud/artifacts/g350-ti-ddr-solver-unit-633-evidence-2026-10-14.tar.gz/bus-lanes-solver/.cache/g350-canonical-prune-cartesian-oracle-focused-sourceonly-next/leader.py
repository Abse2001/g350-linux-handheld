from pathlib import Path
import json, os, subprocess, time

ROOT = Path(__file__).resolve().parent
assert os.environ.get('G350_CARTESIAN_ORACLE_APPROVED') == '1'
commands = json.loads((ROOT / 'commands.json').read_bytes())
rows = []
for name, command in commands:
    (ROOT / 'run/phase.json').write_text(json.dumps({'phase': name, 'completed': rows}) + '\n')
    started = time.monotonic()
    completed = subprocess.run(command, cwd=ROOT / 'source', check=False)
    rows.append({'name': name, 'command': command, 'exitCode': completed.returncode,
                 'wallSeconds': time.monotonic() - started})
    (ROOT / 'run/steps.json').write_text(json.dumps(rows, indent=2) + '\n')
    if completed.returncode:
        raise SystemExit(completed.returncode)
(ROOT / 'run/result.json').write_text(json.dumps({
    'passed': True, 'typecheckPassed': True, 'originalNativeGridCases': 6, 'independentOracleWitnessCases': 1,
    'wholeSuiteExecuted': False, 'allElevenBenchmarksExecuted': False,
    'accepted49': False, 'steps': rows}, indent=2) + '\n')
