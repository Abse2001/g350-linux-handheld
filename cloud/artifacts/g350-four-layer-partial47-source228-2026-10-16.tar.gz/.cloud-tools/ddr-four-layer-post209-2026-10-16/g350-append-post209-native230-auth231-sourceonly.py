#!/usr/bin/env python3
"""Persist two closed Source47 diagnostics only; no SDK or archive execution."""
import datetime, hashlib, json, os, shutil, stat
from pathlib import Path
ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post209-2026-10-16'
BASE = ROOT / '.cloud-tools/ddr-four-layer-manual-2026-10-16'

def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        while b := f.read(1024 * 1024): h.update(b)
        os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return h.hexdigest()

def read(p):
    with p.open('rb') as f:
        x = json.load(f); os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return x

def write(p, x):
    t = p.with_name(p.name + '.append231')
    with t.open('x') as f: json.dump(x, f, indent=2, allow_nan=False); f.write('\n')
    os.replace(t, p)

def main():
    files = [SAVED / n for n in ('WORKSPACE_RESTORE_MANIFEST.json', 'PROGRESS.json', 'WORKSPACE_HASH_INDEX.json')]
    mfile, pfile, ifile = files
    m, p = read(mfile), read(pfile); targets = {v['restorePath']: v for v in m['files']}
    assert len(targets) == len(m['files'])
    base_pins = p['baseArchiveDependency']['originalBaseSavedMetadataPins']
    for n, h in base_pins.items(): assert sha(BASE / n) == h
    for f in files + [SAVED / 'README.md']:
        t = SAVED / 'history' / (f.stem + '.before-native231.' + sha(f)[:16] + f.suffix)
        with f.open('rb') as a, t.open('xb') as b: shutil.copyfileobj(a, b); os.fchmod(b.fileno(), stat.S_IMODE(f.stat().st_mode))
    def save(source, name=None):
        source = Path(source); assert str(source).startswith('/tmp/g350-') and source.is_file() and not source.is_symlink()
        h, mode = sha(source), stat.S_IMODE(source.stat().st_mode)
        if str(source) in targets:
            v = targets[str(source)]; assert v['sha256'] == h and v['bytes'] == source.stat().st_size and v['mode'] == mode
            return v
        dest = SAVED / (name or source.name)
        if dest.exists() and sha(dest) != h: dest = dest.with_name(dest.stem + '__' + h[:16] + dest.suffix)
        if not dest.exists():
            with source.open('rb') as a, dest.open('xb') as b:
                shutil.copyfileobj(a, b, 1024 * 1024); os.fchmod(b.fileno(), mode); os.posix_fadvise(a.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
        assert sha(dest) == h and stat.S_IMODE(dest.stat().st_mode) == mode
        v = {'savedPath': dest.name, 'restorePath': str(source), 'bytes': source.stat().st_size, 'sha256': h, 'mode': mode}
        targets[str(source)] = v; m['files'].append(v)
        return v
    labels = {230: 'NATIVE230_PARTIAL47', 231: 'AUTH231_PARTIAL47'}
    reports = {}
    for scope, label in labels.items():
        folder = next(Path('/tmp').glob('g350-*-root-20261016-run' + str(scope)))
        c = read(folder / 'COLLECTED.json'); assert c['closedAt'] and c['scope'] == scope and c['execution']['exitCode'] == 0
        save(folder / 'COLLECTED.json', label + '_COLLECTED.json')
        rp = folder / 'byte0-result.json'; save(rp, label + '_' + rp.name); reports[scope] = read(rp)
        for name in ('child.log', 'execution.json', 'memory.jsonl'):
            q = folder / 'owned' / name
            if q.is_file(): save(q, label + '_owned_' + name)
        cmd = c['execution']['command']; save(cmd[1])
        for i, value in enumerate(cmd[2:], 2):
            q = Path(value)
            if value.startswith('/tmp/g350-') and q.is_file():
                save(q, 'INPUT_' + label + '_' + q.parent.name + '_' + q.name)
                if cmd[i - 1] == '--input' and (q.parent / 'proof.json').is_file():
                    save(q.parent / 'proof.json', 'INPUT_' + label + '_' + q.parent.name + '_proof.json')
        p['closedExperiments'].append({'scope': scope, 'label': label, 'closedAt': c['closedAt'], 'executionOccurred': True,
            'exitCode': 0, 'reportProduced': True, 'candidateProduced': False, 'defaultBoardPromoted': False, 'all49Accepted': False})
    native, auth = reports[230], reports[231]
    assert native['completed'] and len(native['results']) == 16 and native['completedCheckCount'] == 16
    assert all(v['state'] == 'completed' for v in native['results'])
    assert sum(len(v['findings']) for v in native['results']) == 3
    assert all(not v['findings'] for v in native['results'] if v['name'] != 'checkPcbBusLengthSkew')
    assert len(next(v for v in native['results'] if v['name'] == 'checkPcbBusLengthSkew')['findings']) == 3
    assert auth['complete'] and auth['actualViaCount'] == auth['completedViaCount'] == 227 and auth['foreignViaTrackCopperClearancePassed']
    assert all(auth[k] == [] for k in ('violations', 'ambiguousVias', 'identityFailures', 'invalidSegments', 'unresolvedSegmentOwners'))
    assert auth['exactInputFilesUnchanged'] and auth['expectedConnectedOwners'] == 47 and auth['expectedPendingOwners'] == 2
    assert sha(Path('/tmp/g350-manual47-native-root-20261016-run230/byte0-result.json')) == '1f7e3d6207d9e07a49aa865432e95db86cc2a80b89d2e475d6ed6588544c5252'
    assert sha(Path('/tmp/g350-manual47-via-track-root-20261016-run231/byte0-result.json')) == '39c9b828b22ba47ca4b372fee6e54b985292428b612b31b83aa5502fe5210d7d'
    save(__file__)
    p['latestClosedScopeIncluded'] = 231; p['freshBoardNativePending'] = False
    milestone = {'nativeReport': 'NATIVE230_PARTIAL47_byte0-result.json', 'nativeSha256': '1f7e3d6207d9e07a49aa865432e95db86cc2a80b89d2e475d6ed6588544c5252',
        'focused16Completed': True, 'physical10Findings': 0, 'otherFocusedGeometryFindings': 0, 'busSkewFailuresRetained': 3,
        'historical185Other16NotRetestedOrInherited': True, 'authReport': 'AUTH231_PARTIAL47_byte0-result.json',
        'authSha256': '39c9b828b22ba47ca4b372fee6e54b985292428b612b31b83aa5502fe5210d7d',
        'authenticatedVias': 227, 'foreignViaTrackViolations': 0, 'literalPourAuditPending': True,
        'all49Accepted': False, 'electricalTimingQualified': False, 'fabricationReady': False}
    p['freshNative230Authenticated231'] = milestone
    for primary in (p['primaryCandidate'], m['primaryCandidate']):
        primary['freshBoardNativePending'] = False; primary['freshNative230Authenticated231'] = milestone
        primary['freshEditableSource228']['freshBoardNativePending'] = False
        primary['freshEditableSource228']['authenticatedViaTrackPending'] = False
        primary['freshEditableSource228']['actualLiteralPourCount'] = 14
    p['freshEditableSource228']['freshBoardNativePending'] = False
    p['freshEditableSource228']['authenticatedViaTrackPending'] = False
    p['freshEditableSource228']['actualLiteralPourCount'] = 14
    p['updatedAt'] = m['updatedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    text = (SAVED / 'README.md').read_text().replace('through closed229.', 'through closed231.')
    text = text.replace('227 actual vias. Board-native, authenticated via-track and literal pour checks are pending.',
        '227 actual vias. Fresh native230 completes16 checks: physical10 and five other\nfocused geometry checks return zero; three bus-skew failures remain unfiltered.\nAuth231 authenticates all227 vias with zero foreign via-track findings. The14 actual\nfresh literal pours still require their own audit. Other native185 checks are historical\nand not inherited as current passes.')
    (SAVED / 'README.md').write_text(text)
    m['files'].sort(key=lambda v: v['restorePath']); write(mfile, m); write(pfile, p)
    excluded = {'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
    artifacts = [{'path': f.relative_to(SAVED).as_posix(), 'bytes': f.stat().st_size, 'sha256': sha(f), 'mode': stat.S_IMODE(f.stat().st_mode)}
                 for f in sorted(SAVED.rglob('*')) if f.is_file() and not f.is_symlink() and f.relative_to(SAVED).as_posix() not in excluded]
    p['artifacts'] = artifacts; write(pfile, p)
    rows = artifacts + [{'path': f.name, 'bytes': f.stat().st_size, 'sha256': sha(f), 'mode': stat.S_IMODE(f.stat().st_mode)} for f in (mfile, pfile)]
    write(ifile, {'scope': 'Separate post209 saved evidence; no board acceptance', 'updatedAt': p['updatedAt'],
        'files': sorted(rows, key=lambda v: v['path']), 'selfExcluded': True, 'all49Accepted': False, 'fabricationReady': False})
    for n, h in base_pins.items(): assert sha(BASE / n) == h
    print(json.dumps({'restoreTargets': len(m['files']), 'indexedFiles': len(rows), 'latestClosedIncluded': 231,
        'nativeFocused16Complete': True, 'physical10Findings': 0, 'busSkewFailures': 3, 'all227AuthPassed': True,
        'literal14PoursPending': True, 'oldFrozenBaseUnchanged': True, 'sdkExecuted': False, 'archiveCreated': False}))

if __name__ == '__main__': main()
