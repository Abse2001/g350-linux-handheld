"""ONE explicitly delegated routing-disabled V7 source/physical export; no router."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
from validate_v7 import validate
ROOT=Path(__file__).resolve().parent;BOARD=Path('/workspace/g350-linux-handheld');BUN=str(BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 if sys.argv[1:]!=['--one-approved-source-export'] or os.environ.get('G350_TI_V7_EXPORT_APPROVED')!='1':raise ValueError('Explicit root-delegated V7 source-only authority required')
 raw=(ROOT/'packet-manifest.json').read_bytes();pkt=hashlib.sha256(raw).hexdigest();m=json.loads(raw)
 if os.environ.get('G350_TI_V7_PACKET_SHA')!=pkt:raise ValueError('Exact frozen packet required')
 output=ROOT/m['freshOutput']
 if not(ROOT/'run').is_dir() or output.exists() or output.parent.exists() or(ROOT/'output').exists():raise ValueError('Fresh exclusive source output required')
 started=time.time();command=m['originalCommand'];print(json.dumps({'phase':'ONE_PINNED_ROUTING_DISABLED_V7_SOURCE_BUILD','command':command,'routingDisabled':True,'autoroutingPerformed':False}),flush=True)
 p=subprocess.run(command,cwd=ROOT/'source',env={**os.environ,'G350_REPO_ROOT':str(BOARD)},check=False);(ROOT/'run/source-build-exit.json').write_text(json.dumps({'command':command,'actualExitCode':p.returncode,'sourceBuildCount':1,'routingDisabled':True},indent=2)+'\n')
 if p.returncode!=0 or not output.is_file() or output.stat().st_mtime<started:raise ValueError('Fresh source build failed')
 (ROOT/'run/fresh-layout.circuit.json').write_bytes(output.read_bytes());compiled=json.loads(output.read_bytes())
 values=[json.loads((ROOT/n).read_bytes()) for n in ['inputs/base-layout.circuit.json','inputs/v5-layout.circuit.json','inputs/v6-layout.circuit.json','source/lib/am3352/placement/g350-ti-top-bottom-ddr-v7-translation.json','source/lib/am3352/placement/g350-ti-top-bottom-ddr-v5.json']]
 base,v5,v6,poses,table=values;report=validate(base,v5,v6,compiled,poses,table,m['planeDeclarations']);(ROOT/'run/source-validation.json').write_text(json.dumps(report,indent=2)+'\n');h=sha(output);exits=[]
 commands=[('all17-native-physical',[BUN,str(ROOT/'check-native-physical.mjs'),str(output),h,str(ROOT/'run/native-physical.json')]),('pinned-core-projection',[BUN,str(ROOT/'capture-v7.ts'),str(BOARD/'node_modules/@tscircuit/core/dist/index.js'),str(output),h]),('fresh-endpoint-ti-input',[sys.executable,'-B',str(ROOT/'derive-input.py')])]
 for name,argv in commands:
  print(json.dumps({'phase':name,'command':argv,'signalRoutingPerformed':False}),flush=True);p=subprocess.run(argv,cwd=ROOT,check=False);exits.append({'name':name,'command':argv,'actualExitCode':p.returncode});(ROOT/'run/projection-check-exits.json').write_text(json.dumps(exits,indent=2)+'\n')
  if p.returncode!=0:raise ValueError('Source-only qualification failed: '+name)
 native=json.loads((ROOT/'run/native-physical.json').read_bytes());derive=json.loads((ROOT/'run/input-derivation.json').read_bytes())
 if native['physicalErrors']!=0 or native['checkCount']!=17:raise ValueError('All17 fresh native checks must pass')
 result={'packetSha256':pkt,'sourceBuildExitCode':0,'originalCommand':command,'sourceOutput':{'path':str(output),'bytes':output.stat().st_size,'sha256':h},'copiedFreshOutputSha256':sha(ROOT/'run/fresh-layout.circuit.json'),'validation':report,'nativePhysicalCounts':native['counts'],'nativePhysicalErrors':0,'inputSha256':derive['hashes']['input.json'],'unrestrictedInputSha256':derive['hashes']['original-unrestricted-input.json'],'sourceOnlyQualified':True,'exact18PartAnd2ReferenceRigidTranslationVerified':True,'freshTiEndpointAuditVerified':True,'byte0MaximumTotalPlanarMm':13.2,'byte1MaximumTotalPlanarMm':14.4,'commandTotalPlanarRangeMm':derive['commandTotalPlanarRangeMm'],'sourceBuildCount':1,'toolExits':exits,'sourceInitializerCalled':False,'autoroutingPerformed':False,'cadPerformed':False,'actualBoardDdr49Accepted':False,'electricalTimingQualified':False,'fabricationReady':False}
 (ROOT/'run/result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'sourceOnlyQualified':True,'sourceSha256':h,'inputSha256':result['inputSha256'],'nativePhysicalErrors':0,'actualBoardDdr49Accepted':False}),flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
