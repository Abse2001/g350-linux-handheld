CURRENT THROUGH250: Source23347 remains the Source/Core-verified fallback with
focused native237 results, scoped Source23615-pour pass and13 CA minimum owners.
Separate SOURCE248 has48 numeric-connected routes, pending26, critical244 pass,
245 projection/246 literal capture with full inverse, and all35 fresh Core248
controls passed. Native249 completed focused16: physical10 and the requested
other geometry checks returned zero findings; all3 bus-skew findings remain.
Other16 native checks were not retested. Auth250 authenticated229 actual vias and
found zero foreign via-track violations, ambiguities, identities or unresolved
owners. The new actual raw has14 pours whose margin is NOT YET QUALIFIED. No
Source23615-pour pass or233 CA13 timing progress is inherited. Its own CA minimum
count remains3; complete timing, TI/reference continuity, electrical/default,
all49/CAD/fabrication readiness remain FALSE.

Core247's USBLC6 OBJ-as-JavaScript failure and log are retained; it produced no
raw/control outputs or geometry findings. Core248 passed using the diagnostic
wrapper with no asset-behavior changes; no loader fix is asserted. Older status
paragraphs are historical. Four exact through244 metadata files remain
HISTORY_THROUGH244_*. No candidate geometry changed in this append.

CURRENT THROUGH244: Source23347 remains the Source-verified fallback with its
Source236 scoped15-pour pass and separate13 CA minimum observations. MODEL243 has48
physical/numeric-joined routes, only26 pending. Its fresh Root244 critical companion
passed all6 physical/joined paths and all5 critical APIs in both actual DQS1 views.
The48 model's own measured CA minimum-pass count is3 (33,34,46), skew17.4387009342mm;
it does not inherit merged233 CA13 geometry/timing or Source236 pour qualification.
Cap12 editable Source/Core, full native-board, model pours, CAD, complete timing,
TI/reference-plane, electrical/default/fabrication qualification remain pending.
Older status paragraphs below are historical; only the critical-companion pending
status is superseded by closed244. Exact four through243 metadata files are saved
as HISTORY_THROUGH243_*. No candidate geometry changed in this append.

CURRENT THROUGH243: Source-verified merged23347 is the fallback primary. Its
Source236 exact15-pour foreign-margin aggregate passed. A SEPARATE cap12+.79
MODEL243 has48 physical/numeric-joined routes, pending26, with critical companion,
fresh editable Source/Core, full native and CAD qualification still pending.
The48 model does NOT inherit merged233CA13 timing progress or Source236 pours.

Merged233 partial47 evidence, closed233–238.

This separate collection preserves current223's data-route progress and exact204
CA tuning bodies: 47/49 physical paths, with D12/source26 and DQM0/source30 still
pending. Root233 requalified all47 bodies and numeric joins, both actual DQS1
critical views/all five APIs, and all derived hard maxima. Only13/26 CA owners
meet20.95mm; CA spread15.8186mm and three fresh native bus-skew findings remain.
Full timing, electrical readiness, TI qualification, CAD, default promotion,
all49 acceptance and fabrication readiness are FALSE.

Source234 projection, capture235/full inverse and fresh Core236/all35 controls
passed. Native237 reran focused16 checks: physical10 and other requested geometry
checks returned zero findings; all3 bus-skew findings are retained. Other16 native
checks were not rerun, and prior185 full32 results are historical only. Auth238
authenticated all227 manual vias and found no foreign via-to-track violations.

SOURCE236 LITERAL15-POUR FOREIGN CLEARANCE HAS A SCOPED PASS. The exact pinned
coverage combiner reconstructs227 via and7456 routed-wire object identities and
foreign comparison/exemption sets for all15 fresh BREP pours. The bounded94
contribution is excluded and replaced by the separately completed94 retry.
Minimum measured foreign edge gap is0.11832052949719676mm against0.1016mm.
This does not establish reference continuity, own-net reentry, complete routing,
TI/electrical readiness or fabrication qualification. No Source228 pass is
inherited.

The seven frozen g350-ti-current233-source236-* report/script/control files are
included with exact hashes and modes as ANALYSIS ONLY. Their literal reference-
material gap witnesses are retained. TI/reference-plane/electrical qualification
is not established by this review; all-four-signal routing is not proof of the
documented signal/GND/power/signal stack. The original Source CA minimum20.95mm
remains unchanged and stricter than the current-placement pure TI arithmetic
minimum19.75mm. The assessment does not relax any retained routing requirement.

Restore Source209 and its documented prior prerequisites first, then the frozen
Source228 archive. Their exact archive/manifest hashes are recorded in
WORKSPACE_RESTORE_MANIFEST.json. They are dependencies and were not copied or
rewritten here. The helper does not enforce dependency order; that is a caller
precondition. Then verify/restore this new saved workspace using:

python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post232-2026-10-16
python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post232-2026-10-16 --restore

The existing helper rejects different bytes/modes instead of replacing local
work. Only public regular files are saved; private authority/context bodies are
excluded. No SDK, Bun/Node, application import, archive creation or commit is
performed by the collector. Prior post209 metadata and payloads remain frozen.


Historical append through closed240:239 was refused by shared-memory admission with no
child runtime.240 stopped at the raw component-count guard before geometry
search; its inherited diagnostic arrays do not establish fresh qualification.
No48-path result is claimed. Exact v2/v3/v3a worker bytes are preserved; no v3
runtime closure is included in this append.

The two same-Source236 pour reports are preserved: the first completed14 pours
and bounded before finishing94; the separate94 retry completed. Whole-pour
qualification REMAINS PENDING until the independently reviewed coverage combiner
passes. No Source228 pour pass is inherited. Initial through238 metadata is
preserved byte-for-byte under HISTORY_THROUGH238_*.


Append through243:241 was refused at shared-memory admission without a child.
242 passed the hardware schema and two fanout checks but rejected the changed
Source1 body for a nonconventional corner.243 passed the model all48 body/numeric
and native0.15via-land gates with one named capacitor translated+X0.79 and two
exact0.2mm Bottom reference reroutes. Its original critical-pair geometry stays
held, but fresh critical API/capture/Core/native/CAD companion checks are pending.
The Source23347 primary and its full CA13 timing-improvement geometry remain a
separate fallback. No48 Source-verified, full timing, TI, electrical, default or
fabrication acceptance is claimed. Old pending wording in the historical
through240 append is superseded by the scoped aggregate status above.
Initial through238 and through240 metadata remain exact HISTORY_THROUGH*_ files.
