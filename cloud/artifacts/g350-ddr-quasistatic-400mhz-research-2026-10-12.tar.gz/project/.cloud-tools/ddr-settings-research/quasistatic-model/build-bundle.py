#!/usr/bin/env python3
"""Prepare an ignored, hash-indexed proposal only; never stage/commit/push it."""
from pathlib import Path
import hashlib
import json
import shutil
import stat
import tarfile
import gzip
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
STAGE = ROOT / ".cloud-tools/ddr-quasistatic-400mhz-research-bundle-2026-10-12"
assert not STAGE.exists(), "Preserve existing prepared proposals"
DEFAULTS = ROOT / ".cloud-tools/ddr-settings-research/defaults-independent-review/report.json"
MODEL = json.loads((HERE / "report.json").read_text())
PEER = HERE / "independent-review.json"
assert PEER.exists(), "Independent final peer receipt required"
declared = json.loads(DEFAULTS.read_text())["boundFiles"]
historical_bytes = {}
current_reference_differences = []
for entry in declared:
    current = (ROOT / entry["path"]).read_bytes()
    observed = hashlib.sha256(current).hexdigest()
    if observed != entry["sha256"]:
        assert entry["path"] == "cloud/DDR_ANALYSIS_DEFAULTS_2026-10-12.md", "Unexpected research input drift"
        historical = subprocess.check_output(["git", "show", "d34b33b330faedbac4209344a4267678be08a428:" + entry["path"]], cwd=ROOT)
        assert hashlib.sha256(historical).hexdigest() == entry["sha256"]
        historical_bytes[entry["path"]] = historical
        current_reference_differences.append({"path": entry["path"], "researchInputSha256": entry["sha256"],
                                              "currentRootRecordSha256": observed,
                                              "researchInputRecoveredFromExactGitRevision": "d34b33b330faedbac4209344a4267678be08a428",
                                              "currentRecordLeftUntouched": True})
for entry in MODEL["inputBindings"]:
    assert hashlib.sha256(Path(entry["path"]).read_bytes()).hexdigest() == entry["sha256"]
STAGE.mkdir()
payload = STAGE / "payload"
project = payload / "project"
copies = []


def copy(path, role, override=None):
    relative = path.relative_to(ROOT)
    target = project / relative
    source_bytes = path.read_bytes() if override is None else override
    if target.exists():
        assert target.read_bytes() == source_bytes
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    if override is None:
        shutil.copy2(path, target)
    else:
        target.write_bytes(override)
        target.chmod(stat.S_IMODE(path.stat().st_mode))
    copies.append({"path": str(target.relative_to(payload)), "originalPath": str(relative),
                   "bytes": len(source_bytes), "sha256": hashlib.sha256(source_bytes).hexdigest(),
                   "mode": stat.S_IMODE(path.stat().st_mode), "role": role})


for entry in declared:
    original = historical_bytes.get(entry["path"])
    role = "exact original thirteen-reference research snapshot"
    if original is not None:
        role += "; frozen Gitd34b33b historical input, newer root record not overwritten"
    copy(ROOT / entry["path"], role, original)
for entry in MODEL["inputBindings"]:
    copy(Path(entry["path"]), "retained official model input")
for path in sorted(HERE.rglob("*")):
    if path.is_file() and "__pycache__" not in path.parts:
        copy(path, "local model/control/raw execution or explicitly superseded history")
clock_dir = DEFAULTS.parent
for path in sorted(clock_dir.glob("*")):
    if path.is_file():
        copy(path, "documented400MHz operating-point/source review")
for name in ["cloud/env.sh", "cloud/python-routing-requirements.txt",
             ".cloud-tools/ddr-settings-research/calculator-source/templates-request-binding.json",
             ".cloud-tools/ddr-settings-research/calculator-source/templates-response.json",
             ".cloud-tools/ddr-settings-research/calculator-source/pictures-request-binding.json",
             ".cloud-tools/ddr-settings-research/calculator-source/pictures-response.json",
             ".cloud-tools/ddr-settings-research/calculator-source/3313-single-forward-execution.json",
             ".cloud-tools/ddr-settings-research/calculator-source/3313-single-forward-response.json",
             ".cloud-tools/ddr-settings-research/calculator-source/anonymous-websocket-connect.json",
             ".cloud-tools/ddr-settings-research/guarantee-audit/jlc-pcb-capabilities.txt",
             ".cloud-tools/ddr-settings-research/guarantee-audit/jlc-controlled-stackup.txt",
             ".cloud-tools/ddr-settings-research/guarantee-audit/jlc-calculator-user-guide.txt",
             ".cloud-tools/ddr-settings-research/guarantee-audit/ti-ddr3-impedance-frozen-excerpts.txt"]:
    copy(ROOT / name, "auxiliary reproducibility or retained public provenance")

instructions = """This is a proposed research evidence archive; it imports no board copper.
Extract into a NEW ignored directory, then verify every file against bundle-source-manifest.json.
Do not overwrite any frozen project sources or historical raw results.

Initialize the actual managed board environment: cd /workspace/g350-linux-handheld
source cloud/env.sh
Python3.12.14/NumPy2.3.5/SciPy1.17.0 are asserted by the model; package RECORD audit is preserved.
No package install was performed for this research. Existing cloud/python-routing-requirements.txt
preserves the official wheel hashes for auxiliary package reconstruction if needed in a later task.
Use the prepared managed Python3.12.14; a different interpreter must fail closed.

Example fresh local CONTROL reproduction after extraction (no network needed):
source /workspace/g350-linux-handheld/cloud/env.sh
G350_MODEL_RESEARCH=/absolute/path/to/unpacked/project/.cloud-tools/ddr-settings-research/quasistatic-model
python3 "$G350_MODEL_RESEARCH/run-job.py" "$G350_MODEL_RESEARCH/reproduced-controls-execution.json" --controls --output "$G350_MODEL_RESEARCH/reproduced-controls.json"

Example unchanged3313 SINGLE nominal reproduction using a new output path:
python3 "$G350_MODEL_RESEARCH/run-job.py" "$G350_MODEL_RESEARCH/reproduced-3313-single-execution.json" --stack 3313 --step-um 1 --box-scale 2 --mask offset --output "$G350_MODEL_RESEARCH/reproduced-3313-single.json"
For pair mode append --pair. Use --stack 1080 for the second retained template.
All jobs retain the60s/1GiB RSS/1BLAS guard; raw historical output files refuse overwrite.

The old report/command strings record original absolute paths as provenance. Model inputs are read
relative to the copied project root and are self-contained. Compare numerical values/controls,
not entire regenerated JSON hashes containing runtime paths/time. The source-defaults review also
requires a real board Git checkout; do not present this reduced copied project as an editable board.

All results are nominal local electrostatic estimates. See model README/report and independent
review for interface/metal/mask/outer-boundary approximations. No impedance guarantee, electrical
timing pass, accepted49 route, fabrication readiness or exact stackup selection is established.
"""
(payload / "REPRODUCE.md").write_text(instructions)
local = payload / "REPRODUCE.md"
copies.append({"path": "REPRODUCE.md", "bytes": local.stat().st_size,
               "sha256": hashlib.sha256(local.read_bytes()).hexdigest(),
               "mode": stat.S_IMODE(local.stat().st_mode), "role": "archive-only reproducibility instructions"})
internal = {"schemaVersion": 1, "kind": "Proposed local DDR electrical research bundle",
            "files": sorted(copies, key=lambda item: item["path"]),
            "fileCount": len(copies), "declaredThirteenOriginalReferences": declared,
            "currentRootRecordDifferences": current_reference_differences,
            "noFieldGridArrays": True, "accepted49": False, "electricalTimingPassed": False,
            "impedanceQualified": False, "fabricationReady": False,
            "stagedOrCommittedOrPushedByBuilder": False}
(payload / "bundle-source-manifest.json").write_text(json.dumps(internal, indent=2) + "\n")
archive = STAGE / "g350-ddr-quasistatic-400mhz-research-2026-10-12.tar.gz"
with archive.open("wb") as raw, gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w") as tf:
        for path in sorted(payload.rglob("*")):
            if path.is_file():
                info = tf.gettarinfo(str(path), arcname=str(path.relative_to(payload)))
                info.mtime, info.uid, info.gid = 0, 0, 0
                info.uname, info.gname = "", ""
                with path.open("rb") as handle:
                    tf.addfile(info, handle)
data = archive.read_bytes()
proposed = {"schemaVersion": 1,
            "proposedArchivePath": "cloud/artifacts/" + archive.name,
            "archive": {"localIgnoredPath": str(archive), "bytes": len(data),
                        "sha256": hashlib.sha256(data).hexdigest()},
            "bundleManifestSha256": hashlib.sha256((payload / "bundle-source-manifest.json").read_bytes()).hexdigest(),
            "archiveMembers": len(copies) + 1,
            "reportSha256": hashlib.sha256((HERE / "report.json").read_bytes()).hexdigest(),
            "independentReviewSha256": hashlib.sha256(PEER.read_bytes()).hexdigest(),
            "originalResearchInputSnapshotsExact": True,
            "currentRootRecordDifferences": current_reference_differences,
            "researchBuilderChangedOriginalReferenceFiles": False, "accepted49": False,
            "impedanceQualified": False, "electricalTimingPassed": False,
            "fabricationReady": False, "publicationRequiresRootReview": True,
            "stagedOrCommittedOrPushedByBuilder": False}
(STAGE / "artifact-manifest.proposed.json").write_text(json.dumps(proposed, indent=2) + "\n")
print(json.dumps(proposed))
