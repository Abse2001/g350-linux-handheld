 assert out.parent==Path('/tmp')and out.name.startswith('g350-source29-api-root-')and out.resolve()==out and not out.exists()and not out.is_symlink()
 with(ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  prior=closed54();assert prior['actualClosedScopeCount']==api29_contract['requiredPriorScopeCount']==54
  identity_before=guard_identity();_,native_before,board_before,solver_before,_=c.guard.checked();bindings();git_before=git_inventory();assert git_before==base['gitMetadataFiles']
  assert board_before['treeSha256']==stage['boardSdkTreeSha256']and solver_before['treeSha256']==stage['solverSdkTreeSha256']
  workspace_floor=shutil.disk_usage('/workspace').free;out.mkdir(mode=0o700);phases=[];generated=[];model_pin=proof_pin=None;batch_passed=False;batch_error=None
  artifacts=dict(actualCorePath=proposal['actual53CoreRawPin']['path'],actualCoreSha256=proposal['actual53CoreRawPin']['sha256'],coreControlsPath=proposal['actual53CoreControlsPin']['path'],coreControlsSha256=proposal['actual53CoreControlsPin']['sha256'])
  def invariant_check(require_phase_success=True):
   bindings();no_git_redirects();assert closed54()==prior and guard_identity()==identity_before and git_inventory()==git_before and shutil.disk_usage('/workspace').free>=workspace_floor
   for row in generated:binding(row)
   for row in phases:
    if require_phase_success:assert row['passed']is True
    assert row['ownedGroupEmptyActuallyObserved']is True and c.guard.process_scope.owned(row['execution']['pgid'])==[]
  for phase in('projection','api'):
   phase_dir=out/phase;phase_dir.mkdir(mode=0o700);(phase_dir/'bun-cache').mkdir(mode=0o700);(phase_dir/'tmp').mkdir(mode=0o700);output=phase_dir/'output';output.mkdir(mode=0o700)
   policy=api29_contract['phasePolicies'][phase];expected_wall=60 if phase=='projection'else 90;assert policy=={'wallSeconds':expected_wall,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
   environment={'NO_COLOR':'1','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(phase_dir/'bun-cache'),'TMPDIR':str(phase_dir/'tmp')}
   command=None;execution=None;run_error=post_error=inspection_error=output_error=None;phase_before=phase_after=None;empty=None;held=False;phase_passed=False;result=None;raw_report=None;packet_pin=None;authority_pin=None
   try:
    invariant_check();_,n0,b0,s0,_=c.guard.checked();phase_before=dict(native=n0,board=b0,solver=s0);assert n0==native_before and b0==board_before and s0==solver_before
    if phase=='projection':
     manifest=dict(coreSourceManifestSha256=proposal['promoted29ManifestPin']['sha256'],originalSource29ProposalSha256=proposal['promoted29ProposalPin']['sha256'],actualFreshArtifacts=artifacts,actualNativeReportPath=proposal['actual54ReportPin']['path'],actualNativeReportSha256=proposal['actual54ReportPin']['sha256'],originalConstraintTemplatePath=proposal['originalConstraintTemplatePin']['path'],originalConstraintTemplateSha256=proposal['originalConstraintTemplatePin']['sha256'],originalNumericMetadataPath=proposal['originalNumericMetadataPin']['path'],originalNumericMetadataSha256=proposal['originalNumericMetadataPin']['sha256'])
     pm=phase_dir/'PROJECTION-BOUND.json';write(pm,manifest);packet_pin=file_row(pm);generated.append(packet_pin)
     command=[api29_contract['pythonInterpreterPin']['path'],'-B',api29_contract['projectorPin']['path'],str(pm),packet_pin['sha256'],str(output)];environment['G350_FRESH29_FULL49_PROJECTION_APPROVED']='1'
    else:
     assert model_pin is not None and proof_pin is not None and len(phases)==1 and phases[0]['phase']=='projection'and phases[0]['passed']is True and phases[0]['ownedGroupEmptyActuallyObserved']is True
     manifest=json.loads(json.dumps(native29_template));manifest.update(scope='ROOT_ONE_ACTUAL_SOURCE29_FRESH49_AND_ORIGINAL_PRIVATE_API131_AFTER_NATIVE54',status='ROOT_BOUND_ACTUAL_SOURCE29_ORIGINAL_API131_STAGE',sourceManifestSha256=proposal['native29PreparationPin']['sha256'],actualFreshArtifacts=artifacts,actualNativeReportPath=proposal['actual54ReportPin']['path'],actualNativeReportSha256=proposal['actual54ReportPin']['sha256'],nativeQualificationPacketSha256=proposal['actual54BoundManifestPin']['sha256'],authorized49InputPath=model_pin['path'],authorized49InputSha256=model_pin['sha256'],fresh49ProjectionProofPath=proof_pin['path'],fresh49ProjectionProofSha256=proof_pin['sha256'],actualSource29BatchRootCollection=proposal['actual53CollectionPin'],actualSource29BatchPostaudit=proposal['actual53PostauditPin'],actualNativeRootCollection=proposal['actual54CollectionPin'])
     verified={}
     for doc in(proposal,native29_preparation,native29_template,promoted29,data29,read(proposal['actual54CollectionPin']['path']),read(proposal['actual54PostauditPin']['path']),generated):
      for row in rows(doc):
       row={k:row[k]for k in('path','sha256','bytes','mode')};assert row['path']not in verified or verified[row['path']]==row;binding(row);verified[row['path']]=row
     local={r['path']for r in native29_template['files']};assert len(local)==3;manifest['files']=[verified[r['path']]for r in native29_template['files']];manifest['externalFiles']=[verified[p]for p in sorted(verified)if p not in local]
     ab=phase_dir/'API-BOUND.json';write(ab,manifest);packet_pin=file_row(ab);generated.append(packet_pin)
     aa=phase_dir/'API_ROOT_AUTHORITY.json';write(aa,dict(authorizedByRoot=True,scope=manifest['scope'],packetSha256=packet_pin['sha256'],rootFullGuardReadPassed=True,noConcurrentRootWorker=True,sourceManifestSha256=proposal['native29PreparationPin']['sha256'],coreSourceManifestSha256=proposal['promoted29ManifestPin']['sha256'],freshArtifacts=artifacts,rootGuardProposalManifestSha256=source_sha,actualClosedPriorScopes=prior,projectionExecution=phases[0]['execution'],projectionOwnedChildWaitReturned=True,projectionOwnedGroupEmptyActuallyObserved=True,policy=policy,nonce=secrets.token_hex(32),Source29Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingQualified=False,fabricationReady=False));authority_pin=file_row(aa);generated.append(authority_pin)
     command=[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',api29_contract['apiWorkerPin']['path'],str(ab),packet_pin['sha256'],str(aa),authority_pin['sha256'],proposal['actual54ReportPin']['path'],str(output/'actual-original-api29.json')];environment['G350_SOURCE7_SOURCE6_SOURCE18_RESET_REPAIR_29_FRESH_NATIVE_APPROVED']='1'
    def prefork(memory):
     invariant_check();assert memory['current']+policy['rssBytes']+1073741824<policy['sharedBytes']and shutil.disk_usage('/tmp').free>=536870912
    execution=process_runner.run_guarded(command,str(c.BOARD),phase_dir/'owned',policy,environment,before_spawn=prefork)
   except BaseException as error:
    run_error=type(error).__name__+': '+str(error)
    try:
     if(phase_dir/'owned/execution.json').is_file():execution=read(phase_dir/'owned/execution.json')
    except BaseException as parse_error:run_error+='; execution recovery '+type(parse_error).__name__+': '+str(parse_error)
   try:
    invariant_check();_,n1,b1,s1,_=c.guard.checked();phase_after=dict(native=n1,board=b1,solver=s1);assert phase_before==phase_after and n1==native_before and b1==board_before and s1==solver_before;held=True
   except BaseException as error:post_error=type(error).__name__+': '+str(error)
   try:
    assert isinstance(execution,dict);empty=c.guard.process_scope.owned(execution['pgid'])==[]
   except BaseException as error:inspection_error='Owned scope '+type(error).__name__+': '+str(error)
   natural=bool(isinstance(execution,dict)and type(execution.get('exitCode'))is int and execution['exitCode']>=0 and execution.get('diagnosticStopped')is False and not execution.get('stopReasons')and execution.get('cleanupOwnedGroupEmpty')is True and isinstance(execution.get('oomDelta'),dict)and bool(execution['oomDelta'])and not any(execution['oomDelta'].values())and empty is True)
   try:
    assert held and run_error is post_error is inspection_error is None and natural and execution['exitCode']in(0,1);h.finite(execution,execution['exitCode']);assert execution['command']==command and execution['policy']==policy and execution['currentGuardPid']==identity_before['pid']and guard_identity()==identity_before and 'guardError'not in execution
    if phases:assert phases[-1]['execution']['endedAt']<=execution['startedAt']and phases[-1]['execution']['pgid']!=execution['pgid']
    if phase=='projection':
     expected={'GENUINE_CORE29_FULL49_UNSEEDED_PUBLIC_INPUT.json','GENUINE_CURRENT_CORE49_NUMERIC_REQUESTS_AND_CONTACTS.json','CURRENT_MATERIAL_PROJECTION_PROOF.json','GENUINE_CURRENT_CORE49_CONSTRUCTOR_INPUT.json','CURRENT_VIA_EVENT_AND_NPTH_INVERSE_PROOF.json'}
     assert execution['exitCode']==0 and {p.name for p in output.iterdir()}==expected
     for path in output.iterdir():assert path.is_file()and not path.is_symlink()and path.stat().st_size<=16777216
     model_pin=file_row(output/'GENUINE_CURRENT_CORE49_CONSTRUCTOR_INPUT.json');proof_pin=file_row(output/'CURRENT_VIA_EVENT_AND_NPTH_INVERSE_PROOF.json');model=read(model_pin['path']);proof=read(proof_pin['path']);material=read(output/'CURRENT_MATERIAL_PROJECTION_PROOF.json');numeric=read(output/'GENUINE_CURRENT_CORE49_NUMERIC_REQUESTS_AND_CONTACTS.json')
     assert len(model['connections'])==49 and len(model['traces'])==263 and len(model['obstacles'])==1298 and model['layerCount']==4 and sum(p['route_type']=='via'for t in model['traces']for p in t['route'])==98
     assert proof['actualCoreSha256']==artifacts['actualCoreSha256']and proof['actualNativeReportSha256']==proposal['actual54ReportPin']['sha256']and proof['constructorInputSha256']==model_pin['sha256']and proof['sourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and proof['originalSource29ProposalSha256']==proposal['promoted29ProposalPin']['sha256']and proof['exactFullInverseToFresh29Parent']is True
     for key in('reference129BarrelsAsOwnedObstaclesExactlyOnce','reference165WiresUnchanged','physical227BarrelsRepresentedExactlyOnce','viaEventsRepresentExistingPhysicalBarrelsNotNewHoles','wireGeometryWidthsAndPlanarLengthsHeld','only98TerminalLayersKeysRemoved','allOriginalConstraintFieldsHeld','physicalSourceAndCoreUntouched'):assert proof[key]is True
     assert len(proof['viaEvents98'])==98 and len(proof['removedDuplicateSignalViaObstacles98'])==98 and len(proof['terminalMap49'])==49 and len(proof['npthConservativeMarginProjection'])==2
     projected_stub_lengths=[len(x['projectedRoute'])for x in proof['viaEvents98']];assert projected_stub_lengths.count(4)==95 and projected_stub_lengths.count(6)==projected_stub_lengths.count(13)==projected_stub_lengths.count(15)==1 and sum(projected_stub_lengths)==414
     model_trace_by_id={t['pcb_trace_id']:t for t in model['traces']};assert all(model_trace_by_id[x['actualPcbTraceId']]['route']==x['projectedRoute']for x in proof['viaEvents98'])
     assert len(material['fixed263Projection'])==263 and len(material['excludedOnly26ActualCarrierBodies'])==29 and len(material['current1396ObstacleProjection'])==1396 and material['originalRulesExactlyHeld']is material['all98GenuineFull4SpanBarrelsAndCurrentNumericPadContactsHeld']is material['oldPlanningMaterialNotReused']is True and material['currentCoreRawEdited']is material['publicRoutingExecuted']is False
     assert len(numeric['numericFull49Input']['connections'])==49 and len(numeric['contacts'])==98
     result=dict(actualFresh49Model=model_pin,actualFresh49ProjectionProof=proof_pin,source29FreshFull49ProjectionPassed=True,actual49Requests=49,actualFixedTraces=263,actualHardObstacles=1298,actualSignalViaEvents=98,zeroSelected29CarrierBodiesSeeded=True)
    else:
     assert {p.name for p in output.iterdir()}=={'actual-original-api29.json'};raw_report=read_bounded(output/'actual-original-api29.json',16777216)
     assert raw_report['scope']=='ACTUAL_MOVED29_FRESH_CORE_ALL3_UNCHANGED_ORIGINAL_PRIVATE_API_DIAGNOSTIC'and raw_report['packetSha256']==packet_pin['sha256']and raw_report['actualCorePath']==artifacts['actualCorePath']and raw_report['actualCoreSha256']==artifacts['actualCoreSha256']and raw_report['actualNativeReportPath']==proposal['actual54ReportPin']['path']and raw_report['actualNativeReportSha256']==proposal['actual54ReportPin']['sha256']
     assert raw_report['original49Input']=={k:model_pin[k]for k in('path','sha256')}and raw_report['fresh49ProjectionProof']==dict(path=proof_pin['path'],sha256=proof_pin['sha256'],actualCoreSha256=artifacts['actualCoreSha256'])
     assert raw_report['actualCompleteOriginalSignalCount']==29 and raw_report['expectedMissingOriginalSignalCount']==20 and len(raw_report['continuity'])==29 and raw_report['allOriginalApiLoaded26ChecksPassed']is True
     assert raw_report['checkInventory']==dict(continuityRows=29,primaryBooleanPredicates=128,secondaryDqs1BooleanPredicates=3,primaryPlusSecondaryBooleanPredicates=131,loadedCohortBusGatesAdditional=3,immutableDataGateAdditional=1)
     for row in raw_report['continuity']:assert row['pathVisible']is row['selfClear']is row['conventionalAngles']is row['foreignActual26AndOriginalFixedCopperIncluded']is True and row['segmentsVisible']and all(row['segmentsVisible'])
     for name in('shared','exterior','coupling','pairLengths'):assert len(raw_report[name])==3 and all(r['matched']is True for r in raw_report[name])
     secondary=raw_report['secondaryDqs1View'];assert secondary['name']=='early_reflected_meander'and secondary['geometryAndEndpointsUnchanged']is secondary['passed']is True
     for name in('shared','exterior','coupling'):assert len(secondary[name])==1 and secondary[name][0]['matched']is True
     for key in('exactMaterialHeld','fullOriginalBusRostersAndConstraintsHeld','originalFullDifferentialPairArrayUnchanged','all3DifferentialPairsInvokedAgainstFreshCopper','actualLayerAndEndpointIdViewDerivedFromFreshPhysicalOwnedAliases','originalPrivateContinuousApiImplementationsUnchanged','actualNumericPhysicalGraphsRequired','actualClockGeometryUsed','onlyByte1FullElevenPresent','originalFullByte0AndCaStillIncomplete'):assert raw_report[key]is True
     assert raw_report['loadedCohortsExplicitlyPartial']==dict(DDR_BYTE0=6,DDR_BYTE1=11,DDR_COMMAND_CLOCK=11)and len(raw_report['loadedCohortBusReports'])==3 and all(r['aboveMinimumLength']is r['withinLengthLimit']is r['matched']is True for r in raw_report['loadedCohortBusReports'])
     for key in('stale21316IndicesOr068fSource28GeometryUsed','automaticCoreSrjUsed','rawCoreOrAuthoritativeInputRetagged','nativeManufacturingCheckerExecuted','coreRenderedByThisWorker','freshCadExecuted','originalGridOrPublicSolverExecuted','fullCohortTimingPassed','electricalDelayModelQualified','referenceQualified','complete26Accepted','accepted49','fabricationReady'):assert raw_report[key]is False
     result=dict(actualOriginalApiReportPin=file_row(output/'actual-original-api29.json'),originalApiLoaded29ChecksPassed=True,originalApiBooleanPredicates=131,apiMethodInvocationCount=None,methodCountNotInstrumented=True,bothDqs1CoupledViewsPassed=True,loadedCohortsExplicitlyPartial=raw_report['loadedCohortsExplicitlyPartial'])
    phase_passed=bool(natural and execution['exitCode']==0)
   except BaseException as error:inspection_error=(inspection_error+'; 'if inspection_error else'')+type(error).__name__+': '+str(error)
   phase_outputs=[]
   for path in sorted(output.iterdir()):
    try:phase_outputs.append(file_row(path))
    except BaseException as error:output_error=type(error).__name__+': '+str(error);phase_passed=False
   try:identity_after=guard_identity()
   except BaseException as error:identity_after=None;output_error=type(error).__name__+': '+str(error);phase_passed=False
   row=dict(phase=phase,command=command,execution=execution,runFailure=run_error,postverificationFailure=post_error,resultInspectionFailure=inspection_error,outputBindingFailure=output_error,guardIdentityBefore=identity_before,guardIdentityAfter=identity_after,sourceAndDependenciesHeld=held,phaseSnapshotsBefore=phase_before,phaseSnapshotsAfter=phase_after,ownedGroupEmptyActuallyObserved=empty,stageNaturallyCompleted=natural,ownedChildNatural0=natural and execution['exitCode']==0,passed=phase_passed,result=result,packetPin=packet_pin,authorityPin=authority_pin,outputFiles=phase_outputs,originalApiBooleanPredicates=131 if isinstance(raw_report,dict)and raw_report.get('checkInventory',{}).get('primaryPlusSecondaryBooleanPredicates')==131 else None,originalApiCalls=None if phase=='api'else 0,originalApiMethodInvocationCountNotInstrumented=True,CoreCalls=0,nativeCalls=0,cliCalls=0,cadCalls=0,Source29Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingPassed=False,fabricationReady=False)
   pp=phase_dir/'POSTAUDIT.json';write(pp,row);row['postauditPath']=str(pp);row['postauditSha256']=sha(pp);phases.append(row)
   if not phase_passed:batch_error='Phase '+phase+' failed; later phases not attempted';break
   generated.extend(phase_outputs+[file_row(pp)])
  final_error=None;native_after=board_after=solver_after=None
  try:
   invariant_check(False);_,native_after,board_after,solver_after,_=c.guard.checked();assert native_before==native_after and board_before==board_after and solver_before==solver_after
   batch_passed=len(phases)==2 and all(r['passed']is True for r in phases)
  except BaseException as error:final_error=type(error).__name__+': '+str(error);batch_passed=False
  projection=next((r for r in phases if r['phase']=='projection'),None);api=next((r for r in phases if r['phase']=='api'),None)
  post=dict(scope='ROOT_SOURCE29_FRESH49_PROJECTION_AND_ORIGINAL_API131_WITH54_AUTHENTIC_PRIOR_CLOSURES',phase='projection-api-batch',sourceManifestSha256=proposal['native29PreparationPin']['sha256'],coreSourceManifestSha256=proposal['promoted29ManifestPin']['sha256'],rootGuardProposalManifestSha256=source_sha,actualClosedPriorScopes=prior,phases=phases,orderedPhaseNames=[r['phase']for r in phases],expectedPhaseNames=['projection','api'],notAttemptedPhaseNames=[p for p in('projection','api')if p not in[r['phase']for r in phases]],sameGuardIdentity=identity_before,guardIdentityHeldAcrossChildren=all(r['guardIdentityBefore']==r['guardIdentityAfter']==identity_before for r in phases),allOwnedGroupsIndependentlyObservedEmpty=bool(phases)and all(r['ownedGroupEmptyActuallyObserved']is True for r in phases),eachAttemptedChildNaturallyCompleted=bool(phases)and all(r['stageNaturallyCompleted']is True for r in phases),bothChildrenNaturallyCompleted=len(phases)==2 and all(r['stageNaturallyCompleted']is True for r in phases),sourceAndDependenciesHeld=final_error is None and all(r['sourceAndDependenciesHeld']is True for r in phases),dependenciesBefore=board_before,dependenciesAfter=board_after,solverDependenciesBefore=solver_before,solverDependenciesAfter=solver_after,projectionExecution=projection['execution']if projection else None,apiExecution=api['execution']if api else None,projectionPassed=projection['passed']if projection else False,apiPassed=api['passed']if api else False,projectionBeforeApiSeriallyEnforced=api is not None and projection is not None and projection['passed']is True and projection['execution']['endedAt']<=api['execution']['startedAt']if api and isinstance(api['execution'],dict)else False,actualCorePath=artifacts['actualCorePath'],actualCoreSha256=artifacts['actualCoreSha256'],actualNativeReport=proposal['actual54ReportPin'],actualFresh49Model=model_pin,actualFresh49ProjectionProof=proof_pin,workspaceFreeBytesBefore=workspace_floor,workspaceFreeBytesFloorHeld=final_error is None,gitMetadataHeld=final_error is None,batchFailure=batch_error,finalVerificationFailure=final_error,passed=batch_passed,passedMeansFresh49ProjectionAndOriginalLoaded29Api131Only=True,originalApiBooleanPredicates=api['originalApiBooleanPredicates']if api else None,originalApiCalls=None if api and isinstance(api['execution'],dict)else 0,originalApiMethodInvocationCountNotInstrumented=True,CoreCalls=0,nativeCalls=0,cliCalls=0,cadCalls=0,newRoutesAdopted=0,hardwareAcceptanceCheckpointUnchanged=True,Source29Accepted=False,referenceQualified=False,electricalTimingPassed=False,all49Accepted=False,accepted49=False,fabricationReady=False,toolSessionCollected=False)
  pp=out/'POSTAUDIT.json';write(pp,post);print(json.dumps(dict(passed=batch_passed,scope=post['scope'],postauditPath=str(pp),postauditSha256=sha(pp),projectionExecution=post['projectionExecution'],apiExecution=post['apiExecution'])))
 return 0 if batch_passed else 2

if __name__=='__main__':raise SystemExit(main())
