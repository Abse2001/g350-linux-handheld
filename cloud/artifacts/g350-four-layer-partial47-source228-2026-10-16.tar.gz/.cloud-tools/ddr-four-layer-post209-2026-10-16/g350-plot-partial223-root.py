#!/usr/bin/env python3
"""Render only the hash-pinned run223 partial model and read run225 evidence.

No SDK, native, Core or CAD execution. Frozen predecessor outputs stay intact.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', '/tmp/g350-plot223-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Circle, Rectangle
from matplotlib.transforms import Affine2D

CANDIDATE = Path('/tmp/g350-deterministic-manual47-root-20261016-run223/byte0-result.candidate.json')
CANDIDATE_SHA = 'ddaa4efd8d20f16cefca89b9166e834a956113194beed6f0f13903e346e36ea0'
CRITICAL_REPORT = Path('/tmp/g350-manual47-critical-root-20261016-run225/byte0-result.json')
CRITICAL_SHA = '0b4027452b0acdfca4f2009a57fbff7d47700c233fa7476b840f6a1946106a60'
OUTPUT_DIR = Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-four-layer-post209-2026-10-16')
LAYERS = ['top', 'inner1', 'inner2', 'bottom']
COLORS = {'ordinary': '#16856d', 'source_trace_15': '#1170aa', 'source_trace_16': '#1170aa',
          'source_trace_27': '#dd761c', 'source_trace_28': '#dd761c',
          'source_trace_33': '#8b43b3', 'source_trace_34': '#8b43b3'}


def owner(trace):
    return trace.get('connection_name', trace.get('source_trace_id'))


def wire_segments(trace, layer):
    return [[(a['x'], a['y']), (b['x'], b['y'])] for a, b in zip(trace['route'], trace['route'][1:])
            if a['route_type'] == b['route_type'] == 'wire' and a['layer'] == b['layer'] == layer]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path, default=CANDIDATE)
    parser.add_argument('--output-dir', type=Path, default=OUTPUT_DIR)
    args = parser.parse_args()
    data = args.candidate.read_bytes()
    if hashlib.sha256(data).hexdigest() != CANDIDATE_SHA:
        raise ValueError('Expected exact frozen run223 candidate')
    candidate = json.loads(data)
    scene, bodies = candidate['full49FanoutInput'], candidate['carrierTraces']
    routed = {owner(t) for t in bodies}
    pending = [c for c in scene['connections'] if c['name'] not in routed]
    if len(bodies) != 47 or len(routed) != 47 or {c['name'] for c in pending} != {'source_trace_26', 'source_trace_30'}:
        raise ValueError('Expected 47 routed owners and only D12/DQM0 pending')
    if scene['allowedLayers'] != LAYERS or scene['layerCount'] != 4 or candidate['all49Accepted'] is not False or candidate['fabricationReady'] is not False:
        raise ValueError('Expected partial four-layer candidate with fabricationReady=false')
    physical = candidate['finalScenePhysicalReports']
    if candidate['allSavedCarriersCurrentSceneQualified'] is not True or len(physical) != 47 or not all(r['passed'] for r in physical):
        raise ValueError('Expected actual223 all47 physical checks passed')
    critical_data = CRITICAL_REPORT.read_bytes()
    if hashlib.sha256(critical_data).hexdigest() != CRITICAL_SHA:
        raise ValueError('Expected exact actual225 critical report')
    critical = json.loads(critical_data)
    views = critical['criticalValidationViews']
    if critical['inputSha256'] != CANDIDATE_SHA or critical['currentSceneCriticalAssertionsFreshlyQualified'] is not True or critical['criticalProfileQualified'] is not True:
        raise ValueError('Critical evidence must bind this exact223 model')
    if len(critical['criticalPhysicalReports']) != 6 or not all(r['passed'] for r in critical['criticalPhysicalReports']):
        raise ValueError('Expected six actual225 physical reports passed')
    if len(views) != 2 or {v['scope'] for v in views} != {'DQS1_LOWER_U_SHARED_VIEW', 'DQS1_EARLY_MEANDER_SHARED_VIEW'}:
        raise ValueError('Both actual DQS1 shared-section views required')
    for view in views:
        if view['passed'] is not True or view['c31']['solved'] is not True or set(view['reports']) != {'bus', 'pair', 'shared', 'coupling', 'exterior'}:
            raise ValueError('Actual225 five APIs and planar validation must pass')
        if not all(len(rows) == 3 and all(r['matched'] for r in rows) for rows in view['reports'].values()):
            raise ValueError('Expected three original pairs in every API report')
    if args.output_dir.resolve() != OUTPUT_DIR.resolve():
        raise ValueError('Only the new post209 visualization directory is authorized')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    outputs = [args.output_dir / ('PARTIAL223_FORTY_SEVEN_FOUR_LAYER_SNAPSHOT.' + extension) for extension in ('png', 'svg')]
    if any(p.exists() for p in outputs):
        raise FileExistsError('Fresh run223 plot outputs required')
    fig, axes = plt.subplots(1, 4, figsize=(18, 9.5), sharex=True, sharey=True)
    for ax, layer in zip(axes, LAYERS):
        for obstacle in scene['obstacles']:
            if layer not in obstacle['layers']:
                continue
            x, y = obstacle['center']['x'], obstacle['center']['y']
            if x < -11 or x > 10 or y < 2 or y > 29:
                continue
            if obstacle.get('shape', obstacle.get('type')) == 'circle':
                patch = Circle((x, y), obstacle['width'] / 2)
            else:
                patch = Rectangle((x - obstacle['width'] / 2, y - obstacle['height'] / 2), obstacle['width'], obstacle['height'])
                patch.set_transform(Affine2D().rotate_deg_around(x, y, obstacle.get('ccwRotationDegrees', 0)) + ax.transData)
            patch.set(facecolor='#d5d9de', edgecolor='none', alpha=.55, zorder=1)
            ax.add_patch(patch)
        fixed = [segment for t in scene['traces'] for segment in wire_segments(t, layer)]
        ax.add_collection(LineCollection(fixed, colors='#aab2bb', linewidths=.5, zorder=2))
        for trace in scene['traces']:
            for p in trace['route']:
                if p['route_type'] == 'via' and layer in p.get('layers', []):
                    ax.add_patch(Circle((p['x'], p['y']), p.get('via_diameter', .4572) / 2, fill=False, edgecolor='#a5adb6', linewidth=.45, zorder=2))
        for trace in bodies:
            color = COLORS.get(owner(trace), COLORS['ordinary'])
            ax.add_collection(LineCollection(wire_segments(trace, layer), colors=color, linewidths=1.15, zorder=4))
            for p in trace['route']:
                if p['route_type'] == 'via' and layer in p.get('layers', []):
                    ax.add_patch(Circle((p['x'], p['y']), p['via_diameter'] / 2, fill=False, edgecolor=color, linewidth=.9, zorder=5))
        for connection in pending:
            a, b = connection['pointsToConnect']
            ax.plot([a['x'], b['x']], [a['y'], b['y']], color='#d9a21b', linewidth=.85, alpha=.9, linestyle=(0, (4, 3)), zorder=3)
            label = {'source_trace_26': 'D12 pending', 'source_trace_30': 'DQM0 pending'}[connection['name']]
            ax.text((a['x'] + b['x']) / 2 + .12, (a['y'] + b['y']) / 2, label,
                    color='#9b6d03', fontsize=6, rotation=75, zorder=6,
                    bbox={'facecolor': 'white', 'edgecolor': 'none', 'alpha': .72, 'pad': .6})
        ax.add_patch(Rectangle((-7, 13), 14, 14, fill=False, edgecolor='#697386', linestyle='--', linewidth=.7))
        ax.add_patch(Rectangle((-5.01, 3.99), 12.42, 6.82, fill=False, edgecolor='#697386', linestyle='--', linewidth=.7))
        ax.text(-6.9, 26.35, 'AM3352', fontsize=8, color='#475467')
        ax.text(-4.9, 4.25, 'DDR3L', fontsize=8, color='#475467')
        ax.set(title={'top': 'Top', 'inner1': 'Inner1', 'inner2': 'Inner2', 'bottom': 'Bottom'}[layer],
               xlim=(-10.2, 9), ylim=(2.8, 28), aspect='equal', xlabel='X (mm)')
        ax.grid(alpha=.12)
    axes[0].set_ylabel('Y (mm)')
    fig.suptitle('G350 · Run223 partial candidate · 47 of 49 DDR paths', fontsize=15, weight='bold', y=.965)
    fig.text(.5, .083, 'Green: ordinary routes   |   Blue: DQS0   |   Orange: DQS1   |   Purple: CK   |   Yellow dashed: D12 / DQM0 pending',
             ha='center', fontsize=10)
    fig.text(.5, .044, 'Model checks: all47 physical + numeric joins PASS (223); critical6 + five APIs in both DQS1 views PASS (225).\nPartial47/49; matching pending. No fresh editable Source/Core, native, CAD or TI qualification; default unchanged; fabricationReady=false.',
             ha='center', fontsize=9, color='#475467')
    fig.subplots_adjust(top=.92, bottom=.13, wspace=.13)
    description = ('Hash-pinned run223 candidate SHA256 ' + CANDIDATE_SHA + '; partial47; actual225 critical evidence SHA256 ' + CRITICAL_SHA + '; fabricationReady=false; no fresh Source/Core/native/CAD/TI qualification.')
    fig.savefig(outputs[0], dpi=180, metadata={'Description': description})
    fig.savefig(outputs[1], metadata={'Date': None, 'Description': description})
    plt.close(fig)
    for output in outputs:
        print(str(output) + ' ' + hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
