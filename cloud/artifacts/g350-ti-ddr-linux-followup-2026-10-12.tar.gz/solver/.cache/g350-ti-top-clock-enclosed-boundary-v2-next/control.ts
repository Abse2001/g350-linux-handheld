import { runBoundedRouting } from "./source/lib/run-bounded-routing"

/** Record only original generator lifecycle; no Grid, checker or constructor
 * replacement. Explicit fake producer is confined to tests. */
export function captureOneOriginalJob(
  module: any,
  args: readonly unknown[],
  testOriginalOverride?: (...args: any[]) => Generator<any, any, any>,
) {
  const original = testOriginalOverride ?? module.routeCoupledPair
  const state = {
    originalFactories: 0,
    originalNextCalls: 0,
    originalReturnCalls: 0,
    originalThrowCalls: 0,
    naturalCompletion: false,
    originalTerminalMethod: null as string | null,
    chargedYields: 0,
    boundedDone: false,
    rawResult: null as any,
  }
  state.originalFactories++
  const work = Reflect.apply(original, undefined, [...args]) as Generator<
    any,
    any,
    any
  >
  const advance = (method: "next" | "return" | "throw", values: any[]) => {
    if (method === "next") state.originalNextCalls++
    else if (method === "return") state.originalReturnCalls++
    else state.originalThrowCalls++
    const result = Reflect.apply(work[method], work, values) as IteratorResult<
      any,
      any
    >
    if (result.done && state.originalTerminalMethod === null) {
      state.originalTerminalMethod = method
      state.naturalCompletion = method === "next"
      state.rawResult = result.value
    }
    return result
  }
  const observed: any = {
    next: (...values: any[]) => advance("next", values),
    return: (...values: any[]) => advance("return", values),
    throw: (...values: any[]) => advance("throw", values),
    [Symbol.iterator]() {
      return this
    },
  }
  const bounded = runBoundedRouting(observed, 6000)
  let completed = false
  try {
    while (true) {
      const result = bounded.next()
      if (result.done) {
        completed = true
        state.boundedDone = true
        state.rawResult = result.value
        break
      }
      state.chargedYields++
    }
  } finally {
    if (!completed) bounded.return(null)
  }
  return state
}
