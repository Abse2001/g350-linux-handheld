"""Read-only stdlib comparison of real raw declarations and already-run CAD output.
Never invokes a worker, KiCad, Node, CLI, Native, Source or SDK imports.
"""
import hashlib
import json
from pathlib import Path

BOARD = Path('/workspace/g350-linux-handheld')
CAD = BOARD / '.cloud-tools/ddr-clock-v11-fresh-kicad-baseline-diagnostic-sourceonly-next/run-cad'
INPUTS = [
    (BOARD / '.cloud-tools/ddr-clock-v11-manual-pair-source-successor-next/run-core/raw-core.json', '7793a13abbc457569cb15c1a9bc549ce585dbd75ac85acd6e384441557075c06'),
    (BOARD / '.cloud-tools/ddr-clock-v11-fresh-core-native-sourceonly-next/run-native/native18-report.json', '55f3b2a9629532e24d74ad3527e155d9491a921b7a6253a6e51d192597a2a159'),
    (BOARD / '.cloud-tools/ddr-clock-v11-export96-owned-topstub-lexical-diagnostic-next/REPORT.json', 'edaa0a6e182d2c5f760c6f88db2d4077f41d885578fe9043350fb761c8384a7f'),
    (CAD / 'output/baseline-report.json', 'c96541c82f98c6844c1c194e5eaa7e7f62277ae7ff9b214025c0c7e55c386fbd'),
    (CAD / 'POSTAUDIT.json', '8e938cabf3dea80b5fd97e8a92f94ddba0822ffdd7f37a6559734b499578fab9'),
    (Path('/workspace/bus-lanes-solver/.cache/root-routing-progress/clock-v11-baseline-cad-94957-COLLECTED-root.json'), '95c4462595710d909d90481bf7377416873f05bf79c6506920b682e9061620fa'),
    (CAD / 'output/actual-net-connectivity-observations.json', 'eaa24d221f4aa48f439f209d12f7a9adedac0f47a2a43b885f636a948aab4234'),
    (Path('/workspace/bus-lanes-solver/.cache/root-routing-progress/clock-v11-fresh-cli-owned-next/exports/clock-v11.kicad_pcb'), '540b9d2c5259a06e18f0be3706fe818fd86db444ed431ef7997c772998aa36d7'),
]

def require(value, reason):
    if not value:
        raise ValueError(reason)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load_bound(path, expected):
    require(path.is_file() and not path.is_symlink(), 'Concrete immutable input required')
    data = path.read_bytes()
    require(digest(data) == expected, 'Actual evidence hash changed: ' + str(path))
    return data

def main():
    before = [load_bound(path, expected) for path, expected in INPUTS]
    raw, native, lexical, cad, post, collected, observations = [json.loads(data) for data in before[:7]]
    require(cad['passed'] is True and cad['diagnosticCompleted'] is True and cad['allInputBytesHeld'] is True and cad['status'] == 'NARROW_FRESH_CLOCK_KICAD_NET_CONNECTIVITY_PASS', 'Actual narrow CAD child pass required')
    require(collected['toolSessionId'] == 94957 and collected['toolSessionCollected'] is True and collected['toolExitCode'] == collected['toolWrapperExitCode'] == 2 and collected['passed'] is False, 'Preserve actual rejected outer wrapper outcome')
    execution = post['execution']
    require(collected['execution'] == execution and execution['exitCode'] == 0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values()), 'Actual completed CAD child0 with empty/no-OOM scope required')
    require(post['passed'] is False and post['expectedNet0FailureObserved'] is False and post['diagnosticCompleted'] is True and post['sourceAndDependenciesHeld'] is True and post['ownedContainerRemoved'] is True, 'Preserve rejected expected-negative assumption and held resources')
    require(post['dependenciesBefore'] == post['dependenciesAfter'] and post['solverDependenciesBefore'] == post['solverDependenciesAfter'], 'Actual complete board/solver SDK inventories held')
    require(cad['signalObservations'] == observations['signalObservations'] and cad['actualClockObservations'] == observations['actualClockObservations'], 'Pre-assertion actual observations must agree with final narrow report')
    require(observations['passed'] is False and observations['signalViaNetMismatchCount'] == 0, 'Pre-assertion passed=false is initial state, not failed findings')
    owners = {row['actualViaId']: row for row in native['actualOwnershipProof']['signalMappings']}
    old = {row['actualViaId']: row for row in lexical['signalMappings']}
    actual = {row['actualViaId']: row for row in cad['signalObservations']}
    require(len(owners) == len(old) == len(actual) == 96 and set(owners) == set(old) == set(actual), 'Exactly the same authentic96 Source-owned signal barrels required')
    core_vias = {row['pcb_via_id']: row for row in raw if row['type'] == 'pcb_via'}
    compared = []
    for ident, owner in owners.items():
        before_row, after_row = old[ident], actual[ident]
        require(all(after_row[key] == value for key, value in owner.items()), 'Actual CAD ownership must retain every authenticated Source field')
        require(before_row['actualKiCadViaNetCode'] == 0 and after_row['actualViaNetCode'] == after_row['actualNumericPadNetCode'] == before_row['actualKiCadNumericPadNetCode'] > 0, 'Actual raw net0 declaration becomes the authentic numeric-pad net in native memory')
        require(after_row['actualViaNetName'] == after_row['actualNumericPadNetName'] == before_row['actualKiCadNumericPadNetName'], 'Actual Source numeric net names agree')
        require(after_row['nativeViaUuid'] == before_row['actualKiCadViaUuid'] and after_row['nativePadUuid'] == before_row['actualKiCadNumericPadUuid'] and after_row['nativeTopstubSegmentUuids'] == [row['uuid'] for row in before_row['actualKiCadTopstubSegments']], 'Original raw/native physical via/pad/Topstub UUID identities held')
        require(after_row['numericPadTopstubNetAgreement'] and after_row['viaNetMatchesActualNumericPadAndTopstub'] and after_row['nativePadConnectedToVia'] and after_row['nativePadConnectedToAllTopstubSegments'], 'Actual96 local numeric-pad/Topstub/barrel connections passed')
        require('pcb_trace_id' not in core_vias[ident] and 'source_net_id' not in core_vias[ident] and 'subcircuit_connectivity_map_key' not in core_vias[ident], 'Raw metadata was not repaired or rewritten')
        compared.append({**owner, 'originalRawKiCadViaNetCode': 0, 'actualPostLoadAndBuildConnectivityViaNetCode': after_row['actualViaNetCode'], 'actualNetName': after_row['actualViaNetName'], 'actualNumericPin': after_row['numericPin'], 'actualNumericOwnerName': after_row['numericSourceOwnerName'], 'rawAndNativeViaUuid': after_row['nativeViaUuid'], 'rawAndNativeNumericPadUuid': after_row['nativePadUuid'], 'allActualTopstubUuidsHeld': True, 'actualLocalPhysicalConnectivityPassed': True})
    require(cad['signalViaNetMismatchCount'] == cad['signalViaNetZeroCount'] == cad['referenceViaNetZeroCount'] == 0 and cad['numericPadTopstubAgreementCount'] == 96 and cad['physicalClockConnectedCount'] == 2, 'Exact actual96 local/2 complete clock counts required')
    require(cad['actualNativeInventory']['physicalVias'] == 225 and cad['actualNativeInventory']['segments'] == 461 and cad['actualNativeInventory']['footprintsIncluding225EmptyViaPlaceholders'] == 505 and cad['actualNativeInventory']['layers'] == ['F.Cu', 'In1.Cu', 'In2.Cu', 'B.Cu'] and cad['actualNativeInventory']['zoneFreeZones'] == 0, 'Exact actual fresh native inventory')
    require(all(clock['allOwnedClockCopperConnectedFromCpuPad'] and clock['actualRamPadConnectedFromCpuPad'] and clock['actualCpuPadNet'] == clock['actualRamPadNet'] > 0 and clock['actualBarrelNetCodes'] == [clock['actualCpuPadNet']] * 2 and all(net == clock['actualCpuPadNet'] for path in clock['actualPathSegmentNetCodes'] for net in path) for clock in cad['actualClockObservations']), 'Both actual complete three-path clocks and two real barrels each passed')
    require(all(load_bound(path, expected) == before[index] for index, (path, expected) in enumerate(INPUTS)), 'Every actual input byte remains held')
    report = {'scope': 'STDLIB_REVIEW_OF_ACTUAL94957_RAW_NET0_AND_NATIVE_NET_ASSIGNMENT', 'reviewPassed': True, 'inputBindings': [{'path': str(path), 'sha256': expected} for path, expected in INPUTS], 'actualCadChildExitCode': 0, 'actualNarrowCadChildPassed': True, 'actualOuterToolWrapperExitCode': 2, 'actualOuterPassed': False, 'originalOuterExpectedNegativeAssumptionMatched': False, 'outerFailureReason': 'The original wrapper required a net0 failure, while the actual CAD child passed. Its rejected outcome remains unchanged.', 'rawDeclaredSignalViaNetZeroCount': 96, 'actualPostLoadAndBuildConnectivitySignalViaNetZeroCount': 0, 'actualSourceOwnedNumericPadTopstubViaNetAgreementCount': 96, 'actualLocalPhysicalSignalApproachCount': 96, 'actualCompleteClockPathCount': 2, 'sourceOwnershipComparisons': compared, 'actualClocks': cad['actualClockObservations'], 'actualNativeInventory': cad['actualNativeInventory'], 'originalRaw7793AndExport540bHeld': True, 'actualCompleteSourceAndSdkInventoriesHeldByRoot': True, 'ownedProcessAndContainerClosed': True, 'assignmentPhasePreciselyInstrumented': False, 'phaseObservation': 'Nets and physical connectivity were observed after LoadBoard followed by BuildConnectivity; this run did not isolate which call assigned each net.', 'metadataViewAdapterAdoptedOrExecuted': False, 'netRepairNeededForThisObservedNarrowCadScope': False, 'newCadOrOtherApplicationCalls': 0, 'allRuleDrcPerformed': False, 'referenceQualified': False, 'globalDdrRoutesStillMissing': 47, 'electricalTimingQualified': False, 'accepted49': False, 'fabricationReady': False}
    output = Path(__file__).resolve().parent / 'REPORT.json'
    with output.open('x') as handle:
        json.dump(report, handle, indent=2)
        handle.write('\n')
    output.chmod(0o600)
    print(json.dumps({'reviewPassed': True, 'reportPath': str(output), 'reportSha256': digest(output.read_bytes()), 'rawDeclaredNetZero': 96, 'actualNativeNetZero': 0, 'actualCompleteClocks': 2, 'outerFailurePreserved': True, 'newApplicationCalls': 0}))

if __name__ == '__main__':
    main()
