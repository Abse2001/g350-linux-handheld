"""Pure stdlib explicit current12+Reset2 material; original225 helpers untouched.

New holes use standard native via-pad/drill rules, not a wire spacing waiver.
No real Source/Core/native/API/CAD application or reference qualification.
"""
from pathlib import Path
import importlib.util,json,math,copy,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;BASE=HERE.parent/'ddr-full49-cap19-owned32-owned4-jointpool-sourceonly-next'
s=importlib.util.spec_from_file_location('preserved225_context12',BASE/'material-one-context.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q);z,p,g=q.z,q.p,q.g
CONTEXT=HERE/'EMPTY49_CONTEXT12_PLUS_RESET2_227_MATERIAL_CONTEXT02.json';assert g.sha(CONTEXT)=='fb267b4917d1cc27b4fcf86331ddf7256105c65ce12f80d8c79d15ad0e6f2c28';context=json.loads(CONTEXT.read_text());assert context['physicalViaCount']==227 and context['carrierCount']==0
for key in ['baseline225ContextPin','full49NumericInputPin','full49CarrierInputPin','fullNativeContextPin','authenticSiteAndNumericLeadProofPin','resetVariableCandidatePoolPin','fullCoreGeometryHypothesisPin']:
 pin=context[key];assert g.sha(Path(pin['path']))==pin['sha256']
full,carrier,native=[json.loads(Path(context[k]['path']).read_text()) for k in ['full49NumericInputPin','full49CarrierInputPin','fullNativeContextPin']]
assert all(full[k]==carrier[k] for k in full if k!='connections')
assert full['connections']==q.full['connections'] and full['obstacles']==q.full['obstacles'] and full['traces'][:261]==q.full['traces'] and len(full['traces'])==263
assert native['referenceVias']==q.native['referenceVias'] and native['signalDogbones'][:96]==q.native['signalDogbones'] and len(native['signalDogbones'])==98
assert set(v['sourceTraceId'] for v in context['proposedVias'])=={'source_trace_10'} and len(context['proposedVias'])==2
connections={c['name']:c for c in carrier['connections']};addedBranches=context['addedTopBranches'];assert len(addedBranches)==2
for c in carrier['connections']:
 if c['name']!='source_trace_10':assert c==q.connections[c['name']]
def normalize(document):
 rows=document['records'];rows=list(rows.values()) if isinstance(rows,dict) else rows;assert isinstance(rows,list);out={};raw={}
 for row in rows:
  n=row['sourceTraceId'];assert n in connections and n not in out
  if n!='source_trace_10':r,o=q.normalize({'records':[row]});out.update(r);raw.update(o);continue
  assert row['role']=='DDR_RESET' and row['layer'] in ['inner1','inner2','bottom'];assert len(row['path'])>=2
  path=[(v['x'],v['y']) if isinstance(v,dict) else tuple(v) for v in row['path']];assert all(len(v)==2 and all(type(t)in(int,float)and math.isfinite(t)for t in v)for v in path)
  endpoints=[(v['x'],v['y'])for v in connections[n]['pointsToConnect']];assert math.dist(path[0],endpoints[0])<1e-8 and math.dist(path[-1],endpoints[-1])<1e-8
  out[n]={'layer':row['layer'],'path':path};raw[n]=copy.deepcopy(row)
 return out,raw
class Scene(q.Scene):
 def __init__(self,layer,records,target,reservedRegions=()):
  super().__init__(layer,records,target,reservedRegions)
  self.full,self.carrier=full,carrier;self.terminals['source_trace_10']=[(v['x'],v['y'])for v in context['proposedVias']]
  for via in context['proposedVias']:
   x,y=via['x'],via['y'];r=.4572/2+.1016/2+full['minTraceToPadEdgeClearance'];self.add({'kind':'circle','p':(x,y),'r':r,'owners':{'source_trace_10'},'id':via['proposedViaId'],'bbox':(x-r,x+r,y-r,y+r)});self.counts['signalFullSpanBarrels']+=1
  assert self.counts['signalFullSpanBarrels']==98
  if layer=='top':
   for trace in addedBranches:
    wires=[v for v in trace['route']if v['route_type']=='wire'and v['layer']=='top'];assert len(wires)==2;a,b=[(v['x'],v['y'])for v in wires];required=p.normal_spacing(target,'source_trace_10',self.byclass,self.mates);self.segment(a,b,required,{'source_trace_10'},trace['pcb_trace_id']);item=self.items[-1];item.update(ddrOwner='source_trace_10',localPieces=p.circlesplit(a,b,self.terminals['source_trace_10']))
 def exposure(self,path,name):
  # Equivalent exact interval union, with every layer scene reconstructed from
  # this literal227 context (never the original helper's96-barrel constructor).
  pieces=[('new-main',i,a,b,self.layer)for i,(a,b)in enumerate(g.pairs(path))]
  for trace in full['traces']:
   if trace.get('source_trace_id')!=name:continue
   for i,(a,b)in enumerate(zip(trace['route'],trace['route'][1:])):
    if a['route_type']==b['route_type']=='wire'and(a['x'],a['y'])!=(b['x'],b['y']):pieces.append((trace['pcb_trace_id'],i,(a['x'],a['y']),(b['x'],b['y']),a['layer']))
  scenes={self.layer:self};reports=[];total=0.;noneligibleDeficit=0.
  for branch,i,a,b,layer in pieces:
   if layer not in scenes:scenes[layer]=Scene(layer,self.records,name)
   scene=scenes[layer];eligible=[];ineligible=[]
   for item in scene.items:
    if name in item['owners']or'ddrOwner'not in item or scene.pair_is_intrinsic(item['ddrOwner']):continue
    intervals=p.capsule_intervals(a,b,item['a'],item['b'],item['r']-1e-10)
    (eligible if scene.eligible(item['ddrOwner'])else ineligible).extend(intervals)
   union=p.merge(eligible);mm=sum((hi-lo)*math.dist(a,b)for lo,hi in union);total+=mm
   normalUnion=p.merge(ineligible);normalMm=sum((hi-lo)*math.dist(a,b)for lo,hi in normalUnion);noneligibleDeficit+=normalMm
   reports.append({'branch':branch,'segment':i,'layer':layer,'normalDeficitParameterUnion':union,'normalDeficitLengthMm':mm,'nonEligibleNormalDeficitParameterUnion':normalUnion,'nonEligibleNormalDeficitLengthMm':normalMm})
  return {'exactNormalDeficitUnionLengthMm':total,'includesImmutableOriginalTopStubsAndNewOwnedResetBranches':True,'absoluteTICapMm':31.75,'absoluteTICapPass':total<=31.75+1e-8,'nonEligibleNormalDeficitLengthMm':noneligibleDeficit,'noResetOrIntrinsicPairSpacingException':noneligibleDeficit<=1e-8,'segments':reports,'reciprocalOtherConductorAuditRequired':True}
