"""Own stdlib geometry planner, prospective26 context; no application imports."""
import collections,heapq,json,math,pathlib,sys,time,hashlib
sys.path.insert(0,'/tmp/g350-source24-remaining-nonpair-peer-planner-next');import scalar_plan as g
ROOT=pathlib.Path(__file__).resolve().parent;CLASSES={n:b['busId']for b in g.MODEL['buses']for n in b['connectionNames']}
cp=pathlib.Path('/tmp/g350-source3-moved135-inner1-geometry-sourceonly-next/SOURCE3_MOVED135_INNER1_PROPOSAL.json');rp=pathlib.Path('/tmp/g350-reset-after-joint24-candidate-next/RESET_TRACE_PROPOSAL.json');assert g.sha(cp)=='413a1fccacc1d59c65064add218f93b3a324965f4e6426ae490e8fb12b3502fd'and g.sha(rp)=='29c5903c1047c114314cd004fedd57d4e60b120db157743a73cbb68d3ab436f2';C=json.loads(cp.read_bytes());R=json.loads(rp.read_bytes())
PRIMS=[p for p in g.PRIMITIVES if p['id']!='pcb_via_135'and not p['id'].startswith('pcb_trace_239:')]
def segment(path,layer,owner,prefix):
 for i,(a,b)in enumerate(zip(path,path[1:])):
  a,b=tuple(a),tuple(b);r=g.WIDTH/2;PRIMS.append(dict(kind='segment',geom=(a,b),rad=r,layers=[layer],owners={owner},id=f'{prefix}:{i}',bbox=(min(a[0],b[0])-r,min(a[1],b[1])-r,max(a[0],b[0])+r,max(a[1],b[1])+r)))
x,y=C['existingCpuBarrelMove']['toXY'];rad=.2286;PRIMS.append(dict(kind='circle',geom=(x,y),rad=rad,layers=g.LAYERS,owners={'source_trace_3','pcb_via_135'},id='planned_moved_pcb_via_135',bbox=(x-rad,y-rad,x+rad,y+rad)))
segment(C['cpuTopStubPoints'],'top','source_trace_3','planned26_source3_cpu_top');segment(C['inner1CarrierPoints'],'inner1','source_trace_3','planned26_source3_i1');segment([g.xy(p)for p in R['geometryOnly']['route']],'bottom','source_trace_10','planned26_reset_bottom')

def distance(a,b,p):
 if p['kind']=='segment':return g.segdist(a,b,*p['geom'])
 if p['kind']=='circle':return g.point_segment(p['geom'],a,b)
 return g.rectdist(a,b,p['geom'])
def required(p,name,ti=True):
 hard=p['rad']+g.MARGIN
 if ti and p['kind']=='segment':
  cls=CLASSES.get(next(iter(p['owners'])))
  if cls:return max(hard,g.WIDTH*(3 if cls==CLASSES[name]else 4))
 return hard

def setup(layer,name,ti=True):
 objects=[p for p in PRIMS if layer in p['layers']and name not in p['owners']];buckets=collections.defaultdict(set)
 for i,p in enumerate(objects):
  x0,y0,x1,y1=p['bbox'];extra=required(p,name,ti)-p['rad']
  for x in range(math.floor(x0-extra),math.floor(x1+extra)+1):
   for y in range(math.floor(y0-extra),math.floor(y1+extra)+1):buckets[x,y].add(i)
 def clear(a,b):
  ids=set()
  for x in range(math.floor(min(a[0],b[0])),math.floor(max(a[0],b[0]))+1):
   for y in range(math.floor(min(a[1],b[1])),math.floor(max(a[1],b[1]))+1):ids.update(buckets[x,y])
  return all(distance(a,b,objects[i])>=required(objects[i],name,ti)+1e-8 for i in ids)
 return clear,objects

def search(name,layer,step=.1,cap=90000,ti=True):
 clear,obs=setup(layer,name,ti);start,goal=map(g.xy,g.CONNECTIONS[name]['pointsToConnect']);a,z=[tuple(round(x/step)for x in p)for p in(start,goal)];ends=[]
 for side,p in enumerate((start,goal)):
  m=min((distance(p,p,r)-required(r,name,ti),r['id'])for r in obs);ends.append(dict(side=side,minimumSlackMm=m[0],primitive=m[1]))
  if not clear(p,p):return dict(name=name,layer=layer,step=step,ti=ti,termination='ENDPOINT_BLOCKED',endpoints=ends)
 def point(n):return n[0]*step,n[1]*step
 def h(n):
  dx,dy=abs(n[0]-z[0]),abs(n[1]-z[1]);return step*(max(dx,dy)+(math.sqrt(2)-1)*min(dx,dy))
 heap=[(h(a),0.,a)];cost={a:0.};parent={};edge={};expanded=0;begin=time.monotonic()
 while heap and expanded<cap:
  _,c,n=heapq.heappop(heap)
  if c!=cost.get(n):continue
  if n==z:
   points=[goal];v=n
   while v!=a:v=parent[v];points.append(point(v))
   points[-1]=start;points.reverse();points=g.simplify(points)
   return dict(name=name,layer=layer,step=step,ti=ti,termination='FOUND',expanded=expanded,seconds=time.monotonic()-begin,points=points,carrierMm=g.plen(points),wholeMm=g.plen(points)+g.STUB_LENGTH[name],endpoints=ends)
  expanded+=1
  for dx,dy in((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
   v=(n[0]+dx,n[1]+dy)
   if not(-10.5<=v[0]*step<=10.5 and-2<=v[1]*step<=20):continue
   le=c+step*(math.sqrt(2)if dx and dy else 1)
   if le>=cost.get(v,math.inf)-1e-12:continue
   key=tuple(sorted((n,v)))
   if key not in edge:edge[key]=clear(point(n),point(v))
   if not edge[key]:continue
   cost[v]=le;parent[v]=n;heapq.heappush(heap,(le+h(v),le,v))
 return dict(name=name,layer=layer,step=step,ti=ti,termination='CAP'if heap else'EXHAUSTED_FINITE_LOCAL_GRID',expanded=expanded,seconds=time.monotonic()-begin,endpoints=ends)

def save(name,d):
 p=ROOT/name
 with p.open('x')as f:json.dump(d,f,indent=2);f.write('\n')
 p.chmod(0o600)
if __name__=='__main__':
 results=[]
 for name in ['source_trace_17','source_trace_30','source_trace_32','source_trace_42','source_trace_43']:
  r=search(name,'inner1');results.append(r);print(json.dumps(r),flush=True)
 for name in ['source_trace_6','source_trace_7','source_trace_20','source_trace_21','source_trace_23','source_trace_25','source_trace_35','source_trace_36','source_trace_37','source_trace_38','source_trace_39','source_trace_44','source_trace_45','source_trace_47','source_trace_0','source_trace_18','source_trace_19','source_trace_22']:
  r=search(name,'bottom');results.append(r);print(json.dumps(r),flush=True)
 save('JOINT26_BYTE0_I1_CA_BOTTOM_FINITE_RANKING.json',dict(scope='OWN_SCALAR_JOINT_TO_PROSPECTIVE26_NOT_ACTUAL_ACCEPTANCE',source3=cached if False else str(cp),reset=str(rp),results=results,globalInfeasibilityClaimed=False))
