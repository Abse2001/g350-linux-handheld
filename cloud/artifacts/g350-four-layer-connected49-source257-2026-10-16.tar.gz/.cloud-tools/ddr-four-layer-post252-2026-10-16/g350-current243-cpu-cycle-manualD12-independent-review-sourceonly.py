"""Independent pure-JSON binding/geometry review; never loads SDK/native/Core.
Cap8 relocation and both reference paths remain explicitly unproved here.
"""
exec(open('/tmp/g350-generic-focus-static-helper.py').read())
P='/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json';PIN='cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
R='/tmp/g350-current243-cpu-cycle42A16-11SW-2NE-joint-planning-screen-report.json';RPIN='4737965e5e21b45f642bde94a47c3dfc81150d649dbfd45b1f3a7c06267326ec'
D='/tmp/g350-current243-cpu-cycle-manualD12-R12-795-joint-report.json';DPIN='fd5bd7580826a378215c9d9a7cbc6e10857df90ad5b23077f60a9e10efa1d6e7'
def read(path,pin):
 b=Path(path).read_bytes();assert hashlib.sha256(b).hexdigest()==pin;return json.loads(b)
p=read(P,PIN);r=read(R,RPIN);d=read(D,DPIN);own=lambda t:t.get('connection_name') or t.get('source_trace_id');clone=lambda v:json.loads(json.dumps(v));xy=lambda q:dict(zip(('x','y'),q))
f=clone(p['full49FanoutInput']);bodies=clone(p['carrierTraces']);inverses=[r['body'+str(n)+'Inverse'] for n in (2,11,35,42)]
for inv in inverses:
 i=next(i for i,t in enumerate(bodies) if own(t)==own(inv['before']));assert bodies[i]==inv['before'];assert own(inv['after'])==own(inv['before']);bodies[i]=inv['after']
for inv in r['cpuFanoutInverses']:
 i=next(i for i,t in enumerate(f['traces']) if t['pcb_trace_id']==inv['before']['pcb_trace_id']);assert f['traces'][i]==inv['before'];f['traces'][i]=inv['after'];assert inv['before']['route'][0]==inv['after']['route'][0]
e=d['endpointInverse'];assert f['connections'][e['connection']['index']]==e['connection']['before'];f['connections'][e['connection']['index']]=e['connection']['after']
for inv in e['branches']:assert f['traces'][inv['index']]==inv['before'];f['traces'][inv['index']]=inv['after']
assert sorted(own(t) for t in bodies)==sorted(own(t) for t in p['carrierTraces']) and len(bodies)==48
assert len({own(t) for t in bodies}|{own(d['manualD12Carrier'])})==49
assert f['obstacles']==p['full49FanoutInput']['obstacles'] and len(f['obstacles'])==1298
raw=json.load(open('/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json'))
for id,pos in [('pcb_port_63',(.4,15.6)),('pcb_port_375',(4.8,5.8))]:
 port=next(q for q in raw if q.get('type')=='pcb_port' and q.get('pcb_port_id')==id);assert math.dist((port['x'],port['y']),pos)<1e-8
g=focus(26,P,PIN);removed={inv['before']['pcb_trace_id'] for inv in inverses+r['cpuFanoutInverses']};g['objects'][:]=[o for o in g['objects'] if o['id'] not in removed]
for inv in inverses+r['cpuFanoutInverses']:
 for obj in g['mats'](inv['after']):
  obj={**obj,'owner':own(inv['after']),'id':inv['after']['pcb_trace_id']};obj['bbox']=g['bbox'](obj);g['objects'].append(obj)
wireHits=[];viaHits=[];t=d['manualD12Carrier'];route=t['route'];bodylen=0
for i,q in enumerate(route):
 if q['route_type']=='via':
  assert q['via_diameter']==.4572 and q['via_hole_diameter']==.254 and set(q['layers'])=={'top','inner1','inner2','bottom'}
  hs=g['viaContacts'](q);viaHits.append({'index':i,'xy':[q['x'],q['y']],'contacts':[(a['owner'],a['id'],a.get('index',-1)) for a in hs]})
 elif i and route[i-1]['route_type']=='wire' and route[i-1]['layer']==q['layer']:
  a=route[i-1];bodylen+=math.dist((a['x'],a['y']),(q['x'],q['y']));hs=g['wireContacts'](a,q,q['layer'])
  if hs:wireHits.append({'index':i,'contacts':[(a['owner'],a['id'],a.get('index',-1)) for a in hs]})
def length(t):return sum(math.dist((a['x'],a['y']),(b['x'],b['y'])) for a,b in zip(t['route'],t['route'][1:]) if a['route_type']=='wire' and b['route_type']=='wire' and a['layer']==b['layer'])
cpuFanout=sum(length(inv['after']) for inv in e['branches']);whole=cpuFanout+bodylen;assert abs(whole-d['wholePlanarLengthMm'])<1e-10 and 12.907653789032027<whole<14.177653789032021
assert not wireHits and len(viaHits)==2 and not any(q['contacts'] for q in viaHits)
out={'scope':'INDEPENDENT_PURE_JSON_D12_BINDING_AND_FOREIGN_GEOMETRY_REVIEW_CAP8_REFERENCES_STILL_PENDING_NO_SDK','inputSha256':PIN,'jointProofSha256':RPIN,'manualD12ProofSha256':DPIN,'actualNumericPortsUnchanged':['pcb_port_63','pcb_port_375'],'allFourChangedOrdinaryBodyBeforeObjectsExact':True,'cpu2And11NumericFirstPointsExact':True,'foundation1298ObstaclesAndAll49RulesUnchanged':True,'wholePlanarLengthMm':whole,'wholeLengthWindowMm':[12.907653789032027,14.177653789032021],'wholeMinimumSlackMm':whole-12.907653789032027,'wholeMaximumSlackMm':14.177653789032021-whole,'foreignWireContacts':wireHits,'newFullspanViaReports':viaHits,'originalCritical6Held':True,'cap8OverlayPending':True,'nativeOwnSelfTerminalCriticalSourceCadPending':True,'all49Accepted':False,'fabricationReady':False}
O='/tmp/g350-current243-cpu-cycle-manualD12-independent-review-report.json';Path(O).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'output':O,'sha256':hashlib.sha256(Path(O).read_bytes()).hexdigest(),'whole':whole,'wireHits':wireHits,'viaHits':viaHits},indent=2))
