 def inspect32_capture(paths):
  capture,diagnostic=paths['capture'],paths['diagnostic'];r=read_bounded(capture,5242880);d=read_bounded(diagnostic,7340032)
  assert r['scope']=='ACTUAL_ROOT_SOURCE32_CAPTURE_WITH_PARENT29_FULL_INVERSE'and d['scope']=='ACTUAL_SOURCE32_AND_PARENT29_BEFORE_INVERSE_ASSERTIONS'
  for key in('passed','fullInverseSourceTreePassed','all227ExistingViasAnd29PriorRoutesHeld','all98NumericBranchesAnd49LogicalOwnersHeld','original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse','pureSourceEvaluationExecuted','automaticCoreSrjForThisForkMustNotBeUsed','bothDqs1CoupledViewsRequireFreshOriginalApi'):assert r[key]is True
  for key,value in dict(proposedReactElementCount=2286,previousReactElementCount=2278,genuineNewInnerPortCount=52,exactNewPortDeclarations=6,exactChangedOriginalRouteDeclarations=3,exactChangedLocalSuppressions=6,exactMovedExistingViaCount=0,exactAddedIntermediateCarrierViaCount=2,expectedPhysicalVias=229,expectedPhysicalTraces=297,expectedCarrierPaths=32,expectedPhysicalCarrierBodyPaths=34,missingOriginal49RequestsExpected=17).items():assert r[key]==value
  assert r['newViaRole']=='REMOVABLE_CARRIER_NOT_FIXED_FANOUT'and r['sourceOnlyProposalSha256']==proposal['promoted32ProposalPin']['sha256']
  assert r['actualDiagnosticPath']==str(diagnostic)and r['actualDiagnosticSha256']==sha(diagnostic)and r['actualSourceTree']==d['actualProposedSource32Tree']
  assert r['actualParent29CapturePin']==proposal['actual53CapturePin']
  assert d['actualParent29Tree']==read(proposal['actual53CapturePin']['path'])['actualSourceTree']
  assert d['beforeCounts']['reactElements']==2278 and d['afterCounts']['reactElements']==2286 and d['beforeCounts']['unsupported']==d['afterCounts']['unsupported']==0 and d['inverseChecksExecuted']is False
  for key in('circuitConstructed','coreRendered','all49Accepted','fabricationReady'):assert r[key]is d[key]is False
  for key in('source29QualificationInherited','nativeExecuted','cadExecuted','singleCoupledSectionCoversBoth','referenceQualified','electricalTimingPassed'):assert r[key]is False
  return dict(sourceCapturePin=file_row(capture),sourceDiagnosticPin=file_row(diagnostic),fullSourceInversePassed=True,CoreExecuted=False)

 def inspect32_core(paths,capture_pin):
  raw,controls=paths['raw'],paths['controls'];core=read_bounded(raw,16777216);r=read_bounded(controls,4194304)
  assert isinstance(core,list)and r['scope']=='ROOT_FRESH_EDITABLE_SOURCE_CORE_229_SOURCE20_SOURCE21_INTERMEDIATE_VIAS_AND_SOURCE45_32'
  assert r['rawCorePath']==str(raw)and r['rawCoreSha256']==sha(raw)and r['actualCapturePath']==capture_pin['path']and r['actualCaptureSha256']==capture_pin['sha256']
  assert r['freshCoreControlPassed']is True and len(r['checks'])==29 and all(x['passed']is True for x in r['checks'])
  expected={'source_component':280,'source_trace':1195,'pcb_component':509,'pcb_smtpad':1161,'pcb_plated_hole':4,'pcb_hole':2,'pcb_via':229,'source_manually_placed_via':229,'pcb_trace':297,'source_port':1671,'pcb_port':1671,'source_net':98,'source_bus':8,'pcb_keepout':2}
  for kind,count in expected.items():assert sum(row['type']==kind for row in core)==count
  assert len(r['carriers'])==32 and all(x['passed']is True for x in r['carriers'])and len(r['signalTopProjection'])==98 and all(x['passed']is True for x in r['signalTopProjection'])
  assert len(r['original49Projection'])==49 and all(x['passed']is True for x in r['original49Projection'])and len(r['viaProjection'])==229 and all(x['passed']is True for x in r['viaProjection'])
  assert len(r['actualSourcePortMatches']['registrations'])==52 and r['expectedOriginalCarrierCount']==32 and r['expectedMissingOriginalSignalCount']==17 and r['actualNonzeroWireSegmentCount']==1116
  assert r['all29PriorCarrierGeometryHeldByExactSourceInverse']is r['source20And21ExactFourPathArchitectureOnly']is True
  mids=r['explicitIntermediateCarrierViaProjection'];assert len(mids)==2 and {x['sourceViaName']for x in mids}=={'V_TI_SIGNAL_INTERMEDIATE_source_trace_20_0','V_TI_SIGNAL_INTERMEDIATE_source_trace_21_0'}
  assert all(x['passed']is True and x['carrierOwned']is True and x['reference']is False for x in mids)
  mid_ids={x['actualViaId']for x in mids};assert len(mid_ids)==2
  for row in core:
   if row['type']=='pcb_via'and row['pcb_via_id']in mid_ids:assert row['layers']==['top','inner1','inner2','bottom']and row['from_layer']=='top'and row['to_layer']=='bottom'and row['outer_diameter']==.4572 and row['hole_diameter']==.254
  body_ids=[]
  for carrier in r['carriers']:
   mixed=carrier['originalSourceTraceId']in('source_trace_20','source_trace_21')
   assert len(carrier['actualDirectPcbTraceIds'])==(4 if mixed else 3)and len(set(carrier['actualDirectPcbTraceIds']))==len(carrier['actualDirectPcbTraceIds'])
   if mixed:
    assert carrier['carrierArchitecture']=='TWO_LAYER_ONE_OWNED_INTERMEDIATE_VIA'and carrier['physicalFullThroughBarrels']==3 and len(carrier['actualCarrierPcbTraceIds'])==2 and len(carrier['actualRemovableCarrierViaIds'])==1 and carrier['actualRemovableCarrierViaIds'][0]in mid_ids
    assert carrier['actualSourceOwnedPhysicalGraph']['physicallyConnected']is carrier['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is carrier['intermediateViaIsNotFixedFanout']is True
    body_ids.extend(carrier['actualCarrierPcbTraceIds'])
   else:body_ids.append(carrier['actualCarrierPcbTraceId'])
  assert len(body_ids)==len(set(body_ids))==34
  event=r['source3OwnerEvent'];assert event['sourceViaName']=='V_TI_SIGNAL_source_trace_3_0'and event['capturedPriorViaIdProvenanceOnly']=='pcb_via_135'and event['freshIdsDerivedFromActualCore']is True and event['capturedIdAssignedToFreshCore']is False
  vp=event['actualViaProjection'];sp=event['actualTopStubProjection'];cc=event['actualCarrierProjection'];assert vp['passed']is sp['passed']is cc['passed']is True and sp['originalSourceTraceId']==cc['originalSourceTraceId']=='source_trace_3'and sp['side']==0
  for name,x,y,vertices,side,owner in [('V_TI_SIGNAL_source_trace_3_0',6.2,12.4,4,0,'source_trace_3'),('V_TI_SIGNAL_source_trace_7_1',-7.4,7.8,13,1,'source_trace_7')]:
   v=[x for x in r['viaProjection']if x['sourceViaName']==name];s=[x for x in r['signalTopProjection']if x['originalSourceTraceId']==owner and x['side']==side];assert len(v)==len(s)==1 and v[0]['passed']is s[0]['passed']is True
   actual=[p for p in core if p['type']=='pcb_via'and p['pcb_via_id']==v[0]['actualViaId']];assert len(actual)==1 and abs(actual[0]['x']-x)<1e-8 and abs(actual[0]['y']-y)<1e-8 and actual[0]['layers']==['top','inner1','inner2','bottom']and actual[0]['outer_diameter']==.4572 and actual[0]['hole_diameter']==.254
   stub=[p for p in core if p['type']=='pcb_trace'and p['pcb_trace_id']==s[0]['actualPcbTraceId']];assert len(stub)==1 and len(stub[0]['route'])==vertices and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in stub[0]['route'])
  for key in('sourceNumericAndPhysicalIdsDerivedWithoutAssignment','pcbRoutingDisabled','authoredPourLiteralsHeldByActualSourceInverse','manualPairSourceBusForkHeld','automaticCoreSrjForThisForkMustNotBeUsed','originalCouplingApisRequiredAgainstFreshActualGeometry'):assert r[key]is True
  for key in('circuitJsonGeometryEdited','parent29ActualQualificationInherited','nativeExecuted','cadExecuted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert r[key]is False
  return dict(rawCorePin=file_row(raw),coreControlsPin=file_row(controls),all29CorePredicatesPassed=True,actualCandidateCarrierCount=32,actualCarrierWireBodyCount=34,actualPhysicalViaCount=229,nativeQualificationPerformed=False)

