// SOURCE ONLY. Exact actual223 47 held carriers remain literal. Missing
// DQM0/source30 actualRAMball(4,5.8) rotates NW(3.6,6.2) to the genuine empty
// SEcell(4.4,5.4), with one exact RAMbranch/request inverse. CPU30 staysSE.
// Fresh47 and actualRAM native/Topstub/fullspan preflight precede only30
// four-layer search. Numeric pin map and all original timing/physical rules stay.
import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {pathToFileURL} from 'node:url'
type R=Record<string,any>
const ROOT='/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib/'
const RAW='/tmp/g350-deterministic-manual47-root-20261016-run223/byte0-result.candidate.json',PIN='ddaa4efd8d20f16cefca89b9166e834a956113194beed6f0f13903e346e36ea0'
const CTOR='/tmp/g350-manual223-root-profile224/constructor.json',CTOR_PIN='a187d46e6c71333476f93819ad3852988d708ae1c4f173a14a32a956a9d4a7d6'
const RAW_CORE='/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json',RAW_CORE_PIN='d2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607'
const QUALIFIER='/tmp/g350-mixed-carrier-physical-four-vias-sourceonly.ts'
const QUALIFIER_PIN='cdea6326a318b332ba98bb74bb1c8fd52c3b757bde34d75402558bd6dc86623f'
const ENDPOINTS='/tmp/g350-native-top-or-barrel-endpoints-ripup-sourceonly.ts',ENDPOINTS_PIN='f737af519a0dbc4bde8edeced01fc5526284b16affa6949e973eb609c9fe8a45'
const SPARSE='/tmp/g350-bounded-sparse-state-store-sourceonly.ts',SPARSE_PIN='6eca0efdc6c97f459e6f4dffd8da8a6826d5fa3f760fcd6a40239eeb5f78db7f'
const L=['top','inner1','inner2','bottom'],STEP=.01016,VD=.4572,HD=.254,W=.1016
const req=(v:any,m:string)=>{if(!v)throw Error(m)},clone=<T>(x:T):T=>structuredClone(x),same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b),near=(a:R,b:R)=>Math.hypot(a.x-b.x,a.y-b.y)<1e-8
const owner=(t:R)=>t.connection_name??t.source_trace_id,sha=(b:any)=>createHash('sha256').update(b).digest('hex')
const planar=(t:R)=>t.route.slice(1).reduce((s:number,b:R,i:number)=>{const a=t.route[i];return s+(a.route_type==='wire'&&b.route_type==='wire'&&a.layer===b.layer?Math.hypot(b.x-a.x,b.y-a.y):0)},0)
const args=new Map<string,string>();for(let i=2;i<process.argv.length;i+=2){const k=process.argv[i],v=process.argv[i+1];req(['--input','--input-sha','--constructor','--output','--budget-ms','--case-ms','--max-expansions','--max-vias','--max-labels','--constructor-sha'].includes(k)&&v&&!args.has(k),'Invalid CLI '+k);args.set(k,v)}
const profilePin=args.get('--constructor-sha')??CTOR_PIN
const inputPath=path.resolve(args.get('--input')??RAW),inputPin=args.get('--input-sha')??PIN,ctorPath=path.resolve(args.get('--constructor')??CTOR),out=path.resolve(args.get('--output')??''),budget=Number(args.get('--budget-ms')??165000),perCase=Number(args.get('--case-ms')??6000),maxExpanded=Number(args.get('--max-expansions')??2000000),maxVias=Number(args.get('--max-vias')??4),maxLabels=Number(args.get('--max-labels')??4000000)
req(['--input','--input-sha','--constructor','--constructor-sha'].every(k=>args.has(k)),'Explicit current input and reviewed constructor paths/hashes required')
req(args.has('--output')&&!fs.existsSync(out)&&![inputPath,ctorPath,RAW_CORE,QUALIFIER,ENDPOINTS].includes(out),'Separate fresh output required')
req(budget>=1000&&budget<=170000&&perCase>=100&&perCase<=20000&&Number.isInteger(maxExpanded)&&maxExpanded>=1000&&maxExpanded<=2000000,'Finite time/state budgets required')
req([3,4].includes(maxVias)&&Number.isInteger(maxLabels)&&maxLabels>=1000&&maxLabels<=8000000,'Finite 3/4-via and sparse-label budgets required')
const read=(p:string,pin:string)=>{const b=fs.readFileSync(p);req(sha(b)===pin,'Pinned public input changed '+p);return JSON.parse(b.toString())}
req(/^[0-9a-f]{64}$/.test(profilePin),'Exact reviewed constructor SHA required')
req(/^[0-9a-f]{64}$/.test(inputPin),'Exact public current scene hash required')
const bun=(globalThis as any).Bun;req(typeof bun?.gc==='function','Bun full GC required between completed search cases')
const packet=read(inputPath,inputPin),constructor=read(ctorPath,profilePin),rawCore:R[]=read(RAW_CORE,RAW_CORE_PIN)
req(sha(fs.readFileSync(QUALIFIER))===QUALIFIER_PIN,'Reviewed independent mixed qualifier source required')
req(sha(fs.readFileSync(ENDPOINTS))===ENDPOINTS_PIN,'Reviewed genuine numeric Top endpoint-menu source required')
req(sha(fs.readFileSync(SPARSE))===SPARSE_PIN,'Reviewed bounded sparse state-store source required')
req(inputPin===PIN&&profilePin===CTOR_PIN,'Exact actual223 plus reviewed224 constructor required');const base:R=clone(packet.full49FanoutInput),held:R[]=clone(packet.heldCarrierTraces),parentCaptured:R[]=clone(packet.ordinaryCarrierTraces),captured:R[]=clone(parentCaptured),rules:R[]=clone(constructor.input.buses)
const critical=new Set(held.map(owner)),ordinary=base.connections.filter((c:R)=>!critical.has(c.name)),missing=ordinary.filter((c:R)=>!captured.some(t=>owner(t)===c.name)).map((c:R)=>c.name)
req(base.connections.length===49&&base.traces.length===263&&base.obstacles.length===1298&&held.length===6&&captured.length>=33&&captured.length<=43&&missing.length===43-captured.length,'Current coherent partial49 inventory')
req(new Set([...held,...captured].map(owner)).size===held.length+captured.length&&captured.every(t=>ordinary.some((c:R)=>c.name===owner(t))),'Unique current ordinary and critical owners')
req(base.layerCount===4&&same(base.allowedLayers,L)&&base.minTraceWidth===W&&base.minTraceToPadEdgeClearance===W&&base.minViaDiameter===VD&&base.minViaHoleDiameter===HD&&base.allowBlindAndBuriedVias===false,'Original physical stack and dimensions')
req(same(base,constructor.full49FanoutInput)&&same(held,constructor.heldCarrierTraces),'Actual current full foundation and six critical carriers must equal the explicit reviewed constructor profile')
req(constructor.profile?.sourcePacketSha256===inputPin&&same(base.buses,constructor.originalRules?.buses)&&same(base.differentialPairs,constructor.originalRules?.differentialPairs),'Reviewed constructor must bind this exact input SHA and preserve literal original rules')
req(base.differentialPairs.length===3&&base.differentialPairs.every((p:R)=>p.lengthTolerance===.127&&p.traceGap===.12)&&base.buses.find((b:R)=>b.busId==='DDR_BYTE0').maxLength===11.8&&base.buses.find((b:R)=>b.busId==='DDR_BYTE1').maxLength===14.2&&base.buses.find((b:R)=>b.busId==='DDR_COMMAND_CLOCK').minLength===20.95&&base.buses.find((b:R)=>b.busId==='DDR_COMMAND_CLOCK').maxLength===22.29,'All original limits retained')
const frozen=JSON.stringify({base,held,parentCaptured}),started=performance.now(),stem=out.endsWith('.json')?out.slice(0,-5):out,retained:R[]=[],rawCandidates:R[]=[]
let working=clone(base)
const releasedWorkingBranchMaterial:R[]=clone(packet.releasedWorkingBranchMaterial??[])
const report:R={scope:'ACTUAL223_MISSING30_RAM_SE_KEEP_CPU_SE_ALL47_PREFLIGHT_THEN_FOUR_LAYER_SEARCH',inputPath,inputSha256:inputPin,constructorPath:ctorPath,constructorSha256:profilePin,qualifierSourceSha256:sha(fs.readFileSync(QUALIFIER)),endpointMenuSourceSha256:ENDPOINTS_PIN,sparseStoreSourceSha256:SPARSE_PIN,gridStepMm:STEP,maximumCellsPerLayer:2000000,maximumNewThroughViasPerOwner:maxVias,maxExpanded,maxLabels,attempts:[],retained:[],rawCandidatesPath:stem+'.raw-candidates.json',physicalRunReports:clone(packet.physicalRunReports??[]),newViaReports:clone(packet.newViaReports??[]),all49Connected:false,all49Accepted:false,wholeMixedC31Supported:false,matched:false,timingPassed:false,electricalTimingQualified:false,criticalCompanionQualificationInherited:false,nativeExecuted:false,cadExecuted:false,fabricationReady:false}
fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,'',{flag:'wx'})
const save=()=>{report.elapsedMs=performance.now()-started;fs.writeFileSync(out+'.tmp',JSON.stringify(report,null,2)+'\n');fs.renameSync(out+'.tmp',out)}
save()
try{
 const imp=(n:string)=>import(pathToFileURL(ROOT+n+'.ts').href)
 const {GridVisibilitySearch}=await imp('grid-visibility'),{GridHeap}=await imp('grid-heap'),{VectorScene,fixedCopper,clearanceToCopper}=await imp('vector-scene')
 const {reduceOrdinaryTurns}=await imp('reduce-ordinary-turns'),{chamferOrdinaryCorners}=await imp('chamfer-ordinary-corners'),{nativeSignalGeometryIsValid}=await imp('native-signal-geometry'),{tuningPathIsSelfClear}=await imp('length-tuning')
 const {pointSegmentDistanceToPoints,segmentDistance,length}=await imp('geometry'),{boardOutlineViolations}=await imp('board-outline'),{BusLanesSolver}=await imp('bus-lanes-solver')
 const {retargetGeneratedEscape}=await imp('retarget-generated-escape'),{joinSignalEscapes}=await imp('join-signal-escapes'),lengths=await imp('route-lengths')
 const {qualifyMixedCarrier}=await import(pathToFileURL(QUALIFIER).href)
 const {createEndpointMenus,applyEndpointSelection}=await import(pathToFileURL(ENDPOINTS).href)
 const {BoundedSparseStateStore}=await import(pathToFileURL(SPARSE).href)
 const helpers={VectorScene,fixedCopper,clearanceToCopper,pointSegmentDistanceToPoints,segmentDistance,nativeSignalGeometryIsValid,tuningPathIsSelfClear,boardOutlineViolations,BusLanesSolver}
 const maximumWhole=(n:string)=>{const a=rules.filter(b=>b.connectionNames.includes(n)&&b.maxLength!==undefined);req(a.length===1,'One real bounded bus per missing owner '+n);return a[0].maxLength}
 const minimumWhole=(n:string)=>{const a=rules.filter(b=>b.connectionNames.includes(n)&&b.maxLength!==undefined);req(a.length===1,'One real bounded bus per bounded missing owner '+n);return a[0].minLength??0}
 const activeEscapes=(t:R,foundation:R=working)=>foundation.traces.filter((q:R)=>owner(q)===owner(t)).map((q:R)=>{const end=q.route.at(-1),layer=near(end,t.route[0])?t.route[0].layer:near(end,t.route.at(-1))?t.route.at(-1).layer:undefined;req(layer,'Owned branch must end at one exact carrier handoff');return retargetGeneratedEscape(clone(q),layer)})
 const joined=(t:R,foundation:R=working)=>{const escapes=activeEscapes(t,foundation),j=joinSignalEscapes(t,escapes),ends=[j.route[0],j.route.at(-1)];req(escapes.length===2&&ends.every((p:R)=>p.route_type==='wire'&&p.layer==='top'&&foundation.obstacles.some((o:R)=>o.circuitJsonMetadata?.pcb_port_id&&o.connectedTo.includes(owner(t))&&near(o.center,p))),'Actual numeric Top pads at both joined ends required');return j}
 const material=(t:R)=>t.route.slice(1).flatMap((b:R,i:number)=>{const a=t.route[i];return a.route_type==='wire'&&b.route_type==='wire'&&!near(a,b)?[{a:{x:a.x,y:a.y,layer:a.layer,width:a.width},b:{x:b.x,y:b.y,layer:b.layer,width:b.width}}]:[]})
 // Clean146 intentionally omitted141's inverse ledger. Recover only the six
 // already-authorized Top working-barrel deletions from pinned138 originals.
 if(!releasedWorkingBranchMaterial.length)for(const old of constructor.full49FanoutInput.traces){const current=working.traces.find((t:R)=>t.pcb_trace_id===old.pcb_trace_id);if(old.route.some((p:R)=>p.route_type==='via')&&current&&!current.route.some((p:R)=>p.route_type==='via')){req([8,21,41].some(i=>owner(old)==='source_trace_'+i)&&same(material(old),material(current)),'Inherited Top removal must preserve exact authorized owner/stub material');releasedWorkingBranchMaterial.push({owner:owner(old),reason:'INHERITED_ACTUAL141_TOP_WORKING_BARREL_REMOVAL_IN_CLEAN146',originalBranch:clone(old),replacementBranch:clone(current)})}}
 const extraHoles=(input:R)=>{
  const holes:R[]=[]
  for(const t of input.traces)for(const p of t.route)if(p.route_type==='via')holes.push({x:p.x,y:p.y,diameter:p.via_hole_diameter??HD,plated:true,owner:owner(t),physicalId:t.pcb_trace_id})
  for(const o of input.obstacles){const m=o.circuitJsonMetadata??{},id=m.pcb_via_id??m.pcb_hole_id??m.pcb_plated_hole_id;if(!id)continue;const r=rawCore.find((q:R)=>q.pcb_via_id===id||q.pcb_hole_id===id||q.pcb_plated_hole_id===id);req(r&&near(r,o.center),'Actual fixed hole record '+id);holes.push({x:o.center.x,y:o.center.y,diameter:r.hole_diameter??Math.hypot(r.hole_width,r.hole_height),plated:r.type!=='pcb_hole',physicalId:id,conservativeCircumscribedSlot:r.hole_shape!=='circle'&&r.shape==='pill'})}
  return holes
 }
 const nativeViaLandReport=(carrier:R,input:R)=>{
  const sites:R[]=[]
  for(const t of input.traces)if(owner(t)!==owner(carrier))for(const v of t.route)if(v.route_type==='via')sites.push({x:v.x,y:v.y,diameter:v.via_diameter,owner:owner(t),physicalId:t.pcb_trace_id})
  for(const o of input.obstacles)if(o.circuitJsonMetadata?.pcb_via_id&&!o.connectedTo?.includes(owner(carrier)))sites.push({x:o.center.x,y:o.center.y,diameter:Math.max(o.width,o.height),owner:o.connectedTo?.join(','),physicalId:o.circuitJsonMetadata.pcb_via_id})
  const reports=carrier.route.filter((v:R)=>v.route_type==='via').map((v:R)=>({via:{x:v.x,y:v.y,diameter:v.via_diameter},minimumGapMm:.15,violations:sites.flatMap(s=>{req(Number.isFinite(s.diameter)&&s.diameter>0,'Actual foreign via land diameter');const d=Math.hypot(v.x-s.x,v.y-s.y),required=v.via_diameter/2+s.diameter/2+.15;return d<required-1e-8?[{...s,actualCenterDistanceMm:d,requiredCenterDistanceMm:required,gapMm:d-v.via_diameter/2-s.diameter/2}]:[]})}))
  return {scope:'ACTUAL_NEW_CARRIER_VIAS_NATIVE_POINT15_LAND_GAP_SUPPLEMENT',passed:reports.every((r:R)=>r.violations.length===0),reports,allBoardNativeChecksExecuted:false}
 }
 // Native via-to-SMT/plated-pad edge clearance follows the explicit .1016
 // board rule. The separate native via-to-VIA land minimum remains .15.
 const nativePadClearanceScenes=(input:R)=>{
  const padOnly={...input,traces:[],obstacles:input.obstacles.filter((o:R)=>o.circuitJsonMetadata?.pcb_smtpad_id||o.circuitJsonMetadata?.pcb_plated_hole_id),minTraceToPadEdgeClearance:input.minViaEdgeToPadEdgeClearance??input.minTraceToPadEdgeClearance??.1016}
  return L.map(layer=>new VectorScene(padOnly,{name:'__NEW_FULLSPAN_VIA_PAD_CLEARANCE__',pointsToConnect:[{x:0,y:0,layer},{x:0,y:0,layer}]},VD,fixedCopper(padOnly)))
 }
 const allActualForeignViaSites=(input:R,name:string)=>[
  ...input.traces.filter((t:R)=>owner(t)!==name).flatMap((t:R)=>t.route.filter((v:R)=>v.route_type==='via').map((v:R)=>({x:v.x,y:v.y,diameter:v.via_diameter}))),
  ...input.obstacles.filter((o:R)=>o.circuitJsonMetadata?.pcb_via_id&&!o.connectedTo?.includes(name)).map((o:R)=>({x:o.center.x,y:o.center.y,diameter:Math.max(o.width,o.height)}))
 ]
 // Only one missing owner RAM approach/request changes. All41 ordinary
 // bodies, sixcritical, fixedreference copper and native-via repairs remain.
 const moves=[{name:'source_trace_30',side:1,pad:{x:4,y:5.8},beforeVia:{x:3.6,y:6.2},afterVia:{x:4.4,y:5.4}}],atomicInverses:R[]=[]
 req(missing.length===2&&same([...missing].sort(),['source_trace_26','source_trace_30'])&&captured.length===41&&[13,32,43,46].every(i=>captured.some(t=>owner(t)==='source_trace_'+i)),'Exact actual223 47-path profile including manual13/D5/D7/A6 and only26/30 missing')
 const manual11Inverse=clone(packet.manual11Inverse??null),manual40Inverse=clone(packet.manual40Inverse??null)
 req(same(captured,parentCaptured),'All41 current ordinary bodies remain bytewise fixed')
 for(const move of moves){
  req(![...held,...captured].some(t=>owner(t)===move.name),'No routed/critical owner may move')
  const index=working.traces.findIndex((t:R)=>owner(t)===move.name&&near(t.route[0],move.pad)),before=clone(working.traces[index]);req(index>=0&&before,'Exact numeric missing RAM-owned approach')
  const events=before.route.filter((p:R)=>p.route_type==='via');req(events.length===1&&near(events[0],move.beforeVia)&&same(events[0].layers,L)&&events[0].via_diameter===VD&&events[0].via_hole_diameter===HD,'Exact old missing RAM fullspan barrel required')
  const ci=working.connections.findIndex((c:R)=>c.name===move.name),oldRequest=clone(working.connections[ci]);req(ci>=0&&near(oldRequest.pointsToConnect[move.side],move.beforeVia),'Original missing RAM request order required')
  const layer=before.route.at(-1).layer,first=clone(before.route[0]),after={...clone(before),trace_length:Math.hypot(first.x-move.afterVia.x,first.y-move.afterVia.y),route:[first,{route_type:'wire',...move.afterVia,layer:'top',width:W},{...clone(events[0]),...move.afterVia},{route_type:'wire',...move.afterVia,layer,width:W}]}
  working.traces[index]=after;const points=clone(oldRequest.pointsToConnect);points[move.side]={...points[move.side],...move.afterVia};working.connections[ci]={...clone(oldRequest),pointsToConnect:points}
  const inverse={owner:move.name,reason:'DECLARED_MISSING30_RAM_NW_TO_SE_DOGBONE_RELOCATION',branches:[{index,before,after:clone(after)}],connection:{index:ci,before:oldRequest,after:clone(working.connections[ci])},noForeignMaterialReleased:true};atomicInverses.push(inverse);releasedWorkingBranchMaterial.push(clone(inverse))
 }
 const changedIndices=new Set(atomicInverses.map(r=>r.branches[0].index)),changedOwners=new Set(moves.map(m=>m.name))
 req(base.traces.every((t:R,i:number)=>changedIndices.has(i)||same(t,working.traces[i]))&&base.connections.every((c:R,i:number)=>changedOwners.has(c.name)||same(c,working.connections[i]))&&same(base.obstacles,working.obstacles)&&same(base.buses,working.buses)&&same(base.differentialPairs,working.differentialPairs),'Only the declared30 RAM owned approach/request may change')
 const expectedWorking=clone(constructor.full49FanoutInput)
 for(const inverse of atomicInverses){for(const b of inverse.branches)expectedWorking.traces[b.index]=clone(b.after);expectedWorking.connections[inverse.connection.index]=clone(inverse.connection.after)}
 req(same(working,expectedWorking)&&same(held,constructor.heldCarrierTraces)&&same(base,constructor.full49FanoutInput),'Changed foundation must equal only the exact declared30 RAM branch/request atomic delta from actual223 constructor; no constructor bypass')
 report.constructorFoundationDelta={sourcePacketSha256:inputPin,constructorSha256:profilePin,declaredChangedBranchIds:atomicInverses.map(r=>r.branches[0].after.pcb_trace_id),declaredChangedRequests:atomicInverses.map(r=>r.owner),fullExpectedFoundationEqualityPassed:true,criticalSixLiteralUnchanged:true,allReferencesLiteralUnchanged:true}
 report.atomicFanoutInverses=clone(atomicInverses);report.atomicFanoutPhysicalReports=[];save()
 const atomicScene={...working,traces:[...working.traces,...held,...captured]}
 for(const inverse of atomicInverses){
  const t=inverse.branches[0].after,first=t.route[0],end=t.route[1],via=t.route[2],c=working.connections.find((c:R)=>c.name===owner(t)),pad=working.obstacles.filter((o:R)=>near(o.center,first)&&o.circuitJsonMetadata?.pcb_port_id&&o.connectedTo.includes(owner(t)))
  req(pad.length===1&&first.layer==='top'&&[first.start_pcb_port_id,first.end_pcb_port_id].filter(Boolean).every((id:string)=>id===pad[0].circuitJsonMetadata.pcb_port_id),'Actual numeric Top ball backing, no stale fanout-port alias')
  // Exclude only this installed approach for land checks; its incident own stub
  // naturally meets its own land. Other owned material and every foreign object
  // remain present. A radial straight stub has only initial numeric-pad contact.
  const other={...atomicScene,traces:atomicScene.traces.filter((q:R)=>q.pcb_trace_id!==t.pcb_trace_id)},fixed=fixedCopper(other),landViolations:R[]=[]
  for(const q of fixed)if(clearanceToCopper(via,via,q)<VD/2+(working.minViaEdgeToPadEdgeClearance??W)-1e-8)landViolations.push({layer:q.layer,owners:q.owners,distanceToCopperMm:clearanceToCopper(via,via,q)})
  const physicalHoles=extraHoles(other),drillViolations=physicalHoles.filter((h:R)=>Math.hypot(via.x-h.x,via.y-h.y)<HD/2+h.diameter/2+Math.max(working.minViaHoleEdgeToViaHoleEdgeClearance??.254,working.minPlatedHoleDrillEdgeToDrillEdgeClearance??0)-1e-8),wireDrillViolations=physicalHoles.filter((h:R)=>pointSegmentDistanceToPoints(h,first,end)<W/2+h.diameter/2+(working.minTraceToHoleEdgeClearance??.2)-1e-8)
  const stub={...clone(t),pcb_trace_id:t.pcb_trace_id+'_atomic_top_stub',route:[clone(first),clone(end)]},stubConnection={...c,pointsToConnect:[first,end].map((p:R)=>({x:p.x,y:p.y,layer:'top'}))},input={...atomicScene,connections:[stubConnection],buses:[],differentialPairs:[]},validator=BusLanesSolver.forValidation(input,[stub],{smoothTuning:true,denseSearch:true,maxSearchIterations:2000000});for(let k=0;k<8&&!validator.solved&&!validator.failed;k++)validator.step()
  const nativeViaLandGap=nativeViaLandReport(t,other),nativeViaPadScenes=nativePadClearanceScenes(other),nativeViaPadClearancePassed=nativeViaPadScenes.every(scene=>scene.visible(via,via)),outlineViolations=boardOutlineViolations(working,[t]),native=nativeSignalGeometryIsValid(t)&&nativeSignalGeometryIsValid(stub),self=tuningPathIsSelfClear(stub.route,W+(working.minTraceToPadEdgeClearance??W)),r={owner:owner(t),pcb_trace_id:t.pcb_trace_id,numericPadId:pad[0].circuitJsonMetadata.pcb_port_id,allFourLayersChecked:true,nativeViaLandGap,nativeViaPadClearancePassed,landViolations,drillViolations,wireDrillViolations,outlineViolations,nativeGeometry:native,selfClear:self,topStubC31:{solved:validator.solved,error:validator.error,failureCode:validator.failureCode},passed:nativeViaLandGap.passed&&nativeViaPadClearancePassed&&!landViolations.length&&!drillViolations.length&&!wireDrillViolations.length&&!outlineViolations.length&&native&&self&&validator.solved};report.atomicFanoutPhysicalReports.push(r);save()
 }
 report.atomicFanoutsPhysicallyPreflightPassed=report.atomicFanoutPhysicalReports.length===1&&report.atomicFanoutPhysicalReports.every((r:R)=>r.passed);req(report.atomicFanoutsPhysicallyPreflightPassed,'Atomic dogbone fullspan/stub physical preflight failed; no routing or acceptance')
 report.beforeSearchAll47PhysicalReports=[]
 for(const t of [...held,...captured]){
  req(performance.now()-started<budget-3000,'Budget expired during required before-search47 physical controls')
  const walls={...working,traces:[...working.traces,...held,...captured].filter((q:R)=>owner(q)!==owner(t)||working.traces.includes(q))},c=working.connections.find((c:R)=>c.name===owner(t)),q=qualifyMixedCarrier({...walls,extraPhysicalHoles:extraHoles(walls)},c,t,helpers),numeric=joined(t),r={owner:owner(t),...q,joinedNativeGeometry:nativeSignalGeometryIsValid(numeric)}
  report.beforeSearchAll47PhysicalReports.push(r);save()
 }
 report.beforeSearchAll47Qualified=report.beforeSearchAll47PhysicalReports.length===47&&report.beforeSearchAll47PhysicalReports.every((r:R)=>r.passed&&r.joinedNativeGeometry)
 save();req(report.beforeSearchAll47Qualified,'Every retained47 must freshly qualify in exact atomic scene before searching')
 const persist=()=>{
  const all=[...held,...captured,...retained],numeric=all.map(t=>joined(t)),dormant:R[]=[]
  const ordinaryMinimumLengthObservations=[...captured,...retained].map(t=>{
   const name=owner(t),wholeLengthMm=lengths.fixedRouteLength(working,name)+planar(t),ownerRules=rules.filter(b=>b.connectionNames.includes(name));req(ownerRules.length===1,'Exactly one real ordinary bus rule including unbounded RESET');const r=ownerRules[0],minimumWholeMm=r.minLength??null,maximumWholeMm=r.maxLength??null,minimumMatched=minimumWholeMm===null?null:wholeLengthMm>=minimumWholeMm-1e-7,maximumSatisfied=maximumWholeMm===null?null:wholeLengthMm<=maximumWholeMm+1e-7
   return {owner:name,wholeLengthMm,derivedWholeWindowMm:[minimumWholeMm,maximumWholeMm],minimumBoundPresent:minimumWholeMm!==null,maximumBoundPresent:maximumWholeMm!==null,unboundedWholeLength:minimumWholeMm===null&&maximumWholeMm===null,minimumMatched,maximumSatisfied,belowMinimumNeedsLengthTuning:minimumMatched===false,physicalConnectivityStageOnly:true,matched:false,timingPassed:false}
  })
  const wholeByOwner=new Map(all.map(t=>[owner(t),lengths.fixedRouteLength(working,owner(t))+planar(t)]))
  const originalBusConstraintObservations=working.buses.map((rule:R)=>{
   const present=rule.connectionNames.filter((n:string)=>wholeByOwner.has(n)).map((n:string)=>({owner:n,wholePlanarLengthMm:wholeByOwner.get(n)!})),missingOwners=rule.connectionNames.filter((n:string)=>!wholeByOwner.has(n)),values=present.map((r:R)=>r.wholePlanarLengthMm),observedSkewMm=values.length>=2?Math.max(...values)-Math.min(...values):null,violations:R[]=[]
   for(const r of present){if(rule.minLength!==undefined&&r.wholePlanarLengthMm<rule.minLength-1e-7)violations.push({kind:'ORIGINAL_MIN_LENGTH',owner:r.owner,actualMm:r.wholePlanarLengthMm,requiredMm:rule.minLength});if(rule.maxLength!==undefined&&r.wholePlanarLengthMm>rule.maxLength+1e-7)violations.push({kind:'ORIGINAL_MAX_LENGTH',owner:r.owner,actualMm:r.wholePlanarLengthMm,requiredMm:rule.maxLength})}
   if(rule.maxLengthSkew!==undefined&&observedSkewMm!==null&&observedSkewMm>rule.maxLengthSkew+1e-7)violations.push({kind:'ORIGINAL_MAX_LENGTH_SKEW',actualMm:observedSkewMm,requiredMm:rule.maxLengthSkew})
   return {originalRule:clone(rule),measurement:'WHOLE_PLANAR_XY_CENTERLINE_MM_FANOUTS_PLUS_CARRIER',present,missingOwners,allMembersPresent:missingOwners.length===0,observedSkewMm,violations,observedPlanarConstraintsPassed:missingOwners.length===0&&violations.length===0,electricalTimingQualified:false}
  })
  const originalPairConstraintObservations=working.differentialPairs.map((rule:R)=>{
   const missingOwners=rule.connectionNames.filter((n:string)=>!wholeByOwner.has(n)),values=rule.connectionNames.filter((n:string)=>wholeByOwner.has(n)).map((n:string)=>({owner:n,wholePlanarLengthMm:wholeByOwner.get(n)!})),observedLengthSkewMm=values.length===2?Math.abs(values[0].wholePlanarLengthMm-values[1].wholePlanarLengthMm):null
   return {originalRule:clone(rule),values,missingOwners,observedLengthSkewMm,lengthToleranceSatisfied:observedLengthSkewMm===null?null:observedLengthSkewMm<=rule.lengthTolerance+1e-7,spacingCouplingGeometryExecutedByThisObservation:false,electricalTimingQualified:false}
  })
  report.originalBusConstraintObservations=clone(originalBusConstraintObservations);report.originalPairConstraintObservations=clone(originalPairConstraintObservations)
  report.ordinaryMinimumLengthObservations=clone(ordinaryMinimumLengthObservations);report.minimumMatched=ordinaryMinimumLengthObservations.filter(r=>r.minimumBoundPresent).every(r=>r.minimumMatched);report.physicalConnectivityStage='PARTIAL_CONNECTED_TOPOLOGY_UNMATCHED_TIMING_PENDING';report.minimumLengthFailuresRetained=ordinaryMinimumLengthObservations.filter(r=>r.minimumMatched===false).map(r=>r.owner)


  for(const t of working.traces)for(let i=0;i<t.route.length;i++){const p=t.route[i];if(p.route_type==='via'&&all.some(q=>owner(q)===owner(t))&&!numeric.find(q=>owner(q)===owner(t))!.route.some((q:R)=>q.route_type==='via'&&near(p,q)))dormant.push({owner:owner(t),pcb_trace_id:t.pcb_trace_id,routeIndex:i,...p})}
  const p={manual12Inverse:clone(packet.manual12Inverse??null),manual12BeforeAfter:clone(packet.manual12BeforeAfter??null),manual13Route:clone(packet.manual13Route??null),manual13Head:clone(packet.manual13Head??null),ordinaryBodyInverses:clone(packet.ordinaryBodyInverses??[]),manualD5Seed:clone(packet.manualD5Seed??null),scope:'ACTUAL223_MISSING30_RAM_SE_KEEP_CPU_SE_UNMATCHED_TOPOLOGY_CANDIDATE',manual11Inverse:clone(manual11Inverse),manual11BeforeAfter:clone(packet.manual11BeforeAfter??null),clockPairRepair:clone(packet.clockPairRepair??null),beforeSearchAll47Qualified:report.beforeSearchAll47Qualified,constructorFoundationDelta:clone(report.constructorFoundationDelta),ordinaryMinimumLengthObservations:clone(ordinaryMinimumLengthObservations),originalBusConstraintObservations:clone(originalBusConstraintObservations),originalPairConstraintObservations:clone(originalPairConstraintObservations),minimumMatched:report.minimumMatched,minimumLengthFailuresRetained:clone(report.minimumLengthFailuresRetained),physicalConnectivityStage:'PARTIAL_CONNECTED_TOPOLOGY_UNMATCHED_TIMING_PENDING',inheritedAtomicFanoutInverses:clone(packet.atomicFanoutInverses??[]),manual40Inverse:clone(manual40Inverse),manual40BeforeAfter:clone(packet.manual40BeforeAfter??null),atomicFanoutInverses:clone(atomicInverses),atomicFanoutPhysicalReports:clone(report.atomicFanoutPhysicalReports),workingChanges:[...clone(packet.workingChanges??[]),{type:'DECLARED_MISSING30_RAM_SE_RETAIN_ALL47',manual11Inverse:clone(manual11Inverse),inverses:clone(atomicInverses),manual40Inverse:clone(manual40Inverse)}],source21NativeTopRepair:clone(packet.source21NativeTopRepair??null),full49FanoutInput:working,heldCarrierTraces:held,ordinaryCarrierTraces:[...captured,...retained],carrierTraces:all,joinedNumericPadTraces:numeric,dormantWorkingBarrels:dormant,releasedWorkingBranchMaterial,physicalRunReports:report.physicalRunReports,newViaReports:report.newViaReports,finalScenePhysicalReports:report.finalScenePhysicalReports??[],allSavedCarriersCurrentSceneQualified:report.allSavedCarriersCurrentSceneQualified===true,newViaEventCount:[...captured,...retained].reduce((s,t)=>s+t.route.filter((p:R)=>p.route_type==='via').length,0),capturedMixedOwners:captured.filter(t=>t.route.some((p:R)=>p.route_type==='via')).map(owner),retainedMixedOwners:retained.map(owner),all49Connected:all.length===49,all49Accepted:false,wholeMixedC31Supported:false,matched:false,timingPassed:false,electricalTimingQualified:false,criticalCompanionQualificationInherited:false,nativeExecuted:false,cadExecuted:false,fabricationReady:false}
  fs.writeFileSync(stem+'.candidate.json',JSON.stringify(p,null,2)+'\n');report.connectedAll49Count=all.length;report.remaining=missing.filter((n:string)=>!retained.some(t=>owner(t)===n));report.all49Connected=all.length===49;save()
 }
 persist()
 const normalize=(t:R,input:R,c:R)=>{
  const route:R[]=[];let run:R[]=[]
  const flush=()=>{if(!run.length)return;const layer=run[0].layer,local={...c,pointsToConnect:[run[0],run.at(-1)].map(p=>({x:p.x,y:p.y,layer}))},one={...input,connections:[local],buses:[],differentialPairs:[]},scene=new VectorScene(one,local,W,fixedCopper(one)),reduced=reduceOrdinaryTurns(run,scene).map((p:R)=>({...p,route_type:'wire',layer,width:W})),trace={...t,route:reduced},next=chamferOrdinaryCorners(one,[trace])[0];route.push(...next.route);run=[]}
  for(const p of t.route){if(p.route_type==='via'){flush();route.push(p)}else run.push(p)}flush();return {...t,route}
 }
 const searchMixed=(input:R,c:R,menus:R,bounds:R,cap:number,record:R):R|undefined=>{
  const maps:any[]=[],scenes:any[]=[],access:any[]=[],fixed=fixedCopper(input),viaMemo=new Map<number,boolean>(),holes=extraHoles(input),caseStart=performance.now()
  try{
   for(const layer of L){const local={...c,pointsToConnect:clone(menus.byLayer[layer].pointsToConnect)},scene=new VectorScene(input,local,W,fixed),grid=new GridVisibilitySearch(scene,local.pointsToConnect[0],local.pointsToConnect[1],[],0,undefined,{step:STEP,bounds,maxLength:cap,allTerminalAttachments:true,checkReachability:false,paretoLength:false});maps.push(grid);scenes.push(scene);access.push(grid.getRoutingAccess())}
   const N=access[0].cellCount,nx=access[0].nx,ny=access[0].ny
   req(N<=2000000&&access.every(a=>a.cellCount===N&&a.nx===nx&&a.ny===ny&&near(a.point(0),access[0].point(0))&&near(a.point(N-1),access[0].point(N-1))),'Identical bounded four-layer XY grids required')
   record.actualCellsPerLayer=N;record.endpointAttachments=access.map((a,i)=>({layer:L[i],starts:a.starts.length,ends:a.ends.length,pointsToConnect:menus.byLayer[L[i]].pointsToConnect,fanoutMm:menus.byLayer[L[i]].fanoutMm}));save()
   const store=new BoundedSparseStateStore(maxLabels),heap=new GridHeap(maxLabels),roots=new Map<number,R[]>(),goals=access.map((a,i)=>new Map<number,R[]>((menus.byLayer[L[i]].supportedEndpoints[1]?a.ends:[]).map((e:R)=>[e.id,e.path.toReversed()])))
   // Exact terminal attachments may have arbitrary angle. Euclidean is an
   // admissible lower bound; octile can overestimate their physical length.
   const heuristic=(p:R)=>Math.min(...L.filter(layer=>menus.byLayer[layer].supportedEndpoints[1]).map(layer=>{const end=menus.byLayer[layer].pointsToConnect[1];return Math.hypot(p.x-end.x,p.y-end.y)+menus.byLayer[layer].fanoutMm[1]}))
   const push=(state:number,g:number,fromLabel:number)=>{const old=store.get(state);if(old>=0&&g>=store.cost(old)-1e-10)return -1;const p=access[0].point(state%N),k=Math.floor(state/(4*N));if(g+heuristic(p)>cap+1e-8)return -1;const label=store.relax(state,g,fromLabel);if(label>=0)heap.push(label,g,g+heuristic(p)+k*.2);return label}
   for(let l=0;l<4;l++)for(const a of (menus.byLayer[L[l]].supportedEndpoints[0]?access[l].starts:[])){const state=a.id+N*l,g=length(a.path)+menus.byLayer[L[l]].fanoutMm[0],label=push(state,g,-1);if(label>=0)roots.set(label,a.path)}
   const viaScenes=L.map(layer=>new VectorScene(input,{name:'__NEW_MIXED_BARREL__',pointsToConnect:[{x:0,y:0,layer},{x:0,y:0,layer}]},VD,fixed)),viaPadScenes=nativePadClearanceScenes(input),foreignViaSites=allActualForeignViaSites(input,c.name)
   const viaClear=(cell:number)=>{const cached=viaMemo.get(cell);if(cached!==undefined)return cached;const p=access[0].point(cell),clear=viaScenes.every(s=>s.visible(p,p))&&viaPadScenes.every(s=>s.visible(p,p))&&foreignViaSites.every(v=>Math.hypot(v.x-p.x,v.y-p.y)>=VD/2+v.diameter/2+.15-1e-8)&&holes.every(h=>Math.hypot(h.x-p.x,h.y-p.y)>=HD/2+h.diameter/2+Math.max(input.minViaHoleEdgeToViaHoleEdgeClearance??.254,input.minPlatedHoleDrillEdgeToDrillEdgeClearance??0)-1e-8);viaMemo.set(cell,clear);return clear}
   let expanded=0
   while(heap.length&&expanded<maxExpanded&&performance.now()-caseStart<perCase&&performance.now()-started<budget-3000){
    heap.pop();const label=heap.id,g=heap.g;if(g!==store.cost(label))continue;const state=store.state(label);expanded++;const cell=state%N,l=Math.floor(state/N)%4,k=Math.floor(state/(4*N)),a=access[l],goal=goals[l].get(cell)
    if(goal&&g+length(goal)+menus.byLayer[L[l]].fanoutMm[1]<=cap+1e-8){
     const chain:number[]=[];let s=label;while(s>=0){chain.push(s);s=store.parent(s)}chain.reverse();let route:R[]=roots.get(chain[0])!.map(p=>({...p,route_type:'wire',layer:L[Math.floor(store.state(chain[0])/N)%4],width:W}))
     for(let i=1;i<chain.length;i++){const previous=store.state(chain[i-1]),current=store.state(chain[i]),pl=Math.floor(previous/N)%4,cl=Math.floor(current/N)%4,p=access[0].point(current%N);if(pl!==cl)route.push({route_type:'via',x:p.x,y:p.y,from_layer:L[pl],to_layer:L[cl],layers:clone(L),via_diameter:VD,via_hole_diameter:HD});route.push({...p,route_type:'wire',layer:L[cl],width:W})}
     route.push(...goal.slice(1).map(p=>({...p,route_type:'wire',layer:L[l],width:W})));record.expanded=expanded;record.selectedCPUFanoutMm=menus.byLayer[route[0].layer].fanoutMm[0];record.selectedRAMFanoutMm=menus.byLayer[L[l]].fanoutMm[1];record.rawWholeLengthMm=g+length(goal)+record.selectedRAMFanoutMm;record.outcome='RAW_MIXED_TOPOLOGY_SAVED_BEFORE_QUALIFICATION';return {type:'pcb_trace',pcb_trace_id:'native_top_mixed_'+c.name,connection_name:c.name,source_trace_id:c.name,route}
    }
    const x=cell%nx,y=Math.floor(cell/nx)
    for(const n of a.neighbors){if(x+n.dx<0||x+n.dx>=nx||y+n.dy<0||y+n.dy>=ny)continue;const next=cell+n.offset;if(a.isBlocked(next)||!a.hardEdgeIsClear(cell,n))continue;push(next+N*(l+4*k),g+n.cost*STEP,label)}
    if(k<maxVias&&viaClear(cell))for(let target=0;target<4;target++)if(target!==l&&!access[target].isBlocked(cell))push(cell+N*(target+4*(k+1)),g,label)
    if((expanded&65535)===0){record.expanded=expanded;record.openStates=heap.length;record.sparseLabels=store.count;record.sparseLabelLimitReached=store.limitReached;save()}
   }
   record.expanded=expanded;record.sparseLabels=store.count;record.sparseLabelLimitReached=store.limitReached;record.outcome=store.limitReached?'SPARSE_LABEL_BUDGET_REACHED_NO_INFEASIBILITY_CLAIM':heap.length?'BOUNDED_STATE_OR_TIME_EXIT':'EXHAUSTED_THIS_BOUNDED_XY_LAYER_STATE_MODEL';return
  }finally{for(const grid of maps)grid.cancel()}
 }
 const order=['source_trace_30'];req(missing.includes('source_trace_30'),'Only missing30 receives this newSERAM search')
 for(const halo of [[1,1],[2,2],[3,2]])for(const n of order){
  if(retained.some(t=>owner(t)===n)||performance.now()-started>=budget-3000)continue
  const c=clone(working.connections.find((q:R)=>q.name===n)),menus=createEndpointMenus(working,c,{retargetGeneratedEscape}),points=L.flatMap(layer=>menus.byLayer[layer].pointsToConnect)
  const walls={...clone(working),traces:[...working.traces,...held,...captured,...retained]},cap=maximumWhole(n),bounds={minX:Math.min(...points.map((p:R)=>p.x))-halo[0],maxX:Math.max(...points.map((p:R)=>p.x))+halo[0],minY:Math.min(...points.map((p:R)=>p.y))-halo[1],maxY:Math.max(...points.map((p:R)=>p.y))+halo[1]},estimated=(Math.ceil((bounds.maxX-bounds.minX)/STEP)+1)*(Math.ceil((bounds.maxY-bounds.minY)/STEP)+1),record:R={name:n,halo,bounds,maximumWholeMm:cap,endpointMenus:menus.byLayer,estimatedCellsPerLayer:estimated};report.attempts.push(record);save()
  if(estimated>2000000){record.outcome='ROI_CELL_CAP';continue}
  try{
   const raw=searchMixed(walls,c,menus,bounds,cap,record);if(!raw){save();continue}
   const rawSelection=applyEndpointSelection(working,c,raw,menus,{retargetGeneratedEscape})
   rawCandidates.push({name:n,carrierTrace:raw,joinedNumericPadTrace:joined(raw,rawSelection.foundation),unqualifiedEndpointChanges:rawSelection.inverse,qualified:false,matched:false,all49Accepted:false});fs.writeFileSync(report.rawCandidatesPath,JSON.stringify({scope:'RAW_MIXED_TOPOLOGIES_UNQUALIFIED',candidates:rawCandidates,all49Accepted:false},null,2)+'\n');save()
   const variants:R[]=[];try{variants.push(normalize(raw,walls,c))}catch(e){record.normalizationError=String(e)}variants.push(raw)
   for(const t of variants){const selected=applyEndpointSelection(working,c,t,menus,{retargetGeneratedEscape}),next=selected.foundation,removed=selected.inverse,wholeMm=lengths.fixedRouteLength(next,n)+planar(t);record.minimumMatched=wholeMm>=minimumWhole(n)-1e-7;record.minimumWholeMm=minimumWhole(n);record.maximumWholeMm=cap;record.belowMinimumNeedsLengthTuning=!record.minimumMatched;record.topologyStageAllowsBelowMinimumOnly=true;record.matched=false;record.timingPassed=false;if(wholeMm>cap+1e-7){record.rejectedWholeLengthMm=wholeMm;record.maximumHardLimitRejected=true;continue;}const nextWalls={...next,traces:[...next.traces,...held,...captured,...retained]},nextConnection=next.connections.find((p:R)=>p.name===n),q=qualifyMixedCarrier({...nextWalls,extraPhysicalHoles:extraHoles(nextWalls)},nextConnection,t,helpers);record.qualifications??=[];record.qualifications.push(q);const numeric=joined(t,next);record.normalizedProposals??=[];record.normalizedProposals.push({carrierTrace:t,joinedNumericPadTrace:numeric,wholeLengthMm:wholeMm,qualified:q.passed,minimumMatched:wholeMm>=minimumWhole(n)-1e-7,derivedMinimumWholeMm:minimumWhole(n),derivedMaximumWholeMm:cap,belowMinimumNeedsLengthTuning:wholeMm<minimumWhole(n)-1e-7,matched:false,timingPassed:false,joinedNativeGeometry:nativeSignalGeometryIsValid(numeric)});save();record.newCarrierNativeViaLandGap=nativeViaLandReport(t,nextWalls);if(!q.passed||!record.newCarrierNativeViaLandGap.passed)continue;if(!nativeSignalGeometryIsValid(numeric)){record.numericJoinedGeometryPassed=false;continue}working=next;releasedWorkingBranchMaterial.push(removed);retained.push(t);report.retained.push(clone(t));report.physicalRunReports.push(...q.physicalRunReports.map((r:R)=>({owner:n,...r})));report.newViaReports.push(...q.newViaReports.map((r:R)=>({owner:n,...r})));record.outcome='INDEPENDENT_PER_RUN_AND_STANDARD_BARREL_PHYSICAL_CHECKS_PASSED';record.newViaCount=t.route.filter((p:R)=>p.route_type==='via').length;record.wholeLengthMm=wholeMm;persist();break}
   if(!retained.some(t=>owner(t)===n))record.outcome='RAW_MIXED_TOPOLOGY_REQUIRES_GEOMETRY_OR_BARREL_REPAIR'
  }catch(e){record.outcome='CASE_EXCEPTION';record.error=e instanceof Error?e.stack:String(e)}finally{bun.gc(true);record.fullGcAfterSearchAndQualification=true;save()}
 }
 const all=[...held,...captured,...retained];report.finalScenePhysicalReports=[]
 for(const t of [...retained,...held,...captured]){
  if(performance.now()-started>=budget){report.finalSceneCheckIncomplete=true;break}
  const input={...working,traces:[...working.traces,...all.filter(q=>owner(q)!==owner(t))]},c=working.connections.find((c:R)=>c.name===owner(t)),qualification=qualifyMixedCarrier({...input,extraPhysicalHoles:extraHoles(input)},c,t,helpers)
  report.finalScenePhysicalReports.push({owner:owner(t),...qualification});save()
 }
 report.allSavedCarriersCurrentSceneQualified=report.finalScenePhysicalReports.length===all.length&&report.finalScenePhysicalReports.every((r:R)=>r.passed)
 persist();req(JSON.stringify({base,held,parentCaptured})===frozen,'Held physical scene mutated')
 report.terminalOutcome=report.all49Connected?'ALL49_CONNECTED_WITH_INDEPENDENT_MIXED_CHECKS_TIMING_SOURCE_NATIVE_PENDING':'PARTIAL_MIXED_PROGRESS_SAVED_NO_BOARD_INFEASIBILITY_CLAIM'
}catch(e){report.terminalOutcome='EXCEPTION_NO_ACCEPTANCE';report.error=e instanceof Error?e.stack:String(e);process.exitCode=2}finally{save()}
console.log(JSON.stringify({out,terminalOutcome:report.terminalOutcome,connectedAll49:report.connectedAll49Count,remaining:report.remaining,all49Accepted:false}))
