# Manual Source-only static18 integration

This unexecuted Source fork integrates the independently checked static18:
all11 byte1 signals, clocks33/34, and byte0 signals3/15/16/30/31. It adds three
physical PCB paths to16 original numeric Source declarations and suppresses only
their32 duplicate local PCB renderings. The existing two qualified V11 clock
declarations and paths remain exact. Twenty-four genuine Inner1/Inner2 Port
children use public Via matching before render; existing Top/Bottom aliases stay.
No physical barrel, footprint, reference path or Topstub geometry changes.

All four original DDR class buses explicitly widen their pcbAllowedLayers to
Top/Inner1/Inner2/Bottom, as the user authorized. The saved routing input widens
the corresponding allowedLayers lists. This is a declared layer-policy fork.
Preferred layers, every original numeric endpoint and bus roster, width,
max/min length,0.635mm class skew and0.127mm/0.12mm pair skew/gap remain exact.
The capture inversely restores every original allowed-layer list and complete
Source tree. The manual7ff public Bus pair representation remains; automatic
Core SRJ routing/discovery must not be used for this manual fork.

The original144-file Source closure is retained byte-exact. Only the new files
declare the successor. No Source evaluation, typecheck, Core, Native or CAD
execution occurred while authoring. Fourteen independent stdlib negative
controls reject wrong numeric/barrel ownership, missing/extra ports, changed
geometry/layers, altered qualified clocks, missing original owners, weakened
timing/pair rules, changed preference and missing logical endpoints.

Fresh Core must derive all runtime port/trace IDs from real Source objects. The
expected inventories are225 full-span barrels,165 unchanged reference paths,
96 unchanged Topstub geometries,279 physical traces and24 new real Ports. The
original1615 Source/PCB ports should increase to1639. These are expectations,
not an actual Core result. Exactly28 inner Port/Via matches include the four
existing clocks plus24 new matches. No ownership ID may be copied from raw7793.

The strict18 reference shadow0620c69b remains unqualified: adjacent signal
shadows, missing reference intervals and fixed gaps are recorded. No planes
were edited, no reference/impedance/return/timing qualification is claimed, and
31 DDR channels remain missing after the intended18-route qualification.
Source-only static passes do not establish fresh Core/Native/CAD acceptance.
fabricationReady=false. Root must review and separately guard Source capture,
functional strict typecheck, fresh manual Core, original continuous Native APIs
and actual KiCad before this fork can become a hardware checkpoint.

Source capture requires the pinned Bun1.3.14, a fresh owned output/report pair
and G350_STRICT18_SOURCE_ROOT_GUARDED=1 under Root's serial resource guard.
It saves the actual trees before assertions. RegisterStrict18InnerPorts must
be called only on the actual unrendered PCB-only Circuit after adding this
element. Neither function was invoked by the author. The pre-peer draft keeps
the earlier control report and source bytes; final source distinguishes the
routing allowedLayers field from Source pcbAllowedLayers and asserts exact
Port child props with no invented coordinates.
