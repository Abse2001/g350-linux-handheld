"""Finite all-candidate recheck on explicit227 material, stdlib only."""
from pathlib import Path
import sys,json,hashlib,math,importlib.util,copy,time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;pins={}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p,expected=None):
    p=Path(p);h=sha(p)
    if expected:assert h==expected,(str(p),h)
    pins[str(p)]=h;return json.loads(p.read_text())
def mod(name,p):
    pins[str(p)]=sha(p);spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
resetbase=BASE/'ddr-reset10-context12-two-owned-breakout-227-sourceonly-next'
z=mod('explicit227',resetbase/'material-reset227-proposal.py')
s=mod('actual_input_floor',BASE/'ddr-cpu19-cap-and-owned32-corner-sourceonly-next/material-context-cap19-owned32-owned4.py')
assert sha(z.CONTEXT)=='fb267b4917d1cc27b4fcf86331ddf7256105c65ce12f80d8c79d15ad0e6f2c28'
assert len(z.full['traces'])==263 and len(z.native['referenceVias'])==129 and len(z.native['signalDogbones'])==98
assert all(z.full[k]==z.carrier[k] for k in z.full if k!='connections')
assert z.full['connections']==z.q.full['connections'] and z.full['traces'][:261]==z.q.full['traces']
for pin in [z.context[k] for k in ['baseline225ContextPin','full49NumericInputPin','full49CarrierInputPin','fullNativeContextPin','authenticSiteAndNumericLeadProofPin','resetVariableCandidatePoolPin','fullCoreGeometryHypothesisPin']]:read(pin['path'],pin['sha256'])
old=read(BASE/'ddr-context12-global-pool-coordinator-sourceonly-next/GLOBAL_CONTEXT12_UPDATED_B1_ALL24_CA_POOL_PARTIAL04.json','51476346d6cf0e5b09696e294206a4a12786cbbd1f67d6b7afd4a033be21dcf3')
ca=read(resetbase/'ALL24_CA_VARIABLE_POOLS_LITERAL227_LOCAL_REPAIR_SUCCESSOR.json','13058f8072fb5fc34444a80cb64881f605da63ae746d0d5ad14019d8af4bd930')
assert ca['proposed227ContextPin']=={'path':str(z.CONTEXT),'sha256':sha(z.CONTEXT)}
assert ca['actualNumericPhysicalAuthorityPin']==z.context['full49NumericInputPin']
assert ca['correctedActualMaterialSolverViewPin']==z.context['full49CarrierInputPin']
reserved=ca['reservedRegions'];classes,mates=z.p.classes(z.full)
fixed={}
for t in z.full['traces']:
    n=t.get('source_trace_id');fixed[n]=fixed.get(n,0.)+sum(math.dist((a['x'],a['y']),(b['x'],b['y'])) for a,b in zip(t['route'],t['route'][1:]) if a['route_type']==b['route_type']=='wire' and a['layer']==b['layer'])
bus_by_name={n:b for b in z.full['buses'] for n in b['connectionNames']}
pairunits={frozenset(p['connectionNames']):'PAIR:'+','.join(sorted(p['connectionNames'])) for p in z.full['differentialPairs']}
class Scene(z.Scene):
    def __init__(self,layer,records,target):
        # Reuse the genuine227 constructor: its original225 scene explicitly
        # adds only the two authenticated Reset circles/Top leads and holds98.
        super().__init__(layer,records,target,reserved)
        traces={t['pcb_trace_id']:t for t in z.full['traces']}
        old_items=self.items;self.items=[];self.buckets={}
        for item in old_items:
            item=dict(item)
            if item['kind']=='segment' and 'ddrOwner' not in item:
                assert item['id'] in traces
                trace=traces[item['id']];widths=[]
                for a,b in zip(trace['route'],trace['route'][1:]):
                    if a['route_type']!=b['route_type'] or a['route_type']!='wire' or a['layer']!=layer:continue
                    if math.dist((a['x'],a['y']),item['a'])<1e-10 and math.dist((b['x'],b['y']),item['b'])<1e-10:widths.append(max(a['width'],b['width']))
                assert widths
                item['preservedConservativePDN4WPlanningR']=item['r']
                item['r']=max(widths)/2+.1016/2+z.full['minTraceToPadEdgeClearance']
                a,b=item['a'],item['b'];r=item['r'];item['bbox']=(min(a[0],b[0])-r,max(a[0],b[0])+r,min(a[1],b[1])-r,max(a[1],b[1])+r)
            self.add(item)
        assert self.counts['signalFullSpanBarrels']==98
candidate={};domains={};rejected=[];seen=set();pairnames=set().union(*pairunits)
def add(rows,origin,label):
    strict,raw=z.normalize({'records':rows});names=frozenset(strict);assert len(names)==1 or names in pairunits
    if len(names)==1:assert not names&pairnames
    unit=pairunits.get(names,next(iter(names)))
    signature=json.dumps([(n,r['layer'],r['path']) for n,r in sorted(strict.items())],separators=(',',':'))
    if signature in seen:return
    seen.add(signature);key=unit+'/'+hashlib.sha256(signature.encode()).hexdigest()[:16]
    checks={};good=True
    for n,r in strict.items():
        others={k:v for k,v in strict.items() if k!=n};scene=Scene(r['layer'],others,n)
        blocked=[i for i,(a,b) in enumerate(zip(r['path'],r['path'][1:])) if not scene.visible(a,b,n)]
        st=s.ns['selfcheck']([s.P(*p) for p in r['path']]);an=s.angles(r['path']);whole=z.g.length(r['path'])+fixed.get(n,0.)
        bus=bus_by_name[n];window=bus.get('minLength',0.)-1e-8<=whole<=bus.get('maxLength',math.inf)+1e-8
        exposure=scene.exposure(r['path'],n)
        checks[n]={'blockedSegments':blocked,'selfClear':st['clear'],'originalAnglesPass':an['allOriginalDirectionDotsPass'],'wholePlanarMm':whole,'absoluteBusWindowPass':window,'reciprocalOwnWholeConductorDeficitUnionMm':exposure['exactNormalDeficitUnionLengthMm'],'absolute31_75Pass':exposure['absoluteTICapPass'],'actualOwnedPhysicalViaCount':2,'originalNativeFloorFixedWidthRule':True}
        good &= not blocked and st['clear'] and an['allOriginalDirectionDotsPass'] and window and exposure['absoluteTICapPass']
    if len(names)==2:
        values=[r['wholePlanarMm'] for r in checks.values()];good &= max(values)-min(values)<=.127+1e-8
    normalized=[{k:v for k,v in r.items() if k in ['sourceTraceId','role','class','layer','path','coupledSection','genuineCurvedArcPointRanges']} for r in raw.values()]
    record={'unit':unit,'records':normalized,'origin':origin,'label':label,'checks':checks}
    if good:candidate[key]=record;domains.setdefault(unit,[]).append(key)
    else:rejected.append({'key':key,**record})
for key,c in old['candidates'].items():
    if all(classes[r['sourceTraceId']]!='ADDR_CTRL' for r in c['records']):add(c['records'],c['origin'],'225 option freshly rechecked against literal227')
for n,options in ca['pools'].items():
    for r in options:assert r['sourceTraceId']==n;add([r],{'path':str(resetbase/'ALL24_CA_VARIABLE_POOLS_LITERAL227_LOCAL_REPAIR_SUCCESSOR.json'),'sha256':sha(resetbase/'ALL24_CA_VARIABLE_POOLS_LITERAL227_LOCAL_REPAIR_SUCCESSOR.json')},'new literal227 CA option')
reset=read(z.context['resetVariableCandidatePoolPin']['path'],z.context['resetVariableCandidatePoolPin']['sha256'])
for r in reset['records']:add([r],z.context['resetVariableCandidatePoolPin'],'literal227 real owned Reset2 option')
new17=BASE/'ddr-cpu19-cap-and-owned32-corner-sourceonly-next/SOURCE17_BOTTOM_AROUND4_AND14_AUTHORITATIVE_CONTEXT12_RECHECK29.json'
doc=read(new17,'15fe04647ea154ac20c3fd79304d6279f7f77abaefa4c4b5026a2c2d71e88af8')
points=doc.get('path',doc.get('result',{}).get('path'));assert points
add([{'sourceTraceId':'source_trace_17','role':'BYTE0_DATA','class':'DQ0','layer':'bottom','path':points}],{'path':str(new17),'sha256':sha(new17)},'new Source17Bottom leftwrap, actual227 recheck')
for path in sys.argv[2:]:
    doc=read(path);assert doc['contextSha256']==z.context['baseline225ContextPin']['sha256'] and doc['fullInputSha256']==old['pins'][str(s.INPUT)]
    rows=doc['records'];rows=list(rows.values()) if isinstance(rows,dict) else rows
    for r in rows:
        if classes[r['sourceTraceId']]=='DQ1':add([r],{'path':str(Path(path)),'sha256':sha(path)},'latest timed BYTE1 option freshly rechecked literal227')
# All46 units remain in the domain table, including empty ones; no request drop.
allunits=[*pairunits.values(),*sorted(set(z.connections)-pairnames)]
for u in allunits:domains.setdefault(u,[])
rank={'inner1':0,'inner2':1,'bottom':2,'top':3}
for u in domains:domains[u].sort(key=lambda k:(sum(rank[r['layer']] for r in candidate[k]['records']),sum(v['wholePlanarMm'] for v in candidate[k]['checks'].values())))
conflicts=[];comparisons=0
for i,a in enumerate(sorted(candidate)):
    for b in sorted(candidate)[i+1:]:
        if candidate[a]['unit']==candidate[b]['unit']:continue
        hit=None
        for ra in candidate[a]['records']:
            for rb in candidate[b]['records']:
                if ra['layer']!=rb['layer']:continue
                floor=.4064 if 'source_trace_10' in [ra['sourceTraceId'],rb['sourceTraceId']] else .2032
                pa=[(p['x'],p['y']) for p in ra['path']];pb=[(p['x'],p['y']) for p in rb['path']]
                for ia,(u,v) in enumerate(zip(pa,pa[1:])):
                    for ib,(x,y) in enumerate(zip(pb,pb[1:])):
                        dx=max(0.,min(u[0],v[0])-max(x[0],y[0]),min(x[0],y[0])-max(u[0],v[0]));dy=max(0.,min(u[1],v[1])-max(x[1],y[1]),min(x[1],y[1])-max(u[1],v[1]))
                        if dx*dx+dy*dy>=floor*floor:continue
                        comparisons+=1;distance=z.g.segdist(u,v,x,y)
                        if distance<floor-1e-9:hit={'a':a,'b':b,'sourceIds':[ra['sourceTraceId'],rb['sourceTraceId']],'segmentIndices':[ia,ib],'centerDistanceMm':distance,'requiredCenterMm':floor};break
                    if hit:break
                if hit:break
            if hit:break
        if hit:conflicts.append(hit)
coverage={b['busId']:{n:len(domains[pairunits.get(next((p for p in pairunits if n in p),frozenset()),n)]) for n in b['connectionNames']} for b in z.full['buses']}
report={'scope':'SOURCE_ONLY_LITERAL227_ALL49_GLOBAL_POOLED_CANDIDATE_MATERIAL_RECHECK','materialContextPin':{'path':str(z.CONTEXT),'sha256':sha(z.CONTEXT)},'numericInputPin':z.context['full49NumericInputPin'],'carrierInputPin':z.context['full49CarrierInputPin'],'nativeContextPin':z.context['fullNativeContextPin'],'baseline225ActualRootOutputNotAdoptedWithoutRecheck':True,'allOriginal225PhysicalDescriptorsAnd49NumericContactsHeld':True,'exactlyTwoAdditionalProposedOwnedResetBarrels':True,'physicalViaCount':227,'fixedTraceCount':263,'originalReferenceVias':129,'signalDogbones':98,'allOriginalBusAndPairConstraints':{'buses':z.full['buses'],'differentialPairs':z.full['differentialPairs']},'pins':pins,'controllerPin':{'path':str(Path(__file__).resolve()),'sha256':sha(Path(__file__).resolve())},'candidateCount':len(candidate),'candidates':candidate,'optionsByAtomicUnit':domains,'physicalMaterialRejections':rejected,'all46OriginalUnitsRetained':True,'emptyDomains':[u for u in allunits if not domains[u]],'coverageByOriginalBus':coverage,'actualPhysicalConflictGraph':conflicts,'exactSegmentComparisonsAfterCertifiedBBoxSkips':comparisons,'reservedGroundRegions':reserved,'geometrySourceOnlyNoRealSourceAssignedIds':True,'core04LacksOwned4AndReset2Integration':True,'referenceQualified':False,'electricalTimingPassed':False,'all49Accepted':False,'fabricationReady':False,'typescriptOrSdkNativeCoreCadCalls':0}
out=HERE/sys.argv[1];assert not out.exists();out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'path':str(out),'sha256':sha(out),'candidates':len(candidate),'empty':report['emptyDomains'],'rejected':len(rejected),'physicalConflicts':len(conflicts),'counts':{k:len(v) for k,v in domains.items()}}))
