#!/usr/bin/env python3
"""One sequential local field-model process with bounded wall time and sampled RSS."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
assert len(sys.argv) > 2
receipt = Path(sys.argv[1]).resolve()
assert not receipt.exists()
args = [sys.executable, str(HERE / "model.py"), *sys.argv[2:]]
environment = dict(os.environ)
for variable in ["OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
                 "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"]:
    environment[variable] = "1"
memory_file = Path("/sys/fs/cgroup/memory.current")
oom_file = Path("/sys/fs/cgroup/memory.events")


def events():
    return dict((key, int(value)) for key, value in
                (line.split() for line in oom_file.read_text().splitlines()))


started = time.monotonic()
before = events()
process = subprocess.Popen(args, cwd=HERE, env=environment, start_new_session=True,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
peak, shared_peak, count, stop = 0, 0, 0, None
while process.poll() is None:
    try:
        status = Path(f"/proc/{process.pid}/status").read_text()
        rss = next(int(line.split()[1]) * 1024 for line in status.splitlines()
                   if line.startswith("VmRSS:"))
    except (FileNotFoundError, StopIteration):
        rss = 0
    shared = int(memory_file.read_text())
    peak, shared_peak, count = max(peak, rss), max(shared_peak, shared), count + 1
    wall = time.monotonic() - started
    if wall > 60 or rss > 1024 ** 3 or shared > 28 * 1024 ** 3:
        stop = "wall60s" if wall > 60 else "ownedRSS1GiB" if rss > 1024 ** 3 else "shared28GiB"
        # This newly spawned process group belongs exclusively to this one job.
        if os.getpgid(process.pid) != process.pid:
            raise RuntimeError("Unexpected job group identity")
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        break
    time.sleep(0.05)
stdout, stderr = process.communicate()
after = events()
result = {"argv": args, "actualExitCode": process.returncode,
          "wallSeconds": time.monotonic() - started,
          "sampledPeakOwnedRssBytes": peak, "sampledPeakSharedBytes": shared_peak,
          "rssSamplePeriodSeconds": 0.05, "sampleCount": count,
          "resourceStop": stop, "oomEventsBefore": before, "oomEventsAfter": after,
          "oomEventDelta": {key: after[key] - before[key] for key in before},
          "singleBlasThreadEnvironment": {key: environment[key] for key in
              ["OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"]},
          "stdout": stdout, "stderr": stderr,
          "modelSha256": hashlib.sha256((HERE / "model.py").read_bytes()).hexdigest(),
          "guardSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "noNetworkOrRoutingOrBoardSourceMutation": True}
receipt.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: result[key] for key in ["actualExitCode", "wallSeconds",
                 "sampledPeakOwnedRssBytes", "resourceStop"]}))
print(stdout, end="")
if stderr:
    print(stderr, file=sys.stderr, end="")
raise SystemExit(0 if process.returncode == 0 and stop is None else 1)
