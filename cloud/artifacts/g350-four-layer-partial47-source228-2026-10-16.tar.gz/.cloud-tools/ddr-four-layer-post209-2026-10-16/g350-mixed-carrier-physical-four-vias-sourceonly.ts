/** SOURCE ONLY; separate v3 successor with actual-object terminal contact.
 * No imports, I/O, SDK execution, or native qualification here. Frozen7423
 * sources remain unchanged. Only genuine terminal circles/end caps receive an
 * initial contiguous contact exemption; off-terminal pads/stubs remain checked.
 * C31's whole-carrier validator rejects vias. This helper uses genuine C31
 * validation ONLY for individual planar runs, then checks explicit transitions,
 * all-layer via lands/drills, own fixed-copper reentry, and global self copper.
 * nativeSignalGeometryIsValid resets headings at vias; it is never treated as a
 * transition/DRC validator. Results are physical diagnostics, not timing proofs.
 */
type Row=Record<string,any>
export interface MixedPhysicalHelpers {
 VectorScene:any;fixedCopper:(input:Row)=>Row[]
 clearanceToCopper:(a:Row,b:Row,c:Row)=>number
 pointSegmentDistanceToPoints:(p:Row,a:Row,b:Row)=>number
 segmentDistance:(a:Row[],b:Row[])=>number
 nativeSignalGeometryIsValid:(trace:Row)=>boolean
 tuningPathIsSelfClear:(points:Row[],clearance:number)=>boolean
 boardOutlineViolations?:(input:Row,traces:Row[])=>Row[]
 BusLanesSolver:any
}
export interface MixedPhysicalResult {passed:boolean;physicalRunReports:Row[];newViaReports:Row[];fixedTerminalContactReports:Row[];errors:string[]}
const L=['top','inner1','inner2','bottom'],EPS=1e-8,W=.1016,VD=.4572,HD=.254
const near=(a:Row,b:Row)=>Math.hypot(a.x-b.x,a.y-b.y)<=EPS
const len=(a:Row,b:Row)=>Math.hypot(a.x-b.x,a.y-b.y)
const owner=(t:Row)=>t.connection_name??t.source_trace_id
/** The open parameter interval lying strictly inside a disk. Orthogonal
 * projection gives the circle roots without subtracting B*B-4*A*C. Factoring
 * (radius-perpendicular)*(radius+perpendicular) retains near-tangent slack.
 * The caller's radius already includes the original physical EPS tolerance;
 * no parameter-space dead zone suppresses a real outside interval.
 */
function circleInteriorInterval(a:Row,b:Row,c:Row,radius:number):[number,number]|null {
 const x=a.x-c.x,y=a.y-c.y,dx=b.x-a.x,dy=b.y-a.y,A=dx*dx+dy*dy
 if(A===0)return Math.hypot(x,y)<radius?[0,1]:null
 const span=Math.sqrt(A),perpendicular=Math.abs(x*dy-y*dx)/span,slack=(radius-perpendicular)*(radius+perpendicular)
 if(slack<=0)return null
 const center=-(x*dx+y*dy)/A,half=Math.sqrt(slack)/span
 const lo=Math.hypot(x,y)<radius?0:Math.max(0,center-half),hi=Math.hypot(b.x-c.x,b.y-c.y)<radius?1:Math.min(1,center+half)
 return hi>lo?[lo,hi]:null
}
/** Points are ordered OUTWARD from the exact incident via center. Exempt only
 * the initial connected component of contact with its clearance disk. Once a
 * segment actually leaves that disk, every later open-disk interval is reentry.
 * Touching the boundary without entering the exterior does not split contact.
 * Native and same-run self-clearance checks remain separate and mandatory.
 */
export function incidentLandContactReport(points:Row[],center:Row,radius:number):Row {
 const report:Row={passed:true,clearanceRadiusMm:radius,startsAtVia:!!points.length&&near(points[0],center),firstExit:null,reentries:[]}
 if(!report.startsAtVia||!Number.isFinite(radius)||radius<=0){report.passed=false;report.error='Incident run must start at actual via center with a finite positive radius';return report}
 let exited=false
 for(let i=1;i<points.length;i++){
  const a=points[i-1],b=points[i],span=len(a,b);if(span===0)continue
  const inside=circleInteriorInterval(a,b,center,radius)
  const dx=b.x-a.x,dy=b.y-a.y,t=Math.max(0,Math.min(1,((center.x-a.x)*dx+(center.y-a.y)*dy)/(span*span))),closest={x:a.x+t*dx,y:a.y+t*dy},hasInterior=Math.hypot(closest.x-center.x,closest.y-center.y)<radius
  // Use an independent closest-point predicate for reentry, so loss of a tiny
  // near-tangent root interval cannot silently qualify a penetration.
  if(exited){if(hasInterior){report.passed=false;report.reentries.push({segmentEndIndex:i,interval:inside,closestPoint:closest,entry:inside?{x:a.x+dx*inside[0],y:a.y+dy*inside[0]}:null,analyticIntervalUnresolved:inside===null})}continue}
  // With all previous vertices in the closed convex disk, this segment can
  // leave it iff its end is strictly outside. A boundary-only touch stays in
  // the initial connected contact component; there are no parameter dead zones.
  if(Math.hypot(b.x-center.x,b.y-center.y)>radius){exited=true;const parameter=inside?.[1]??(Math.hypot(a.x-center.x,a.y-center.y)>=radius?0:null);report.firstExit={segmentEndIndex:i,parameter,point:parameter===null?null:{x:a.x+dx*parameter,y:a.y+dy*parameter},analyticIntervalUnresolved:parameter===null}}
 }
 report.exited=exited;return report
}
/** input.traces: actual fixed fanouts and OTHER held carriers, not this trace.
 * Optional input.extraPhysicalHoles supplies actual fixed drill geometry as
 * {x,y,diameter,physicalId?,owners?:string[],layers?:string[]}. Include reference
 * vias/PTH/NPTH for exact drill checking. Missing nearby drill metadata fails
 * conservatively; an inflated NPTH obstacle is never called its actual drill.
 */
export function qualifyMixedCarrier(input:Row,connection:Row,trace:Row,H:MixedPhysicalHelpers):MixedPhysicalResult {
 const result:MixedPhysicalResult={passed:false,physicalRunReports:[],newViaReports:[],fixedTerminalContactReports:[],errors:[]}
 const error=(s:string)=>{if(!result.errors.includes(s)&&result.errors.length<200)result.errors.push(s)}
 try{
  const r:Row[]=trace.route??[],name=connection.name,clear=input.minTraceToPadEdgeClearance??.1016,viaClear=input.minViaEdgeToPadEdgeClearance??clear,holeClear=Math.max(input.minViaHoleEdgeToViaHoleEdgeClearance??0,input.minPlatedHoleDrillEdgeToDrillEdgeClearance??0),trackHole=input.minTraceToHoleEdgeClearance??.2,edge=input.minBoardEdgeClearance??0
  if(input.layerCount!==4||input.allowBlindAndBuriedVias!==false||!Array.isArray(input.allowedLayers)||L.some(l=>!input.allowedLayers.includes(l)))error('Requires actual four-layer fullspan-only input')
  if(owner(trace)!==name||!Array.isArray(connection.pointsToConnect)||connection.pointsToConnect.length!==2||r.length<2)error('Invalid original owner, terminal pair, or route')
  if(result.errors.length)return result
  if(!near(r[0],connection.pointsToConnect[0])||!near(r.at(-1)!,connection.pointsToConnect[1]))error('Broken original carrier endpoint coordinates')
  if(r[0].route_type!=='wire'||r.at(-1)!.route_type!=='wire')error('Carrier must begin/end with actual wire vertices')
  if(!H.nativeSignalGeometryIsValid(trace))error('Global native wire headings or curve-index metadata invalid')
  const runs:Row[]=[],events:Row[]=[];let points:Row[]=[],indices:number[]=[]
  const finish=()=>{if(!points.length)return;const run={index:runs.length,points,indices,layer:points[0].layer};runs.push(run);points=[];indices=[]}
  for(let i=0;i<r.length;i++){
   const p=r[i];if(!Number.isFinite(p.x)||!Number.isFinite(p.y)){error('Nonfinite vertex '+i);continue}
   if(p.route_type==='wire'){
    if(!L.includes(p.layer)||!Number.isFinite(p.width)||Math.abs(p.width-W)>EPS)error('Nonstandard wire layer/width at '+i)
    if(points.length&&points[0].layer!==p.layer)error('Layer changed without actual via at '+i)
    points.push(p);indices.push(i)
   }else if(p.route_type==='via'){
    const a=r[i-1],b=r[i+1]
    if(a?.route_type!=='wire'||b?.route_type!=='wire'||!near(a,p)||!near(b,p)||a.layer===b.layer||p.from_layer!==a.layer||p.to_layer!==b.layer)error('Discontinuous or same-layer via event '+i)
    if(!Array.isArray(p.layers)||p.layers.length!==4||new Set(p.layers).size!==4||L.some(l=>!p.layers.includes(l))||!Number.isFinite(p.via_diameter)||!Number.isFinite(p.via_hole_diameter)||Math.abs(p.via_diameter-VD)>EPS||Math.abs(p.via_hole_diameter-HD)>EPS)error('Via is not explicit fullspan .4572/.254 at '+i)
    finish();events.push({point:p,routeIndex:i,beforeRun:runs.length-1,afterRun:runs.length})
   }else error('Unsupported route primitive at '+i)
  }
  finish();if(events.length>4)error('More than four NEW fullspan carrier vias in this bounded search profile')
  const ownNames=new Set([name,connection.source_trace_id,...connection.pointsToConnect.flatMap((p:Row)=>[p.pointId,p.pcb_port_id])].filter(Boolean)),ownFixed=(input.traces??[]).filter((t:Row)=>owner(t)===name||connection.source_trace_id&&t.source_trace_id===connection.source_trace_id)
  for(const [side,p] of [[0,r[0]],[1,r.at(-1)!]] as const){
   const port=connection.pointsToConnect[side],supported=ownFixed.some((t:Row)=>t.route.some((q:Row)=>q.route_type==='via'&&near(p,q)&&q.layers?.includes(p.layer))||(p.layer==='top'&&near(t.route.at(-1),p)&&t.route.at(-1).layer==='top'))||(p.layer==='top'&&input.obstacles.some((o:Row)=>near(o.center,p)&&o.layers.includes('top')&&o.connectedTo.some((id:string)=>ownNames.has(id))&&[port.pointId,port.pcb_port_id].filter(Boolean).includes(o.circuitJsonMetadata?.pcb_port_id)))
   if(!supported)error('No authentic fixed contact on selected endpoint layer, side '+side)
  }
  const fixed:Row[]=H.fixedCopper(input),ownCopper:Row[]=[],terminalVias=ownFixed.flatMap((t:Row)=>(t.route??[]).filter((p:Row)=>p.route_type==='via'&&(near(p,r[0])||near(p,r.at(-1)!))).map((p:Row)=>({...p,physicalIdentity:t.pcb_trace_id})))
  // Keep material identity so a coincident pad/capsule never inherits a via's
  // exemption merely because it shares an electrical owner or approximate XY.
  for(const o of input.obstacles??[])if(o.connectedTo?.some((n:string)=>ownNames.has(n)))for(const c of H.fixedCopper({...input,obstacles:[o],traces:[]}))ownCopper.push({...c,materialKind:'obstacle',materialId:o.obstacleId??o.circuitJsonMetadata?.pcb_port_id,originalObstacle:o})
  for(const t of ownFixed)for(const c of H.fixedCopper({...input,obstacles:[],traces:[t]})){
   const via=(t.route??[]).find((p:Row)=>p.route_type==='via'&&!c.rect&&near(c.a,c.b)&&near(p,c.a)&&Number.isFinite(p.via_diameter)&&Math.abs(c.radius-p.via_diameter/2)<=EPS)
   ownCopper.push({...c,materialKind:via?'via-land':'trace-wire',materialId:t.pcb_trace_id,originalTrace:t,originalVia:via})
  }
  const segments:Row[]=[]
  for(const run of runs){
   const total=run.points.slice(1).reduce((s:number,p:Row,i:number)=>s+len(run.points[i],p),0),rr:Row={runIndex:run.index,layer:run.layer,pointCount:run.points.length,planarMm:total,passed:false};result.physicalRunReports.push(rr)
   if(run.points.length<2||total<=EPS){error('Zero/nonexistent planar run '+run.index);continue}
   const c={...connection,pointsToConnect:[run.points[0],run.points.at(-1)].map((p:Row)=>({x:p.x,y:p.y,layer:run.layer}))},curved=(trace.curvedSegments??[]).filter((end:number)=>run.indices.includes(end)&&run.indices.includes(end-1)).map((end:number)=>run.indices.indexOf(end)),t={...trace,pcb_trace_id:(trace.pcb_trace_id??name)+'_physical_run_'+run.index,route:run.points,coupledSection:undefined,curvedSegments:curved.length?curved:undefined},one={...input,connections:[c],buses:[],differentialPairs:[]}
   rr.selfClear=H.tuningPathIsSelfClear(run.points,W+clear);rr.nativeGeometry=H.nativeSignalGeometryIsValid(t)
   const v=H.BusLanesSolver.forValidation(one,[t],{smoothTuning:true,denseSearch:true,maxSearchIterations:2000000});for(let step=0;step<8&&!v.solved&&!v.failed;step++)v.step()
   rr.planarC31Validator={solved:v.solved,failed:v.failed,error:v.error,failureCode:v.failureCode};rr.passed=rr.selfClear&&rr.nativeGeometry&&v.solved
   if(!rr.passed)error('Planar run '+run.index+' failed physical/native/self check')
   let along=0
   for(let i=1;i<run.points.length;i++){const a=run.points[i-1],b=run.points[i],length=len(a,b);if(length>EPS)segments.push({a,b,length,layer:run.layer,run:run.index,local:i-1,along,total});along+=length}
  }
  const totalLength=(points:Row[])=>points.slice(1).reduce((sum:number,p:Row,i:number)=>sum+len(points[i],p),0)
  const contactArc=(points:Row[],disk:Row,identity:string)=>{
   const contact=incidentLandContactReport(points,disk.center,disk.radius),exit=contact.firstExit
   if(!contact.startsAtVia)throw Error('Actual terminal contact must start at its object center')
   if(!exit)return {arc:totalLength(points),contact:{physicalIdentity:identity,...contact}}
   if(exit.parameter===null)throw Error('Analytic terminal exit coordinate unresolved; no exemption qualification')
   let arc=0;for(let i=1;i<exit.segmentEndIndex;i++)arc+=len(points[i-1],points[i]);arc+=exit.parameter*len(points[exit.segmentEndIndex-1],points[exit.segmentEndIndex])
   return {arc,contact:{physicalIdentity:identity,...contact}}
  }
  // Same per-object policy as initialContiguousDiskContact/piecesOutside in
  // the reviewed pure clipping utility; retain every piece after FIRST EXIT.
  const objectPieces=(run:Row,start:Row|undefined,end:Row|undefined,identity:string)=>{
   const a=start?contactArc(run.points,start,identity):null,z=end?contactArc([...run.points].reverse(),end,identity):null,total=totalLength(run.points),from=a?.arc??0,until=total-(z?.arc??0),pieces:Row[]=[]
   if(a||z)result.fixedTerminalContactReports.push({runIndex:run.index,physicalIdentity:identity,startContact:a?.contact??null,endContact:z?.contact??null})
   let along=0;for(let i=1;i<run.points.length;i++){const u=run.points[i-1],v=run.points[i],span=len(u,v),lo=Math.max(along,from),hi=Math.min(along+span,until);if(span>0&&hi>lo){const x=(lo-along)/span,y=(hi-along)/span;pieces.push({a:{x:u.x+(v.x-u.x)*x,y:u.y+(v.y-u.y)*x},b:{x:u.x+(v.x-u.x)*y,y:u.y+(v.y-u.y)*y},analyticCutBoundary:!!(a&&lo===from||z&&hi===until)})}along+=span}return pieces
  }
  // Root reconstruction of an analytic exit may move its boundary a few ULPs.
  // This allowance applies ONLY to the piece touching that analytic cut, not
  // to later reentry pieces, off-terminal materials, or the physical EPS rule.
  const cutRoundoff=(p:Row,o:Row)=>p.analyticCutBoundary?64*Number.EPSILON*Math.max(1,...[p.a,p.b,o.a,o.b,o].filter(Boolean).flatMap((q:Row)=>[q.x,q.y].filter(Number.isFinite).map(Math.abs))):0
  const copperDisk=(c:Row,p:Row)=>{
   if(c.layer!==p.layer)return undefined
   let legitimate=false
   if(c.materialKind==='via-land')legitimate=near(c.originalVia,p)&&c.originalVia.layers?.includes(p.layer)&&Number.isFinite(c.originalVia.via_diameter)
   else if(c.materialKind==='trace-wire')legitimate=near(c.originalTrace.route.at(-1),p)&&(near(c.a,p)||near(c.b,p))
   else if(c.materialKind==='obstacle'&&!c.rect&&near(c.a,p)){
    const m=c.originalObstacle.circuitJsonMetadata??{},nativePort=m.pcb_port_id,endpoint=near(p,r[0])?connection.pointsToConnect[0]:connection.pointsToConnect[1]
    legitimate=!!nativePort&&p.layer==='top'&&[endpoint.pcb_port_id,endpoint.pointId].includes(nativePort)
   }
   return legitimate?{center:{x:p.x,y:p.y},radius:c.radius+W/2+clear-EPS}:undefined
  }
  // C31 masks own-net copper. Each actual object gets only its own endpoint
  // circle/end-cap exemption; a nonincident pad or stub has no exemption.
  for(const c of ownCopper)for(const run of runs){if(c.layer!==run.layer)continue;const start=run.index===0?copperDisk(c,r[0]):undefined,end=run.index===runs.length-1?copperDisk(c,r.at(-1)!):undefined,pieces=objectPieces(run,start,end,String(c.materialId));if(pieces.some(p=>H.clearanceToCopper(p.a,p.b,c)<W/2+clear-EPS-cutRoundoff(p,c)))error('Own fixed-copper reentry on run '+run.index+' against '+c.materialKind+' '+c.materialId)}
  for(let i=0;i<segments.length;i++)for(let j=i+1;j<segments.length;j++){const a=segments[i],b=segments[j];if(a.layer!==b.layer||a.run===b.run)continue;if(H.segmentDistance([a.a,a.b],[b.a,b.b])<W+clear-EPS)error('Nonadjacent same-layer runs intersect: '+a.run+'/'+b.run)}
  // Exact fixed drill events, optional raw holes, and conservative bounds for
  // otherwise unknown obstacle drills. Bounds are NOT fabricated drill sizes.
  const holes:Row[]=[]
  for(const t of input.traces??[])for(const p of t.route??[])if(p.route_type==='via'&&Number.isFinite(p.via_hole_diameter))holes.push({x:p.x,y:p.y,diameter:p.via_hole_diameter,layers:p.layers??L,owners:[owner(t),t.source_trace_id].filter(Boolean),physicalId:t.pcb_trace_id})
  for(const p of input.extraPhysicalHoles??[]){if(!Number.isFinite(p.x)||!Number.isFinite(p.y)||!(p.diameter>0)){error('Invalid extraPhysicalHoles row');continue}holes.push({...p,layers:p.layers??L,owners:p.owners??(p.owner?[p.owner]:[])})}
  const unknown:Row[]=[]
  for(const o of input.obstacles??[]){const m=o.circuitJsonMetadata??{},id=m.pcb_via_id??m.pcb_hole_id??m.pcb_plated_hole_id;if(!id)continue;if(holes.some(p=>p.physicalId===id||near(p,o.center)))continue;const actual=o.hole_diameter??o.holeDiameter??m.hole_diameter;if(Number.isFinite(actual)&&actual>0)holes.push({...o.center,diameter:actual,layers:o.layers,owners:o.connectedTo,physicalId:id});else unknown.push({...o.center,boundDiameter:o.shape==='circle'?o.width:Math.hypot(o.width,o.height),layers:o.layers,owners:o.connectedTo,physicalId:id})}
  for(const event of events){
   const p=event.point,vr:Row={routeIndex:event.routeIndex,x:p.x,y:p.y,fromLayer:p.from_layer,toLayer:p.to_layer,allFourLayersChecked:true,passed:true,violations:[]};result.newViaReports.push(vr)
   const bad=(s:string)=>{vr.passed=false;vr.violations.push(s);error('Via '+event.routeIndex+': '+s)}
   for(const c of fixed)if(L.includes(c.layer)&&H.clearanceToCopper(p,p,c)<VD/2+viaClear-EPS)bad('Land clearance to fixed '+JSON.stringify(c.owners??[])+', layer '+c.layer)
   for(const h of holes)if(Math.hypot(p.x-h.x,p.y-h.y)<HD/2+h.diameter/2+holeClear-EPS)bad('Drill clearance to '+(h.physicalId??'actual fixed hole'))
   for(const h of unknown)if(Math.hypot(p.x-h.x,p.y-h.y)<HD/2+h.boundDiameter/2+holeClear-EPS)bad('Actual drill metadata required near '+h.physicalId)
   const contactRadius=Math.max(VD/2+W/2+clear,HD/2+W/2+trackHole)-EPS
   vr.incidentLandContactReports=[]
   for(const run of runs){
    if(run.index===event.beforeRun||run.index===event.afterRun){
     const outward=run.index===event.beforeRun?[...run.points].reverse():run.points,contact=incidentLandContactReport(outward,p,contactRadius)
     vr.incidentLandContactReports.push({runIndex:run.index,outwardFrom:run.index===event.beforeRun?'run-end':'run-start',...contact})
     if(!contact.passed)bad('Own incident wire exits then reenters land on run '+run.index)
    }else for(const s of segments.filter(s=>s.run===run.index))if(H.pointSegmentDistanceToPoints(p,s.a,s.b)<contactRadius)bad('Own nonincident wire/land reentry on run '+s.run)
   }
   const b=input.bounds;if(!b||p.x<b.minX+VD/2+edge-EPS||p.x>b.maxX-VD/2-edge+EPS||p.y<b.minY+VD/2+edge-EPS||p.y>b.maxY-VD/2-edge+EPS)bad('Via land violates board bounds')
  }
  for(let i=0;i<events.length;i++)for(let j=i+1;j<events.length;j++){const d=len(events[i].point,events[j].point);if(d<Math.max(VD+viaClear,HD+holeClear)-EPS)error('New fullspan vias violate mutual land/drill spacing')}
  for(const h of holes)for(const run of runs){
   if(h.layers&&!h.layers.includes(run.layer))continue
   const actualTerminal=(p:Row)=>h.owners?.some((n:string)=>ownNames.has(n))&&near(h,p)&&terminalVias.some((v:Row)=>h.physicalId===v.physicalIdentity&&near(v,h)&&v.layers?.includes(run.layer)&&Number.isFinite(v.via_hole_diameter)&&Math.abs(v.via_hole_diameter-h.diameter)<=EPS)
   const radius=h.diameter/2+W/2+trackHole-EPS,start=run.index===0&&actualTerminal(r[0])?{center:r[0],radius}:undefined,end=run.index===runs.length-1&&actualTerminal(r.at(-1)!)?{center:r.at(-1)!,radius}:undefined,pieces=objectPieces(run,start,end,String(h.physicalId??'actual hole'))
   if(pieces.some(p=>H.pointSegmentDistanceToPoints(h,p.a,p.b)<radius-cutRoundoff(p,h)))error('Wire-to-fixed-drill clearance on run '+run.index+' against '+(h.physicalId??'actual hole'))
  }
  for(const s of segments){
   for(const h of unknown)if(h.layers?.includes(s.layer)&&H.pointSegmentDistanceToPoints(h,s.a,s.b)<h.boundDiameter/2+W/2+trackHole-EPS)error('Actual fixed drill metadata required near wire run '+s.run+': '+h.physicalId)
  }
  if(input.outline!==undefined&&!H.boardOutlineViolations)error('Exact board outline checker required')
  if(H.boardOutlineViolations){const violations=H.boardOutlineViolations(input,[trace]);if(violations.length)error('Mixed route violates actual board outline: '+JSON.stringify(violations.slice(0,4)))}
  result.passed=result.errors.length===0&&result.physicalRunReports.length>0&&result.physicalRunReports.every(r=>r.passed)&&result.newViaReports.every(r=>r.passed)
 }catch(e){error('Mixed physical validator exception: '+(e instanceof Error?e.message:String(e)))}
 return result
}
