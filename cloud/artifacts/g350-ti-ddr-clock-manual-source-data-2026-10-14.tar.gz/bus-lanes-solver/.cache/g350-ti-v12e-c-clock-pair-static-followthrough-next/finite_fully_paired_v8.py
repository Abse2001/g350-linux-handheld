import json,math,pathlib,heapq,time,hashlib
ROOT=pathlib.Path('/workspace/bus-lanes-solver/.cache'); OUT=ROOT/'g350-ti-v12e-c-clock-pair-static-followthrough-next'
CAP=ROOT/'g350-ti-v12e-c-runtime128-cpu34-active-observer-next/run/latest-clock-hard-scene.json'
CORE=pathlib.Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-core-qualification-source-next/run-core/fresh-core.circuit.json')
d=json.loads(CAP.read_text())['records'][0]['data'];core=json.loads(CORE.read_text()); margin=d['margin']; width=d['width']
P=lambda x,y:{'x':x,'y':y}
def dst(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])
def pt(p,a,b):
 dx=b['x']-a['x'];dy=b['y']-a['y'];q=dx*dx+dy*dy;t=max(0,min(1,((p['x']-a['x'])*dx+(p['y']-a['y'])*dy)/q)) if q else 0
 return math.hypot(p['x']-a['x']-t*dx,p['y']-a['y']-t*dy)
def seg(a,b,c,e):
 def cross(a,b,c):return (b['x']-a['x'])*(c['y']-a['y'])-(b['y']-a['y'])*(c['x']-a['x'])
 if max(a['x'],b['x'])>=min(c['x'],e['x']) and max(c['x'],e['x'])>=min(a['x'],b['x']) and max(a['y'],b['y'])>=min(c['y'],e['y']) and max(c['y'],e['y'])>=min(a['y'],b['y']) and cross(a,b,c)*cross(a,b,e)<=0 and cross(c,e,a)*cross(c,e,b)<=0:return 0
 return min(pt(a,c,e),pt(b,c,e),pt(c,a,b),pt(e,a,b))
def slack(a,b,c):return seg(a,b,c['a'],c['b'])-c['radius']-margin
def routecheck(path,copper):
 m=min((slack(a,b,c),j,c.get('tag',c['owners'])) for a,b in zip(path,path[1:]) for j,c in enumerate(copper))
 return {'length':sum(dst(a,b) for a,b in zip(path,path[1:])),'minSlack':m[0],'limitingCopper':m[2],'clear':m[0]>=-1e-9}
# Actual167 captured capsules plus additional129 reference vias. Remove only pair-owned planning geometry.
base=[c for c in d['hardCopper'] if 'source_trace_33' not in c['owners'] and 'reserved_pair_tail' not in c['owners']]
base += [{'a':P(v['x'],v['y']),'b':P(v['x'],v['y']),'radius':v['outer_diameter']/2,'layer':'inner1','owners':[v['pcb_via_id'],v['source_net_id']],'tag':v['pcb_via_id']} for v in core if v['type']=='pcb_via']
# Same geometry duplicates are harmless. Both own clock via circles are omitted per conductor, then restored for mate checks.
pair_vias=[]
for name in ('source_trace_33','source_trace_34'):
 con=next(c for c in d['input']['connections'] if c['name']==name)
 for p in con['pointsToConnect']:pair_vias.append({'a':p,'b':p,'radius':.2286,'layer':'inner1','owners':[name],'tag':name+'-fixed-via'})
base=[c for c in base if c['owners'] not in [['source_trace_33','source_trace_33'],['source_trace_33']]]
# Explicit short left/right CPU approach; source33 is relocated instead of obstructing source34.
def offset(path,amount):
 ns=[P(-(b['y']-a['y'])/dst(a,b),(b['x']-a['x'])/dst(a,b)) for a,b in zip(path,path[1:])]
 out=[]
 for i,p in enumerate(path):
  a=ns[max(0,i-1)];b=ns[min(len(ns)-1,i)];q=1+a['x']*b['x']+a['y']*b['y'];out.append(P(p['x']+amount*(a['x']+b['x'])/q,p['y']+amount*(a['y']+b['y'])/q))
 return out
center=[P(-4.4,12.2),P(-5,11.6),P(-5.8,11.6),P(-5.8,9.7),P(-5.4,9.3),P(-4.6,9.3)]
rail33=offset(center,-.1108);rail34=offset(center,.1108)
a=rail33[0];b=rail34[0]
cpu33=[P(-4,13.6),P(-4.4,13.2),P(-4.4,12.6),P(a['x'],12.6-abs(a['x']+4.4)),a]+rail33[1:]
cpu34=[P(-4,12.8),P(-3.6,12.4),P(-3.6,b['y']),b]+rail34[1:]
def railcopper(path,name):return [{'a':a,'b':b,'radius':width/2,'layer':'inner1','owners':[name],'tag':name+'-candidate'} for a,b in zip(path,path[1:])]
def copper_for(name,mate):return [c for c in base if name not in c['owners']]+[c for c in pair_vias if name not in c['owners']]+railcopper(mate,'mate')
# Finite, fixed .1mm manual waypoint lattice over localRAM rectangle. This is stdlib geometry, not solver output.
STEP=.1; XMIN=-7.;XMAX=4.;YMIN=.8;YMAX=11.2
nodes={(i,j):P(XMIN+i*STEP,YMIN+j*STEP) for i in range(round((XMAX-XMIN)/STEP)+1) for j in range(round((YMAX-YMIN)/STEP)+1)}
def clearseg(a,b,cs):
 for c in cs:
  r=c['radius']+margin
  if max(a['x'],b['x'])+r < min(c['a']['x'],c['b']['x']) or min(a['x'],b['x'])-r>max(c['a']['x'],c['b']['x']) or max(a['y'],b['y'])+r<min(c['a']['y'],c['b']['y']) or min(a['y'],b['y'])-r>max(c['a']['y'],c['b']['y']):continue
  if slack(a,b,c)<-1e-9:return False
 return True
def connector(a,b):
 dx=b['x']-a['x'];dy=b['y']-a['y'];q=min(abs(dx),abs(dy));sx=math.copysign(1,dx);sy=math.copysign(1,dy)
 return [[a,P(a['x']+sx*q,a['y']+sy*q),b],[a,P(b['x']-sx*q,b['y']-sy*q),b],[a,P(a['x'],b['y']),b],[a,P(b['x'],a['y']),b]]
def search(start,end,cs):
 st=time.monotonic();attachments={};targets={}
 for k,p in nodes.items():
  if dst(p,start)<.4:
   for path in connector(start,p):
    if all(clearseg(a,b,cs) for a,b in zip(path,path[1:])):attachments[k]=min(attachments.get(k,path),path,key=lambda z:sum(dst(a,b) for a,b in zip(z,z[1:])))
  if dst(p,end)<.4:
   for path in connector(p,end):
    if all(clearseg(a,b,cs) for a,b in zip(path,path[1:])):targets[k]=min(targets.get(k,path),path,key=lambda z:sum(dst(a,b) for a,b in zip(z,z[1:])))
 q=[];distances={};prev={};expanded=0;seen={};neighbor_cache={}
 for k,path in attachments.items():
  g=sum(dst(a,b) for a,b in zip(path,path[1:]));distances[k]=g;heapq.heappush(q,(g+dst(nodes[k],end),g,k));prev[k]=None
 while q and expanded<15000 and time.monotonic()-st<40:
  _,g,k=heapq.heappop(q)
  if g!=distances[k]:continue
  expanded+=1
  if k in targets:
   seq=[k]
   while prev[seq[-1]] is not None:seq.append(prev[seq[-1]])
   seq.reverse();path=attachments[seq[0]][:-1]+[nodes[t] for t in seq]+targets[k][1:]
   simple=[path[0]]
   for n,p in enumerate(path[1:-1],1):
    a=simple[-1];b=path[n+1]
    if abs((p['x']-a['x'])*(b['y']-p['y'])-(p['y']-a['y'])*(b['x']-p['x']))>1e-9:simple.append(p)
   simple.append(path[-1]);return {'path':simple,'expanded':expanded,'elapsed':time.monotonic()-st,'attachments':len(attachments),'targets':len(targets),'check':routecheck(simple,cs)}
  for di,dj in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
   t=(k[0]+di,k[1]+dj)
   if t not in nodes:continue
   ng=g+STEP*(math.sqrt(2) if di and dj else 1)
   if ng>=distances.get(t,math.inf):continue
   edge=tuple(sorted((k,t)));vis=neighbor_cache.get(edge)
   if vis is None:vis=neighbor_cache.setdefault(edge,clearseg(nodes[k],nodes[t],cs))
   if not vis:continue
   distances[t]=ng;prev[t]=k;heapq.heappush(q,(ng+dst(nodes[t],end),ng,t))
 return {'path':None,'expanded':expanded,'elapsed':time.monotonic()-st,'attachments':len(attachments),'targets':len(targets),'finiteLatticeFailureOnly':True}
ramCenter=json.loads((OUT/'finite-paired-RAM-center-result-v7.json').read_text())['centerSearch']['path']+[P(.8,4.6)]
def chamfer(path):
 out=[path[0]]
 for i,p in enumerate(path[1:-1],1):
  a=path[i-1];b=path[i+1];u=P((p['x']-a['x'])/dst(a,p),(p['y']-a['y'])/dst(a,p));v=P((b['x']-p['x'])/dst(p,b),(b['y']-p['y'])/dst(p,b));dot=u['x']*v['x']+u['y']*v['y']
  if abs(dot)<1e-8:
   trim=min(.15,dst(a,p)/3,dst(p,b)/3);out += [P(p['x']-trim*u['x'],p['y']-trim*u['y']),P(p['x']+trim*v['x'],p['y']+trim*v['y'])]
  else:out.append(p)
 out.append(path[-1]);return out
extra=21.5-17.840490004919207
left=-5.8-extra/2+.351471862576144/2
center=[P(-4.4,12.4),P(-5,11.8),P(-5.8,11.8),P(-5.8,11.4),P(left,11.4),P(left,10.6),P(-5.8,10.6),P(-5.8,9.7),P(-5.4,9.3),P(-4.6,9.3)]+ramCenter[1:]
oldLength=sum(dst(a,b) for a,b in zip(center,center[1:]))
temp=chamfer(center);loss=oldLength-sum(dst(a,b) for a,b in zip(temp,temp[1:]))
for p in center:
 if p['x']==left:p['x']-=loss/2
center=chamfer(center)
rail33=offset(center,.1108);rail34=offset(center,-.1108)
a=rail33[0];b=rail34[0]
cpu33=[P(-4,13.6),P(-3.6,13.2),P(-3.6,a['y']),a]
cpu34=[P(-4,12.8),P(-4,13.055),P(-4.428,13.483),P(-4.428,13.1),P(-4.4,13.072),P(-4.4,12.6),P(b['x'],12.6-abs(b['x']+4.4)),b]
end33=rail33[-1];end34=rail34[-1]
tail33=[end33,P(1.2,end33['y']-(1.2-end33['x'])),P(1.2,4.2)]
tail34=[end34,P(.4,end34['y']-(end34['x']-.4)),P(.4,4.2)]
paths={'source_trace_33':cpu33[:-1]+rail33+tail33[1:],'source_trace_34':cpu34[:-1]+rail34+tail34[1:]}
result={'scope':'fully-offset-common-clock-pair-static-v8','capturedSourceSha256':hashlib.sha256(CAP.read_bytes()).hexdigest(),'package101CoreSha256':hashlib.sha256(CORE.read_bytes()).hexdigest(),'sceneMarginAlreadyIncludesTraceRadius':margin,'pairGap':.12,'pairedCenter':center,'coupledSections':{'source_trace_33':[len(cpu33)-1,len(cpu33)+len(rail33)-2],'source_trace_34':[len(cpu34)-1,len(cpu34)+len(rail34)-2]},'accepted49':False,'fabricationReady':False,'nativeValidationRequired':True}
for name in paths:
 path=paths[name];other=paths[next(n for n in paths if n!=name)];check=routecheck(path,copper_for(name,other));whole=check['length']+1.1313708498984762
 result[name]={'path':path,'check':check,'fixedTopDogbonePlanarLength':1.1313708498984762,'wholePlanarLength':whole,'twoThroughViaNominalNativeLength':whole+3.2,'transitionCount':2,'viaDepthModelElectricalQualified':False}
result['wholePlanarPairSkew']=abs(result['source_trace_33']['wholePlanarLength']-result['source_trace_34']['wholePlanarLength'])
(OUT/'finite-fully-paired-result-v8.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('pairedCenter','source_trace_33','source_trace_34')},indent=2));print({n:{k:v for k,v in result[n].items() if k!='path'} for n in paths})
