#!/usr/bin/env python3
"""SOURCE ONLY. Root-run stdlib collector; never invokes SDKs or helpers.
Stages ONLY a new /tmp checkpoint because workspace disk reserve is insufficient.
Canonical archive member prefix is .cloud-tools/ddr-four-layer-post274-2026-10-16.
Cut294 is fixed. All295+ operational/CAD work remains outside this checkpoint.
"""
import argparse,copy,datetime,hashlib,json,os,re,shutil,stat
from pathlib import Path
BOARD=Path('/workspace/g350-linux-handheld')
BASE=BOARD/'.cloud-tools/ddr-four-layer-post259-v2-2026-10-16'
CANONICAL='.cloud-tools/ddr-four-layer-post274-2026-10-16'
SAVED=Path('/tmp/g350-source289-post274-checkpoint-20261016')
PROFILE_SHA='4d56c3c25837b38d83f98007fec29a40870cb43ad709b2af92baea7f7497dd26'
BASE_PINS={'PROGRESS.json':'0498f92fe9270d0eea497a9fa1bcc0ec66a7feae265c1138f7a73c4facaa4c08','README.md':'deb4eea0596a46593408ab77f036146557d440d130311009df19c271ed669997','WORKSPACE_HASH_INDEX.json':'af64eafc41c24680f64aa086cb006a5384df55c78d1fbe013bafff5f7e487382','WORKSPACE_RESTORE_MANIFEST.json':'99dac002c87c150a9b6b3a64b3b9865c181f4bb5c4c804be9a142142c19d1f9a'}
ARCHIVE=BOARD/'cloud/artifacts/g350-four-layer-both-bytes-matched49-source272-v2-2026-10-16.tar.gz'
ARCHIVE_SHA='4ebb4ac4e750534c62de43f200d01a3ad81bb0c05bae0369e87c75351cd71f4b'
ARCHIVE_MANIFEST=ARCHIVE.with_name('g350-four-layer-both-bytes-matched49-source272-v2-2026-10-16.manifest.json')
ARCHIVE_MANIFEST_SHA='4fbe88bedfde00ec5a632643745cb8994a9b9831ee2807338c6237661614067d'
SUMMARY=BOARD/'cloud/artifacts/g350-four-layer-source289-validation-summary-2026-10-16.json'
SUMMARY_SHA='84d9dcb9a1b1d1fe098b7ef7641c4c87e0aba0f479dd560ee5c423cc93e3cfd8'
SOLVER='/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib'
META={'README.md','PROGRESS.json','WORKSPACE_HASH_INDEX.json','WORKSPACE_RESTORE_MANIFEST.json'}
ALIASES={'candidate':'byte0-result.candidate.json','modelReport':'byte0-result.json','plan':'route-plan.json','capture':'source-capture.json','raw':'raw-core.json','controls':'core-controls.json','native16':'native-focused16.json','nativeComplement16':'native-complement16.json','native32Summary':'native32-coverage-summary.json','auth':'via-owner234.json'}
RESERVED=META|set(ALIASES.values())
FALSE={'all49Accepted':False,'fullBoardPassed':False,'fullTimingPassed':False,'electricalTimingQualified':False,'tiQualified':False,'referenceContinuityQualified':False,'cadQualified':False,'defaultBoardPromoted':False,'fabricationReady':False}
def need(v,m):
 if not v:raise ValueError(m)
def regular(p):return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
  if hasattr(os,'posix_fadvise'):os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 return h.hexdigest()
def read(p):return json.loads(p.read_bytes())
def md(p):return {'bytes':p.stat().st_size,'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)}
def exact(p,r):need(regular(p) and md(p)=={k:r[k] for k in ('bytes','sha256','mode')},'Exact regular bytes/hash/mode '+str(p))
def rel(v):
 p=Path(v);need(not p.is_absolute() and '..' not in p.parts and str(p)==v,'Contained relative saved path');return p
def write(p,d):
 with p.open('x') as f:os.fchmod(f.fileno(),0o600);json.dump(d,f,indent=2,allow_nan=False);f.write('\n')
def base_verify():
 need(BASE.resolve()==BASE and BASE.is_dir(),'Existing exact frozen Source272v2 dependency')
 for n,h in BASE_PINS.items():need(sha(BASE/n)==h,'Frozen base metadata unchanged')
 rows=read(BASE/'WORKSPACE_HASH_INDEX.json')['files'];need(len(rows)==118,'Exact frozen base118 rows')
 for r in rows:
  p=BASE/rel(r['path']);need(p.resolve().is_relative_to(BASE),'Contained frozen base payload');exact(p,r)
 need(regular(ARCHIVE) and ARCHIVE.stat().st_size==13615307 and sha(ARCHIVE)==ARCHIVE_SHA and sha(ARCHIVE_MANIFEST)==ARCHIVE_MANIFEST_SHA,'Published Source272v2 archive/manifest unchanged')
 need(read(BASE/'WORKSPACE_RESTORE_MANIFEST.json')['solverSourceRoot']==SOLVER,'Exact inherited solverSourceRoot')
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--profile',type=Path,default=Path('/tmp/g350-post274-source289-checkpoint-profile-sourceonly.json'));ap.add_argument('--profile-sha',required=True);args=ap.parse_args()
 need(args.profile_sha==PROFILE_SHA and regular(args.profile) and sha(args.profile)==PROFILE_SHA,'Explicit reviewed exact profile')
 p=read(args.profile);need(p['latestClosedScopeIncluded']==294 and len(p['runs'])==20 and [r['scope'] for r in p['runs']]==list(range(275,295)),'Cut exactly275–294')
 need(not SAVED.exists() and SAVED.parent==Path('/tmp'),'Fresh owned tmp checkpoint only');base_verify()
 current=copy.deepcopy(p['current']);cp=Path(current['candidate']['path']);current['modelReport']={'path':str(cp.with_name('byte0-result.json')),'sha256':sha(cp.with_name('byte0-result.json'))}
 by_path={r['path']:r for r in p['artifacts']};need(len(by_path)==len(p['artifacts'])==138,'Exact138 profile artifacts')
 for r in p['artifacts']:exact(Path(r['path']),r)
 for k,r in current.items():need(r['path'] in by_path and by_path[r['path']]['sha256']==r['sha256'],'Current explicit pin '+k)
 need(regular(SUMMARY) and sha(SUMMARY)==SUMMARY_SHA,'Exact compact public validation summary')
 c,model,plan,cap,ctrl,native,auth,complement,union=[read(Path(current[k]['path'])) for k in ['candidate','modelReport','plan','capture','controls','native16','auth','nativeComplement16','native32Summary']]
 owners={'source_trace_'+str(i) for i in range(49)}
 for d in (c,model):
  need(d['all49Connected'] is True and d['allSavedCarriersCurrentSceneQualified'] is True and len(d['finalScenePhysicalReports'])==49 and all(q['passed'] is True for q in d['finalScenePhysicalReports']),'Current286 all49 physical reports')
  need(len(d['criticalValidationViews'])==2 and all(v['passed'] is True and v['c31']['solved'] is True and set(v['reports'])=={'bus','pair','shared','coupling','exterior'} and all(len(rs)==3 and all(q['matched'] for q in rs) for rs in v['reports'].values()) for v in d['criticalValidationViews']),'Both actual critical views fresh/full5 APIs')
 need(plan['inputBindings']['candidate']['sha256']==current['candidate']['sha256'] and cap['passed'] is True and cap['fullInverseSourceTreePassed'] is True and cap['parentNormalizationInversePassed'] is True,'Current287/288 projection/capture')
 need(ctrl['candidateSha256']==current['candidate']['sha256'] and ctrl['planSha256']==current['plan']['sha256'] and ctrl['actualCaptureSha256']==current['capture']['sha256'] and ctrl['rawCoreSha256']==current['raw']['sha256'],'Exact current289 replay bindings')
 need(ctrl['freshCoreDerived'] is True and ctrl['all49Connected'] is True and len(ctrl['checks'])==35 and all(q['passed'] is True for q in ctrl['checks']) and len(ctrl['physicalGraphs'])==49 and {q['originalSourceTraceId'] for q in ctrl['physicalGraphs']}==owners and all(q['physicallyConnectedByActualOwnedNumericIdGraph'] for q in ctrl['physicalGraphs']),'Actual35/49 controls')
 counts=ctrl['expectedCounts'];need(counts['physicalVias']==234 and counts['physicalTraces']==317 and ctrl['cap8HardwareDelta']==plan['cap8HardwareDelta'] and ctrl['cap12HardwareDelta']==plan['cap12HardwareDelta'],'Exact current material/hardware')
 timing=ctrl['timingObservations'];co={r['cohort']:r for r in timing['cohorts']}
 need(co['DDR_BYTE0']['withinTolerance'] is True and co['DDR_BYTE1']['withinTolerance'] is True and co['DDR_COMMAND_CLOCK']['withinTolerance'] is False and abs(co['DDR_COMMAND_CLOCK']['skewMm']-17.662818756581967)<1e-9,'Current actual289 timing, not272 timing')
 need(sum(q.get('cohort')=='DDR_COMMAND_CLOCK' and q.get('timingObservationOnly',{}).get('aboveMinimum') is True for q in ctrl['generatedWireChecks'])==15,'Actual15/26 CA minimum observations')
 results=[]
 for d in (native,complement):
  need(d['completed'] is True and d['finished'] is True and d['completedCheckCount']==16 and d['exceptionCount']==0 and d['allPinnedInputsUnchanged'] is True,'Both fresh native16 invocations complete')
  for k,ck in [('raw','raw'),('controls','controls'),('reviewedSourcePlan','plan')]:need(d['inputBindings'][k]['sha256']==current[ck]['sha256'],'Native same current input')
  results.extend(d['results'])
 names=[r['name'] for r in results];need(len(names)==len(set(names))==32 and set(names)==set(complement['original32CheckNames']),'Exact disjoint original32 union')
 expected_findings={'checkPcbBusLengthSkew':1,'checkSourceTracesHavePcbTraces':70,'checkEachPcbPortConnectedToPcbTraces':718,'checkSourceTracesMatchPcbTraceThickness':162}
 need(all(r['state']=='completed' and r['findingCount']==expected_findings.get(r['name'],0) for r in results),'All unfiltered native findings retained')
 need(union['all32FreshCallsCompleted'] is True and union['exceptions']==0 and union['totalUnfilteredFindings']==951 and union['thicknessFindingsForThe49DirectLogicalDdrSignalDeclarations']==0 and union['nativeBoardPassed'] is False,'Pinned complete native32 coverage summary without board pass')
 need(auth['complete'] is True and auth['actualViaCount']==auth['completedViaCount']==234 and auth['foreignViaTrackCopperClearancePassed'] is True and auth['exactInputFilesUnchanged'] is True and all(auth[k]==[] for k in ['violations','ambiguousVias','identityFailures','invalidSegments','unresolvedSegmentOwners']),'Current291 authenticated234 no omissions')
 raw=read(Path(current['raw']['path']));pour_ids=[q['pcb_copper_pour_id'] for q in raw if q.get('type')=='pcb_copper_pour'];need(len(pour_ids)==19 and len(set(pour_ids))==19,'Actual19 current unqualified pours')
 receipts=[]
 for rr in p['runs']:
  folder=Path(rr['folder']);closed=read(folder/'COLLECTED.json');e=closed.get('execution')
  need(closed['scope']==rr['scope'] and closed.get('closedAt') and closed['sourcePinsUnchanged'] is True and closed['protectedFilesUnchanged'] is True,'Exact closed public scope')
  if rr['scope']==275:need(e is None and rr['exitCode'] is None,'275 admission refusal, not an SDK result')
  else:need(e is not None and e['exitCode']==rr['exitCode'] and e['cleanupOwnedGroupEmpty'] is True,'Exact actual closed execution')
  need(rr['exitCode']==(None if rr['scope']==275 else 2 if rr['scope'] in (276,277) else 0),'Preserved negative/success exit statuses')
  receipts.append({**rr,'closedAt':closed['closedAt'],'qualificationInheritedBySource289':False})
 base_manifest=read(BASE/'WORKSPACE_RESTORE_MANIFEST.json');base_progress=read(BASE/'PROGRESS.json')
 for r in p['baseDependencyReferences']:
  exact(Path(r['restorePath']),r);folder=BOARD/r['baseSavedDirectory'];need(folder.resolve().is_relative_to(BOARD/'.cloud-tools'),'Contained declared base folder');exact(folder/rel(r['savedPath']),r)
 extras=[args.profile,Path(__file__),Path('/tmp/g350-author-post274-source289-profile-sourceonly.py'),SUMMARY]
 total=p['plannedCopiedArtifactBytes']+sum(Path(current[k]['path']).stat().st_size for k in ALIASES)+sum(q.stat().st_size for q in extras)
 need(total<256*1024**2,'Reviewed under256MiB planned tmp staging bound')
 need(shutil.disk_usage('/tmp').free>total+1024**3,'Tmp capacity plus1GiB reserve')
 need(int(Path('/sys/fs/cgroup/memory.current').read_text())+total+1024**3<30*1024**3,'Tmpfs charge keeps shared30GiB/+1GiB reserve')
 SAVED.mkdir(mode=0o700);targets={};workspace=[];seen={};inputs={}
 def collect(q,label=None):
  q=Path(q);data=md(q);need(regular(q),'Regular public input only');inputs[str(q)]=data
  if str(q) in seen:return seen[str(q)]
  n=label or q.name
  if n in RESERVED:n='DEPENDENCY_'+data['sha256'][:16]+'_'+n
  dst=SAVED/n;need(dst.parent==SAVED,'Flat confined staging')
  if dst.exists() and md(dst)!=data:dst=SAVED/(dst.stem+'__'+data['sha256'][:16]+dst.suffix)
  if not dst.exists():
   with q.open('rb') as src,dst.open('xb') as out:shutil.copyfileobj(src,out,1048576);os.fchmod(out.fileno(),data['mode'])
  need(md(dst)==data,'Exact staged byte/hash/mode')
  row={'savedPath':dst.name,'restorePath':str(q),**data};seen[str(q)]=row
  if str(q).startswith('/tmp/g350-'):targets[str(q)]=row
  else:workspace.append({**row,'boardRelativePath':q.relative_to(BOARD).as_posix(),'dataOnlyEvidenceCopy':True,'legacyWorkspaceHelperRestoresThisFile':False})
  return row
 for r in p['artifacts']:
  q=Path(r['path']);label=None
  for rr in p['runs']:
   f=Path(rr['folder'])
   if q.is_relative_to(f):label='SCOPE'+str(rr['scope'])+'_'+('owned_' if q.parent.name=='owned' else '')+q.name;break
  collect(q,label)
 for q in extras:collect(q)
 aliases={}
 for key,name in ALIASES.items():
  row=seen[current[key]['path']];src=SAVED/row['savedPath'];out=SAVED/name
  with src.open('rb') as f,out.open('xb') as g:shutil.copyfileobj(f,g,1048576);os.fchmod(g.fileno(),row['mode'])
  need(md(out)=={k:row[k] for k in ['bytes','sha256','mode']},'Exact canonical alias')
  aliases[name]={'canonicalSavedPath':row['savedPath'],**row}
 current_saved={k:seen[r['path']] for k,r in current.items()}
 milestone={'scope':'SOURCE289_CONNECTED49_BOTH_BYTES_PASS_CA15_OF26_NATIVE32_WITH951_FINDINGS_NO_CURRENT_POUR_OR_CAD_PASS','candidateSha256':current['candidate']['sha256'],'savedCandidate':ALIASES['candidate'],'routedOwners':49,'pendingOwnerIds':[],'freshCoreScope':289,'all35CoreControlsPassed':True,'timingObservations':timing,'byte0PlanarSkewPassed':True,'byte1PlanarSkewPassed':True,'caMinimumPassingCount':15,'caUnderMinimumCount':11,'caMemberCount':26,'caPlanarSkewPassed':False,'all32FreshNativeCallsCompleted':True,'nativeUnfilteredFindingCount':951,'nativeBoardPassed':False,'direct49DdrThicknessFindingCount':0,'authenticated234ViaTrackPassed':True,'currentLiteralPourCount':19,'currentLiteralPourQualificationPending':True,'source272PourQualificationInherited':False,'currentCadQualificationPending':True,'source272CadExportQualificationInherited':False,'resumeRoutingFromThisCheckpoint':True,**current_saved,**FALSE}
 dep={**read(ARCHIVE_MANIFEST)['archive'],'manifest':ARCHIVE_MANIFEST.relative_to(BOARD).as_posix(),'manifestSha256':ARCHIVE_MANIFEST_SHA,'mustBeRestoredFirst':True,'payloadCopiedByThisCollector':False}
 deps=copy.deepcopy(base_progress['baseArchiveDependenciesInRestoreOrder'])+[dep]
 common={'scope':milestone['scope'],'updatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozenCheckpoint':True,'latestClosedScopeIncluded':294,'freezeBoundary':{'latestClosedScope':294,'sourceCoreScope':289,'candidateSha256':current['candidate']['sha256'],'laterWorkRequiresNewSavedDirectory':True},'canonicalArchiveSavedDirectory':CANONICAL,'actualTmpStagingDirectory':str(SAVED),'workspaceCheckpointFolderCreated':False,'primaryCandidate':milestone,'latestSourceVerifiedCheckpoint':milestone,'independentFallbacks':{'source272':base_progress['latestSourceVerifiedCheckpoint'],'olderFallbacks':base_progress['independentFallbacks'],'independentNotInherited':True},'baseArchiveDependency':dep,'baseArchiveDependenciesInRestoreOrder':deps,'source289UnqualifiedActualPourIds':pour_ids,'later295PlusWorkExcluded':True,**FALSE}
 mf={**common,'solverSourceRoot':base_manifest['solverSourceRoot'],'files':sorted(targets.values(),key=lambda r:r['restorePath']),'baseDependencyRestoreFiles':p['baseDependencyReferences'],'workspaceEvidenceCopies':workspace,'immutableWorkspaceAssets':[],'immutableAssetsRestoredByBaseArchives':base_manifest['immutableAssetsRestoredByBaseSource257Archive'],'aliases':aliases}
 need(mf['solverSourceRoot']==SOLVER,'Carry exact solverRoot for complete existing --restore branch')
 progress={**common,'closedExperiments':receipts,'profileSha256':PROFILE_SHA,'plannedPayloadBytesBeforeMetadata':total,'collectorSource':str(Path(__file__)),'payloadsStagedByOwnPythonStdlib':True,'sdkExecutedByCollector':False,'archiveCreated':False,'gitExecuted':False,'cloudDocumentEdited':False,'aliases':aliases}
 for n,r in inputs.items():exact(Path(n),r)
 for r in p['artifacts']:exact(Path(r['path']),r)
 base_verify();write(SAVED/'WORKSPACE_RESTORE_MANIFEST.json',mf)
 text='''Resume routing from Source289: all49 actual numeric DDR graphs, Core35/35.
Both original .635mm byte skews PASS; CA FAILS17.6628187566mm skew.15/26 CA
members meet unchanged20.95mm minimum;11 remain below. Original constraints stay.
Native290+294 executed the exact disjoint original32 calls with0 exceptions.
ALL951 findings remain:70 missing board source paths,718 unconnected PCB ports,
162 width warnings (0 for direct49 DDR logical declarations),1 CA bus-skew.
Native board qualification and full board acceptance remain FALSE.
Auth291 checks234 real vias with no foreign via-track/unknown-owner omissions.
Current Source28919 literal pours are NOT independently qualified. No Source272
pour/PDN/CAD result is inherited. Source272 stock export285 is a separate data
artifact; no current Source289 CAD/plane/TI/SI/default/fabrication pass is claimed.

This is a new /tmp-staged checkpoint, canonical archive member folder:
.cloud-tools/ddr-four-layer-post274-2026-10-16. Earlier frozen folders stay intact.
Cut275–294 includes275 admission refusal,276/277 exit2 failures, actual294 all16
completed in162s (NOT timeout),292/293 PRoot prerequisites (NOT KiCad results).
All295+ CAD work is excluded. PRoot is path translation, not kernel RO/network
isolation. ROOTFS.json is evidence only:1.5GB image/rootfs material is not copied.

Restore five prior archives209→228→248→257→272-v2 before this archive. Restore
this canonical folder, then use the pinned existing workspace helper with
--saved-directory <folder> (verify first; --restore refuses differing files).
solverSourceRoot is carried literally. Workspace export/rootfs-manifest copies
are data-only artifacts in workspaceEvidenceCopies; the legacy /tmp helper does
not overwrite workspace inputs. PRoot packages/tools/rootfs and their aliases
require separately reviewed exact reconstruction; no CAD readiness is implied.
No collector SDK, archive, Docker/PRoot, helper, or git execution occurred.
'''
 with (SAVED/'README.md').open('x') as f:os.fchmod(f.fileno(),0o600);f.write(text)
 progress['artifacts']=[{'path':q.name,**md(q)} for q in sorted(SAVED.iterdir()) if regular(q)];write(SAVED/'PROGRESS.json',progress)
 rows=[{'path':q.name,**md(q)} for q in sorted(SAVED.iterdir()) if regular(q)];write(SAVED/'WORKSPACE_HASH_INDEX.json',{'scope':milestone['scope'],'files':rows,'selfExcluded':True,'frozenCheckpoint':True})
 for r in rows:exact(SAVED/r['path'],r)
 base_verify();print(json.dumps({'savedDirectory':str(SAVED),'canonicalArchiveSavedDirectory':CANONICAL,'files':len(rows)+1,'indexRows':len(rows),'tmpRestoreTargets':len(targets),'workspaceDataOnlyEvidenceCopies':len(workspace),'baseReferences':len(p['baseDependencyReferences']),'exactStagedPayloadBytesBeforeMetadata':total,'actualAllFileBytes':sum(q.stat().st_size for q in SAVED.iterdir() if regular(q)),'metadataSha256':{n:sha(SAVED/n) for n in sorted(META)},'workspaceFolderCreated':False,'sdkExecuted':False,'fabricationReady':False},indent=2))
if __name__=='__main__':main()
