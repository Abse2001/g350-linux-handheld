"""Lossless DRC-selected Silk->Fab edit; reject every other lexical change."""
from pathlib import Path
import collections
import hashlib
import json
import re
import sys

TOKEN = re.compile(r'\s+|"(?:\\.|[^"\\])*"|[()]|[^\s()"]+')


def digest(data):
    return hashlib.sha256(data.encode()).hexdigest()


def parse(text):
    tokens, stack, roots, nodes = [], [], [], []
    position = 0
    for match in TOKEN.finditer(text):
        if match.start() != position:
            raise ValueError("Unparsed lexical content")
        position = match.end()
        raw = match.group()
        if raw.isspace():
            continue
        index = len(tokens)
        tokens.append((raw, match.start(), match.end()))
        if raw == "(":
            node = {"start": index, "children": [], "parent": stack[-1] if stack else None}
            (stack[-1]["children"] if stack else roots).append(node)
            nodes.append(node)
            stack.append(node)
        elif raw == ")":
            if not stack:
                raise ValueError("Unexpected closing parenthesis")
            stack.pop()["end"] = index
        else:
            if not stack:
                raise ValueError("Atom outside board root")
            stack[-1]["children"].append(index)
    if position != len(text) or stack or len(roots) != 1:
        raise ValueError("Incomplete board expression")
    return tokens, nodes


def atom(tokens, index):
    raw = tokens[index][0]
    return json.loads(raw) if raw.startswith('"') else raw


def head(tokens, node):
    return atom(tokens, node["children"][0])


def child(tokens, node, name):
    found = [x for x in node["children"] if isinstance(x, dict) and head(tokens, x) == name]
    if len(found) > 1:
        raise ValueError("Ambiguous direct field")
    return found[0] if found else None


def check(original, candidate, replacements):
    before, _ = parse(original)
    after, _ = parse(candidate)
    if len(before) != len(after):
        raise AssertionError("Lexical token count changed")
    for index, (a, b) in enumerate(zip(before, after)):
        expected = replacements.get(index, a[0])
        if b[0] != expected:
            raise AssertionError(f"Unexpected token change at {index}: {a[0]} -> {b[0]}")
    rebuilt = original
    for index, raw in sorted(replacements.items(), reverse=True):
        _, start, end = before[index]
        rebuilt = rebuilt[:start] + raw + rebuilt[end:]
    if rebuilt != candidate:
        raise AssertionError("Nonselected bytes or whitespace changed")


def run(source, report, output):
    if output.exists() or Path(str(output) + ".negative-drill-mutated").exists():
        raise ValueError("Fresh output paths required; preserve previous candidates")
    original = source.read_text()
    drc = json.loads(report.read_text())
    selected = {item["uuid"] for violation in drc["violations"]
                if violation["type"] in {"silk_overlap", "silk_over_copper", "silk_edge_clearance"}
                for item in violation["items"]
                if item["description"].startswith(("Reference field of ", "Segment of "))}
    tokens, nodes = parse(original)
    replacements, changes, found = {}, [], set()
    for node in nodes:
        uid, layer = child(tokens, node, "uuid"), child(tokens, node, "layer")
        if not uid or not layer or atom(tokens, uid["children"][1]) not in selected:
            continue
        identity = atom(tokens, uid["children"][1])
        kind = head(tokens, node)
        if not (kind == "property" and atom(tokens, node["children"][1]) == "Reference"
                or kind in {"fp_line", "fp_arc", "fp_circle", "fp_rect", "fp_poly", "fp_text", "fp_text_box"}):
            raise AssertionError("Selected UUID is not permitted reference/footprint ink")
        index = layer["children"][1]
        old = atom(tokens, index)
        if old not in {"F.SilkS", "B.SilkS"} or identity in found:
            raise AssertionError("Selected ink must have unique original Silk layer")
        new = "F.Fab" if old == "F.SilkS" else "B.Fab"
        replacements[index] = json.dumps(new)
        found.add(identity)
        owner = node["parent"]
        while owner and head(tokens, owner) != "footprint":
            owner = owner["parent"]
        if not owner:
            raise AssertionError("Selected ink lost its footprint owner")
        changes.append({"uuid": identity, "kind": kind, "from": old, "to": new,
                        "ownerUuid": atom(tokens, child(tokens, owner, "uuid")["children"][1])})
    if found != selected or not changes:
        raise AssertionError("Not all selected reference/graphic UUIDs matched exactly")
    candidate = original
    for index, raw in sorted(replacements.items(), reverse=True):
        _, start, end = tokens[index]
        candidate = candidate[:start] + raw + candidate[end:]
    check(original, candidate, replacements)
    drill = next(n for n in nodes if head(tokens, n) == "drill"
                 and isinstance(n["children"][1], int)
                 and re.fullmatch(r"[0-9.]+", atom(tokens, n["children"][1])))
    drill_index = drill["children"][1]
    numeric = float(atom(tokens, drill_index))
    negative = candidate
    candidate_tokens, _ = parse(candidate)
    _, start, end = candidate_tokens[drill_index]
    negative = negative[:start] + str(numeric + 0.001) + negative[end:]
    rejected = False
    try:
        check(original, negative, replacements)
    except AssertionError:
        rejected = True
    if not rejected:
        raise AssertionError("Negative drill mutation was not rejected")
    output.write_text(candidate)
    Path(str(output) + ".negative-drill-mutated").write_text(negative)
    result = {"originalBoardSha256": digest(original), "boardSha256": digest(candidate),
              "drcReportSha256": hashlib.sha256(report.read_bytes()).hexdigest(),
              "selectedInkRecords": len(changes), "selectedKinds": dict(collections.Counter(c["kind"] for c in changes)),
              "changes": changes, "allOtherTokensAndBytesIdentical": True,
              "tokenCount": len(tokens), "drillMutationRejected": rejected,
              "zoneNameOrderUnchanged": True, "requiresFreshLibraryAndAllRuleDrc": True,
              "accepted49": False, "fabricationReady": False}
    Path(str(output) + ".selected-ink-proof.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "changes"}))


if __name__ == "__main__":
    run(*(Path(name) for name in sys.argv[1:4]))
