"""Authorization/policy mocks only; no actual child, source export or signal."""
from pathlib import Path
import importlib.util,unittest
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v7_guard_mock',ROOT/'guard.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
class Tests(unittest.TestCase):
 def value(self):return {'authorizedByRoot':True,'packetSha256':'a'*64,'policy':g.POLICY,'scope':'one-ti-v7-ram-right-source-only-no-router-no-cad','approvalToken':'b'*64}
 def test_exact_policy_root_receipt(self):g.receipt(self.value(),'a'*64);self.assertEqual(g.POLICY,{'wallSeconds':60,'rssBytes':2*1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5})
 def test_no_authority_or_wrong_packet_rejected(self):
  for key,value in [('authorizedByRoot',False),('packetSha256','c'*64),('scope','one-ti-v6-alternate-cohort-source-only-no-router-no-cad')]:
   x=self.value();x[key]=value
   with self.assertRaises(ValueError):g.receipt(x,'a'*64)
 def test_policy_and_nonce_cannot_change(self):
  for key,value in [('policy',{**g.POLICY,'rssBytes':3*1024**3}),('approvalToken','not-a-nonce')]:
   x=self.value();x[key]=value
   with self.assertRaises(ValueError):g.receipt(x,'a'*64)
if __name__=='__main__':unittest.main()
