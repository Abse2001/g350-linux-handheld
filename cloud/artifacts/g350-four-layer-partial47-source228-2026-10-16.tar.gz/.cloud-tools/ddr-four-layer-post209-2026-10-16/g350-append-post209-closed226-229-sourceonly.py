#!/usr/bin/env python3
"""Append closed public226-229 and fresh Source47 evidence; no SDK/archive."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat

ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post209-2026-10-16'
BASE = ROOT / '.cloud-tools/ddr-four-layer-manual-2026-10-16'
BASE_PINS = {'WORKSPACE_HASH_INDEX.json': '7d471d7f282e2b50e8a10991a50946b6068d114e4f79d7c0b85ee2d26701e6eb',
             'WORKSPACE_RESTORE_MANIFEST.json': '6937e1bd2512ec77d3c9adc97c45c9d5f8e09d420b613b2ca9151ee683102e3d',
             'PROGRESS.json': '2d255e885f078cef97fc7b698b7a9f71025418fabcd07eca4c64f10d18d6f437'}

def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        while chunk := f.read(1024 * 1024): h.update(chunk)
        os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return h.hexdigest()

def read(p):
    with p.open('rb') as f:
        value = json.load(f); os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return value

def write(p, value):
    temporary = p.with_name(p.name + '.append229')
    with temporary.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n')
    os.replace(temporary, p)

def main():
    for name, digest in BASE_PINS.items(): assert sha(BASE / name) == digest
    mfile, pfile, ifile = [SAVED / name for name in ('WORKSPACE_RESTORE_MANIFEST.json', 'PROGRESS.json', 'WORKSPACE_HASH_INDEX.json')]
    manifest, progress = read(mfile), read(pfile)
    targets = {v['restorePath']: v for v in manifest['files']}
    assert len(targets) == len(manifest['files'])
    for p in (mfile, pfile, ifile, SAVED / 'README.md'):
        dest = SAVED / 'history' / (p.stem + '.before-closed229.' + sha(p)[:16] + p.suffix)
        dest.parent.mkdir(exist_ok=True)
        with p.open('rb') as a, dest.open('xb') as b:
            shutil.copyfileobj(a, b); os.fchmod(b.fileno(), stat.S_IMODE(p.stat().st_mode))
    def save(source, name=None):
        source = Path(source)
        assert str(source).startswith('/tmp/g350-') and source.is_file() and not source.is_symlink()
        assert not any(v.upper().startswith(('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT')) for v in source.parts)
        digest, mode = sha(source), stat.S_IMODE(source.stat().st_mode)
        if str(source) in targets:
            old = targets[str(source)]; assert old['sha256'] == digest and old['bytes'] == source.stat().st_size and old['mode'] == mode
            return old
        dest = SAVED / (name or source.name)
        if dest.exists() and sha(dest) != digest: dest = dest.with_name(dest.stem + '__' + digest[:16] + dest.suffix)
        if not dest.exists():
            with source.open('rb') as a, dest.open('xb') as b:
                shutil.copyfileobj(a, b, 1024 * 1024); os.fchmod(b.fileno(), mode)
                os.posix_fadvise(a.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
        assert sha(dest) == digest and stat.S_IMODE(dest.stat().st_mode) == mode
        row = {'savedPath': dest.name, 'restorePath': str(source), 'bytes': source.stat().st_size, 'sha256': digest, 'mode': mode}
        targets[str(source)] = row; manifest['files'].append(row)
        return row
    sources = set()
    observations = []
    labels = {226: 'DQM0_NW226_NO_ADDITION', 227: 'CAPTURE227_PARTIAL47',
              228: 'CORE228_PARTIAL47', 229: 'DQM0_RAM_SE229_NO_ADDITION'}
    for scope, label in labels.items():
        folder = next(Path('/tmp').glob('g350-*-root-20261016-run' + str(scope)))
        collection = read(folder / 'COLLECTED.json')
        assert collection.get('closedAt') and collection['scope'] == scope
        execution = collection['execution']; assert execution and execution['exitCode'] == 0
        save(folder / 'COLLECTED.json', label + '_COLLECTED.json')
        for p in sorted(folder.glob('byte0-result*.json')): save(p, label + '_' + p.name)
        for name in ('child.log', 'execution.json', 'memory.jsonl'):
            p = folder / 'owned' / name
            if p.is_file(): save(p, label + '_owned_' + name)
        command = execution['command']; worker = Path(command[1]); save(worker); sources.add(worker)
        for i, value in enumerate(command[2:], 2):
            p = Path(value)
            if value.startswith('/tmp/g350-') and p.is_file():
                save(p, p.name if command[i - 1] == '--raw-output' else 'INPUT_' + label + '_' + p.parent.name + '_' + p.name)
                if command[i - 1] in ('--input', '--constructor'):
                    for name in ('proof.json', 'contacts.json'):
                        q = p.parent / name
                        if q.is_file(): save(q, 'INPUT_' + label + '_' + q.parent.name + '_' + q.name)
        report = read(folder / 'byte0-result.json')
        observations.append({'scope': scope, 'label': label, 'closedAt': collection['closedAt'], 'executionOccurred': True,
            'exitCode': 0, 'reportProduced': True, 'candidateProduced': (folder / 'byte0-result.candidate.json').exists(),
            'reportedConnectedCount': report.get('connectedAll49Count', report.get('expectedConnectedOwners')),
            'reportedRemaining': report.get('remaining', report.get('pendingOwnerIds')),
            'reportedTerminalOutcome': report.get('terminalOutcome'), 'defaultBoardPromoted': False, 'all49Accepted': False})
    save(__file__)
    visited = set()
    for depth in range(2):
        follow = set()
        for source in sorted(sources - visited):
            visited.add(source)
            with source.open('r') as f:
                text = f.read(); os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
            for literal in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]", text):
                p = Path(literal)
                if p.is_file() and not p.is_symlink() and not any(v.upper().startswith(('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT')) for v in p.parts):
                    save(p)
                    if p.suffix in ('.ts', '.tsx', '.mjs', '.py', '.sh'): follow.add(p)
        sources |= follow
    controls_path = Path('/tmp/g350-manual47-core-root-20261016-run228/byte0-result.json')
    controls = read(controls_path)
    assert controls['partialDiagnosticReplayControlsPassed'] and len(controls['checks']) == 35 and all(c['passed'] for c in controls['checks'])
    assert controls['expectedConnectedOwners'] == 47 and controls['expectedPendingOwners'] == 2
    assert set(controls['pendingOwnerIds']) == {'source_trace_26', 'source_trace_30'}
    assert controls['rawCoreSha256'] == sha(Path('/tmp/g350-manual47-core228-raw.json'))
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    manifest['updatedAt'] = progress['updatedAt'] = now
    manifest['files'].sort(key=lambda v: v['restorePath'])
    fresh = {'capture': targets['/tmp/g350-manual47-capture-root-20261016-run227/byte0-result.json']['savedPath'],
        'coreControls': targets[str(controls_path)]['savedPath'], 'coreControlsSha256': sha(controls_path),
        'rawCore': targets['/tmp/g350-manual47-core228-raw.json']['savedPath'], 'rawCoreSha256': controls['rawCoreSha256'],
        'all35FidelityControlsPassed': True, 'connected': 47, 'pendingOwners': [26, 30],
        'actualPhysicalVias': 227, 'freshBoardNativePending': True, 'authenticatedViaTrackPending': True,
        'literalPourAuditPending': True, 'all49Accepted': False, 'fabricationReady': False}
    for primary in (manifest['primaryCandidate'], progress['primaryCandidate']):
        primary['freshSourceCorePending'] = False; primary['freshSourceCorePassed'] = True
        primary['freshEditableSource228'] = fresh
    progress['freshEditableSource228'] = fresh
    progress['latestVerifiedSourceBoardConnected'] = 47
    progress['freshSourceCorePending'] = False
    progress['freshBoardNativePending'] = True
    progress['latestClosedScopeIncluded'] = 229
    progress.pop('live226Excluded', None)
    progress['onlyClosedScopesCollected'] = True
    progress['closedExperiments'].extend(observations)
    text = (SAVED / 'README.md').read_text()
    text = text.replace('through closed225.', 'through closed229.')
    text = text.replace('Fresh Source/Core and board-native checks are pending.',
        'Fresh capture227/Core228 now pass all35 fidelity controls:47 connected, two pending,\n227 actual vias. Board-native, authenticated via-track and literal pour checks are pending.')
    text = text.replace('Live226 is excluded.', 'Closed226/229 preserve47 and add no route; their alternate attempts are retained separately.')
    (SAVED / 'README.md').write_text(text)
    write(mfile, manifest); write(pfile, progress)
    excluded = {'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
    artifacts = []
    for p in sorted(SAVED.rglob('*')):
        if p.is_file() and not p.is_symlink() and p.relative_to(SAVED).as_posix() not in excluded:
            artifacts.append({'path': p.relative_to(SAVED).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p), 'mode': stat.S_IMODE(p.stat().st_mode)})
    progress['artifacts'] = artifacts; write(pfile, progress)
    rows = artifacts + [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p), 'mode': stat.S_IMODE(p.stat().st_mode)} for p in (mfile, pfile)]
    write(ifile, {'scope': 'Separate post209 saved evidence; no board acceptance', 'updatedAt': now,
        'files': sorted(rows, key=lambda v: v['path']), 'selfExcluded': True, 'all49Accepted': False, 'fabricationReady': False})
    for name, digest in BASE_PINS.items(): assert sha(BASE / name) == digest
    print(json.dumps({'restoreTargets': len(manifest['files']), 'indexedFiles': len(rows), 'latestClosedIncluded': 229,
        'source228All35Passed': True, 'connected': 47, 'pending': [26, 30], 'freshNativePending': True,
        'frozenBaseUnchanged': True, 'sdkExecuted': False, 'archiveCreated': False}))

if __name__ == '__main__': main()
