import assert from "node:assert/strict"
import type { SimpleRouteJson, SimplifiedPcbTrace } from "@tscircuit/capacity-autorouter"
import { buildNativeReferenceRegistry, type CoreRecord } from "../g350-ti-v12e-c-clock-native-port-corrective-sourceonly-next/reference-registry"
import { createOwnedViaTerminalRegistry, type OwnedViaTerminalRegistry } from "../g350-ti-v12e-c-owned-via-port-native-checker-proposal-next/owned-via-terminals"
import { validateRoutedCopperDrc, type RoutedCopperDrcReport } from "../g350-ti-v12e-c-owned-via-port-native-checker-proposal-next/validate-routed-copper-drc"

export interface JointLocalGeometry {
  connections: Array<{ name: string }>
  traces: SimplifiedPcbTrace[]
}
export interface NativeGateContext {
  readonly nativeConnectionCount: 51
  readonly fixedTraceCount: 98
  readonly accepted49: false
  readonly fabricationReady: false
}
type State = {
  original: SimpleRouteJson; native: SimpleRouteJson; registry: OwnedViaTerminalRegistry
  snapshot: string; expectedNames: Set<string>; precheckCalled: boolean
  precheckPassed: boolean; naturalCalled: boolean
}
const states = new WeakMap<NativeGateContext, State>()
type PublishRawReport = (report: RoutedCopperDrcReport) => void

/** Source-bound callers supply exact input bba/Core0e/joint2a8d. This prepares
 * an audit scene only: neither the source objects nor solver requests change. */
export function prepareNativePhysicalScene(
  originalInput: SimpleRouteJson, core: CoreRecord[], joint: JointLocalGeometry,
): NativeGateContext {
  const sourceBefore = JSON.stringify({ originalInput, core, joint })
  assert.equal(originalInput.connections.length, 49)
  assert.equal(originalInput.obstacles.length, 856)
  assert.equal(originalInput.traces?.length, 2)
  assert.equal(joint.connections.length, 49); assert.equal(joint.traces.length, 96)
  const expectedNames = new Set(originalInput.connections.map(connection => connection.name))
  assert.equal(expectedNames.size, 49)
  assert.equal(new Set(joint.connections.map(connection => connection.name)).size, 49)
  assert.ok(joint.connections.every(connection => expectedNames.has(connection.name)))
  assert.ok(joint.traces.every(trace => typeof trace.connection_name === "string" && expectedNames.has(trace.connection_name)))
  const proof = buildNativeReferenceRegistry(core,
    originalInput as unknown as Parameters<typeof buildNativeReferenceRegistry>[1])
  const registry = createOwnedViaTerminalRegistry(core, originalInput)
  assert.equal(proof.connections.length, 2); assert.equal(registry.entryCount, 2)
  const original = structuredClone(originalInput)
  const native = { ...structuredClone(originalInput),
    connections: [...structuredClone(originalInput.connections), ...structuredClone(proof.connections)],
    traces: [...structuredClone(originalInput.traces!), ...structuredClone(joint.traces)],
  } as unknown as SimpleRouteJson
  assert.equal(native.connections.length, 51); assert.equal(native.traces!.length, 98)
  assert.equal(JSON.stringify(native.connections.slice(0, 49)), JSON.stringify(originalInput.connections))
  assert.equal(JSON.stringify(native.traces!.slice(0, 2)), JSON.stringify(originalInput.traces))
  assert.equal(JSON.stringify(native.traces!.slice(2)), JSON.stringify(joint.traces))
  assert.notEqual((native as SimpleRouteJson & { allowViaInPad?: boolean }).allowViaInPad, true)
  assert.equal(JSON.stringify({ originalInput, core, joint }), sourceBefore)
  const token = Object.freeze({ nativeConnectionCount: 51 as const, fixedTraceCount: 98 as const,
    accepted49: false as const, fabricationReady: false as const })
  states.set(token, { original, native, registry, expectedNames, snapshot: JSON.stringify(native),
    precheckCalled: false, precheckPassed: false, naturalCalled: false })
  return token
}

function stateFor(context: NativeGateContext): State {
  const state = states.get(context)
  assert.ok(state, "Native gate context must be created by the source-derived factory")
  assert.equal(JSON.stringify(state.native), state.snapshot)
  return state
}
function audit(state: State, routed: SimpleRouteJson, publish: PublishRawReport): RoutedCopperDrcReport {
  const before = JSON.stringify(routed)
  const report = validateRoutedCopperDrc({ inputSrj: state.native, routedSrj: routed,
    clearance: .1016, allowBlindAndBuriedVias: false, ownedViaTerminalRegistry: state.registry })
  assert.equal(JSON.stringify(routed), before)
  assert.equal(JSON.stringify(state.native), state.snapshot)
  const rawReport = JSON.stringify(report)
  // The full unfiltered report is persisted before the strict-zero assertion.
  publish(report)
  assert.equal(JSON.stringify(report), rawReport, "Report publication must preserve every issue")
  assert.equal(report.valid, true, "Private native checker must pass")
  assert.equal(report.issues.length, 0, "Private native checker requires strict zero issues")
  return report
}

/** Exactly one baseline native call over the 96 joint dogbones and two refs. */
export function validateJointNative(context: NativeGateContext, publish: PublishRawReport): RoutedCopperDrcReport {
  const state = stateFor(context)
  assert.equal(state.precheckCalled, false, "One baseline call is permitted")
  state.precheckCalled = true
  const report = audit(state, state.native, publish)
  state.precheckPassed = true
  return report
}

/** Receives the existing originalNaturalPublicOutput().output once, only after
 * NATURAL_SOLVED. It never calls getOutput(), invents a route, or rewrites copper. */
export function validateNaturalOutput(
  context: NativeGateContext, output: unknown, publish: PublishRawReport,
): RoutedCopperDrcReport {
  const state = stateFor(context)
  assert.equal(state.precheckPassed, true)
  assert.equal(state.naturalCalled, false, "One final native call is permitted")
  assert.ok(output !== null && typeof output === "object" && !Array.isArray(output))
  const actual = output as SimpleRouteJson
  assert.ok(Array.isArray(actual.traces)); assert.equal(actual.traces.length, 51)
  assert.equal(JSON.stringify(actual.connections), JSON.stringify(state.original.connections))
  assert.equal(JSON.stringify(actual.traces.slice(0, 2)), JSON.stringify(state.original.traces))
  const names = actual.traces.slice(2).map(trace => trace.connection_name)
  assert.equal(names.length, 49); assert.equal(new Set(names).size, 49)
  assert.ok(names.every(name => typeof name === "string" && state.expectedNames.has(name)))
  assert.equal(JSON.stringify(actual), JSON.stringify({ ...state.original, traces: actual.traces }))
  const before = JSON.stringify(actual)
  // Add authentic reference connection descriptors solely to the audit view.
  // The raw natural output and all route points remain exactly as returned.
  const routed = { ...actual, connections: state.native.connections }
  state.naturalCalled = true
  const report = audit(state, routed, publish)
  assert.equal(JSON.stringify(actual), before)
  return report
}
