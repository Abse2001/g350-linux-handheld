// SOURCE-ONLY. The Root requires actual collected Source23 Core0 before invocation.
// Read-only authentication of genuine fresh rows; never creates circuit JSON rows.
import assert from 'node:assert/strict'
import {getFullConnectivityMapFromCircuitJson} from 'circuit-json-to-connectivity-map'
const states=new WeakMap(),LAYERS=['top','inner1','inner2','bottom'],EPS=1e-8
const one=(rows,label)=>{assert.equal(rows.length,1,label);return rows[0]}
const near=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<EPS
const at=(a,b)=>a&&b&&near(a.x,b.x)&&near(a.y,b.y)
const canonical=x=>Array.isArray(x)?'['+x.map(canonical).join(',')+']':x&&typeof x==='object'?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}':JSON.stringify(x)
const same=(a,b,label)=>assert.equal(canonical(a),canonical(b),label)
const omit=(r,keys)=>Object.fromEntries(Object.entries(r).filter(([k])=>!keys.includes(k)))
const logical=r=>omit(r,['subcircuit_connectivity_map_key'])
const pointShape=p=>omit(p,['start_pcb_port_id','end_pcb_port_id'])
const routeShape=r=>r.map(pointShape)
const geometrySame=(a,b)=>typeof a==='number'&&typeof b==='number'?near(a,b):Array.isArray(a)||Array.isArray(b)?Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((v,i)=>geometrySame(v,b[i])):a&&b&&typeof a==='object'&&typeof b==='object'?canonical(Object.keys(a).sort())===canonical(Object.keys(b).sort())&&Object.keys(a).every(k=>geometrySame(a[k],b[k])):a===b
function index(circuit){
 assert(Array.isArray(circuit));const byType=new Map(),maps=new Map()
 for(const r of circuit){assert(r&&typeof r.type==='string');if(!byType.has(r.type))byType.set(r.type,[]);byType.get(r.type).push(r)}
 const rows=t=>byType.get(t)||[]
 const by=(t,id)=>{if(!maps.has(t)){const m=new Map();for(const r of rows(t)){const k=r[t+'_id'];assert.equal(typeof k,'string');assert(!m.has(k),'Duplicate actual ID '+k);m.set(k,r)}maps.set(t,m)}const r=maps.get(t).get(id);assert(r,'Missing actual '+t+' '+id);return r}
 return {rows,by}
}
function alias(actual,via,layer){
 const pcb=one(via.pcb_port_ids.map(id=>actual.by('pcb_port',id)).filter(p=>canonical(p.layers)===canonical([layer])),'One actual '+layer+' alias')
 assert(at(pcb,via));const source=actual.by('source_port',pcb.source_port_id);assert.equal(source.name,layer)
 const owner=actual.by('source_manually_placed_via',source.source_component_id),placeholder=actual.by('pcb_component',pcb.pcb_component_id)
 assert.equal(placeholder.source_component_id,owner.source_manually_placed_via_id);assert(at(placeholder.center,via));assert.equal(placeholder.width,.4572);assert.equal(placeholder.height,.4572)
 assert.equal(owner.source_net_id,via.source_net_id,'No signal rail fabrication')
 return {pcb,source,owner}
}
function endpoints(t,ids){
 const found=t.route.flatMap((p,i)=>i===0||i===t.route.length-1?[p.start_pcb_port_id,p.end_pcb_port_id].filter(Boolean):[])
 same([...found].sort(),[...ids].sort(),'Exact actual trace endpoint IDs');assert(!t.route.slice(1,-1).some(p=>p.start_pcb_port_id||p.end_pcb_port_id))
}
const freeze=v=>{if(v&&typeof v==='object'&&!Object.isFrozen(v)){Object.values(v).forEach(freeze);Object.freeze(v)}return v}
export function proveFreshMoved23Core({freshCore,controls,oldCore,oldNativeProof,proposal,material,nativeTargets}){
 const before=JSON.stringify(freshCore),actual=index(freshCore),old=index(oldCore)
 assert.equal(controls.scope,'ROOT_FRESH_EDITABLE_SOURCE_CORE_OWNER_MOVED_227_JOINT23');assert.equal(controls.freshCoreControlPassed,true);assert.equal(controls.checks.length,29);assert(controls.checks.every(r=>r.passed===true))
 assert.equal(controls.sourceNumericAndPhysicalIdsDerivedWithoutAssignment,true);assert.equal(controls.circuitJsonGeometryEdited,false);assert.equal(controls.pcbRoutingDisabled,true);assert.equal(controls.expectedOriginalCarrierCount,23);assert.equal(controls.expectedMissingOriginalSignalCount,26)
 assert.equal(controls.automaticCoreSrjForThisForkMustNotBeUsed,true)
 for(const [t,n]of [['pcb_via',227],['pcb_trace',286],['pcb_port',1651],['source_port',1651],['pcb_smtpad',1161],['source_component',280],['pcb_component',507],['source_net',98],['source_bus',8],['pcb_hole',2],['pcb_plated_hole',4]])assert.equal(actual.rows(t).length,n,t)
 assert.equal(proposal.all98NumericOwnedSignalBranches.length,98);assert.equal(proposal.selected23OriginalCarriers.length,23);assert.equal(material.referenceViaTargets129.length,129);assert.equal(material.referencePathTargets165.length,165)
 // The entire original logical trace/bus/rail declarations are authenticated independently.
 for(const r of old.rows('source_trace').filter(r=>/^source_trace_\d+$/.test(r.source_trace_id)&&Number(r.source_trace_id.slice(13))<49))same(logical(actual.by('source_trace',r.source_trace_id)),logical(r),'Original49 logical numeric requests')
 for(const type of ['source_net','source_bus']){
  const pending=actual.rows(type).slice();for(const r of old.rows(type)){const shape=x=>type==='source_bus'?omit(x,['source_bus_id']):logical(x);const i=pending.findIndex(x=>canonical(shape(x))===canonical(shape(r)));assert(i>=0,'Every original '+type+' held');pending.splice(i,1)}assert.equal(pending.length,0)
 }
 const partByName=name=>one(actual.rows('source_component').filter(r=>r.name===name),'One real component '+name)
 const numeric=selector=>{
  const match=/^(.*)\.pin(\d+)$/.exec(selector);assert(match);const part=partByName(match[1]),sp=one(actual.rows('source_port').filter(r=>r.source_component_id===part.source_component_id&&r.pin_number===Number(match[2])),'Actual numeric pin')
  same(logical(sp),logical(old.by('source_port',sp.source_port_id)),'Original numeric Source owner');same(logical(part),logical(old.by('source_component',part.source_component_id)),'Real part metadata')
  const pcb=one(actual.rows('pcb_port').filter(r=>r.source_port_id===sp.source_port_id),'Actual numeric PCB port'),pad=one(actual.rows('pcb_smtpad').filter(r=>r.pcb_port_id===pcb.pcb_port_id),'Actual numeric land')
  const target=one(nativeTargets.allOriginalCopperLands.filter(r=>r.pcb_port_id===one(old.rows('pcb_port').filter(p=>p.source_port_id===sp.source_port_id),'Old numeric origin').pcb_port_id),'One planning numeric copper target')
  assert(geometrySame(omit(pad,['pcb_smtpad_id','pcb_port_id','pcb_component_id']),omit(target,['pcb_smtpad_id','pcb_port_id','pcb_component_id'])),'Planned real moved pad shape')
  assert(at(pcb,pad));return {part,sp,pcb,pad}
 }
 const usedVias=new Set(),usedTraces=new Set(),viaByName=new Map(),viaByOrigin=new Map(),registry=new Map(),padRegistry=new Map(),referenceMappings=[],signalMappings=[]
 for(const target of material.referenceViaTargets129){
  const ctl=one(controls.viaProjection.filter(r=>r.sourceViaName===target.sourceViaName),'Collected actual reference via projection');assert.equal(ctl.passed,true);assert.equal(ctl.reference,true)
  const v=actual.by('pcb_via',ctl.actualViaId),expected=target.expectedPhysical
  for(const k of ['x','y','outer_diameter','hole_diameter','layers','from_layer','to_layer','tented_on_top','tented_on_bottom','source_net_id'])assert(geometrySame(v[k],expected[k]),'Reference actual '+k)
  assert(!usedVias.has(v.pcb_via_id));usedVias.add(v.pcb_via_id);assert.equal(v.pcb_port_ids.length,2)
  const a=alias(actual,v,'top'),b=alias(actual,v,'bottom');assert.equal(a.owner.source_manually_placed_via_id,b.owner.source_manually_placed_via_id);assert.equal(a.owner.source_manually_placed_via_id,ctl.actualSourceViaOwner)
  for(const own of [a,b]){const c=one(ctl.aliases.filter(r=>r.layer===own.source.name),'Exact reference projection alias');assert(c.authentic);assert.equal(c.actualPcbPortId,own.pcb.pcb_port_id);assert.equal(c.actualSourcePortId,own.source.source_port_id)}
  viaByName.set(target.sourceViaName,v);viaByOrigin.set(target.originViaIdForMappingOnly,v);registry.set(v.pcb_via_id,new Set())
 }
 for(const target of material.referencePathTargets165){
  const ctl=one(controls.referenceProjection.filter(r=>r.literalTraceName===target.literalTraceName),'Actual reference path projection');assert(ctl.passed&&ctl.semanticOwnerHeld)
  const t=actual.by('pcb_trace',ctl.actualPcbTraceId),source=actual.by('source_trace',t.source_trace_id);assert.equal(source.name,target.literalTraceName);assert.equal(source.source_trace_id,ctl.actualSourceTraceId)
  const oldSource=old.by('source_trace',target.actualBeforeSourceTraceId);same(omit(source,['source_trace_id','connected_source_port_ids','subcircuit_connectivity_map_key']),omit(oldSource,['source_trace_id','connected_source_port_ids','subcircuit_connectivity_map_key']),'Reference actual logical declaration')
  const expected=target.expectedTargetRoute;assert(geometrySame(routeShape(t.route),routeShape(expected))||geometrySame(routeShape(t.route),routeShape(expected).reverse()),'Exact moved reference copper')
  const oldMap=one(oldNativeProof.referenceMappings.filter(r=>r.actualPcbTraceId===target.actualBeforePcbTraceId),'Original Root checked reference owner mapping')
  const oldSp=old.by('source_port',oldMap.actualNumericSourcePortId),oldPart=old.by('source_component',oldSp.source_component_id),n=numeric(oldPart.name+'.pin'+oldSp.pin_number),v=viaByOrigin.get(oldMap.actualViaId);assert(v)
  const a=alias(actual,v,t.route[0].layer);endpoints(t,[n.pcb.pcb_port_id,a.pcb.pcb_port_id]);same([...source.connected_source_port_ids].sort(),[n.sp.source_port_id,a.source.source_port_id].sort(),'Reference numeric/via Source ownership');assert(source.connected_source_net_ids.includes(v.source_net_id))
  assert(!usedTraces.has(t.pcb_trace_id));usedTraces.add(t.pcb_trace_id);registry.get(v.pcb_via_id).add(t.source_trace_id)
  referenceMappings.push({originalPcbTraceId:target.actualBeforePcbTraceId,actualPcbTraceId:t.pcb_trace_id,actualSourceTraceId:t.source_trace_id,originalViaId:oldMap.actualViaId,actualViaId:v.pcb_via_id,actualNumericPcbPortId:n.pcb.pcb_port_id,actualAliasPcbPortId:a.pcb.pcb_port_id,actualNumericSourcePortId:n.sp.source_port_id})
 }
 const selected=new Map(proposal.selected23OriginalCarriers.map(c=>[c.originalSourceTraceId,c]))
 for(const owner of proposal.all98NumericOwnedSignalBranches){
  const n=numeric(owner.numericSelector);assert(at(n.pcb,owner.padXY));assert.equal(n.sp.pin_number,owner.numericPin)
  const ctl=one(controls.viaProjection.filter(r=>r.sourceViaName===owner.viaName),'Actual signal via projection');assert(ctl.passed&&!ctl.reference)
  const v=actual.by('pcb_via',ctl.actualViaId);assert(at(v,owner.viaXY));assert.equal(v.outer_diameter,.4572);assert.equal(v.hole_diameter,.254);same(v.layers,LAYERS);assert.equal(v.from_layer,'top');assert.equal(v.to_layer,'bottom');assert.equal(v.source_net_id,undefined);assert.equal(v.tented_on_top,true);assert.equal(v.tented_on_bottom,true)
  assert(!usedVias.has(v.pcb_via_id));usedVias.add(v.pcb_via_id)
  const definition=selected.get(owner.originalSourceTraceId),layer=definition?.carrierLayer,expected=['top','bottom',...(['inner1','inner2'].includes(layer)?[layer]:[])]
  same(v.pcb_port_ids.map(id=>one(actual.by('pcb_port',id).layers,'Single actual alias layer')).sort(),expected.slice().sort(),'Exact genuine via alias roster')
  const aliases=expected.map(l=>alias(actual,v,l));assert.equal(new Set(aliases.map(a=>a.owner.source_manually_placed_via_id)).size,1);assert.equal(aliases[0].owner.source_manually_placed_via_id,ctl.actualSourceViaOwner)
  const top=alias(actual,v,'top'),bottom=alias(actual,v,'bottom'),local=one(actual.rows('source_trace').filter(r=>r.name===owner.traceName),'Unique authored local branch');same(local.connected_source_port_ids,[n.sp.source_port_id,top.source.source_port_id],'True numeric-to-via Source branch');same(local.connected_source_net_ids,[]);assert.equal(local.min_trace_thickness,.1016)
  const physical=definition?owner.originalSourceTraceId:local.source_trace_id
  const t=one(actual.rows('pcb_trace').filter(r=>r.source_trace_id===physical&&(geometrySame(routeShape(r.route),owner.topStub)||geometrySame(routeShape(r.route),owner.topStub.slice().reverse()))),'One true source-owned Topstub')
  endpoints(t,[n.pcb.pcb_port_id,top.pcb.pcb_port_id]);assert.equal(actual.rows('pcb_trace').filter(r=>r.source_trace_id===local.source_trace_id).length,definition?0:1)
  const projection=one(controls.signalTopProjection.filter(r=>r.originalSourceTraceId===owner.originalSourceTraceId&&r.side===owner.side),'Actual Topstub projection');assert(projection.passed);assert.equal(projection.actualPcbTraceId,t.pcb_trace_id);assert.equal(projection.actualLocalSourceTraceId,local.source_trace_id)
  assert(!usedTraces.has(t.pcb_trace_id));usedTraces.add(t.pcb_trace_id);registry.set(v.pcb_via_id,new Set([physical]));viaByName.set(owner.viaName,v)
  if(v.pcb_trace_id!==undefined)assert.equal(v.pcb_trace_id,t.pcb_trace_id,'Signal via physical owner must be authentic Topstub')
  signalMappings.push({originalSourceTraceId:owner.originalSourceTraceId,side:owner.side,originalNumericSourcePortId:n.sp.source_port_id,sourceViaName:owner.viaName,actualViaId:v.pcb_via_id,actualLocalSourceTraceId:local.source_trace_id,actualPhysicalSourceTraceId:physical,actualPcbTraceId:t.pcb_trace_id,actualNumericPcbPortId:n.pcb.pcb_port_id,actualTopPcbPortId:top.pcb.pcb_port_id,actualBottomPcbPortId:bottom.pcb.pcb_port_id,actualTopSourcePortId:top.source.source_port_id,sourceViaOwnerId:top.owner.source_manually_placed_via_id})
 }
 const carriers=proposal.selected23OriginalCarriers.map(d=>{
  const id=d.originalSourceTraceId,layer=d.carrierLayer;assert(LAYERS.includes(layer));const mapped=[d.cpu,d.ram].map(o=>one(signalMappings.filter(m=>m.originalSourceTraceId===id&&m.sourceViaName===o.viaName),'Actual selected endpoint'))
  const vias=mapped.map(m=>actual.by('pcb_via',m.actualViaId)),ports=vias.map(v=>alias(actual,v,layer)),paths=actual.rows('pcb_trace').filter(t=>t.source_trace_id===id);assert.equal(paths.length,3)
  const body=one(paths.filter(t=>!mapped.some(m=>m.actualPcbTraceId===t.pcb_trace_id)),'One actual main carrier');assert(!usedTraces.has(body.pcb_trace_id));assert.equal(body.route.length,d.expectedCarrierPath.length)
  body.route.forEach((p,i)=>assert(p.route_type==='wire'&&p.layer===layer&&p.width===.1016&&at(p,d.expectedCarrierPath[i]),'Pinned Source23 carrier geometry'))
  endpoints(body,ports.map(p=>p.pcb.pcb_port_id));assert(at(body.route[0],vias[0])&&at(body.route.at(-1),vias[1]));assert(paths.every(t=>t.route.every(p=>p.route_type==='wire')));usedTraces.add(body.pcb_trace_id)
  const planar=paths.reduce((s,t)=>s+t.route.slice(1).reduce((n,p,i)=>n+Math.hypot(p.x-t.route[i].x,p.y-t.route[i].y),0),0);assert(near(planar,d.expectedWholePlanarMm))
  const graph=new Map(),edges=[];const join=(a,b,basis)=>{for(const x of[a,b])if(!graph.has(x))graph.set(x,new Set());graph.get(a).add(b);graph.get(b).add(a);edges.push({fromActualId:a,toActualId:b,...basis})}
  for(const t of paths){const first=t.route[0],last=t.route.at(-1);assert(first.start_pcb_port_id&&last.end_pcb_port_id);for(const [p,pid]of [[first,first.start_pcb_port_id],[last,last.end_pcb_port_id]]){const port=actual.by('pcb_port',pid);assert(at(p,port)&&port.layers.includes(p.layer))}join(first.start_pcb_port_id,last.end_pcb_port_id,{basis:'ACTUAL_FRESH_SOURCE_OWNED_WIRE_PATH',actualPcbTraceId:t.pcb_trace_id,actualSourceTraceId:t.source_trace_id})}
  for(const v of vias)for(const pid of v.pcb_port_ids){const p=actual.by('pcb_port',pid);assert(at(p,v)&&p.layers.every(l=>v.layers.includes(l)));join(pid,v.pcb_via_id,{basis:'ACTUAL_FULLSPAN_BARREL_OWNED_ALIAS',actualSourceViaOwner:actual.by('source_port',p.source_port_id).source_component_id})}
  const begin=mapped[0].actualNumericPcbPortId,end=mapped[1].actualNumericPcbPortId,queue=[begin],prev=new Map([[begin,null]]);for(let i=0;i<queue.length;i++)for(const next of graph.get(queue[i])||[])if(!prev.has(next)){prev.set(next,queue[i]);queue.push(next)}assert(prev.has(end),'Genuine physical numeric CPU-to-RAM graph')
  const path=[];for(let current=end;current!==null;current=prev.get(current))path.unshift(current)
  const ctl=one(controls.carriers.filter(c=>c.originalSourceTraceId===id),'Collected carrier proof');assert(ctl.passed);assert.equal(ctl.actualCarrierPcbTraceId,body.pcb_trace_id);same(ctl.actualDirectPcbTraceIds,paths.map(t=>t.pcb_trace_id),'Actual carrier roster')
  return {originalSourceTraceId:id,carrierLayer:layer,actualDirectPcbTraceIds:paths.map(t=>t.pcb_trace_id),actualCarrierPcbTraceId:body.pcb_trace_id,actualCpuNumericPcbPortId:begin,actualRamNumericPcbPortId:end,actualCpuViaId:vias[0].pcb_via_id,actualRamViaId:vias[1].pcb_via_id,actualCpuCarrierLayerPcbPortId:ports[0].pcb.pcb_port_id,actualRamCarrierLayerPcbPortId:ports[1].pcb.pcb_port_id,wholePlanarLengthMm:planar,physicalFullThroughBarrels:2,actualActiveLayerTransitions:layer==='top'?[]:[{x:vias[0].x,y:vias[0].y,fromLayer:'top',toLayer:layer},{x:vias[1].x,y:vias[1].y,fromLayer:layer,toLayer:'top'}],legacyViaMarkerLengthContributionMm:0,actualSourceOwnedPhysicalGraph:{actualEdges:edges,actualNumericCpuToRamIdPath:path,physicallyConnected:true,logicalMapAloneNotUsed:true},electricalDelayQualified:false}
 })
 for(let n=0;n<49;n++)assert.equal(actual.rows('pcb_trace').filter(t=>t.source_trace_id==='source_trace_'+n).length,selected.has('source_trace_'+n)?3:0,'Exactly23 completed and26 unfinished')
 assert.equal(usedVias.size,227);assert.equal(usedTraces.size,286);assert.equal(registry.size,227)
 // Retain ONLY the authentic old RAM25/HS8 physical-contact exception; re-prove
 // its new geometry, explicit numeric owner, and real known-rail graph.
 const contact=oldNativeProof.registeredRam25Hs8Junction;assert(contact.onlyOriginalRam25Owner&&contact.stripDrillClear&&contact.padDrillClear)
 const newVia=viaByOrigin.get(contact.actualViaId),oldOwnedVia=viaByOrigin.get(contact.actualOldHsViaId),strip=one(referenceMappings.filter(m=>m.originalPcbTraceId===contact.actualOldStripPcbTraceId),'Authentic HS8 strip mapped'),t=actual.by('pcb_trace',strip.actualPcbTraceId),n=numeric('C_DDR_RAM_8.pin2'),pad=n.pad
 assert(newVia&&oldOwnedVia);assert.equal(newVia.source_net_id,'source_net_0');assert.equal(t.source_trace_id,'source_trace_987');assert.equal(n.pad.layer,'bottom');assert.equal(t.route.length,2)
 const[a,b]=t.route;assert(a.layer==='bottom'&&b.layer==='bottom'&&a.width===.2&&b.width===.2&&!a.width_interpolation_mode&&!b.width_interpolation_mode)
 const dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy),along=((newVia.x-a.x)*dx+(newVia.y-a.y)*dy)/len,distance=Math.abs(dx*(newVia.y-a.y)-dy*(newVia.x-a.x))/len,R=newVia.outer_diameter/2,h=newVia.hole_diameter/2,nearest=Math.max(0,distance-a.width/2),halfChord=Math.sqrt(R*R-nearest*nearest)
 assert(Number.isFinite(halfChord)&&2*halfChord>=.1016&&along-halfChord>1e-8&&along+halfChord<len-1e-8&&distance-a.width/2>h);assert.equal(pad.shape,'rect');assert.equal(pad.ccw_rotation??0,0)
 const closestX=Math.max(pad.x-pad.width/2,Math.min(newVia.x,pad.x+pad.width/2)),closestY=Math.max(pad.y-pad.height/2,Math.min(newVia.y,pad.y+pad.height/2)),padDistance=Math.hypot(newVia.x-closestX,newVia.y-closestY);assert(padDistance<R&&padDistance>h&&R-h>=.1016-Number.EPSILON)
 const connectivity=getFullConnectivityMapFromCircuitJson(freshCore)
 for(const pair of [[t.pcb_trace_id,newVia.pcb_via_id],[t.source_trace_id,newVia.pcb_via_id],[oldOwnedVia.pcb_via_id,newVia.pcb_via_id],[pad.pcb_smtpad_id,newVia.pcb_via_id],[n.pcb.pcb_port_id,newVia.pcb_via_id],[n.sp.source_port_id,newVia.pcb_via_id]])assert(connectivity.areIdsConnected(...pair),'Authentic known-rail RAM25/HS8 contact')
 registry.get(newVia.pcb_via_id).add(t.source_trace_id);padRegistry.set(newVia.pcb_via_id,new Set([pad.pcb_smtpad_id]))
 for(const m of referenceMappings){const t=actual.by('pcb_trace',m.actualPcbTraceId),v=actual.by('pcb_via',m.actualViaId);for(const pair of [[m.actualNumericPcbPortId,t.pcb_trace_id],[m.actualAliasPcbPortId,t.pcb_trace_id],[m.actualNumericPcbPortId,v.pcb_via_id],[t.source_trace_id,v.pcb_via_id],[v.source_net_id,v.pcb_via_id]])assert(connectivity.areIdsConnected(...pair),'Actual reference numeric graph')}
 assert.equal(JSON.stringify(freshCore),before,'No circuit JSON edit during ownership proof')
 const proof=freeze({scope:'ACTUAL_FRESH_CORE_MOVED227_286_NUMERIC23_AUTHENTIC_REFERENCE_OWNERSHIP',referenceMappings,signalMappings,carriers,clocks:carriers.filter(c=>['source_trace_33','source_trace_34'].includes(c.originalSourceTraceId)),registeredRam25Hs8Junction:{actualViaId:newVia.pcb_via_id,actualOldStripPcbTraceId:t.pcb_trace_id,actualOldStripSourceTraceId:t.source_trace_id,actualHs8PadId:pad.pcb_smtpad_id,actualHs8NumericPcbPortId:n.pcb.pcb_port_id,actualOldHsViaId:oldOwnedVia.pcb_via_id,actualContactChordMm:2*halfChord,actualPadClosestDistanceMm:padDistance,actualLandRadiusMm:R,actualDrillRadiusMm:h,onlyOriginalRam25Owner:true,stripDrillClear:true,padDrillClear:true},rawCircuitUnmodified:true,referenceQualified:false,accepted49:false,fabricationReady:false})
 states.set(proof,{circuit:freshCore,signature:before,registry,padRegistry});return proof
}
export function getFreshViaBranchRegistry(proof,circuit){const s=states.get(proof);assert(s&&s.circuit===circuit,'Only exact privately proved actual Core object');assert.equal(JSON.stringify(circuit),s.signature);return new Map([...s.registry].map(([id,owners])=>[id,new Set(owners)]))}
export function getFreshIntentionalPadContactRegistry(proof,circuit){const s=states.get(proof);assert(s&&s.circuit===circuit,'Only exact privately proved actual Core object');assert.equal(JSON.stringify(circuit),s.signature);return new Map([...s.padRegistry].map(([id,pads])=>[id,new Set(pads)]))}
