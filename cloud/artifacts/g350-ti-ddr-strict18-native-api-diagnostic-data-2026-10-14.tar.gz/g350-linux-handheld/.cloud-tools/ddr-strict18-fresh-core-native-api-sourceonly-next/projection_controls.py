"""Finite stdlib actual fresh279 geometry/ownership/physicalgraph controls; no SDK/CAD imports."""
import ast,copy,hashlib,json,math
from pathlib import Path
ROOT=Path('/workspace/g350-linux-handheld');HERE=Path(__file__).parent
RAW=ROOT/'.cloud-tools/ddr-strict18-manual-core-owned-alias-successor-next/run-core/raw-core.json';CTL=RAW.with_name('core-controls.json')
SIGNAL=ROOT/'.cloud-tools/ddr-package101-signal96-joint-native-sourceonly-next/signal-source-proposal.json';CLOCK=ROOT/'.cloud-tools/ddr-package101-signal96-clock-v11-source-contract-next/clock-fidelity-source-proposal.json';PROPOSAL=ROOT/'.cloud-tools/ddr-strict18-manual-source-integration-sourceonly-next/strict18-source-proposal.json'
def require(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def near(a,b):return abs(a-b)<1e-9
def at(a,b):return near(a['x'],b['x'])and near(a['y'],b['y'])
def one(v,m):require(len(v)==1,m);return v[0]
signal=read(SIGNAL);clock=read(CLOCK);proposal=read(PROPOSAL)
definitions=[dict(c,carrierLayer='inner1',expectedCarrierPhysicalRoute=c['expectedInner1PhysicalRoute'])for c in clock['clockCarriers']]+proposal['newOriginalSignalChanges'];byid={c['originalSourceTraceId']:c for c in definitions};require(len(byid)==18,'Actual18definitions')
def validate(rows):
 by={}
 for r in rows:
  t=r['type'];key=r.get(t+'_id')
  if key:
   require(key not in by.setdefault(t,{}),'Duplicate actual ID');by[t][key]=r
 require([len(by[t])for t in ['pcb_via','pcb_trace','pcb_port','pcb_smtpad','source_component']]==[225,279,1639,1161,280],'Fresh actual inventories')
 mappings=[];usedvias=set();usedstubs=set()
 for o in signal['owners']:
  numeric=one([p for p in by['pcb_port'].values()if p['source_port_id']==o['originalSourcePortId']],'Genuine numeric Source port');sp=by['source_port'][numeric['source_port_id']];require(sp['pin_number']==o['numericPin']and by['source_component'][sp['source_component_id']]['name']==o['package']and at(numeric,o['padXY']),'Authentic numericowner')
  v=one([v for v in by['pcb_via'].values()if at(v,o['viaXY'])],'Actual signalbarrel');require(v['pcb_via_id']not in usedvias,'Unique96barrels');usedvias.add(v['pcb_via_id']);require(v['layers']==['top','inner1','inner2','bottom']and v['outer_diameter']==.4572 and v['hole_diameter']==.254 and v.get('source_net_id')is None,'Physical span and nofake signalrail')
  aliases=[by['pcb_port'][pid]for pid in v['pcb_port_ids']];d=byid.get(o['originalSourceTraceId']);expected=['top','bottom']+([d['carrierLayer']]if d and d['carrierLayer']in ['inner1','inner2']else[])
  require(sorted(p['layers']for p in aliases)==sorted([[x]for x in expected]),'Exact real aliasroles')
  owners={by['source_port'][p['source_port_id']]['source_component_id']for p in aliases};pcs={p['pcb_component_id']for p in aliases};require(len(owners)==len(pcs)==1,'Same realSourceowner andplaceholder');owner=next(iter(owners));placeholder=by['pcb_component'][next(iter(pcs))];require(owner in by['source_manually_placed_via']and placeholder['source_component_id']==owner and at(placeholder['center'],v)and placeholder['width']==placeholder['height']==.4572,'Actual Sourcevia placeholder')
  for p in aliases:require(at(p,v)and by['source_port'][p['source_port_id']]['name']==p['layers'][0],'Actual Sourcealias layer/coordinate')
  top=one([p for p in aliases if p['layers']==['top']],'Topalias');local=one([s for s in by['source_trace'].values()if s.get('name')==o['traceName']],'Unique original localSource prototype')
  require(set(local['connected_source_port_ids'])=={numeric['source_port_id'],top['source_port_id']}and local['connected_source_net_ids']==[],'Real localnumericowner')
  physical=o['originalSourceTraceId']if d else local['source_trace_id']
  def stub(t):
   route=t['route'];return t['source_trace_id']==physical and len(route)==len(o['topStub'])and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in route)and(all(at(p,q)for p,q in zip(route,o['topStub']))or all(at(p,q)for p,q in zip(route,reversed(o['topStub']))))
  t=one([t for t in by['pcb_trace'].values()if stub(t)],'Actual singleowned Topstub');require(t['pcb_trace_id']not in usedstubs,'Unique96stubs');usedstubs.add(t['pcb_trace_id'])
  require(len([t for t in by['pcb_trace'].values()if t['source_trace_id']==local['source_trace_id']])==(0 if d else 1),'No duplicated prototype copper')
  mappings.append({'definition':o,'actualNumericPcbPortId':numeric['pcb_port_id'],'actualViaId':v['pcb_via_id'],'actualTopStubId':t['pcb_trace_id'],'actualAliasPcbPortsByLayer':{p['layers'][0]:p['pcb_port_id']for p in aliases}})
 reports=[]
 for d in definitions:
  id=d['originalSourceTraceId'];ms=[one([m for m in mappings if m['definition']['originalSourceTraceId']==id and m['definition']['originalSourcePortId']==o['originalSourcePortId']],'Directendpoint')for o in[d['cpu'],d['ram']]]
  traces=[t for t in by['pcb_trace'].values()if t['source_trace_id']==id];require(len(traces)==3,'Actual source owns3paths');body=one([t for t in traces if t['pcb_trace_id']not in {m['actualTopStubId']for m in ms}],'Actual distinctcarrier');require(len(body['route'])==len(d['expectedCarrierPhysicalRoute'])and all(p['route_type']=='wire'and p['layer']==d['carrierLayer']and p['width']==.1016 and at(p,q)for p,q in zip(body['route'],d['expectedCarrierPhysicalRoute'])),'Actual pinnedcarrier shape')
  require(body['route'][0]['start_pcb_port_id']==ms[0]['actualAliasPcbPortsByLayer'][d['carrierLayer']]and body['route'][-1]['end_pcb_port_id']==ms[1]['actualAliasPcbPortsByLayer'][d['carrierLayer']],'CarrieractualOwnedAlias endpoints')
  graph={};edges=[]
  def link(a,b):graph.setdefault(a,set()).add(b);graph.setdefault(b,set()).add(a);edges.append([a,b])
  for t in traces:
   f,l=t['route'][0],t['route'][-1];ids=[f.get('start_pcb_port_id'),l.get('end_pcb_port_id')];require(all(ids),'Actualport annotated')
   for point,pid in zip([f,l],ids):require(pid in by['pcb_port']and at(point,by['pcb_port'][pid])and point['layer']in by['pcb_port'][pid]['layers'],'Physical endpoint must meetdeclaredport')
   link(*ids)
  for m in ms:
   for pid in by['pcb_via'][m['actualViaId']]['pcb_port_ids']:link(pid,m['actualViaId'])
  start,end=ms[0]['actualNumericPcbPortId'],ms[1]['actualNumericPcbPortId'];seen={start};queue=[start]
  for p in queue:
   for q in graph.get(p,[]):
    if q not in seen:seen.add(q);queue.append(q)
  require(end in seen,'Actual physical numericCPUtoRAM graph')
  reports.append({'originalSourceTraceId':id,'actualCarrierPcbTraceId':body['pcb_trace_id'],'actualThreePcbTraceIds':[t['pcb_trace_id']for t in traces],'actualCpuNumericPcbPortId':start,'actualRamNumericPcbPortId':end,'actualCpuViaId':ms[0]['actualViaId'],'actualRamViaId':ms[1]['actualViaId'],'physicalGraphConnected':True,'actualEdges':edges})
 for n in range(49):require(len([t for t in by['pcb_trace'].values()if t['source_trace_id']=='source_trace_'+str(n)])==(3 if 'source_trace_'+str(n)in byid else 0),'Only18 fulloriginalsourcepaths')
 return reports

def main():
 require(sha(RAW)=='81a72280365352ac9116563921536a2aced6f7ea2b65f330535927582537c76a'and sha(CTL)=='10b126f8e0aa01977e646b7607a31175d7094d04d0af92a0b833ff9cad5e9885','Exact Root36930 actualinputs')
 raw=read(RAW);positive=validate(raw);negative=[]
 def bad(name,edit):
  x=copy.deepcopy(raw);edit(x)
  try:validate(x)
  except(ValueError,KeyError)as e:negative.append({'name':name,'refused':True,'reason':str(e)})
  else:raise ValueError('Badcontrol accepted '+name)
 def row(x,t,id):return next(v for v in x if v['type']==t and v[t+'_id']==id)
 cpu=positive[0]['actualCpuViaId'];carrier=positive[0]['actualCarrierPcbTraceId'];port=positive[0]['actualCpuNumericPcbPortId']
 bad('signal_barrel_wrong_rail',lambda x:row(x,'pcb_via',cpu).update(source_net_id='source_net_0'))
 bad('signal_barrel_wrong_coordinate',lambda x:row(x,'pcb_via',cpu).update(x=99))
 bad('carrier_wrong_source_owner',lambda x:row(x,'pcb_trace',carrier).update(source_trace_id='source_trace_48'))
 bad('carrier_missing',lambda x:x.remove(row(x,'pcb_trace',carrier)))
 bad('carrier_wrong_layer',lambda x:row(x,'pcb_trace',carrier)['route'][2].update(layer='bottom'))
 bad('carrier_wrong_width',lambda x:row(x,'pcb_trace',carrier)['route'][2].update(width=.075))
 bad('numeric_pad_owner_swap',lambda x:row(x,'pcb_port',port).update(source_port_id='source_port_6'))
 bad('carrier_endpoint_actual_id_swap',lambda x:row(x,'pcb_trace',carrier)['route'][0].update(start_pcb_port_id=positive[1]['actualCpuNumericPcbPortId']))
 bad('duplicate_actual_carrier_row',lambda x:x.append(copy.deepcopy(row(x,'pcb_trace',carrier))))
 firstvia=row(raw,'pcb_via',cpu);alias=firstvia['pcb_port_ids'][-1]
 bad('carrier_alias_wrong_source_via_owner',lambda x:row(x,'source_port',row(x,'pcb_port',alias)['source_port_id']).update(source_component_id='source_manually_placed_via_0'))
 bad('carrier_alias_wrong_coordinate',lambda x:row(x,'pcb_port',alias).update(x=99))
 bad('carrier_alias_placeholder_wrong_owner',lambda x:row(x,'pcb_component',row(x,'pcb_port',alias)['pcb_component_id']).update(source_component_id='source_manually_placed_via_0'))
 # Root receipt controls invoke only actual stdlib validator definitions, never appworkers.
 module=ast.parse((HERE/'validate-root-prerequisites.py').read_text());e={'Path':Path,'hashlib':hashlib,'json':json,'re':__import__('re'),'stat':__import__('stat')}
 for n in module.body:
  if isinstance(n,(ast.Assign,ast.FunctionDef)):exec(compile(ast.Module(body=[n],type_ignores=[]),'Root-receipt-pure-defs','exec'),e)
 for phase,meta in e['ACTUAL'].items():
  c=read(Path(meta['path']));p=read(Path(c['postauditPath']));e['validate_collection'](c,p,phase)
  badc=copy.deepcopy(c);badc['toolSessionCollected']=False
  try:e['validate_collection'](badc,p,phase)
  except ValueError:negative.append({'name':'uncollected_actual_'+phase,'refused':True})
  else:raise ValueError('Uncollected receipt accepted')
 try:e['validate_binding']({'scope':'UNBOUND'}, {'authorizedByRoot':False},'0'*64)
 except ValueError:negative.append({'name':'unbound_authority_template','refused':True})
 else:raise ValueError('Unbound authority accepted')
 out={'scope':'FINITE_STDLIB_STRICT18_ACTUAL_CORE279_PROJECTION_AND_PHYSICAL_OWNER_GRAPH_CONTROLS','actualCoreSha256':sha(RAW),'actualControlsSha256':sha(CTL),'positiveDerivedActualPhysicalGraphs':positive,'positiveGraphCount':18,'negativeControls':negative,'negativeCount':len(negative),'noActualIdsCopiedIntoSource':True,'noSdkOrAppImports':True,'nativeExecuted':False,'originalApiExecuted':False,'accepted49':False,'referenceQualified':False,'fabricationReady':False}
 f=HERE/'STDLIB_CONTROLS.json'
 with f.open('x')as fp:json.dump(out,fp,indent=2);fp.write('\n')
 f.chmod(0o600);print(json.dumps({'sha256':sha(f),'positive18':len(positive),'negativeCount':len(negative)}))
if __name__=='__main__':main()
