#!/usr/bin/env python3
"""SOURCE ONLY. Root executes this own-stdlib serializer preparation, not the author.

Raw Source272 and the stock CLI remain immutable. The distinct export array adds
only missing, authenticated via connectivity keys. It never moves copper or
constructs fresh Source/PCB IDs. This preparation does not execute the exporter.
"""
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path

ROOT = Path('/workspace/g350-linux-handheld')
PINS = {
 'raw': ('/tmp/g350-both-bytes-ca9-matched49-core272-raw.json', '33584d197a1bb45a0dc76ac0a69e7016866a2369f1750c72d5eedc41ef444594'),
 'controls': ('/tmp/g350-both-bytes-ca9-matched49-core-smol-root-20261016-run272/byte0-result.json', '32eec52a75348a996f7fbfd4271b2318c9bf4c39229fd67a289d97835aa63ec4'),
 'auth': ('/tmp/g350-both-bytes-ca9-matched49-via-track-root-20261016-run274/byte0-result.json', '7459c5bd51b041686dea91b56779dcc94498b02b2a7e6ef51c796e42192d5886'),
 'plan': ('/tmp/g350-both-bytes-ca9-matched49-projector-root-20261016-run269/byte0-result.json', '4bb8153b7dddfcd73b78dad9d07483c239967680bdd25ef53b5487da46fbb107'),
}
CLI = ROOT / 'node_modules/@tscircuit/cli/dist/cli/main.js'
CLI_SHA = '2135bc7f5e27b72ddfaa9b65586c905897e4222f989328ebc0434b1d1961c19c'
LAYERS = ['top', 'inner1', 'inner2', 'bottom']
ALL49 = {'source_trace_' + str(i) for i in range(49)}
AUTH_SCOPE = 'EXPLICITLY_PINNED_M49_PLAN269_BOTH_BYTES_MATCHED_CAP12_CAP8_TWO_PDN_AUTHENTICATED_234_MANUAL_VIA_TRACK_MANUFACTURING_DIAGNOSTIC'
UF_POLICY = 'ONLY SourceTrace connected_source_port_ids and connected_source_net_ids; no PCB/copper/via alias/geometric union'

def need(ok, message):
    if not ok:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def index(rows, key):
    result = {}
    for r in rows:
        need(isinstance(r.get(key), str) and r[key] not in result, 'Unique actual ' + key)
        result[r[key]] = r
    return result

def near(a, b):
    return math.hypot(a['x'] - b['x'], a['y'] - b['y']) <= 1e-8

class Uf:
    def __init__(self): self.parent = {}
    def add(self, x): self.parent.setdefault(x, x)
    def root(self, x):
        need(x in self.parent, 'Unknown explicitly declared logical ID ' + x)
        if self.parent[x] != x: self.parent[x] = self.root(self.parent[x])
        return self.parent[x]
    def union(self, a, b):
        self.add(a); self.add(b); self.parent[self.root(b)] = self.root(a)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output-dir', type=Path, required=True)
    args = ap.parse_args()
    out = args.output_dir.absolute()
    need(out.parent.resolve() == ROOT / 'dist' and out.name.startswith('g350-source272-kicad49-') and not out.exists(),
         'Use a fresh owned board/dist/g350-source272-kicad49-* directory')
    data = {k: Path(p).read_bytes() for k, (p, _) in PINS.items()}
    for k, (_, h) in PINS.items(): need(sha(data[k]) == h, 'Exact frozen Source272 input ' + k)
    need(sha(CLI.read_bytes()) == CLI_SHA, 'Pinned stock CLI must remain exact')
    need(json.loads((ROOT / 'node_modules/@tscircuit/cli/package.json').read_text())['version'] == '0.1.2258', 'Pinned CLI version')
    raw, controls, auth, plan = [json.loads(data[k]) for k in ('raw', 'controls', 'auth', 'plan')]
    need(isinstance(raw, list) and controls['rawCoreSha256'] == PINS['raw'][1] and controls['planSha256'] == PINS['plan'][1]
         and controls['freshCoreDerived'] is True and controls['partialDiagnosticReplayControlsPassed'] is True
         and len(controls['checks']) == 35 and all(c['passed'] for c in controls['checks']), 'Actual272 all35 controls')
    need(controls['all49Connected'] is True and controls['pendingOwnerIds'] == []
         and set(controls['routedOwnerIds']) == ALL49 and len(controls['physicalGraphs']) == 49
         and all(g['physicallyConnectedByActualOwnedNumericIdGraph'] for g in controls['physicalGraphs']), 'Exact49 owned graphs')
    need(auth['scope'] == AUTH_SCOPE and auth['logicalUfPolicy'] == UF_POLICY and auth['complete'] is True
         and auth['actualViaCount'] == auth['completedViaCount'] == 234 and auth['exactInputFilesUnchanged'] is True
         and auth['foreignViaTrackCopperClearancePassed'] is True
         and all(auth[k] == [] for k in ('violations', 'ambiguousVias', 'identityFailures', 'invalidSegments', 'unresolvedSegmentOwners')), 'Exact completed274 ownership diagnostic')
    for k in ('raw', 'controls', 'plan'):
        need(auth['inputBindings'][k]['sha256'] == PINS[k][1], 'Current auth binding ' + k)
    rows = lambda kind: [r for r in raw if r.get('type') == kind]
    types = {kind: index(rows(kind), key) for kind, key in [
        ('source_component', 'source_component_id'), ('source_manually_placed_via', 'source_manually_placed_via_id'),
        ('source_trace', 'source_trace_id'), ('source_port', 'source_port_id'), ('source_net', 'source_net_id'),
        ('pcb_component', 'pcb_component_id'), ('pcb_port', 'pcb_port_id'), ('pcb_trace', 'pcb_trace_id'), ('pcb_via', 'pcb_via_id')]}
    parts, manual, st, sp, sn, pc, pp, traces, vias = [types[k] for k in (
        'source_component', 'source_manually_placed_via', 'source_trace', 'source_port', 'source_net', 'pcb_component', 'pcb_port', 'pcb_trace', 'pcb_via')]
    need((len(parts), len(manual), len(pc), len(vias), len(traces)) == (280, 234, 514, 234, 317), 'Exact typed inventory')
    uf, declarations = Uf(), []
    for sid, t in st.items():
        uf.add(sid)
        ports, nets = t.get('connected_source_port_ids', []), t.get('connected_source_net_ids', [])
        for value in ports: need(value in sp, 'Actual SourcePort declaration'); uf.union(sid, value)
        for value in nets: need(value in sn, 'Actual SourceNet declaration'); uf.union(sid, value)
        declarations.append({'sourceTraceId': sid, 'connectedSourcePortIds': ports, 'connectedSourceNetIds': nets})
    need(declarations == auth['declaredLogicalSources'], 'Independent Source-only UF declarations identical to274')
    key_names, keys_by_root = {}, {}
    for net in sn.values():
        key = net.get('subcircuit_connectivity_map_key') or net['source_net_id']
        key_names[key] = net.get('name') or net['source_net_id']
    def trace_key(t):
        key = t.get('subcircuit_connectivity_map_key')
        if not key:
            for nid in t.get('connected_source_net_ids', []):
                n = sn[nid]; key = n.get('subcircuit_connectivity_map_key') or n['source_net_id']
                if key: break
        need(isinstance(key, str) and key, 'Real Source trace connectivity key')
        return key
    for sid, t in st.items():
        key = trace_key(t)
        key_names.setdefault(key, t.get('display_name') or sid)
        keys_by_root.setdefault(uf.root(sid), set()).add(key)
    alias_incidents = {}
    for t in traces.values():
        need(t['source_trace_id'] in st and len(t['route']) >= 2 and all(p['route_type'] == 'wire' for p in t['route']), 'Pure real source-owned wire rows')
        for p in t['route']:
            for field in ('start_pcb_port_id', 'end_pcb_port_id'):
                pid = p.get(field)
                if pid:
                    need(pid in pp and near(p, pp[pid]) and p['layer'] in pp[pid]['layers'], 'Authentic actual endpoint alias')
                    alias_incidents.setdefault(pid, set()).add(t['source_trace_id'])
    auth_vias = index(auth['viaReports'], 'pcbViaId')
    need(set(auth_vias) == set(vias), 'Every actual via independently covered')
    export = copy.deepcopy(raw); changes, expected_vias = [], []
    alias_seen, manual_seen, component_seen = set(), set(), set()
    for i, v in enumerate(raw):
        if v.get('type') != 'pcb_via': continue
        vid, ar = v['pcb_via_id'], auth_vias[v['pcb_via_id']]
        need(ar['aliasIdentityAuthenticated'] and ar['logicalOwnerResolved'] and ar['identityErrors'] == []
             and ar['unresolvedOwnerEvidence'] == [] and len(ar['authenticatedLogicalRoots']) == 1, 'No ambiguous via ownership')
        need(v['layers'] == LAYERS and v['from_layer'] == 'top' and v['to_layer'] == 'bottom'
             and v['outer_diameter'] == .4572 and v['hole_diameter'] == .254 and near(v, ar['xy']), 'Actual fullspan via material')
        ids = v['pcb_port_ids']; need(len(ids) >= 2 and len(ids) == len(set(ids)) and not (set(ids) & alias_seen), 'Unique actual aliases')
        alias_seen.update(ids); sources, components, observed = set(), set(), set()
        aliases = []
        for pid in ids:
            p = pp[pid]; s = sp[p['source_port_id']]; c = pc[p['pcb_component_id']]
            need(near(v, p) and len(p['layers']) == 1 and s['name'] == p['layers'][0]
                 and s['source_component_id'] in manual and c['source_component_id'] == s['source_component_id'], 'Typed actual PP/SP/manual/component chain')
            sources.add(s['source_component_id']); components.add(c['pcb_component_id'])
            observed.update(uf.root(sid) for sid in alias_incidents.get(pid, []))
            observed.update(uf.root(sid) for sid, t in st.items() if s['source_port_id'] in t.get('connected_source_port_ids', []))
            aliases.append({'actualPcbPortId': pid, 'actualSourcePortId': s['source_port_id'], 'layer': p['layers'][0]})
        if v.get('source_net_id'): observed.add(uf.root(v['source_net_id']))
        need(len(sources) == len(components) == 1 and not (sources & manual_seen) and not (components & component_seen), 'One unique manual via component')
        manual_seen.update(sources); component_seen.update(components)
        need(observed == set(ar['authenticatedLogicalRoots']) == {ar['selectedLogicalRoot']}, 'Recomputed explicit endpoint/declaration roots agree')
        root = ar['selectedLogicalRoot']; keys = keys_by_root[root]
        need(len(keys) == 1, 'One genuine connectivity key per authenticated Source-only root')
        key = next(iter(keys)); old = v.get('subcircuit_connectivity_map_key')
        fallback = sn[v['source_net_id']].get('subcircuit_connectivity_map_key') or v['source_net_id'] if v.get('source_net_id') else None
        need(old is None or old == key, 'Existing via key must agree, never overwritten')
        need(fallback is None or fallback == key, 'Declared via net must agree')
        if not old and not fallback:
            after = copy.deepcopy(v); after['subcircuit_connectivity_map_key'] = key; export[i] = after
            changes.append({'rawIndex': i, 'actualPcbViaId': vid, 'before': v, 'after': after,
                            'addedKey': key, 'authenticatedLogicalRoot': root, 'actualAliasEvidence': aliases})
        expected_vias.append({'raw': v, 'actualPcbViaId': vid, 'connectivityKey': key, 'expectedNetName': key_names[key],
                              'authenticatedLogicalRoot': root, 'actualLayerAliases': aliases})
    need(len(changes) == 103, 'Exactly103 missing signal via keys; no other metadata edited')
    inverse = copy.deepcopy(export)
    for change in changes: inverse[change['rawIndex']] = change['before']
    need(inverse == raw, 'Exact full-array inverse restores every original field and record')
    physical_parts, lands = [], []
    for cid, c in pc.items():
        if c['source_component_id'] in parts:
            physical_parts.append({'source': parts[c['source_component_id']], 'pcb': c})
    for land in rows('pcb_smtpad') + rows('pcb_plated_hole'):
        p = pp[land['pcb_port_id']]; s = sp[p['source_port_id']]; c = pc[land['pcb_component_id']]
        need(s['source_component_id'] in parts and c['source_component_id'] == s['source_component_id'], 'Real-part land ownership')
        need(s.get('pin_number') is not None, 'Actual numeric physical pad number')
        lands.append({'raw': land, 'pcbPort': p, 'sourcePort': s, 'reference': parts[s['source_component_id']]['name'], 'pin': str(s['pin_number'])})
    need(len(physical_parts) == 280 and len(lands) == 1165, 'All real parts/semantic lands retained')
    projections = index(controls['logical49Projection'], 'originalSourceTraceId')
    signals, wire_segments = [], []
    for oid, p in projections.items():
        endpoints = []
        for pid in p['actualNumericPcbPortIds']:
            port = pp[pid]; source = sp[port['source_port_id']]; part = parts[source['source_component_id']]
            need(part['name'] in ('U_SOC', 'U_RAM') and port['layers'] == ['top'], 'Actual CPU/RAM numeric Top endpoints')
            endpoints.append({'reference': part['name'], 'pin': str(source['pin_number']), 'pcbPort': port, 'sourcePort': source})
        need({e['reference'] for e in endpoints} == {'U_SOC', 'U_RAM'}, 'One genuine endpoint per package')
        root = uf.root(p['actualSourceTraceId']); key = trace_key(st[p['actualSourceTraceId']])
        signals.append({'originalSourceTraceId': oid, 'actualSourceTraceId': p['actualSourceTraceId'], 'name': st[p['actualSourceTraceId']]['name'],
                        'connectivityKey': key, 'expectedNetName': key_names[key], 'root': root, 'endpoints': endpoints,
                        'viaIds': [v['actualPcbViaId'] for v in expected_vias if v['authenticatedLogicalRoot'] == root]})
    need(set(projections) == ALL49 and len({s['root'] for s in signals}) == 49, '49 distinct original signal logical roots')
    actual_to_original = {p['actualSourceTraceId']: p['originalSourceTraceId'] for p in controls['logical49Projection']}
    for tid, t in traces.items():
        key = trace_key(st[t['source_trace_id']])
        for i, (a, b) in enumerate(zip(t['route'], t['route'][1:])):
            need(a['layer'] == b['layer'] and a['layer'] in LAYERS, 'Actual pure same-layer wire run')
            if (a['x'], a['y']) == (b['x'], b['y']): continue
            wire_segments.append({'actualPcbTraceId': tid, 'actualSourceTraceId': t['source_trace_id'], 'originalOwner': actual_to_original.get(t['source_trace_id']),
                                  'routeIndex': i, 'a': {'x': a['x'], 'y': a['y']}, 'b': {'x': b['x'], 'y': b['y']},
                                  'layer': a['layer'], 'width': a.get('width', b.get('width', t.get('width', .25))), 'expectedNetName': key_names[key]})
    need(len(wire_segments) == auth['wireSegmentCount'], 'Complete actual wire catalog agrees with current ownership diagnostic')
    expected = {'scope': 'SOURCE272_KICAD49_EXPECTED_GEOMETRY_AND_AUTHENTIC_OWNERSHIP_NOT_CAD_QUALIFICATION',
        'inputBindings': {k: {'path': p, 'sha256': h} for k, (p, h) in PINS.items()}, 'stockCli': {'path': str(CLI), 'sha256': CLI_SHA, 'version': '0.1.2258'},
        'coordinateFrame': {'x': '100 + sourceX', 'y': '100 - sourceY', 'toleranceMm': 1e-5},
        'parts': physical_parts, 'lands': lands, 'vias': expected_vias, 'wireSegments': wire_segments, 'signals': signals,
        'originalSourceRuleBridge': controls['sourceRuleBridge'], 'originalTimingObservations': controls['timingObservations'],
        'expectedCounts': {'realParts': 280, 'representedPcbComponents': 514, 'lands': 1165, 'vias': 234, 'ownedSignals': 49, 'copperLayers': 4},
        'fullBoardPassed': False, 'all49Accepted': False, 'fabricationReady': False}
    out.mkdir(parents=False, exist_ok=False)
    def write(name, value):
        p = out / name
        with p.open('x') as f: json.dump(value, f, indent=2, allow_nan=False); f.write('\n'); os.fchmod(f.fileno(), 0o600)
        return {'path': str(p), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
    original = out / 'original-source272.circuit.json'
    with original.open('xb') as f: f.write(data['raw']); os.fchmod(f.fileno(), 0o600)
    representation = write('source272-via-key-bridge.circuit.json', export)
    catalog = write('source272-kicad49-expected.json', expected)
    bridge = {'scope': 'SOURCE272_EXPLICIT_SERIALIZER_VIA_NET_KEY_BRIDGE_NO_GEOMETRY_CHANGE', 'inputBindings': expected['inputBindings'],
        'originalRawByteIdenticalCopy': {'path': str(original), 'sha256': PINS['raw'][1]}, 'exportRepresentation': representation,
        'expectedCatalog': catalog, 'addedViaKeyCount': len(changes), 'changes': changes, 'exactInversePassed': True,
        'ownershipPolicy': UF_POLICY, 'stockCli': expected['stockCli'], 'originalRawRowsEdited': False,
        'exportRepresentationMetadataAugmented': True, 'geometryLayersDimensionsOrNumericIdsChanged': False,
        'sdkExecuted': False, 'kicadExecuted': False, 'nativeFindingsFiltered': False, 'fullBoardPassed': False,
        'all49Accepted': False, 'fabricationReady': False, 'maskTentingTransferVerified': False}
    for k, (p, h) in PINS.items(): need(sha(Path(p).read_bytes()) == h, 'Input changed during preparation ' + k)
    need(sha(CLI.read_bytes()) == CLI_SHA and sha(original.read_bytes()) == PINS['raw'][1], 'Stock CLI/raw byte copy unchanged')
    write('SERIALIZER_BRIDGE.json', bridge)
    print(json.dumps({'outputDirectory': str(out), 'exportRepresentation': representation, 'expectedCatalog': catalog,
                      'addedViaKeys': len(changes), 'sdkExecuted': False, 'all49Accepted': False, 'fabricationReady': False}))

if __name__ == '__main__': main()
