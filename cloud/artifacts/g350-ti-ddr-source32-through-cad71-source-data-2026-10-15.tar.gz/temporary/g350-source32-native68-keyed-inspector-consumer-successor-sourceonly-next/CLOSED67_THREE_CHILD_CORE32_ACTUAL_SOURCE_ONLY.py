 def closed67():
  prior=closed66();assert prior['actualClosedScopeCount']==66 and proposal['actual67Sealed']is True
  for key in('actual67CollectionPin','actual67PostauditPin','actual67GuardManifestPin','actual67CoreRawPin','actual67CoreControlsPin','actual67CapturePin','actual67DiagnosticPin'):binding(proposal[key])
  r=read(proposal['actual67CollectionPin']['path']);p=read(proposal['actual67PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is r['passed']is p['passed']is True and r['toolExitCode']==r['toolWrapperExitCode']==0 and r['toolSessionId']==proposal['actual67ToolSessionId']
  assert r['postauditPath']==proposal['actual67PostauditPin']['path']and r['postauditSha256']==proposal['actual67PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior
  for d in(r,p):
   assert d['scope']=='ROOT_SOURCE32_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH66_AUTHENTIC_PRIOR_CLOSURES'and d['phase']=='capture-types-core-batch'and d['sourceManifestSha256']==proposal['promoted32ManifestPin']['sha256']and d['rootGuardProposalManifestSha256']==proposal['actual67GuardManifestPin']['sha256']
   assert d['orderedPhaseNames']==d['expectedPhaseNames']==['capture','types','core']and d['notAttemptedPhaseNames']==[]and 'execution'not in d
   for k in('passedMeansCaptureStrictTypesAndRawCore32Only','batchScopeContainsThreeSerialOwnedChildren','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','allThreeChildrenNaturallyCompleted'):assert d[k]is True
   assert d['batchFailure']is d['finalVerificationFailure']is None and d['CoreCalls']==d['CoreChildInvocations']==d['captureChildInvocations']==d['typesChildInvocations']==1
   assert all(d[k]==0 for k in('nativeCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'))and all(d[k]is False for k in('Source32Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'))
  assert r['phases']==p['phases']and len(p['phases'])==3 and len(proposal['actual67PhasePostauditPins'])==3
  before_end=None;groups=[]
  for i,row in enumerate(p['phases']):
   phasepin=proposal['actual67PhasePostauditPins'][i];binding(phasepin);assert row['postauditPath']==phasepin['path']and row['postauditSha256']==phasepin['sha256']and read(phasepin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   assert row['phase']==['capture','types','core'][i]and all(row[k]is True for k in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'))and all(row[k]is None for k in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'))
   e=row['execution'];h.finite(e,0);assert e['policy']==batch32['phasePolicies'][row['phase']]and e['pid']==e['pgid']and e['currentGuardPid']==proposal['actual67GuardPid']and e['pgid']not in groups and(before_end is None or before_end<=e['startedAt']);groups.append(e['pgid']);before_end=e['endedAt']
   assert c.guard.process_scope.owned(e['pgid'])==[]and row['guardIdentityBefore']==row['guardIdentityAfter']==p['sameGuardIdentity']and row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']
   for artifact in row['outputFiles']:binding(artifact)
  capture,types,core=p['phases'];assert capture['result']==inspect32_capture({'capture':Path(proposal['actual67CapturePin']['path']),'diagnostic':Path(proposal['actual67DiagnosticPin']['path'])})and types['result']['strictNoEmitTypecheckNatural0']is True and types['result']['actualPriorCapturePin']==capture['result']['sourceCapturePin']
  assert core['result']==inspect32_core({'raw':Path(proposal['actual67CoreRawPin']['path']),'controls':Path(proposal['actual67CoreControlsPin']['path'])},capture['result']['sourceCapturePin'])and core['result']['rawCorePin']==proposal['actual67CoreRawPin']and core['result']['coreControlsPin']==proposal['actual67CoreControlsPin']
  assert capture['result']['sourceCapturePin']==proposal['actual67CapturePin']and capture['result']['sourceDiagnosticPin']==proposal['actual67DiagnosticPin']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]and r['independentlyObservedOwnedGroupMembers']=={str(g):[]for g in groups}and not Path('/proc',str(proposal['actual67GuardPid'])).exists();h.held_inventory_post(p)
  prior['actual67Source32CaptureTypesCoreCollectionPin']={k:proposal['actual67CollectionPin'][k]for k in('path','sha256')};prior['actual67ThreeSerialCaptureTypesCore32PassedOnly']=True;prior['actualClosedScopeCount']=67
  return prior
 def native32_bindings():
  bindings()
  for row in native32_preparation['files']+native32_preparation['externalFiles']:binding(row)
  binding(proposal['native32PreparationPin']);binding(proposal['native32TemplatePin']);binding(proposal['native32StageContractPin'])
  assert native32_preparation['knownPromotedSource32Manifest']==proposal['promoted32ManifestPin']and native32_preparation['knownPromotedSource32Proposal']==proposal['promoted32ProposalPin']and native32_template['source32ProposalPath']==proposal['promoted32ProposalPin']['path']and native32_template['source32ProposalSha256']==proposal['promoted32ProposalPin']['sha256']
  assert policy32=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
