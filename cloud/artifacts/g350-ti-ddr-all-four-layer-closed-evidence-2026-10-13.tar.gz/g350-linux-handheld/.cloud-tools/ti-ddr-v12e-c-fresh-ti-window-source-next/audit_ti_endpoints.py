"""Pure JSON endpoint audit; never imports Circuit/Core/native/router APIs."""
import copy,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PARENT=Path('/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-c-cohort-qualified-input-bridge-next')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def audit():
 old=json.loads((PARENT/'input.json').read_bytes());by={c['name']:c for c in old['connections']};assert len(by)==49
 details={};maxima={}
 for b in old['buses']:
  rows=[]
  for name in b['connectionNames']:
   c=by[name];p,q=c['pointsToConnect'];d=abs(q['x']-p['x'])+abs(q['y']-p['y'])
   rows.append({'name':name,'source_trace_id':c['source_trace_id'],'start':p,'end':q,'manhattanMm':d})
  details[b['busId']]=rows;maxima[b['busId']]=max(r['manhattanMm'] for r in rows)
 assert abs(maxima['DDR_COMMAND_CLOCK']-14.6)<1e-7 and abs(maxima['DDR_BYTE0']-13.0)<1e-7 and abs(maxima['DDR_BYTE1']-15.4)<1e-7
 caclm=maxima['DDR_COMMAND_CLOCK']+7.62;lower=round(caclm-1.27,9);upper=round(caclm+1.27,9)
 assert (lower,upper)==(20.95,23.49)
 for name in ['input.json','original-unrestricted-input.json']:
  expected=json.loads((PARENT/name).read_bytes());ca=next(b for b in expected['buses'] if b['busId']=='DDR_COMMAND_CLOCK');assert ca['minLength']==21.15 and ca['maxLength']==23.69
  ca['minLength']=lower;ca['maxLength']=upper;actual=json.loads((ROOT/name).read_bytes());assert actual==expected
  for b in actual['buses']:
   if b['busId'] in ['DDR_BYTE0','DDR_BYTE1']:assert 'minLength' not in b and b['maxLength']==({'DDR_BYTE0':13.2,'DDR_BYTE1':14.4}[b['busId']])
   if b['busId']!='DDR_RESET':assert b['maxLengthSkew']==0.635
  assert all(p['lengthTolerance']==0.127 for p in actual['differentialPairs'])
 expected={'scope':'PURE_ACTUAL_C_ENDPOINT_TI_CA_WINDOW_AUDIT','parentInputSha256':sha(PARENT/'input.json'),'parentBroadInputSha256':sha(PARENT/'original-unrestricted-input.json'),'actualEndpointDetails':details,'maximumManhattanMm':maxima,'caclmMm':round(caclm,9),'caToleranceMm':1.27,'previousCAWindowMm':[21.15,23.69],'freshCAWindowMm':[lower,upper],'dataByteMinimumsAbsent':True,'dataByteMaximumsHeld':[13.2,14.4],'busSkewMm':0.635,'pairSkewMm':0.127,'changedNativeBusFieldsOnly':['DDR_COMMAND_CLOCK.minLength','DDR_COMMAND_CLOCK.maxLength'],'signalLayerAndGeometryFieldsHeld':True,'tiSource':{'document':'AM335x SPRS717L revised March2020','printedPage':187,'table':'7-68','row':13,'note':9,'layoutExtractLines':[785,803],'frozenPdfSha256':'ec145b6b19a7ff35118bb0ec06b5ae9c51aa97ccdf4da935f2176d9168af0205'},'oldWindowProvenance':'V7 maxManhattan14.8 plus7.62 ±1.27; preserved through V9 RAM+0.2Y and V10','newCoreBuildPerformed':False,'newNativePlacementCheckPerformed':False,'nativePlacementChecksInheritedNotRerun':True,'electricalTimingQualified':False,'referenceQualified':False,'TIplaneArrangement':False,'accepted49':False,'fabricationReady':False}
 assert json.loads((ROOT/'endpoint-ti-audit.json').read_bytes())==expected
 return expected
