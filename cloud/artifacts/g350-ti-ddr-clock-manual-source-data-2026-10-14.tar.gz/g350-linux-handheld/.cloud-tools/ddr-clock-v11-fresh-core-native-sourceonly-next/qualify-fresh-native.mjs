// Root-only future Native invocation. No Core render, CLI, CAD or routing.
import assert from 'node:assert/strict'
import fs from 'node:fs'
import {createHash} from 'node:crypto'
import * as checks from '/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js'
import {g350DdrPhysicalChecks} from '/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v10-ca-top-bytes-bottom-prefork-successor-next/source/scripts/lib/g350-ddr-physical-checks.mjs'
import {proveSharedPackageLoops} from '/workspace/g350-linux-handheld/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/prove-shared-package-loops.mjs'
import {proveFreshClockCore} from './fresh-owner-factory.mjs'
import {checkG350ProvedViaBranchManufacturingClearance} from './fresh-via-branch-manufacturing-clearance.mjs'
const BOARD='/workspace/g350-linux-handheld',ROOT=import.meta.dir
const digest=b=>createHash('sha256').update(b).digest('hex')
const [manifestPath,manifestSha,authorityPath,authoritySha,output,...extra]=process.argv.slice(2)
assert.equal(process.env.G350_CLOCK_FRESH_NATIVE_APPROVED,'1');assert.equal(process.versions.bun,'1.3.14')
assert(manifestPath&&manifestSha&&authorityPath&&authoritySha&&output&&!extra.length&&!fs.existsSync(output))
const load=(path,sha)=>{const raw=fs.readFileSync(path);if(sha)assert.equal(digest(raw),sha);return JSON.parse(raw)}
const manifest=load(manifestPath,manifestSha),authority=load(authorityPath,authoritySha)
assert.equal(authority.authorizedByRoot,true);assert.equal(authority.scope,manifest.scope);assert.equal(authority.packetSha256,manifestSha)
for(const row of [...manifest.files,...manifest.externalFiles]){const p=fs.lstatSync(row.path);assert(p.isFile()&&!p.isSymbolicLink());const b=fs.readFileSync(row.path);assert.equal(b.length,row.bytes);assert.equal(p.mode&0o777,row.mode);assert.equal(digest(b),row.sha256)}
assert.equal(digest(fs.readFileSync(BOARD+'/node_modules/@tscircuit/checks/dist/index.js')),'1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc')
const fresh=load(authority.freshArtifacts.actualCorePath,authority.freshArtifacts.actualCoreSha256),controls=load(authority.freshArtifacts.coreControlsPath,authority.freshArtifacts.coreControlsSha256)
assert.equal(controls.rawCorePath,authority.freshArtifacts.actualCorePath);assert.equal(controls.rawCoreSha256,authority.freshArtifacts.actualCoreSha256);assert.equal(controls.freshCoreControlPassed,true)
const old=load(BOARD+'/.cloud-tools/ddr-package101-core-qualification-source-next/run-core/fresh-core.circuit.json','ed33a0a335b1fbf0da9adcdeacaa954b655c3c4964c600efb6ef3c72aef4040e')
const golden=load(BOARD+'/.cloud-tools/ddr-hs-all32-capture-first-type4096-root-successor-next/run-core/fresh-core.circuit.json','384628cd46c2b5cb5b32a94d442651eda3c604c8acf19bd85fc68b728f529769')
const proposal=load(BOARD+'/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/grouped-proposal.json','fffd02510548c16606eff4f6489da9860e45af82aca1cbc8e053a1201bc148a5')
const signal=load(BOARD+'/.cloud-tools/ddr-package101-signal96-joint-native-sourceonly-next/signal-source-proposal.json','7430bd5d5201af6e53dde9d07dc38395811adb4e6fc923949d4b4a772c8d304a')
const clock=load(BOARD+'/.cloud-tools/ddr-package101-signal96-clock-v11-source-contract-next/clock-fidelity-source-proposal.json','ad1ed113e5c35b81b94839808d8e22c8c00aafb2f9f57889e4a3d8a1794bb973')
const originalProof=proveSharedPackageLoops({proposal,goldenCore:golden,freshCore:old})
const signature=JSON.stringify(fresh),proof=proveFreshClockCore({freshCore:fresh,controls,oldCore:old,oldPackageProof:originalProof,signalProposal:signal,clockProposal:clock})
const names=[...g350DdrPhysicalChecks,'checkPadPadClearance','checkTracesAreContiguous','checkDanglingTraces','checkPcbTracesOutOfBoard','checkPcbCopperOverKeepout','checkPcbComponentOverlap','checkPcbComponentsOutOfBoard'];assert.equal(names.length,17)
const results={},timing={}
for(const name of names){assert.equal(typeof checks[name],'function');results[name]=checks[name](fresh)}
results.checkG350ProvedViaBranchManufacturingClearance=checkG350ProvedViaBranchManufacturingClearance(fresh,proof)
// Call the unchanged full-circuit Native functions. The direct original Source
// IDs own all3 paths, so both Top stubs are part of their native planar sum.
// Other 47 links and global timing remain unfinished; no scoped soup is built.
timing.checkPcbBusLengthSkew=checks.checkPcbBusLengthSkew(fresh)
timing.checkPcbRoutingConstraints=checks.checkPcbRoutingConstraints(fresh)
const actualClockBus=fresh.filter(r=>r.type==='source_bus'&&r.name==='DDR_CK_PAIR');assert.equal(actualClockBus.length,1)
assert.deepEqual(actualClockBus[0].source_trace_ids,['source_trace_33','source_trace_34']);assert.equal(actualClockBus[0].max_length_skew,.127)
const clockNativeFindings=Object.values(timing).flat().filter(r=>r.source_bus_id===actualClockBus[0].source_bus_id)
assert.equal(JSON.stringify(fresh),signature,'Original Native calls cannot modify actual raw Core')
const physicalErrors=Object.values(results).flat().length,skew=Math.abs(proof.clocks[0].wholePlanarLengthMm-proof.clocks[1].wholePlanarLengthMm)
const report={scope:'ACTUAL_FRESH_CORE_NATIVE18_OWNED_REFERENCE_FANOUT_AND_CLOCK_ONLY_QUALIFICATION',packetSha256:manifestSha,actualCorePath:authority.freshArtifacts.actualCorePath,actualCoreSha256:authority.freshArtifacts.actualCoreSha256,actualCoreControlsSha256:authority.freshArtifacts.coreControlsSha256,checkCount:18,counts:Object.fromEntries(Object.entries(results).map(([name,issues])=>[name,issues.length])),results,physicalErrors,unchangedNativeTimingFunctions:timing,actualClockNativeFindings:clockNativeFindings,actualClockSourceBusId:actualClockBus[0].source_bus_id,actualOwnershipProof:proof,actualWholeClockPlanarSkewMm:skew,maximumClockPairSkewMm:.127,physicalExistingThroughBarrelsPerClock:2,routeViaMarkerCountPerClock:0,legacyViaMarkerContributionMm:0,all165ReferencePathsPreserved:true,all129ReferenceBarrelsPreserved:true,all96SignalBarrelsAndTopStubsPreserved:true,all49OriginalLogicalNumericRequestsPreserved:true,sourceNetFabricationPerformed:false,circuitJsonGeometryOrIdentitiesEdited:false,globalSameNetManufacturingExemption:false,rawCircuitUnmodified:true,onlyAuthenticRam25Hs8PadAndStripContactRegistered:true,originalCouplingApisAgainstActualGeometryRequiredSeparately:true,noCoreRenderPerformed:true,noRoutingPerformed:true,noCliOrCadPerformed:true,full49RoutesUnfinished:true,fullCohortTimingPassed:false,electricalTimingQualified:false,referenceQualified:false,accepted49:false,fabricationReady:false}
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600})
assert.equal(physicalErrors,0,'Actual Native18 physical/manufacturing findings retained before assertion')
assert.equal(clockNativeFindings.length,0,'Actual unmodified Native clock pair findings retained')
assert(skew<=.127+1e-9)
console.log(JSON.stringify({actualNative18PhysicalErrors:physicalErrors,actualClockPairNativeFindings:clockNativeFindings.length,actualClockPlanarSkewMm:skew,full49RoutesUnfinished:true,accepted49:false,fabricationReady:false}))
