/** SOURCE-ONLY proposal: Node V5 with bounded primitive original Grid/replay observation. */
import assert from "node:assert/strict"
import { createHash } from "node:crypto"
import fs from "node:fs"
import path from "node:path"
import { createPublicPipeline, runPublicSteps } from "./public-pipeline-protocol"
import type { ScalarProgress } from "./public-pipeline-protocol"
import { sameHardware } from "./input-parity"
import { originalNaturalPublicOutput } from "./natural-public-output"
import { installPositiveBankStats } from "./positive-bank-stats"
import { installStagePrimitives } from "./stage-primitives"
import { createStageTelemetry } from "./stage-telemetry"
import { installGlobalSelectionPrimitives } from "./global-selection-primitives"
import { ownPublicFailureFields } from "./public-failure-fields"
import { installPrivateSelectionPrimitives } from "./private-selection-primitives"
import { installPrivateGapPrimitives } from "./private-gap-primitives"
import { installClockHardSceneCapture } from "./hard-scene-capture.cjs"
import { deriveClockGroupProjection, verifyClockGroupProjection } from "./clock-group-projection.cjs"
import type { SimpleRouteJson } from "./source/lib/types"

const ROOT = __dirname
const sha = (bytes: string | Uint8Array) => createHash("sha256").update(bytes).digest("hex")
const atomic = (name: string, raw: string) => {
  const target = path.join(ROOT, "run", name)
  fs.writeFileSync(`${target}.tmp`, raw, { flag: "wx" })
  fs.renameSync(`${target}.tmp`, target)
}

export async function main() {
  assert.deepEqual(process.argv.slice(2), ["--run-one-approved"])
  assert.equal(process.env.G350_NODE_UNINSTRUMENTED_APPROVED, "1")
  assert.equal(process.version, "v25.6.1")
  assert.deepEqual(process.execArgv, [], "No extra Node runtime flags")
  assert.equal(process.env.NODE_OPTIONS ?? "", "", "Inherited NODE_OPTIONS must be empty; do not silently override it")
  const packetRaw = fs.readFileSync(path.join(ROOT, "FINAL-manifest.json"))
  const packet = JSON.parse(packetRaw.toString())
  const packetSha256 = sha(packetRaw)
  assert.equal(packet.nodeArtifactQualified, true)
  assert.equal(packet.privateGapCardinalityQualificationPassed, true)
  assert.equal(packet.hardSceneCaptureV2QualificationPassed, true)
  assert.equal(packet.hardSceneReleaseObserverQualificationPassed, true)
  assert.equal(packet.exactClockProjectionQualificationPassed, true)
  assert.equal(packet.hardSceneActiveCpuCaptureQualificationPassed, true)
  assert.equal(packet.runtimeCardinalityClassOriginQualified, true)
  assert.equal(packet.privateOwnedViaNativeQualificationPassed, true)
  assert.equal(packet.strictOriginalNativeFailureRecorded, true)
  assert.equal(packet.nativeAdapterSourceQualified, true)
  assert.equal(packet.noPitchPhaseRetry, true)
  assert.equal(packet.allQualificationWorkersCollected, true)
  assert.equal(packet.privateSelectionObserverQualificationPassed, true)
  assert.equal(packet.privateSelectionClassOriginQualified, true)
  assert.equal(packet.nativePlacementChecksInheritedNotRerun, true)
  assert.equal(packet.actualCoreGeometryReusedNotFreshlyRendered, true)
  assert.equal(packet.actualCoreInputQualified, true, "Fresh V12e Core input must qualify before public routing")
  assert.equal(packet.actualCoreNativePlacementChecks, 17)
  assert.equal(packet.actualCoreNativePlacementErrorCount, 0)
  assert.equal(packet.actualInputAndSourceParityQualified, true)
  assert.equal(packet.actualPrivateFanoutBundleQualified, true)
  assert.equal(packet.privatePatchedMatcherSha256, "52bc23fc38acacf1b85bd37245a2f69ead3356fa8fa59751743784a99364cac4")
  assert.equal(packet.exactAll49SourceConnectionsQualified, true)
  assert.equal(packet.signalLayersAllowed.join(","), "top,inner1,inner2,bottom")
  assert.equal(packet.tiWireClassSpacingAdopted, false)
  assert.equal(packet.observationMode, "PRIMITIVE_GRID_REPLAY_STATS_SELECTION_GAP_AND_BOUNDED_HARD_SCENE")
  assert.equal(process.env.NODE_PATH ?? "", packet.inheritedEnvironment.NODE_PATH)
  const receiptPath = process.env.G350_NODE_RECEIPT_PATH
  const receiptSha256 = process.env.G350_NODE_RECEIPT_SHA256
  assert.ok(receiptPath && receiptSha256)
  const receiptRaw = fs.readFileSync(receiptPath)
  assert.equal(sha(receiptRaw), receiptSha256)
  const receipt = JSON.parse(receiptRaw.toString())
  assert.equal(receipt.authorizedByRoot, true)
  assert.equal(receipt.scope, "one-node25-runtime128-cpu34-active-observer-ti-v12e-c-public-diagnostic")
  assert.equal(receipt.packetSha256, packetSha256)
  assert.deepEqual(receipt.policy, packet.policy)
  assert.match(receipt.approvalToken, /^[0-9a-f]{32,128}$/)
  assert.ok(fs.existsSync(path.join(ROOT, "run")))
  for (const name of ["result.json", "public-progress.jsonl", "natural-public-output.json", "latest-positive-bank-stats.json", "latest-stage-primitives.jsonl", "latest-private-selection-primitives.jsonl", "latest-private-gap-primitives.jsonl", "latest-clock-hard-scene.json", "joint-native-private-report.json", "natural-native-private-report.json"])
    assert.equal(fs.existsSync(path.join(ROOT, "run", name)), false, "Fresh output required")
  const inputRaw = fs.readFileSync(path.join(ROOT, "input.json"))
  const originalRaw = fs.readFileSync(path.join(ROOT, "original-unrestricted-input.json"))
  assert.equal(sha(inputRaw), packet.inputBindings["input.json"].sha256)
  assert.equal(sha(originalRaw), packet.inputBindings["original-unrestricted-input.json"].sha256)
  const input = JSON.parse(inputRaw.toString()) as SimpleRouteJson
  const original = JSON.parse(originalRaw.toString()) as SimpleRouteJson
  assert.equal(sameHardware(input, original), true)
  assert.equal(input.connections.length, 49)
  assert.equal(input.traces?.length, 2)
  const before = JSON.stringify(input)
  const fixedBefore = sha(JSON.stringify(input.traces))
  let solver: any
  let terminal: ReturnType<typeof runPublicSteps> | undefined
  let exception: string | null = null
  let phase: string | null = null
  let lastBucket = -1
  let progressRows = 0, progressBytes = 0, droppedProgress = 0, writeErrors = 0
  let statsObserver: ReturnType<typeof installPositiveBankStats> | undefined
  let statsWrites = 0, droppedStatsWrites = 0, statsBytes = 0, statsBindingsRestored = false
  let lastStatsBucket = -1
  let stageObserver: ReturnType<typeof installStagePrimitives> | undefined
  const stageTelemetry = createStageTelemetry()
  let stageBindingsRestored = false
  let selectionObserver: ReturnType<typeof installGlobalSelectionPrimitives> | undefined
  let selectionBindingsRestored = false
  let privateSelectionObserver: ReturnType<typeof installPrivateSelectionPrimitives> | undefined
  let privateSelectionRestored = false
  let privateSelectionPublications = 0
  let privateGapObserver: ReturnType<typeof installPrivateGapPrimitives> | undefined
  let privateGapRestored = false, privateGapPublications = 0
  let hardSceneCapture: any
  let hardSceneRestored = false, hardScenePublications = 0
  let nativeGate: any, nativeContext: any
  let privateNativePrecheckPassed = false, privateNativeNaturalOutputPassed = false
  let lastStageBucket = -1
  let lastPublicProgress: ScalarProgress | undefined
  let lastPublicObservationElapsedMs = 0
  const publishStage = (row: unknown, publicSteps: number, force = false) => {
    try {
      if (!stageObserver || !statsObserver || !stageTelemetry.canPublish()) return
      const bucket = Math.floor(publicSteps / 5000)
      if (!force && bucket === lastStageBucket) return
      lastStageBucket = bucket
      const raw = stageTelemetry.encode(publicSteps, { diagnosticOnly: true, accepted49: false, packetSha256, sourceManifestSha256: packet.sourceManifestSha256, inputSha256: sha(inputRaw), publicationKind: force ? "last-observed-public-hook" : "periodic-public-hook", publishedElapsedMs: performance.now() - started, publicStepBinding: row, positiveBankStats: statsObserver.snapshot(), stagePrimitives: stageObserver.snapshot(), globalSelection: selectionObserver?.snapshot() ?? null, privateGap: privateGapObserver?.snapshot() ?? null, hardSceneCapture: hardSceneCapture?.snapshot() ?? null }, force)
      if (raw === null) return
      atomic("latest-stage-primitives.jsonl", raw)
      stageTelemetry.recordPublication(true)
    } catch { stageTelemetry.recordPublication(false); writeErrors++ }
  }
  const publishStats = () => {
    try {
      if (!statsObserver) return
      if (statsWrites >= 1602) { droppedStatsWrites++; return }
      const raw = `${JSON.stringify({ diagnosticOnly: true, accepted49: false, packetSha256, sourceManifestSha256: packet.sourceManifestSha256, inputSha256: sha(inputRaw), snapshot: statsObserver.snapshot() })}\n`
      assert.ok(Buffer.byteLength(raw) <= 128 * 1024)
      atomic("latest-positive-bank-stats.json", raw)
      statsBytes = Buffer.byteLength(raw)
      statsWrites++
    } catch { writeErrors++ }
  }
  const started = performance.now()
  try {
    // Deferred until all Root-authority and immutable-input checks pass.
    // Adapter copies native-validation metadata only; the solver keeps input49 unchanged.
    nativeGate = await import("./private_native_gate")
    const coreRaw = fs.readFileSync(packet.actualCoreSourcePath)
    const jointRaw = fs.readFileSync(packet.actualJointGeometryPath)
    assert.equal(sha(coreRaw), packet.actualCoreSourceSha256)
    assert.equal(sha(jointRaw), packet.actualJointGeometrySha256)
    const expectedClockSceneInput = deriveClockGroupProjection(input, JSON.parse(jointRaw.toString()))
    nativeContext = nativeGate.prepareNativePhysicalScene(input, JSON.parse(coreRaw.toString()), JSON.parse(jointRaw.toString()))
    const jointNativeReport = nativeGate.validateJointNative(nativeContext, (report: unknown) => {
      const raw = JSON.stringify(report) + "\n"
      atomic("joint-native-private-report.json", raw)
    })
    assert.equal(jointNativeReport.valid, true)
    assert.equal(jointNativeReport.issues.length, 0)
    privateNativePrecheckPassed = true
    assert.equal(JSON.stringify(input), before)
    const { PositiveNativeSiteBankReplay } = await import("./source/lib/positive-native-site-bank-replay")
    const pairedNames = new Set(input.differentialPairs?.flatMap(pair => pair.connectionNames) ?? [])
    const ordinaryNames = input.connections.map(connection => connection.name).filter(name => !pairedNames.has(name))
    assert.equal(ordinaryNames.length, 43)
    statsObserver = installPositiveBankStats(PositiveNativeSiteBankReplay.prototype, ordinaryNames, input.connections.map(connection => connection.name))
    const { GridVisibilitySearch } = await import("./source/lib/grid-visibility")
    stageObserver = installStagePrimitives(GridVisibilitySearch.prototype, PositiveNativeSiteBankReplay.prototype, input.connections.map(connection => connection.name))
    // Layer the qualified active CPU snapshot after Stage; step only, restore before Stage.
    hardSceneCapture = installClockHardSceneCapture(GridVisibilitySearch.prototype, (raw: string) => {
      assert.ok(Buffer.byteLength(raw) <= 2 * 1024 * 1024)
      atomic("latest-clock-hard-scene.json", raw)
      hardScenePublications++
    }, { callerSha256: packet.coupledPairCallerSha256, gridSha256: packet.gridSourceSha256,
      publicInputSha256: sha(inputRaw), stageObserverSha256: packet.stageObserverSha256,
      precheckEnclosedTerminals: true }, expectedClockSceneInput, verifyClockGroupProjection)
    const poolModule = await import("./source/lib/solve-signal-candidate-pool")
    const pruneModule = await import("./source/lib/prune-candidate-domains")
    selectionObserver = installGlobalSelectionPrimitives(poolModule, pruneModule, input.connections.map(connection => connection.name))
    const { RouteCandidatePool } = await import("./source/lib/select-route-candidates")
    privateSelectionObserver = installPrivateSelectionPrimitives(RouteCandidatePool.prototype, () => performance.now(), (row, rolling) => {
      assert.ok(Buffer.byteLength(row) <= 128 && Buffer.byteLength(rolling) <= 2048)
      assert.ok(rolling.trimEnd().split("\n").length <= 16)
      atomic("latest-private-selection-primitives.jsonl", rolling)
      privateSelectionPublications++
    })
    privateGapObserver = installPrivateGapPrimitives(RouteCandidatePool.prototype, () => performance.now(), (row, rolling) => {
      assert.ok(Buffer.byteLength(row) <= 128 && Buffer.byteLength(rolling) <= 2048)
      assert.ok(rolling.trimEnd().split("\n").length <= 16)
      atomic("latest-private-gap-primitives.jsonl", rolling)
      privateGapPublications++
    })
    const { BusLanesPipelineSolver } = await import("./source/lib")
    solver = createPublicPipeline(BusLanesPipelineSolver, input)
    assert.equal(solver.MAX_ITERATIONS, 800_000)
    assert.equal(solver.options.goal, undefined)
    assert.equal(solver.options.maxSearchIterations, undefined)
    assert.deepEqual({ maxBusViaCountSkew: solver.options.maxBusViaCountSkew, maxPairViaCountSkew: solver.options.maxPairViaCountSkew, precheckEnclosedTerminals: solver.options.precheckEnclosedTerminals, originalCorridorTuningCandidates: solver.options.originalCorridorTuningCandidates }, packet.requestedOptions)
    terminal = runPublicSteps(solver, row => {
      // This row contains only original public scalars, including attempted steps on an exception.
      lastPublicProgress = row
      lastPublicObservationElapsedMs = performance.now() - started
      const bucket = Math.floor(row.publicSteps / 5000)
      publishStage({ ...row, elapsedMs: lastPublicObservationElapsedMs }, row.publicSteps)
      if (bucket !== lastStatsBucket) { lastStatsBucket = bucket; publishStats() }
      if (row.phase === phase && bucket === lastBucket && !row.solved && !row.failed) return
      phase = row.phase
      lastBucket = bucket
      try {
        const raw = `${JSON.stringify({ ...row, elapsedMs: performance.now() - started })}\n`
        const bytes = Buffer.byteLength(raw)
        if (progressRows < 64 && progressBytes + bytes <= 24 * 1024) {
          fs.appendFileSync(path.join(ROOT, "run", "public-progress.jsonl"), raw)
          progressRows++
          progressBytes += bytes
        } else droppedProgress++
      } catch { writeErrors++ }
    })
  } catch (error) { exception = String(error).slice(0, 1024) }
  finally {
    if (privateGapObserver) privateGapRestored = privateGapObserver.restore()
    if (hardSceneCapture) {
      try { hardSceneRestored = hardSceneCapture.restore() }
      catch { writeErrors++ }
    }
    if (privateSelectionObserver) privateSelectionRestored = privateSelectionObserver.restore()
    if (stageObserver) {
      if (lastPublicProgress) publishStage({ ...lastPublicProgress, elapsedMs: lastPublicObservationElapsedMs }, lastPublicProgress.publicSteps, true)
      selectionObserver?.restore()
      selectionBindingsRestored = selectionObserver !== undefined
      stageObserver.restore()
      stageBindingsRestored = true
    }
    if (statsObserver) { publishStats(); statsObserver.restore(); statsBindingsRestored = true }
  }
  let publicOutput: { path: string; bytes: number; sha256: string } | null = null
  if (terminal?.termination === "NATURAL_SOLVED" && exception === null) {
    const output = originalNaturalPublicOutput(solver, terminal, input)
    assert.ok(output)
    assert.ok(output.raw.byteLength <= 16 * 1024 * 1024)
    try {
      const naturalNativeReport = nativeGate.validateNaturalOutput(nativeContext, output.output, (report: unknown) => {
        const raw = JSON.stringify(report) + "\n"
        atomic("natural-native-private-report.json", raw)
      })
      assert.equal(naturalNativeReport.valid, true)
      assert.equal(naturalNativeReport.issues.length, 0)
      privateNativeNaturalOutputPassed = true
      fs.writeFileSync(path.join(ROOT, "run", "natural-public-output.json"), output.raw, { flag: "wx" })
      publicOutput = { path: "natural-public-output.json", bytes: output.raw.byteLength, sha256: sha(output.raw) }
    } catch (error) { exception = String(error).slice(0, 1024) }
  }
  const inputUnchanged = JSON.stringify(input) === before && sha(fs.readFileSync(path.join(ROOT, "input.json"))) === sha(inputRaw) && sha(fs.readFileSync(path.join(ROOT, "original-unrestricted-input.json"))) === sha(originalRaw)
  const fixedReferencesHeld = solver !== undefined && sha(JSON.stringify(solver.input.traces)) === fixedBefore
  const fullHardwareHeld = sameHardware(input, original)
  const capUnchanged = solver?.MAX_ITERATIONS === 800_000 && terminal?.defaultCap === 800_000
  const actualOptions = solver ? { maxBusViaCountSkew: solver.options.maxBusViaCountSkew, maxPairViaCountSkew: solver.options.maxPairViaCountSkew, precheckEnclosedTerminals: solver.options.precheckEnclosedTerminals, originalCorridorTuningCandidates: solver.options.originalCorridorTuningCandidates } : null
  const requestedOptionsHeld = JSON.stringify(actualOptions) === JSON.stringify(packet.requestedOptions) && solver?.options.goal === undefined && solver?.options.maxSearchIterations === undefined
  const naturalOutputGateHeld = terminal?.termination === "NATURAL_SOLVED" ? publicOutput !== null && solver?.solved === true && solver?.failed === false && solver?.traces.length === 49 : publicOutput === null
  const finalStats = statsObserver?.summary()
  const finalStageStats = stageObserver?.snapshot()
  const finalSelectionStats = selectionObserver?.snapshot()
  const privateSelectionStats = privateSelectionObserver?.snapshot()
  const privateGapStats = privateGapObserver?.snapshot()
  const hardSceneStats = hardSceneCapture?.snapshot()
  const result = {
    diagnosticOnly: true,
    diagnosticQualified: privateNativePrecheckPassed && (terminal?.termination !== "NATURAL_SOLVED" || privateNativeNaturalOutputPassed) && privateGapRestored && privateGapStats?.observationErrors === 0 && privateGapStats?.overflows === 0 && hardSceneRestored && hardSceneStats?.errors === 0 && privateSelectionRestored && privateSelectionStats?.observationErrors === 0 && privateSelectionStats?.overflows === 0 && terminal !== undefined && exception === null && inputUnchanged && fixedReferencesHeld && fullHardwareHeld && capUnchanged && requestedOptionsHeld && naturalOutputGateHeld && writeErrors === 0 && statsBindingsRestored && finalStats?.observationErrors === 0 && stageBindingsRestored && finalStageStats?.observationErrors === 0 && finalStageStats?.snapshotOverflows === 0 && stageTelemetry.snapshot().rejectedRows === 0 && stageTelemetry.snapshot().failedPublications === 0 && selectionBindingsRestored && finalSelectionStats?.totals.observationErrors === 0 && finalSelectionStats?.totals.snapshotOverflows === 0,
    observationMode: "PRIMITIVE_GRID_REPLAY_STATS_SELECTION_GAP_AND_BOUNDED_HARD_SCENE",
    privateSelectionStats: privateSelectionStats ?? null,
    privateGapStats: privateGapStats ?? null,
    privateGapRestored, privateGapPublications,
    privateGapEventRowsBound: 16, privateGapEventBytesBound: 128, privateGapRollingBytesBound: 2048,
    hardSceneStats: hardSceneStats ?? null,
    hardSceneRestored, hardScenePublications,
    hardSceneBytesBound: 2 * 1024 * 1024,
    persistedActiveCpuGeometryArtifactForExternalRootController: "latest-clock-hard-scene.json",
    runnerStopsOrCancelsOnActiveCapture: false,
    nativeValidationSceneOnlyAddsOwnedReferences: true,
    original49SolverRequestsUnchanged: true,
    privateNativePrecheckPassed, privateNativeNaturalOutputPassed,
    originalStrictNativeFailurePreviouslyRecorded: true,
    privateNativeAuditReplacesStandardDrcOrManufacturingAcceptance: false,
    privateCardinalityCacheFixOnlyRuntimeDelta: true,
    pitchPhaseRetryInstalled: false,
    privateSelectionRestored,
    privateSelectionPublications,
    privateSelectionEventRowsBound: 16,
    privateSelectionEventBytesBound: 128,
    privateSelectionRollingBytesBound: 2048,
    factoryOrSiteTelemetryInstalled: false,
    globalSelectionStats: finalSelectionStats,
    selectionBindingsRestored,
    gridOriginalMethodPrimitiveTelemetryInstalled: true,
    gridConstructorReplacementInstalled: false,
    moduleReplacementInstalled: false,
    engine: process.version,
    execArgv: process.execArgv,
    inheritedNodeOptions: process.env.NODE_OPTIONS ?? "",
    inheritedNodePath: process.env.NODE_PATH ?? "",
    packetSha256,
    sourceCommit: null,
    sourceFileCount: 128,
    sourceManifestSha256: packet.sourceManifestSha256,
    sourceClosureSha256: packet.sourceClosureSha256,
    nodeArtifactSha256: packet.nodeArtifactSha256,
    inputSha256: sha(inputRaw),
    originalInputSha256: sha(originalRaw),
    requestedOptions: packet.requestedOptions,
    actualOptions,
    requestedOptionsHeld,
    publicPipelineExecuted: solver !== undefined,
    originalDefaultCap: solver?.MAX_ITERATIONS ?? null,
    capUnchanged,
    terminal: terminal ?? null,
    originalException: exception,
    inputUnchanged,
    fullHardwareHeld,
    fixedReferencesHeld,
    naturalOutputGateHeld,
    suppliedPhysicalReferences: 2,
    publicOutput,
    progressRows, progressBytes, droppedProgress, writeErrors,
    positiveBankStats: finalStats ?? null,
    stagePrimitives: finalStageStats ?? null,
    stageTelemetry: stageTelemetry.snapshot(),
    stageBindingsRestored,
    statsWrites, droppedStatsWrites, statsBytes, statsBindingsRestored,
    actualSolverState: solver ? { iterations: solver.iterations, phase: solver.phase, solved: solver.solved, failed: solver.failed, actualTraceCount: solver.traces.length, ...ownPublicFailureFields(solver) } : null,
    totalChildSeconds: (performance.now() - started) / 1000,
    accepted49: false,
    tiEligibleBoard: false,
    signalLayersAllowed: ["top", "inner1", "inner2", "bottom"],
    referenceQualified: false,
    TIplaneArrangement: false,
    fabricationReady: false,
    scope: "Original public steps with bounded original observers, two private method boundaries, active CPU scene capture, qualified owned-reference native audit and one private assignment-key fix. Natural raw output requires separate timing, reference-plane, standard DRC and CAD qualification. External resource interruption is not infeasibility.",
  }
  const raw = `${JSON.stringify(result, null, 2)}\n`
  assert.ok(Buffer.byteLength(raw) <= 32 * 1024)
  atomic("result.json", raw)
  console.log(JSON.stringify({ diagnosticQualified: result.diagnosticQualified, accepted49: false, observationMode: result.observationMode }))
  return result.diagnosticQualified ? 0 : 2
}

// Executable entry only; helper controls import the unchanged pure helpers separately.
main().then(code => { process.exitCode = code }).catch(error => { console.error(error); process.exitCode = 1 })
