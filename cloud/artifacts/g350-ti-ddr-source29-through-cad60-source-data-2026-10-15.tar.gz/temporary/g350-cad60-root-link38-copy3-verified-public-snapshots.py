"""Root-only immutable public snapshots; no SDK, container or authority imports."""
import hashlib
import json
import os
import stat
from pathlib import Path

assert os.environ.get("G350_SOURCE29_CAD60_SNAPSHOT_ROOT_APPROVED") == "1"
OLD = Path("/tmp/g350-source29-cad57-authentic56-root-guard-sourceonly-next/SNAPSHOT_COPY_INPUTS.json")
NEW = Path("/tmp/g350-source29-cad60-three-phase-posts-after59-sourceonly-next/SNAPSHOT_COPY_INPUTS.json")
REPORT = Path("/tmp/g350-source29-cad60-root-linked38-copied3-precopy-report.json")
EXTRAS = {
    "/tmp/g350-source29-three-stage-root-20261015-after52/capture/POSTAUDIT.json": ("162c611e77cd4a653a6dbb7594ae8e2e2a28dd83a64c1891f47f3d1708a7a097", 7739),
    "/tmp/g350-source29-three-stage-root-20261015-after52/types/POSTAUDIT.json": ("658cf04a58a1bd3468e8c87732c496089b817a829632a5f0d4b4a55bffe99434", 6085),
    "/tmp/g350-source29-three-stage-root-20261015-after52/core/POSTAUDIT.json": ("17461e8f0c79698826d4451b562a7f889d234d40425dd82f80639d29c4940f23", 7983),
}


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()


def verified(path, pin):
    assert path.is_absolute() and path.resolve() == path
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode)
        assert before.st_size == pin["bytes"] and stat.S_IMODE(before.st_mode) == pin["mode"]
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1048576)
            if not chunk:
                break
            h.update(chunk)
        assert h.hexdigest() == pin["sha256"]
        return before
    finally:
        os.close(fd)


def held(a, b):
    return (a.st_dev, a.st_ino, a.st_size, a.st_mode, a.st_mtime_ns, a.st_ctime_ns, a.st_nlink) == (b.st_dev, b.st_ino, b.st_size, b.st_mode, b.st_mtime_ns, b.st_ctime_ns, b.st_nlink)


assert sha(OLD) == "cc66242f5aeba1ba5218cc6bfe26e656b01cde2331af671a3ff8b8baa22c687a"
assert sha(NEW) == "775b6e30b44e8f41c45b36facbae5b1a1167b1b6729a75504039b160fdd00c3c"
old, new = [json.loads(p.read_bytes()) for p in (OLD, NEW)]
run = Path(new["runRoot"])
assert run == Path("/tmp/g350-source29-cad-root-20261015-after59")
assert not run.exists() and not run.is_symlink() and not REPORT.exists()
old_root, new_root = [Path(d["snapshotRoot"]) for d in (old, new)]
assert old_root.parent == Path(old["runRoot"]) / "snapshots"
assert new_root.parent == run / "snapshots" and new_root.resolve() == new_root
assert len(old["snapshots"]) == 38 and len(new["snapshots"]) == 41
assert old["requiredSparseBytes"] == 24380686 and new["requiredSparseBytes"] == 24402493
old_rows = {r["original"]["path"]: r for r in old["snapshots"]}
new_rows = {r["original"]["path"]: r for r in new["snapshots"]}
assert len(old_rows) == 38 and len(new_rows) == 41 and set(new_rows) - set(old_rows) == set(EXTRAS)
prepared = []
for item in new["snapshots"]:
    pin = item["original"]
    source = Path(pin["path"])
    target = Path(item["snapshotPath"])
    assert target == new_root / item["snapshotRelativePath"] and target.is_relative_to(new_root)
    assert item["containerTargetPath"] == str(source)
    original_stat = verified(source, pin)
    if pin["path"] in old_rows:
        previous = old_rows[pin["path"]]
        assert previous["original"] == pin
        prior = Path(previous["snapshotPath"])
        assert prior == old_root / previous["snapshotRelativePath"] and prior.is_relative_to(old_root)
        prior_stat = verified(prior, pin)
        assert (original_stat.st_dev, original_stat.st_ino) != (prior_stat.st_dev, prior_stat.st_ino)
    else:
        assert (pin["sha256"], pin["bytes"]) == EXTRAS[pin["path"]] and pin["mode"] == 0o600
        prior = prior_stat = None
    prepared.append((pin, source, prior, target, original_stat, prior_stat))
assert len({str(r[3]) for r in prepared}) == 41
run.mkdir(mode=0o700)
for pin, source, prior, target, original_stat, prior_stat in prepared:
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    assert target.parent.resolve() == target.parent
    if prior is not None:
        os.link(prior, target, follow_symlinks=False)
    else:
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        try:
            with source.open("rb") as stream:
                while True:
                    chunk = stream.read(1048576)
                    if not chunk:
                        break
                    view = memoryview(chunk)
                    while view:
                        count = os.write(fd, view)
                        assert count > 0
                        view = view[count:]
        finally:
            os.close(fd)
    now = verified(target, pin)
    if prior_stat is not None:
        assert (now.st_dev, now.st_ino, now.st_mtime_ns) == (prior_stat.st_dev, prior_stat.st_ino, prior_stat.st_mtime_ns)
    else:
        assert (now.st_dev, now.st_ino) != (original_stat.st_dev, original_stat.st_ino)
for pin, source, prior, target, original_stat, prior_stat in prepared:
    assert held(verified(source, pin), original_stat), "Original bytes and metadata must remain held"
    now = verified(target, pin)
    if prior_stat is not None:
        previous = verified(prior, pin)
        assert previous.st_ino == now.st_ino == prior_stat.st_ino and previous.st_dev == now.st_dev == prior_stat.st_dev
        assert previous.st_mtime_ns == now.st_mtime_ns == prior_stat.st_mtime_ns
        assert previous.st_nlink == now.st_nlink == prior_stat.st_nlink + 1
value = dict(scope="ROOT_ACTUAL_CAD60_VERIFIED_PUBLIC_SNAPSHOT_LINK38_COPY3", verifiedFiles=41,
             snapshotLogicalBytes=24402493, hardlinkedPriorSnapshotFiles=38, independentlyCopiedPublicPhasePosts=3,
             snapshotFileBytesWritten=21807, copyInputsPath=str(NEW), copyInputsSha256=sha(NEW),
             runRoot=str(run), snapshotRoot=str(new_root), allOriginalBytesModesMtimeCtimeAndLinksHeld=True,
             allSnapshotBytesAndModesVerified=True, existingSnapshotMtimeHeld=True,
             priorSnapshotLinkCountsIncrementedByOne=True, priorSnapshotCtimeMayChangeAsExpected=True,
             originalSourceOrHardwareHardlinked=False, filesDeleted=False, all41TargetsReadOnlyContainerInputs=True,
             RootAuthorityBodiesCopied=0, SDKOrAppsImported=False, workspaceWrites=False, fabricationReady=False)
with REPORT.open("x") as stream:
    json.dump(value, stream, indent=2)
    stream.write("\n")
REPORT.chmod(0o600)
print(json.dumps(dict(passed=True, reportPath=str(REPORT), reportSha256=sha(REPORT))))
