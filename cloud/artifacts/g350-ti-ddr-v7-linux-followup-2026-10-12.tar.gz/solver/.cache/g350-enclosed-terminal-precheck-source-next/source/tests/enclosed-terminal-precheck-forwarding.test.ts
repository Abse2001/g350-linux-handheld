import { expect, mock, spyOn, test } from "bun:test"
import assert from "node:assert/strict"
import { createHash } from "node:crypto"
import type { SimpleRouteJson, SolverOptions, Trace } from "../lib/types"

// The child owns every module double. Importing this file in the ordinary suite
// never replaces Grid or planner exports in the parent process.
if (process.env.PRECHECK_FORWARDING_MOCK_CHILD === "1") {
  let assertions = 0
  const equal = (actual: unknown, expected: unknown) => {
    assertions++
    assert.equal(actual, expected)
  }
  const signature = (value: unknown) =>
    createHash("sha256").update(JSON.stringify(value)).digest("hex")
  const counters = { gridConstructors: 0, projectorConstructors: 0, steps: 0 }
  const originalGrid = await import("../lib/grid-visibility")
  equal(
    Object.keys(originalGrid).sort().join(","),
    "GridHistoryProjector,GridVisibilitySearch",
  )
  class ProhibitedGrid {
    constructor() {
      counters.gridConstructors++
      throw Error("Real Grid construction is prohibited")
    }
    step() {
      counters.steps++
      throw Error("Real Grid advancement is prohibited")
    }
  }
  class ProhibitedProjector {
    constructor() {
      counters.projectorConstructors++
      throw Error("Real Projector construction is prohibited")
    }
    step() {
      counters.steps++
      throw Error("Real Projector advancement is prohibited")
    }
  }
  mock.module(
    new URL("../lib/grid-visibility.ts", import.meta.url).pathname,
    () => ({
      ...originalGrid,
      GridVisibilitySearch: ProhibitedGrid,
      GridHistoryProjector: ProhibitedProjector,
    }),
  )
  const coupled = await import("../lib/coupled-pair-routing")
  const calls: Parameters<typeof coupled.routeCoupledPair>[] = []
  const coupledStub = spyOn(coupled, "routeCoupledPair").mockImplementation(
    function* (...args) {
      calls.push(args)
      yield
      return null
    },
  )
  const planner = await import("../lib/plan-shared-pair-corridors")
  const { priorityPairPlans } = await import("../lib/route-fresh-surface-buses")
  const input: SimpleRouteJson = {
    layerCount: 4,
    allowedLayers: ["top", "bottom"],
    minTraceWidth: 0.1,
    bounds: { minX: -4, maxX: 4, minY: -3, maxY: 3 },
    obstacles: [],
    connections: ["P", "N"].map((name, i) => ({
      name,
      pointsToConnect: [-2, 2].map((x) => ({ x, y: i * 0.3, layer: "top" })),
    })),
    differentialPairs: [
      { connectionNames: ["P", "N"], traceGap: 0.2, lengthTolerance: 0.127 },
    ],
  }
  const before = signature(input)
  const layers = new Map(input.connections.map((c) => [c.name, ["top"]]))
  const policies: Pick<SolverOptions, "precheckEnclosedTerminals">[] = [
    {},
    { precheckEnclosedTerminals: false },
    { precheckEnclosedTerminals: true },
  ]
  for (const policy of policies) {
    calls.length = 0
    const work = planner.planSharedPairCorridors(input, layers, false, {
      maxTopologyVariants: 1,
      ...policy,
    })
    try {
      let complete = false
      for (let i = 0; i < 8; i++) {
        if (work.next().done) {
          complete = true
          break
        }
      }
      equal(complete, true)
      equal(calls.length, 1)
      const call = calls[0]!
      equal(call.length, policy.precheckEnclosedTerminals === true ? 5 : 4)
      equal(call[1], input.differentialPairs![0])
      equal(call[3]?.penalty, 0)
      equal(call[3]?.copper.length, 0)
      equal(call[3]?.variant, 1)
      equal(Object.hasOwn(call[3]!, "precheckEnclosedTerminals"), false)
      equal(
        call[4]?.precheckEnclosedTerminals,
        policy.precheckEnclosedTerminals === true ? true : undefined,
      )
    } finally {
      work.return(undefined)
    }
  }
  coupledStub.mockRestore()

  const guide: Trace = {
    type: "pcb_trace",
    pcb_trace_id: "mock_guide",
    connection_name: "control",
    route: [{ route_type: "wire", x: 0, y: 1, width: 0.1, layer: "top" }],
  }
  let streamChecks = 0
  for (const policy of policies) {
    const seen: { argc: number; options: unknown; guided: boolean }[] = []
    const planned = spyOn(
      planner,
      "planSharedPairCorridors",
    ).mockImplementation(function* (...args) {
      const guided = args[0].traces?.includes(guide) === true
      seen.push({ argc: args.length, options: args[3], guided })
      yield [
        { ...guide, pcb_trace_id: `mock_${seen.length}`, connection_name: "P" },
      ]
    })
    const work = priorityPairPlans(input, layers, [], policy)
    try {
      equal(work.next().done, false)
      equal(
        work.next({ kind: "native-approach-guidance", guides: [guide] }).done,
        false,
      )
      equal(work.next().done, false)
      equal(work.next().done, true)
      equal(seen.length, 3)
      equal(seen.map((call) => call.guided).join(","), "false,true,false")
      for (const call of seen) {
        const options = call.options as { precheckEnclosedTerminals?: boolean }
        equal(call.argc, 4)
        equal(
          Object.hasOwn(options, "precheckEnclosedTerminals"),
          policy.precheckEnclosedTerminals === true,
        )
        equal(
          options.precheckEnclosedTerminals,
          policy.precheckEnclosedTerminals === true ? true : undefined,
        )
        streamChecks++
      }
    } finally {
      work.return(undefined)
      planned.mockRestore()
    }
  }
  equal(signature(input), before)
  equal(counters.gridConstructors, 0)
  equal(counters.projectorConstructors, 0)
  equal(counters.steps, 0)
  console.log(
    JSON.stringify({
      mode: "PROCESS_ISOLATED_MOCK_PRECHECK_FORWARDING",
      assertions,
      coupledCases: policies.length,
      preferredGuidedFallbackChecks: streamChecks,
      ...counters,
      inputUnchanged: true,
      physicalRoutingQualified: false,
    }),
  )
} else {
  test("enclosed-terminal policy preserves the disabled ABI and reaches all pair probes", async () => {
    const child = Bun.spawn([process.execPath, "--smol", import.meta.path], {
      env: { ...process.env, PRECHECK_FORWARDING_MOCK_CHILD: "1" },
      stdout: "pipe",
      stderr: "pipe",
    })
    let timedOut = false
    const deadline = setTimeout(() => {
      timedOut = true
      child.kill("SIGKILL")
    }, 2500)
    try {
      const [exitCode, stdout, stderr] = await Promise.all([
        child.exited,
        new Response(child.stdout).text(),
        new Response(child.stderr).text(),
      ])
      if (stdout) console.log(stdout.trim())
      if (stderr) console.error(stderr.trim())
      expect(timedOut).toBe(false)
      expect(exitCode).toBe(0)
      expect(stderr).toBe("")
      const result = JSON.parse(stdout.trim())
      expect(result).toMatchObject({
        mode: "PROCESS_ISOLATED_MOCK_PRECHECK_FORWARDING",
        coupledCases: 3,
        preferredGuidedFallbackChecks: 9,
        gridConstructors: 0,
        projectorConstructors: 0,
        steps: 0,
        inputUnchanged: true,
        physicalRoutingQualified: false,
      })
      expect(result.assertions).toBeGreaterThan(70)
    } finally {
      clearTimeout(deadline)
      if (child.exitCode === null) {
        child.kill("SIGKILL")
        await child.exited
      }
    }
  })
}
