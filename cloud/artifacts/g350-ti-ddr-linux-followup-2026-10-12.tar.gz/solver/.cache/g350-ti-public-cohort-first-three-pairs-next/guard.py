"""One root-approved original TI-bounded chronological first-three prefix; preflight never launches routing."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import time

ROOT = Path(__file__).resolve().parent
REPO = Path("/workspace/bus-lanes-solver")
BUN = "/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe"
POLICY = {"wallSeconds": 60, "rssBytes": 1 * 1024 ** 3,
          "sharedBytes": 24 * 1024 ** 3, "sampleSeconds": .05,
          "termGraceSeconds": 5}
OOM_KEYS = ("oom", "oom_kill", "oom_group_kill")


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def import_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_source_roots(manifest):
    listed = {item["path"] for item in manifest["files"]}
    for name in ["source/lib", "source/scripts"]:
        root = ROOT / name
        if root.is_symlink() or not root.is_dir() or root.resolve() != root:
            raise ValueError("Source root must be a real pinned directory")
        for current, dirs, files in os.walk(root, followlinks=False):
            for name in dirs:
                path = Path(current) / name
                if name == "node_modules" or path.is_symlink():
                    raise ValueError("Nearest source resolver override")
            for name in files:
                path = Path(current) / name
                if (name == "node_modules" or path.is_symlink()
                        or not stat.S_ISREG(path.lstat().st_mode)
                        or str(path.relative_to(ROOT)) not in listed):
                    raise ValueError("Unlisted or nonregular source entry")
    for name in ["node_modules", "source/node_modules"]:
        link = ROOT / name
        if (not link.is_symlink() or os.readlink(link) != str(REPO / "node_modules")
                or link.resolve() != REPO / "node_modules"):
            raise ValueError("Exact trusted dependency symlink required")
    if (ROOT / "source").is_symlink():
        raise ValueError("Pinned source root must be real")


def checked_manifest():
    raw = (ROOT / "packet-manifest.json").read_bytes()
    manifest = json.loads(raw)
    if (manifest["policy"] != POLICY
            or manifest["sourceRevision"] != "c1151212be7b9de4b34b07436d135d874e6c0466"
            or manifest["libTree"] != "6c2f08dac7b248f94c2fd1125545031eeaa01e13"
            or manifest["maximumOriginalFactories"] != 3
            or manifest["producerCaps"] != {"nativeSiteSteps": 4000, "pairedDomainYields": 6000, "maxTopologyVariants": 2}):
        raise ValueError("Pinned source, candidate or policy differs")
    validate_source_roots(manifest)
    for path in manifest["requiredAbsentRuntimeFiles"]:
        if Path(path).exists() or Path(path).is_symlink():
            raise ValueError("Unbound runtime/resolver file appeared: " + path)
    for item in manifest["files"]:
        path = ROOT / item["path"]
        if (path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode)
                or sha(path) != item["sha256"]
                or stat.S_IMODE(path.stat().st_mode) != item["mode"]):
            raise ValueError("Packet bytes changed: " + item["path"])
    for item in manifest["externalFiles"]:
        if sha(item["path"]) != item["sha256"]:
            raise ValueError("Pinned external bytes changed")
    return manifest, hashlib.sha256(raw).hexdigest()


def checked_provenance(manifest):
    prepared = json.loads(Path(manifest["originalPreparedPath"]).read_bytes())
    if len(prepared["sourceHashes"]) != 177:
        raise ValueError("Original source177 provenance differs")
    original = Path(manifest["originalPreparedPath"]).parent
    for name, expected in prepared["sourceHashes"].items():
        if (sha(original / "frozen" / name) != expected
                or sha(ROOT / "source" / name) != expected
                or sha(REPO / name) != expected):
            raise ValueError("Original/frozen source bytes differ")
    verifier = import_module("trusted_verifier", ROOT / "verify-installed-dependencies.py")
    result = verifier.verify(ROOT / "dependencies/archive-receipt.json",
                             manifest["dependencyReceiptSha256"], ROOT / "audit-installed-dependencies.py")
    if (result["treeSha256"] != manifest["dependencyTreeSha256"]
            or result["archiveSha256"] != manifest["dependencyArchiveSha256"]):
        raise ValueError("Complete dependency closure differs")
    return result


def require_receipt(receipt, packet_hash):
    if (receipt.get("authorizedByRoot") is not True
            or receipt.get("packetSha256") != packet_hash
            or receipt.get("policy") != POLICY
            or receipt.get("scope") != "one-c115-public-cohort-first-three-pairs"
            or not re.fullmatch("[0-9a-f]{32,128}", receipt.get("approvalToken", ""))):
        raise ValueError("Root-pinned one-search authorization required")


def read_receipt(path, expected_hash, packet_hash):
    if not isinstance(expected_hash, str) or not re.fullmatch("[0-9a-f]{64}", expected_hash):
        raise ValueError("Exact approved receipt SHA256 required")
    raw = Path(path).read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != expected_hash:
        raise ValueError("Approved receipt bytes changed")
    receipt = json.loads(raw)
    require_receipt(receipt, packet_hash)
    return receipt, actual


def require_headroom(current):
    if current + POLICY["rssBytes"] + 2 * 1024 ** 3 >= POLICY["sharedBytes"]:
        raise ValueError("Insufficient strict shared24GiB launch headroom")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--launch-receipt", type=Path)
    parser.add_argument("--receipt-sha256")
    args = parser.parse_args()
    if args.preflight == bool(args.launch_receipt) or (args.preflight and args.receipt_sha256):
        raise ValueError("Select preflight or one approved launch")
    if args.preflight and ((ROOT / "root-launch-receipt.json").exists() or (ROOT / "root-launch-receipt.json").is_symlink()):
        raise ValueError("Fresh authority path required absent at preflight")
    if (ROOT / "run").exists() or (ROOT / "run").is_symlink():
        raise ValueError("Fresh exclusive run directory required")
    started = time.monotonic()
    manifest, packet_hash = checked_manifest()
    dependency_before = checked_provenance(manifest)
    if args.preflight:
        print(json.dumps({"phase": "PREFLIGHT_ONLY", "packetSha256": packet_hash,
                          "preflightSeconds": time.monotonic() - started, "actualGridLaunched": False}))
        return 0
    receipt, receipt_hash = read_receipt(args.launch_receipt, args.receipt_sha256, packet_hash)
    scope = import_module("owned_scope", ROOT / "process_scope.py")
    before = scope.memory()
    require_headroom(before["current"])
    _, current_hash = checked_manifest()
    if current_hash != packet_hash:
        raise ValueError("Packet changed before fork")
    current = scope.memory()
    require_headroom(current["current"])
    if any(current["events"][key] != before["events"][key] for key in OOM_KEYS):
        raise ValueError("New OOM before launch")
    command = [BUN, "--smol", str(ROOT / "runner.ts"), "--run-one-approved"]
    def before_spawn(fresh_baseline):
        require_headroom(fresh_baseline["current"])
        if any(fresh_baseline["events"][key] != before["events"][key] for key in OOM_KEYS):
            raise ValueError("Fresh pre-fork OOM baseline changed")
    execution = scope.run_guarded(command, ROOT, ROOT / "run", POLICY,
                                  {"G350_PUBLIC_COHORT_PAIRS_APPROVED": "1"},
                                  before_spawn=before_spawn)
    _, post_hash = checked_manifest()
    dependency_after = checked_provenance(manifest)
    if post_hash != packet_hash:
        raise ValueError("Packet changed during child")
    after = scope.memory()
    if any(after["events"][key] > before["events"][key] for key in OOM_KEYS):
        execution["diagnosticStopped"] = True
        execution["stopReasons"].append("POSTFLIGHT_NEW_OOM")
    result_path = ROOT / "run/result.json"
    result = json.loads(result_path.read_bytes()) if result_path.is_file() else None
    trust = (execution["exitCode"] == 0 and not execution["diagnosticStopped"]
             and execution.get("cleanupOwnedGroupEmpty") is True and result is not None
             and result.get("diagnosticQualified") is True
             and result.get("packetSha256") == packet_hash
             and result.get("sourceCommit") == manifest["sourceRevision"]
             and result.get("libTree") == manifest["libTree"]
             and result.get("captureContractSatisfied") is True
             and result.get("originalFactories") == 3
             and result.get("factoryAttempts") <= 4
             and result.get("closed") is True
             and result.get("completed") is False
             and result.get("inputUnchanged") is True
             and result.get("newInitializerCalls") == 0
             and result.get("parentPublicInitializationTrusted") is True
             and result.get("tiInputBoundsHeld") is True
             and result.get("referenceHardCopperHeld") is True
             and result.get("seededPriorCopper") is False
             and result.get("accepted49") is False
             and result.get("fabricationReady") is False)
    report = {"packetSha256Before": packet_hash, "packetSha256After": post_hash,
              "receiptSha256": receipt_hash, "policy": POLICY,
              "dependencyBefore": dependency_before, "dependencyAfter": dependency_after,
              "execution": execution, "resultTrustEligible": trust,
              "resultSha256": sha(result_path) if result_path.is_file() else None,
              "totalGuardSeconds": time.monotonic() - started, "accepted49": False,
              "scope": "Original first-three producer prefix; no fullcaller/default49 acceptance/timing/fabrication claim"}
    (ROOT / "run/postflight.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"exitCode": execution["exitCode"], "resultTrustEligible": trust, "accepted49": False}))
    return 0 if trust else 2


if __name__ == "__main__":
    raise SystemExit(main())
