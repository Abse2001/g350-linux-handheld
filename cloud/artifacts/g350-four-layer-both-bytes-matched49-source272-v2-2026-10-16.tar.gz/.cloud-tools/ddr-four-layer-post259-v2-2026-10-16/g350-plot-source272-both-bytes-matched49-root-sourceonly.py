#!/usr/bin/env python3
"""SOURCE ONLY: render exact268 both-byte-matched full49 geometry with fresh Source272 evidence.

Author did not execute/import this file or supplied code; Root owns rendering.

No SDK, native, Core or CAD execution. Frozen predecessor outputs stay intact.
"""
import argparse
import hashlib
import json
import io
import math
import os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', '/tmp/g350-plot272-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Circle, Rectangle
from matplotlib.transforms import Affine2D

CANDIDATE = Path('/tmp/g350-both-bytes-retimed49-root-20261016-run268/byte0-result.candidate.json')
CANDIDATE_SHA = 'fcc50ba7874af9724526a443367f70eeb42bff6179eb07ef8fd3ff929c0c6c77'
CRITICAL_REPORT = Path('/tmp/g350-both-bytes-retimed49-root-20261016-run268/byte0-result.json')
CRITICAL_SHA = 'd144c0693f814d2488deadb63c7b819d7308804d5de361d7e8b35b6976c07ad4'
RAW_CORE = Path('/tmp/g350-both-bytes-ca9-matched49-core272-raw.json')
RAW_CORE_SHA = '33584d197a1bb45a0dc76ac0a69e7016866a2369f1750c72d5eedc41ef444594'
CONTROLS = Path('/tmp/g350-both-bytes-ca9-matched49-core-smol-root-20261016-run272/byte0-result.json')
CONTROLS_SHA = '32eec52a75348a996f7fbfd4271b2318c9bf4c39229fd67a289d97835aa63ec4'
NATIVE = Path('/tmp/g350-both-bytes-ca9-matched49-native-root-20261016-run273/byte0-result.json')
NATIVE_SHA = '657a1e5f68dcc0ccf7594741c10ef3db343266e5163ecb338b975f69634ac91f'
AUTH = Path('/tmp/g350-both-bytes-ca9-matched49-via-track-root-20261016-run274/byte0-result.json')
AUTH_SHA = '7459c5bd51b041686dea91b56779dcc94498b02b2a7e6ef51c796e42192d5886'
PLAN = Path('/tmp/g350-both-bytes-ca9-matched49-projector-root-20261016-run269/byte0-result.json')
PLAN_SHA = '4bb8153b7dddfcd73b78dad9d07483c239967680bdd25ef53b5487da46fbb107'
PDN_PROOF_SHA = '618ea6dfb7294ff665a4c5f84b33149ea16367d633dff5b3c7f024bdc744f57a'
PDN_PROOF_SOURCE = Path('/tmp/g350-plan269-fresh-core-two-pdn-same-polygon-annular-contact-sourceonly.py')
PDN_PROOF_SOURCE_SHA = '73d6a1e8f8eaa31ee7682a4af56ae2855ac83b438be4d55cf263be0483d04c98'
PDN_PRIOR = Path('/tmp/g350-source257-new-pdn-same-polygon-root-20261016.json')
PDN_PRIOR_SHA = 'a7e83cfb76a258eb211b00e962c74ce7ba46f60a1aa864bb53f61eea43deece8'
PDN_PRIOR_SOURCE = Path('/tmp/g350-plan254-fresh-two-pdn-same-polygon-contact-sourceonly.py')
PDN_PRIOR_SOURCE_SHA = 'c437815a3ac2f486d7c0540835517a6ebfd0147a096db927643d986267d52081'
OUTPUT_DIR = Path('/tmp/g350-source272-both-bytes-matched49-root-20261016-plot')
LAYERS = ['top', 'inner1', 'inner2', 'bottom']
COLORS = {'ordinary': '#16856d', 'source_trace_15': '#1170aa', 'source_trace_16': '#1170aa',
          'source_trace_27': '#dd761c', 'source_trace_28': '#dd761c',
          'source_trace_33': '#8b43b3', 'source_trace_34': '#8b43b3'}


def owner(trace):
    return trace.get('connection_name', trace.get('source_trace_id'))


def wire_segments(trace, layer):
    return [[(a['x'], a['y']), (b['x'], b['y'])] for a, b in zip(trace['route'], trace['route'][1:])
            if a['route_type'] == b['route_type'] == 'wire' and a['layer'] == b['layer'] == layer]


def pinned_json(location, expected_sha):
    data = location.read_bytes()
    if hashlib.sha256(data).hexdigest() != expected_sha:
        raise ValueError('Closed evidence hash mismatch: ' + str(location))
    return json.loads(data)


def require(value, message):
    if not value:
        raise ValueError(message)


def compact_run(points):
    result = []
    for p in points:
        q = (p['x'], p['y'])
        require(all(isinstance(x, (int, float)) and math.isfinite(x) for x in q), 'Finite actual wire coordinates required')
        if not result or math.dist(q, result[-1]) > 1e-8:
            result.append(q)
    return result


def same_run(a, b):
    return len(a) == len(b) and all(math.dist(x, y) <= 1e-8 for x, y in zip(a, b))


def joined_runs(trace):
    result, run, layer = [], [], None
    def flush():
        nonlocal run
        points = compact_run(run)
        if len(points) > 1:
            result.append((layer, points))
        run = []
    for point in trace['route']:
        if point['route_type'] != 'wire':
            flush(); layer = None
        else:
            if layer is not None and layer != point['layer']:
                flush()
            layer = point['layer']; run.append(point)
    flush()
    return result


def verify_closed_evidence(candidate, aggregate_path, aggregate_sha, pdn_path, pdn_sha):
    require(all(len(v) == 64 and all(c in '0123456789abcdef' for c in v) for v in (aggregate_sha, pdn_sha)),
            'Explicit actual closed aggregate and fresh PDN-contact SHA256 pins required')
    raw, controls = pinned_json(RAW_CORE, RAW_CORE_SHA), pinned_json(CONTROLS, CONTROLS_SHA)
    plan = pinned_json(PLAN, PLAN_SHA)
    require(controls['rawCoreSha256'] == RAW_CORE_SHA and controls['freshCoreDerived'] is True and
            controls['partialDiagnosticReplayControlsPassed'] is True and len(controls['checks']) == 35 and
            all(c['passed'] is True for c in controls['checks']), 'Actual Source272 all35 replay controls must bind the exact raw')
    require(controls['planSha256'] == PLAN_SHA and controls['candidateSha256'] == CANDIDATE_SHA and
            controls['sourceRuleBridge']['candidatePin']['sha256'] == CANDIDATE_SHA and
            controls['referenceQualified'] is False, 'Exact candidate268/plan269 binding with reference qualification open')
    require(controls['pendingOwnerIds'] == [] and len(controls['routedOwnerIds']) == 49
            and controls['all49Connected'] is True,
            'Exact49 routed and no pending owner')
    cap = plan['cap12HardwareDelta']
    require(plan['inputBindings']['candidate']['sha256'] == CANDIDATE_SHA and
            controls['cap12HardwareDelta'] == cap and cap['profile'] == 'CAP12_TRANSLATE_X_0P79_ONLY' and
            cap['component']['sourcePlacement'] == {
                'before': {'pcbX': 6, 'pcbY': 4.7, 'layer': 'bottom', 'pcbRotation': 180},
                'after': {'pcbX': 6.79, 'pcbY': 4.7, 'layer': 'bottom', 'pcbRotation': 180}} and
            candidate['requiredSourceHardwarePlacementDelta'] == cap['originalDeclaration'],
            'Exact declared cap12 placement and reference inverse ledger required')
    cap8 = plan['cap8HardwareDelta']
    require(plan['hardwareDeltaProfile'] == 'CAP12_X0P79_CAP8_TWO_NEW_PDN_VIAS' and
            controls['cap8HardwareDelta'] == cap8 and cap8['profile'] == 'CAP8_AT_0_7P9_TWO_NEW_PLANE_VIAS_VDD7P2' and
            cap8['descriptorBinding']['sha256'] == '20e698e6225f7aa0759aa4acf70103c5f90f3894ae94726336e098598b3f3976' and
            cap8['component']['sourcePlacement'] == {
                'before': {'pcbX': 1.2, 'pcbY': 9.799999999999999, 'layer': 'bottom', 'pcbRotation': 0},
                'after': {'pcbX': 0, 'pcbY': 7.9, 'layer': 'bottom', 'pcbRotation': 0}} and
            candidate['cap8PlacementInverse'] == cap8['originalDeclaration'] and
            candidate['requiredSourceHardwarePlacementDeltas'] == [cap['originalDeclaration'], cap8['originalDeclaration']],
            'Exact combined two-cap/two-PDN placement/reference inverse ledger required')
    projected = {g['originalSourceTraceId']: g for g in plan['projectedGeometry']}
    logical = {g['originalSourceTraceId']: g for g in controls['logical49Projection']}
    joined = {owner(t): t for t in candidate['joinedNumericPadTraces']}
    require(set(projected) == set(joined) == set(controls['routedOwnerIds']), 'Exact candidate/source projected-owner roster')
    pcb_traces = [r for r in raw if r.get('type') == 'pcb_trace']
    wire_count = 0
    for sid, geometry in projected.items():
        expected = [(r['layer'], compact_run(r['absolutePoints'])) for r in geometry['wireRuns']]
        actual = []
        for trace in pcb_traces:
            if trace.get('source_trace_id') == logical[sid]['actualSourceTraceId']:
                points = compact_run(trace['route'])
                require(all(p['route_type'] == 'wire' for p in trace['route']), 'Source pcbPaths produce separate actual wire runs')
                actual.append((trace['route'][0]['layer'], points))
                wire_count += len(points) - 1
        for runs in (actual, joined_runs(joined[sid])):
            require(len(runs) == len(expected) and all(a[0] == b[0] and same_run(a[1], b[1]) for a, b in zip(runs, expected)),
                    'Exact raw272/candidate268 wire-run geometry must agree with plan269 for ' + sid)
    raw_pours = [r for r in raw if r.get('type') == 'pcb_copper_pour']
    via_count = sum(r.get('type') == 'pcb_via' for r in raw)
    require(via_count == controls['expectedCounts']['physicalVias'] == 129 + len(plan['newVias']) + len(cap8['pdnVias']) == 234,
            'Actual plan-derived234 via inventory required')
    native, auth = pinned_json(NATIVE, NATIVE_SHA), pinned_json(AUTH, AUTH_SHA)
    require(native['completed'] is True and native['finished'] is True and native['completedCheckCount'] == 16 and
            native['exceptionCount'] == 0 and native['inputBindings']['raw']['sha256'] == RAW_CORE_SHA and
            native['inputBindings']['controls']['sha256'] == CONTROLS_SHA, 'Exact closed focused16 native273 diagnostic required')
    results = {r['name']: r for r in native['results']}
    require(len(native['physical10']) == 10 and all(results[n]['findingCount'] == 0 for n in native['physical10']) and
            results['checkPcbBusLengthSkew']['findingCount'] == 1 and
            all(r['findingCount'] == 0 for name, r in results.items() if name != 'checkPcbBusLengthSkew') and
            native['all32FreshNativeChecksExecuted'] is False,
            'All15 non-skew checks zero and the remaining CA skew finding must remain explicit')
    require(auth['complete'] is True and auth['executed'] is True and auth['actualViaCount'] == via_count and
            auth['completedViaCount'] == via_count and auth['foreignViaTrackCopperClearancePassed'] is True and
            auth['inputBindings']['raw']['sha256'] == RAW_CORE_SHA and auth['inputBindings']['controls']['sha256'] == CONTROLS_SHA,
            'Exact closed authenticated234-via diagnostic274 required')
    require(all(not auth[k] for k in ['identityFailures', 'ambiguousVias', 'violations', 'invalidSegments', 'unresolvedSegmentOwners']),
            'Auth274 findings must remain zero')
    aggregate = pinned_json(aggregate_path, aggregate_sha)
    require(aggregate['scope'] == 'SOURCE49_PLAN269_BOTH_BYTES_MATCHED_CAP12_CAP8_TWO_PDN_ALL_ACTUAL_LITERAL_POURS_COMPLETED_COVERAGE_AGGREGATE_NOT_BOARD_QUALIFICATION' and
            aggregate['completed'] is True and aggregate['literalForeignPourMarginClear'] is True and
            aggregate['completedPourCount'] == aggregate['actualRawPourCount'] == len(raw_pours) and
            aggregate['completedPourIds'] == [r['pcb_copper_pour_id'] for r in raw_pours] and
            aggregate['actualViaCount'] == via_count and aggregate['wireSegmentCount'] == wire_count and
            aggregate['wireOwnerCount'] == 49 and aggregate['inputFilesUnchanged'] is True,
            'Complete exact Source272 dynamic pour/via/wire aggregate required')
    require(aggregate['inputBindings']['raw']['sha256'] == RAW_CORE_SHA and
            aggregate['inputBindings']['controls']['sha256'] == CONTROLS_SHA and
            aggregate['inputBindings']['current234Ownership']['sha256'] == AUTH_SHA and
            aggregate['inputBindings']['reviewedSourcePlan269']['sha256'] == PLAN_SHA and aggregate['violations'] == [],
            'Literal aggregate must bind these exact current inputs')
    require(pdn_sha == PDN_PROOF_SHA, 'Exact actual fresh annular-contact report SHA required')
    pdn = pinned_json(pdn_path, pdn_sha)
    prior = pinned_json(PDN_PRIOR, PDN_PRIOR_SHA)
    require(prior['passed'] is False and prior['newPdnLocalPlaneContactsQualified'] is False and
            hashlib.sha256(PDN_PRIOR_SOURCE.read_bytes()).hexdigest() == PDN_PRIOR_SOURCE_SHA and
            hashlib.sha256(PDN_PROOF_SOURCE.read_bytes()).hexdigest() == PDN_PROOF_SOURCE_SHA,
            'Prior negative sufficient-condition evidence and both exact proof sources remain preserved')
    require(pdn['scope'] == 'PLAN269_FRESH_CORE_TWO_NEW_PDN_FULL_LAND_PLUS_HELD_ANNULAR_BAND_SAME_FILLED_POLYGON_CONTACT_PROOF' and
            pdn['passed'] is True and pdn['newPdnLocalPlaneContactsQualified'] is True and pdn['errors'] == [] and
            pdn['exactInputFilesUnchanged'] is True and pdn['actualViaCount'] == 234 and
            pdn['heldOriginalReferenceViaCount'] == 129 and pdn['candidateBinding']['sha256'] == CANDIDATE_SHA,
            'Fresh full-new-PDN-land plus authentic held annular/full-land contacts in the same actual filled island must pass')
    require(all(pdn['inputBindings'][k]['sha256'] == v for k, v in {
                'raw': RAW_CORE_SHA, 'controls': CONTROLS_SHA, 'auth': AUTH_SHA, 'plan': PLAN_SHA}.items()) and
            pdn['actualFreshPourRoster'] == [{'actualPcbCopperPourId': p['pcb_copper_pour_id'], 'layer': p.get('layer'),
                'sourceNetId': p.get('source_net_id'), 'shape': p.get('shape')} for p in raw_pours] and
            pdn['all49Accepted'] is False and pdn['fabricationReady'] is False,
            'Fresh PDN proof must bind these actual raw/control/auth/plan and pour identities')
    require(pdn['geometryOrManufacturingRulesChanged'] is False and
            pdn['priorFullHeldDiskSufficientConditionReport'] == {
                'path': str(PDN_PRIOR), 'sha256': PDN_PRIOR_SHA, 'passed': False,
                'source': {'path': str(PDN_PRIOR_SOURCE), 'sha256': PDN_PRIOR_SOURCE_SHA},
                'preservedWithoutEdits': True, 'sufficientConditionWasStricterThanElectricalContact': True,
                'historicalOnly': True, 'currentRawEvidence': False, 'currentQualificationInherited': False},
            'Annular proof preserves the old negative and changes no geometry/manufacturing rule')
    actual_rows = {kind: {r[kind + '_id']: r for r in raw if r.get('type') == kind}
                   for kind in ['pcb_via', 'pcb_port', 'source_port', 'source_component', 'source_trace', 'pcb_trace']}
    held_vias = {r['actualFreshPcbViaId']: r for r in controls['heldViaChecks']}
    require(len(held_vias) == 129 and all(r['passed'] for r in held_vias.values()), 'Exactly129 real held reference barrels')
    for result in pdn['newPdnPlaneContactResults']:
        successful = [t for t in result['polygonTrials'] if t['passed'] and
                      t['newPdnLandDisk']['wholeLandDiskInThisFilledPolygon']]
        require(successful, 'Every new PDN still needs its complete actual .2286 land disk inside the same fresh filled island')
        if result['actualSourceNetName'] == 'DDR_1V5':
            full = [(trial, w) for trial in successful for w in trial['heldSameNetFullLandWitnesses']
                    if w['diskProof']['wholeLandDiskInThisFilledPolygon']]
            require(full and any(w['actualPcbViaId'] in held_vias and
                    held_vias[w['actualPcbViaId']]['name'] == w['heldSourceViaName'] and
                    w['sameActualSourceNetBySourceDeclarations'] == result['actualSourceNetId'] and
                    actual_rows['pcb_via'][w['actualPcbViaId']].get('source_net_id') == result['actualSourceNetId'] and
                    bool(w['incidentOwnedReferenceEndpoints']) for trial, w in full),
                    'VDD proof has an authentic held same-net full-land reference witness')
        elif result['actualSourceNetName'] == 'GND':
            annular = [w for trial in successful for w in trial['heldSameNetAnnularContactWitnesses']
                       if w['passed'] and w['heldSourceViaName'] == 'V_TI_PKG_SITE_010_GND']
            require(annular, 'GND proof requires the specifically authenticated held annular-contact chain')
            for w in annular:
                require(w['actualPcbViaId'] in held_vias and held_vias[w['actualPcbViaId']]['name'] == w['heldSourceViaName'],
                        'Annular witness resolves through the actual held-via control')
                v = actual_rows['pcb_via'][w['actualPcbViaId']]
                disk = w['fullHeldLandDiskProof']
                radius = min(v['outer_diameter'] / 2, disk['minimumBoundaryDistanceMm']) - 1e-9
                band = radius - v['hole_diameter'] / 2
                require(disk['centerStrictlyInsideFilledRegion'] is True and w['noGeometryOrRuleChange'] is True and
                        w['actualFullspanPlatedBarrelJoinsTopPackageReferenceToThisInner1Annulus'] is True and
                        math.isclose(w['guaranteedFilledDiskRadiusMm'], radius, abs_tol=1e-12) and
                        math.isclose(w['guaranteedCompleteAnnularContactBandWidthMm'], band, abs_tol=1e-12) and band > 1e-6 and
                        v['layers'] == LAYERS and v.get('source_net_id') == result['actualSourceNetId'],
                        'Actual plated annulus has a complete strictly positive filled contact band outside its drill')
                gs, gw = w['authenticPackageGroundSourceTrace'], w['authenticPackageGroundPcbTrace']
                sp, pp, top = w['actualRamNumericSourcePort'], w['actualRamNumericPcbPort'], w['actualHeldTopAlias']
                require(gs == actual_rows['source_trace'][gs['source_trace_id']] and gs['name'] == 'TI_PKG_U_RAM_PIN14_GND' and
                        gw == actual_rows['pcb_trace'][gw['pcb_trace_id']] and gw['source_trace_id'] == gs['source_trace_id'] and
                        sp == actual_rows['source_port'][sp['source_port_id']] and sp['pin_number'] == 14 and
                        actual_rows['source_component'][sp['source_component_id']]['name'] == 'U_RAM' and
                        pp == actual_rows['pcb_port'][pp['pcb_port_id']] and pp['source_port_id'] == sp['source_port_id'] and
                        top['actualPcbPortId'] in v['pcb_port_ids'] and top['layer'] == 'top' and
                        set(gs['connected_source_port_ids']) == {sp['source_port_id'], top['actualSourcePortId']} and
                        gs['connected_source_net_ids'] == [result['actualSourceNetId']] and len(gw['route']) == 2 and
                        gw['route'][0]['start_pcb_port_id'] == top['actualPcbPortId'] and
                        gw['route'][-1]['end_pcb_port_id'] == pp['pcb_port_id'] and
                        all(p['route_type'] == 'wire' and p['layer'] == 'top' and p['width'] == .2 for p in gw['route']),
                        'GND witness authentic raw Top reference connects the plated alias to real numeric U_RAM.pin14')
        else:
            raise ValueError('Unexpected PDN net in fresh contact proof')
    pdn_vias = []
    raw_vias = {v['pcb_via_id']: v for v in raw if v.get('type') == 'pcb_via'}
    for declaration in cap8['pdnVias']:
        mapping = [v for v in controls['generatedViaChecks'] if v['name'] == declaration['name']]
        results = [r for r in pdn['newPdnPlaneContactResults'] if r['sourceViaName'] == declaration['name']]
        require(len(mapping) == len(results) == 1 and mapping[0]['generatedKind'] == 'PDN' and mapping[0]['passed'] is True and
                results[0]['passed'] is True and results[0]['newPdnIdentity']['actualPcbViaId'] == mapping[0]['actualPcbViaId'],
                'Each drawn new PDN is the actual fresh authenticated barrel with a fresh plane-contact proof')
        v = raw_vias[mapping[0]['actualPcbViaId']]
        require(math.dist((v['x'], v['y']), (declaration['x'], declaration['y'])) <= 1e-8 and v['layers'] == LAYERS and
                v['outer_diameter'] == .4572 and v['hole_diameter'] == .254, 'Draw actual new fullspan PDN dimensions')
        pdn_vias.append({'name': declaration['name'], 'net': declaration['connectsTo'][4:], **v})
    cohorts = controls['timingObservations']['cohorts']
    require({r['cohort'] for r in cohorts} == {'DDR_BYTE0', 'DDR_BYTE1', 'DDR_COMMAND_CLOCK'} and
            {r['cohort']: r['withinTolerance'] for r in cohorts} ==
            {'DDR_BYTE0': True, 'DDR_BYTE1': True, 'DDR_COMMAND_CLOCK': False} and
            all(r['toleranceMm'] == .635 for r in cohorts) and len(controls['timingObservations']['pairs']) == 3 and
            all(r['withinTolerance'] is True for r in controls['timingObservations']['pairs']),
            'Both byte planar-skew passes, remaining CA timing failure and three pair passes remain explicit')
    for report in [controls, native, auth, aggregate]:
        require(report['fullBoardPassed'] is False and report['all49Accepted'] is False and report['fabricationReady'] is False,
                'Whole-board and fabrication acceptance flags must remain false')
    return {'pours': len(raw_pours), 'vias': via_count, 'wires': wire_count, 'cap': cap, 'cap8': cap8,
            'raw_pours': raw_pours, 'pdn_vias': pdn_vias,
            'cohortSkewMm': {r['cohort']: r['skewMm'] for r in cohorts}}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path, default=CANDIDATE)
    parser.add_argument('--output-dir', type=Path, default=OUTPUT_DIR)
    parser.add_argument('--pour-aggregate', type=Path, required=True)
    parser.add_argument('--pour-aggregate-sha', required=True)
    parser.add_argument('--pdn-proof', type=Path, required=True)
    parser.add_argument('--pdn-proof-sha', required=True)
    args = parser.parse_args()
    candidate = pinned_json(args.candidate, CANDIDATE_SHA)
    scene, bodies = candidate['full49FanoutInput'], candidate['carrierTraces']
    routed = {owner(t) for t in bodies}
    pending = [c for c in scene['connections'] if c['name'] not in routed]
    require(len(bodies) == len(routed) == 49 and pending == [] and candidate['all49Connected'] is True,
            'Expected49 routed owners, no pending owner and genuine connected candidate')
    require(scene['allowedLayers'] == LAYERS and scene['layerCount'] == 4 and candidate['all49Accepted'] is False and
            candidate['fabricationReady'] is False, 'Exact partial four-layer candidate with fabricationReady=false')
    evidence = verify_closed_evidence(candidate, args.pour_aggregate, args.pour_aggregate_sha, args.pdn_proof, args.pdn_proof_sha)
    physical = candidate['finalScenePhysicalReports']
    require(candidate['allSavedCarriersCurrentSceneQualified'] is True and len(physical) == 49 and all(r['passed'] for r in physical),
            'Actual268 all49 physical reports required')
    critical = pinned_json(CRITICAL_REPORT, CRITICAL_SHA)
    views = critical['criticalValidationViews']
    require(critical['candidatePath'] == str(CANDIDATE) and critical['all49Connected'] is True and
            critical['allSavedCarriersCurrentSceneQualified'] is True and critical['connectedCount'] == 49 and
            critical['remaining'] == [] and critical['criticalCompanionQualificationInherited'] is False and
            critical['criticalValidationViews'] == candidate['criticalValidationViews'] and
            critical['finalScenePhysicalReports'] == physical, 'Exact268 current49 physical and fresh both-view critical evidence required')
    require(len(views) == 2 and {v['scope'] for v in views} == {'DQS1_LOWER_U_SHARED_VIEW', 'DQS1_EARLY_MEANDER_SHARED_VIEW'},
            'Both actual DQS1 shared-section views required')
    for view in views:
        require(view['passed'] is True and view['c31']['solved'] is True and
                set(view['reports']) == {'bus', 'pair', 'shared', 'coupling', 'exterior'} and
                all(len(rows) == 3 and all(r['matched'] for r in rows) for rows in view['reports'].values()),
                'Actual268 original five APIs and C31 must pass for all three critical pairs in both views')
    require(args.output_dir.resolve() == OUTPUT_DIR.resolve() and not args.output_dir.is_symlink(),
            'Only the new owned Source272 visualization directory is authorized')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    outputs = [args.output_dir / ('SOURCE272_BOTH_BYTES_MATCHED_CAP12_CAP8_PDN_CONNECTED49_FOUR_LAYER_MILESTONE.' + extension) for extension in ('png', 'svg')]
    require(not any(p.exists() for p in outputs), 'Fresh Source272 connected49 output names required')
    fig, axes = plt.subplots(1, 4, figsize=(18, 9.5), sharex=True, sharey=True)
    for ax, layer in zip(axes, LAYERS):
        for obstacle in scene['obstacles']:
            if layer not in obstacle['layers']:
                continue
            x, y = obstacle['center']['x'], obstacle['center']['y']
            if x < -11 or x > 10 or y < 2 or y > 29:
                continue
            if obstacle.get('shape', obstacle.get('type')) == 'circle':
                patch = Circle((x, y), obstacle['width'] / 2)
            else:
                patch = Rectangle((x - obstacle['width'] / 2, y - obstacle['height'] / 2), obstacle['width'], obstacle['height'])
                patch.set_transform(Affine2D().rotate_deg_around(x, y, obstacle.get('ccwRotationDegrees', 0)) + ax.transData)
            patch.set(facecolor='#d5d9de', edgecolor='none', alpha=.55, zorder=1)
            ax.add_patch(patch)
        # Actual fresh BREP boundaries only; no regenerated/guessed plane fill.
        boundaries = []
        for pour in evidence['raw_pours']:
            if pour['layer'] != layer:
                continue
            require(pour['shape'] == 'brep', 'Actual plot pour must be a literal BREP')
            brep = pour['brep_shape']
            for ring in [brep['outer_ring']] + brep.get('inner_rings', []):
                points = [(p['x'], p['y']) for p in ring['vertices']]
                require(len(points) >= 3, 'Actual BREP boundary vertices')
                boundaries.append(points + [points[0]])
        ax.add_collection(LineCollection(boundaries, colors='#94a3b8', linewidths=.25, alpha=.30, zorder=.5))
        fixed = [segment for t in scene['traces'] for segment in wire_segments(t, layer)]
        ax.add_collection(LineCollection(fixed, colors='#aab2bb', linewidths=.5, zorder=2))
        for trace in scene['traces']:
            for p in trace['route']:
                if p['route_type'] == 'via' and layer in p.get('layers', []):
                    ax.add_patch(Circle((p['x'], p['y']), p.get('via_diameter', .4572) / 2, fill=False, edgecolor='#a5adb6', linewidth=.45, zorder=2))
        for trace in bodies:
            color = COLORS.get(owner(trace), COLORS['ordinary'])
            ax.add_collection(LineCollection(wire_segments(trace, layer), colors=color, linewidths=1.15, zorder=4))
            for p in trace['route']:
                if p['route_type'] == 'via' and layer in p.get('layers', []):
                    ax.add_patch(Circle((p['x'], p['y']), p['via_diameter'] / 2, fill=False, edgecolor=color, linewidth=.9, zorder=5))
        for via in evidence['pdn_vias']:
            color = '#b54708' if via['net'] == 'DDR_1V5' else '#344054'
            ax.add_patch(Circle((via['x'], via['y']), via['outer_diameter'] / 2, fill=False,
                                edgecolor=color, linewidth=1.45, zorder=8))
            ax.plot(via['x'], via['y'], marker='+', markersize=3.7, color=color, zorder=9)
            if (via['net'] == 'DDR_1V5' and layer == 'inner2') or (via['net'] == 'GND' and layer == 'inner1'):
                ax.annotate('PDN ' + via['net'], xy=(via['x'], via['y']), xytext=(via['x'] - 3.0, via['y'] - .8),
                            fontsize=5.8, color=color, arrowprops={'arrowstyle': '->', 'lw': .6, 'color': color}, zorder=10)
        ax.add_patch(Rectangle((-7, 13), 14, 14, fill=False, edgecolor='#697386', linestyle='--', linewidth=.7))
        ax.add_patch(Rectangle((-5.01, 3.99), 12.42, 6.82, fill=False, edgecolor='#697386', linestyle='--', linewidth=.7))
        ax.text(-6.9, 26.35, 'AM3352', fontsize=8, color='#475467')
        ax.text(-4.9, 4.25, 'DDR3L', fontsize=8, color='#475467')
        ax.set(title={'top': 'Top', 'inner1': 'Inner1', 'inner2': 'Inner2', 'bottom': 'Bottom'}[layer],
               xlim=(-10.2, 9), ylim=(2.8, 28), aspect='equal', xlabel='X (mm)')
        ax.grid(alpha=.12)
        if layer == 'bottom':
            ax.annotate('C_DDR_RAM_12 +0.79 mm X', xy=(6.79, 4.7), xytext=(2.1, 3.15),
                        fontsize=6.3, color='#9c4707', arrowprops={'arrowstyle': '->', 'lw': .65, 'color': '#9c4707'}, zorder=7)
            ax.annotate('C_DDR_RAM_8 moved to (0, 7.9)', xy=(0, 7.9), xytext=(-8.4, 5.8),
                        fontsize=6.0, color='#9c4707', arrowprops={'arrowstyle': '->', 'lw': .65, 'color': '#9c4707'}, zorder=10)
    axes[0].set_ylabel('Y (mm)')
    fig.suptitle('G350 · Source272 editable DDR geometry · 49 of 49 connected · both byte groups matched', fontsize=15, weight='bold', y=.965)
    fig.text(.5, .099, 'Green: ordinary routes  |  Blue: DQS0  |  Orange: DQS1  |  Purple: CK  |  Rust/charcoal rings: new PDN vias',
             ha='center', fontsize=9.4)
    fig.text(.5, .039,
             'Fresh Source272: 35/35 controls and all49 numeric graphs PASS. Byte0/Byte1 planar skew PASS; command/address timing still fails.\n'
             + f"Byte0 {evidence['cohortSkewMm']['DDR_BYTE0']:.5f} mm / Byte1 {evidence['cohortSkewMm']['DDR_BYTE1']:.5f} mm (limit 0.635). Native273: 15 checks zero; one CA skew finding.\n"
             + f"Auth274: {evidence['vias']} vias, zero foreign via-track violations. Literal {evidence['pours']} pours / {evidence['wires']} routed segments: zero margin violations.\n"
             + 'Cap12 X+0.79; cap8 moved with two real PDN barrels and proven local plane contacts. Timing / TI / reference / CAD / fabrication unqualified; not default; fabricationReady=false.',
             ha='center', fontsize=8.2, color='#475467')
    fig.subplots_adjust(top=.92, bottom=.17, wspace=.13)
    bindings = [(args.candidate, CANDIDATE_SHA), (CRITICAL_REPORT, CRITICAL_SHA), (RAW_CORE, RAW_CORE_SHA),
                (CONTROLS, CONTROLS_SHA), (NATIVE, NATIVE_SHA), (AUTH, AUTH_SHA), (PLAN, PLAN_SHA),
                (args.pour_aggregate, args.pour_aggregate_sha), (args.pdn_proof, args.pdn_proof_sha),
                (PDN_PROOF_SOURCE, PDN_PROOF_SOURCE_SHA), (PDN_PRIOR, PDN_PRIOR_SHA), (PDN_PRIOR_SOURCE, PDN_PRIOR_SOURCE_SHA)]
    require(all(hashlib.sha256(path.read_bytes()).hexdigest() == expected for path, expected in bindings),
            'All exact plot geometry/evidence inputs must remain unchanged')
    description = ('Exact268 geometry ' + CANDIDATE_SHA + '; Source272 raw ' + RAW_CORE_SHA + '; controls ' + CONTROLS_SHA
        + '; current268 both-view critical ' + CRITICAL_SHA + '; native273 ' + NATIVE_SHA + '; auth274 ' + AUTH_SHA
        + '; literal aggregate ' + args.pour_aggregate_sha + '; fresh new-full-land/held-annular PDN contact proof ' + args.pdn_proof_sha
        + '; preserved prior negative ' + PDN_PRIOR_SHA
        + '; 49/49 connected; no pending owner; cap12 X+.79, cap8 center0,7.9 and two net-declared PDN fullspan barrels; '
        + str(evidence['pours']) + ' actual pours/' + str(evidence['wires']) + ' routed segments/' + str(evidence['vias'])
        + ' vias; both byte cohort planar skew checks pass; CA skew/minimum failures remain; timing/TI/reference/CAD/fabrication unqualified; default unchanged; all49Accepted=false; fabricationReady=false.')
    for output, kind in zip(outputs, ('png', 'svg')):
        buffer = io.BytesIO()
        metadata = {'Description': description}
        if kind == 'svg':
            metadata['Date'] = None
        fig.savefig(buffer, format=kind, dpi=180, metadata=metadata)
        payload = buffer.getvalue()
        with output.open('xb') as stream:
            stream.write(payload)
        print(str(output) + ' ' + hashlib.sha256(payload).hexdigest())
    plt.close(fig)
    print(json.dumps({'candidateSha256': CANDIDATE_SHA, 'source272RawSha256': RAW_CORE_SHA,
                      'routedOwners': 49, 'pendingOwnerIds': [], 'bothBytesPlanarSkewPassed': True, 'commandAddressTimingPassed': False,
                      'actualPourCount': evidence['pours'], 'actualViaCount': evidence['vias'],
                      'actualRoutedWireSegmentCount': evidence['wires'], 'all49Accepted': False, 'fabricationReady': False}))


if __name__ == '__main__':
    main()
