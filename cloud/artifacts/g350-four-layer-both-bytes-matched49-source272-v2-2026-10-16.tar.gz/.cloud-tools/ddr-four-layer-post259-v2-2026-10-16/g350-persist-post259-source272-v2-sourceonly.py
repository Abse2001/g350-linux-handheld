#!/usr/bin/env python3
"""SOURCE ONLY. Root-reviewed own-stdlib collector; author did not execute it.
Writes ONLY a fresh post259-v2 folder. Preserves the first post259 snapshot.
Adds solverSourceRoot from the exact Source257 base manifest for the existing
workspace restorer; routing evidence/constraints/qualification do not change. All old frozen evidence and tracked Source
stay unchanged. Freeze is Source272 through274;275+ are outside this snapshot.
"""
import argparse,copy,datetime,hashlib,json,math,os,re,shutil,stat
from pathlib import Path
ROOT=Path('/workspace/g350-linux-handheld')
SAVED=ROOT/'.cloud-tools/ddr-four-layer-post259-v2-2026-10-16'
PRIOR=ROOT/'.cloud-tools/ddr-four-layer-post259-2026-10-16'
PRIOR_PINS={'PROGRESS.json':'51b592730f1c5268539a603da19cef478aa9b9e47316a616b36cfc79d5da7a88','WORKSPACE_HASH_INDEX.json':'1a21ed578619c45f2cba32a075ffd755ed5b65b074a860786f1ea1f241d0ba53','WORKSPACE_RESTORE_MANIFEST.json':'58d8a5c05ec5dd0c3c94ca2d5cae01257c385642bd919ee4f4977f7f0d78ae3b','README.md':'0748026024841e3970f1ae549bd2720c41387c1b4d8606493b6f20d9247aa3bf'}
SOLVER_SOURCE_ROOT='/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib'
BASE=ROOT/'.cloud-tools/ddr-four-layer-post252-2026-10-16'
BASE_PINS={'PROGRESS.json':'1d9f42e2156cf88c35749db4afabef9487c76abf9bf4db2f84c6a5d0a8506929',
'WORKSPACE_HASH_INDEX.json':'34cc299291cc22ff1d32516501e2031d594e225dd029fd24141215a576715b13',
'WORKSPACE_RESTORE_MANIFEST.json':'2593a7737076d09e011a52e7b1f97eb9ee7211cdd3f9ace9239c1809617a5150',
'README.md':'4d46631646828b215e5fc0a50b7c83624540a5ffb869a7a327d1dad9de4c03b7'}
BASE_MANIFEST=ROOT/'cloud/artifacts/g350-four-layer-connected49-source257-2026-10-16.manifest.json'
BASE_MANIFEST_SHA='4b7c6414612c0119e8b718877a912052cdf76e4fcc87279a35735ea40fe05bd9'
BASE_ARCHIVE_SHA='8e18d75892787b85fe99b13de607871dab8009a19ff03d0515a4c4b835efb3ac'
CANDIDATE=Path('/tmp/g350-both-bytes-retimed49-root-20261016-run268/byte0-result.candidate.json')
CANDIDATE_SHA='fcc50ba7874af9724526a443367f70eeb42bff6179eb07ef8fd3ff929c0c6c77'
REPORT=CANDIDATE.with_name('byte0-result.json')
PLAN=Path('/tmp/g350-both-bytes-ca9-matched49-projector-root-20261016-run269/byte0-result.json')
PLAN_SHA='4bb8153b7dddfcd73b78dad9d07483c239967680bdd25ef53b5487da46fbb107'
CAPTURE=Path('/tmp/g350-both-bytes-ca9-matched49-capture-root-20261016-run270/byte0-result.json')
CAPTURE_SHA='a370b9a6e2b05a72f84be9696beff79adad3bd9fd7cfa16045319b5dd381c6ec'
RAW=Path('/tmp/g350-both-bytes-ca9-matched49-core272-raw.json')
RAW_SHA='33584d197a1bb45a0dc76ac0a69e7016866a2369f1750c72d5eedc41ef444594'
CONTROLS=Path('/tmp/g350-both-bytes-ca9-matched49-core-smol-root-20261016-run272/byte0-result.json')
CONTROLS_SHA='32eec52a75348a996f7fbfd4271b2318c9bf4c39229fd67a289d97835aa63ec4'
NATIVE=Path('/tmp/g350-both-bytes-ca9-matched49-native-root-20261016-run273/byte0-result.json')
AUTH=Path('/tmp/g350-both-bytes-ca9-matched49-via-track-root-20261016-run274/byte0-result.json')
AUTH_SHA='7459c5bd51b041686dea91b56779dcc94498b02b2a7e6ef51c796e42192d5886'
AGGREGATE=Path('/tmp/g350-source272-all16-literal-pour-margin-root-aggregate-20261016.json')
AGGREGATE_SHA='4e2062c0dd589462e7f07a739d9c71d0ddf395f21c22791110973ea4f2a56479'
PDN=Path('/tmp/g350-source272-new-pdn-annular-same-polygon-root-20261016.json')
PDN_SHA='618ea6dfb7294ff665a4c5f84b33149ea16367d633dff5b3c7f024bdc744f57a'
SMOL=Path('/tmp/g350-route-bounded-explicit-input-smol-root-20261016.py')
SMOL_SHA='bef1bbd2ae97aab2263263a5fc5905cc26d31647cad9499baff2e73c6a11d9ba'
PLOT_DIR=Path('/tmp/g350-source272-both-bytes-matched49-root-20261016-plot')
PLOT_SOURCE=Path('/tmp/g350-plot-source272-both-bytes-matched49-root-sourceonly.py')
PLOT_SOURCE_SHA='f8b27be1962b98325ef4b89c9b0ef8998326d3d80762626601a9b7525fd4d158'
PLOTS={
'SOURCE272_BOTH_BYTES_MATCHED_CAP12_CAP8_PDN_CONNECTED49_FOUR_LAYER_MILESTONE.png':'4dd0744f1e7e914eaa2e59259b1b2ddee2db39fc5760d27d0fb72868ddeb6c8a',
'SOURCE272_BOTH_BYTES_MATCHED_CAP12_CAP8_PDN_CONNECTED49_FOUR_LAYER_MILESTONE.svg':'307458d86a910e3402672f353fcedab5b9c57faec13176e7e8c8974f25748dbc'}
PINS={str(p):h for p,h in ((CANDIDATE,CANDIDATE_SHA),(PLAN,PLAN_SHA),(CAPTURE,CAPTURE_SHA),(RAW,RAW_SHA),
(CONTROLS,CONTROLS_SHA),(AUTH,AUTH_SHA),(AGGREGATE,AGGREGATE_SHA),(PDN,PDN_SHA),(SMOL,SMOL_SHA),(PLOT_SOURCE,PLOT_SOURCE_SHA))}
PINS.update({str(PLOT_DIR/n):h for n,h in PLOTS.items()})
ALL49={'source_trace_'+str(i) for i in range(49)}
DENIED=('ROOT_AUTHORITY','PRIVATE_CONTEXT','CONTEXT_BODY','BOUND_CONTEXT','AUTHORITY_PACKET')
ALIASES=[('byte0-result.candidate.json',CANDIDATE),('byte0-result.json',REPORT),('route-plan.json',PLAN),
('source-capture.json',CAPTURE),('raw-core.json',RAW),('core-controls.json',CONTROLS),
('native-focused16.json',NATIVE),('via-owner234.json',AUTH),('literal-pour-aggregate-all16.json',AGGREGATE),('new-pdn-annular-contact.json',PDN)]
META={'PROGRESS.json','WORKSPACE_HASH_INDEX.json','WORKSPACE_RESTORE_MANIFEST.json','README.md'}
RESERVED=META|{name for name,_ in ALIASES}
def need(v,m):
 if not v:raise ValueError(m)
def regular(p):return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
def safe(p):return p.is_absolute() and str(p).startswith('/tmp/g350-') and p.resolve().is_relative_to('/tmp') and not any(s in str(p).upper() for s in DENIED)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
  if hasattr(os,'posix_fadvise'):os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 return h.hexdigest()
def read(p):
 with p.open('rb') as f:
  d=json.load(f)
  if hasattr(os,'posix_fadvise'):os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 return d
def metadata(p):return {'bytes':p.stat().st_size,'sha256':digest(p),'mode':stat.S_IMODE(p.stat().st_mode)}
def owner(t):return t.get('connection_name') or t.get('source_trace_id') or t.get('owner')
def roster(rows):return len(rows)==49 and {owner(t) for t in rows}==ALL49
def verify_rows(folder,rows):
 for r in rows:
  rel=Path(r['path']);p=folder/rel
  need(not rel.is_absolute() and '..' not in rel.parts and p.resolve().is_relative_to(folder.resolve()) and regular(p) and metadata(p)=={k:r[k] for k in ('bytes','sha256','mode')},'Frozen bytes/mode '+str(p))
def verify_prior():
 need(PRIOR.is_dir() and not PRIOR.is_symlink(),'Exact frozen first Source272 snapshot')
 for n,h in PRIOR_PINS.items():need(digest(PRIOR/n)==h,'Frozen first Source272 metadata changed')
 rows=read(PRIOR/'WORKSPACE_HASH_INDEX.json')['files'];need(len(rows)==118,'Exact frozen first118-row index');verify_rows(PRIOR,rows)
 need({q.relative_to(PRIOR).as_posix() for q in PRIOR.rglob('*') if q.is_file()}=={r['path'] for r in rows}|{'WORKSPACE_HASH_INDEX.json'},'Frozen first Source272 inventory unchanged')
def verify_base():
 need(BASE.is_dir() and not BASE.is_symlink(),'Frozen Source257 dependency')
 for n,h in BASE_PINS.items():need(digest(BASE/n)==h,'Frozen Source257 metadata changed')
 rows=read(BASE/'WORKSPACE_HASH_INDEX.json')['files'];need(len(rows)==107,'Exact Source257107-row frozen index');verify_rows(BASE,rows)
 need(digest(BASE_MANIFEST)==BASE_MANIFEST_SHA,'Source257 archive manifest pin')
 a=read(BASE_MANIFEST)['archive'];p=ROOT/a['path']
 need(p.resolve().is_relative_to(ROOT.resolve()) and regular(p) and a['sha256']==BASE_ARCHIVE_SHA and a['bytes']==8420938 and p.stat().st_size==a['bytes'] and digest(p)==BASE_ARCHIVE_SHA,'Frozen Source257 archive unchanged')
def verify_current(profile):
 c,r,plan,cap,ctrl,nat,auth,agg,pdn,raw=[read(p) for p in (CANDIDATE,REPORT,PLAN,CAPTURE,CONTROLS,NATIVE,AUTH,AGGREGATE,PDN,RAW)]
 for d in (c,r):
  need(d['all49Connected'] is True and d['allSavedCarriersCurrentSceneQualified'] is True and roster(d['finalScenePhysicalReports']) and all(q['passed'] is True for q in d['finalScenePhysicalReports']),'Fresh268 all49 physical')
  need(len(d['criticalValidationViews'])==2 and all(v['passed'] is True and v['c31']['solved'] is True and set(v['reports'])=={'bus','pair','shared','coupling','exterior'} and all(len(a)==3 and all(q['matched'] for q in a) for a in v['reports'].values()) for v in d['criticalValidationViews']),'Fresh268 both actual DQS1 critical views/all five APIs')
  need(all(d[k] is False for k in ('all49Accepted','fabricationReady','electricalTimingQualified','timingPassed','cadExecuted','nativeExecuted','freshSource')),'Model boundaries retained')
 need(roster(c['carrierTraces']) and roster(c['joinedNumericPadTraces']) and len(c['heldCarrierTraces'])==6 and len(c['full49FanoutInput']['connections'])==49 and len(c['full49FanoutInput']['traces'])==263 and len(c['full49FanoutInput']['obstacles'])==1300,'Complete268 geometry/foundation inventory')
 need(plan['inputBindings']['candidate']['sha256']==CANDIDATE_SHA and plan['pendingOwnerIds']==[] and len(plan['newVias'])==103 and len(plan['innerPortRegistrations'])==80 and len(plan['projectedGeometry'])==49,'Exact269 complete49 projection')
 need(cap['passed'] is True and cap['fullInverseSourceTreePassed'] is True and cap['parentNormalizationInversePassed'] is True and cap['planSha256']==PLAN_SHA and cap['candidateSha256']==CANDIDATE_SHA,'Capture270 full literal/key inverse')
 need(ctrl['rawCoreSha256']==RAW_SHA and ctrl['planSha256']==PLAN_SHA and ctrl['candidateSha256']==CANDIDATE_SHA and ctrl['actualCaptureSha256']==CAPTURE_SHA and ctrl['freshCoreDerived'] is True and ctrl['partialDiagnosticReplayControlsPassed'] is True and ctrl['all49Connected'] is True and len(ctrl['checks'])==35 and all(q['passed'] is True for q in ctrl['checks']),'Fresh272 actual35/35 controls bound to268/269/270')
 need(len(ctrl['physicalGraphs'])==49 and {g['originalSourceTraceId'] for g in ctrl['physicalGraphs']}==ALL49 and all(g['physicallyConnectedByActualOwnedNumericIdGraph'] is True for g in ctrl['physicalGraphs']),'All49 actual owned numeric graphs')
 need(ctrl['expectedCounts']['physicalVias']==234 and ctrl['expectedCounts']['physicalTraces']==317 and ctrl['expectedCounts']['newSignalVias']==103 and ctrl['expectedCounts']['newPdnVias']==2,'Actual234/317 and103+2 inventory')
 need(ctrl['cap8HardwareDelta']==plan['cap8HardwareDelta'] and ctrl['cap12HardwareDelta']==plan['cap12HardwareDelta'],'Current hardware descriptors literal')
 co={x['cohort']:x for x in ctrl['timingObservations']['cohorts']}
 need(set(co)=={'DDR_BYTE0','DDR_BYTE1','DDR_COMMAND_CLOCK'} and co['DDR_BYTE0']['withinTolerance'] is True and co['DDR_BYTE1']['withinTolerance'] is True and co['DDR_COMMAND_CLOCK']['withinTolerance'] is False,'Both byte planar skews pass; CA fails')
 for n,v in (('DDR_BYTE0',.5771666935110176),('DDR_BYTE1',.5769421602573122),('DDR_COMMAND_CLOCK',17.438700934198632)):
  need(abs(co[n]['skewMm']-v)<1e-9 and co[n]['toleranceMm']==.635,'Original exact .635 skew observation')
 ca_count=sum(q['cohort']=='DDR_COMMAND_CLOCK' and q['timingObservationOnly']['aboveMinimum'] is True for q in ctrl['generatedWireChecks']);need(ca_count==9,'Actual2729/26 CA above retained20.95 minimum')
 need(all(q['withinTolerance'] is True for q in ctrl['timingObservations']['pairs']) and len(ctrl['timingObservations']['pairs'])==3,'Original three .127 pair observations')
 nr={q['name']:q for q in nat['results']};need(nat['completed'] is True and nat['finished'] is True and nat['completedCheckCount']==16 and nat['exceptionCount']==0 and nat['allPinnedInputsUnchanged'] is True and len(nr)==16 and nat['all32FreshNativeChecksExecuted'] is False and nr['checkPcbBusLengthSkew']['findingCount']==1 and all(q['state']=='completed' and q['findingCount']==0 for n,q in nr.items() if n!='checkPcbBusLengthSkew'),'Native27316 complete/all15 geometry clear/one CA skew finding')
 need(auth['complete'] is True and auth['actualViaCount']==auth['completedViaCount']==234 and auth['foreignViaTrackCopperClearancePassed'] is True and auth['exactInputFilesUnchanged'] is True and all(auth[k]==[] for k in ('violations','identityFailures','ambiguousVias','invalidSegments','unresolvedSegmentOwners')),'Auth274 all234 unfiltered clear')
 pour_ids=[p['pcb_copper_pour_id'] for p in raw if p.get('type')=='pcb_copper_pour']
 need(len(pour_ids)==16 and len(set(pour_ids))==16 and sum(p.get('type')=='pcb_via' for p in raw)==234,'Actual27216-pour234-via inventory')
 need(agg['completed'] is True and agg['literalForeignPourMarginClear'] is True and agg['actualRawPourIds']==pour_ids and agg['completedPourIds']==pour_ids and agg['actualRawPourCount']==agg['completedPourCount']==16 and agg['actualViaCount']==234 and agg['wireSegmentCount']==5097 and agg['wireOwnerCount']==49 and agg['violations']==agg['unsupportedGeometry']==agg['identityFailures']==[] and agg['inputFilesUnchanged'] is True and agg['allCompletedComparisonRostersReconstructedFromExactRaw'] is True and agg['requiredForeignViaPourEdgeMm']==agg['requiredForeignWirePourEdgeMm']==.1016 and agg['coordinateToleranceMm']==1e-8,'Complete literal16/234/5097 exact current foreign-margin aggregate')
 for n in range(4):
  b=agg['inputBindings']['report_'+str(n)];p=Path(b['path']);need(digest(p)==b['sha256'],'Exact completed batch receipt');d=read(p)
  need(d['inputFilesUnchanged'] is True and d['literalForeignPourMarginClear'] is True and all(q['state']=='COMPLETED' for q in d['pourReports']),'All four completed bounded selected contributions')
 need(pdn['passed'] is True and pdn['newPdnLocalPlaneContactsQualified'] is True and pdn['errors']==[] and pdn['exactInputFilesUnchanged'] is True and pdn['geometryOrManufacturingRulesChanged'] is False and pdn['actualViaCount']==234 and len(pdn['newPdnPlaneContactResults'])==2 and all(q['passed'] is True for q in pdn['newPdnPlaneContactResults']),'Current272 two fresh local PDN annular/full-land contacts')
 for d,bindings in ((nat,{'raw':RAW_SHA,'controls':CONTROLS_SHA,'reviewedSourcePlan':PLAN_SHA}),
 (auth,{'raw':RAW_SHA,'controls':CONTROLS_SHA,'plan':PLAN_SHA,'candidate':CANDIDATE_SHA}),
 (agg,{'raw':RAW_SHA,'controls':CONTROLS_SHA,'current234Ownership':AUTH_SHA,'reviewedSourcePlan269':PLAN_SHA}),
 (pdn,{'raw':RAW_SHA,'controls':CONTROLS_SHA,'auth':AUTH_SHA,'plan':PLAN_SHA})):
  need(all(d['inputBindings'][k]['sha256']==v for k,v in bindings.items()),'Fresh reports must bind exact current272 inputs')
 need(profile['rootRenderedAndViewedPlot'] is True and profile['frozenCheckpoint'] is True,'Root-rendered/viewed current plot')
 receipts=[]
 for item in profile['runs']:
  scope=item['scope'];folder=Path(item['folder']);closed=read(folder/'COLLECTED.json');e=read(folder/'owned/execution.json')
  need(260<=scope<=274 and closed['scope']==scope and closed['closedAt'] and closed['execution']==e and closed['sourcePinsUnchanged'] is True and closed['protectedFilesUnchanged'] is True and e['cleanupOwnedGroupEmpty'] is True,'Exact closed260..274 receipt')
  if scope==262:need(e['exitCode']==1 and not (folder/'byte0-result.json').exists(),'Failed262 STEPparse before output')
  elif scope==271:need(e['diagnosticStopped'] is True and 'OWNED_RSS_STOP' in e['stopReasons'] and not (folder/'byte0-result.json').exists(),'Failed271 RSS stop, no accepted Core result')
  else:need(e['exitCode']==0,'Passed closed scope')
  receipts.append({'scope':scope,'closedAt':closed['closedAt'],'exitCode':e['exitCode'],'state':'STEP_PARSE_FAILURE' if scope==262 else 'OWNED_RSS_STOP' if scope==271 else 'CLOSED_SCOPED_RESULT','folder':str(folder)})
 need({r['scope'] for r in receipts}==set(range(260,275)),'Exactly all fifteen closed scopes260–274')
 return {'candidate':c,'report':r,'plan':plan,'controls':ctrl,'native':nat,'auth':auth,'aggregate':agg,'pdn':pdn,'pourIds':pour_ids,'receipts':receipts}
def write_json(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n');os.fchmod(f.fileno(),0o600)
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--profile',default='/tmp/g350-post259-source272-checkpoint-profile-sourceonly.json');a.add_argument('--profile-sha',required=True);args=a.parse_args();pp=Path(args.profile)
 need(safe(pp) and regular(pp) and re.fullmatch('[0-9a-f]{64}',args.profile_sha) and digest(pp)==args.profile_sha,'Explicit reviewed profile SHA')
 p=read(pp);need(p['scope']=='POST259_SOURCE272_CONNECTED49_BOTH_BYTES_MATCHED_CA_UNMATCHED_FROZEN_PROFILE' and p['candidateSha256']==CANDIDATE_SHA and p['rawSha256']==RAW_SHA and p['controlsSha256']==CONTROLS_SHA,'Exact reviewed Source272 profile')
 need(not SAVED.exists(),'Fresh newpost259-v2 only; never append frozen evidence');verify_base();verify_prior()
 pinmap=dict(PINS)
 for row in p['artifacts']:
  q=Path(row['path']);need(safe(q) and regular(q) and metadata(q)=={k:row[k] for k in ('bytes','sha256','mode')},'Exact profile artifact bytes/hash/mode')
  need(str(q) not in pinmap or pinmap[str(q)]==row['sha256'],'Explicit pin agreement');pinmap[str(q)]=row['sha256']
 for n,h in pinmap.items():need(safe(Path(n)) and regular(Path(n)) and digest(Path(n))==h,'Required exact current Source272 bytes')
 state=verify_current(p);bp=read(BASE/'PROGRESS.json');bm=read(BASE/'WORKSPACE_RESTORE_MANIFEST.json')
 need(bm['solverSourceRoot']==SOLVER_SOURCE_ROOT,'Exact pinned Source257 solverSourceRoot; no invented metadata')
 catalog={r['restorePath']:copy.deepcopy(r) for r in bm['baseDependencyRestoreFiles']}
 for row in bm['files']:catalog[row['restorePath']]={'baseSavedDirectory':BASE.relative_to(ROOT).as_posix(),**copy.deepcopy(row)}
 targets={};bases={};inputs={};SAVED.mkdir(parents=True,exist_ok=False)
 def save(q,name=None):
  q=Path(q);need(safe(q) and regular(q),'Only public regular /tmp inputs');before=q.stat();d=metadata(q);inputs[str(q)]=d
  if str(q) in targets:
   need(d=={k:targets[str(q)][k] for k in ('bytes','sha256','mode')},'Repeated restore source unchanged')
   return targets[str(q)]
  old=catalog.get(str(q))
  if old and all(old.get(k)==v for k,v in d.items()):bases[str(q)]=copy.deepcopy(old);return {'baseDependencyOnly':True,**old}
  dest=SAVED/(name or q.name);need(dest.parent==SAVED,'Flat safe destination')
  if dest.name in RESERVED:dest=dest.with_name('DEPENDENCY_'+d['sha256'][:16]+'_'+dest.name)
  if dest.exists() and metadata(dest)!=d:dest=dest.with_name(dest.stem+'__'+d['sha256'][:16]+'_'+str(d['mode'])+dest.suffix)
  if not dest.exists():
   with q.open('rb') as source,dest.open('xb') as out:shutil.copyfileobj(source,out,1048576);os.fchmod(out.fileno(),d['mode'])
  after=q.stat();need((before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns) and metadata(dest)==d,'Stable exact source copy')
  row={'savedPath':dest.name,'restorePath':str(q),**d};targets[str(q)]=row;return row
 for n in pinmap:
  q=Path(n);label=None
  for rr in p['runs']:
   folder=Path(rr['folder'])
   if q.is_relative_to(folder):label='SCOPE'+str(rr['scope'])+'_'+('owned_' if q.parent.name=='owned' else '')+q.name;break
  save(q,label)
 save(pp);save(Path(__file__));save(Path('/tmp/g350-author-post259-source272-profile-sourceonly.py'))
 need(all(not (SAVED/n).exists() for n in RESERVED),'All alias and metadata names reserved')
 aliases={}
 for n,q in ALIASES:
  row=targets[str(q)]
  with (SAVED/row['savedPath']).open('rb') as source,(SAVED/n).open('xb') as out:shutil.copyfileobj(source,out,1048576);os.fchmod(out.fileno(),row['mode'])
  need(metadata(SAVED/n)=={k:row[k] for k in ('bytes','sha256','mode')},'Exact current alias')
  aliases[n]={'canonicalSavedPath':row['savedPath'],'restorePath':str(q),**{k:row[k] for k in ('bytes','sha256','mode')}}
 base_archive=read(BASE_MANIFEST)['archive'];dep={**base_archive,'manifest':BASE_MANIFEST.relative_to(ROOT).as_posix(),'manifestSha256':BASE_MANIFEST_SHA,'mustBeRestoredFirst':True,'payloadCopiedByThisCollector':False}
 dependencies=copy.deepcopy(bp['baseArchiveDependenciesInRestoreOrder'])+[dep]
 def saved(q):return copy.deepcopy(targets[str(q)])
 false={'all49Accepted':False,'fullBoardPassed':False,'fullTimingPassed':False,'electricalTimingQualified':False,'tiQualified':False,'referenceContinuityQualified':False,'cadQualified':False,'defaultBoardPromoted':False,'fabricationReady':False}
 current={'scope':'SOURCE272_BOTH_BYTE_PLANAR_SKEWS_PASSED_CA_UNMATCHED_SCOPED_CHECKPOINT','candidateSha256':CANDIDATE_SHA,'savedCandidate':'byte0-result.candidate.json','candidate':saved(CANDIDATE),'report':saved(REPORT),'routedOwners':49,'pendingOwnerIds':[],'resumeRoutingFromThisCheckpoint':True,'raw':saved(RAW),'controls':saved(CONTROLS),'plan':saved(PLAN),'capture':saved(CAPTURE),'freshCoreScope':272,'all35CoreControlsPassed':True,'nativeFocused16':saved(NATIVE),'nativePhysical10Findings':0,'nativeBusSkewFindingCount':1,'other16NativeChecksNotRetested':True,'authenticated234ViaTrack':saved(AUTH),'timingObservations':state['controls']['timingObservations'],'byte0PlanarSkewPassed':True,'byte1PlanarSkewPassed':True,'caMinimumPassingCount':9,'caMemberCount':26,'caUnderMinimumCount':17,'caPlanarSkewPassed':False,'originalConstraintsUnchanged':True,**false}
 pours={'scope':state['aggregate']['scope'],'aggregate':saved(AGGREGATE),'reports':[saved(Path(state['aggregate']['inputBindings']['report_'+str(i)]['path'])) for i in range(4)],'actualPourCount':16,'actualPourIds':state['pourIds'],'actualViaCount':234,'routedWireSegmentCount':5097,'routedWireOwnerCount':49,'requiredForeignEdgeClearanceMm':.1016,'literalForeignPourMarginClear':True,'referenceWireGeometryIncluded':False,'ownNetReentryQualified':False,**false}
 contact={'report':saved(PDN),'newPdnLocalPlaneContactsQualified':True,'geometryOrManufacturingRulesChanged':False,'fullDdrReferencePlaneContinuityQualified':False,'historicalSource257NegativeNotCurrentQualification':True,**false}
 plot={'source':saved(PLOT_SOURCE),'files':[saved(PLOT_DIR/n) for n in PLOTS],'rootRenderedAndViewed':True,'views':['top','inner1','inner2','bottom'],'candidateSha256':CANDIDATE_SHA,'rawCoreSha256':RAW_SHA,'routedOwners':49,'pendingOwnerIds':[],**false}
 current.update({'literalPourCoverageAggregate':pours,'newPdnLocalContactProof':contact,'reviewedFourLayerPlot':plot})
 receipts=[]
 for rr in state['receipts']:
  folder=Path(rr['folder']);row={**rr,'closure':saved(folder/'COLLECTED.json'),'execution':saved(folder/'owned/execution.json'),'qualificationInheritedBySource272':False,**false}
  if regular(folder/'byte0-result.json'):row['report']=saved(folder/'byte0-result.json')
  receipts.append(row)
 now=datetime.datetime.now(datetime.timezone.utc).isoformat();freeze={'scope':'CLOSED274_SOURCE272_BOTH_BYTES_MATCHED_CA_UNMATCHED_ALL16_POURS_PDN_LOCAL_CONTACTS_REVIEWED_PLOT','latestClosedScope':274,'candidateSha256':CANDIDATE_SHA,'rawCoreSha256':RAW_SHA,'laterWorkRequiresNewSavedDirectory':True}
 common={'updatedAt':now,'scope':freeze['scope'],'frozenCheckpoint':True,'freezeBoundary':freeze,'laterRoutingWorkRequiresNewSavedDirectory':True,'primaryCandidate':current,'latestSourceVerifiedCheckpoint':current,'literalPourCoverageAggregate':pours,'newPdnLocalContactProof':contact,'reviewedFourLayerPlot':plot,'baseArchiveDependenciesInRestoreOrder':dependencies,'independentFallbacks':{'source257':bp['latestSourceVerifiedCheckpoint'],'olderFallbacks':bp['independentFallbacks'],'baseSavedDirectory':BASE.relative_to(ROOT).as_posix(),'independentNotInherited':True},**false}
 mf={**common,'solverSourceRoot':bm['solverSourceRoot'],'files':sorted(targets.values(),key=lambda r:r['restorePath']),'baseDependencyRestoreFiles':sorted(bases.values(),key=lambda r:r['restorePath']),'baseArchiveDependency':dep,'aliases':aliases,'immutableWorkspaceAssets':[],'immutableAssetsRestoredByBaseSource257Archive':copy.deepcopy(bm['immutableWorkspaceAssets'])}
 progress={**common,'latestClosedScopeIncluded':274,'closedExperiments':receipts,'profileSha256':args.profile_sha,'publicBaseRestoreDependencies':mf['baseDependencyRestoreFiles'],'aliases':aliases,'frozenSource257MetadataPins':BASE_PINS,'collectorSource':str(Path(__file__)),'collectorUsesOnlyOwnPythonStdlib':True,'sdkExecutedByCollector':False,'existingRestoreHelperExecutedByCollector':False,'archiveCreated':False,'commitCreated':False,'cloudDocumentEdited':False,'privateAuthorityAndContextBodiesExcluded':True,'source264QualificationNotInherited':True,'excludedLaterScopes':[275,276,277]}
 for n,d in inputs.items():need(metadata(Path(n))==d,'Collected source unchanged')
 for n,h in pinmap.items():need(digest(Path(n))==h,'Explicit profile pin unchanged before publication')
 need(digest(pp)==args.profile_sha,'Profile unchanged');verify_base();verify_prior();write_json(SAVED/'WORKSPACE_RESTORE_MANIFEST.json',mf)
 text=f'''Resume Source272 from latestSourceVerifiedCheckpoint in PROGRESS.json.
All49 numeric-owned DDR paths are connected. Original .635mm cohort-skew checks
PASS for Byte0 (.5771666935mm) and Byte1 (.5769421603mm). CA still FAILS:
17.4387009342mm skew, only9/26 above the unchanged20.95mm minimum,17 below.
All original49 endpoints, cohort limits and three .127 pair rules remain.

Candidate: {CANDIDATE}\nSHA256 {CANDIDATE_SHA}
Raw actual Core272: {RAW}\nSHA256 {RAW_SHA}
Controls: {CONTROLS}\nPlan269: {PLAN}\nCapture270: {CAPTURE}
Fresh Core272 passed35/35 and all49 numeric graphs. Native273 focused16 is
complete: all15 requested geometry checks returned0, with ONE CA bus-skew finding.
Other16 native checks were not rerun. Auth274 authenticated234 real vias, all
foreign via-track results clear with no ambiguous/unknown-owner exemptions.
Four exact batches plus the independent aggregate cover all16 current BREP pours,
234 vias and5097 routed signal-wire segments at .1016mm foreign edge margin.
Both new PDN local contacts passed on CURRENT272 polygons/full-new-land/held
annular witnesses. This is not full DDR reference continuity or own-net proof.

Root-rendered/reviewed PNG/SVG show four layers/all49 and both byte passes plus
the remaining CA failure. Timing/electrical readiness/TI/reference/CAD/default/
fabrication/all49 acceptance remain FALSE. Source264 and older Source257 results
are separate historical branches; no physical/pour/PDN pass is inherited.

Closed260–274 receipts/workers/inputs/logs are saved. Failed262 STEPparse and
failed271 OWNED_RSS_STOP remain failures. Core272's --smol guard bef1 and v3
runtime loader are exact public Sources. All later275/276/277 work is EXCLUDED.
FROZEN at274+current all16 pours/local PDN proof/reviewed plot; later work needs
a NEW saved folder. Root's tracked cloud report and all old folders are untouched.

Restore dependencies in order: Source209 -> Source228 -> Source248 -> Source257,
then this Source272 saved directory/archive. The immutable original OBJ and STEP
assets are already exact board-relative members of Source257; this delta does not
copy or rewrite them. Manifest files are regular /tmp restore targets compatible
with scripts/restore-g350-four-layer-routing-workspace.py --saved-directory
.cloud-tools/ddr-four-layer-post259-v2-2026-10-16. --restore refuses differing local
bytes/modes. V2 obtains solverSourceRoot from the exact pinned Source257 base
manifest; the first frozen post259 snapshot/archive remains unchanged.
Collector never executes that supplied helper, SDK, archive or git.
'''
 with (SAVED/'README.md').open('x') as f:f.write(text);os.fchmod(f.fileno(),0o600)
 progress['artifacts']=[{'path':q.name,**metadata(q)} for q in sorted(SAVED.iterdir()) if regular(q) and q.name not in META-{'README.md'}];write_json(SAVED/'PROGRESS.json',progress)
 rows=[{'path':q.name,**metadata(q)} for q in sorted(SAVED.iterdir()) if regular(q) and q.name!='WORKSPACE_HASH_INDEX.json'];write_json(SAVED/'WORKSPACE_HASH_INDEX.json',{'scope':freeze['scope'],'updatedAt':now,'files':rows,'selfExcluded':True,'frozenCheckpoint':True,**false});verify_rows(SAVED,rows)
 for row in mf['files']:need(metadata(SAVED/row['savedPath'])==metadata(Path(row['restorePath']))=={k:row[k] for k in ('bytes','sha256','mode')},'Saved/restoration byte and mode identity')
 verify_base();verify_prior();print(json.dumps({'savedDirectory':str(SAVED),'fileCount':len(rows)+1,'indexRows':len(rows),'restoreTargets':len(targets),'baseRestoreDependencies':len(bases),'metadataSha256':{n:digest(SAVED/n) for n in sorted(META)},'sdkExecuted':False,'all49Accepted':False,'fabricationReady':False},indent=2))
if __name__=='__main__':main()
