"""Finite stdlib future29 actual-artifact contract. No SDK/CAD imports.
The Root fills actual prerequisite hashes only after authentic collected0.
"""
import hashlib,json,math,re,stat
from pathlib import Path
BOARD=Path('/workspace/g350-linux-handheld');HERE=Path(__file__).parent
SOURCE_SHA='6cffcee4868f6fa81c48c4a105b594256ef4e53af057d4866d42407d797f7b4e';NATIVE_SOURCE_SHA=API_SOURCE_SHA='a46216424013c6ef588b210c6c7d631458e26f7cef16f5e16a5abec2e084fdc7';SIGNAL_PROPOSAL=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-source32-intermediate20-21-ca45-es2020-own-property-source-stages-sourceonly-next/source32-proposal.json');SIGNAL_SHA='988491449fe1ed02ca09a62d2b6ecd40cf82f6e569f1a7916d546e81a7e17ac8'
RAW=CONTROLS=RAW_SHA=CONTROLS_SHA=ACTUAL_NATIVE_COLLECTION=ACTUAL_NATIVE_REPORT=ACTUAL_API_COLLECTION=ACTUAL_API=None
STATE=None
ACTUAL_API_BATCH_COLLECTION=ACTUAL_NATIVE_COLLECTION_PIN=ACTUAL_NATIVE_REPORT_PIN=None;ACTUAL_CORE_BATCH_COLLECTION={'path': '/workspace/bus-lanes-solver/.cache/root-routing-progress/source32-three-stage-95645-PASS-COLLECTED-root.json', 'sha256': 'a6ee3d2308288697fe7452034139ee8f6e6dcdf7d18802b6d2227dcc6ff5e900', 'bytes': 55824, 'mode': 384}
API_BATCH_SCOPE=API_GUARD_SHA=API_TOOL_SESSION_ID=API_OWNED_GROUP_IDS=None
CORE_BATCH_SCOPE='ROOT_SOURCE32_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH66_AUTHENTIC_PRIOR_CLOSURES';CORE_TOOL_SESSION_ID=95645;CORE_OWNED_GROUP_IDS=[522128, 522142, 522184]
def require(v,label):
 if not v:raise ValueError(label)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def regular(p):
 p=Path(p);require(p.is_absolute()and p.is_file()and not p.is_symlink(),'Absolute regular artifact');return p
def load(row):
 require(isinstance(row,dict)and isinstance(row.get('path'),str)and isinstance(row.get('sha256'),str)and re.fullmatch('[0-9a-f]{64}',row['sha256']),'Concrete actual binding, no placeholder')
 p=regular(row['path']);require(p.stat().st_size<=32*1024*1024 and sha(p)==row['sha256'],'Exact finite actual artifact');return json.loads(p.read_bytes())
def binding(row):
 p=regular(row['path']);require(p.stat().st_size==row['bytes']and stat.S_IMODE(p.stat().st_mode)==row['mode']and sha(p)==row['sha256'],'Exact Source binding')
def one(rows,label):
 require(len(rows)==1,label+'; matches='+str(len(rows)));return rows[0]
def near(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])<1e-8
def index(raw,kind):
 rows=[r for r in raw if r['type']==kind];out={r[kind+'_id']:r for r in rows};require(len(rows)==len(out),'Unique actual '+kind);return out
def collected(row):
 c=load(row);require(c.get('authorizedByRoot')is True and c.get('toolSessionCollected')is True and c.get('passed')is True and c.get('toolExitCode')==c.get('toolWrapperExitCode')==0 and isinstance(c.get('toolSessionId'),int),'Actual successful collected Root natural0')
 post=load({'path':c['postauditPath'],'sha256':c['postauditSha256']});e=post['execution'];require(c['execution']==e and e['exitCode']==0 and e['diagnosticStopped']is False and e['cleanupOwnedGroupEmpty']is True and not any(e['oomDelta'].values()),'Actual natural child0/closed/OOM0')
 require(c['sourceAndDependenciesHeld']is True and post['sourceAndDependenciesHeld']is True and post['passed']is True,'Source/SDK held0')
 for prefix,digest in [('dependencies','ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'),('solverDependencies','47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6')]:require(post[prefix+'Before']==post[prefix+'After']and post[prefix+'After']['treeSha256']==digest,'Complete ce3/476 held')
 require(any(k in post for k in ('accepted49','all49Accepted'))and all(post[k]is False for k in ('accepted49','all49Accepted')if k in post)and post['fabricationReady']is False,'Partial acceptance remains explicit')
 if API_BATCH_SCOPE is not None and post.get('scope')==API_BATCH_SCOPE:
  pe=post['projectionExecution'];require(post['apiExecution']==e and pe['exitCode']==0 and pe['cleanupOwnedGroupEmpty']is True and pe['diagnosticStopped']is False and not pe['stopReasons']and not any(pe['oomDelta'].values()),'Actual serial projection child0/closed/OOM0')
  require(post['projectionOwnedChildWaitReturned']is post['projectionOwnedGroupEmptyActuallyObserved']is post['apiOwnedGroupEmptyActuallyObserved']is post['bothOwnedGroupsIndependentlyObservedEmpty']is post['projectionBeforeApiSeriallyEnforced']is True and pe['pgid']!=e['pgid']and pe['endedAt']<=e['startedAt'],'Both distinct owned children closed serially')
 return c,post
def produced(post,row):
 key='outputFiles';require(isinstance(post.get(key),list),'Current actual Core/Native/API outputFiles schema')
 require(any(r['path']==row['path']and r['sha256']==row['sha256']for r in post[key]),'Actual collected output required');return load(row)
def authority(row,manifest_sha,scope):
 global STATE,RAW,CONTROLS,RAW_SHA,CONTROLS_SHA,ACTUAL_NATIVE_COLLECTION,ACTUAL_NATIVE_REPORT,ACTUAL_API_COLLECTION,ACTUAL_API
 require(all(isinstance(v,str)and re.fullmatch('[0-9a-f]{64}',v)for v in [SOURCE_SHA,NATIVE_SOURCE_SHA,API_SOURCE_SHA,SIGNAL_SHA]),'Future authentic Source32 source/proposal/Native/API bindings remain null')
 require(isinstance(SIGNAL_PROPOSAL,Path)and SIGNAL_PROPOSAL.is_absolute()and isinstance(ACTUAL_CORE_BATCH_COLLECTION,dict)and isinstance(CORE_BATCH_SCOPE,str)and type(CORE_TOOL_SESSION_ID)is int and CORE_TOOL_SESSION_ID>0 and isinstance(CORE_OWNED_GROUP_IDS,list)and len(CORE_OWNED_GROUP_IDS)==len(set(CORE_OWNED_GROUP_IDS))==3 and all(type(p)is int and p>1 for p in CORE_OWNED_GROUP_IDS),'Future actual Core batch identity remains null; bind only genuine collected schema')
 require(isinstance(API_BATCH_SCOPE,str),'Future actual projection/API scope remains null')
 a=load(row);require(a.get('authorizedByRoot')is True and a.get('scope')==scope and a.get('sourceManifestSha256')==manifest_sha and a.get('actualPreviousScopesCollectedAndEmpty')is True and a.get('noConcurrentRootWorker')is True and a.get('rootFullWorkerReadPassed')is True,'Fresh Root serial/full-read authority')
 require(isinstance(NATIVE_SOURCE_SHA,str)and re.fullmatch('[0-9a-f]{64}',NATIVE_SOURCE_SHA)and isinstance(API_SOURCE_SHA,str)and re.fullmatch('[0-9a-f]{64}',API_SOURCE_SHA),'Future Native/API source pins remain unbound')
 require(isinstance(ACTUAL_NATIVE_COLLECTION_PIN,dict)and isinstance(ACTUAL_NATIVE_REPORT_PIN,dict)and isinstance(ACTUAL_API_BATCH_COLLECTION,dict)and isinstance(API_GUARD_SHA,str)and re.fullmatch('[0-9a-f]{64}',API_GUARD_SHA)and type(API_TOOL_SESSION_ID)is int and API_TOOL_SESSION_ID>0 and isinstance(API_OWNED_GROUP_IDS,list)and len(API_OWNED_GROUP_IDS)==len(set(API_OWNED_GROUP_IDS))==2 and all(type(p)is int and p>1 for p in API_OWNED_GROUP_IDS),'Future authentic Native and projection/API identities remain unbound')
 require(a['actualNativeCollection']==ACTUAL_NATIVE_COLLECTION_PIN and a['actualNativeReport']==ACTUAL_NATIVE_REPORT_PIN and a['actualApiCollection']==ACTUAL_API_BATCH_COLLECTION,'Exact genuine future Native/API collection/report pins required')
 require(a['genuineSourceManifestSha256']==SOURCE_SHA and a['actualNativeSourceManifestSha256']==NATIVE_SOURCE_SHA and a['actualApiSourceManifestSha256']==API_SOURCE_SHA,'Exact fresh32 Source and reviewed separate Native/API source')
 for key in ['actualCoreCollection','actualCoreRaw','actualCoreControls','actualNativeCollection','actualNativeReport','actualApiCollection','actualOriginalApiReport','actualFresh49Model','actualFresh49ProjectionProof']:load(a[key])
 STATE=a;RAW=Path(a['actualCoreRaw']['path']);RAW_SHA=a['actualCoreRaw']['sha256'];CONTROLS=Path(a['actualCoreControls']['path']);CONTROLS_SHA=a['actualCoreControls']['sha256'];ACTUAL_NATIVE_COLLECTION=a['actualNativeCollection'];ACTUAL_NATIVE_REPORT=a['actualNativeReport'];ACTUAL_API_COLLECTION=a['actualApiCollection'];ACTUAL_API=a['actualOriginalApiReport'];return a
def core_batch_source32():
 # Future authentic Core batch is a collected batch with three per-phase POSTs; never invent execution.
 c=load(STATE['actualCoreCollection'])
 require({k:STATE['actualCoreCollection'][k]for k in ('path','sha256')}=={k:ACTUAL_CORE_BATCH_COLLECTION[k]for k in ('path','sha256')},'Exact genuine future actual Core batch collected batch')
 require(c['authorizedByRoot']is c['toolSessionCollected']is c['passed']is True and c['toolSessionId']==CORE_TOOL_SESSION_ID and c['toolExitCode']==c['toolWrapperExitCode']==0,'Future authentic Core batch Root collection natural0')
 post=load({'path':c['postauditPath'],'sha256':c['postauditSha256']})
 require(c['sourceManifestSha256']==post['sourceManifestSha256']==SOURCE_SHA and c['phase']==post['phase']=='capture-types-core-batch'and c['scope']==post['scope']==CORE_BATCH_SCOPE,'Future authentic Core batch Source32 batch scope')
 require(c['phases']==post['phases']and c['orderedPhaseNames']==post['orderedPhaseNames']==['capture','types','core']and c['expectedPhaseNames']==post['expectedPhaseNames']==['capture','types','core']and c['notAttemptedPhaseNames']==post['notAttemptedPhaseNames']==[],'All three attempted in exact order')
 for obj in (c,post):
  require(all(obj[k]is True for k in ['historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','allThreeChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passedMeansCaptureStrictTypesAndRawCore32Only','batchScopeContainsThreeSerialOwnedChildren']),'Future authentic Core batch complete held serial batch')
  require(obj['batchFailure']is obj['finalVerificationFailure']is None and obj['CoreCalls']==obj['CoreChildInvocations']==obj['captureChildInvocations']==obj['typesChildInvocations']==1,'One real Core invocation and each prerequisite child')
  require(all(obj[k]==0 for k in ['nativeCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'])and all(obj[k]is False for k in ['Source32Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady']),'Batch only, all broader qualification withheld')
  for prefix,digest in [('dependencies','ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'),('solverDependencies','47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6')]:require(obj[prefix+'Before']==obj[prefix+'After']and obj[prefix+'After']['treeSha256']==digest,'Future authentic Core batch full SDK holdings')
 require(c['independentlyObservedAllOwnedGroupsEmpty']is c['independentlyObservedGuardAbsent']is True and c['independentProcReadErrors']==[]and c['independentlyObservedOwnedGroupMembers']=={str(p):[]for p in CORE_OWNED_GROUP_IDS},'Root future actual Core batch independent closure observations')
 phases=post['phases'];require(len(phases)==3 and len({r['execution']['pgid']for r in phases})==3,'Three distinct owned children')
 prior_end=None
 for number,phase in enumerate(phases):
  require(phase['phase']==['capture','types','core'][number]and all(phase[k]is True for k in ['passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0']),'Future authentic Core batch per-phase success and owned closure')
  require(all(phase[k]is None for k in ['runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure']),'No phase failure')
  actual_post=load({'path':phase['postauditPath'],'sha256':phase['postauditSha256']});require(actual_post=={k:v for k,v in phase.items()if k not in ('postauditPath','postauditSha256')},'Every actual separate phase POST matches its final batch row')
  e=phase['execution'];require(e['exitCode']==0 and e['diagnosticStopped']is False and e['stopReasons']==[]and e['cleanupOwnedGroupEmpty']is True and not any(e['oomDelta'].values())and e['signalErrors']==[],'Every child natural0/no resource stop/OOM0/groupempty')
  require(e['command']==phase['command']and e['pgid']==e['pid']==CORE_OWNED_GROUP_IDS[number]and (prior_end is None or prior_end<=e['startedAt']),'Genuine exact commands and serial lifetimes');prior_end=e['endedAt']
  require(phase['guardIdentityBefore']==phase['guardIdentityAfter']==post['sameGuardIdentity']and e['currentGuardPid']==post['sameGuardIdentity']['pid'],'Same authenticated guard across all three children')
  require(phase['CoreCalls']==phase['CoreChildInvocations']==(1 if number==2 else 0)and all(phase[k]==0 for k in ['nativeCalls','originalApiCalls','cliCalls','cadCalls']),'Uppercase per-phase CoreCalls accounting')
  before=phase['phaseSnapshotsBefore'];after=phase['phaseSnapshotsAfter'];require(before==after and after['board']['treeSha256']=='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'and after['solver']['treeSha256']=='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6','Each phase SDK holdings exact')
 capture,types,core=phases
 require(capture['result']['fullSourceInversePassed']is True and capture['result']['CoreExecuted']is False and types['result']['strictNoEmitTypecheckNatural0']is True and types['result']['actualPriorCapturePin']==capture['result']['sourceCapturePin'],'Genuine capture inverse and strict types precede Core')
 for key in ['sourceCapturePin','sourceDiagnosticPin']:produced(capture,capture['result'][key])
 require(core['CoreCalls']==1 and core['result']['all29CorePredicatesPassed']is True and core['result']['actualCandidateCarrierCount']==32 and core['result']['nativeQualificationPerformed']is False,'Future authentic Core batch32 carriers and29 predicates only')
 require(core['result']['rawCorePin']==STATE['actualCoreRaw']and core['result']['coreControlsPin']==STATE['actualCoreControls'],'Exact future actual Core batch produced Core/control bindings')
 return c,post,core

def api_batch_source32():
 # Real future actual projection/API batch is a two-child batch; neither a top-level execution nor outputFiles is invented.
 require(STATE is not None,'Actual Root bindings required first')
 require(STATE['actualApiCollection']==ACTUAL_API_BATCH_COLLECTION,'Exact genuine future actual projection/API batch Root collection')
 c=load(ACTUAL_API_BATCH_COLLECTION);post=load({'path':c['postauditPath'],'sha256':c['postauditSha256']})
 require(c['authorizedByRoot']is c['toolSessionCollected']is c['passed']is True and c['toolSessionId']==API_TOOL_SESSION_ID and c['toolExitCode']==c['toolWrapperExitCode']==0,'Future authentic projection/API batch Root collection natural0')
 require(c['phases']==post['phases']and c['projectionExecution']==post['projectionExecution']and c['apiExecution']==post['apiExecution'],'Future authentic projection/API batch phase rows and execution aliases exact')
 for obj in (c,post):
  require(obj['scope']==API_BATCH_SCOPE and obj['phase']=='projection-api-batch'and obj['sourceManifestSha256']==API_SOURCE_SHA and obj['coreSourceManifestSha256']==SOURCE_SHA and obj['rootGuardProposalManifestSha256']==API_GUARD_SHA,'Future authentic projection/API batch exact Source/API/guard scope')
  require(obj['orderedPhaseNames']==obj['expectedPhaseNames']==['projection','api']and obj['notAttemptedPhaseNames']==[]and len(obj['phases'])==2,'Exactly two real phases')
  require('execution'not in obj and 'outputFiles'not in obj and 'packetSha256'not in obj,'Do not synthesize standalone API receipt shape')
  require(all(obj[k]is True for k in ['guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','bothChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','projectionPassed','apiPassed','projectionBeforeApiSeriallyEnforced','passedMeansFresh49ProjectionAndOriginalLoaded32Api151Plus2JointOnly','hardwareAcceptanceCheckpointUnchanged']),'Future authentic projection/API batch complete serial held success')
  require(obj['batchFailure']is obj['finalVerificationFailure']is None and obj['originalApiBooleanPredicates']==151 and obj['additionalJointNetAggregates']==2 and obj['mixedWholeNetJointAggregatesPassed']is True and obj['originalApiCalls']is None and obj['originalApiMethodInvocationCountNotInstrumented']is True,'Actual151 original plus2joint aggregate predicates, method count not invented')
  require(all(obj[k]==0 for k in ['CoreCalls','nativeCalls','cliCalls','cadCalls','newRoutesAdopted'])and all(obj[k]is False for k in ['Source32Accepted','all49Accepted','accepted49','referenceQualified','electricalTimingPassed','fabricationReady']),'No broader adoption or application calls')
  require(obj['actualCorePath']==str(RAW)and obj['actualCoreSha256']==RAW_SHA and obj['actualNativeReport']==ACTUAL_NATIVE_REPORT and obj['actualFresh49Model']==STATE['actualFresh49Model']and obj['actualFresh49ProjectionProof']==STATE['actualFresh49ProjectionProof'],'Exact current29 data provenance')
  for prefix,digest in [('dependencies','ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'),('solverDependencies','47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6')]:require(obj[prefix+'Before']==obj[prefix+'After']and obj[prefix+'After']['treeSha256']==digest,'Future authentic projection/API batch full SDK holdings')
 require(c['independentlyObservedAllOwnedGroupsEmpty']is c['independentlyObservedGuardAbsent']is True and c['independentProcReadErrors']==[]and c['independentlyObservedOwnedGroupMembers']=={str(p):[]for p in API_OWNED_GROUP_IDS},'Root future actual projection/API batch independent closure observations')
 phases=post['phases'];require([r['execution']['pgid']for r in phases]==API_OWNED_GROUP_IDS,'Two authentic owned groups')
 prior_end=None
 for number,phase in enumerate(phases):
  require(phase['phase']==['projection','api'][number]and all(phase[k]is True for k in ['passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0']),'Every future actual projection/API batch child passed and closed')
  require(all(phase[k]is None for k in ['runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure']),'No future actual projection/API batch phase failure')
  require(load({'path':phase['postauditPath'],'sha256':phase['postauditSha256']})=={k:v for k,v in phase.items()if k not in ('postauditPath','postauditSha256')},'Separate actual phase POST exactly matches batch row')
  e=phase['execution'];require(e==post[['projectionExecution','apiExecution'][number]]and e['exitCode']==0 and e['diagnosticStopped']is False and e['stopReasons']==[]and e['cleanupOwnedGroupEmpty']is True and not any(e['oomDelta'].values())and e['signalErrors']==[],'Natural0/OOM0/no stop/ownedempty')
  require(e['command']==phase['command']and e['pid']==e['pgid']and(prior_end is None or prior_end<=e['startedAt']),'Exact commands and serialized lifetimes');prior_end=e['endedAt']
  require(e['policy']=={'wallSeconds':[60,90][number],'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5},'Original bounded phase policies')
  require(phase['guardIdentityBefore']==phase['guardIdentityAfter']==post['sameGuardIdentity']and e['currentGuardPid']==post['sameGuardIdentity']['pid'],'One held actual Root guard')
  require(phase['phaseSnapshotsBefore']==phase['phaseSnapshotsAfter']and phase['phaseSnapshotsAfter']['board']['treeSha256']=='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'and phase['phaseSnapshotsAfter']['solver']['treeSha256']=='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6','Each phase full SDK held')
  require(all(phase[k]==0 for k in ['CoreCalls','nativeCalls','cliCalls','cadCalls']),'No Core/Native/CLI/CAD inside future actual projection/API batch')
 projection,api=phases
 require(projection['result']['actualFresh49Model']==STATE['actualFresh49Model']and projection['result']['actualFresh49ProjectionProof']==STATE['actualFresh49ProjectionProof']and projection['result']['source32FreshFull49ProjectionPassed']is projection['result']['zeroSelected32CarrierBodiesSeeded']is True,'Actual unseeded fresh29 model and proof')
 require([projection['result'][k]for k in ['actual49Requests','actualFixedTraces','actualHardObstacles','actualSignalViaEvents']]==[49,263,1298,98],'Original full49 current material')
 for key in ['actualFresh49Model','actualFresh49ProjectionProof']:produced(projection,STATE[key])
 require(api['result']['actualOriginalApiReportPin']==ACTUAL_API and api['result']['originalApiLoaded32ChecksPassed']is api['result']['bothDqs1CoupledViewsPassed']is True and api['result']['originalApiBooleanPredicates']==151 and api['result']['additionalJointNetAggregates']==2 and api['result']['mixedWholeNetJointAggregatesPassed']is True and api['result']['apiMethodInvocationCount']is None and api['result']['methodCountNotInstrumented']is True,'Actual151 original plus2joint API predicates and both real DQS1 views')
 require(api['result']['loadedCohortsExplicitlyPartial']=={'DDR_BYTE0':6,'DDR_BYTE1':11,'DDR_COMMAND_CLOCK':14},'Partial original cohorts remain explicit')
 require(c['actualOriginalApiReportPin']==ACTUAL_API and c['actualApiPacketPin']==api['packetPin'],'Root collector binds actual API report and packet metadata')
 return c,post,api

def actual_core():
 require(STATE is not None,'Actual Root bindings required first');c,post,core=core_batch_source32();require(c['CoreCalls']==core['CoreCalls']==1,'Actual uppercase CoreCalls==1 for genuine current Core child')
 raw=produced(core,STATE['actualCoreRaw']);controls=produced(core,STATE['actualCoreControls']);require(controls['rawCorePath']==str(RAW)and controls['rawCoreSha256']==RAW_SHA and controls['freshCoreControlPassed']is True and len(controls['checks'])==29 and all(c['passed']is True for c in controls['checks']),'Actual all29 fresh Core controls')
 require(controls['sourceNumericAndPhysicalIdsDerivedWithoutAssignment']is True and controls['circuitJsonGeometryEdited']is False and controls['automaticCoreSrjForThisForkMustNotBeUsed']is True and controls['expectedOriginalCarrierCount']==32 and controls['expectedMissingOriginalSignalCount']==17,'Genuine32/manual fork/17 missing')
 return raw,controls
def native_outputs():
 # Native18 and API151+2joint are separate actual Root scopes; never force them to share a packetsha.
 nc,np=collected(ACTUAL_NATIVE_COLLECTION);report=produced(np,ACTUAL_NATIVE_REPORT)
 ac,ap,api_phase=api_batch_source32();api=produced(api_phase,ACTUAL_API)
 require(nc['sourceManifestSha256']==np['sourceManifestSha256']==report['sourceManifestSha256']==NATIVE_SOURCE_SHA,'Actual reviewed Native32 source')
 require(ac['sourceManifestSha256']==ap['sourceManifestSha256']==API_SOURCE_SHA,'Actual reviewed API32 source')
 require(nc['packetSha256']==np['packetSha256']==report['packetSha256'] and api_phase['packetPin']['sha256']==api['packetSha256'],'Each report belongs to its own authentic collected packet')
 require(report['actualCoreSha256']==api['actualCoreSha256']==RAW_SHA and report['actualCoreControlsSha256']==CONTROLS_SHA,'Same actual fresh29 raw/control hashes')
 require(report['coreSourceManifestSha256']==SOURCE_SHA and report['originalSource32ProposalSha256']==SIGNAL_SHA,'Native32 exact original declaration and source closure')
 require(api['actualNativeReportPath']==ACTUAL_NATIVE_REPORT['path'] and api['actualNativeReportSha256']==ACTUAL_NATIVE_REPORT['sha256'],'API binds actual prior Native report')
 require(api['original49Input']=={k:STATE['actualFresh49Model'][k]for k in ('path','sha256')} and api['fresh49ProjectionProof']['path']==STATE['actualFresh49ProjectionProof']['path'] and api['fresh49ProjectionProof']['sha256']==STATE['actualFresh49ProjectionProof']['sha256'],'Fresh49 model/projection bindings')
 projection=load(STATE['actualFresh49ProjectionProof']);require(projection['actualCoreSha256']==RAW_SHA and projection['actualNativeReportSha256']==ACTUAL_NATIVE_REPORT['sha256'] and projection['constructorInputSha256']==STATE['actualFresh49Model']['sha256'],'Fresh49 derived from this actual29 Core and Native')
 require(projection['sourceManifestSha256']==SOURCE_SHA and projection['originalSource32ProposalSha256']==SIGNAL_SHA and projection['exactFullInverseToFresh32Parent']is True and projection['raw229BarrelsExplicitlyPartitioned']is projection['unseededFixed227BarrelsRepresentedExactlyOnce']is True and len(projection['removedIntermediateCarrierViaIds2'])==2 and projection['intermediateViasNeverSerializedAsFixedFanouts']is True,'Exact same Source32 fresh49 inverse and two removable carrier-via provenance')
 require(report['checkCount']==len(report['counts'])==18 and not any(report['counts'].values())and report['physicalErrors']==0 and report['actualNativePairFindings']==[]and report['physicalCpuRamConnectedCarrierCount']==32,'Native18/all3pair findings0/32 graphs')
 require(api['allOriginalApiLoaded32ChecksPassed']is True and api['exactMaterialHeld']is True and api['actualCompleteOriginalSignalCount']==32 and api['expectedMissingOriginalSignalCount']==17,'All actual original API predicates passed on29')
 require(api['fullOriginalBusRostersAndConstraintsHeld']is True and api['originalFullDifferentialPairArrayUnchanged']is True and api['originalPrivateContinuousApiImplementationsUnchanged']is True,'All original49 rules held')
 for key in ['shared','exterior','coupling','pairLengths']:require(len(api[key])==3 and all(r['matched']is True for r in api[key]),'All3 original '+key+' predicates')
 require(set(projection['removedIntermediateCarrierViaIds2'])=={m['actualViaId']for m in report['actualOwnershipProof']['intermediateCarrierMappings']},'Exactly both genuine Native-proved removable carrier barrels excluded from unseeded49')
 model=load(STATE['actualFresh49Model']);proof=report['actualOwnershipProof'];signal_ids={m['actualViaId']for m in proof['signalMappings']};middle_ids={m['actualViaId']for m in proof['intermediateCarrierMappings']};stub_ids={m['actualPcbTraceId']for m in proof['signalMappings']}
 require(len(model['connections'])==49 and len(model['traces'])==263 and len(model['obstacles'])==1298 and model['layerCount']==4,'Full unseeded49 current fixed material retained')
 stubs=[t for t in model['traces']if t['pcb_trace_id']in stub_ids];events=[p for t in model['traces']for p in t['route']if p['route_type']=='via']
 require(len(stubs)==98 and sum(len(t['route'])for t in stubs)==414 and [sum(len(t['route'])==n for t in stubs)for n in [4,6,13,15]]==[95,1,1,1],'Exact414 serialized endpoint-stub primitives,95ordinary plus CPU3/RAM14/RAM7 special stubs')
 require(len(events)==98 and {p['pcb_via_id']for p in events}==signal_ids and all(p['layers']==['top','inner1','inner2','bottom']and p['from_layer']=='top'and p['to_layer']=='bottom'and p['via_diameter']==.4572 and p['via_hole_diameter']==.254 for p in events),'Exactly98 authentic fullspan original endpoint events')
 require(not any(o.get('circuitJsonMetadata',{}).get('pcb_via_id')in middle_ids for o in model['obstacles'])and not middle_ids&{p['pcb_via_id']for p in events},'Neither new carrier barrel is seeded as a fixed fanout/obstacle')
 inverse=load(projection['removableCarrierGeometryInverse']);body_ids={pid for c in proof['carriers']for pid in(c['actualCarrierPcbTraceIds']if c.get('carrierArchitecture')=='TWO_LAYER_ONE_OWNED_INTERMEDIATE_VIA'else[c['actualCarrierPcbTraceId']])}
 require(len(body_ids)==34 and set(inverse['excludedBodyPcbTraceIds'])==body_ids and {v['pcb_via_id']for v in inverse['excludedIntermediateViaRows2']}==middle_ids and len(inverse['removedRawRows52'])==52 and inverse['exactFullRawRowInverseProved']is inverse['exactRaw1398ObstacleInverseProved']is inverse['exactRaw509ComponentInverseProved']is True,'Exact34body/two-via removable geometry and52row full inverse bound to this Native ownership')

 require(len(api['continuity'])==32 and all(r['pathVisible']and r['selfClear']and r['conventionalAngles']and r['segmentsVisible']and all(r['segmentsVisible'])for r in api['continuity']),'All32 continuous/self/angle predicates')
 second=api['secondaryDqs1View'];require(second['name']=='early_reflected_meander'and second['geometryAndEndpointsUnchanged']is True and second['passed']is True,'Both real DQS1 shared meanders checked')
 for key in ['shared','exterior','coupling']:require(len(second[key])==1 and all(r['matched']is True for r in second[key]),'Second actual DQS1 '+key)
 inventory=api['checkInventory'];require(inventory['actualWireRunRows']==34 and inventory['perNetSummaries']==32 and inventory['runBooleanPredicates']==136 and inventory['originalPairBooleanPredicates']==12 and inventory['secondaryDqs1BooleanPredicates']==3 and inventory['allOriginalApiBooleanPredicates']==151 and inventory['additionalJointNetAggregates']==2 and inventory['originalApiPlusJointAggregateGates']==153,'151 original per-run/pair/DQS1 predicates plus two separate mandatory mixed-net gates')
 require(api['bodyOnlyTraceViewCount']==32 and api['actualPhysicalWireRunCount']==34 and api['analysisMixedRoutesNotGenericRouterInputs']is True and api['fullTiClassOrElectricalQualificationClaimed']is False,'Body-only mixed length projections and actual layer-continuous runs only')
 require(len(api['runContinuity'])==34 and all(r['pathVisible']and r['selfClear']and r['conventionalAngles']and r['segmentsVisible']and all(r['segmentsVisible'])and r['foreignAll34WireRunsAndBothFullspanViasIncluded']for r in api['runContinuity']),'All34 genuine wire-run original API checks')
 joint=api['jointNetChecks'];require([r['connectionName']for r in joint]==['source_trace_20','source_trace_21']and all(r['passed']and r['originalMergedSelfClear2032']and r['strict3WNonlocalTopSelf']['passed']and r['mergedRamJunctionConventionalAngles']and r['disconnectedCpuTopStubClear']and r['ownedBarrelContactsBounded']and len(r['ownBarrelContactRows'])==12 and all(q['passed']for q in r['ownBarrelContactRows'])for r in joint),'Both mandatory mixed whole-net/junction/self/contact aggregates')
 coverage=api['fullSpanViaCoverage'];require([r['originalSourceTraceId']for r in coverage]==['source_trace_20','source_trace_21']and all(r['allFourLayersIncluded']and r['physicalLayers']==['top','inner1','inner2','bottom']and r['physicalFromLayer']=='top'and r['physicalToLayer']=='bottom'and r['capsuleCount']==4 and r['radiusMm']==.2286 for r in coverage),'Both actual removable vias restored on all4 physical layers in API foreign scenes')
 require(len(api['loadedCohortBusReports'])==3 and all(r['aboveMinimumLength']and r['withinLengthLimit']and r['matched']for r in api['loadedCohortBusReports']),'All original loaded-cohort bounds')
 for obj in [report,api]:require(obj['accepted49']is False and obj['fabricationReady']is False and obj['referenceQualified']is False,'No broader qualification')
 return report,np
def derive_owned(raw,controls,proposal):
 report,_=native_outputs();proof=report['actualOwnershipProof'];kinds=['pcb_via','pcb_trace','pcb_port','source_port','pcb_component','source_component','source_trace','source_manually_placed_via'];ix={k:index(raw,k)for k in kinds}
 require([len(ix[k])for k in ['pcb_via','pcb_trace','pcb_component','source_component','pcb_port']]==[229,297,509,280,1671],'Exact fresh229/297/509/280/1671')
 signals=proof['signalMappings'];carriers=proof['carriers'];require(len(signals)==98 and len(carriers)==32 and len(proof['referenceMappings'])==165,'Native authentic98/32/165 proofs')
 require(len({s['actualViaId']for s in signals})==98 and len({s['actualPcbTraceId']for s in signals})==98,'Unique actual signal barrels/stubs')
 for s in signals:
  owner=one([o for o in proposal['all98NumericOwnedSignalBranches']if o['viaName']==s['sourceViaName']],'Actual Source named via branch')
  numeric=ix['pcb_port'][s['actualNumericPcbPortId']];sp=ix['source_port'][numeric['source_port_id']];part=ix['source_component'][sp['source_component_id']]
  require(part['name']+'.pin'+str(sp['pin_number'])==owner['numericSelector']and near(numeric,owner['padXY']),'Real numeric package/pad')
  via=ix['pcb_via'][s['actualViaId']];top=ix['pcb_port'][s['actualTopPcbPortId']];trace=ix['pcb_trace'][s['actualPcbTraceId']]
  require(near(via,owner['viaXY'])and via['layers']==['top','inner1','inner2','bottom']and via['outer_diameter']==.4572 and via['hole_diameter']==.254 and via['from_layer']=='top'and via['to_layer']=='bottom','Real fullspan barrel')
  require(top['pcb_port_id']in via['pcb_port_ids']and top['layers']==['top']and near(top,via)and ix['source_port'][top['source_port_id']]['source_component_id']==s['sourceViaOwnerId'],'Actual same-owner alias')
  expected=owner['topStub'];wire=trace['route'];long=s['originalSourceTraceId']=='source_trace_14'and s['side']==1;moved_cpu3=s['originalSourceTraceId']=='source_trace_3'and s['side']==0;moved_ram7=s['originalSourceTraceId']=='source_trace_7'and s['side']==1
  require(len(expected)==(11 if long else 4 if moved_cpu3 else 13 if moved_ram7 else 2)and len(wire)==len(expected),'Only actual moved14 RAM has11 and moved3 CPU has4 wirepoints; moved7 RAM has13; other95 have2')
  same=lambda points:all(near(p,q)for p,q in zip(points,expected))
  require(trace['source_trace_id']==s['actualPhysicalSourceTraceId']and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in wire)and(same(wire)or same(wire[::-1]))and {wire[0].get('start_pcb_port_id'),wire[-1].get('end_pcb_port_id')}=={numeric['pcb_port_id'],top['pcb_port_id']},'Actual full Topstub polyline/numeric ownership/geometry')
 intermediates=proof['intermediateCarrierMappings'];require([m['originalSourceTraceId']for m in intermediates]==['source_trace_20','source_trace_21'],'Exact removable carrier-via roster only20/21')
 refs={m['actualViaId']for m in proof['referenceMappings']};ends={m['actualViaId']for m in signals};middle={m['actualViaId']for m in intermediates}
 require(len(refs)==129 and len(ends)==98 and len(middle)==2 and refs.isdisjoint(ends)and not middle&(refs|ends)and refs|ends|middle==set(ix['pcb_via']),'229 actual barrels:129reference+98original endpoints+2removable carriers')
 for c in carriers:
  ident=c['originalSourceTraceId'];paths=[t for t in ix['pcb_trace'].values()if t['source_trace_id']==ident]
  d=one([d for d in proposal['selected32OriginalCarriers']if d['originalSourceTraceId']==ident],'Original selected Source32 carrier')
  if ident in ['source_trace_20','source_trace_21']:
   require(c['carrierArchitecture']==d['carrierArchitecture']=='TWO_LAYER_ONE_OWNED_INTERMEDIATE_VIA'and c['carrierLayer']is None and len(paths)==4 and set(c['actualDirectPcbTraceIds'])=={t['pcb_trace_id']for t in paths},'Only exact20/21 have four actual Source-owned physical paths')
   m=one([m for m in intermediates if m['originalSourceTraceId']==ident],'One actual carrier-via proof');v=ix['pcb_via'][m['actualViaId']];vd=one([v for v in proposal['intermediateCarrierVias']if v['originalSourceTraceId']==ident],'Exact authored carrier-via declaration')
   require(m['role']=='REMOVABLE_INTERMEDIATE_CARRIER_VIA_NOT_FIXED_FANOUT'and m['fixedFanout']is False and m['physicalGraphProved']is True and near(v,vd['xy'])and v['layers']==['top','inner1','inner2','bottom']and v['from_layer']=='top'and v['to_layer']=='bottom'and v['outer_diameter']==.4572 and v['hole_diameter']==.254,'Genuine removable fullspan barrel, not fixed fanout')
   require(v.get('source_net_id')is None and v.get('source_trace_id')is None and v.get('pcb_trace_id')is None and set(v['pcb_port_ids'])==set(m['actualPcbPortIds'])and len(v['pcb_port_ids'])==3,'Unfabricated real carrier-via aliases')
   require(m['sourceViaName']==vd['viaName']and vd['role']==m['role']and v['tented_on_top']is v['tented_on_bottom']is True,'Exact named authored physical intermediate-via definition')
   owner=ix['source_manually_placed_via'][m['actualSourceViaOwner']];placeholder=ix['pcb_component'][m['actualPlaceholderPcbComponentId']]
   require(owner['source_manually_placed_via_id']==placeholder['source_component_id']and near(placeholder['center'],v)and placeholder['width']==placeholder['height']==.4572,'Authentic new via owner and placeholder geometry')
   aliases=[ix['pcb_port'][pid]for pid in m['actualPcbPortIds']]
   require({tuple(p['layers'])for p in aliases}=={('top',),('bottom',),('inner2',)}and {p['source_port_id']for p in aliases}==set(m['actualSourcePortIds'])and all(p['pcb_component_id']==placeholder['pcb_component_id']and near(p,v)and ix['source_port'][p['source_port_id']]['source_component_id']==owner['source_manually_placed_via_id']for p in aliases),'Exactly genuine Top/Bottom/Inner2 aliases bound only to the physical new owner')
   require(c['actualRemovableCarrierViaIds']==[v['pcb_via_id']]and len(c['actualCarrierPcbTraceIds'])==len(c['carrierPieces'])==len(d['carrierPieces'])==2,'Exactly two actual body pieces and one removable barrel')
   for i,(piece,target)in enumerate(zip(c['carrierPieces'],d['carrierPieces'])):
    body=ix['pcb_trace'][piece['actualPcbTraceId']];layer=['inner2','top'][i]
    require(body['source_trace_id']==ident and piece['actualPcbTraceId']==c['actualCarrierPcbTraceIds'][i]and piece['layer']==target['layer']==layer and len(body['route'])==len(target['expectedPath'])and all(p['route_type']=='wire'and p['layer']==layer and p['width']==.1016 and near(p,q)for p,q in zip(body['route'],target['expectedPath'])),'Exact actual layer-continuous owned body geometry')
    require(body['route'][0].get('start_pcb_port_id')==piece['actualStartPcbPortId']and body['route'][-1].get('end_pcb_port_id')==piece['actualEndPcbPortId'],'Actual layer-specific body endpoint IDs')
   local=[m for m in signals if m['originalSourceTraceId']==ident];require(len(local)==2 and {t['pcb_trace_id']for t in paths}=={m['actualPcbTraceId']for m in local}|set(c['actualCarrierPcbTraceIds']),'Exactly two original endpoint Topstubs plus two new bodies')
   cpu=one([m for m in local if m['side']==0],'True CPU endpoint');ram=one([m for m in local if m['side']==1],'True RAM endpoint');require(c['actualCpuViaId']==cpu['actualViaId']and c['actualRamViaId']==ram['actualViaId']and c['actualCpuNumericPcbPortId']==cpu['actualNumericPcbPortId']and c['actualRamNumericPcbPortId']==ram['actualNumericPcbPortId'],'Original numeric side identities remain exact')
   require(c['carrierPieces'][0]['actualStartPcbPortId']==c['actualCpuCarrierLayerPcbPortId']and c['carrierPieces'][0]['actualEndPcbPortId']==m['actualInner2PcbPortId']and c['carrierPieces'][1]['actualStartPcbPortId']==m['actualTopPcbPortId']and c['carrierPieces'][1]['actualEndPcbPortId']==c['actualRamCarrierLayerPcbPortId'],'Real CPU Inner2 -> carrier-via Inner2/Top -> RAM Top piece anchors')
   viaids=[c['actualCpuViaId'],v['pcb_via_id'],c['actualRamViaId']];require(len(set(viaids))==3 and {c['actualCpuViaId'],c['actualRamViaId']}=={m['actualViaId']for m in local},'Three genuine physical barrels including both held endpoints')
   graph={}
   def join(a,b):graph.setdefault(a,set()).add(b);graph.setdefault(b,set()).add(a)
   for t in paths:
    first,last=t['route'][0],t['route'][-1];a,b=first['start_pcb_port_id'],last['end_pcb_port_id']
    require(t['source_trace_id']==ident and all(p['route_type']=='wire'and p['width']==.1016 for p in t['route']),'Actual physical Source ownership and wire material')
    for p,pid in [(first,a),(last,b)]:require(near(p,ix['pcb_port'][pid])and p['layer']in ix['pcb_port'][pid]['layers'],'Genuine real layer port at each path end')
    join(a,b)
   for vid in viaids:
    via=ix['pcb_via'][vid];require(via['layers']==['top','inner1','inner2','bottom']and via['from_layer']=='top'and via['to_layer']=='bottom','All three real barrels remain fullspan')
    for pid in via['pcb_port_ids']:
     port=ix['pcb_port'][pid];require(near(port,via)and all(layer in via['layers']for layer in port['layers']),'Real barrel/alias physical span');join(pid,vid)
   seen={c['actualCpuNumericPcbPortId']};pending=list(seen)
   for node in pending:
    for nxt in graph.get(node,set()):
     if nxt not in seen:seen.add(nxt);pending.append(nxt)
   require(c['actualRamNumericPcbPortId']in seen and set(viaids)<=seen and all(node in seen for node in graph),'Whole numeric CPU-to-RAM four-path and all3barrel physical graph, not logical-only inference')
   require(c['actualSourceOwnedPhysicalGraph']['physicallyConnected']is True and c['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is True and c['physicalFullThroughBarrels']==3,'Native independently proved exact physical graph')
   whole=sum(math.hypot(b['x']-a['x'],b['y']-a['y'])for t in paths for a,b in zip(t['route'],t['route'][1:]));require(abs(whole-c['wholePlanarLengthMm'])<1e-8 and abs(whole-d['expectedWholePlanarMm'])<1e-8,'Actual all4-path planar length')
   continue
  require(len(paths)==3 and set(c['actualDirectPcbTraceIds'])=={t['pcb_trace_id']for t in paths},'Exactly3 actual Source-owned paths')
  body=ix['pcb_trace'][c['actualCarrierPcbTraceId']];require(c['carrierLayer']==d['carrierLayer']and len(body['route'])==len(d['expectedCarrierPath'])and all(p['route_type']=='wire'and p['layer']==c['carrierLayer']and p['width']==.1016 and near(p,q)for p,q in zip(body['route'],d['expectedCarrierPath'])),'Authentic complete carrier')
  require(body['route'][0].get('start_pcb_port_id')==c['actualCpuCarrierLayerPcbPortId']and body['route'][-1].get('end_pcb_port_id')==c['actualRamCarrierLayerPcbPortId'],'Genuine actual carrier endpoints')
  require(c['actualSourceOwnedPhysicalGraph']['physicallyConnected']is True and c['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is True,'Native proved real numeric physical graph')
  whole=sum(math.hypot(b['x']-a['x'],b['y']-a['y'])for t in paths for a,b in zip(t['route'],t['route'][1:]));require(abs(whole-c['wholePlanarLengthMm'])<1e-8 and abs(whole-d['expectedWholePlanarMm'])<1e-8,'Actual all3-path planar length')
 require(len({c['originalSourceTraceId']for c in carriers})==32,'32 distinct original signals')
 segments=sum(a['x']!=b['x']or a['y']!=b['y']for t in ix['pcb_trace'].values()for a,b in zip(t['route'],t['route'][1:]));require(segments==1116,'Exact Source32 current1116 nonzero segments');return ix,signals,carriers,segments
def native_prerequisite(authority,carriers):
 require(authority['actualNativeCollection']==ACTUAL_NATIVE_COLLECTION and authority['actualNativeReport']==ACTUAL_NATIVE_REPORT,'Same Root-bound Native prerequisite')
 report,post=native_outputs();require({c['originalSourceTraceId']for c in carriers}=={c['originalSourceTraceId']for c in report['actualOwnershipProof']['carriers']},'Same authentic29 proof');return report,post
