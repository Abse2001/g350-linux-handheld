 def closed55():
  prior=closed54();assert prior['actualClosedScopeCount']==54
  for key in('actual55CollectionPin','actual55PostauditPin','actual55ModelPin','actual55ProofPin','actual55ApiReportPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert len(proposal['actual55PhasePostauditPins'])==2
  for pin in proposal['actual55PhasePostauditPins']:binding(pin)
  r=read(proposal['actual55CollectionPin']['path']);p=read(proposal['actual55PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual55ToolSessionId'])is int and r['toolSessionId']==proposal['actual55ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE29_FRESH49_PROJECTION_AND_ORIGINAL_API131_WITH54_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='projection-api-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['native29PreparationPin']['sha256']and r['coreSourceManifestSha256']==p['coreSourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual55GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual55PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert len(p['phases'])==2 and p['orderedPhaseNames']==p['expectedPhaseNames']==['projection','api']and p['notAttemptedPhaseNames']==[]
  identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()
  assert proposal['actual55ToolSessionId']==20574 and identity['pid']==502956 and [x['execution']['pgid']for x in p['phases']]==[503042,503380]
  for doc in(r,p):
   for key in('guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','bothChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansFresh49ProjectionAndOriginalLoaded29Api131Only','hardwareAcceptanceCheckpointUnchanged','projectionPassed','apiPassed','projectionBeforeApiSeriallyEnforced','originalApiMethodInvocationCountNotInstrumented'):assert doc[key]is True
   for key in('batchFailure','finalVerificationFailure','originalApiCalls'):assert doc[key]is None
   for key in('Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['originalApiBooleanPredicates']==131 and doc['CoreCalls']==doc['nativeCalls']==doc['cliCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  owned=[];previous=None
  for phase,row,pin in zip(('projection','api'),p['phases'],proposal['actual55PhasePostauditPins']):
   assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
   for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   e=row['execution'];h.finite(e,0);assert e['policy']==api29_contract['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and e['pgid']not in owned and c.guard.process_scope.owned(e['pgid'])==[];owned.append(e['pgid'])
   if previous is not None:assert previous['endedAt']<=e['startedAt']
   previous=e
   binding(row['packetPin'])
   if row['authorityPin']is not None:binding(row['authorityPin'])
   for output in row['outputFiles']:binding(output)
   for key in('Source29Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
   assert row['CoreCalls']==row['nativeCalls']==row['cliCalls']==row['cadCalls']==0
  projection,api=p['phases'];assert p['projectionExecution']==projection['execution']and p['apiExecution']==api['execution']and len(projection['outputFiles'])==5 and len(api['outputFiles'])==1
  assert projection['result']==dict(actualFresh49Model=proposal['actual55ModelPin'],actualFresh49ProjectionProof=proposal['actual55ProofPin'],source29FreshFull49ProjectionPassed=True,actual49Requests=49,actualFixedTraces=263,actualHardObstacles=1298,actualSignalViaEvents=98,zeroSelected29CarrierBodiesSeeded=True)
  assert api['result']==dict(actualOriginalApiReportPin=proposal['actual55ApiReportPin'],originalApiLoaded29ChecksPassed=True,originalApiBooleanPredicates=131,apiMethodInvocationCount=None,methodCountNotInstrumented=True,bothDqs1CoupledViewsPassed=True,loadedCohortsExplicitlyPartial=dict(DDR_BYTE0=6,DDR_BYTE1=11,DDR_COMMAND_CLOCK=11))and api['originalApiCalls']is None and api['originalApiBooleanPredicates']==131
  assert p['actualFresh49Model']==proposal['actual55ModelPin']and p['actualFresh49ProjectionProof']==proposal['actual55ProofPin']and p['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and p['actualNativeReport']==proposal['actual54ReportPin']
  proof=read(proposal['actual55ProofPin']['path']);model=read(proposal['actual55ModelPin']['path']);v=read(proposal['actual55ApiReportPin']['path'])
  assert proof['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and proof['actualNativeReportSha256']==proposal['actual54ReportPin']['sha256']and proof['constructorInputSha256']==proposal['actual55ModelPin']['sha256']and proof['sourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and proof['originalSource29ProposalSha256']==proposal['promoted29ProposalPin']['sha256']and proof['exactFullInverseToFresh29Parent']is True
  assert len(model['connections'])==49 and len(model['traces'])==263 and len(model['obstacles'])==1298 and model['layerCount']==4 and sum(q['route_type']=='via'for t in model['traces']for q in t['route'])==98
  assert v['scope']=='ACTUAL_MOVED29_FRESH_CORE_ALL3_UNCHANGED_ORIGINAL_PRIVATE_API_DIAGNOSTIC'and v['packetSha256']==api['packetPin']['sha256']and v['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and v['actualNativeReportSha256']==proposal['actual54ReportPin']['sha256']and v['original49Input']=={k:proposal['actual55ModelPin'][k]for k in('path','sha256')}
  assert v['actualCompleteOriginalSignalCount']==29 and v['expectedMissingOriginalSignalCount']==20 and v['allOriginalApiLoaded26ChecksPassed']is True and v['checkInventory']['primaryBooleanPredicates']==128 and v['checkInventory']['secondaryDqs1BooleanPredicates']==3 and v['checkInventory']['primaryPlusSecondaryBooleanPredicates']==131
  assert v['secondaryDqs1View']['geometryAndEndpointsUnchanged']is v['secondaryDqs1View']['passed']is v['exactMaterialHeld']is v['fullOriginalBusRostersAndConstraintsHeld']is v['originalPrivateContinuousApiImplementationsUnchanged']is True
  for key in('complete26Accepted','accepted49','fabricationReady','referenceQualified','fullCohortTimingPassed','electricalDelayModelQualified'):assert v[key]is False
  assert {proposal['actual55ModelPin']['path'],proposal['actual55ProofPin']['path']}.issubset({x['path']for x in projection['outputFiles']})and api['outputFiles']==[proposal['actual55ApiReportPin']]
  assert projection['command']==[api29_contract['pythonInterpreterPin']['path'],'-B',api29_contract['projectorPin']['path'],projection['packetPin']['path'],projection['packetPin']['sha256'],str(Path(proposal['actual55ModelPin']['path']).parent)]
  assert api['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',api29_contract['apiWorkerPin']['path'],api['packetPin']['path'],api['packetPin']['sha256'],api['authorityPin']['path'],api['authorityPin']['sha256'],proposal['actual54ReportPin']['path'],proposal['actual55ApiReportPin']['path']]
  prior['actual55Fresh49AndOriginalApi131CollectionPin']={'path':proposal['actual55CollectionPin']['path'],'sha256':proposal['actual55CollectionPin']['sha256']};prior['actualClosedScopeCount']=55;prior['actual55TwoChildrenDoNotQualifyCliCadFull49OrElectrical']=True
  return prior
