import { Children, cloneElement, createElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { buildStrict18ManualSource } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-strict18-smooth-manual-source-core-successor-next/strict18-source-overlay"
import proposal from "./source22-proposal.json"

type Props = Record<string, unknown> & { name?: string; children?: ReactNode }
const routeFields = ["pcbPath", "pcbPaths", "pcbPathRelativeTo"] as const
const mm = (value: unknown): number => {
  if (typeof value === "number" && Number.isFinite(value)) return value
  if (typeof value === "string" && /^-?\d+(?:\.\d+)?mm$/.test(value)) return Number(value.slice(0, -2))
  throw Error("A genuine finite authored millimeter coordinate is required")
}

/** Editable Source proposal. Planning JSON is translated to genuine declarations,
 * never added to a rendered circuit-JSON database. Core allocates every ID. */
export function buildOwnerMoved22Source() {
  const base = buildStrict18ManualSource()
  const moved = new Set<string>(), originals = new Set<string>(), locals = new Set<string>()
  const removedPorts = new Set<string>(), addedPorts = new Set<string>()
  const selected = new Set(proposal.selected22OriginalCarriers.map(row => row.originalSourceTraceId))
  let boards = 0
  function fork(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const props: Props = { ...node.props }
    let children = Children.toArray(props.children).map(fork)
    const name = props.name
    const coordinate = proposal.coordinateChanges.find(row => row.name === name)
    if (coordinate) {
      if (node.type !== coordinate.type || moved.has(coordinate.name)
        || props.pcbX !== coordinate.before.pcbX || props.pcbY !== coordinate.before.pcbY)
        throw Error("One exact original declaration must own each placement change")
      props.pcbX = coordinate.after.pcbX
      props.pcbY = coordinate.after.pcbY
      moved.add(coordinate.name)
    }
    const branch = proposal.all98NumericOwnedSignalBranches.find(row => row.viaName === name)
    if (branch) {
      if (node.type !== "via" || props.fromLayer !== "top" || props.toLayer !== "bottom"
        || mm(props.outerDiameter) !== .4572 || mm(props.holeDiameter) !== .254
        || Math.abs(mm(props.pcbX) - branch.viaXY.x) > 1e-9 || Math.abs(mm(props.pcbY) - branch.viaXY.y) > 1e-9)
        throw Error("An authentic full-span signal barrel declaration is required")
      const prior = proposal.prior28RealInnerLayerPortsToReplace.filter(row => row.viaName === name)
      if (children.length !== prior.length) throw Error("Unexpected existing signal Via child")
      for (const child of children) {
        if (!isValidElement<Props>(child) || child.type !== "port" || child.props.children !== undefined
          || Object.keys(child.props).sort().join(",") !== "layer,name"
          || !prior.some(row => row.actualPriorChildSnapshot.props.name === child.props.name
            && row.actualPriorChildSnapshot.props.layer === child.props.layer))
          throw Error("Only the exact prior genuine inner Port declarations may be replaced")
        const key = `${name}:${String(child.props.name)}`
        if (removedPorts.has(key)) throw Error("Duplicate prior inner Port")
        removedPorts.add(key)
      }
      children = []
      for (const port of proposal.added32RealInnerLayerPorts.filter(row => row.viaName === name)) {
        const key = `${port.viaName}:${port.layer}`
        if (addedPorts.has(key) || !["inner1", "inner2"].includes(port.layer)) throw Error("One actual inner Port child required")
        children.push(createElement("port", { name: port.layer, layer: port.layer }))
        addedPorts.add(key)
      }
    }
    const logical = proposal.all49OriginalLogicalTraces.find(row => row.name === name)
    if (logical) {
      if (node.type !== "trace" || originals.has(logical.originalSourceTraceId)
        || props.from !== logical.from || props.to !== logical.to || props.path !== undefined)
        throw Error("One original numeric CPU-to-RAM logical Trace is required")
      // Explicit overrides are essential: cloneElement merges omitted old props.
      for (const field of routeFields) props[field] = undefined
      const carrier = proposal.selected22OriginalCarriers.find(row => row.originalSourceTraceId === logical.originalSourceTraceId)
      if (carrier) {
        props.pcbPaths = carrier.newPcbPaths
        props.pcbPathRelativeTo = carrier.newPcbPathRelativeTo
      }
      originals.add(logical.originalSourceTraceId)
    }
    const local = proposal.all98NumericOwnedSignalBranches.find(row => row.traceName === name)
    if (local) {
      if (node.type !== "trace" || locals.has(local.traceName) || props.from !== local.numericSelector
        || props.to !== `.${local.viaName} > port.top` || mm(props.thickness) !== .1016
        || props.pcbPaths !== undefined || props.pcbPathRelativeTo !== `.${local.viaName} > port.top`
        || (props.pcbPath !== undefined && (!Array.isArray(props.pcbPath) || props.pcbPath.length !== 0)))
        throw Error("The original numeric-to-owned-Top local branch is required")
      props.pcbPath = selected.has(local.originalSourceTraceId) ? undefined : []
      locals.add(local.traceName)
    }
    if (node.type === "board") {
      boards++
      if (props.layers !== 4 || props.routeRemaining !== false || (props.pcbX ?? 0) !== 0
        || (props.pcbY ?? 0) !== 0 || (props.pcbRotation ?? 0) !== 0)
        throw Error("The existing unrotated manual four-layer board is required")
      for (const via of proposal.resetViaDeclarations) children.push(createElement("via", via.props))
      for (const trace of proposal.resetLocalTraceDeclarations) children.push(createElement("trace", trace.props))
    }
    return cloneElement(node as ReactElement<Props>, props, ...children)
  }
  const element = fork(base.element)
  if (boards !== 1 || moved.size !== 129 || originals.size !== 49 || locals.size !== 96
    || removedPorts.size !== 28 || addedPorts.size !== proposal.expectedCounts.innerLiteralPorts || selected.size !== proposal.expectedCounts.carrierPaths)
    throw Error("Exact owner-closed Source22 declaration inventory is required")
  return { ...base, element, ownerMoved22Proposal: proposal,
    ownerMoved22SourceIntegration: {
      scope: "UNEXECUTED_EDITABLE_SOURCE_ONLY_OWNER_MOVED_227_JOINT22",
      ancestorSourceWasActuallyQualifiedOnlyForOld18: true,
      coordinateChangedNames: [...moved], originalNumericTraceIdsHeld: [...originals],
      replacedInnerPorts: [...removedPorts], genuineInnerPortDeclarations: [...addedPorts],
      newResetTopBranches: proposal.resetLocalTraceDeclarations.map(row => row.props.name),
      expectedCounts: proposal.expectedCounts,
      circuitJsonInjectionOrIdAssignment: false, sourceExecuted: false, coreRendered: false,
      nativeExecuted: false, cadExecuted: false, referenceQualified: false,
      automaticCoreSrjForManualPairBusForkMustNotBeUsed: true,
      all49Accepted: false, electricalTimingPassed: false, fabricationReady: false,
    } }
}

type Via = { componentName: string; props: Props; pcb_via_id?: string | null }
type Port = { componentName: string; props: Props; parent: unknown; matchedComponents: unknown[];
  source_port_id?: string | null; pcb_port_id?: string | null; registerMatch(component: unknown): void; getAvailablePcbLayers(): string[] }
type Circuit = { _hasRenderedAtleastOnce?: boolean; schematicDisabled?: boolean; selectOne(selector: string, options?: { type?: string }): unknown }

/** Public real Port.registerMatch, before rendering. The old hook is intentionally
 * not invoked: its literal coordinates/layers describe the preserved old18. */
export function registerOwnerMoved22InnerPorts(circuitUnknown: unknown) {
  const circuit = circuitUnknown as Circuit
  if (circuit._hasRenderedAtleastOnce || circuit.schematicDisabled !== true) throw Error("An actual PCB-only unrendered Circuit is required")
  const registrations = []
  for (const requested of proposal.added32RealInnerLayerPorts) {
    const via = circuit.selectOne(`.${requested.viaName}`) as Via | null
    const port = circuit.selectOne(`.${requested.viaName} > port.${requested.layer}`, { type: "port" }) as Port | null
    if (!via || via.componentName !== "Via" || via.props.name !== requested.viaName
      || Math.abs(mm(via.props.pcbX) - requested.viaXY.x) > 1e-9 || Math.abs(mm(via.props.pcbY) - requested.viaXY.y) > 1e-9
      || via.props.fromLayer !== "top" || via.props.toLayer !== "bottom" || mm(via.props.outerDiameter) !== .4572 || mm(via.props.holeDiameter) !== .254
      || !port || port.componentName !== "Port" || port.parent !== via || port.props.name !== requested.layer
      || port.props.layer !== requested.layer || port.source_port_id || port.pcb_port_id || via.pcb_via_id
      || port.getAvailablePcbLayers().join(",") !== requested.layer || port.matchedComponents.some(owner => owner !== via))
      throw Error("An actual unrendered inner Port and its one declared full-span owner are required")
    if (!port.matchedComponents.includes(via)) port.registerMatch(via)
    if (port.matchedComponents.length !== 1 || port.matchedComponents[0] !== via) throw Error("Exact genuine Port/Via registration required")
    registrations.push({ viaName: requested.viaName, layer: requested.layer, xy: requested.viaXY, numericSelector: requested.numericSelector })
  }
  if (registrations.length !== proposal.expectedCounts.innerLiteralPorts) throw Error("Exact proposed genuine inner Port registration inventory required")
  return { registrations, extraPhysicalViaFromPortRegistration: false, coreRendered: false, nativeExecuted: false }
}

// Exporting this element alone does not run the public registration hook.
// The supported future path is guarded pinned Core+hook, then JSON CLI export.
export default () => buildOwnerMoved22Source().element
