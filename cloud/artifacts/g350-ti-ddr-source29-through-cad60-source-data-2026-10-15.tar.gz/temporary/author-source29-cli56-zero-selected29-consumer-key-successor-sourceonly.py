from pathlib import Path
import json,hashlib,stat,copy,ast,difflib
OLD=Path('/tmp/g350-source29-cli56-authentic55-root-guard-sourceonly-next');NEW=Path('/tmp/g350-source29-cli56-zero-selected29-consumer-key-successor-sourceonly-next');assert not NEW.exists();NEW.mkdir(mode=0o700)
def pin(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def put(p,b):
 with p.open('xb')as f:f.write(b)
 p.chmod(0o600)
m=json.loads((OLD/'SOURCE-manifest.json').read_text());a='source29FreshFull49ProjectionPassed=True,actual49Requests=49,actualFixedTraces=263,actualHardObstacles=1298,actualSignalViaEvents=98,zeroSelected26CarrierBodiesSeeded=True';b=a.replace('zeroSelected26','zeroSelected29');patch=[];changed=[]
for row in m['files']:
 p=Path(row['path']);assert pin(p)==row;raw=p.read_bytes()
 if p.name in('run-source29-cli56-after55-root.proposal.py','CLOSED55_TWO_SERIAL_PROJECTION_API29_SOURCE_ONLY.py'):
  s=raw.decode();assert s.count(a)==1;t=s.replace(a,b);assert t.replace(b,a)==s;ast.parse(t if p.name.startswith('run-')else'def main():\n'+t);raw=t.encode();changed.append(p.name);patch.extend(difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile='8e4153/'+p.name,tofile='zero-selected29/'+p.name))
 put(NEW/p.name,raw)
assert len(changed)==2
put(NEW/'EXACT_CLOSED55_ZERO_SELECTED29_RESULT_KEY_ONLY_DELTA.patch',''.join(patch).encode())
def remap(v):
 if isinstance(v,dict):
  if all(k in v for k in('path','sha256','bytes','mode'))and Path(v['path']).parent==OLD:
   q=copy.deepcopy(v);q.update(pin(NEW/Path(v['path']).name));return q
  return{k:remap(x)for k,x in v.items()}
 if isinstance(v,list):return[remap(x)for x in v]
 return v
m=remap(m);m.update(historicalUnexecutedClosed55WrongZeroSeedKeyManifestPin=pin(OLD/'SOURCE-manifest.json'),onlyCurrentClosed55ZeroSelected29ResultKeyCorrected=True,exactZeroSelected29ResultKeyDeltaPin=pin(NEW/'EXACT_CLOSED55_ZERO_SELECTED29_RESULT_KEY_ONLY_DELTA.patch'))
m['files']=[pin(p)for p in sorted(NEW.iterdir())if p.is_file()];m['externalFiles'] +=[pin(OLD/'SOURCE-manifest.json'),pin(OLD/'run-source29-cli56-after55-root.proposal.py'),pin(OLD/'CLOSED55_TWO_SERIAL_PROJECTION_API29_SOURCE_ONLY.py'),pin(Path(__file__))];m['ownFileCountExcludingManifest']=len(m['files']);m['externalFileCount']=len(m['externalFiles'])
# Pure data comparison of every phase-result key/value; never evaluate the consumer.
r=json.loads(Path(m['actual55CollectionPin']['path']).read_text());pr,ar=[x['result']for x in r['phases']]
expected_pr=dict(actualFresh49Model=m['actual55ModelPin'],actualFresh49ProjectionProof=m['actual55ProofPin'],source29FreshFull49ProjectionPassed=True,actual49Requests=49,actualFixedTraces=263,actualHardObstacles=1298,actualSignalViaEvents=98,zeroSelected29CarrierBodiesSeeded=True)
expected_ar=dict(actualOriginalApiReportPin=m['actual55ApiReportPin'],originalApiLoaded29ChecksPassed=True,originalApiBooleanPredicates=131,apiMethodInvocationCount=None,methodCountNotInstrumented=True,bothDqs1CoupledViewsPassed=True,loadedCohortsExplicitlyPartial=dict(DDR_BYTE0=6,DDR_BYTE1=11,DDR_COMMAND_CLOCK=11))
assert pr==expected_pr and ar==expected_ar
s=(NEW/'run-source29-cli56-after55-root.proposal.py').read_text();assert "assert proposal['status']=="+repr(m['status'])in s
with(NEW/'SOURCE-manifest.json').open('x')as f:json.dump(m,f,indent=2);f.write('\n')
(NEW/'SOURCE-manifest.json').chmod(0o600)
print(json.dumps(dict(manifest=pin(NEW/'SOURCE-manifest.json'),guard=pin(NEW/'run-source29-cli56-after55-root.proposal.py'),consumer=pin(NEW/'CLOSED55_TWO_SERIAL_PROJECTION_API29_SOURCE_ONLY.py'),tail=pin(NEW/'CLI56_RUNTIME_TAIL_SOURCE_ONLY.py'),delta=pin(NEW/'EXACT_CLOSED55_ZERO_SELECTED29_RESULT_KEY_ONLY_DELTA.patch'),projectionApiResultDataExact=True),indent=2))
