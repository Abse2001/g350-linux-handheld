import {Children,cloneElement,isValidElement,type ReactElement,type ReactNode} from "react"
import {buildJointHsReferenceSource} from "/workspace/g350-linux-handheld/.cloud-tools/ddr-hs-all32-capture-first-type4096-root-successor-next/source/hs-reference-overlay"
import proposal from "./grouped-proposal.json"

type Props=Record<string,unknown>&{name?:string;children?:ReactNode}
type Group={key:string;viaName:string;source_net_id:string;referenceNet:string;x:number;y:number;reuseAcceptedHsViaId:string|null;ownerKeys:string[]}
type Owner={ownerKey:string;package:string;numericPin:number;source_port_id:string;pcb_port_id:string;referenceNet:string;source_net_id:string;padXY:{x:number;y:number};viaXY:{x:number;y:number};topStub:Array<{route_type:string;layer:string;x:number;y:number;width:number}>;traceName:string;viaGroupKey:string}

/** Unexecuted source candidate: preserve the accepted HS64 base and append
 * one canonical owner per NEW site, with distinct per-terminal Top branches.
 * All101 terminals are selected only as source data; known HS8 contact remains unproved. */
export function buildPackageApproachSource(){
 const groups=proposal.viaGroups as Group[],owners=proposal.owners as Owner[]
 if(owners.length!==101||groups.length!==72||groups.filter(g=>g.reuseAcceptedHsViaId===null).length!==65||proposal.unresolvedPackageTerminalCount!==0)throw Error("Exact raw101/group72/new65 candidate required")
 const byKey=new Map(groups.map(g=>[g.key,g]))
 if(byKey.size!==72||new Set(owners.map(o=>o.ownerKey)).size!==101||new Set(owners.map(o=>o.traceName)).size!==101||new Set(groups.map(g=>g.viaName)).size!==72)throw Error("Distinct canonical via groups, branch names and numeric owners required")
 const base=buildJointHsReferenceSource(),names=new Set<string>();let boards=0
 function append(node:ReactNode):ReactNode{
  if(!isValidElement<Props>(node))return node
  const props={...node.props}
  if(typeof props.name==="string")names.add(props.name)
  const children=Children.toArray(props.children).map(append)
  if(node.type==="board"){
   boards++;if(props.layers!==4||props.routeRemaining!==false||(props.pcbX??0)!==0||(props.pcbY??0)!==0||(props.pcbRotation??0)!==0)throw Error("Original routing-disabled four-layer identity board frame required")
   for(const group of groups){
    if(group.reuseAcceptedHsViaId!==null){if(!names.has(group.viaName))throw Error("Exact retained HS via selector must exist");continue}
    if(names.has(group.viaName))throw Error("New canonical via name collides with preserved source")
    children.push(<via name={group.viaName} pcbX={group.x} pcbY={group.y} fromLayer="top" toLayer="bottom" outerDiameter={.4572} holeDiameter={.254} connectsTo={`net.${group.referenceNet}`} tented="top_and_bottom_tented"/>)
   }
   for(const owner of owners){
    const group=byKey.get(owner.viaGroupKey)
    if(!group||!group.ownerKeys.includes(owner.ownerKey)||group.source_net_id!==owner.source_net_id||group.referenceNet!==owner.referenceNet||group.x!==owner.viaXY.x||group.y!==owner.viaXY.y)throw Error("Canonical branch/site/rail ownership differs")
    if(names.has(owner.traceName))throw Error("New branch name collides with preserved source")
    const path=owner.topStub,width=path[0]?.width
    if(path.length<2||path.some(p=>p.route_type!=="wire"||p.layer!=="top"||p.width!==width)||typeof width!=="number"||width<.1016)throw Error("Exact constant-width Top centerline required")
    if(path[0].x!==owner.padXY.x||path[0].y!==owner.padXY.y||path[path.length-1].x!==group.x||path[path.length-1].y!==group.y)throw Error("Original pad and selected via endpoints differ")
    const viaTop=`.${group.viaName} > port.top`
    // Anchor on the unrotated canonical via, not the rotated RAM package.
    // Core prepends/appends both actual ports. Supply only interior points,
    // reversed toward the package and relative to this via's actual origin.
    const relativeInteriors=path.slice(1,-1).reverse().map(p=>({x:p.x-group.x,y:p.y-group.y}))
    children.push(<trace name={owner.traceName} from={`${owner.package}.pin${owner.numericPin}`} to={viaTop} thickness={width} pcbPathRelativeTo={viaTop} pcbPath={relativeInteriors}/>)
   }
  }
  return cloneElement(node as ReactElement<Props>,props,...children)
 }
 const element=append(base.element)
 if(boards!==1)throw Error("One preserved board required")
 return {...base,element,packageApproachProposal:{scope:proposal.scope,intentionalExistingTraceContacts:proposal.intentionalExistingTraceContacts,intentionalExistingPadContacts:proposal.intentionalExistingPadContacts,selectedPackageTerminals:101,totalPackageTerminals:101,unresolved:proposal.unresolved,newCanonicalVias:65,reusedHsSites:7,retainedHsVias:64,candidatePhysicalVias:129,candidatePhysicalTraces:165,originalDdrRequests:49,allOriginalSourcePropsMustPassFreshCapture:true,actualSourceCapturePerformed:false,actualCoreBuildPerformed:false,actualNativeChecksPerformed:false,referenceQualified:false,accepted49:false,fabricationReady:false}}
}

export default()=>buildPackageApproachSource().element
