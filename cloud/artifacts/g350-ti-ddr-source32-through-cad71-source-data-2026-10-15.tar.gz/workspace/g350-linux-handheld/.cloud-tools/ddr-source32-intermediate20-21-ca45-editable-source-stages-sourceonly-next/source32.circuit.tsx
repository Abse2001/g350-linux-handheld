// Source-only future32 declarations. Original numeric owners remain unchanged; fresh IDs belong to Core.
import { Children,cloneElement,createElement,isValidElement,type ReactElement,type ReactNode } from "react"
import { buildOwnerMoved29Source,registerOwnerMoved29InnerPorts } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-source29-joint7-ca6-ca18-reset-editable-source-stages-sourceonly-next/source29.circuit"
import { readFileSync,lstatSync } from "node:fs"
import { createHash } from "node:crypto"
import data from "./source32-proposal.json"
import type { Source32Proposal, Pin, Parent29QualificationBindings } from "./source32-types"
const proposal=data as unknown as Source32Proposal, plan=proposal.source32Delta
const fields=["pcbPath","pcbPaths","pcbPathRelativeTo"] as const
type Props=Record<string,unknown>&{name?:string;children?:ReactNode}
const canonical=(v:unknown):string=>Array.isArray(v)?`[${v.map(canonical).join(",")}]`:v&&typeof v==="object"?`{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical((v as Record<string,unknown>)[k])}`).join(",")}}`:JSON.stringify(v)??"undefined"
const mm=(v:unknown):number=>{if(typeof v==="number"&&Number.isFinite(v))return v;if(typeof v==="string"&&/^-?\d+(?:\.\d+)?mm$/.test(v))return Number(v.slice(0,-2));throw Error("Finite genuine mm required")}
function sealedShape(){
 const roster=["source_trace_20","source_trace_21","source_trace_45"],intermediateRoster=["source_trace_20","source_trace_21"],names=intermediateRoster.map(id=>`V_TI_SIGNAL_INTERMEDIATE_${id}_0`)
 if(proposal.scope!=="UNEXECUTED_SOURCE32_SOURCE20_SOURCE21_INTERMEDIATE_CARRIER_VIAS_AND_SOURCE45_OVER_PROMOTED29"||proposal.promotedParent29Source.sha256!=="00421ca4aba188174b657a0787367231e19c7a4c2b1cade7e0f548378cbf1c5a"
  ||canonical(plan.exactNewOriginalSourceTraceRoster)!==canonical(roster)||canonical(plan.exactIntermediateOriginalSourceTraceRoster)!==canonical(intermediateRoster)||canonical(plan.routeChanges.map(r=>r.originalSourceTraceId))!==canonical(roster)
  ||canonical(plan.newIntermediateCarrierVias.map(v=>v.viaName))!==canonical(names)||canonical(proposal.intermediateCarrierVias)!==canonical(plan.newIntermediateCarrierVias)
  ||plan.newIntermediateCarrierVias.some(v=>v.role!=="REMOVABLE_INTERMEDIATE_CARRIER_VIA_NOT_FIXED_FANOUT")
  ||canonical(plan.newIntermediateCarrierVias.map(v=>v.xy))!==canonical([{x:-9,y:13.6},{x:-8.5,y:14.4}])
  ||canonical(plan.newSixInnerPorts.map(p=>`${p.viaName}:${p.layer}`).sort())!==canonical([...names.map(n=>`${n}:inner2`),...intermediateRoster.map(id=>`V_TI_SIGNAL_${id}_0:inner2`),"V_TI_SIGNAL_source_trace_45_0:inner2","V_TI_SIGNAL_source_trace_45_1:inner2"].sort())
  ||proposal.selected29OriginalCarriers.length!==29||proposal.selected32OriginalCarriers.length!==32||proposal.all98NumericOwnedSignalBranches.length!==98||proposal.all49OriginalLogicalTraces.length!==49
  ||proposal.expectedCounts.physicalVias!==229||proposal.expectedCounts.physicalTraces!==297||proposal.expectedCounts.innerLiteralPorts!==52
  ||proposal.expectedCounts.expectedSourcePorts!==1671||proposal.expectedCounts.expectedReactElements!==2286||proposal.expectedCounts.carrierBodyPaths!==34)
  throw Error("Exact two named intermediate-via/four-path Source20+21 plus ordinary Source45 roster required")
}
function requireFutureQualifiedParent29(){
 const evidence=proposal.parent29QualificationBindings as Parent29QualificationBindings
 if(proposal.actualParent29Qualification===null||proposal.actualParent29Capture===null||evidence.collectionPins.cad60===null||evidence.stagePins.cad===null||evidence.postauditPins.cad60===null||Object.values(proposal.actualParent29Stages).some(pin=>pin===null))
  throw Error("Source32 refuses until genuine successful Source29 stages53 through56 and CAD60, with failed57/58/59 separately closed are collected and bound in an immutable successor")
 const need=(ok:unknown,label:string)=>{if(!ok)throw Error(label)}
 const same=(a:unknown,b:unknown,label:string)=>need(canonical(a)===canonical(b),label)
 same(proposal.actualParent29Qualification,evidence.collectionPins.cad60,"Final parent29 qualification is the genuine CAD60 collection")
 same(proposal.actualParent29Capture,evidence.stagePins.capture,"Dedicated gate capture is the genuine53 capture")
 same(proposal.actualParent29Stages,evidence.stagePins,"All seven exact stage pins agree")
 same(Object.keys(evidence.stagePins).sort(),["cad","capture","cli","core","native","originalApi","types"],"Exact seven-stage roster")
 same(proposal.promotedParent29Source,evidence.sourceManifest,"One promoted parent29 source")
 same(proposal.parent29Proposal,evidence.sourceProposal,"One exact parent29 proposal")
 need(evidence.sourceManifest.sha256==="00421ca4aba188174b657a0787367231e19c7a4c2b1cade7e0f548378cbf1c5a"&&evidence.sourceProposal.sha256==="34a35a2ef12829ac11303dfb98ce8c955efcf0c897fa133c79ddcd63d99cf86a","Exact direct29 declaration and geometry")
 const bytes=(pin:Pin|null):Buffer=>{
  if(!pin||!pin.path.startsWith("/")||!/^[0-9a-f]{64}$/.test(pin.sha256)||typeof pin.bytes!=="number"||typeof pin.mode!=="number")throw Error("Complete authentic parent data pin required")
  const stat=lstatSync(pin.path),data=readFileSync(pin.path)
  need(stat.isFile()&&!stat.isSymbolicLink()&&stat.size===pin.bytes&&data.length===pin.bytes&&(stat.mode&0o777)===pin.mode&&createHash("sha256").update(data).digest("hex")===pin.sha256,"Parent source/data bytes changed")
  return data
 }
 type Json=Record<string,any>
 const json=(pin:Pin|null):Json=>JSON.parse(bytes(pin).toString())
 const produced=(files:Json[],pin:Pin,label:string)=>need(files.filter(row=>canonical(row)===canonical(pin)).length===1,label)
 const natural=(execution:Json)=>{
  need(execution&&execution.exitCode===0&&execution.diagnosticStopped===false&&Array.isArray(execution.stopReasons)&&execution.stopReasons.length===0&&execution.cleanupOwnedGroupEmpty===true,"Every genuine child naturally completed without resource stop")
  need(Object.values(execution.oomDelta??{}).length===3&&Object.values(execution.oomDelta).every(value=>value===0)&&execution.signalErrorCount===0,"Every child has zero OOM/signal error deltas")
  need(typeof execution.startedAt==="string"&&typeof execution.endedAt==="string"&&Number.isFinite(Date.parse(execution.startedAt))&&Number.isFinite(Date.parse(execution.endedAt))&&Date.parse(execution.endedAt)>=Date.parse(execution.startedAt),"Actual finite child timestamps")
  need(Number.isInteger(execution.pid)&&execution.pid>0&&execution.pgid===execution.pid&&execution.freshLeaderIdentity.pid===execution.pid&&execution.freshLeaderIdentity.pgid===execution.pgid&&execution.freshLeaderIdentity.sid===execution.pgid,"Actual fresh owned leader/session identity")
  same(execution.freshLeaderIdentity.argv,execution.command,"Exact child command identity")
 }
 const failed:Record<string,Json>={}
 same(Object.keys(evidence.failedCadAttemptPins).sort(),["cad57","cad58","cad59"],"Exact separate failed CAD attempt roster")
 same(Object.keys(evidence.failedCadAttemptPostPins).sort(),["cad57","cad58","cad59"],"Exact separate failed CAD POST roster")
 const failedTools:Record<string,number>={cad57:98055,cad58:59882,cad59:31552}
 for(const[name,pin]of Object.entries(evidence.failedCadAttemptPins)){
  const r=json(pin),postPin=evidence.failedCadAttemptPostPins[name]
  need(r.authorizedByRoot===true&&r.toolSessionCollected===true&&r.toolSessionId===failedTools[name]&&r.toolWrapperExitCode===(name==="cad57"?1:2)&&r.toolExitCode===r.toolWrapperExitCode&&r.passed===false,"Each failed CAD attempt is an authentic collected failure")
  need(r.sourceManifestSha256===evidence.cliCadRuntime.sha256&&r.independentlyObservedAllActuallySpawnedOwnedGroupsEmpty===true&&r.independentlyObservedGuardAbsent===true,"All actually spawned failed-attempt groups are closed")
  need(r.Source29Accepted===false&&r.accepted49===false&&r.referenceQualified===false&&r.electricalTimingPassed===false&&r.fabricationReady===false,"Failed attempts never qualify Source29")
  if(name==="cad57"){
   need(postPin===null&&r.originalPostauditProduced===false&&r.originalCadExitCode===null&&r.completeSdkPostauditHeld===null&&r.completeSdkPostauditUnavailableBecauseGuardCrashed===true&&r.cadChildPidOrPgidAllocated===false&&r.cadWrapperSpawned===false&&r.cadApplicationInvoked===false,"Failed57 keeps its absent POST/child/complete SDK audit unknown")
   same(json(r.zonePinsExecutionPin),r.zonePinsExecution,"Failed57 original zone execution")
   same(json(r.cadAttemptExecutionPin),r.unspawnedCadAttemptExecution,"Failed57 original unspawned CAD record")
  }else{
   const post=json(postPin)
   need(postPin!==null&&r.postauditPath===postPin.path&&r.postauditSha256===postPin.sha256&&post.toolSessionCollected===false,"Failed attempt retains actual POST distinct from Root collection")
   for(const key of Object.keys(post))if(key!=="toolSessionCollected")same(r[key],post[key],"Failed receipt matches actual POST field "+key)
   need(r.sourceAndDependenciesHeld===true&&r.workspaceFreeBytesFloorHeld===true&&r.gitMetadataHeld===true&&r.dependenciesBefore.treeSha256==="ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2"&&r.dependenciesAfter.treeSha256===r.dependenciesBefore.treeSha256&&r.solverDependenciesBefore.treeSha256==="47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6"&&r.solverDependenciesAfter.treeSha256===r.solverDependenciesBefore.treeSha256,"Failed58/59 retain their actually available SDK and source audits")
  }
  natural(r.zonePinsExecution);failed[name]=r
 }
 const f57=failed.cad57,f58=failed.cad58,f59=failed.cad59
 need(f57.scope==="ROOT_SOURCE29_CAD57_ZONE_ONLY_CAD_PREFORK_REJECTED_POSTAUDIT_CRASH_RECOVERY"&&f57.phase==="cad-prefork-failure"&&f57.unspawnedCadAttemptExecution.exitCode===null&&!Object.hasOwn(f57.unspawnedCadAttemptExecution,"pid")&&!Object.hasOwn(f57.unspawnedCadAttemptExecution,"pgid"),"Failed57 was rejected before a CAD child existed")
 need(f58.scope==="ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH57_AUTHENTIC_PRIOR_CLOSURES"&&f58.cadWrapperSpawned===false&&f58.cadApplicationInvoked===false&&f58.containerInvocationPerformed===false&&f58.cadExecution.exitCode===null&&!Object.hasOwn(f58.cadExecution,"pid")&&!Object.hasOwn(f58.cadExecution,"pgid"),"Failed58 remains a prefork rejection with no CAD process")
 need(f59.scope==="ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH58_AUTHENTIC_PRIOR_CLOSURES"&&f59.cadWrapperSpawned===true&&f59.containerInvocationPerformed===true&&f59.cadDiagnosticWorkerInvoked===true&&f59.actualKiCadLoadBoardPerformed===false&&f59.actualConnectivityDiagnosticPerformed===false&&f59.workerFailedBeforeCadBoardLoad===true&&f59.cadExecution.exitCode===2&&f59.cadExecution.cleanupOwnedGroupEmpty===true&&f59.cadExecution.diagnosticStopped===false&&f59.rootIndependentlyObservedOwnedContainerAbsent===true&&f59.containerCleanupEvidenceActuallyEmpty===true&&f59.outerPostContainerEmptyRemainsNull===true,"Failed59 worker failed before board load; Root container closure is not a fabricated POST pass")
 const collections:Record<string,Json>={}
 for(const[name,pin]of Object.entries(evidence.collectionPins)){
  const receipt=json(pin),postPin=evidence.postauditPins[name],post=json(postPin)
  need(receipt.authorizedByRoot===true&&receipt.toolSessionCollected===true&&receipt.toolWrapperExitCode===0&&receipt.toolExitCode===0&&receipt.passed===true,"Authentic successful collected parent29 stage")
  need(receipt.sourceAndDependenciesHeld===true&&receipt.workspaceFreeBytesFloorHeld===true&&receipt.gitMetadataHeld===true&&receipt.independentlyObservedGuardAbsent===true&&Array.isArray(receipt.independentProcReadErrors)&&receipt.independentProcReadErrors.length===0,"Parent source/dependencies/workspace/Git and Root closure observations held")
  need(receipt.independentlyObservedAllOwnedGroupsEmpty===true||receipt.independentlyObservedOwnedGroupEmpty===true,"Root independently observed every historical owned group empty")
  need(receipt.Source29Accepted===false&&receipt.all49Accepted===false&&receipt.referenceQualified===false&&receipt.electricalTimingPassed===false&&receipt.fabricationReady===false,"Historical narrow geometry is never full hardware/electrical qualification")
  need(receipt.dependenciesBefore.treeSha256==="ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2"&&receipt.dependenciesAfter.treeSha256===receipt.dependenciesBefore.treeSha256&&receipt.solverDependenciesBefore.treeSha256==="47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6"&&receipt.solverDependenciesAfter.treeSha256===receipt.solverDependenciesBefore.treeSha256,"Original pinned SDK trees held at each genuine stage")
  need(postPin!==null&&receipt.postauditPath===postPin.path&&receipt.postauditSha256===postPin.sha256&&post.toolSessionCollected===false,"Actual precollection POST and genuine Root collection are separate")
  for(const key of Object.keys(post))if(key!=="toolSessionCollected")same(receipt[key],post[key],"Collected receipt agrees with POST field "+key)
  collections[name]=receipt
 }
 bytes(evidence.sourceManifest);bytes(evidence.sourceProposal);bytes(evidence.nativeApiRuntime);bytes(evidence.cliCadRuntime)
 for(const pin of Object.values(evidence.stagePins))bytes(pin)
 for(const pin of[evidence.rawCore,evidence.coreControls,evidence.fresh49Model,evidence.fresh49ProjectionProof,evidence.cliExport])bytes(pin)
 const batch=(receipt:Json,names:string[])=>{
  same(receipt.orderedPhaseNames,names,"Exact historical serial child phases");same(receipt.expectedPhaseNames,names,"Exact expected historical phases")
  need(receipt.notAttemptedPhaseNames.length===0&&receipt.guardIdentityHeldAcrossChildren===true&&receipt.allOwnedGroupsIndependentlyObservedEmpty===true&&receipt.eachAttemptedChildNaturallyCompleted===true&&receipt.phases.length===names.length,"Every historical serial child actually completed")
  const phases=receipt.phases as Json[]
  for(const[rowIndex,row]of phases.entries()){
   need(row.phase===names[rowIndex]&&row.passed===true&&row.ownedGroupEmptyActuallyObserved===true&&row.stageNaturallyCompleted===true&&row.ownedChildNatural0===true&&row.sourceAndDependenciesHeld===true,"Each exact historical phase passed with its own group closure")
   natural(row.execution);same(row.command,row.execution.command,"Historical phase command")
   same(row.guardIdentityBefore,receipt.sameGuardIdentity,"Same guard before child");same(row.guardIdentityAfter,receipt.sameGuardIdentity,"Same guard after child")
   const phasePin:Pin={path:row.postauditPath,sha256:row.postauditSha256,bytes:lstatSync(row.postauditPath).size,mode:lstatSync(row.postauditPath).mode&0o777}
   const individual=json(phasePin),{postauditPath:_path,postauditSha256:_sha,...withoutPost}=row;same(individual,withoutPost,"Each phase POST equals its own final row")
   if(rowIndex>0)need(Date.parse(phases[rowIndex-1].execution.endedAt)<=Date.parse(row.execution.startedAt)&&phases[rowIndex-1].execution.pgid!==row.execution.pgid,"Historical children are serial and have separate owned groups")
  }
  return phases
 }
 const b=collections.batch53
 need(b.scope==="ROOT_SOURCE29_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH52_AUTHENTIC_PRIOR_CLOSURES"&&b.phase==="capture-types-core-batch"&&b.sourceManifestSha256===evidence.sourceManifest.sha256&&b.allThreeChildrenNaturallyCompleted===true&&b.CoreCalls===1,"Authentic53 Source29 three-stage batch")
 const stages=batch(b,["capture","types","core"])
 same(stages[0].result.sourceCapturePin,evidence.stagePins.capture,"Actual53 capture output")
 same(stages[1].result.actualPriorCapturePin,evidence.stagePins.capture,"Actual strict types consumed actual capture")
 need(stages[1].result.strictNoEmitTypecheckNatural0===true,"Actual strict types passed")
 need(evidence.stagePins.types?.path===stages[1].postauditPath&&evidence.stagePins.types?.sha256===stages[1].postauditSha256,"Types stage pin is its genuine POST")
 same(stages[2].result.rawCorePin,evidence.rawCore,"Actual53 raw Core");same(stages[2].result.coreControlsPin,evidence.coreControls,"Actual53 Core controls")
 same(evidence.stagePins.core,evidence.coreControls,"Stage Core pin agrees")
 const capture=json(evidence.stagePins.capture),core=json(evidence.coreControls)
 need(capture.passed===true&&capture.fullInverseSourceTreePassed===true&&capture.proposedReactElementCount===2278&&core.freshCoreControlPassed===true&&core.checks.length===29&&core.checks.every((row:Json)=>row.passed===true)&&core.rawCoreSha256===evidence.rawCore.sha256&&core.actualCaptureSha256===evidence.stagePins.capture?.sha256&&core.actualNonzeroWireSegmentCount===1053&&core.expectedOriginalCarrierCount===29&&core.expectedMissingOriginalSignalCount===20,"Exact genuine parent capture and all29 Core predicates")
 const n=collections.native54;natural(n.execution)
 need(n.scope==="ROOT_SOURCE29_NATIVE18_WITH_AUTHENTIC_53_THREE_STAGE_PRIOR_CLOSURES"&&n.sourceManifestSha256===evidence.nativeApiRuntime.sha256&&n.stageNaturallyCompleted===true&&n.ownedChildNatural0===true&&n.ownedGroupEmptyActuallyObserved===true&&n.resultPassed===true&&n.coreSourceManifestSha256===evidence.sourceManifest.sha256&&n.actualCoreSha256===evidence.rawCore.sha256&&n.actualCoreControlsSha256===evidence.coreControls.sha256&&n.reportSha256===evidence.stagePins.native?.sha256,"Actual54 Native joins to same Core29")
 produced(n.outputFiles,evidence.stagePins.native!,"Actual Native report was produced")
 const native=json(evidence.stagePins.native)
 need(native.physicalErrors===0&&native.checkCount===18&&native.physicalCpuRamConnectedCarrierCount===29&&native.rawCircuitUnmodified===true&&native.actualNativePairFindings.length===0&&native.actualCoreSha256===evidence.rawCore.sha256&&native.actualCoreControlsSha256===evidence.coreControls.sha256&&native.originalSource29ProposalSha256===evidence.sourceProposal.sha256,"Native18 plus exact29 numeric physical graphs")
 const a=collections.api55
 need(a.scope==="ROOT_SOURCE29_FRESH49_PROJECTION_AND_ORIGINAL_API131_WITH54_AUTHENTIC_PRIOR_CLOSURES"&&a.sourceManifestSha256===evidence.nativeApiRuntime.sha256&&a.phase==="projection-api-batch"&&a.bothChildrenNaturallyCompleted===true&&a.projectionPassed===true&&a.apiPassed===true&&a.projectionBeforeApiSeriallyEnforced===true&&a.actualCoreSha256===evidence.rawCore.sha256&&a.originalApiBooleanPredicates===131,"Actual55 serial fresh49 and original131 predicates")
 const ap=batch(a,["projection","api"])
 same(ap[0].result.actualFresh49Model,evidence.fresh49Model,"Actual projection produced this fresh model")
 same(ap[0].result.actualFresh49ProjectionProof,evidence.fresh49ProjectionProof,"Actual projection produced this proof")
 same(ap[1].result.actualOriginalApiReportPin,evidence.stagePins.originalApi,"Actual API produced this report")
 need(ap[0].result.actual49Requests===49&&ap[0].result.actualFixedTraces===263&&ap[0].result.actualHardObstacles===1298&&ap[0].result.actualSignalViaEvents===98&&ap[0].result.zeroSelected29CarrierBodiesSeeded===true&&ap[1].result.originalApiLoaded29ChecksPassed===true&&ap[1].result.bothDqs1CoupledViewsPassed===true,"Actual unseeded full49 material and both DQS1 views")
 const api=json(evidence.stagePins.originalApi),projection=json(evidence.fresh49ProjectionProof),model=json(evidence.fresh49Model)
 need(projection.actualCoreSha256===evidence.rawCore.sha256&&projection.actualNativeReportSha256===evidence.stagePins.native?.sha256&&projection.constructorInputSha256===evidence.fresh49Model.sha256&&projection.sourceManifestSha256===evidence.sourceManifest.sha256&&projection.originalSource29ProposalSha256===evidence.sourceProposal.sha256,"Fresh projection inverse joins to genuine Source29")
 same(api.original49Input,{path:evidence.fresh49Model.path,sha256:evidence.fresh49Model.sha256},"Original API uses the exact two-key current model pin")
 need(api.actualCoreSha256===evidence.rawCore.sha256&&api.actualNativeReportSha256===evidence.stagePins.native?.sha256&&api.actualCompleteOriginalSignalCount===29&&api.expectedMissingOriginalSignalCount===20&&api.allOriginalApiLoaded26ChecksPassed===true&&api.exactMaterialHeld===true&&api.checkInventory.primaryPlusSecondaryBooleanPredicates===131&&api.secondaryDqs1View.passed===true&&api.fullOriginalBusRostersAndConstraintsHeld===true&&api.fullOriginalDifferentialPairArrayUnchanged===true&&model.connections.length===49&&model.traces.length===263&&model.obstacles.length===1298,"Actual29 API131 uses its preserved legacy result-key spelling without retagging")
 const c=collections.cli56;natural(c.execution)
 need(c.sourceManifestSha256===evidence.cliCadRuntime.sha256&&c.phase==="cli"&&c.stageNaturallyCompleted===true&&c.ownedChildNatural0===true&&c.ownedGroupEmptyActuallyObserved===true&&c.resultPassed===true&&c.actualCoreSha256===evidence.rawCore.sha256&&c.actualCoreControlsSha256===evidence.coreControls.sha256&&c.reportSha256===evidence.stagePins.cli?.sha256&&c.exportSha256===evidence.cliExport.sha256,"Actual56 CLI report and export join")
 produced(c.outputFiles,evidence.stagePins.cli!,"Actual CLI report was produced");produced(c.outputFiles,evidence.cliExport,"Actual PCB export was produced")
 const cli=json(evidence.stagePins.cli)
 need(cli.exportPassed===true&&cli.cliExitCode===0&&cli.actualCoreSha256===evidence.rawCore.sha256&&cli.coreControlsSha256===evidence.coreControls.sha256&&cli.recognizedCircuitJsonSha256===evidence.rawCore.sha256&&cli.outputSha256===evidence.cliExport.sha256&&cli.actualPhysicalTraceCount===292&&cli.actualPhysicalViaCount===227&&cli.actualSourceSegmentCount===1053&&cli.actualSourceOwnedCarrierCount===29&&cli.sourceOnlyMissingRoutes===20&&cli.byteIdenticalCopyOnly===true&&cli.originalRawEdited===false&&cli.automaticCoreSrjUsed===false&&cli.nativeAndOriginalApiStagesPassed===true,"Exact fresh Source29 CLI geometry and preserved raw bytes")
 const d=collections.cad60
 need(d.scope==="ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH59_AUTHENTIC_PRIOR_CLOSURES"&&d.sourceManifestSha256===evidence.cliCadRuntime.sha256&&d.phase==="cad"&&d.actualCoreSha256===evidence.rawCore.sha256&&d.actualCoreControlsSha256===evidence.coreControls.sha256&&d.reportSha256===evidence.stagePins.cad?.sha256&&d.zonePinsOwnedGroupEmptyActuallyObserved===true&&d.cadOwnedGroupEmptyActuallyObserved===true&&d.zonePinsChildNatural0===true&&d.cadChildNatural0===true&&d.zoneBeforeCadSeriallyEnforced===true,"Genuine60 serial zone/CAD resource and ownership closure")
 natural(d.zonePinsExecution);natural(d.cadExecution)
 need(d.zonePinsExecution.pgid!==d.cadExecution.pgid&&Date.parse(d.zonePinsExecution.endedAt)<=Date.parse(d.cadExecution.startedAt),"Distinct serial CAD60 owned children")
 produced(d.outputFiles,evidence.stagePins.cad!,"Actual CAD report was produced")
 const cad=json(evidence.stagePins.cad)
 need(cad.passed===true&&cad.diagnosticCompleted===true&&cad.actualCoreSha256===evidence.rawCore.sha256&&cad.actualCoreControlsSha256===evidence.coreControls.sha256&&cad.actualExportSha256===evidence.cliExport.sha256&&cad.actualDerivedSourceSegmentCount===1053&&cad.actualSourceOwnedGraphCount===29&&cad.actualLoadedFootprints===507&&cad.actualLoadedVias===227&&cad.actualLoadedSegments===1053&&cad.actualLoadedLayerCount===4&&cad.actualLocalNetAgreementCount===98&&cad.actualLocalPhysicalApproachCount===98&&cad.actual29NonzeroNetGraphCount===29&&cad.actual29PhysicalCpuRamGraphCount===29&&cad.all292SourceTracesMappedBijectively===true&&cad.expectedMissingOriginalSignalCount===20,"Exact same-Core Source29 CAD geometry and physical graphs")
 need(cad.actual29GraphObservations.length===29&&cad.actual29GraphObservations.every((row:Json)=>row.allOwned29GraphItemsSameNonzeroNet===true&&row.actualCpuToRamAndEveryOwnedPathItemPhysicallyConnected===true&&row.actualSourceOwnedPhysicalGraph.physicallyConnected===true),"Every genuine29 CAD numeric path is connected")
 need(cad.actualRetainedNativeHardwareKeepoutZones===2&&cad.actualNativeCopperPourZones===0&&cad.allInputBytesHeld===true&&cad.sourceRawOrSdkEdited===false&&cad.rawExportEdited===false&&cad.netRepairPerformed===false&&cad.saveBoardPerformed===false&&cad.refillPerformed===false&&cad.referenceQualified===false&&cad.electricalTimingQualified===false&&cad.accepted49===false&&cad.fabricationReady===false,"Narrow read-only CAD qualification never asserts planes, full timing, or fabrication")
}
export function buildOwnerIntermediate32Source(){
 sealedShape();requireFutureQualifiedParent29()
 const base=buildOwnerMoved29Source(),changed=new Set<string>(),locals=new Set<string>(),ports=new Set<string>(),logical=new Set<string>();let boards=0,added=0
 function fork(node:ReactNode):ReactNode{
  if(!isValidElement<Props>(node))return node
  const props:Props={...node.props},children=Children.toArray(props.children).map(fork)
  if(plan.newIntermediateCarrierVias.some(v=>v.viaName===props.name))throw Error("New carrier via name must be absent from all parent29 declarations")
  const request=plan.newSixInnerPorts.find(p=>p.viaName===props.name)
  if(request){
   if(node.type!=="via"||children.length!==0||props.fromLayer!=="top"||props.toLayer!=="bottom"||mm(props.outerDiameter)!==.4572||mm(props.holeDiameter)!==.254||mm(props.pcbX)!==request.viaXY.x||mm(props.pcbY)!==request.viaXY.y||ports.has(request.viaName))throw Error("Only a genuine held CPU20/21 or CPU/RAM45 via receives one new inner2 child")
   children.push(createElement("port",{name:request.layer,layer:request.layer}));ports.add(request.viaName)
  }
  const change=plan.routeChanges.find(c=>c.logicalName===props.name)
  if(change){
   const old=Object.fromEntries(fields.filter(k=>props[k]!==undefined).map(k=>[k,props[k]]))
   if(node.type!=="trace"||props.from!==change.fromSelector||props.to!==change.toSelector||props.path!==undefined||mm(props.thickness)!==.1016||canonical(old)!==canonical(change.beforeRouteProps)||changed.has(change.originalSourceTraceId))throw Error("Original exact20/21/45 numeric trace must be physically unseeded")
   for(const k of fields)props[k]=undefined
   props.pcbPaths=change.after.newPcbPaths;props.pcbPathRelativeTo=change.after.newPcbPathRelativeTo;changed.add(change.originalSourceTraceId)
  }
  const local=plan.localSuppressions.find(p=>p.traceName===props.name)
  if(local){
   if(node.type!=="trace"||props.from!==local.numericSelector||props.to!==`.${local.viaName} > port.top`||mm(props.thickness)!==.1016||canonical(props.pcbPath)!=="[]"||props.pcbPaths!==undefined||props.pcbPathRelativeTo!==`.${local.viaName} > port.top`||locals.has(local.traceName))throw Error("Only the six existing Source20+21+45 local physical branches are suppressed")
   props.pcbPath=undefined;locals.add(local.traceName)
  }
  const original=proposal.all49OriginalLogicalTraces.find((p:Record<string,any>)=>p.name===props.name)
  if(original){if(node.type!=="trace"||props.from!==original.from||props.to!==original.to||logical.has(original.originalSourceTraceId))throw Error("Every original49 numeric logical owner remains exact");logical.add(original.originalSourceTraceId)}
  if(node.type==="board"){
   if(++boards!==1||props.layers!==4||props.routeRemaining!==false||(props.pcbX??0)!==0||(props.pcbY??0)!==0||(props.pcbRotation??0)!==0)throw Error("One unchanged manual four-layer board required")
   for(const v of plan.newIntermediateCarrierVias){children.push(createElement("via",{name:v.viaName,pcbX:v.xy.x,pcbY:v.xy.y,fromLayer:"top",toLayer:"bottom",outerDiameter:.4572,holeDiameter:.254,tented:"top_and_bottom_tented"},createElement("port",{name:"inner2",layer:"inner2"})));added++;ports.add(v.viaName)}
  }
  return cloneElement(node as ReactElement<Props>,props,...children)
 }
 const element=fork(base.element)
 if(boards!==1||added!==2||changed.size!==3||locals.size!==6||ports.size!==6||logical.size!==49)throw Error("Exact narrow Source32 declarations required")
 return {...base,element,ownerIntermediate32Proposal:data,ownerIntermediate32Integration:{changedOriginalSourceTraceIds:[...changed],newIntermediateCarrierViaNames:plan.newIntermediateCarrierVias.map(v=>v.viaName),carrierViaRole:"REMOVABLE_CARRIER_NOT_FIXED_FANOUT",newRealPortParents:[...ports],all227ExistingBarrelsHeld:true,all29PriorCarriersHeld:true,all98NumericBranchDefinitionsHeld:true,expectedCounts:proposal.expectedCounts,freshIdsAssigned:false,source32Qualified:false,all49Accepted:false,fabricationReady:false}}
}
type Via={componentName:string;props:Props;pcb_via_id?:string|null;source_manually_placed_via_id?:string|null}
type Port={componentName:string;props:Props;parent:unknown;matchedComponents:unknown[];source_port_id?:string|null;pcb_port_id?:string|null;registerMatch(owner:unknown):void;getAvailablePcbLayers():string[]}
type Circuit={_hasRenderedAtleastOnce?:boolean;schematicDisabled?:boolean;selectOne(selector:string,options?:{type?:string}):unknown}
export function registerOwnerIntermediate32InnerPorts(circuitUnknown:unknown){
 sealedShape();requireFutureQualifiedParent29();const circuit=circuitUnknown as Circuit
 if(circuit._hasRenderedAtleastOnce||circuit.schematicDisabled!==true)throw Error("Unrendered PCB-only actual Circuit required")
 const previous=registerOwnerMoved29InnerPorts(circuitUnknown);if(previous.registrations.length!==46)throw Error("Held46 genuine registrations required")
 const registrations:Array<{viaName:string;layer:string;xy:{x:number;y:number};numericSelector:string|null;originalSourceTraceId?:string;ownershipRole?:string}>=[...previous.registrations]
 for(const request of plan.newSixInnerPorts){
  const via=circuit.selectOne(`.${request.viaName}`)as Via|null,port=circuit.selectOne(`.${request.viaName} > port.${request.layer}`,{type:"port"})as Port|null
  if(!via||via.componentName!=="Via"||via.props.name!==request.viaName||via.props.fromLayer!=="top"||via.props.toLayer!=="bottom"||mm(via.props.outerDiameter)!==.4572||mm(via.props.holeDiameter)!==.254||mm(via.props.pcbX)!==request.viaXY.x||mm(via.props.pcbY)!==request.viaXY.y||!port||port.componentName!=="Port"||port.parent!==via||port.props.name!==request.layer||port.props.layer!==request.layer||port.source_port_id||port.pcb_port_id||via.pcb_via_id||via.source_manually_placed_via_id||port.getAvailablePcbLayers().join(",")!==request.layer||port.matchedComponents.some(owner=>owner!==via))throw Error("One real requested layer Port bound only to its genuine unrendered full-span Via required")
  if(!port.matchedComponents.includes(via))port.registerMatch(via)
  if(port.matchedComponents.length!==1||port.matchedComponents[0]!==via)throw Error("Exact physical alias ownership required")
  registrations.push({viaName:request.viaName,layer:request.layer,xy:request.viaXY,numericSelector:request.numericSelector,originalSourceTraceId:request.originalSourceTraceId,ownershipRole:request.numericSelector===null?"REMOVABLE_CARRIER_VIA_ALIAS":"EXISTING_NUMERIC_ENDPOINT_ALIAS"})
 }
 if(registrations.length!==52||new Set(registrations.map(r=>`${r.viaName}:${r.layer}`)).size!==52)throw Error("Exactly52 unique real matches required")
 return {registrations,extraPhysicalViaFromPortRegistration:false,explicitSourceOwnedIntermediateViaCount:2,coreRendered:false}
}
export default()=>buildOwnerIntermediate32Source().element
