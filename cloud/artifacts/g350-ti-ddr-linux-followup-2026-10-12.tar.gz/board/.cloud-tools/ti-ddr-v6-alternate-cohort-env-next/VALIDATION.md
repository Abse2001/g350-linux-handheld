V6 source-only verification passed. C_DDR_CPU_13 alone moved20µm right on Bottom
from(-4.5,16.8) to(-4.48,16.8); CPU/RAM and all other component poses, original280
parts/1161 contacts, logical inventory, constraints and2 reference stubs/vias remain.
All17 native physical checks return0. CPU13 nearest DDR supply E5 is0.966644mm
and ground C7 is1.399428mm, under10.16mm; same-layer courtyard gap0.0766mm exceeds
0.05mm. All32 CPU/RAM decoupling-center distance checks pass.

The fresh pinned Core projection has49 native DDR connections,854 original pads
plus2 real via obstacles, and2 fixed physical references. Alternate cohort is
BYTE0/BYTE1 Top(22) and COMMAND_CLOCK/RESET Bottom(27). Byte MAXIMUM14.4mm,
command22.35–24.89mm, bus0.635mm and pair0.127mm are unchanged. Expected nominal
via targets bytes0/command2 are design intent until actual routes qualify.

Corrected actual guard/child exit0;44.060s owned/53.207s outer, peak1,973,960,704B
under2GiB, no resource stop/OOM and owned group empty. Full16975-file board tree
ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2 stays exact.
The earlier CLI bootstrap failure remains raw in siblingti-ddr-v6-alternate-cohort-next;
it failed global configuration before loading source and produced no circuit data.
The corrected launcher sources cloud/env.sh as the saved Start does, keeping XDG
configuration under the prepared workspace. No HOME override or installs were made.

No Bus/Fanout/Grid initialization, signal routing or fabrication publication ran.
These are a validated placement and input proposal, not connected49 DDR or timing
acceptance. V5 remains preserved; no tracked files/default/runtime pins changed.
