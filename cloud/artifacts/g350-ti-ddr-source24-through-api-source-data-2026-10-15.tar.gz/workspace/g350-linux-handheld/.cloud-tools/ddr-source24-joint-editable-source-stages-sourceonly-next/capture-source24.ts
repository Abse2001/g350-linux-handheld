/** Root-only pure Source capture. No Circuit construction or Core render. */
import { Children, Fragment, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { readFileSync, writeFileSync, existsSync } from "node:fs"
import { createHash } from "node:crypto"
import assert from "node:assert/strict"
import { buildOwnerMoved23Source } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-owner23-display-offset-compact-source-successor-next/source23.circuit"
import { buildOwnerMoved24Source } from "./source24.circuit"
import proposal from "./source24-proposal.json"
import held169 from "./BASELINE_SOURCE169_BINDINGS.json"
const [output, diagnostic, ...extra] = process.argv.slice(2)
assert.equal(process.env.G350_MOVED24_SOURCE_ROOT_GUARDED, "1")
assert.equal(process.versions.bun, "1.3.14")
assert.ok(output && diagnostic && extra.length === 0 && output !== diagnostic && !existsSync(output) && !existsSync(diagnostic))
const sha = (v: string | Buffer) => createHash("sha256").update(v).digest("hex")
for (const row of held169.files) assert.equal(sha(readFileSync(row.path)), row.sha256)
assert.equal(held169.count, 169)
assert.equal(sha(readFileSync(proposal.parent23Source.path)), proposal.parent23Source.sha256)
for (const row of Object.values(proposal.inputBindings)) assert.equal(sha(readFileSync(row.path)), row.sha256)
assert.equal(sha(readFileSync(proposal.sealedJointGeometry.path)), proposal.sealedJointGeometry.sha256)
type Props = Record<string, unknown> & { children?: ReactNode }
type Row = { kind: "literal" | "fragment" | "primitive" | "unsupported"; type: string; key: string | null; props: Record<string, unknown>; children: Row[]; value?: unknown }
function identity(node: ReactNode): ReactNode {
  if (!isValidElement<Props>(node)) return node
  return cloneElement(node as ReactElement<Props>, { ...node.props }, ...Children.toArray(node.props.children).map(identity))
}
function snapshot(node: ReactNode): Row {
  if (!isValidElement<Props>(node)) {
    const allowed = node === null || node === undefined || ["boolean", "string", "number"].includes(typeof node)
    return { kind: allowed ? "primitive" : "unsupported", type: typeof node, key: null, value: node, props: {}, children: [] }
  }
  const { children, ...props } = node.props, actualType: unknown = node.type
  const kind = typeof actualType === "string" ? "literal" : actualType === Fragment ? "fragment" : "unsupported"
  return { kind, type: kind === "literal" ? actualType as string : kind === "fragment" ? "React.Fragment" : `${typeof actualType}:${String(actualType)}`, key: node.key, props, children: Children.toArray(children).map(snapshot) }
}
const flatten = (row: Row): Row[] => [row, ...row.children.flatMap(flatten)]
const clone = (row: Row): Row => ({ ...row, props: { ...row.props }, children: row.children.map(clone) })
function canonical(v: unknown): string {
  if (Array.isArray(v)) return `[${v.map(canonical).join(",")}]`
  if (v && typeof v === "object") return `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical((v as Record<string, unknown>)[k])}`).join(",")}}`
  if (typeof v === "function") return `function:${v.toString()}`
  if (typeof v === "symbol") return `symbol:${String(v)}`
  return JSON.stringify(v) ?? "undefined"
}
const replacer = (_key: string, v: unknown) => typeof v === "function" ? { diagnosticFunction: v.name, sourceSha256: sha(v.toString()) }
  : typeof v === "symbol" ? { diagnosticSymbol: String(v), globalSymbolKey: Symbol.keyFor(v) ?? null } : v
const normalizedJson = (v: unknown) => JSON.parse(JSON.stringify(v, replacer))
const counts = (rows: Row[]) => ({ reactElements: rows.filter(r => r.kind === "literal" || r.kind === "fragment").length, literalStrings: rows.filter(r => r.kind === "literal").length, fragments: rows.filter(r => r.kind === "fragment").length, primitiveChildren: rows.filter(r => r.kind === "primitive").length, unsupported: rows.filter(r => r.kind === "unsupported").length })
const parent = buildOwnerMoved23Source(), source = buildOwnerMoved24Source()
const actualParent23 = snapshot(parent.element), before = snapshot(identity(parent.element)), after = snapshot(source.element)
const oldRows = flatten(before), newRows = flatten(after)
// Preserve both raw evaluations before inverse assertions. Property presence is checked on live rows below.
writeFileSync(diagnostic, JSON.stringify({ scope: "ACTUAL_SOURCE24_AND_AUTHENTIC_PARENT23_BEFORE_INVERSE_ASSERTIONS", actualParent23Tree: actualParent23, keyNormalizedParent23Tree: before, actualProposedSource24Tree: after, beforeCounts: counts(oldRows), afterCounts: counts(newRows), inverseChecksExecuted: false, circuitConstructed: false, coreRendered: false, all49Accepted: false, fabricationReady: false }, replacer) + "\n", { flag: "wx", mode: 0o600 })
const parentCapture = JSON.parse(readFileSync(proposal.inputBindings.actualParent23Capture.path, "utf8"))
assert.equal(parentCapture.passed, true); assert.equal(parentCapture.fullInverseSourceTreePassed, true)
assert.equal(canonical(normalizedJson(actualParent23)), canonical(parentCapture.actualSourceTree), "Fresh immutable Source23 evaluation equals its genuine held capture")
assert.equal(counts(oldRows).unsupported, 0); assert.equal(counts(newRows).unsupported, 0)
assert.equal(counts(oldRows).reactElements, 2268); assert.equal(counts(newRows).reactElements, 2270)
assert.equal(counts(newRows).literalStrings - counts(oldRows).literalStrings, 2)
assert.equal(counts(newRows).fragments, counts(oldRows).fragments); assert.equal(counts(newRows).primitiveChildren, counts(oldRows).primitiveChildren)
const one = (rows: Row[], label: string) => { assert.equal(rows.length, 1, label); return rows[0] }
const named = (rows: Row[], name: string) => one(rows.filter(r => r.kind === "literal" && r.props.name === name), name)
const fields = ["pcbPath", "pcbPaths", "pcbPathRelativeTo"] as const
const omit = (props: Record<string, unknown>, keys: readonly string[]) => Object.fromEntries(Object.entries(props).filter(([key]) => !keys.includes(key)))
const plan = proposal.source24Delta, movedOld = named(oldRows, plan.movedVia.name), movedNew = named(newRows, plan.movedVia.name)
assert.equal(movedOld.type, "via"); assert.equal(movedNew.type, "via")
assert.deepEqual({ x: movedOld.props.pcbX, y: movedOld.props.pcbY }, plan.movedVia.before)
assert.deepEqual({ x: movedNew.props.pcbX, y: movedNew.props.pcbY }, plan.movedVia.after)
assert.deepEqual(omit(movedOld.props, ["pcbX", "pcbY"]), omit(movedNew.props, ["pcbX", "pcbY"]))
for (const change of plan.routeChanges) {
  const old = named(oldRows, change.logicalName), now = named(newRows, change.logicalName)
  assert.equal(now.type, "trace"); assert.deepEqual(omit(now.props, fields), omit(old.props, fields))
  assert.deepEqual(Object.fromEntries(fields.filter(k => old.props[k] !== undefined).map(k => [k, old.props[k]])), change.beforeRouteProps)
  assert.equal(now.props.pcbPath, undefined); assert.deepEqual(now.props.pcbPaths, change.after.newPcbPaths)
  assert.equal(now.props.pcbPathRelativeTo, change.after.newPcbPathRelativeTo)
}
for (const local of plan.localSuppressions) {
  const old = named(oldRows, local.traceName), now = named(newRows, local.traceName)
  assert.deepEqual(old.props.pcbPath, []); assert.equal(now.props.pcbPath, undefined)
  assert.deepEqual(omit(now.props, ["pcbPath"]), omit(old.props, ["pcbPath"]))
}
for (const port of plan.newTwoInnerPorts) {
  const old = named(oldRows, port.viaName), now = named(newRows, port.viaName)
  assert.equal(old.type, "via"); assert.equal(now.type, "via"); assert.equal(old.children.length, 0); assert.equal(now.children.length, 1)
  const child = now.children[0]; assert.equal(child.kind, "literal"); assert.equal(child.type, "port")
  assert.deepEqual(child.props, { name: "inner1", layer: "inner1" }); assert.deepEqual(child.children, [])
  assert.deepEqual(omit(now.props, ["pcbX", "pcbY"]), omit(old.props, ["pcbX", "pcbY"]))
}
const restored = clone(after), restoredRows = flatten(restored), untouched = canonical(after)
for (const port of plan.newTwoInnerPorts) named(restoredRows, port.viaName).children = []
for (const change of plan.routeChanges) {
  const row = named(restoredRows, change.logicalName), old = named(oldRows, change.logicalName)
  for (const field of fields) { delete row.props[field]; if (Object.prototype.hasOwnProperty.call(old.props, field)) row.props[field] = old.props[field] }
}
for (const local of plan.localSuppressions) {
  const row = named(restoredRows, local.traceName), old = named(oldRows, local.traceName)
  delete row.props.pcbPath; if (Object.prototype.hasOwnProperty.call(old.props, "pcbPath")) row.props.pcbPath = old.props.pcbPath
}
const movedRestored = named(restoredRows, plan.movedVia.name)
movedRestored.props.pcbX = movedOld.props.pcbX; movedRestored.props.pcbY = movedOld.props.pcbY
assert.equal(canonical(restored), canonical(before), "Full inverse: every key, container, child order and property presence outside exact deltas held")
assert.equal(canonical(after), untouched, "Actual proposed tree not mutated by inverse")
for (const [type, expected] of [["via", 227], ["port", 38], ["trace", 1195], ["bus", 8]] as const) assert.equal(newRows.filter(r => r.kind === "literal" && r.type === type).length, expected)
for (const original of proposal.all49OriginalLogicalTraces) {
  const now = named(newRows, original.name); assert.equal(now.type, "trace"); assert.equal(now.props.from, original.from); assert.equal(now.props.to, original.to)
}
writeFileSync(output, JSON.stringify({ scope: "ACTUAL_ROOT_SOURCE24_CAPTURE_WITH_AUTHENTIC_PARENT23_FULL_INVERSE", passed: true, fullInverseSourceTreePassed: true, actualParent23CheckpointHeld: true, proposedReactElementCount: 2270, previousReactElementCount: 2268, genuineNewInnerPortCount: 38, exactNewPortDeclarations: 2, exactChangedOriginalRouteDeclarations: 3, exactChangedLocalSource14Suppressions: 2, exactMovedExistingViaCount: 1, expectedPhysicalVias: 227, expectedPhysicalTraces: 287, expectedCarrierPaths: 24, missingOriginal49RequestsExpected: 25, original49LogicalTracesHeld: true, original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse: true, sourceOnlyProposalSha256: sha(readFileSync(new URL("./source24-proposal.json", import.meta.url))), actualSourceTree: after, actualDiagnosticPath: diagnostic, actualDiagnosticSha256: sha(readFileSync(diagnostic)), pureSourceEvaluationExecuted: true, circuitConstructed: false, coreRendered: false, nativeExecuted: false, cadExecuted: false, automaticCoreSrjForThisForkMustNotBeUsed: true, bothDqs1CoupledViewsRequireFreshOriginalApi: true, singleCoupledSectionCoversBoth: false, referenceQualified: false, electricalTimingPassed: false, all49Accepted: false, fabricationReady: false }, replacer) + "\n", { flag: "wx", mode: 0o600 })
console.log(JSON.stringify({ scope: "ROOT_SOURCE24_CAPTURE_ONLY", passed: true, output, diagnostic, coreRendered: false, fabricationReady: false }))
