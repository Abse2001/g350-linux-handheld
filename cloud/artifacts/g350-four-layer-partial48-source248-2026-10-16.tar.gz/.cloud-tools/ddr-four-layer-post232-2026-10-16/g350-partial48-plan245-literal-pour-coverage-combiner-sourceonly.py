#!/usr/bin/env python3
"""Combine exact Source248 completed selected-pour contributions; no geometry/SDK execution."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path

RAW_SHA = 'c5129a2ec734e873c209ab8cdccf2cad1753d177f1c87857ffae0cf7ff12a486'
CONTROLS_SHA = '5fb5a432d5854a8cccf689070d901ed4823a427cb42ec6487d474c50d081d525'
AUTH_SHA = '28a4e908e638546542d97a21be165d14a7f6ba0c8ec77457e3820ae208cf1e7e'
PLAN_PATH = '/tmp/g350-cap12-48-projector-root-20261016-run245/byte0-result.json'
PLAN_SHA = 'f57834ed51009d0a88df6a70beb6ea188284bae978516d8f389e254295425d64'
CANDIDATE_SHA = 'cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
AUDIT_SOURCE_SHA = '8bca2fe7c63fb3fc74fdc6f2930590d891358b7fff09fcf8d46b08452f07f443'
AUTH_SCOPE = 'EXPLICITLY_PINNED_M48_PLAN245_CAP12_AUTHENTICATED_229_MANUAL_VIA_TRACK_MANUFACTURING_DIAGNOSTIC'
AUTH_POLICY = 'ONLY SourceTrace connected_source_port_ids and connected_source_net_ids; no PCB/copper/via alias/geometric union'
CAP_PROFILE = 'CAP12_TRANSLATE_X_0P79_ONLY'
PENDING = {'source_trace_26'}
LAYERS, EPS, REQUIRED = ['top', 'inner1', 'inner2', 'bottom'], 1e-8, .1016

def require(condition, message):
    if not condition:
        raise ValueError(message)

def pin(path, expected):
    require(len(expected) == 64 and all(c in '0123456789abcdef' for c in expected), 'Explicit lowercase SHA256 required')
    with path.open('rb') as f:
        data = f.read()
        require(hashlib.sha256(data).hexdigest() == expected, 'Input hash mismatch: ' + str(path))
        value = json.loads(data)
        os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return value

def index(rows, key):
    result = {}
    for row in rows:
        value = row.get(key)
        require(isinstance(value, str) and value not in result, 'Unique ' + key + ' required')
        result[value] = row
    return result

def numeric(value):
    return type(value) in (int, float) and math.isfinite(value)

def close(a, b):
    return numeric(a) and numeric(b) and abs(a - b) <= EPS

def xy(row):
    require(numeric(row.get('x')) and numeric(row.get('y')), 'Finite XY required')
    return [row['x'], row['y']]

class Uf:
    def __init__(self):
        self.parent = {}
    def add(self, value):
        self.parent.setdefault(value, value)
    def root(self, value):
        if value not in self.parent:
            return None
        if self.parent[value] != value:
            self.parent[value] = self.root(self.parent[value])
        return self.parent[value]
    def union(self, a, b):
        self.add(a); self.add(b)
        self.parent[self.root(b)] = self.root(a)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('input', 'controls', 'auth', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    for key in ('input-sha', 'controls-sha', 'auth-sha'):
        parser.add_argument('--' + key, required=True)
    parser.add_argument('--report', type=Path, action='append', required=True)
    parser.add_argument('--report-sha', action='append', required=True)
    args = parser.parse_args()
    require((args.input_sha, args.controls_sha, args.auth_sha) == (RAW_SHA, CONTROLS_SHA, AUTH_SHA),
            'Exact actual Source248 raw/control and completed auth250 pins required')
    require(len(args.report) == len(args.report_sha) and len(args.report) > 0 and
            len({p.resolve() for p in args.report}) == len(args.report), 'Each unique contribution needs one explicit report SHA')
    inputs = [('raw', args.input, args.input_sha), ('controls', args.controls, args.controls_sha),
              ('current229Ownership', args.auth, args.auth_sha), ('reviewedSourcePlan245', Path(PLAN_PATH), PLAN_SHA)]
    inputs += [('report_' + str(i), p, s) for i, (p, s) in enumerate(zip(args.report, args.report_sha))]
    require(not args.output.exists() and args.output.resolve() not in {p.resolve() for _, p, _ in inputs}, 'Fresh separate output required')
    loaded = {name: pin(path, digest) for name, path, digest in inputs}
    raw, controls, auth, plan = [loaded[k] for k in ('raw', 'controls', 'current229Ownership', 'reviewedSourcePlan245')]
    all49 = {'source_trace_' + str(i) for i in range(49)}
    routed = set(controls.get('routedOwnerIds', []))
    require(isinstance(raw, list) and controls.get('rawCoreSha256') == RAW_SHA and
            controls.get('partialCoreControlPassed') is True and controls.get('partialDiagnosticReplayControlsPassed') is True and
            len(controls.get('checks', [])) == 35 and all(c.get('passed') is True for c in controls['checks']) and
            controls.get('planSha256') == PLAN_SHA and controls.get('candidateSha256') == CANDIDATE_SHA,
            'Exact fresh Source248 controls, plan245 and candidate243 binding required')
    require(len(routed) == 48 and set(controls.get('pendingOwnerIds', [])) == PENDING and routed | PENDING == all49 and
            controls.get('expectedConnectedOwners') == 48 and controls.get('expectedPendingOwners') == 1,
            'Exact48 connected/pending26 partition required')
    graphs = index(controls.get('physicalGraphs', []), 'originalSourceTraceId')
    projections = index(controls.get('logical49Projection', []), 'originalSourceTraceId')
    require(set(graphs) == all49 and set(projections) == all49 and all(p.get('passed') is True for p in projections.values()) and
            all(graphs[s].get('physicallyConnectedByActualOwnedNumericIdGraph') is (s in routed) for s in all49),
            'All49 exact current logical and physical graphs required')
    require(plan.get('scope') == 'SOURCE33B_PARTIAL_MIXED_JOINED_EDITABLE_PLAN_SOURCE_PROJECTION_ONLY' and
            plan.get('inputBindings', {}).get('candidate', {}).get('sha256') == CANDIDATE_SHA and
            set(plan.get('routedOwnerIds', [])) == routed and set(plan.get('pendingOwnerIds', [])) == PENDING,
            'Exact reviewed cap12 plan245 required')
    n, i, a = len(plan['newVias']), len(plan['innerPortRegistrations']), len(plan['auxiliaryLocalTraces'])
    r = sum(len(g['wireRuns']) for g in plan['projectedGeometry'])
    inventory = {'physicalVias': 129 + n, 'pcbComponents': 409 + n, 'sourceAndPcbPorts': 1419 + 2 * n + i,
                 'sourceTraces': 1097 + a, 'physicalTraces': 165 + r + a, 'reactElements': 2036 + n + i + a,
                 'newVias': n, 'newInnerPorts': i, 'routedWireRuns': r, 'auxiliaryLocalTraces': a,
                 'routedOwners': 48, 'pendingOwners': 1}
    require((n, i, r, a) == (100, 80, 146, 2) and len(plan['replacedOriginals']) == 49 and len(plan['projectedGeometry']) == 48 and
            all(controls.get('expectedCounts', {}).get(k) == v for k, v in inventory.items()), 'Exact actual plan-derived229/313 inventory required')
    cap = plan.get('cap12HardwareDelta', {})
    require(plan.get('hardwareDeltaProfile') == CAP_PROFILE and cap.get('profile') == CAP_PROFILE and
            cap.get('candidateBinding') == plan['inputBindings']['candidate'] and
            cap.get('component', {}).get('sourcePlacement') == {
                'before': {'pcbX': 6, 'pcbY': 4.7, 'layer': 'bottom', 'pcbRotation': 180},
                'after': {'pcbX': 6.79, 'pcbY': 4.7, 'layer': 'bottom', 'pcbRotation': 180}} and
            cap.get('exactPhysicalScope') == {'componentCount': 280, 'heldPlacements': 279,
                'translatedPlacements': 1, 'totalLands': 1165, 'heldLands': 1163, 'translatedSmtPadsAndPorts': 2,
                'totalReferences': 165, 'heldReferences': 163, 'reroutedReferences': 2, 'heldReferenceVias': 129} and
            controls.get('cap12HardwareDeltaProfile') == CAP_PROFILE and controls.get('cap12HardwareDelta') == cap,
            'Exact cap12 hardware ledger and fresh controls required')
    require(auth.get('scope') == AUTH_SCOPE and auth.get('logicalUfPolicy') == AUTH_POLICY and auth.get('complete') is True and
            auth.get('actualViaCount') == 229 and auth.get('completedViaCount') == 229 and
            auth.get('foreignViaTrackCopperClearancePassed') is True and auth.get('exactInputFilesUnchanged') is True and
            auth.get('requiredCopperEdgeClearanceMm') == REQUIRED and
            auth.get('inputBindings', {}).get('raw', {}).get('sha256') == RAW_SHA and
            auth.get('inputBindings', {}).get('controls', {}).get('sha256') == CONTROLS_SHA and
            auth.get('inputBindings', {}).get('plan', {}).get('sha256') == PLAN_SHA and
            auth.get('inputBindings', {}).get('candidate', {}).get('sha256') == CANDIDATE_SHA and
            auth.get('cap12HardwareDelta') == cap, 'Completed exact auth250 ownership/foreign-track scope required')
    for key in ('violations', 'ambiguousVias', 'identityFailures', 'invalidSegments', 'unresolvedSegmentOwners'):
        require(auth.get(key) == [], 'Current ownership report retains failures: ' + key)
    rows = lambda kind: [r for r in raw if r.get('type') == kind]
    pours, vias = index(rows('pcb_copper_pour'), 'pcb_copper_pour_id'), index(rows('pcb_via'), 'pcb_via_id')
    require(len(pours) > 0 and len(vias) == 229, 'Actual raw pour roster and exact229 vias required')
    sources = rows('source_trace')
    declarations = [{'sourceTraceId': r['source_trace_id'], 'connectedSourcePortIds': r.get('connected_source_port_ids', []),
                     'connectedSourceNetIds': r.get('connected_source_net_ids', [])} for r in sources]
    require(auth.get('declaredLogicalSources') == declarations, 'Exact actual Source-only declarations required')
    uf = Uf()
    for row in declarations:
        sid = row['sourceTraceId']; uf.add(sid)
        for value in row['connectedSourcePortIds'] + row['connectedSourceNetIds']:
            uf.union(sid, value)
    via_proofs = index(auth['viaReports'], 'pcbViaId')
    require(set(via_proofs) == set(vias), 'Exact via proof roster required')
    via_roots = {}
    for vid, proof in via_proofs.items():
        require(proof.get('aliasIdentityAuthenticated') is True and proof.get('logicalOwnerResolved') is True and
                proof.get('identityErrors') == [] and proof.get('unresolvedOwnerEvidence') == [] and
                len(proof.get('authenticatedLogicalRoots', [])) == 1 and
                proof.get('selectedLogicalRoot') in proof['authenticatedLogicalRoots'] and proof.get('violationCount') == 0,
                'Unresolved via identity: ' + vid)
        via_roots[vid] = proof['selectedLogicalRoot']
    projection = {p['actualSourceTraceId']: sid for sid, p in projections.items() if sid in routed}
    require(len(projection) == 48, 'Unique actual Source IDs for all48 routed owners required')
    wire_catalog = {}
    for trace in rows('pcb_trace'):
        sid = trace.get('source_trace_id')
        if sid not in projection:
            continue
        route = trace['route']
        for i, (a, b) in enumerate(zip(route, route[1:]), 1):
            if a.get('route_type') != 'wire' or b.get('route_type') != 'wire' or a.get('layer') != b.get('layer'):
                continue
            pa, pb = xy(a), xy(b)
            if math.dist(pa, pb) <= EPS:
                continue
            widths = [a.get('width'), b.get('width'), a.get('end_width', 0), b.get('end_width', 0)]
            require(a['layer'] in LAYERS and all(numeric(v) for v in widths) and max(widths) > 0, 'Unsupported current wire')
            key = trace['pcb_trace_id'] + ':' + str(i)
            require(key not in wire_catalog, 'Duplicate current wire identity')
            wire_catalog[key] = {'pcbTraceId': trace['pcb_trace_id'], 'actualSourceTraceId': sid,
                'originalOwner': projection[sid], 'segmentStartIndex': i - 1, 'segmentEndIndex': i,
                'a': pa, 'b': pb, 'layer': a['layer'], 'radius': max(widths) / 2, 'root': uf.root(sid)}
    require(wire_catalog and all(v['root'] is not None for v in wire_catalog.values()), 'Complete dynamic wire catalogue with declared owners required')
    expected_roster = [{'pcbCopperPourId': p['pcb_copper_pour_id'], 'layer': p.get('layer'),
                        'sourceNetId': p.get('source_net_id'), 'shape': p.get('shape')} for p in pours.values()]
    contributions = []
    baseline_identities = None
    baseline_distance = None
    baseline_policy = None
    for report_index, (path, report_sha) in enumerate(zip(args.report, args.report_sha)):
        label = 'report_' + str(report_index)
        report = loaded[label]
        require(report.get('scope') == 'PARTIAL48_PLAN245_LITERAL_SELECTED_FRESH_BREP_POUR_MARGIN_DIAGNOSTIC' and
                report.get('auditSourceSha256') == AUDIT_SOURCE_SHA and report.get('inputFilesUnchanged') is True,
                'Exact new reviewed Source48 audit and unchanged inputs required')
        expected_bindings = {'raw': RAW_SHA, 'controls': CONTROLS_SHA, 'current229Ownership': AUTH_SHA, 'reviewedSourcePlan245': PLAN_SHA}
        require(all(report.get('inputBindings', {}).get(k, {}).get('sha256') == v for k, v in expected_bindings.items()) and
                report.get('cap12HardwareDelta') == cap and report.get('cap12HardwareDeltaProfile') == CAP_PROFILE and
                report.get('planDerivedInventory') == inventory and report.get('source236GeometryOrPourQualificationInherited') is False,
                'Every contribution must bind exact Source248/cap12/plan245/auth250 inputs')
        selected = report.get('selectedPourIds', [])
        require(selected and len(selected) == len(set(selected)) and set(selected) <= set(pours) and
                report.get('actualRawPourIds') == list(pours) and report.get('actualRawPourRoster') == expected_roster and
                report.get('actualRawPourCount') == len(pours) and
                set(report.get('omittedPourIds', [])) == set(pours) - set(selected) and
                len(report['omittedPourIds']) == len(pours) - len(selected), 'Exact actual/selected/omitted pour roster required')
        require(report.get('coverageScope') == ('EXPLICIT_ALL_ACTUAL_POURS' if set(selected) == set(pours) else 'EXPLICIT_SELECTED_POURS_ONLY') and
                report.get('wireScope') == 'all-routed' and set(report.get('wireOriginalOwners', [])) == routed and
                len(report['wireOriginalOwners']) == 48 and report.get('wireSegmentCount') == len(wire_catalog) and
                report.get('actualViaCount') == 229 and report.get('requiredForeignViaPourEdgeMm') == REQUIRED and
                report.get('requiredForeignWirePourEdgeMm') == REQUIRED and report.get('coordinateToleranceMm') == EPS and
                report.get('sourceRuleBridge') == controls.get('sourceRuleBridge'), 'Exact dynamic geometry scope and unchanged margin thresholds required')
        for key in ('globalIdentityFailures', 'viaIdentityFailures', 'unsupportedGeometry', 'unknownPourIdentities', 'violations'):
            require(report.get(key) == [], 'Contribution retains failures: ' + key)
        require(all(report.get(k) is False for k in ('all49Accepted', 'full49Accepted', 'fullBoardPassed',
                'electricalTimingQualified', 'nativeExecuted', 'cadExecuted', 'fabricationReady')), 'Acceptance boundaries remain false')
        identities = index(report.get('actualViaIdentities', []), 'pcbViaId')
        require(set(identities) == set(vias), 'Exact current229 via identity roster required')
        for vid, row in identities.items():
            require(row.get('failures') == [] and row.get('logicalRoot') == via_roots[vid] and
                    row.get('xy') == xy(vias[vid]) and set(row.get('layers', [])) == set(LAYERS), 'Exact actual via identity and Source-only root required')
        if baseline_identities is None:
            baseline_identities, baseline_distance, baseline_policy = report['actualViaIdentities'], report['distanceModel'], report['netExemptionPolicy']
        require(report['actualViaIdentities'] == baseline_identities and report['distanceModel'] == baseline_distance and
                report['netExemptionPolicy'] == baseline_policy, 'One exact geometry/exemption model across all contributions required')
        reports = index(report.get('pourReports', []), 'pcbCopperPourId')
        require(set(reports) <= set(selected), 'No contribution outside its explicit selected subset')
        is_completed = set(reports) == set(selected) and all(p.get('state') == 'COMPLETED' for p in reports.values())
        require(report.get('completed') is is_completed and report.get('literalForeignPourMarginClear') is is_completed and
                report.get('allActualPoursCompleted') is (is_completed and set(selected) == set(pours)), 'Retain exact selected and whole-coverage status')
        contributions.append((label, report))
    completed, excluded = {}, []
    for label, report in contributions:
        reports = index(report['pourReports'], 'pcbCopperPourId')
        exemptions = report['sameNetExemptions']
        for pid, pr in reports.items():
            require(pid in pours, 'Unknown reported pour')
            if pr.get('state') != 'COMPLETED':
                require(pr['state'] == 'BOUNDED_PARTIAL', 'Only explicitly bounded partial results may be excluded; unsupported/running results never qualify')
                excluded.append({'report': label, 'pcbCopperPourId': pid, 'state': pr['state'],
                                 'viaChecksExcluded': len(pr['viaChecks']), 'wireChecksExcluded': len(pr['wireChecks'])})
                continue
            require(pid not in completed, 'Duplicate completed pour coverage')
            pour = pours[pid]; root = uf.root(pour['source_net_id']); layer = pour['layer']
            require(root is not None and pour['shape'] == 'brep' and pr['layer'] == layer and
                    pr['sourceNetId'] == pour['source_net_id'] and pr['logicalRoot'] == root and pr['violations'] == [], 'Completed pour metadata mismatch')
            require(pr['outerVertices'] == len(pour['brep_shape']['outer_ring']['vertices']) and
                    pr['innerRings'] == len(pour['brep_shape'].get('inner_rings', [])), 'Literal BREP roster mismatch')
            expected_vias = {k for k in vias if via_roots[k] != root}
            expected_wires = {k for k, v in wire_catalog.items() if v['layer'] == layer and v['root'] != root}
            own_vias = set(vias) - expected_vias
            own_wires = {k for k, v in wire_catalog.items() if v['layer'] == layer and v['root'] == root}
            via_checks, wire_checks = index(pr['viaChecks'], 'identity'), index(pr['wireChecks'], 'identity')
            require(set(via_checks) == expected_vias and set(wire_checks) == expected_wires, 'Exact per-pour foreign object coverage required')
            ex = [v for v in exemptions if v['pour'] == pid]
            via_ex = [v for v in ex if v['kind'] == 'via']; wire_ex = [v for v in ex if v['kind'] == 'wire']
            require(len(ex) == len(via_ex) + len(wire_ex) == pr['sameNetExemptionCount'] and
                    len(via_ex) == len(own_vias) and {v['identity'] for v in via_ex} == own_vias and
                    len(wire_ex) == len(own_wires) and {v['identity'] for v in wire_ex} == own_wires and
                    all(v['layer'] == layer and v['authenticatedLogicalRoot'] == root and v['ownNetReentryQualified'] is False for v in ex), 'Authenticated exact same-net exemption roster required')
            gaps = []
            for kind, checks in (('via', via_checks), ('wire', wire_checks)):
                for identity, check in checks.items():
                    require(check.get('kind') == kind and check.get('layer') == layer and check.get('passed') is True and
                            check.get('requiredMm') == REQUIRED and check.get('pourLogicalRoot') == root and
                            numeric(check.get('edgeClearanceMm')) and check['edgeClearanceMm'] >= REQUIRED - EPS and
                            check.get('overlap') is False and close(check.get('centerlineDistanceToFilledPourMm', float('nan')) - check.get('copperRadiusMm', float('nan')), check['edgeClearanceMm']),
                            'Every completed foreign comparison must pass its unchanged threshold')
                    if kind == 'via':
                        require(check['xy'] == xy(vias[identity]) and check['objectLogicalRoot'] == via_roots[identity] and
                                close(check['copperRadiusMm'], vias[identity]['outer_diameter'] / 2) and set(check['allPhysicalLayers']) == set(LAYERS), 'Via comparison geometry mismatch')
                    else:
                        v = wire_catalog[identity]
                        require(all(check.get(k) == value for k, value in v.items()) and check['objectLogicalRoot'] == v['root'] and
                                close(check['copperRadiusMm'], v['radius']), 'Wire comparison geometry mismatch')
                    gaps.append(check['edgeClearanceMm'])
            completed[pid] = {'pcbCopperPourId': pid, 'sourceReport': label, 'layer': layer, 'state': 'COMPLETED',
                              'foreignViaChecks': len(via_checks), 'foreignWireChecks': len(wire_checks),
                              'sameNetExemptions': len(ex), 'minimumForeignEdgeGapMm': min(gaps) if gaps else None,
                              'zeroViolations': True}
    require(set(completed) == set(pours), 'Every actual pour must have exactly one fully reconstructed completed contribution')
    report = {'scope': 'SOURCE248_PLAN245_ALL_ACTUAL_LITERAL_POURS_COMPLETED_COVERAGE_AGGREGATE_NOT_BOARD_QUALIFICATION',
        'inputBindings': {name: {'path': str(path), 'sha256': digest} for name, path, digest in inputs},
        'auditSourceSha256': AUDIT_SOURCE_SHA, 'candidate243Sha256': CANDIDATE_SHA,
        'actualRawPourIds': list(pours), 'actualRawPourRoster': expected_roster,
        'actualRawPourCount': len(pours), 'completedPourCount': len(completed),
        'completedPourIds': list(pours), 'completedPourReports': [completed[pid] for pid in pours],
        'excludedBoundedPartialReports': excluded,
        'actualViaCount': 229, 'wireSegmentCount': len(wire_catalog), 'wireOwnerCount': 48,
        'planDerivedInventory': inventory, 'cap12HardwareDeltaProfile': CAP_PROFILE, 'cap12HardwareDelta': cap,
        'requiredForeignViaPourEdgeMm': REQUIRED, 'requiredForeignWirePourEdgeMm': REQUIRED,
        'coordinateToleranceMm': EPS, 'identityFailures': [], 'unsupportedGeometry': [], 'violations': [],
        'allCompletedComparisonRostersReconstructedFromExactRaw': True,
        'sameExactRawControlsAuthAcrossAllContributions': True,
        'completed': True, 'literalForeignPourMarginClear': True,
        'minimumForeignEdgeGapMm': min(v['minimumForeignEdgeGapMm'] for v in completed.values() if v['minimumForeignEdgeGapMm'] is not None),
        'source236GeometryOrPourQualificationInherited': False,
        'all49Accepted': False, 'full49Accepted': False, 'fullBoardPassed': False, 'electricalTimingQualified': False,
        'referenceQualified': False, 'ownNetReentryQualified': False, 'referenceWireGeometryIncluded': False,
        'nativeExecuted': False, 'cadExecuted': False, 'fabricationReady': False,
        'scopeLimits': ['Only exact Source248 actual229 vias and current48 routed-owner wire segments against its complete literal raw pour roster.',
                        'Only completed contributions are used; bounded partial entries and all their comparison rows are excluded.',
                        'No earlier Source236 result, full-board, own-net reentry, reference, TI, delay, CAD or fabrication qualification is inherited.']}
    def file_sha(path):
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(block)
        return digest.hexdigest()
    require(all(file_sha(path) == digest for _, path, digest in inputs), 'Every pinned input and contribution must remain byte-identical')
    report['inputFilesUnchanged'] = True
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({'completedPours': len(completed), 'actualVias': 229, 'routedWireSegments': len(wire_catalog),
                      'literalForeignPourMarginClear': True, 'all49Accepted': False, 'geometryExecutedByCombiner': False}))

if __name__ == '__main__':
    main()
