/** SOURCE ONLY: compose the frozen cap12 replay with the exact cap8 / two-PDN
 * Source declarations. This module never renders Core, assigns IDs, or claims
 * that regenerated plane polygons connect the new barrels to the old rails. */
// @ts-ignore Exact managed React runtime, matching the frozen parent overlay.
import ReactRuntime from '/workspace/g350-linux-handheld/node_modules/react/index.js'
import type * as ReactTypes from '/workspace/g350-linux-handheld/node_modules/@types/react/index'
import {
  buildAll49SourceReplay as buildCap12Replay,
  deriveAll49ReplayExpectedCounts as baseCounts,
  registerAll49SourceReplayInnerPorts as registerSignalPorts,
  snapshotAll49ReplaySource,
  inverseAll49ReplaySnapshot,
  inverseAll49ReplayParentNormalization,
} from '/tmp/g350-cap12point79-partial-replay-overlay-sourceonly.ts'
import type { All49ReplayPlan as Cap12Plan, ReplayAuditPlan as Cap12Audit,
  LiteralSnapshot } from '/tmp/g350-cap12point79-partial-replay-overlay-sourceonly.ts'
export { snapshotAll49ReplaySource, inverseAll49ReplaySnapshot, inverseAll49ReplayParentNormalization }
export type { LiteralSnapshot }

type Row = Record<string, any>
type Node = ReactTypes.ReactNode
type Props = Row & { children?: Node }
const { cloneElement, createElement, isValidElement }: typeof ReactTypes = ReactRuntime
export const CAP8_PROFILE = 'CAP8_AT_0_7P9_TWO_NEW_PLANE_VIAS_VDD7P2' as const
export const CAP8_PROOF_SHA = 'ec002642c791f3fdcd041e647202712020f9acccf20ced6e22302db20c5601c3'
const LAYERS = ['top', 'inner1', 'inner2', 'bottom']
const INNER = ['inner1', 'inner2']
const SPECS = [
  { name: 'TI_HS_C_DDR_RAM_8_POWER', sid: 'source_trace_986', from: 'C_DDR_RAM_8.pin1',
    oldTo: '.V_TI_HS_C_DDR_RAM_8_POWER > port.bottom', viaName: 'V_CAP8_REPLAY_DDR_1V5',
    connectsTo: 'net.DDR_1V5', xy: { x: .4, y: 7.2 },
    points: [{ x: .420116, y: 7.9 }, { x: .420116, y: 7.220116 }, { x: .4, y: 7.2 }] },
  { name: 'TI_HS_C_DDR_RAM_8_GROUND', sid: 'source_trace_987', from: 'C_DDR_RAM_8.pin2',
    oldTo: '.V_TI_HS_C_DDR_RAM_8_GROUND > port.bottom', viaName: 'V_CAP8_REPLAY_GND',
    connectsTo: 'net.GND', xy: { x: -1.6, y: 7.4 },
    points: [{ x: -.420116, y: 7.9 }, { x: -1.4, y: 7.9 }, { x: -1.6, y: 7.7 }, { x: -1.6, y: 7.4 }] },
]
const check = (v: unknown, message: string): void => { if (!v) throw Error(message) }
const canonical = (v: any): string => Array.isArray(v) ? `[${v.map(canonical).join(',')}]`
  : v && typeof v === 'object' ? `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`
  : typeof v === 'function' ? `function:${v.toString()}` : typeof v === 'symbol' ? `symbol:${String(v)}` : JSON.stringify(v) ?? 'undefined'
const same = (a: unknown, b: unknown) => canonical(a) === canonical(b)
const own = (v: object, key: string) => Object.prototype.hasOwnProperty.call(v, key)
const flatten = (r: LiteralSnapshot): LiteralSnapshot[] => [r, ...r.children.flatMap(flatten)]
export interface All49ReplayPlan extends Cap12Plan { cap8HardwareDelta: Row }
export interface ReplayAuditPlan extends Cap12Audit {
  cap8HardwareDelta: Row
  combinedHardwareProfile: string
  combinedHardwareExpectations: Row
}

function validateDelta(plan: All49ReplayPlan): void {
  const d = plan.cap8HardwareDelta
  check(d?.profile === CAP8_PROFILE && d.proofBinding?.sha256 === CAP8_PROOF_SHA
    && typeof d.proofBinding.path === 'string' && d.freshCoreDerived === false
    && d.capturedIdsAreMappingProvenanceOnly === true, 'Exact unexecuted cap8 proof binding')
  check(plan.routedOwnerIds.length === 49 && plan.pendingOwnerIds.length === 0
    && plan.auxiliaryLocalTraces.length === 0, 'This successor requires a complete49 geometry candidate; timing acceptance remains separate')
  check(d.component?.name === 'C_DDR_RAM_8' && same(d.component.sourcePlacement, {
    before: { pcbX: 1.2, pcbY: 9.799999999999999, layer: 'bottom', pcbRotation: 0 },
    after: { pcbX: 0, pcbY: 7.9, layer: 'bottom', pcbRotation: 0 },
  }), 'Exact original and planned cap8 Source placement')
  check(Array.isArray(d.references) && d.references.length === 2 && Array.isArray(d.pdnVias)
    && d.pdnVias.length === 2 && Array.isArray(d.innerPortRegistrations)
    && d.innerPortRegistrations.length === 4, 'Two references, two real new PDN vias, four actual inner aliases')
  for (const s of SPECS) {
    const refs = d.references.filter((r: Row) => r.literalTraceName === s.name)
    const vias = d.pdnVias.filter((r: Row) => r.name === s.viaName)
    check(refs.length === 1 && vias.length === 1, 'Unique exact cap8 reference and added PDN via')
    const r = refs[0], v = vias[0], to = `.${s.viaName} > port.bottom`
    check(r.name === s.name && r.originalSourceTraceId === s.sid && r.fromSelector === s.from
      && r.beforeToSelector === s.oldTo && r.toSelector === to && r.width === .2
      && same(r.absolutePoints, s.points) && same(r.beforeRouteProps, { pcbPath: [] })
      && same(r.afterRouteProps, { pcbPaths: [[s.from, ...s.points.slice(1, -1).map(p => ({ x: p.x, y: p.y - 20 })), to]],
        pcbPathRelativeTo: 'U_SOC.pin7' }), 'Exact .2 Bottom reference, real selectors and CPU-origin coordinates')
    check(v.x === s.xy.x && v.y === s.xy.y && v.connectsTo === s.connectsTo
      && v.fromLayer === 'top' && v.toLayer === 'bottom' && same(v.layers, LAYERS)
      && v.outerDiameter === .4572 && v.holeDiameter === .254 && v.tented === 'top_and_bottom_tented'
      && same(v.innerLayers, INNER) && v.plannedIdsAreSourceIdentitiesOnly === true
      && v.futureFreshIds === null, 'Named physical PDN barrel with genuine net selector; no new authentic IDs yet')
    check(!plan.newVias.some(q => q.name === v.name) && !plan.removeViaNames.includes(v.name),
      'PDN declarations remain separate from the original49 signal-via inventory')
    for (const layer of INNER) {
      const reqs = d.innerPortRegistrations.filter((p: Row) => p.viaName === v.name && p.layer === layer)
      check(reqs.length === 1 && same(reqs[0].xy, s.xy), 'One genuine inner-child request per new PDN via layer')
    }
  }
  check(d.sourceEndpointInverses?.length === 2
    && SPECS.every(s => d.sourceEndpointInverses.filter((r: Row) => r.originalSourceTraceId === s.sid
      && r.beforeSelector === s.oldTo && r.afterSelector === `.${s.viaName} > port.bottom`).length === 1),
    'Both original reference logical endpoint changes have explicit captured-to-planned inverses')
}

export function deriveAll49ReplayExpectedCounts(plan: All49ReplayPlan): Row {
  validateDelta(plan)
  const b = baseCounts(plan), P = plan.cap8HardwareDelta.pdnVias.length
  const J = plan.cap8HardwareDelta.innerPortRegistrations.length
  return { ...b, originalReferenceVias: 129, addedPdnReferenceVias: P,
    referenceVias: 129 + P, physicalVias: b.physicalVias + P,
    pcbComponentsIncludingViaAliases: b.pcbComponentsIncludingViaAliases + P,
    expectedSourcePorts: b.expectedSourcePorts + 2 * P + J,
    innerLiteralPorts: b.innerLiteralPorts + J, generatedPdnInnerPorts: J,
    expectedReactElements: b.expectedReactElements + P + J,
    allOriginalReferenceViasHeld: true, signalGeneratedFullspanVias: plan.newVias.length,
    sourceTracesAddedByNetOnlyViaConnectsTo: 0, fullBoardPassed: false }
}

export function buildAll49SourceReplay(parentInput: Node, plan: All49ReplayPlan): {
  parentElement: Node; element: Node; auditPlan: ReplayAuditPlan; expectedCounts: Row;
} {
  validateDelta(plan)
  const base = buildCap12Replay(parentInput, plan), before = snapshotAll49ReplaySource(base.element)
  const beforeRows = flatten(before), d = plan.cap8HardwareDelta
  for (const v of d.pdnVias) check(!beforeRows.some(r => r.props.name === v.name), 'New PDN name absent from every parent literal')
  const propertyEdits = [...base.auditPlan.propertyEdits], changed = new Set<string>()
  let boards = 0
  function fork(node: Node): Node {
    if (Array.isArray(node)) { const rows = node.map(fork); return rows.every((r, i) => r === node[i]) ? node : rows }
    if (!isValidElement<Props>(node)) return node
    const beforeProps: Props = { ...node.props }; delete beforeProps.children
    const props = { ...beforeProps }, name = String(props.name ?? ''), s = SPECS.find(r => r.name === name)
    const cap = name === 'C_DDR_RAM_8', change = cap || !!s
    if (cap) {
      check(node.type === 'capacitor' && !changed.has(name) && props.pcbX === 1.2
        && props.pcbY === 9.799999999999999 && props.layer === 'bottom' && props.pcbRotation === 0,
        'One exact original cap8 literal')
      Object.assign(props, d.component.sourcePlacement.after)
    } else if (s) {
      check(node.type === 'trace' && !changed.has(name) && same(beforeProps,
        { from: s.from, to: s.oldTo, name: s.name, thickness: .2, pcbPath: [] }), 'Exact original cap8 reference literal')
      delete props.pcbPath; delete props.pcbPaths; delete props.pcbPathRelativeTo
      const r = d.references.find((q: Row) => q.literalTraceName === name)
      props.to = r.toSelector; Object.assign(props, r.afterRouteProps)
    }
    const oldChildren = node.props.children
    let newChildren = fork(oldChildren)
    if (node.type === 'board') {
      check(++boards === 1 && Array.isArray(newChildren), 'One exact normalized board child array')
      newChildren = [...newChildren, ...d.pdnVias.map((v: Row) => createElement('via', {
        key: `CAP8-PDN-${v.name}`, name: v.name, pcbX: v.x, pcbY: v.y,
        fromLayer: 'top', toLayer: 'bottom', outerDiameter: .4572, holeDiameter: .254,
        tented: 'top_and_bottom_tented', connectsTo: v.connectsTo,
      }, ...INNER.map(layer => createElement('port', { key: layer, name: layer, layer }))))]
    }
    if (!change && newChildren === oldChildren) return node
    if (!change) return cloneElement(node, { children: newChildren })
    changed.add(name); propertyEdits.push({ name, type: String(node.type), beforeProps, afterProps: { ...props } })
    const exactProps: Props & { key?: string } = { ...props }
    if (node.key !== null) exactProps.key = String(node.key)
    if (own(node.props, 'children')) exactProps.children = newChildren
    return createElement(node.type, exactProps)
  }
  const element = fork(base.element), after = snapshotAll49ReplaySource(element), rows = flatten(after)
  check(boards === 1 && changed.size === 3, 'Exactly cap8 and its two reference literals plus two Via declarations')
  const expectedCounts = deriveAll49ReplayExpectedCounts(plan)
  const hardware = { realComponents: 280, heldRealComponents: 278, movedRealComponents: 2,
    originalCopperLands: 1165, heldCopperLands: 1161, movedCopperLands: 4,
    referencePaths: 165, heldReferencePaths: 161, changedReferencePaths: 4,
    originalReferenceVias: 129, heldOriginalReferenceVias: 129, addedPdnReferenceVias: 2,
    numericSignalPadLocationsHeld: true, capturedIdsAreComparisonProvenanceOnly: true,
    freshCoreDerived: false, regeneratedPlaneContinuityQualified: false, sourceHardwareNativeQualified: false }
  const auditPlan: ReplayAuditPlan = { ...base.auditPlan, propertyEdits, expectedCounts,
    addedViaNames: [...base.auditPlan.addedViaNames, ...d.pdnVias.map((v: Row) => v.name)],
    combinedHardwareProfile: 'CAP12_X0P79_CAP8_TWO_NEW_PDN_VIAS', cap8HardwareDelta: d,
    combinedHardwareExpectations: hardware, cap12HeldHardwareExpectations: hardware,
    effectiveConstraintBridge: { ...base.auditPlan.effectiveConstraintBridge,
      cap12OnlyStageExpectations: base.auditPlan.cap12HeldHardwareExpectations,
      cap12HeldHardwareExpectations: hardware, combinedHardwareExpectations: hardware,
      cap8HardwareDelta: d, original49SignalLogicalEndpointsAndAllRulesHeld: true,
      powerReferenceEndpointChangesAreExplicit: true, regeneratedPlaneContinuityQualified: false,
      cap8SourceHardwareApplied: true, freshCoreDerived: false,
      all49Accepted: false, electricalTimingPassed: false, fullBoardPassed: false, fabricationReady: false } }
  const normalizedParent = snapshotAll49ReplaySource(base.parentElement)
  check(same(inverseAll49ReplaySnapshot(after, auditPlan), normalizedParent), 'Exact combined hardware, added-via and signal inverse to parent')
  check(same(inverseAll49ReplayParentNormalization(normalizedParent, auditPlan), snapshotAll49ReplaySource(parentInput)),
    'Exact original parent key inverse remains required')
  check(rows.filter(r => r.kind === 'literal' || r.kind === 'fragment').length === expectedCounts.expectedReactElements
    && rows.filter(r => r.type === 'via').length === expectedCounts.physicalVias
    && rows.filter(r => r.type === 'port').length === expectedCounts.innerLiteralPorts
    && rows.filter(r => r.type === 'trace').length === expectedCounts.sourceTraces,
    'Dynamic Source declarations include signal and explicitly added PDN material exactly once')
  return { ...base, element, auditPlan, expectedCounts }
}

/** Register actual unrendered inner Port children only. Their real fresh IDs
 * remain absent until Root runs Core; the net comes from genuine connectsTo. */
export function registerAll49SourceReplayInnerPorts(circuit: any, plan: All49ReplayPlan): Row {
  validateDelta(plan)
  const signal = registerSignalPorts(circuit, plan)
  check(!circuit._hasRenderedAtleastOnce && circuit.schematicDisabled === true, 'Unrendered PCB-only real Circuit')
  const registrations: Row[] = []
  for (const r of plan.cap8HardwareDelta.innerPortRegistrations) {
    const via = circuit.selectOne(`.${r.viaName}`), port = circuit.selectOne(`.${r.viaName} > port.${r.layer}`, { type: 'port' })
    const v = plan.cap8HardwareDelta.pdnVias.find((q: Row) => q.name === r.viaName)
    check(v && via?.componentName === 'Via' && via.props.name === v.name && via.props.connectsTo === v.connectsTo
      && via.props.pcbX === v.x && via.props.pcbY === v.y && via.props.fromLayer === 'top' && via.props.toLayer === 'bottom'
      && via.props.outerDiameter === .4572 && via.props.holeDiameter === .254
      && port?.componentName === 'Port' && port.parent === via && port.props.name === r.layer && port.props.layer === r.layer
      && port.getAvailablePcbLayers().join(',') === r.layer && !port.source_port_id && !port.pcb_port_id
      && !via.pcb_via_id && !via.source_manually_placed_via_id && port.matchedComponents.every((q: unknown) => q === via),
      'One genuine new PDN inner Port and its exact declared fullspan net-connected Via')
    if (!port.matchedComponents.includes(via)) port.registerMatch(via)
    check(port.matchedComponents.length === 1 && port.matchedComponents[0] === via, 'Exact real PDN alias owner match')
    registrations.push({ ...r, futureFreshIds: null })
  }
  return { signal, pdnRegistrations: registrations, generatedPdnInnerCount: registrations.length,
    extraPhysicalViaFromPortRegistration: false, rawCircuitIdsAssigned: false, coreRendered: false,
    regeneratedPlaneContinuityQualified: false, fabricationReady: false }
}
