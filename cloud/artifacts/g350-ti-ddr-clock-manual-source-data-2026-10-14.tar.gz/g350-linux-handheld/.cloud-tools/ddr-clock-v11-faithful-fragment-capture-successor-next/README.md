This immutable source-only successor fixes actual capture91494's failure on a
React.Fragment container. It preserves d011 Source geometry/module, guard46701,
its independent review and the actual failed result/logs. No Source/types/Core/
Native/CLI/CAD/preflight command ran while preparing this successor.

The capture worker now recognizes ONLY the actual imported `React.Fragment`
Symbol. It records the container kind/type, React key, props and child order
through the same inverse projection. A different Symbol or a function element
type remains unsupported. Containers are neither removed nor flattened away.
Primitive child values are retained. Before type/count/inverse assertions, the
worker writes both actual trees and their classified inventories to an exclusive
diagnostic file; an error leaves that diagnostic intact.

The earlier passing package capture counted every valid React element, which
includes Fragment containers. This worker checks the unchanged **2228→2232 total
React elements**, separately reports literal-string and Fragment counts, and
requires exactly four added literal Port elements and unchanged container count.
The full inverse still recovers every original definition/type/key/prop/child
order and all returned Source metadata. No string-only count is invented before
the actual tree is evaluated. Source branch/property deltas remain six elements,
eight PCB-only properties and four real Port children.

The capture policy alone changes from512 MiB to1 GiB, with the same60 seconds,
30 GiB shared threshold and1 GiB prefork reserve. The semantic failure occurred
at a measured524,677,120-byte peak, close to the old536,870,912-byte limit, without
OOM. More memory accommodates complete before-assertion tree diagnostics; it
does not change the semantic/inverse requirements. The new limit is untested.
Types remains120 seconds/2 GiB with the exact successful47841 compiler flags;
Core remains90 seconds/2 GiB with the unchanged d011 worker. Both remain unrun.

Every original guard binding remains:141 Source imports, complete boardCe3 and
solver47633 inventories, original7bd process ownership, real42982/9f collection,
mandatory50372 closure and all actual prior successful stage receipts. The
actual failed91494 collection is additionally mandatory; its wrapper2/child1
are preserved. Later Root scopes must be closed and bound before launching.
The false authority template supplies no permission. Root must read and
authorize this exact successor after its independent finite review.

Root invocation with a fresh exact authority and unique nonce:

```bash
source cloud/env.sh
python3 -B .cloud-tools/ddr-clock-v11-faithful-fragment-capture-successor-next/guard.py \
  --run --phase capture --root-receipt ROOT_RECEIPT_PATH \
  --root-receipt-sha256 ROOT_RECEIPT_SHA256
```

The placeholders are for Root's actual receipt, not the false template. Types
needs a collected successful capture; Core needs that capture and successful
types. Failure outputs remain exclusive and immutable. Frozen ancestors still
load Core module definitions; capture invokes no Circuit constructor or render.
Separate Native/ownership qualification and supported fresh circuit-JSON export
remain future work. `accepted49=false`; `fabricationReady=false`.
