Resume routing from Source289: all49 actual numeric DDR graphs, Core35/35.
Both original .635mm byte skews PASS; CA FAILS17.6628187566mm skew.15/26 CA
members meet unchanged20.95mm minimum;11 remain below. Original constraints stay.
Native290+294 executed the exact disjoint original32 calls with0 exceptions.
ALL951 findings remain:70 missing board source paths,718 unconnected PCB ports,
162 width warnings (0 for direct49 DDR logical declarations),1 CA bus-skew.
Native board qualification and full board acceptance remain FALSE.
Auth291 checks234 real vias with no foreign via-track/unknown-owner omissions.
Current Source28919 literal pours are NOT independently qualified. No Source272
pour/PDN/CAD result is inherited. Source272 stock export285 is a separate data
artifact; no current Source289 CAD/plane/TI/SI/default/fabrication pass is claimed.

This is a new /tmp-staged checkpoint, canonical archive member folder:
.cloud-tools/ddr-four-layer-post274-2026-10-16. Earlier frozen folders stay intact.
Cut275–294 includes275 admission refusal,276/277 exit2 failures, actual294 all16
completed in162s (NOT timeout),292/293 PRoot prerequisites (NOT KiCad results).
All295+ CAD work is excluded. PRoot is path translation, not kernel RO/network
isolation. ROOTFS.json is evidence only:1.5GB image/rootfs material is not copied.

Restore five prior archives209→228→248→257→272-v2 before this archive. Restore
this canonical folder, then use the pinned existing workspace helper with
--saved-directory <folder> (verify first; --restore refuses differing files).
solverSourceRoot is carried literally. Workspace export/rootfs-manifest copies
are data-only artifacts in workspaceEvidenceCopies; the legacy /tmp helper does
not overwrite workspace inputs. PRoot packages/tools/rootfs and their aliases
require separately reviewed exact reconstruction; no CAD readiness is implied.
No collector SDK, archive, Docker/PRoot, helper, or git execution occurred.
