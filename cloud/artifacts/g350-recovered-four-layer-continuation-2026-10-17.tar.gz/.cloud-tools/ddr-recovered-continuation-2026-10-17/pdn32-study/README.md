# Unaccepted PDN32 / C16 reconstruction

This is a fresh finite stdlib-only study against hash-pinned Model328 and
Source333. Run `python3 reconstruct.py` from any directory. It imports no SDK,
Bun, Node or CAD and has 58-second wall / 55-second CPU / 1-GiB address limits.
Accepted source, tracked files and frozen evidence are never edited.

The same C_DDR_CPU_16 capacitor changes only Y=16.3 to 16.23. The same actual
DDR_1V5 PowerVia32 changes (1.6,16) to (.8,16.84); its source identity32,
component312, physical barrel32, aliases1225/1226, standard dimensions and four
physical layers remain. All other128 original PDN barrels and both previously
added C8 PDN barrels remain. Three real .2-mm reference traces are repaired;
all49 DDR bodies remain unchanged. Packet inverses bind true source ports701,
702 and CPU83/sourcePort82, source tree nodes, typed rows, obstacle rows and
physical reference records. Both alternative ground routes have equal length.

The changed-geometry screen checks both reference options against all49 joined
DDR routes, all260 held fixed bodies, all1300 obstacles and105 joined DDR via
events. It retains .1016-mm foreign copper margins, .15-mm pad-to-pad margins
and .254-mm drill edge spacing (including same-net barrels). All comparisons
have zero findings. Via32's tightest margin is .007944961883 mm beyond the
.1016-mm copper requirement at CPU pad100. The moved ground pad's tightest
gap to Source35 is .111915523399 mm. Physical real-pad and own-via terminal
exit/no-reentry screens also pass. No physical pins change, source logical
directions change or fake barrel IDs are introduced.

This does not qualify a new Source, native DRC or a combined ODT route. The
source pcbPath proposals require exact Root replay and native validation.
The proposed via center lies inside OLD Inner1 GND pour0 and Inner2 DDR_1V5
pour49; frozen fills must never be copied onto the proposal. Fresh pours,
foreign/own-net checks and electrical reference continuity remain necessary.
No original board state was replaced; fabricationReady remains false.
