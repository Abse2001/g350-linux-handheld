from pathlib import Path
import argparse, hashlib, importlib.util, json, re, stat, sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent/'g350-ti-v12e-c-handoff-length-prune-runtime128-public-next'
BASE = ROOT.parent/'g350-count-conditioned-site-recovery-next'
POLICY = {'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
RESERVE = 2*1024**3
BUN = '/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path); loaded=importlib.util.module_from_spec(spec);spec.loader.exec_module(loaded);return loaded
def verify():
    raw=(ROOT/'SOURCE-manifest.json').read_bytes();packet=json.loads(raw)
    for row in packet['files']+packet['externalFiles']:
        path=Path(row['path']);assert path.is_file() and not path.is_symlink()
        assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes'] and stat.S_IMODE(path.stat().st_mode)==row['mode'],str(path)
    task=Path(packet['originalTaskPath']).read_bytes()
    assert hashlib.sha256(task[1267:1267+6216]).hexdigest()==packet['originalTaskGeneratorPrefixSha256']
    parent=module('held_runtime128_c_source',PARENT/'global-selection-guard.py');parent.prepared()
    previous=json.loads(Path(packet['reusedLocalProofRootReceiptPath']).read_bytes())
    assert previous['sessionId']==26082 and previous['collectedExitCode']==0 and previous['sourceAndDependenciesHeld'] is True
    assert previous['execution']['cleanupOwnedGroupEmpty'] is True and not any(previous['execution']['oomDelta'].values())
    assert previous['resultSha256']==packet['reusedLocalProofResultSha256']
    scope=module('original_local_dogbone_owned_scope',BASE/'process_scope.py')
    assert not scope.owned(previous['execution']['pgid'])
    return packet,hashlib.sha256(raw).hexdigest(),parent,scope
def closed_public(auth,scope):
    closed_path=Path(auth['previousPublicCollectedReceiptPath'])
    assert closed_path.parent==ROOT.parent/'root-routing-progress'
    assert sha(closed_path)==auth['previousPublicCollectedReceiptSha256']
    closed=json.loads(closed_path.read_bytes());assert closed['sessionId']==78137
    assert type(closed['toolExitCode']) is int, 'Root must collect the public tool session before launch'
    assert closed['sourceAndDependenciesHeld'] is True
    post_path=PARENT/'EXECUTION-postaudit.json'
    assert sha(post_path)==auth['previousPublicPostauditSha256']==closed['postauditSha256']
    post=json.loads(post_path.read_bytes());assert post['sourceAndArtifactHeld'] is True and post['dependenciesBefore']==post['dependenciesAfter']
    execution=post['execution'];assert execution==closed['execution']
    assert execution['endedAt'] and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values())
    assert not scope.owned(execution['pgid'])
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--preflight-only',action='store_true');parser.add_argument('--run',action='store_true');parser.add_argument('--root-receipt');parser.add_argument('--root-receipt-sha256');args=parser.parse_args()
    packet,packet_sha,parent,scope=verify()
    if args.preflight_only: print(json.dumps({'preflightPassed':True,'packetSha256':packet_sha,'sourceOnly':True,'workerStarted':False}));return 0
    assert args.run and args.root_receipt and args.root_receipt_sha256
    auth=json.loads(Path(args.root_receipt).read_bytes())
    assert sha(args.root_receipt)==args.root_receipt_sha256 and auth['authorizedByRoot'] is True and auth['scope']==packet['scope'] and auth['packetSha256']==packet_sha and auth['policy']==POLICY and re.fullmatch('[0-9a-f]{32,128}',auth['approvalToken'])
    closed_public(auth,scope)
    assert not (ROOT/'run').exists()
    before=parent.dependency_check();baseline=scope.memory()
    def gate(now):
        assert now['current']+POLICY['rssBytes']+RESERVE<POLICY['sharedBytes'],'Strict prefork reserve required'
        assert all(now['events'][key]==baseline['events'][key] for key in scope.OOM_KEYS)
    execution=scope.run_guarded([BUN,'--smol',str(ROOT/'diagnose.ts'),'--run-one-approved'],ROOT,ROOT/'run',POLICY,{'G350_LOCAL_DOGBONE_APPROVED':'1','G350_LOCAL_DOGBONE_AUTH_PATH':str(Path(args.root_receipt).resolve()),'G350_LOCAL_DOGBONE_AUTH_SHA':args.root_receipt_sha256},before_spawn=gate)
    verify();after=parent.dependency_check();assert before==after
    result_path=ROOT/'run/result.json';whole_path=ROOT/'run/whole-local-fanouts.json'
    result=json.loads(result_path.read_bytes()) if result_path.is_file() else None
    clean=execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values())
    valid=clean and result is not None and result['patchedWholeCalls']==1 and result['patchedIndividualCalls']==0 and result['inputUnchanged'] is True and result['generatedConnections']==49 and result['generatedViaRecords']==96 and result['noGridNoNativeChecker'] is True and whole_path.is_file() and sha(whole_path)==result['wholeLocalFanoutsSha256']
    receipt={'execution':execution,'dependenciesBefore':before,'dependenciesAfter':after,'sourceAndArtifactsHeld':True,'packetSha256':packet_sha,'resultSha256':sha(result_path) if result else None,'wholeLocalFanoutsSha256':sha(whole_path) if whole_path.is_file() else None,'diagnosticTrustEligible':valid,'accepted49':False,'fabricationReady':False,'physicalAcceptanceClaimed':False}
    (ROOT/'EXECUTION-postaudit.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'diagnosticTrustEligible':valid,'resultSha256':receipt['resultSha256'],'wholeLocalFanoutsSha256':receipt['wholeLocalFanoutsSha256'],'accepted49':False}));return 0 if valid else 2
if __name__=='__main__':raise SystemExit(main())
