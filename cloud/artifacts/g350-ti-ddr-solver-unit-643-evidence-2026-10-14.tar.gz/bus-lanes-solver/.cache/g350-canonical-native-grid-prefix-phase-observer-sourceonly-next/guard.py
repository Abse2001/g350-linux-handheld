from pathlib import Path
import argparse, hashlib, importlib.util, json, os, re, stat, sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
POLICY = {'wallSeconds': 120, 'rssBytes': 2*1024**3, 'sharedBytes': 26*1024**3,
          'sampleSeconds': .05, 'termGraceSeconds': 5}
RESERVE = 2*1024**3

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''): h.update(block)
    return h.hexdigest()

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec); spec.loader.exec_module(loaded)
    return loaded

def environment_record(names):
    return {name: {'present': name in os.environ,
                  'valueSha256': hashlib.sha256(os.environ[name].encode()).hexdigest()
                  if name in os.environ else None} for name in names}

def cpu_record():
    path = Path('/sys/fs/cgroup/cpu.stat')
    return {name: int(value) for name, value in
            (line.split() for line in path.read_text().splitlines())} if path.is_file() else None

def verify():
    raw = (ROOT / 'PREPARED.json').read_bytes(); packet = json.loads(raw)
    for row in packet['files'] + packet['externalFiles']:
        path = Path(row['path'])
        assert path.is_file() and not path.is_symlink() and sha(path) == row['sha256']
        assert path.stat().st_size == row['bytes'] and stat.S_IMODE(path.stat().st_mode) == row['mode']
    assert packet['policy'] == POLICY and packet['preforkReserveBytes'] == RESERVE
    focused = module('prefix_observer_frozen_source', packet['sourceGuardPath'])
    source_packet, digest = focused.verify()
    assert digest == packet['sourcePacketSha256'] == '17fb0ef4091105823b57d738d5ef8dc15c085d5f38d95365030b3a0e354cf7cf'
    assert source_packet['sourceDirectory'] == packet['sourceDirectory']
    original = Path(packet['originalTestPath']).read_text()
    observed = Path(packet['observedTestPath']).read_text()
    inverse = re.sub(r'^// G350_OBSERVATION_BEGIN\n.*?^// G350_OBSERVATION_END\n',
                     '', observed, flags=re.M | re.S)
    assert inverse == original and sha(packet['originalTestPath']) == packet['originalTestSha256']
    assert sha(packet['observedTestPath']) == packet['observedTestSha256']
    assert len(packet['prefixFiles']) == 69 and len(set(packet['prefixFiles'])) == 69
    prior_log = Path(packet['failedFullLogPath']).read_text(errors='replace')
    before_native = prior_log.split('tests/grid-native-length-bounds.test.ts:', 1)[0]
    assert re.findall(r'^(tests/[^\r\n]+):', before_native, re.M) == packet['prefixFiles']
    assert len(re.findall(r'^\((?:pass|fail)\) ', before_native, re.M)) == 222
    assert packet['command'] == [packet['bunPath'], 'test', '--preload', str(ROOT / 'preload.ts')] + packet['prefixFiles'] + ['tests/grid-native-length-bounds.test.ts']
    previous = json.loads(Path(packet['failedFullPostauditPath']).read_bytes())
    assert previous['fullSuitePassed'] is False
    assert previous['actualCounters'] == {'pass': 636, 'fail': 1, 'tests': 637, 'files': 187}
    return packet, hashlib.sha256(raw).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--root-receipt'); parser.add_argument('--root-receipt-sha256')
    args = parser.parse_args(); packet, digest = verify()
    if args.preflight_only:
        print(json.dumps({'preflightPassed': True, 'packetSha256': digest, 'sourceOnly': True})); return 0
    assert args.run and args.root_receipt and args.root_receipt_sha256
    authority = json.loads(Path(args.root_receipt).read_bytes())
    assert sha(args.root_receipt) == args.root_receipt_sha256
    assert authority['authorizedByRoot'] is True and authority['scope'] == packet['scope']
    assert authority['packetSha256'] == digest and authority['policy'] == POLICY
    assert re.fullmatch('[0-9a-f]{32,128}', authority['approvalToken'])
    previous_path = Path(authority['previousClosedPostauditPath'])
    assert sha(previous_path) == authority['previousClosedPostauditSha256']
    previous = json.loads(previous_path.read_bytes()); execution = previous['execution']
    assert execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values())
    assert execution['pgid'] == authority['previousOwnedPgid']
    assert previous.get('sourceAndArtifactHeld', previous.get('sourceAndArtifactsHeld')) is True
    assert previous['dependenciesBefore'] == previous['dependenciesAfter']
    scope = module('prefix_observer_owned_scope', packet['processScopePath'])
    dependency_guard = module('prefix_observer_dependencies', packet['sourceGuardPath'])
    assert not scope.owned(execution['pgid']) and not (ROOT / 'run').exists()
    before = dependency_guard.dependencies(); baseline = scope.memory()
    environment_before = environment_record(packet['environmentNames'])
    tools_before = {name: sha(packet[name + 'Path']) for name in ['node', 'bun']}
    quota_before = Path('/sys/fs/cgroup/cpu.max').read_text().strip(); cpu_before = cpu_record()
    def gate(now):
        assert now['current'] + POLICY['rssBytes'] + RESERVE < POLICY['sharedBytes'], 'Strict prefork reserve required'
        assert all(now['events'][key] == baseline['events'][key] for key in scope.OOM_KEYS)
    actual = scope.run_guarded(packet['command'], Path(packet['sourceDirectory']), ROOT / 'run', POLICY,
        {'GIT_OPTIONAL_LOCKS': '0', 'G350_NATIVE_PREFIX_OBSERVER_APPROVED': '1'}, before_spawn=gate)
    cpu_after = cpu_record(); quota_after = Path('/sys/fs/cgroup/cpu.max').read_text().strip()
    environment_after = environment_record(packet['environmentNames'])
    assert environment_before == environment_after and quota_before == quota_after
    verify(); after = dependency_guard.dependencies(); assert before == after
    tools_after = {name: sha(packet[name + 'Path']) for name in ['node', 'bun']}
    assert tools_before == tools_after
    log_path = ROOT / 'run/child.log'; log = log_path.read_text(errors='replace')
    parser_module = module('prefix_observer_qualified_log_parser', packet['logParserPath'])
    counts, cases = parser_module.parse_text(log)
    order = re.findall(r'^(tests/[^\r\n]+):', log, re.M)
    phase_path = ROOT / 'run/native-phases.jsonl'
    events = [json.loads(line) for line in phase_path.read_text().splitlines()] if phase_path.is_file() else []
    loads = [event for event in events if event.get('kind') == 'module-load']
    phases = [event for event in events if event.get('kind') == 'phase']
    coherent = (counts['tests'] == 228 and counts['files'] == 70 and len(cases) == 228
        and counts['pass'] + counts['fail'] == 228
        and actual['exitCode'] == (0 if counts['fail'] == 0 else 1))
    load_held = (len(loads) == 1 and loads[0]['originalPath'] == packet['originalTestPath']
        and loads[0]['originalSha256'] == packet['originalTestSha256']
        and loads[0]['observedSha256'] == packet['observedTestSha256'])
    phase_held = ([event['phase'] for event in phases] == packet['phaseNames']
        and all(event['millisecondsSincePreviousPhase'] >= 0 for event in phases))
    qualified = (coherent and load_held and phase_held
        and order == packet['prefixFiles'] + ['tests/grid-native-length-bounds.test.ts']
        and not actual['diagnosticStopped'] and actual['cleanupOwnedGroupEmpty']
        and not any(actual['oomDelta'].values()))
    result = {'phaseDiagnosticQualified': qualified, 'actualCounters': counts,
        'actualFileOrder': order, 'cases': cases, 'events': events,
        'testsPassed': actual['exitCode'] == 0 and counts['pass'] == 228 and counts['fail'] == 0,
        'internalReachabilityIncludedInReferenceConstructor': True,
        'observationalLoggingCanPerturbTiming': True, 'failedFullNotQualified': True}
    result_path = ROOT / 'run/result.json'; result_path.write_text(json.dumps(result, indent=2) + '\n')
    receipt = {'execution': actual, 'dependenciesBefore': before, 'dependenciesAfter': after,
        'sourceAndArtifactsHeld': True, 'packetSha256': digest,
        'phaseDiagnosticQualified': qualified, 'actualCounters': counts,
        'resultSha256': sha(result_path), 'phaseEventsSha256': sha(phase_path) if phase_path.is_file() else None,
        'environmentPresenceAndHashesBefore': environment_before,
        'environmentPresenceAndHashesAfter': environment_after,
        'toolSha256Before': tools_before, 'toolSha256After': tools_after,
        'cpuQuotaBefore': quota_before, 'cpuQuotaAfter': quota_after,
        'cgroupCpuBefore': cpu_before, 'cgroupCpuAfter': cpu_after,
        'cgroupCpuScalarsIncludeOtherWorkloads': True,
        'testsPassed': result['testsPassed'], 'wholeSuiteExecuted': False,
        'allElevenBenchmarksExecuted': False, 'accepted49': False, 'fabricationReady': False}
    (ROOT / 'EXECUTION-postaudit.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'phaseDiagnosticQualified': qualified, 'actualCounters': counts,
                     'resultSha256': receipt['resultSha256'], 'testsPassed': result['testsPassed']}))
    return 0 if qualified else 2

if __name__ == '__main__': raise SystemExit(main())
