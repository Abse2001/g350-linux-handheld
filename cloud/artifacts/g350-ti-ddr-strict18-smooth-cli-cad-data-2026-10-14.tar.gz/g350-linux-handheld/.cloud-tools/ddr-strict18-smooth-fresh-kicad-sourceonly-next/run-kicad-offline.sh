#!/usr/bin/env bash
# SOURCE ONLY. Root owns the actual serial guard and container invocation.
set -euo pipefail
board_root=/workspace/g350-linux-handheld
docker_local=(bash "$board_root/scripts/cloud-docker.sh")
image_id=sha256:11b9360b20752e87f20942639e229b0d111e96f6e30b1bd1cb2eaafce9f26cfc
[[ $# -ge 3 ]]
output_dir=$(realpath -e "$1")
container_name=$2
shift 2
[[ "$output_dir" == "$board_root/.cloud-tools/ddr-strict18-smooth-fresh-kicad-sourceonly-next/run-cad/output" ]]
[[ "$container_name" =~ ^g350-strict18-fresh-cad-[0-9a-f]{16}-[0-9a-f]{16}$ ]]
[[ "${G350_STRICT18_CAD_ROOT_GUARDED:-}" == 1 ]]
[[ $("${docker_local[@]}" image inspect "$image_id" --format '{{.Id}}') == "$image_id" ]]
[[ -z $("${docker_local[@]}" ps --all --quiet --filter "name=^/${container_name}$") ]]
# Reuse the tested VFS disk requirement. Never load/build/pull a missing image
# or alter daemon/client proxy configuration. This stage has no network.
if [[ $("${docker_local[@]}" info --format '{{.Driver}}') == vfs ]]; then
  docker_root=$("${docker_local[@]}" info --format '{{.DockerRootDir}}')
  image_bytes=$("${docker_local[@]}" image inspect "$image_id" --format '{{.Size}}')
  python3 -B - "$docker_root" "$image_bytes" <<'PY'
import shutil,sys
available=shutil.disk_usage(sys.argv[1]).free
required=2*int(sys.argv[2])+256*1024*1024
if available<required:raise SystemExit('Existing KiCad VFS disk reserve fails; preserve source/image and stop')
PY
fi
scratch=$(mktemp -d /tmp/g350-strict18-fresh-cad.XXXXXX)
mkdir -p "$scratch/xdg-config" "$scratch/xdg-cache" "$scratch/xdg-data"
for area in config cache data; do
  if [[ -d "$board_root/.cloud-tools/xdg-$area" ]]; then
    cp -a "$board_root/.cloud-tools/xdg-$area/." "$scratch/xdg-$area/"
  fi
done
cleanup() {
  outcome=$?
  trap - EXIT TERM INT
  # The daemon container is outside the host process group. Remove only this
  # uniquely named owned container, then preserve the actual worker status.
  if [[ -n $("${docker_local[@]}" ps --all --quiet --filter "name=^/${container_name}$") ]]; then
    "${docker_local[@]}" rm --force "$container_name" >/dev/null || outcome=2
  fi
  rm -rf -- "$scratch"
  exit "$outcome"
}
trap cleanup EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
"${docker_local[@]}" run --rm --init -i --name "$container_name" \
  --user "$(id -u):$(id -g)" --network none \
  --memory 2147483648 --memory-swap 2147483648 --cpus 2 --pids-limit 256 \
  --read-only --tmpfs /tmp:rw,nosuid,size=512m \
  --tmpfs /tmp/.X11-unix:rw,nosuid,size=1m,mode=1777 \
  -v /workspace:/workspace:ro -v "$output_dir:$output_dir:rw" \
  -v "$scratch:/g350-runtime:rw" -w "$board_root" \
  -e PYTHONPATH="$board_root/.cloud-tools/python-compat" \
  -e PYTHONDONTWRITEBYTECODE=1 -e G350_STRICT18_CAD_ROOT_GUARDED=1 \
  -e XDG_CONFIG_HOME=/g350-runtime/xdg-config \
  -e XDG_CACHE_HOME=/g350-runtime/xdg-cache \
  -e XDG_DATA_HOME=/g350-runtime/xdg-data \
  "$image_id" xvfb-run -a /usr/bin/python3 -B "$@"
