"""Finite new owned CPU heads, frozen short E7 shared/RAM suffix, stdlib only."""
from pathlib import Path
import importlib.util,ast,json,math,sys,hashlib,time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def mod(name,p):
 sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
MP=HERE/'material-owner-move.py';assert sha(MP)=='1e71fd0a03c0f61867c59af9e7406eb3682cceb742c10ee5b8b74714098785d6';h=mod('pair_new_owner_material',MP);q=h.q
U=BASE/'ddr-cpu19-cap-and-owned32-corner-sourceonly-next/material-context-cap19-owned32-owned4.py';u=mod('pair_original_angles_self',U)
HARD=BASE/'ddr-ca20-early31-and-cpu15-16-corner-followthrough-sourceonly-next/NORMALIZED_LITERAL227_NEW40_EARLY31_SIX_CA_JOIN20_01.json';assert sha(HARD)=='718702525544eba8581cd5cdcda630483d65c6f310126d54dfe86f01360a1013'
hard,rawHard=h.normalize(json.loads(HARD.read_text()));assert len(hard)==20;hard.pop('source_trace_12');rawHard.pop('source_trace_12');assert len(hard)==19
PAIR=BASE/'ddr-byte0-ram-yplus1_2-reference-aware-sourceonly-next/NORMALIZED_FRESH_RAM_YPLUS1_2_DQS0_ATOMIC_PAIR2_SHARED_TO_RAM_BOUNDARY08.json';assert sha(PAIR)=='e7c5470f4d52afc4dafcc546b0a6f21413c3803888a00f8d4a136d4a305ee944'
old,oldRaw=q.normalize(json.loads(PAIR.read_text()));names=['source_trace_15','source_trace_16']
ROUND=BASE/'ddr-dqs0-cpu-head-literal227-finite-sourceonly-next/finite-head-fork.py';tree=ast.parse(ROUND.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='rounded'];assert len(nodes)==1;ns={'math':math};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(ROUND),'exec'),ns);rounded=ns['rounded']
COUPLE=BASE/'ddr-dqs0-cap19-context12-coupled-growth-sourceonly-next/seal-coupled-alternatives.py';assert sha(COUPLE)=='155017a07427c1735ed7995cfa48ec0b8b7dd2c724a0e473cd6e1bf4b0a3753f';tree=ast.parse(COUPLE.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ['outside','coupling']];assert len(nodes)==2
ns.update({'q':q,'boxes':[[-7.2632,7.2632,12.3082,27.2632],[-5.2732,8.0918,3.3082,11.4918]],'allowed':(.1016+.12)/math.cos(math.pi/8)-.1016+.002});exec(compile(ast.Module(body=nodes,type_ignores=[]),str(COUPLE),'exec'),ns)
def construct(bay,high,left):
 p=old[names[0]]['path'];head=rounded([h.moves[names[0]],(4.4,high),(bay,high),(bay,13.2),p[9]],.11);positive=head+p[10:]
 p=old[names[1]]['path'];s,e=oldRaw[names[1]]['coupledSection'];head=rounded([h.moves[names[1]],(left,14),(left,13.2),(3.8892,12.9108),p[s]],.11);negative=head+p[s+1:]
 paths={names[0]:positive,names[1]:negative};rows=[]
 for n,path in paths.items():
  os,oe=oldRaw[n]['coupledSection'];suffix=old[n]['path'][os:];assert path[-len(suffix):]==suffix
  start=len(path)-len(suffix);rows.append({'sourceTraceId':n,'role':'DDR_BYTE0','class':'DQS0','layer':'inner1','path':[{'x':x,'y':y}for x,y in path],'coupledSection':[start,start+oe-os]})
 return rows
trials=[];started=time.monotonic()
for bay in [4.55,4.6,4.65]:
 for high in [14,14.05]:
  for left in [3.6,3.605]:
   rows=construct(bay,high,left);rr,raw=h.normalize({'records':rows});joined={**hard,**rr};checks={}
   for n,x in rr.items():
    scene=h.Scene('inner1',joined,n);cert=scene.certificate(x['path'],n);selftest=u.ns['selfcheck']([u.P(*p)for p in x['path']]);angles=u.angles(x['path']);whole=q.g.length(x['path'])+h.fixed[n]
    checks[n]={'physical':cert,'self':selftest,'angles':angles,'wholePlanarLengthMm':whole,'basicPass':cert['violationCount']==0 and selftest['clear']and angles['allOriginalDirectionDotsPass']and whole<=13.2+1e-9}
   skew=abs(checks[names[0]]['wholePlanarLengthMm']-checks[names[1]]['wholePlanarLengthMm']);passed=all(c['basicPass']for c in checks.values())and skew<=.127+1e-9
   t={'parameters':{'positiveBayX':bay,'positiveHighY':high,'negativeColumnX':left},'records':rows,'checks':checks,'pairSkewMm':skew,'basicPass':passed}
   if passed:
    t['coupling']={n:ns['coupling'](rr[n]['path'],rr[names[1]if n==names[0]else names[0]]['path'],raw[n]['coupledSection'])for n in names};t['ownMeters']={n:h.Scene('inner1',joined,n).exposure(rr[n]['path'],n)for n in names};t['specializedPairAndOwnMeterPass']=all(v['entireIntervalBoundedPass']for c in t['coupling'].values()for v in c.values())and all(c['absoluteTICapPass']and c['noResetOrIntrinsicPairSpacingException']for c in t['ownMeters'].values())
   trials.append(t)
out={'scope':'SOURCE_ONLY_GENUINE_MOVED_CPU_BARRELS_DQS0_PAIR_HEADS_WITH_FROZEN_SHORT_E7_SHARED_RAM_BODY','movedOwnerHelperPin':{'path':str(MP),'sha256':sha(MP)},'ownerDeltaPin':{'path':str(HERE/'OWNER_CLOSED_227_PLANNING_DELTA.json'),'sha256':sha(HERE/'OWNER_CLOSED_227_PLANNING_DELTA.json')},'hardCA20AndEarly31Pin':{'path':str(HARD),'sha256':sha(HARD)},'onlySource12MainReleasedFromHard20':True,'shortE7SharedRamGeometryPin':{'path':str(PAIR),'sha256':sha(PAIR)},'longD87BodyAndAllOriginalInputsUntouched':True,'all21ReciprocalAndSource12JointAuditPending':True,'trials':trials,'trialCount':len(trials),'eligibleAtomicPairCount':sum(bool(t.get('specializedPairAndOwnMeterPass'))for t in trials),'elapsedSeconds':time.monotonic()-started,'sourceMaterialAdoptionOrOverlay':False,'SourceCoreNativeApiCadSdkExecuted':False,'all49Accepted':False,'referenceQualified':False,'electricalTimingPassed':False,'fabricationReady':False}
p=HERE/'FINITE_MOVED_CPU_PAIR_HEAD_REPORT01.json'
with p.open('x')as f:json.dump(out,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'path':str(p),'sha256':sha(p),'eligible':out['eligibleAtomicPairCount'],'seconds':out['elapsedSeconds'],'summary':[{'params':t['parameters'],'pass':t.get('specializedPairAndOwnMeterPass',False),'skew':t['pairSkewMm'],'whole':{n:c['wholePlanarLengthMm']for n,c in t['checks'].items()},'fail':{n:{'physical':c['physical']['violationCount'],'closest':c['physical']['closest'],'self':c['self']['clear'],'angle':c['angles']['allOriginalDirectionDotsPass']}for n,c in t['checks'].items()}}for t in trials]}))
