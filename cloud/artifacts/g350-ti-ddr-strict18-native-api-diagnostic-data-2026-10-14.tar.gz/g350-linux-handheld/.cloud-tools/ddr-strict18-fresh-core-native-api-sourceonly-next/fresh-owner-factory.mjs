// Source-only. Root invokes only after an actual collected fresh Core/control PASS.
// This module authenticates real fresh rows; it never adds or rewrites a soup row.
import assert from 'node:assert/strict'
import {getFullConnectivityMapFromCircuitJson} from 'circuit-json-to-connectivity-map'
import {getProvedViaBranchRegistry,getProvedIntentionalPadContactRegistry} from '/workspace/g350-linux-handheld/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/prove-shared-package-loops.mjs'
const states=new WeakMap(),LAYERS=['top','inner1','inner2','bottom'],EPS=1e-9
const one=(rows,label)=>{assert.equal(rows.length,1,label);return rows[0]}
const near=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<EPS
const at=(a,b)=>a&&b&&near(a.x,b.x)&&near(a.y,b.y)
const canonical=x=>Array.isArray(x)?'['+x.map(canonical).join(',')+']':x&&typeof x==='object'?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}':JSON.stringify(x)
const same=(a,b,label)=>assert.equal(canonical(a),canonical(b),label)
const logical=r=>Object.fromEntries(Object.entries(r).filter(([k])=>k!=='subcircuit_connectivity_map_key'))
const pointShape=p=>Object.fromEntries(Object.entries(p).filter(([k])=>!['start_pcb_port_id','end_pcb_port_id'].includes(k)))
const viaShape=v=>Object.fromEntries(['x','y','hole_diameter','outer_diameter','layers','from_layer','to_layer','tented_on_top','tented_on_bottom','source_net_id'].filter(k=>k in v).map(k=>[k,v[k]]))
function index(circuit){
 assert(Array.isArray(circuit));const byType=new Map()
 for(const r of circuit){assert(r&&typeof r.type==='string');if(!byType.has(r.type))byType.set(r.type,[]);byType.get(r.type).push(r)}
 const rows=t=>byType.get(t)||[],maps=new Map()
 const by=(t,id)=>{if(!maps.has(t)){const map=new Map();for(const r of rows(t)){const k=r[t+'_id'];assert.equal(typeof k,'string');assert(!map.has(k),'Duplicate actual ID '+k);map.set(k,r)}maps.set(t,map)}const r=maps.get(t).get(id);assert(r,'Missing actual '+t+' '+id);return r}
 return {rows,by}
}
function alias(actual,via,layer){
 const pcb=one(via.pcb_port_ids.map(id=>actual.by('pcb_port',id)).filter(p=>canonical(p.layers)===canonical([layer])),'One actual '+layer+' alias')
 assert(at(pcb,via));const source=actual.by('source_port',pcb.source_port_id);assert.equal(source.name,layer)
 const owner=actual.by('source_manually_placed_via',source.source_component_id),placeholder=actual.by('pcb_component',pcb.pcb_component_id)
 assert.equal(placeholder.source_component_id,owner.source_manually_placed_via_id);assert(at(placeholder.center,via))
 if(via.source_net_id!==undefined)assert.equal(owner.source_net_id,via.source_net_id)
 else assert.equal(owner.source_net_id,undefined,'No signal rail fabrication')
 return {pcb,source,owner}
}
function endpoints(t,ids){
 const found=t.route.flatMap((p,i)=>i===0||i===t.route.length-1?[p.start_pcb_port_id,p.end_pcb_port_id].filter(Boolean):[])
 same([...found].sort(),[...ids].sort(),'Exact actual trace endpoint IDs')
 assert(!t.route.slice(1,-1).some(p=>p.start_pcb_port_id||p.end_pcb_port_id))
}
function actualNumeric(actual,old,sourceId){
 const sp=actual.by('source_port',sourceId),prior=old.by('source_port',sourceId);same(logical(sp),logical(prior),'Original numeric Source ownership')
 assert(Number.isInteger(sp.pin_number)&&sp.pin_number>0)
 const part=actual.by('source_component',sp.source_component_id);same(logical(part),logical(old.by('source_component',prior.source_component_id)),'Original real part')
 const pcb=one(actual.rows('pcb_port').filter(p=>p.source_port_id===sourceId),'One actual numeric PCB port')
 const priorPcb=one(old.rows('pcb_port').filter(p=>p.source_port_id===sourceId),'One old numeric PCB port')
 same(Object.fromEntries(Object.entries(pcb).filter(([k])=>k!=='pcb_port_id')),Object.fromEntries(Object.entries(priorPcb).filter(([k])=>k!=='pcb_port_id')),'Numeric PCB geometry/component/layer')
 const pad=one(actual.rows('pcb_smtpad').filter(p=>p.pcb_port_id===pcb.pcb_port_id),'One actual numeric land')
 const priorPad=one(old.rows('pcb_smtpad').filter(p=>p.pcb_port_id===priorPcb.pcb_port_id),'One old numeric land')
 const padShape=r=>Object.fromEntries(Object.entries(r).filter(([k])=>!['pcb_smtpad_id','pcb_port_id'].includes(k)))
 same(padShape(pad),padShape(priorPad),'Original numeric copper geometry')
 return {sp,part,pcb,pad}
}
const freeze=v=>{if(v&&typeof v==='object'&&!Object.isFrozen(v)){Object.values(v).forEach(freeze);Object.freeze(v)}return v}
export function proveFreshStrict18Core({freshCore,controls,oldCore,oldPackageProof,signalProposal,clockProposal,strict18Proposal}){
 const before=JSON.stringify(freshCore),actual=index(freshCore),old=index(oldCore)
 assert.equal(controls.freshCoreControlPassed,true);assert(controls.checks.length>20&&controls.checks.every(r=>r.passed===true))
 for(const [t,n] of [['pcb_via',225],['pcb_trace',279],['pcb_port',1639],['pcb_smtpad',1161],['source_component',280],['source_net',98],['source_bus',8],['pcb_hole',2],['pcb_plated_hole',4]])assert.equal(actual.rows(t).length,n,t)
 assert.equal(old.rows('pcb_via').length,129);assert.equal(old.rows('pcb_trace').length,165)
 const remainingBusRows=actual.rows('source_bus').slice()
 for(const original of old.rows('source_bus')){
  const semantic=r=>Object.fromEntries(Object.entries(r).filter(([k])=>k!=='source_bus_id'))
  const i=remainingBusRows.findIndex(now=>now.name===original.name&&canonical(semantic(now))===canonical(semantic(original)))
  assert(i>=0,'Every original bus name/ordered membership/constraint must remain exact');remainingBusRows.splice(i,1)
 }
 assert.equal(remainingBusRows.length,0,'No extra bus declarations')
 for(const r of old.rows('source_net'))same(logical(actual.by('source_net',r.source_net_id)),logical(r),'Original named rail')
 for(const r of old.rows('source_trace').filter(r=>/^source_trace_\d+$/.test(r.source_trace_id)&&Number(r.source_trace_id.slice(13))<49))same(logical(actual.by('source_trace',r.source_trace_id)),logical(r),'Original49 logical numeric requests')
 const oldRegistry=getProvedViaBranchRegistry(oldPackageProof,oldCore),oldPadRegistry=getProvedIntentionalPadContactRegistry(oldPackageProof,oldCore)
 assert.equal(oldRegistry.size,129);assert.equal(oldPadRegistry.size,1)
 const viaMap=new Map(),traceMap=new Map(),registry=new Map(),padRegistry=new Map(),referenceMappings=[],signalMappings=[]
 const usedVias=new Set(),usedTraces=new Set()
 for(const v of old.rows('pcb_via')){
  const now=one(actual.rows('pcb_via').filter(r=>canonical(viaShape(r))===canonical(viaShape(v))),'One exact reference barrel')
  assert(!usedVias.has(now.pcb_via_id));usedVias.add(now.pcb_via_id);viaMap.set(v.pcb_via_id,now)
  assert.equal(now.outer_diameter,.4572);assert.equal(now.hole_diameter,.254);same(now.layers,LAYERS)
  assert.equal(now.pcb_port_ids.length,2)
  for(const layer of ['top','bottom']){
   const a=alias(actual,now,layer),o=alias(old,v,layer)
   same(logical(a.source),logical(o.source),'Reference actual Source alias');same(logical(a.owner),logical(o.owner),'Reference own Source Via identity')
  }
  registry.set(now.pcb_via_id,new Set(oldRegistry.get(v.pcb_via_id)))
 }
 for(const t of old.rows('pcb_trace')){
  const now=one(actual.rows('pcb_trace').filter(r=>r.source_trace_id===t.source_trace_id&&canonical(r.route.map(pointShape))===canonical(t.route.map(pointShape))),'One original source/geometry reference path')
  assert(!usedTraces.has(now.pcb_trace_id));usedTraces.add(now.pcb_trace_id);traceMap.set(t.pcb_trace_id,now)
  const source=actual.by('source_trace',now.source_trace_id),oldSource=old.by('source_trace',t.source_trace_id);same(logical(source),logical(oldSource),'Reference actual logical Source owner')
  const owners=[...oldRegistry].filter(([,set])=>set.has(t.source_trace_id));assert(owners.length>=1)
  const oldBranch=oldPackageProof.branches.find(r=>r.pcb_trace_id===t.pcb_trace_id)
  assert(oldBranch,'Original proof branch required')
  const numeric=actualNumeric(actual,old,oldBranch.source_port_id),v=viaMap.get(oldBranch.pcb_via_id)
  const layer=t.route[0].layer,a=alias(actual,v,layer);endpoints(now,[numeric.pcb.pcb_port_id,a.pcb.pcb_port_id])
  assert(source.connected_source_port_ids.includes(numeric.sp.source_port_id)&&source.connected_source_port_ids.includes(a.source.source_port_id))
  assert(source.connected_source_net_ids.includes(v.source_net_id))
  referenceMappings.push({originalPcbTraceId:t.pcb_trace_id,actualPcbTraceId:now.pcb_trace_id,actualSourceTraceId:now.source_trace_id,originalViaId:oldBranch.pcb_via_id,actualViaId:v.pcb_via_id,actualNumericPcbPortId:numeric.pcb.pcb_port_id,actualAliasPcbPortId:a.pcb.pcb_port_id,actualNumericSourcePortId:numeric.sp.source_port_id})
 }
 same(controls.originalReference165GeometryProjection.map(r=>[r.originalPcbTraceId,r.actualPcbTraceId]),referenceMappings.map(r=>[r.originalPcbTraceId,r.actualPcbTraceId]),'Fresh Core control reference mapping recomputed')
 same(controls.original129ReferenceBarrelProjection.map(r=>[r.originalViaId,r.actualViaId]),[...viaMap].map(([id,v])=>[id,v.pcb_via_id]),'Fresh Core control barrel mapping recomputed')
 for(const [oldId,v] of viaMap){const tIds=[...oldRegistry.get(oldId)].flatMap(s=>[...traceMap.values()].filter(t=>t.source_trace_id===s).map(t=>t.pcb_trace_id));if(v.pcb_trace_id!==undefined)assert(tIds.includes(v.pcb_trace_id),'Actual reference via pcb_trace_id must be an owned real branch')}
 assert.equal(strict18Proposal.scope,'SOURCE_ONLY_16_NEW_DIRECT_ORIGINAL_SIGNAL_THREE_PATHS_PLUS_2_HELD_CLOCKS')
 assert.equal(strict18Proposal.originalPhysicalBarrelsHeld,225);assert.equal(strict18Proposal.expectedPhysicalTraceCount,279)
 assert.equal(strict18Proposal.newOriginalSignalChanges.length,16)
 const directDefinitions=[...clockProposal.clockCarriers.map(c=>({...c,carrierLayer:'inner1',expectedCarrierPhysicalRoute:c.expectedInner1PhysicalRoute})),...strict18Proposal.newOriginalSignalChanges]
 const directById=new Map(directDefinitions.map(c=>[c.originalSourceTraceId,c]));assert.equal(directById.size,18)
 assert.equal(signalProposal.owners.length,96)
 for(const owner of signalProposal.owners){
  const numeric=actualNumeric(actual,old,owner.originalSourcePortId);assert.equal(numeric.part.name,owner.package);assert.equal(numeric.sp.pin_number,owner.numericPin);assert(at(numeric.pcb,owner.padXY))
  const v=one(actual.rows('pcb_via').filter(r=>!usedVias.has(r.pcb_via_id)&&at(r,owner.viaXY)),'One own signal barrel')
  assert.equal(v.outer_diameter,.4572);assert.equal(v.hole_diameter,.254);same(v.layers,LAYERS);assert.equal(v.from_layer,'top');assert.equal(v.to_layer,'bottom');assert.equal(v.source_net_id,undefined);assert.equal(v.tented_on_top,true);assert.equal(v.tented_on_bottom,true)
  const top=alias(actual,v,'top'),bottom=alias(actual,v,'bottom');assert.equal(top.owner.source_manually_placed_via_id,bottom.owner.source_manually_placed_via_id)
  const local=one(actual.rows('source_trace').filter(s=>s.name===owner.traceName),'Actual unique local Source branch')
  same([...local.connected_source_port_ids].sort(),[numeric.sp.source_port_id,top.source.source_port_id].sort());same(local.connected_source_net_ids,[]);assert.equal(local.min_trace_thickness,.1016)
  const selectors=[`${owner.package}.pin${owner.numericPin} to .${owner.viaName} > port.top`,`.${owner.viaName} > port.top to ${owner.package}.pin${owner.numericPin}`];assert(selectors.includes(local.display_name),'Actual authored signal selector binds named Source via')
  const direct=directById.get(owner.originalSourceTraceId),isDirect=!!direct
  const expectedLayers=direct&&['inner1','inner2'].includes(direct.carrierLayer)?['top','bottom',direct.carrierLayer]:['top','bottom']
  assert.equal(v.pcb_port_ids.length,expectedLayers.length)
  const realAliases=v.pcb_port_ids.map(id=>actual.by('pcb_port',id));same(realAliases.map(p=>one(p.layers,'Single real alias layer')).sort(),expectedLayers.slice().sort(),'Exact real barrel alias roster')
  const aliases=expectedLayers.map(layer=>alias(actual,v,layer))
  assert.equal(new Set(aliases.map(a=>a.owner.source_manually_placed_via_id)).size,1,'Every alias belongs to same actual Source via')
  assert.equal(new Set(aliases.map(a=>a.pcb.pcb_component_id)).size,1,'Every alias belongs to same real placeholder')
  for(const a of aliases){const placeholder=actual.by('pcb_component',a.pcb.pcb_component_id);assert.equal(placeholder.width,.4572);assert.equal(placeholder.height,.4572)}
  const physicalSource=isDirect?owner.originalSourceTraceId:local.source_trace_id
  const t=one(actual.rows('pcb_trace').filter(r=>!usedTraces.has(r.pcb_trace_id)&&r.source_trace_id===physicalSource&&r.route.length===owner.topStub.length&&(r.route.every((p,i)=>p.route_type==='wire'&&p.layer==='top'&&p.width===.1016&&at(p,owner.topStub[i]))||r.route.every((p,i)=>p.route_type==='wire'&&p.layer==='top'&&p.width===.1016&&at(p,owner.topStub[owner.topStub.length-1-i])))),'One source-owned Top stub')
  if(isDirect)assert.equal(actual.rows('pcb_trace').filter(r=>r.source_trace_id===local.source_trace_id).length,0,'Direct local logical prototype must not duplicate copper')
  else assert.equal(actual.rows('pcb_trace').filter(r=>r.source_trace_id===local.source_trace_id).length,1)
  endpoints(t,[numeric.pcb.pcb_port_id,top.pcb.pcb_port_id])
  if(v.pcb_trace_id!==undefined)assert.equal(v.pcb_trace_id,t.pcb_trace_id,'Signal physical via owner must be actual Top copper')
  usedVias.add(v.pcb_via_id);usedTraces.add(t.pcb_trace_id);registry.set(v.pcb_via_id,new Set([physicalSource]))
  signalMappings.push({originalSourceTraceId:owner.originalSourceTraceId,originalNumericSourcePortId:owner.originalSourcePortId,sourceViaName:owner.viaName,actualViaId:v.pcb_via_id,actualLocalSourceTraceId:local.source_trace_id,actualPhysicalSourceTraceId:physicalSource,actualPcbTraceId:t.pcb_trace_id,actualNumericPcbPortId:numeric.pcb.pcb_port_id,actualTopPcbPortId:top.pcb.pcb_port_id,actualBottomPcbPortId:bottom.pcb.pcb_port_id,actualTopSourcePortId:top.source.source_port_id,sourceViaOwnerId:top.owner.source_manually_placed_via_id})
 }
 same(controls.original96SignalBarrelProjection.map(r=>[r.sourceViaName,r.actualViaId]),signalMappings.map(r=>[r.sourceViaName,r.actualViaId]),'Fresh Core actual signal barrel control recomputed')
 const carriers=directDefinitions.map(definition=>{
  const id=definition.originalSourceTraceId,layer=definition.carrierLayer
  assert(LAYERS.includes(layer),'Explicit actual carrier layer required')
  const source=actual.by('source_trace',id);same(source.connected_source_port_ids,[definition.cpu.originalSourcePortId,definition.ram.originalSourcePortId]);same(source.connected_source_net_ids,[])
  const mapped=[definition.cpu,definition.ram].map(o=>one(signalMappings.filter(r=>r.originalSourceTraceId===id&&r.originalNumericSourcePortId===o.originalSourcePortId),'Actual direct endpoint owner'))
  const vias=mapped.map(o=>actual.by('pcb_via',o.actualViaId)),ports=vias.map(v=>alias(actual,v,layer))
  const paths=actual.rows('pcb_trace').filter(r=>r.source_trace_id===id);assert.equal(paths.length,3,'Exactly two genuine Topstubs and one actual carrier')
  const stubIds=new Set(mapped.map(m=>m.actualPcbTraceId))
  const body=one(paths.filter(t=>!stubIds.has(t.pcb_trace_id)),'Actual source-owned carrier distinct from both Topstubs')
  assert(!usedTraces.has(body.pcb_trace_id));assert.equal(body.route.length,definition.expectedCarrierPhysicalRoute.length)
  body.route.forEach((p,i)=>assert(p.route_type==='wire'&&p.layer===layer&&p.width===.1016&&at(p,definition.expectedCarrierPhysicalRoute[i]),'Exact pinned static18 carrier geometry'))
  endpoints(body,ports.map(p=>p.pcb.pcb_port_id));assert(at(body.route[0],vias[0])&&at(body.route.at(-1),vias[1]))
  assert(paths.every(t=>t.route.every(p=>p.route_type==='wire')),'No fabricated route-via markers')
  usedTraces.add(body.pcb_trace_id)
  const planar=paths.reduce((s,t)=>s+t.route.slice(1).reduce((n,p,i)=>n+Math.hypot(p.x-t.route[i].x,p.y-t.route[i].y),0),0)
  const routeLength=route=>route.slice(1).reduce((s,p,i)=>s+Math.hypot(p.x-route[i].x,p.y-route[i].y),0)
  const expected=routeLength(definition.expectedCarrierPhysicalRoute)+routeLength(definition.cpu.topStub)+routeLength(definition.ram.topStub)
  assert(near(planar,expected));if(definition.originalV11WholePlanarLength!==undefined)assert(near(planar,definition.originalV11WholePlanarLength))
  // Physical graph uses only real fresh PCB endpoint ports, both physical fullspan
  // barrels and all3 actual source-owned copper paths. Original logical Source
  // connectivity alone is insufficient; no soup row or graph ID is synthesized.
  const graph=new Map(),edges=[]
  const join=(a,b,basis)=>{for(const x of [a,b])if(!graph.has(x))graph.set(x,new Set());graph.get(a).add(b);graph.get(b).add(a);edges.push({fromActualId:a,toActualId:b,...basis})}
  for(const trace of paths){
   const first=trace.route[0],last=trace.route.at(-1)
   assert(first.start_pcb_port_id&&last.end_pcb_port_id,'Actual endpoint annotations required')
   for(const [point,pid] of [[first,first.start_pcb_port_id],[last,last.end_pcb_port_id]]){const port=actual.by('pcb_port',pid);assert(at(point,port)&&port.layers.includes(point.layer),'Actual declared endpoint coordinate/layer must meet its physical port')}
   join(first.start_pcb_port_id,last.end_pcb_port_id,{basis:'ACTUAL_FRESH_SOURCE_OWNED_WIRE_PATH',actualPcbTraceId:trace.pcb_trace_id,actualSourceTraceId:trace.source_trace_id})
  }
  for(const via of vias)for(const pid of via.pcb_port_ids){const p=actual.by('pcb_port',pid);assert(at(p,via)&&p.layers.every(l=>via.layers.includes(l)));join(pid,via.pcb_via_id,{basis:'ACTUAL_FULLSPAN_BARREL_OWNED_ALIAS',actualSourceViaOwner:actual.by('source_port',p.source_port_id).source_component_id})}
  const begin=mapped[0].actualNumericPcbPortId,end=mapped[1].actualNumericPcbPortId,queue=[begin],previous=new Map([[begin,null]])
  for(let i=0;i<queue.length;i++)for(const next of graph.get(queue[i])||[])if(!previous.has(next)){previous.set(next,queue[i]);queue.push(next)}
  assert(previous.has(end),'Genuine fresh physical numeric CPU-to-RAM path required')
  const path=[];for(let current=end;current!==null;current=previous.get(current))path.unshift(current)
  return {originalSourceTraceId:id,carrierLayer:layer,actualDirectPcbTraceIds:paths.map(t=>t.pcb_trace_id),actualCarrierPcbTraceId:body.pcb_trace_id,actualCpuNumericPcbPortId:begin,actualRamNumericPcbPortId:end,actualCpuViaId:vias[0].pcb_via_id,actualRamViaId:vias[1].pcb_via_id,actualCpuCarrierLayerPcbPortId:ports[0].pcb.pcb_port_id,actualRamCarrierLayerPcbPortId:ports[1].pcb.pcb_port_id,wholePlanarLengthMm:planar,physicalFullThroughBarrels:2,actualActiveLayerTransitions:layer==='top'?[]:[{x:vias[0].x,y:vias[0].y,fromLayer:'top',toLayer:layer},{x:vias[1].x,y:vias[1].y,fromLayer:layer,toLayer:'top'}],legacyViaMarkerLengthContributionMm:0,actualSourceOwnedPhysicalGraph:{actualEdges:edges,actualNumericCpuToRamIdPath:path,physicallyConnected:true,logicalMapAloneNotUsed:true},electricalDelayQualified:false}
 })
 const clocks=carriers.filter(c=>['source_trace_33','source_trace_34'].includes(c.originalSourceTraceId)).map(c=>({...c,actualCpuInner1PcbPortId:c.actualCpuCarrierLayerPcbPortId,actualRamInner1PcbPortId:c.actualRamCarrierLayerPcbPortId}))
 assert.equal(clocks.length,2);assert.equal(carriers.length,18)
 for(const t of old.rows('source_trace').filter(t=>/^source_trace_\d+$/.test(t.source_trace_id)&&Number(t.source_trace_id.slice(13))<49))assert.equal(actual.rows('pcb_trace').filter(p=>p.source_trace_id===t.source_trace_id).length,directById.has(t.source_trace_id)?3:0,'Exactly18direct original signals,31unfinished')
 assert.equal(usedVias.size,225);assert.equal(usedTraces.size,279);assert.equal(registry.size,225)
 const contact=one(oldPackageProof.intentionalExistingTraceContacts,'Only authentic RAM25 HS8 contact'),padContact=one(oldPackageProof.intentionalExistingPadContacts,'Only authentic RAM25 HS8 pad')
 assert.equal(contact.pcb_trace_id,'pcb_trace_55');assert.equal(contact.source_trace_id,'source_trace_987');assert.equal(contact.source_net_id,'source_net_0');same(contact.provedPackageOwnerKeys,['U_RAM:pin25'])
 const newVia=viaMap.get(contact.pcb_via_id),strip=traceMap.get(contact.pcb_trace_id),numeric=actualNumeric(actual,old,padContact.source_port_id),oldOwnedVia=viaMap.get(contact.existingOwnedHsViaId)
 assert(at(newVia,{x:.4,y:8.975}));assert.equal(newVia.source_net_id,'source_net_0');assert.equal(numeric.part.name,'C_DDR_RAM_8');assert.equal(numeric.sp.pin_number,2);assert.equal(numeric.pad.layer,'bottom');assert.equal(strip.source_trace_id,'source_trace_987');assert.equal(strip.route.length,2)
 const [a,b]=strip.route;assert(a.layer==='bottom'&&b.layer==='bottom'&&a.width===.2&&b.width===.2&&!a.width_interpolation_mode&&!b.width_interpolation_mode)
 const dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy),along=((newVia.x-a.x)*dx+(newVia.y-a.y)*dy)/len,distance=Math.abs(dx*(newVia.y-a.y)-dy*(newVia.x-a.x))/len,R=newVia.outer_diameter/2,h=newVia.hole_diameter/2,nearest=Math.max(0,distance-a.width/2),halfChord=Math.sqrt(R*R-nearest*nearest)
 assert(Number.isFinite(halfChord)&&2*halfChord>=.1016&&along-halfChord>1e-8&&along+halfChord<len-1e-8&&distance-a.width/2>h)
 const pad=numeric.pad;assert.equal(pad.shape,'rect');assert.equal(pad.ccw_rotation??0,0)
 const closestX=Math.max(pad.x-pad.width/2,Math.min(newVia.x,pad.x+pad.width/2)),closestY=Math.max(pad.y-pad.height/2,Math.min(newVia.y,pad.y+pad.height/2)),padDistance=Math.hypot(newVia.x-closestX,newVia.y-closestY)
 assert(padDistance<R&&padDistance>h&&R-h>=.1016-Number.EPSILON)
 const connectivity=getFullConnectivityMapFromCircuitJson(freshCore)
 for(const pair of [[strip.pcb_trace_id,newVia.pcb_via_id],[strip.source_trace_id,newVia.pcb_via_id],[oldOwnedVia.pcb_via_id,newVia.pcb_via_id],[pad.pcb_smtpad_id,newVia.pcb_via_id],[numeric.pcb.pcb_port_id,newVia.pcb_via_id],[numeric.sp.source_port_id,newVia.pcb_via_id]])assert(connectivity.areIdsConnected(...pair),'Authentic physical junction also needs actual known-rail graph '+pair.join(' / '))
 registry.get(newVia.pcb_via_id).add(strip.source_trace_id);padRegistry.set(newVia.pcb_via_id,new Set([pad.pcb_smtpad_id]))
 for(const map of referenceMappings){const trace=actual.by('pcb_trace',map.actualPcbTraceId),via=actual.by('pcb_via',map.actualViaId);for(const pair of [[map.actualNumericPcbPortId,trace.pcb_trace_id],[map.actualAliasPcbPortId,trace.pcb_trace_id],[map.actualNumericPcbPortId,via.pcb_via_id],[trace.source_trace_id,via.pcb_via_id],[via.source_net_id,via.pcb_via_id]])assert(connectivity.areIdsConnected(...pair),'Actual mapped reference graph')}
 assert.equal(JSON.stringify(freshCore),before,'No circuit JSON edit during ownership proof')
 const proof=freeze({scope:'ACTUAL_FRESH_CORE225_279_NUMERIC18_AND_AUTHENTIC_REFERENCE_OWNERSHIP',referenceMappings,signalMappings,carriers,clocks,registeredRam25Hs8Junction:{actualViaId:newVia.pcb_via_id,actualOldStripPcbTraceId:strip.pcb_trace_id,actualOldStripSourceTraceId:strip.source_trace_id,actualHs8PadId:pad.pcb_smtpad_id,actualHs8NumericPcbPortId:numeric.pcb.pcb_port_id,actualOldHsViaId:oldOwnedVia.pcb_via_id,actualContactChordMm:2*halfChord,actualPadClosestDistanceMm:padDistance,actualLandRadiusMm:R,actualDrillRadiusMm:h,onlyOriginalRam25Owner:true,stripDrillClear:true,padDrillClear:true},rawCircuitUnmodified:true,referenceQualified:false,accepted49:false,fabricationReady:false})
 states.set(proof,{circuit:freshCore,signature:before,registry,padRegistry});return proof
}
export function getFreshViaBranchRegistry(proof,circuit){const s=states.get(proof);assert(s&&s.circuit===circuit,'Only exact privately proved actual Core object');assert.equal(JSON.stringify(circuit),s.signature);return new Map([...s.registry].map(([id,owners])=>[id,new Set(owners)]))}
export function getFreshIntentionalPadContactRegistry(proof,circuit){const s=states.get(proof);assert(s&&s.circuit===circuit,'Only exact privately proved actual Core object');assert.equal(JSON.stringify(circuit),s.signature);return new Map([...s.padRegistry].map(([id,pads])=>[id,new Set(pads)]))}
