#!/usr/bin/env python3
"""Unbound SOURCE ONLY preparation; no checkpoint, archive or SDK execution.

The executable build/verify successor must be a new file after the actual328+
run closes. This draft independently authenticates its known base/profile and
exposes the exact remaining binding contract. Build/verify always refuse here.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat

TEMPLATE_ONLY = True
BOARD = Path('/workspace/g350-linux-handheld')
BASE = Path('/tmp/g350-model318-portable-increment-20261016')
BASE_REL = '.cloud-tools/ddr-four-layer-model318-2026-10-16'
BASE_STEM = 'g350-four-layer-ca17-model318-source313-base-2026-10-16'
BASE_ARCHIVE_SHA = 'f7090db168c637688eaaa4b6456a1de83edc0d2e3ead44a2a7458a12ec82ccc6'
BASE_MANIFEST_SHA = '53c4db6ad308559d5ef5f5c991b24d758550e3dcc7b0c8c033656b1231856c15'
BASE_PINS = {
    'PROGRESS.json': '71295cee8cfa8d6998cfc5df69030b7b3a622d8d00303fce33a1b8a3d0c9e77c',
    'README.md': '836d5a52adc190fc501f743d1942390a68a538244bd6be367c7585306582286e',
    'WORKSPACE_HASH_INDEX.json': 'a384ef5171a2a0ecc8f975ad6198119309d6c4511f8ca69486214cd028fb12e3',
    'WORKSPACE_RESTORE_MANIFEST.json': 'c7f21f5d5d440a01cabbe359e091d958354a92f4f2af7528e02525709f030bbf',
}
PROFILE = Path('/tmp/g350-next-model-after318-portable-increment-profile-v2-sourceonly.json')
PROFILE_SHA = 'c68ddaa3f824f4a64e389a5baf82fe2abb9ca63ce776a17711ac4dd4b32f7609'
PREDECESSOR = Path('/tmp/g350-model318-portable-increment-v2-basefix-sourceonly.py')
PREDECESSOR_SHA = '7d6fdbf6ac280693bfae12ecd6f550314d64935f2133440f6118bcb3f66bec9a'
SOLVER_ROOT = '/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib'

def need(value, message):
    if not value:
        raise ValueError(message)

def regular(path):
    return path.is_file() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)

def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            result.update(block)
        os.posix_fadvise(stream.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return result.hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def exact(path, row):
    need(regular(path), 'Actual regular evidence file: '+str(path))
    actual = {'bytes': path.stat().st_size, 'sha256': sha(path), 'mode': stat.S_IMODE(path.stat().st_mode)}
    need(actual == {key: row[key] for key in actual}, 'Exact actual bytes/hash/mode: '+str(path))

def authenticate_base():
    for name, digest in BASE_PINS.items():
        need(regular(BASE/name) and sha(BASE/name) == digest, 'Frozen Model318 metadata')
    index = read(BASE/'WORKSPACE_HASH_INDEX.json')
    manifest = read(BASE/'WORKSPACE_RESTORE_MANIFEST.json')
    progress = read(BASE/'PROGRESS.json')
    need(len(index['files']) == 22 and len(manifest['files']) == 19 and len(manifest['baseDependencyRestoreFiles']) == 220, 'Actual23/19/220 Model318 base')
    need({p.name for p in BASE.iterdir()} == {row['path'] for row in index['files']} | {'WORKSPACE_HASH_INDEX.json'}, 'Full unchanged base inventory')
    for row in index['files']:
        need(Path(row['path']).name == row['path'], 'Flat actual base alias')
        exact(BASE/row['path'], row)
    targets = [{'baseSavedDirectory': BASE_REL, **row} for row in manifest['files']] + manifest['baseDependencyRestoreFiles']
    need(len(targets) == len({row['restorePath'] for row in targets}) == 239, 'All239 distinct inherited targets')
    for row in targets:
        exact(Path(row['restorePath']), row)
    need(manifest['solverSourceRoot'] == SOLVER_ROOT, 'Literal existing solver root')
    need(progress['latestEditableSourceCoreScope'] == 313 and progress['latestSourceVerifiedCheckpoint']['nativeTotalFindings'] == 951 and progress['latestSourceVerifiedCheckpoint']['unqualifiedCurrentPourCount'] == 19, 'Editable313 remains separate from models')
    archive = BOARD/('cloud/artifacts/'+BASE_STEM+'.tar.gz')
    metadata = archive.with_name(BASE_STEM+'.manifest.json')
    need(regular(archive) and sha(archive) == BASE_ARCHIVE_SHA and regular(metadata) and sha(metadata) == BASE_MANIFEST_SHA, 'Actual tested Model318 archive/manifest')
    am = read(metadata)
    need(am['scope'] == 'PORTABLE_MODEL318_CA17_INCREMENT_NOT_FRESH_SOURCE' and len(am['files']) == 23 and am['archive']['sha256'] == BASE_ARCHIVE_SHA and am['archive']['bytes'] == archive.stat().st_size, 'Exact Model318 archive scope')
    need(am['snapshotPins'] == {BASE_REL+'/'+name: digest for name, digest in BASE_PINS.items()}, 'Archive binds all four actual metadata pins')
    need(regular(PREDECESSOR) and sha(PREDECESSOR) == PREDECESSOR_SHA, 'Reviewed build/verify predecessor is unchanged')
    return targets

def authenticate_known_profile(targets):
    need(regular(PROFILE) and sha(PROFILE) == PROFILE_SHA, 'Exact unbound corrected profile')
    profile = read(PROFILE)
    need(profile['readyForExecution'] is False and profile['actualPhysicalRunClosed'] is False, 'Still an unbound preparation')
    rows = profile['knownPayloadArtifacts']
    need(len(rows) == 40 and sum(row['bytes'] for row in rows) == 159438017, 'Measured known40 payloads/152.05MiB')
    need(len({row['restorePath'] for row in rows}) == len({row['savedPath'] for row in rows}) == 40, 'Unique source paths and explicit saved aliases')
    need(not ({row['restorePath'] for row in rows} & {row['restorePath'] for row in targets}), 'No local/base target overlap')
    for row in rows:
        need(Path(row['savedPath']).name == row['savedPath'], 'Flat explicit saved filename')
        exact(Path(row['restorePath']), row)
    need(all(profile['pendingActualBindings'][key] is None for key in ('runScope', 'candidate', 'report', 'collectedReceipt', 'ownedExecution', 'ownedLog', 'ownedMemorySamples', 'worker', 'independentPeer')), 'Actual run pins are deliberately absent')
    # Only the compact report is decoded. Its58MB predecessor is hash-only.
    compact_row = next(row for row in rows if row['sha256'] == profile['compactStrongSelfCompanionSha256'])
    compact = read(Path(compact_row['restorePath']))
    need(compact['mainProofSha256'] == profile['correctedPureProofSha256'] and compact['zeroIntroducedPreferredSelfFailuresAllFourOwners'] is True, 'Corrected compact proof binding')
    prior = compact['fullCompanionPredecessorPreserved']
    need(any(row['restorePath'] == prior['path'] and row['sha256'] == prior['sha256'] for row in rows), 'Full companion preserved without decoding it')
    need(compact['repairedFormerSource23NewFailurePair']['previousFailedProofSha256'] == profile['failedV1ProofSha256Preserved'], 'Failedv1 explicitly preserved')
    return profile

def describe_template():
    targets = authenticate_base()
    profile = authenticate_known_profile(targets)
    return {'scope': profile['scope'], 'readyForExecution': False, 'templateOnly': True,
        'knownPayloadCount': 40, 'knownPayloadBytes': 159438017, 'inheritedRestoreTargetCount': 239,
        'actualPhysicalRunBindingsReady': False, 'newCheckpointCreated': False, 'newArchiveCreated': False,
        'sdkExecuted': False, 'latestEditableSourceCoreScope': 313, 'all49Accepted': False,
        'fullBoardPassed': False, 'fullTimingPassed': False, 'electricalTimingQualified': False,
        'currentPourQualified': False, 'cadQualified': False, 'tiQualified': False, 'fabricationReady': False}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('describe-template', 'build', 'verify'))
    args = parser.parse_args()
    need(args.mode == 'describe-template', 'Unbound draft cannot build or verify; author a NEW pinned successor after actual328+ closure and independent review')
    print(json.dumps(describe_template(), allow_nan=False))

if __name__ == '__main__':
    main()
