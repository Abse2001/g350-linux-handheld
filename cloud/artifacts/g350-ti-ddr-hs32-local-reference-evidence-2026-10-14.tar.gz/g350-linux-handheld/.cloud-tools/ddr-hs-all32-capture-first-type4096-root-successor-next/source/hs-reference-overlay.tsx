import {Children,cloneElement,isValidElement,type ReactElement,type ReactNode} from "react"
import {buildV12eCTiWindowSource} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-c-fresh-ti-window-source-next/v12e-c-fresh-ti-window-overlay"
import proposal from "./joint-owner-proposal.json"

type Props=Record<string,unknown>&{name?:string;children?:ReactNode}
type Row=Record<string,any>
/** Source-only append of62 new HS terminal loop candidates. No original
 * element is rewritten; RAM7 remains its exact tested original declarations.
 * Raw mathematical site selection is not fresh Core/native acceptance. */
export function buildJointHsReferenceSource(){
 const rows=proposal.owners as Row[]
 if(rows.length!==64||new Set(rows.map(r=>r.pcb_port_id)).size!==64)throw Error("Exactly64 original HS numeric pad owners required")
 const selected=rows.filter(r=>r.status==="RAW_JOINT_GEOMETRY_CANDIDATE_PENDING_ACTUAL_SOURCE_CORE_NATIVE")
 const retained=rows.filter(r=>r.status==="RETAIN_EXISTING_RAM7_BYTE_EXACT")
 if(selected.length!==62||retained.length!==2||retained.some(r=>r.capacitor!=="C_DDR_RAM_7"))throw Error("Exactly31 new loops and originalRAM7 loop required")
 if(new Set(selected.map(r=>r.viaName)).size!==62||new Set(selected.map(r=>r.traceName)).size!==62)throw Error("Distinct new source owner names required")
 const base=buildV12eCTiWindowSource();let boards=0;const caps=new Set<string>();const originalNames=new Set<string>()
 const near=(a:unknown,b:number)=>typeof a==="number"&&Number.isFinite(a)&&Math.abs(a-b)<1e-9
 function apply(node:ReactNode):ReactNode{
  if(!isValidElement<Props>(node))return node
  const p={...node.props}
  if(p.name){
   originalNames.add(p.name)
   const cap=rows.find(r=>r.capacitor===p.name)
   if(cap){
    const pose=proposal.physicalPartPoseInventory.find(g=>g.source_component_id===cap.source_component_id)
    if(!pose||!near(p.pcbX,pose.center.x)||!near(p.pcbY,pose.center.y)||p.layer!==pose.layer||(p.pcbRotation??0)!==pose.rotation)throw Error("Original current HS cap pose changed: "+p.name)
    if(caps.has(p.name))throw Error("Original HS cap duplicated: "+p.name)
    caps.add(p.name)
   }
  }
  const children=Children.toArray(node.props.children).map(apply)
  if(node.type==="board"){
   boards++;if(p.layers!==4||p.routeRemaining!==false)throw Error("Four physical layers and routing-disabled source required")
   for(const r of selected){
    if(originalNames.has(r.viaName)||originalNames.has(r.traceName))throw Error("New HS owner collides with original source name")
    const v=r.via;const path=r.candidateBottomStub
    if(!v||v.layers.join(",")!=="top,inner1,inner2,bottom"||v.outer_diameter!==.4572||v.hole_diameter!==.254)throw Error("Exact full-depth reference dimensions required")
    if(!path||path.length!==2||path.some((q:Row)=>q.route_type!=="wire"||q.layer!=="bottom"||q.width!==.2)||!near(path[0].x,r.x)||!near(path[0].y,r.y)||!near(path[1].x,v.x)||!near(path[1].y,v.y))throw Error("Exact actual-pad to selected-via Bottom stub required")
    if(r.referenceNet!==(r.numericPin===1?"DDR_1V5":"GND"))throw Error("Capacitor terminal net identity changed")
    children.push(
     <via name={r.viaName} pcbX={v.x} pcbY={v.y} fromLayer="top" toLayer="bottom" outerDiameter={.4572} holeDiameter={.254} connectsTo={`net.${r.referenceNet}`} tented="top_and_bottom_tented"/>,
     <trace name={r.traceName} from={`${r.capacitor}.pin${r.numericPin}`} to={`.${r.viaName} > port.bottom`} thickness={.2} pcbPath={[]}/>,
    )
   }
  }
  return cloneElement(node as ReactElement<Props>,p,...children)
 }
 const element=apply(base.element)
 if(boards!==1||caps.size!==32)throw Error("Original one board/all32 HS capacitor identities required")
 return {...base,element,hsReferenceProposal:{scope:"RAW_JOINT62_TERMINAL_SOURCE_CANDIDATE_NOT_NATIVE_ACCEPTED",addedTerminalLoops:62,retainedRam7TerminalLoops:2,all32HsCapNamesHeld:true,existingRam7ElementsUnchanged:true,allOriginal280PartPosesAndSourcePropsMustPassFreshCapture:true,existingReferencePlaneCandidatesUnchanged:true,original49DdrRequestsAndConstraintsHeld:true,newCoreBuildPerformed:false,newNativeChecksPerformed:false,referenceQualified:false,accepted49:false,fabricationReady:false}}
}
export default()=>buildJointHsReferenceSource().element
