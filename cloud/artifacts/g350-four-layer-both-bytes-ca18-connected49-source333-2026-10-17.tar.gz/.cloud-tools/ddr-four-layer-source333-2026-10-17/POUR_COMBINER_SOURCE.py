#!/usr/bin/env python3
"""Combine exact plan331 fresh-Core both-byte-matched Source333 completed selected-pour contributions; no geometry/SDK execution."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path

PLAN_PATH = '/tmp/g350-both-bytes-ca18-model328-projector-root-20261017-run331/byte0-result.json'
PLAN_SHA = '7a10f9b14d9e6656ad7033279fdfdf2ca60047e855fdc9c36466cc9223250103'
CANDIDATE_SHA = '056cac41c6a654b417f6c088d871b8aab41bdaf1bfd42f570acd9dd42d7a09c8'
AUDIT_SOURCE_SHA = '88063399195e856c97a818771c0502e838a7f825e0bff20bfb5f915625ddd03d'
AUTH_SCOPE = 'EXPLICITLY_PINNED_M49_PLAN331_MODEL328_CA18_WIDE_CAP12_CAP8_TWO_PDN_AUTHENTICATED_236_MANUAL_VIA_TRACK_MANUFACTURING_DIAGNOSTIC'
RAW333_SHA = 'fcb39e6bb43d972f8d511671ffe30b40819d53aeaeb48fd05d8017f30667990d'
CONTROLS333_SHA = '435bf9061803ed2c903eeba7085e1f2b4bc77f6cdd7fd8137f024df9b49f1f38'
AUTH335_SHA = '46e2c5737899d698b9cbd195cd1901d4df3d88ce446bbe2f7eb85035c51b501d'
AUTH_POLICY = 'ONLY SourceTrace connected_source_port_ids and connected_source_net_ids; no PCB/copper/via alias/geometric union'
CAP_PROFILE = 'CAP12_TRANSLATE_X_0P79_ONLY'
COMBINED_PROFILE = 'CAP12_X0P79_CAP8_TWO_NEW_PDN_VIAS'
CAP8_PROFILE = 'CAP8_AT_0_7P9_TWO_NEW_PLANE_VIAS_VDD7P2'
PENDING = set()
LAYERS, EPS, REQUIRED = ['top', 'inner1', 'inner2', 'bottom'], 1e-8, .1016

def require(condition, message):
    if not condition:
        raise ValueError(message)

def pin(path, expected):
    require(len(expected) == 64 and all(c in '0123456789abcdef' for c in expected), 'Explicit lowercase SHA256 required')
    with path.open('rb') as f:
        data = f.read()
        require(hashlib.sha256(data).hexdigest() == expected, 'Input hash mismatch: ' + str(path))
        value = json.loads(data)
        os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return value

def index(rows, key):
    result = {}
    for row in rows:
        value = row.get(key)
        require(isinstance(value, str) and value not in result, 'Unique ' + key + ' required')
        result[value] = row
    return result

def numeric(value):
    return type(value) in (int, float) and math.isfinite(value)

def close(a, b):
    return numeric(a) and numeric(b) and abs(a - b) <= EPS

def xy(row):
    require(numeric(row.get('x')) and numeric(row.get('y')), 'Finite XY required')
    return [row['x'], row['y']]

class Uf:
    def __init__(self):
        self.parent = {}
    def add(self, value):
        self.parent.setdefault(value, value)
    def root(self, value):
        if value not in self.parent:
            return None
        if self.parent[value] != value:
            self.parent[value] = self.root(self.parent[value])
        return self.parent[value]
    def union(self, a, b):
        self.add(a); self.add(b)
        self.parent[self.root(b)] = self.root(a)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('input', 'controls', 'auth', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    for key in ('input-sha', 'controls-sha', 'auth-sha'):
        parser.add_argument('--' + key, required=True)
    parser.add_argument('--report', type=Path, action='append', required=True)
    parser.add_argument('--report-sha', action='append', required=True)
    args = parser.parse_args()
    require(args.input_sha == RAW333_SHA and args.controls_sha == CONTROLS333_SHA and args.auth_sha == AUTH335_SHA,
            'Only exact fresh Source333 raw/controls and completed auth335 bytes are permitted')
    require(all(len(v) == 64 and all(c in '0123456789abcdef' for c in v)
                for v in (args.input_sha, args.controls_sha, args.auth_sha)), 'Mandatory exact fresh raw/control/auth SHA256 pins required')
    RAW_SHA, CONTROLS_SHA, AUTH_SHA = args.input_sha, args.controls_sha, args.auth_sha
    require(len(args.report) == len(args.report_sha) and len(args.report) > 0 and
            len({p.resolve() for p in args.report}) == len(args.report), 'Each unique contribution needs one explicit report SHA')
    inputs = [('raw', args.input, args.input_sha), ('controls', args.controls, args.controls_sha),
              ('current236Ownership', args.auth, args.auth_sha), ('reviewedSourcePlan331', Path(PLAN_PATH), PLAN_SHA)]
    inputs += [('report_' + str(i), p, s) for i, (p, s) in enumerate(zip(args.report, args.report_sha))]
    require(not args.output.exists() and args.output.resolve() not in {p.resolve() for _, p, _ in inputs}, 'Fresh separate output required')
    loaded = {name: pin(path, digest) for name, path, digest in inputs}
    raw, controls, auth, plan = [loaded[k] for k in ('raw', 'controls', 'current236Ownership', 'reviewedSourcePlan331')]
    all49 = {'source_trace_' + str(i) for i in range(49)}
    routed = set(controls.get('routedOwnerIds', []))
    require(isinstance(raw, list) and controls.get('rawCoreSha256') == RAW_SHA and
            controls.get('partialCoreControlPassed') is True and controls.get('partialDiagnosticReplayControlsPassed') is True and
            len(controls.get('checks', [])) == 35 and all(c.get('passed') is True for c in controls['checks']) and
            controls.get('planSha256') == PLAN_SHA and controls.get('candidateSha256') == CANDIDATE_SHA,
            'Exact fresh Source333 controls, plan331 and candidate328 binding required')
    require(len(routed) == 49 and set(controls.get('pendingOwnerIds', [])) == PENDING and routed | PENDING == all49 and
            controls.get('expectedConnectedOwners') == 49 and controls.get('expectedPendingOwners') == 0,
            'Exact49 connected/no-pending partition required')
    graphs = index(controls.get('physicalGraphs', []), 'originalSourceTraceId')
    projections = index(controls.get('logical49Projection', []), 'originalSourceTraceId')
    require(set(graphs) == all49 and set(projections) == all49 and all(p.get('passed') is True for p in projections.values()) and
            all(graphs[s].get('physicallyConnectedByActualOwnedNumericIdGraph') is (s in routed) for s in all49),
            'All49 exact current logical and physical graphs required')
    require(plan.get('scope') == 'SOURCE33B_PARTIAL_MIXED_JOINED_EDITABLE_PLAN_SOURCE_PROJECTION_ONLY' and
            plan.get('inputBindings', {}).get('candidate', {}).get('sha256') == CANDIDATE_SHA and
            set(plan.get('routedOwnerIds', [])) == routed and set(plan.get('pendingOwnerIds', [])) == PENDING,
            'Exact reviewed cap12 plan331 required')
    n, i, a = len(plan['newVias']), len(plan['innerPortRegistrations']), len(plan['auxiliaryLocalTraces'])
    r = sum(len(g['wireRuns']) for g in plan['projectedGeometry'])
    cap8 = plan.get('cap8HardwareDelta', {})
    p, j = len(cap8.get('pdnVias', [])), len(cap8.get('innerPortRegistrations', []))
    inventory = {'physicalVias': 129 + n + p, 'pcbComponents': 409 + n + p,
                 'sourceAndPcbPorts': 1419 + 2 * n + i + 2 * p + j,
                 'sourceTraces': 1097 + a, 'physicalTraces': 165 + r + a,
                 'reactElements': 2036 + n + i + a + p + j,
                 'newVias': n + p, 'newInnerPorts': i + j, 'newSignalVias': n, 'newPdnVias': p,
                 'newSignalInnerPorts': i, 'newPdnInnerPorts': j,
                 'routedWireRuns': r, 'auxiliaryLocalTraces': a, 'routedOwners': 49, 'pendingOwners': 0}
    require((n, i, r, a, p, j) == (105, 82, 154, 0, 2, 4) and len(plan['replacedOriginals']) == 49
            and len(plan['projectedGeometry']) == 49
            and all(controls.get('expectedCounts', {}).get(k) == v for k, v in inventory.items()),
            'Exact actual plan331 N105/I82/R154/A0/P2/J4-derived234/319 inventory required')
    cap = plan.get('cap12HardwareDelta', {})
    require(plan.get('hardwareDeltaProfile') == COMBINED_PROFILE and cap.get('profile') == CAP_PROFILE and
            cap.get('candidateBinding') == plan['inputBindings']['candidate'] and
            cap.get('component', {}).get('sourcePlacement') == {
                'before': {'pcbX': 6, 'pcbY': 4.7, 'layer': 'bottom', 'pcbRotation': 180},
                'after': {'pcbX': 6.79, 'pcbY': 4.7, 'layer': 'bottom', 'pcbRotation': 180}} and
            cap.get('exactPhysicalScope') == {'componentCount': 280, 'heldPlacements': 279,
                'translatedPlacements': 1, 'totalLands': 1165, 'heldLands': 1163, 'translatedSmtPadsAndPorts': 2,
                'totalReferences': 165, 'heldReferences': 163, 'reroutedReferences': 2, 'heldReferenceVias': 129} and
            controls.get('cap12HardwareDeltaProfile') == CAP_PROFILE and controls.get('cap12HardwareDelta') == cap,
            'Exact cap12 hardware ledger and fresh controls required')
    require(cap8.get('profile') == CAP8_PROFILE
            and cap8.get('descriptorBinding', {}).get('sha256') == '20e698e6225f7aa0759aa4acf70103c5f90f3894ae94726336e098598b3f3976'
            and cap8.get('proofBinding', {}).get('sha256') == 'ec002642c791f3fdcd041e647202712020f9acccf20ced6e22302db20c5601c3'
            and cap8.get('candidateBinding') == plan['inputBindings']['candidate']
            and cap8.get('component', {}).get('sourcePlacement') == {
                'before': {'pcbX': 1.2, 'pcbY': 9.799999999999999, 'layer': 'bottom', 'pcbRotation': 0},
                'after': {'pcbX': 0, 'pcbY': 7.9, 'layer': 'bottom', 'pcbRotation': 0}}
            and controls.get('cap8HardwareDelta') == cap8
            and controls.get('cap8HardwareDeltaProfile') == CAP8_PROFILE,
            'Exact combined cap8 two-PDN ledger and fresh controls required')
    require(auth.get('scope') == AUTH_SCOPE and auth.get('logicalUfPolicy') == AUTH_POLICY and auth.get('complete') is True and
            auth.get('actualViaCount') == 236 and auth.get('completedViaCount') == 236 and
            auth.get('foreignViaTrackCopperClearancePassed') is True and auth.get('exactInputFilesUnchanged') is True and
            auth.get('requiredCopperEdgeClearanceMm') == REQUIRED and
            auth.get('inputBindings', {}).get('raw', {}).get('sha256') == RAW_SHA and
            auth.get('inputBindings', {}).get('controls', {}).get('sha256') == CONTROLS_SHA and
            auth.get('inputBindings', {}).get('plan', {}).get('sha256') == PLAN_SHA and
            auth.get('inputBindings', {}).get('candidate', {}).get('sha256') == CANDIDATE_SHA and
            auth.get('cap12HardwareDelta') == cap, 'Completed exact auth236 ownership/foreign-track scope required')
    for key in ('violations', 'ambiguousVias', 'identityFailures', 'invalidSegments', 'unresolvedSegmentOwners'):
        require(auth.get(key) == [], 'Current ownership report retains failures: ' + key)
    rows = lambda kind: [r for r in raw if r.get('type') == kind]
    pours, vias = index(rows('pcb_copper_pour'), 'pcb_copper_pour_id'), index(rows('pcb_via'), 'pcb_via_id')
    require(len(pours) > 0 and len(vias) == 236, 'Actual raw pour roster and exact236 vias required')
    sources = rows('source_trace')
    declarations = [{'sourceTraceId': r['source_trace_id'], 'connectedSourcePortIds': r.get('connected_source_port_ids', []),
                     'connectedSourceNetIds': r.get('connected_source_net_ids', [])} for r in sources]
    require(auth.get('declaredLogicalSources') == declarations, 'Exact actual Source-only declarations required')
    uf = Uf()
    for row in declarations:
        sid = row['sourceTraceId']; uf.add(sid)
        for value in row['connectedSourcePortIds'] + row['connectedSourceNetIds']:
            uf.union(sid, value)
    via_proofs = index(auth['viaReports'], 'pcbViaId')
    require(set(via_proofs) == set(vias), 'Exact via proof roster required')
    via_roots = {}
    for vid, proof in via_proofs.items():
        require(proof.get('aliasIdentityAuthenticated') is True and proof.get('logicalOwnerResolved') is True and
                proof.get('identityErrors') == [] and proof.get('unresolvedOwnerEvidence') == [] and
                len(proof.get('authenticatedLogicalRoots', [])) == 1 and
                proof.get('selectedLogicalRoot') in proof['authenticatedLogicalRoots'] and proof.get('violationCount') == 0,
                'Unresolved via identity: ' + vid)
        via_roots[vid] = proof['selectedLogicalRoot']
    projection = {p['actualSourceTraceId']: sid for sid, p in projections.items() if sid in routed}
    require(len(projection) == 49, 'Unique actual Source IDs for all49 routed owners required')
    wire_catalog = {}
    for trace in rows('pcb_trace'):
        sid = trace.get('source_trace_id')
        if sid not in projection:
            continue
        route = trace['route']
        for i, (a, b) in enumerate(zip(route, route[1:]), 1):
            if a.get('route_type') != 'wire' or b.get('route_type') != 'wire' or a.get('layer') != b.get('layer'):
                continue
            pa, pb = xy(a), xy(b)
            if math.dist(pa, pb) <= EPS:
                continue
            widths = [a.get('width'), b.get('width'), a.get('end_width', 0), b.get('end_width', 0)]
            require(a['layer'] in LAYERS and all(numeric(v) for v in widths) and max(widths) > 0, 'Unsupported current wire')
            key = trace['pcb_trace_id'] + ':' + str(i)
            require(key not in wire_catalog, 'Duplicate current wire identity')
            wire_catalog[key] = {'pcbTraceId': trace['pcb_trace_id'], 'actualSourceTraceId': sid,
                'originalOwner': projection[sid], 'segmentStartIndex': i - 1, 'segmentEndIndex': i,
                'a': pa, 'b': pb, 'layer': a['layer'], 'radius': max(widths) / 2, 'root': uf.root(sid)}
    require(wire_catalog and all(v['root'] is not None for v in wire_catalog.values()), 'Complete dynamic wire catalogue with declared owners required')
    expected_roster = [{'pcbCopperPourId': p['pcb_copper_pour_id'], 'layer': p.get('layer'),
                        'sourceNetId': p.get('source_net_id'), 'shape': p.get('shape')} for p in pours.values()]
    contributions = []
    baseline_identities = None
    baseline_distance = None
    baseline_policy = None
    for report_index, (path, report_sha) in enumerate(zip(args.report, args.report_sha)):
        label = 'report_' + str(report_index)
        report = loaded[label]
        require(report.get('scope') == 'SOURCE333_PLAN331_MODEL328_CA18_WIDE_BOTH_BYTES_MATCHED_CAP12_CAP8_TWO_PDN_LITERAL_SELECTED_FRESH_BREP_POUR_MARGIN_DIAGNOSTIC' and
                report.get('auditSourceSha256') == AUDIT_SOURCE_SHA and report.get('inputFilesUnchanged') is True,
                'Exact new reviewed Source333 audit and unchanged inputs required')
        expected_bindings = {'raw': RAW_SHA, 'controls': CONTROLS_SHA, 'current236Ownership': AUTH_SHA, 'reviewedSourcePlan331': PLAN_SHA}
        require(all(report.get('inputBindings', {}).get(k, {}).get('sha256') == v for k, v in expected_bindings.items()) and
                report.get('cap12HardwareDelta') == cap and report.get('cap12HardwareDeltaProfile') == CAP_PROFILE and
                report.get('cap8HardwareDelta') == cap8 and report.get('cap8HardwareDeltaProfile') == CAP8_PROFILE and
                report.get('freshPdnPlaneConnectivityQualified') is False and
                report.get('planDerivedInventory') == inventory and report.get('source248GeometryOrPourQualificationInherited') is False,
                'Every contribution must bind exact Source333/cap12/plan331/auth236 inputs')
        selected = report.get('selectedPourIds', [])
        require(selected and len(selected) == len(set(selected)) and set(selected) <= set(pours) and
                report.get('actualRawPourIds') == list(pours) and report.get('actualRawPourRoster') == expected_roster and
                report.get('actualRawPourCount') == len(pours) and
                set(report.get('omittedPourIds', [])) == set(pours) - set(selected) and
                len(report['omittedPourIds']) == len(pours) - len(selected), 'Exact actual/selected/omitted pour roster required')
        require(report.get('coverageScope') == ('EXPLICIT_ALL_ACTUAL_POURS' if set(selected) == set(pours) else 'EXPLICIT_SELECTED_POURS_ONLY') and
                report.get('wireScope') == 'all-routed' and set(report.get('wireOriginalOwners', [])) == routed and
                len(report['wireOriginalOwners']) == 49 and report.get('wireSegmentCount') == len(wire_catalog) and
                report.get('actualViaCount') == 236 and report.get('requiredForeignViaPourEdgeMm') == REQUIRED and
                report.get('requiredForeignWirePourEdgeMm') == REQUIRED and report.get('coordinateToleranceMm') == EPS and
                report.get('sourceRuleBridge') == controls.get('sourceRuleBridge'), 'Exact dynamic geometry scope and unchanged margin thresholds required')
        for key in ('globalIdentityFailures', 'viaIdentityFailures', 'unsupportedGeometry', 'unknownPourIdentities', 'violations'):
            require(report.get(key) == [], 'Contribution retains failures: ' + key)
        require(all(report.get(k) is False for k in ('all49Accepted', 'full49Accepted', 'fullBoardPassed',
                'electricalTimingQualified', 'nativeExecuted', 'cadExecuted', 'fabricationReady')), 'Acceptance boundaries remain false')
        identities = index(report.get('actualViaIdentities', []), 'pcbViaId')
        require(set(identities) == set(vias), 'Exact current236 via identity roster required')
        for vid, row in identities.items():
            require(row.get('failures') == [] and row.get('logicalRoot') == via_roots[vid] and
                    row.get('xy') == xy(vias[vid]) and set(row.get('layers', [])) == set(LAYERS), 'Exact actual via identity and Source-only root required')
        if baseline_identities is None:
            baseline_identities, baseline_distance, baseline_policy = report['actualViaIdentities'], report['distanceModel'], report['netExemptionPolicy']
        require(report['actualViaIdentities'] == baseline_identities and report['distanceModel'] == baseline_distance and
                report['netExemptionPolicy'] == baseline_policy, 'One exact geometry/exemption model across all contributions required')
        reports = index(report.get('pourReports', []), 'pcbCopperPourId')
        require(set(reports) <= set(selected), 'No contribution outside its explicit selected subset')
        is_completed = set(reports) == set(selected) and all(p.get('state') == 'COMPLETED' for p in reports.values())
        require(report.get('completed') is is_completed and report.get('literalForeignPourMarginClear') is is_completed and
                report.get('allActualPoursCompleted') is (is_completed and set(selected) == set(pours)), 'Retain exact selected and whole-coverage status')
        contributions.append((label, report))
    completed, excluded = {}, []
    for label, report in contributions:
        reports = index(report['pourReports'], 'pcbCopperPourId')
        exemptions = report['sameNetExemptions']
        for pid, pr in reports.items():
            require(pid in pours, 'Unknown reported pour')
            if pr.get('state') != 'COMPLETED':
                require(pr['state'] == 'BOUNDED_PARTIAL', 'Only explicitly bounded partial results may be excluded; unsupported/running results never qualify')
                excluded.append({'report': label, 'pcbCopperPourId': pid, 'state': pr['state'],
                                 'viaChecksExcluded': len(pr['viaChecks']), 'wireChecksExcluded': len(pr['wireChecks'])})
                continue
            require(pid not in completed, 'Duplicate completed pour coverage')
            pour = pours[pid]; root = uf.root(pour['source_net_id']); layer = pour['layer']
            require(root is not None and pour['shape'] == 'brep' and pr['layer'] == layer and
                    pr['sourceNetId'] == pour['source_net_id'] and pr['logicalRoot'] == root and pr['violations'] == [], 'Completed pour metadata mismatch')
            require(pr['outerVertices'] == len(pour['brep_shape']['outer_ring']['vertices']) and
                    pr['innerRings'] == len(pour['brep_shape'].get('inner_rings', [])), 'Literal BREP roster mismatch')
            expected_vias = {k for k in vias if via_roots[k] != root}
            expected_wires = {k for k, v in wire_catalog.items() if v['layer'] == layer and v['root'] != root}
            own_vias = set(vias) - expected_vias
            own_wires = {k for k, v in wire_catalog.items() if v['layer'] == layer and v['root'] == root}
            via_checks, wire_checks = index(pr['viaChecks'], 'identity'), index(pr['wireChecks'], 'identity')
            require(set(via_checks) == expected_vias and set(wire_checks) == expected_wires, 'Exact per-pour foreign object coverage required')
            ex = [v for v in exemptions if v['pour'] == pid]
            via_ex = [v for v in ex if v['kind'] == 'via']; wire_ex = [v for v in ex if v['kind'] == 'wire']
            require(len(ex) == len(via_ex) + len(wire_ex) == pr['sameNetExemptionCount'] and
                    len(via_ex) == len(own_vias) and {v['identity'] for v in via_ex} == own_vias and
                    len(wire_ex) == len(own_wires) and {v['identity'] for v in wire_ex} == own_wires and
                    all(v['layer'] == layer and v['authenticatedLogicalRoot'] == root and v['ownNetReentryQualified'] is False for v in ex), 'Authenticated exact same-net exemption roster required')
            gaps = []
            for kind, checks in (('via', via_checks), ('wire', wire_checks)):
                for identity, check in checks.items():
                    require(check.get('kind') == kind and check.get('layer') == layer and check.get('passed') is True and
                            check.get('requiredMm') == REQUIRED and check.get('pourLogicalRoot') == root and
                            numeric(check.get('edgeClearanceMm')) and check['edgeClearanceMm'] >= REQUIRED - EPS and
                            check.get('overlap') is False and close(check.get('centerlineDistanceToFilledPourMm', float('nan')) - check.get('copperRadiusMm', float('nan')), check['edgeClearanceMm']),
                            'Every completed foreign comparison must pass its unchanged threshold')
                    if kind == 'via':
                        require(check['xy'] == xy(vias[identity]) and check['objectLogicalRoot'] == via_roots[identity] and
                                close(check['copperRadiusMm'], vias[identity]['outer_diameter'] / 2) and set(check['allPhysicalLayers']) == set(LAYERS), 'Via comparison geometry mismatch')
                    else:
                        v = wire_catalog[identity]
                        require(all(check.get(k) == value for k, value in v.items()) and check['objectLogicalRoot'] == v['root'] and
                                close(check['copperRadiusMm'], v['radius']), 'Wire comparison geometry mismatch')
                    gaps.append(check['edgeClearanceMm'])
            completed[pid] = {'pcbCopperPourId': pid, 'sourceReport': label, 'layer': layer, 'state': 'COMPLETED',
                              'foreignViaChecks': len(via_checks), 'foreignWireChecks': len(wire_checks),
                              'sameNetExemptions': len(ex), 'minimumForeignEdgeGapMm': min(gaps) if gaps else None,
                              'zeroViolations': True}
    require(set(completed) == set(pours), 'Every actual pour must have exactly one fully reconstructed completed contribution')
    report = {'scope': 'SOURCE333_PLAN331_MODEL328_CA18_WIDE_BOTH_BYTES_MATCHED_CAP12_CAP8_TWO_PDN_ALL_ACTUAL_LITERAL_POURS_COMPLETED_COVERAGE_AGGREGATE_NOT_BOARD_QUALIFICATION',
        'inputBindings': {name: {'path': str(path), 'sha256': digest} for name, path, digest in inputs},
        'auditSourceSha256': AUDIT_SOURCE_SHA, 'candidate328Sha256': CANDIDATE_SHA,
        'actualRawPourIds': list(pours), 'actualRawPourRoster': expected_roster,
        'actualRawPourCount': len(pours), 'completedPourCount': len(completed),
        'completedPourIds': list(pours), 'completedPourReports': [completed[pid] for pid in pours],
        'excludedBoundedPartialReports': excluded,
        'actualViaCount': 236, 'wireSegmentCount': len(wire_catalog), 'wireOwnerCount': 49,
        'planDerivedInventory': inventory, 'cap12HardwareDeltaProfile': CAP_PROFILE, 'cap12HardwareDelta': cap,
        'cap8HardwareDeltaProfile': CAP8_PROFILE, 'cap8HardwareDelta': cap8, 'freshPdnPlaneConnectivityQualified': False,
        'requiredForeignViaPourEdgeMm': REQUIRED, 'requiredForeignWirePourEdgeMm': REQUIRED,
        'coordinateToleranceMm': EPS, 'identityFailures': [], 'unsupportedGeometry': [], 'violations': [],
        'allCompletedComparisonRostersReconstructedFromExactRaw': True,
        'sameExactRawControlsAuthAcrossAllContributions': True,
        'completed': True, 'literalForeignPourMarginClear': True,
        'minimumForeignEdgeGapMm': min(v['minimumForeignEdgeGapMm'] for v in completed.values() if v['minimumForeignEdgeGapMm'] is not None),
        'source248GeometryOrPourQualificationInherited': False, 'source257GeometryOrPourQualificationInherited': False, 'source264GeometryOrPourQualificationInherited': False, 'source313GeometryOrPourQualificationInherited': False,
        'all49Accepted': False, 'full49Accepted': False, 'fullBoardPassed': False, 'electricalTimingQualified': False,
        'referenceQualified': False, 'ownNetReentryQualified': False, 'referenceWireGeometryIncluded': False,
        'nativeExecuted': False, 'cadExecuted': False, 'fabricationReady': False,
        'scopeLimits': ['Only exact Source333 actual236 vias and current49 routed-owner wire segments against its complete literal raw pour roster.',
                        'Only completed contributions are used; bounded partial entries and all their comparison rows are excluded.',
                        'No earlier Source248, Source257 or Source264 result, full-board, own-net reentry, reference, TI, delay, CAD or fabrication qualification is inherited.']}
    def file_sha(path):
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(block)
        return digest.hexdigest()
    require(all(file_sha(path) == digest for _, path, digest in inputs), 'Every pinned input and contribution must remain byte-identical')
    report['inputFilesUnchanged'] = True
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({'completedPours': len(completed), 'actualVias': 236, 'routedWireSegments': len(wire_catalog),
                      'literalForeignPourMarginClear': True, 'all49Accepted': False, 'geometryExecutedByCombiner': False}))

if __name__ == '__main__':
    main()
