#!/usr/bin/env python3
"""Root-reviewed own-stdlib material audit and narrowly gated fontcache repair.

Audit is read-only except its fresh report. Repair is Root-only: every mutation
must first be proven confined to the disposable rootfs fontconfig cache. Original
cache bytes/modes come only from the exact existing image layer. No SDK runs;
the image/archive/manifest/boards/frozen Source are never written.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import time

BOARD=Path('/workspace/g350-linux-handheld')
MANIFEST=BOARD/'.cloud-tools/kicad10-single-rootfs-root-20261016/ROOTFS.json'
MANIFEST_SHA='61b8b426aaa3220d5413480cc0e32f901e367020d723fc0496ca9489b97f14c9'
IMAGE=BOARD/'.cloud-tools/kicad10-debian.tar'
IMAGE_SHA='70a47643a9a6d89cca64579b5ef6bab5a290803ccc94ed9b9e170fb14c70b6bb'
LAYER='blobs/sha256/dc6bd6081d010129ac314430968e4a36f2c066bcda19468fc1c1fbc9fc80f938'
RECEIPT=Path('/tmp/g350-source272-kicad-api-posix-root-20261016-run296/COLLECTED.json')
RECEIPT_SHA='82516c2e02782dfed7fdfe659a37bdaa36787d662417f6888c4409afd41ffb2d'
PREFIX='var/cache/fontconfig/'

def need(ok,message):
    if not ok: raise ValueError(message)

def regular(p): return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while block:=f.read(1048576): h.update(block)
        if hasattr(os,'posix_fadvise'): os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
    return h.hexdigest()

def relative(v):
    p=PurePosixPath(v)
    need(p.parts and not p.is_absolute() and '..' not in p.parts and str(p)==v,'Canonical contained POSIX path')
    return Path(*p.parts)

def write(path,obj):
    need(not path.exists() and path.parent.is_dir(),'Fresh owned report only')
    with path.open('x') as f: json.dump(obj,f,indent=2,allow_nan=False);f.write('\n');os.fchmod(f.fileno(),0o600)

def metadata(p):
    st=p.lstat()
    base={'mode':stat.S_IMODE(st.st_mode),'device':st.st_dev,'inode':st.st_ino,'mtimeNs':st.st_mtime_ns,'ctimeNs':st.st_ctime_ns}
    if p.is_symlink(): return {**base,'kind':'symlink','target':os.readlink(p)}
    if stat.S_ISREG(st.st_mode): return {**base,'kind':'regular','bytes':st.st_size,'sha256':digest(p)}
    return {**base,'kind':'directory' if stat.S_ISDIR(st.st_mode) else 'special'}

def pinned():
    for p,h in [(MANIFEST,MANIFEST_SHA),(IMAGE,IMAGE_SHA),(RECEIPT,RECEIPT_SHA)]:
        need(regular(p) and digest(p)==h,'Exact immutable input '+str(p))
    m=json.loads(MANIFEST.read_bytes());r=json.loads(RECEIPT.read_bytes());root=Path(m['rootfs'])
    need(m['complete'] is True and m['regularFiles']==18238 and m['linkCount']==2115 and root.is_dir() and root.resolve()==root,'Exact completed293 disposable image rootfs')
    need(r['scope']==296 and r['hostOwnedGroupEmpty'] is True and r['sourcePinsUnchanged'] is True and r['inputFilesUnchanged'] is True
         and r['execution']['cleanupOwnedGroupEmpty'] is True,'296 fully collected and owned group empty before audit/repair')
    return m,root

def scan(m,root):
    started=time.monotonic();changes=[];checked=0;entries={r['path']:r for r in m['entries']};links={r['path']:r for r in m['links']}
    need(len(entries)==18238 and len(links)==2115 and not(set(entries)&set(links)),'Exact unique manifest roster')
    for name,row in entries.items():
        need(time.monotonic()-started<55,'Full read-only audit55-second bound')
        p=root/relative(name);need(p.parent.resolve().is_relative_to(root),'Contained expected file parent')
        actual=metadata(p) if p.exists() or p.is_symlink() else {'kind':'missing'}
        expected={'kind':'regular',**{k:row[k] for k in ('bytes','sha256','mode')}}
        if not all(actual.get(k)==v for k,v in expected.items()): changes.append({'path':name,'change':'expected_file_differs','expected':expected,'actual':actual})
        checked+=1
    for name,row in links.items():
        need(time.monotonic()-started<55,'Full link audit bound')
        p=root/relative(name);need(p.parent.resolve().is_relative_to(root),'Contained expected link parent')
        actual=metadata(p) if p.exists() or p.is_symlink() else {'kind':'missing'}
        good=actual['kind']=='symlink' and actual.get('target')==row['target'] if row['symbolic'] else False
        if not row['symbolic']:
            q=root/relative(row['target'])
            good=regular(p) and regular(q) and p.stat().st_dev==q.stat().st_dev and p.stat().st_ino==q.stat().st_ino
        if not good: changes.append({'path':name,'change':'expected_link_differs','expected':row,'actual':actual})
        checked+=1
    actual_names=set()
    for current,dirs,files in os.walk(root,followlinks=False):
        need(time.monotonic()-started<55,'Full extra-entry audit bound')
        for name in dirs+files:
            p=Path(current)/name
            if p.is_symlink() or not p.is_dir(): actual_names.add(p.relative_to(root).as_posix())
    for name in sorted(actual_names-set(entries)-set(links)):
        changes.append({'path':name,'change':'extra_entry','expected':None,'actual':metadata(root/relative(name))})
    confined=all(c['path'].startswith(PREFIX) and '/' not in c['path'][len(PREFIX):] for c in changes)
    repairable=confined and all(c['change'] in ('expected_file_differs','extra_entry') and c['actual']['kind'] in ('regular','missing')
        and (c['change']!='extra_entry' or re.fullmatch('[0-9a-f]{32}-[A-Za-z0-9]+\\.cache-[0-9]+(?:\\.NEW)?',c['path'][len(PREFIX):])) for c in changes)
    return {'scope':'ROOT293_FULL_IMAGE_MATERIAL_AUDIT_AFTER_CLOSED296_NO_REPAIR','complete':True,'rootfs':str(root),
        'inputBindings':{'manifest':{'path':str(MANIFEST),'sha256':MANIFEST_SHA},'image':{'path':str(IMAGE),'sha256':IMAGE_SHA},'closed296':{'path':str(RECEIPT),'sha256':RECEIPT_SHA}},
        'expectedRegularFilesChecked':len(entries),'expectedLinksChecked':len(links),'actualFileOrLinkCount':len(actual_names),
        'changes':changes,'changeCount':len(changes),'allChangesConfinedToFontconfigCache':confined,'narrowRepairPreconditionsSatisfied':bool(repairable),
        'imageMaterialExactlyMatchesOriginal':not changes,'elapsedSeconds':time.monotonic()-started,
        'sdkExecuted':False,'rootfsModifiedByAudit':False,'manifestModified':False,'frozenEvidenceModified':False,'all49Accepted':False,'fabricationReady':False}

def repair(audit_path,audit_sha,out):
    need(regular(audit_path) and digest(audit_path)==audit_sha,'Explicit actual read-only audit SHA')
    old=json.loads(audit_path.read_bytes());m,root=pinned();current=scan(m,root)
    need(old['scope']==current['scope'] and old['complete'] is True and old['rootfs']==str(root)
         and old['inputBindings']==current['inputBindings'] and old['changes']==current['changes']
         and current['narrowRepairPreconditionsSatisfied'] is True and current['changeCount']>0,'Exact unchanged actual cache-only audit before any write')
    need(out.is_absolute() and out.parent.resolve()==Path('/tmp') and out.name.startswith('g350-kicad10-fontcache-repair-') and not out.exists(),'Fresh owned repair diagnostics only')
    original={r['path']:r for r in m['entries'] if r['path'].startswith(PREFIX)}
    need(len(original)==14 and not any(r['path'].startswith(PREFIX) for r in m['links']),'Exact14 regular baseline cache files and no cache links')
    contents={}
    with tarfile.open(IMAGE,mode='r:') as outer:
        need(outer.getmember(LAYER).size==1536673280,'Exact pinned single rootfs layer')
        with tarfile.open(fileobj=outer.extractfile(LAYER),mode='r|') as layer:
            for item in layer:
                if item.name not in original: continue
                row=original[item.name];need(item.isfile() and item.size==row['bytes'] and (item.mode&0o777)==row['mode'],'Original regular cache metadata from image')
                blob=layer.extractfile(item).read();need(hashlib.sha256(blob).hexdigest()==row['sha256'],'Exact original image cache bytes')
                need(item.name not in contents,'No duplicate image cache member');contents[item.name]=blob
    need(set(contents)==set(original),'All14 baseline cache payloads recovered before writes')
    need(scan(m,root)['changes']==current['changes'] and digest(audit_path)==audit_sha,'No mutation during source recovery')
    out.mkdir(mode=0o700);before=out/'before';before.mkdir(mode=0o700);actions=[]
    for i,change in enumerate(current['changes']):
        p=root/relative(change['path'])
        if change['actual']['kind']=='regular':
            blob=p.read_bytes();backup=before/(str(i)+'.bin')
            with backup.open('xb') as f:f.write(blob);os.fchmod(f.fileno(),0o600)
            need(hashlib.sha256(blob).hexdigest()==change['actual']['sha256'],'Before bytes preserved exactly')
            change['beforePayload']={'path':str(backup),'bytes':len(blob),'sha256':digest(backup)}
    # All removals are exact observed new regular fontconfig outputs, never a
    # directory, symlink, original baseline file, or anything outside this cache.
    for change in current['changes']:
        if change['change']!='extra_entry': continue
        p=root/relative(change['path']);need(metadata(p)==change['actual'],'Exact new cache output still present')
        p.unlink();actions.append({'kind':'remove_proven_new_fontcache_file','path':change['path'],'before':change['actual'],'beforePayload':change['beforePayload']})
    for name,row in sorted(original.items()):
        p=root/relative(name);need(p.parent.resolve()==root/'var/cache/fontconfig' and not p.is_symlink(),'Only exact owned cache file writes')
        # Same-directory exclusive temporary permits atomic replacement on the
        # workspace filesystem; /tmp diagnostics are a different filesystem.
        # This exact owned temporary is never a manifest or preexisting file.
        temporary=p.with_name('.g350-owned-original-'+p.name)
        need(not temporary.exists() and not temporary.is_symlink(),'Fresh exact owned cache temporary')
        with temporary.open('xb') as f:f.write(contents[name]);os.fchmod(f.fileno(),row['mode'])
        os.replace(temporary,p);actions.append({'kind':'restore_exact_original_cache_file','path':name,'after':row})
    after=scan(m,root);need(after['imageMaterialExactlyMatchesOriginal'] is True,'Full18238-file/2115-link/extra inventory must be exact after repair')
    for p,h in [(MANIFEST,MANIFEST_SHA),(IMAGE,IMAGE_SHA),(RECEIPT,RECEIPT_SHA),(audit_path,audit_sha)]: need(digest(p)==h,'Immutable input unchanged')
    report={'scope':'ROOT_ONLY_EXACT_BASELINE_FONTCONFIG_CACHE_REPAIR_AFTER_CLOSED296','passed':True,'audit':{'path':str(audit_path),'sha256':audit_sha},
        'beforeAudit':current,'actions':actions,'afterAudit':after,'originalManifestSha256':MANIFEST_SHA,'originalImageSha256':IMAGE_SHA,
        'allChangesWereConfinedToFontconfigCache':True,'everyBaselineCacheFileRestoredFromPinnedImage':True,
        'allNoncacheFileAndLinkMaterialExact':True,'manifestEdited':False,'imageArchiveEdited':False,'sdkExecuted':False,
        'all49Accepted':False,'fabricationReady':False}
    write(out/'REPAIR.json',report);print(json.dumps({'report':str(out/'REPAIR.json'),'sha256':digest(out/'REPAIR.json'),'passed':True,'sdkExecuted':False}))

def main():
    ap=argparse.ArgumentParser(description=__doc__);sub=ap.add_subparsers(dest='mode',required=True)
    a=sub.add_parser('audit');a.add_argument('--output',type=Path,required=True)
    a=sub.add_parser('repair');a.add_argument('--audit-report',type=Path,required=True);a.add_argument('--audit-sha',required=True);a.add_argument('--output-dir',type=Path,required=True)
    args=ap.parse_args()
    if args.mode=='audit':
        need(args.output.is_absolute() and args.output.parent.resolve()==Path('/tmp') and args.output.name.startswith('g350-kicad10-fontcache-audit-'),'Fresh owned /tmp audit report')
        m,root=pinned();report=scan(m,root)
        need(digest(MANIFEST)==MANIFEST_SHA and digest(IMAGE)==IMAGE_SHA and digest(RECEIPT)==RECEIPT_SHA,'Inputs unchanged during audit')
        write(args.output,report);print(json.dumps({'report':str(args.output),'sha256':digest(args.output),'changeCount':report['changeCount'],
            'allChangesConfinedToFontconfigCache':report['allChangesConfinedToFontconfigCache'],'narrowRepairPreconditionsSatisfied':report['narrowRepairPreconditionsSatisfied'],'sdkExecuted':False}))
    else: repair(args.audit_report,args.audit_sha,args.output_dir)

if __name__=='__main__':main()
