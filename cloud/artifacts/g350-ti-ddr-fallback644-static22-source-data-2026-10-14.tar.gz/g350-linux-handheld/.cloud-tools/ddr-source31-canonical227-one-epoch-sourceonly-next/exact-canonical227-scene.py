"""Copy ONLY canonical227 unchanged Scene definition; no coordinator/application run."""
from pathlib import Path
import importlib.util,json,math,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
HP=ROOT.parent/'ddr-reset10-context12-two-owned-breakout-227-sourceonly-next/material-reset227-proposal.py'
sp=importlib.util.spec_from_file_location('literal227_material',HP);z=importlib.util.module_from_spec(sp);sp.loader.exec_module(z)
CONTROLLER=ROOT.parent/'ddr-context12-reset227-global-pool-sourceonly-next/recheck-and-freeze227-02.py'
assert z.g.sha(CONTROLLER)=='c89a495e0a9d775d2e35ade53e835c805571c01af4b159e0c824ede6b0386ce1'
POOL=ROOT.parent/'ddr-context12-reset227-global-pool-sourceonly-next/GLOBAL_LITERAL227_LATEST_MATCHED_B1_ALL49_CANDIDATE_POOL03.json'
document=json.loads(POOL.read_text())
assert document['materialContextPin']['sha256']==z.g.sha(z.CONTEXT)
reserved=document['reservedGroundRegions']
code=CONTROLLER.read_text();fragment=code[code.index('class Scene(z.Scene):'):code.index('candidate={};domains={};rejected=[];seen=set();pairnames=set().union(*pairunits)')]
exec(compile(fragment,str(CONTROLLER),'exec'))
exactCanonicalFixedWidthFloorOverrideAndGroundReservationContractCopied=True
