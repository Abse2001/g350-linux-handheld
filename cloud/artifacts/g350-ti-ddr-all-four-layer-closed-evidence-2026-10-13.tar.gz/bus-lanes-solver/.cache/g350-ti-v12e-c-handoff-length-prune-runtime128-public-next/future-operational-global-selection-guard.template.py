"""Source-only stage-controller proposal; only explicit qualified root launch runs routing.

Uses the exact bound Linux owned-process helper and original policies. Preparing
or importing this file does not spawn children or import solver/native modules.
"""
from pathlib import Path
import argparse, datetime, hashlib, importlib.util, json, math, os, re, stat, sys
sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parent
BASE = Path('/workspace/bus-lanes-solver/.cache/g350-count-conditioned-site-recovery-next')
QUAL = Path('/workspace/bus-lanes-solver/.cache/g350-positive-native-bank-replay-v5-next')
PARENT = Path('/workspace/bus-lanes-solver/.cache/g350-ti-v7-v5-stage-primitives-point-annotation-overload-public-next')
NODE = '/workspace/g350-linux-handheld/.cloud-tools/node/bin/node'
BUN = '/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
SMALL_POLICY = {'wallSeconds': 60, 'rssBytes': 1024**3, 'sharedBytes': 24*1024**3, 'sampleSeconds': .05, 'termGraceSeconds': 5}
PUBLIC_POLICY = {'wallSeconds': 1200, 'rssBytes': 5*1024**3, 'sharedBytes': 26*1024**3, 'sampleSeconds': .05, 'termGraceSeconds': 5}
RUNTIME_SHA = 'b3de08d028a63cac1f45bcbb7b1d3568ca93640395f58d2fc915ef13f8c4e681'
RUNTIME_CLOSURE = '96bc9fe16d23f2d7b9b76d984aca2c0ae106a297b7614cf10266d0f8f2efae43'
OPTIONS = {'maxBusViaCountSkew': 0, 'maxPairViaCountSkew': 0, 'precheckEnclosedTerminals': True, 'originalCorridorTuningCandidates': 4096}
OBSERVATION_MODE = 'PRIMITIVE_GRID_REPLAY_STATS_AND_PUBLIC_STEP_ONLY'
ROOT_SCOPE = 'one-node25-v5-handoff-prune-runtime128-ti-v12e-c-cohort-patched-fanout-public-control'
QUAL_SCOPE = 'one-node25-v5-handoff-prune-runtime128-ti-v12e-c-cohort-patched-fanout-build-control'
PREVIOUS_PUBLIC_CLOSED_PATH = Path('/workspace/bus-lanes-solver/.cache/root-routing-progress/v12e-c-v2-public-COLLECTED-root.json')
PREVIOUS_PUBLIC_CLOSED_SHA = '42158cba42d22f2c0a6a5c11f4f03389faa17a1dba9f197fb530db1469b7cc40'
PREVIOUS_PUBLIC_OWNED_PGID = 292304
CONTROL_NAMES = ['qualification-build', 'api-bun', 'api-node', 'stats-bun', 'stats-node', 'stage-bundledBun', 'stage-bundledNode'] + [
    'native-' + fixture + '-' + engine + ('-observed' if observed else '-plain')
    for fixture in ['common', 'replay']
    for engine in ['unbundledBun', 'bundledBun', 'bundledNode']
    for observed in [False, True]
]
BUILD_ARTIFACTS = [
    prefix + suffix
    for prefix in ['runner', 'api-controls', 'native-controls', 'stats-controls', 'stage-controls']
    for suffix in ['.cjs']
] + ['bundle-metafile.json', 'build-receipt.json'] + [
    prefix + suffix
    for prefix in ['api-controls', 'native-controls', 'stats-controls', 'stage-controls']
    for suffix in ['-metafile.json', '-build-receipt.json']
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def write_new(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def verify_files(directory, rows):
    for row in rows:
        path = Path(row['path']) if directory is None else directory / row['path']
        assert not path.is_symlink() and path.is_file(), str(path)
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], str(path)
        assert stat.S_IMODE(path.stat().st_mode) == row['mode'], str(path)



FAMILY_SHA = 'ec6b1cee5ecac0ace96d79b97f70d2e409941878dbf25dbc2af74c1a6e39dacb'
FAMILY = Path('/workspace/bus-lanes-solver/.cache/g350-ti-v7-v5-cross-family-selection-qualification-v2-next')
V10_CONTEXT = Path('/workspace/bus-lanes-solver/.cache/g350-ti-v10-actual-core-input-provenance-next')
V10_CONTEXT_SHA = '808973497c8fc33ef8e012fd0026eaef024aa12bf8505a71b9875fa6b84ccf97'
NODE5_NAMES = ['build-deterministic', 'node-caller-plain', 'node-caller-observed', 'node-native-common-observed', 'node-native-replay-observed']
NODE5_OUTPUTS = ['runner.cjs', 'bundle-metafile.json', 'build-receipt.json'] + [prefix + suffix for prefix in ['api-controls', 'native-controls', 'stats-controls', 'stage-controls', 'selection-controls', 'caller-selection-controls'] for suffix in ['.cjs', '-metafile.json', '-build-receipt.json']]

def verify_family_and_v12e(packet):
    assert sha(ROOT / 'CROSS-FAMILY-QUALIFIED.json') == packet['inheritedFamilyReceiptSha256'] == FAMILY_SHA
    proof = json.loads((ROOT / 'CROSS-FAMILY-QUALIFIED.json').read_bytes())
    assert proof['passed'] is True and proof['preparedManifestSha256'] == '64d84c729f54379a56a1ab0ced70968f863ec1fae12f79d78f8628e0a8c1d3d5'
    assert proof['observerSha256'] == sha(ROOT / 'global-selection-primitives.ts') == '941e161193e6e4c5d45e26d15760761ff75bec70ee70481da4b3a430a48c78bd'
    for field in ['source164Runtime127AndCompiled21ArtifactsHeld', 'sameNineNetPhysicsYieldsAndRawStates', 'candidateConnectionOrCarrierOwnerOwnDataOnly', 'unknownGetterMixedShapesFailClosed', 'originalCallbackAndAllArgumentsReceiverResultsErrorsPreserved', 'dependenciesMainGitHeldOomZeroAndGroupsEmpty']:
        assert proof[field] is True
    assert proof['unbundledGlobalObserverQualified'] is False and proof['actualG350Routing'] is False and proof['accepted49'] is False
    assert len(proof['actualOriginalNativeNineNetCallerBothEngines']) == 2
    assert all(row['actualNative9CallerPlainObservedParity'] is True and row['poolHits'] > 0 and row['pruneHits'] > 0 and row['assignments'] > 0 for row in proof['actualOriginalNativeNineNetCallerBothEngines'])
    assert len(proof['physics1879And4275HistoricalParities']) == 4 and all(row['fullHistoricalLedgerParityExcludingOnlyGlobalSelection'] is True and row['assertions'] in [1879,4275] for row in proof['physics1879And4275HistoricalParities'])
    assert proof['runtimeLibraryManifestSha256'] == '383dab3993fbd2128ad67bf3220f1342ef6252edad5c118264c9232ee03541b5' and proof['runtimeClosureSha256'] == '3f221c12ec2bf0040728eb3839ed60376a30f805ac46a6a1e768f3ff28bcdc7c'
    binding = module('v10_pure_input_context', V10_CONTEXT / 'v10_input_provenance.py')
    binding.verify(V10_CONTEXT_SHA)
    bridge = module('v11_pure_layer_bridge', Path(packet['v12eCBridgeModulePath']))
    actual = bridge.verify_producer_inputs(ROOT, packet['v12eCBridgeManifestSha256'])
    assert actual['signalLayersAllowed']==['top','inner1','inner2','bottom'] and actual['naturallyDerivedGenericDefaultCap']==800_000 and actual['nativePlacementChecks']==17
    assert actual['referenceQualified'] is False and actual['TIplaneArrangement'] is False
    assert actual['nativePlacementErrors']==0 and actual['actualCoreInputQualified'] is True
    assert actual['sourceInputParityQualified'] is True and actual['exactAll49SourceConnectionsQualified'] is True
    assert actual['proposedThreeRigidXMotionsExactlyHeld'] is True and actual['actualFinalReactTreeEvaluated'] is True

def node5_ledger(path):
    rows=[]
    for line in Path(path).read_text().splitlines():
        try: value=json.loads(line)
        except json.JSONDecodeError: continue
        if isinstance(value,dict) and ('mode' in value or 'fixtureReport' in value): rows.append(value)
    assert len(rows)==1
    return rows[0]

def selection_semantics_without_elapsed(value):
    assert isinstance(value,dict)
    result=json.loads(json.dumps(value))
    last=result.get('last')
    if last is not None:
        assert isinstance(last,dict) and 'elapsedMs' in last
        elapsed=last.pop('elapsedMs')
        assert type(elapsed) in [int,float] and math.isfinite(elapsed) and elapsed>=0
    return result

def node5_rows(packet):
    rows=list(packet['files'])
    relative=NODE5_OUTPUTS + ['node5-qualification-receipt.json'] + ['qualification-node5/'+name+'/'+part for name in NODE5_NAMES for part in ['execution.json','child.log','memory.jsonl']] + ['qualification-node5/'+name+'-argv.json' for name in NODE5_NAMES]
    for name in relative:
        path=ROOT/name
        assert path.is_file() and not path.is_symlink()
        rows.append({'path':name,'sha256':sha(path),'bytes':path.stat().st_size,'mode':stat.S_IMODE(path.stat().st_mode)})
    assert len({row['path'] for row in rows})==len(rows)
    return rows

def qualify_build_only(packet, prepared_sha, authority_path, authority_sha):
    root_authority(authority_path, authority_sha, prepared_sha, QUAL_SCOPE, SMALL_POLICY)
    assert not any((ROOT/name).exists() for name in ['runner.cjs','error-capture-qualification','QUALIFIED-candidate-manifest.json','FINAL-manifest.json'])
    before_deps = dependency_check()
    scope = module('error_capture_qualification_scope', BASE/'process_scope.py')
    run = ROOT/'error-capture-qualification'; run.mkdir(); (run/'tmp').mkdir()
    results = []
    for name, argv in [('build-deterministic', [NODE,str(ROOT/'build.cjs')]),('private-class-origin',[NODE,str(ROOT/'private-selection-origin-controls.cjs'),'--run-one-approved'])]:
        arg_path=run/(name+'-argv.json');write_new(arg_path,argv)
        execution=controlled_run(scope,'error-capture-qualification/'+name,[BUN,'--smol',str(ROOT/'build-leader.ts'),str(arg_path)],SMALL_POLICY,2*1024**3,{'TMPDIR':str(run/'tmp'),'G350_PRIVATE_CLASS_ORIGIN_APPROVED':'1','G350_PRIVATE_CLASS_ORIGIN_DIRECTORY':str(run)})
        results.append({'name':name,'execution':execution})
        if not clean(execution):
            write_new(ROOT/'error-capture-qualification-receipt.json',{'passed':False,'results':results,'scope':'Fresh deterministic build only; no solver/native calls'})
            return 1
        prepared()
    assert (ROOT/'actual-final-v12e-c-authored-props.json').stat().st_size <= 64*1024
    bridge=module('v11_actual_final_props',Path(packet['v12eCBridgeModulePath']))
    final_props=bridge.verify_actual_authored_props(ROOT/'actual-final-v12e-c-authored-props.json')
    assert final_props['actualFinalReactTreeEvaluated'] is True and final_props['captureSha256']==packet['actualV12eCReactCaptureSha256']
    build=json.loads((ROOT/'build-receipt.json').read_bytes()); assert build['deterministicTwoBuilds'] is True and build['bundleSha256']==sha(ROOT/'runner.cjs')
    verify_private_fanout_build(packet,build)
    included={r['realpath']:r for r in build['inputBindings']}
    for relative in ['coupled-pair-routing.ts','coupled-handoff-length-bound.ts']:
        p=ROOT/'source/lib'/relative;assert str(p) in included and included[str(p)]['sha256']==sha(p)
    origin=json.loads((run/'class-origin-result.json').read_bytes()); assert origin['passed'] is True and origin['classConstructorAndPrototypeIdentity'] is True and origin['actualCopiedPrivateClassReachedByOriginalSelectExactlyOnce'] is True and origin['cachedSelectAddsNoComputeCall'] is True and origin['noGridNoNativeChecker'] is True
    origin_build=json.loads((ROOT/'private-selection-origin-controls-build-receipt.json').read_bytes()); assert origin_build['sameClassSourceBindingAcrossPublicAndControl'] is True and origin_build['artifactSha256']==sha(ROOT/'private-selection-origin-controls.cjs')
    after_deps=dependency_check();prepared();assert before_deps==after_deps
    receipt={'passed':True,'scope':'Fresh deterministic build with owned-leader drain; actual C final React layer metadata with inherited measured E Core/native17; build runs only deterministic compilation and original empty-domain class-origin/cached-select control; historical native controls explicitly reused; new runtime128 handoff prune has actual 701+9 distinct test-body qualification across two runs; original full-suite hook failure preserved and single-invocation full-suite pass false','results':results,'privateClassOrigin':origin,'privateClassOriginBuild':origin_build,'actualFinalReactProps':final_props,'inheritedActualReactExecution':packet['actualV12eCReactExecution'],'inheritedActualReactReceiptSha256':packet['actualV12eCReactReceiptSha256'],'inheritedPure11ReceiptSha256':packet['parentErrorCaptureReceiptSha256'],'dependenciesBefore':before_deps,'dependenciesAfter':after_deps,'preparedManifestSha256':prepared_sha,'parentFinalSha256':packet['parentFinalSha256'],'actualG350Routing':False,'accepted49':False}
    write_new(ROOT/'error-capture-qualification-receipt.json',receipt)
    rows=list(packet['files'])
    for name in ['runner.cjs','bundle-metafile.json','build-receipt.json','error-fields-controls.cjs','error-fields-controls-metafile.json','error-fields-controls-build-receipt.json','error-capture-qualification-receipt.json','private-selection-origin-controls.cjs','private-selection-origin-controls-metafile.json','private-selection-origin-controls-build-receipt.json','error-capture-qualification/class-origin-result.json']:
        path=ROOT/name;rows.append({'path':name,'sha256':sha(path),'bytes':path.stat().st_size,'mode':stat.S_IMODE(path.stat().st_mode)})
    candidate={**packet,'actualPrivateFanoutBundleQualified':True,'privateSelectionClassOriginQualified':True,'files':rows,'nodeArtifactQualified':True,'nodeArtifactSha256':sha(ROOT/'runner.cjs'),'preparedManifestSha256':prepared_sha,'qualificationReceiptSha256':sha(ROOT/'error-capture-qualification-receipt.json'),'scope':'Qualified bounded public-error capture; original Node5 physics/caller proof reused; root final/public authority pending'}
    write_new(ROOT/'QUALIFIED-candidate-manifest.json',candidate)
    print(json.dumps({'passed':True,'candidateManifestSha256':sha(ROOT/'QUALIFIED-candidate-manifest.json'),'qualificationReceiptSha256':candidate['qualificationReceiptSha256'],'actualG350Routing':False}))
    return 0


def prepared():
    path = ROOT / 'PREPARED-controller-manifest-v1.json'
    packet = json.loads(path.read_bytes())
    verify_length_prune_qualification(packet)
    assert packet['actualCoreInputQualified'] is True and packet['actualCoreNativePlacementChecks']==17 and packet['actualCoreNativePlacementErrorCount']==0
    assert packet['actualInputAndSourceParityQualified'] is True and packet['exactAll49SourceConnectionsQualified'] is True
    assert packet['tiWireClassSpacingAdopted'] is False and packet['signalLayersAllowed']==['top','inner1','inner2','bottom']
    verify_private_fanout_source(packet)
    verify_private_selection_qualification(packet)
    verify_files(ROOT, packet['files'])
    verify_files(None, packet['externalFiles'])
    verify_family_and_v12e(packet)
    assert packet['sourceManifestSha256'] == RUNTIME_SHA and packet['sourceClosureSha256'] == RUNTIME_CLOSURE
    assert packet['requestedOptions'] == OPTIONS and packet['policy'] == PUBLIC_POLICY
    assert packet['nodeArtifactQualified'] is False and packet['actualG350Routing'] is False
    assert packet['unbundledGlobalObserverQualified'] is False
    parent=json.loads(Path(packet['parentFinalPath']).read_bytes())
    assert sha(packet['parentFinalPath'])==packet['parentFinalSha256']=='1979685dcd1cb3e3d3bfbf96d4bcc3513bf7f4b95119a895b1f2d471774d316c'
    assert parent['nodeArtifactQualified'] is True and parent['sourceManifestSha256']=='383dab3993fbd2128ad67bf3220f1342ef6252edad5c118264c9232ee03541b5'
    receipt=json.loads(Path(packet['parentNode5ReceiptPath']).read_bytes())
    assert sha(packet['parentNode5ReceiptPath'])==packet['parentNode5ReceiptSha256']==parent['parentNode5ReceiptSha256']
    assert receipt['passed'] is True and len(receipt['results'])==5 and all(clean(row['execution']) for row in receipt['results'])
    fields=json.loads(Path(packet['parentErrorCaptureReceiptPath']).read_bytes())
    assert sha(packet['parentErrorCaptureReceiptPath'])==packet['parentErrorCaptureReceiptSha256']==parent['parentErrorCaptureReceiptSha256']=='9651257869158ce301134d35d257cc3cf658d29e16bd6cc5cf7d28dbbe11f7c7'
    assert fields['passed'] is True and fields['controls']['assertions']==11 and all(clean(row['execution']) for row in fields['results'])
    react_receipt=json.loads(Path(packet['actualV12eCReactReceiptPath']).read_bytes())
    assert sha(packet['actualV12eCReactReceiptPath'])==packet['actualV12eCReactReceiptSha256']
    assert clean(react_receipt['execution'])
    assert sha(ROOT/'actual-final-v12e-c-authored-props.json')==packet['actualV12eCReactCaptureSha256']
    bridge=module('inherited_v12d_final_props',Path(packet['v12eCBridgeModulePath']))
    assert bridge.verify_actual_authored_props(ROOT/'actual-final-v12e-c-authored-props.json')['actualFinalReactTreeEvaluated'] is True
    assert packet['observationMode'] == OBSERVATION_MODE and packet['finiteArtifactList'] is True
    assert os.environ.get('NODE_OPTIONS', '') == '', 'Reject nonempty NODE_OPTIONS; do not silently override it'
    assert os.environ.get('NODE_PATH', '') == packet['inheritedEnvironment']['NODE_PATH']
    for link in [ROOT / 'node_modules', ROOT / 'source' / 'node_modules']:
        assert link.is_symlink() and os.readlink(link) == '/workspace/bus-lanes-solver/node_modules'
        assert link.resolve() == Path('/workspace/bus-lanes-solver/node_modules')
    runtime = json.loads((ROOT / 'qualified-runtime-library-manifest.json').read_bytes())
    assert sha(ROOT / 'qualified-runtime-library-manifest.json') == RUNTIME_SHA
    verify_files(ROOT / 'source', runtime['sourceFiles'])
    expected = {row['path'] for row in runtime['sourceFiles'] if row['path'].startswith('lib/')}
    actual = {str(path.relative_to(ROOT / 'source')) for path in (ROOT / 'source' / 'lib').rglob('*') if path.is_file() or path.is_symlink()}
    assert actual == expected, 'Unlisted production resolver/source entry'
    assert sha(QUAL / 'qualified-source-manifest.json') == '4369714a5cdd69e6aed9261f279c73a08ac7e32123232efef86f9e97917eb9a8'
    full = json.loads((QUAL / 'qualified-source-manifest.json').read_bytes())
    verify_files(QUAL / 'source', [{**row, 'mode': full['filesystemModes'][row['path']]} for row in full['sourceFiles']])
    assert sha(QUAL / 'RELEASE.json') == packet['qualifiedReleaseSha256']
    assert json.loads((QUAL / 'RELEASE.json').read_bytes())['currentFullUnitQualified'] is True
    return packet, sha(path)


def verify_private_fanout_source(packet):
    copied=ROOT/'fanout-source'
    rows=packet['privateFanoutSourceFiles']
    assert len([r for r in rows if r['path'].startswith('lib/')])==95
    verify_files(copied,rows)
    actual={str(p.relative_to(copied)) for p in (copied/'lib').rglob('*') if p.is_file() or p.is_symlink()}
    assert actual=={r['path'] for r in rows if r['path'].startswith('lib/')}
    assert json.loads((copied/'package.json').read_bytes())['version']=='0.0.76'
    assert sha(copied/'lib/match-component-dogbone-via-sites.ts')==packet['privatePatchedMatcherSha256']=='52bc23fc38acacf1b85bd37245a2f69ead3356fa8fa59751743784a99364cac4'
    link=copied/'node_modules';target=Path('/workspace/bus-lanes-solver/node_modules/@tscircuit/fanout-solver/node_modules')
    assert link.is_symlink() and os.readlink(link)==str(target) and link.resolve()==target.resolve()
    graphics=target/'graphics-debug/package.json'
    assert graphics.is_file() and json.loads(graphics.read_bytes())['version']=='0.0.99' and sha(graphics)==packet['nestedGraphics99PackageSha256']

def verify_private_fanout_build(packet,build):
    verify_private_fanout_source(packet)
    override=build['fanoutOverride']
    assert override['copiedPackageVersion']=='0.0.76' and override['privateMatcherSha256']==packet['privatePatchedMatcherSha256']
    assert override['privateIndexSha256']==sha(ROOT/'fanout-source/lib/index.ts')
    assert override['privateMatcherInBundle'] is True and override['originalInstalledFanoutLibBundled'] is False and override['installedDependenciesEdited'] is False
    inputs=build['inputBindings'];included={r['realpath'] for r in inputs}
    assert str(ROOT/'fanout-source/lib/match-component-dogbone-via-sites.ts') in included and str(ROOT/'fanout-source/lib/index.ts') in included
    assert not any(r['realpath'].startswith('/workspace/bus-lanes-solver/node_modules/@tscircuit/fanout-solver/lib/') for r in inputs)
    for row in inputs:
        path=Path(row['realpath']);assert path.is_file() and sha(path)==row['sha256'] and stat.S_IMODE(path.stat().st_mode)==row['mode'] and path.stat().st_size==row['bytes']


def verify_private_selection_qualification(packet):
    path=Path(packet['privateSelectionQualificationReceiptPath']);q=json.loads(path.read_bytes())
    assert sha(path)==packet['privateSelectionQualificationReceiptSha256']=='65fd2a0602317901eb82be6ac60ea91822cde63581b1ce21e7f1ca5914a39fc6'
    assert q['passed'] is True and q['sourceHeld'] is True and len(q['executions'])==3 and all(clean(r['execution']) for r in q['executions']) and q['dependenciesBefore']==q['dependenciesAfter']
    assert q['observerSourceSha256']==sha(ROOT/'private-selection-primitives.ts') and q['actualBoardRoutingPerformed'] is False and q['futureProducerModuleOriginQualified'] is False
    assert packet['privateSelectionObserverQualificationPassed'] is True and packet['nativePlacementChecksInheritedNotRerun'] is True and packet['actualCoreGeometryReusedNotFreshlyRendered'] is True


def verify_length_prune_qualification(packet):
    receipt_path=Path(packet['lengthPruneFullSuiteReceiptPath']);q=json.loads(receipt_path.read_bytes())
    assert sha(receipt_path)==packet['lengthPruneFullSuiteReceiptSha256']=='fd9110cbbac44c5fc4b7fc5833946d118c78b93e99e4e62d0296a597c752ba6c'
    assert q['fullSuitePassed'] is False and q['wholeSuiteExecuted'] is True and q['sourceAndArtifactsHeld'] is True
    execution=q['execution']; assert execution['exitCode']==1 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values())
    assert q['dependenciesBefore']==q['dependenciesAfter'] and q['actualCounters']=={'pass':701,'fail':1,'tests':702,'files':202}
    isolated_path=Path(packet['lengthPruneIsolated9ReceiptPath']);isolated=json.loads(isolated_path.read_bytes())
    assert sha(isolated_path)==packet['lengthPruneIsolated9ReceiptSha256']=='809dece5c9b47c329812dcaa5ec0d746213851f4dbf072605eb70c5a75becb7d'
    assert isolated['isolatedFilePassed'] is True and isolated['isolatedFileExecuted'] is True and isolated['sourceAndArtifactsHeld'] is True and clean(isolated['execution'])
    assert isolated['actualCounters']=={'pass':9,'fail':0,'tests':9,'files':1} and isolated['dependenciesBefore']==isolated['dependenciesAfter']==q['dependenciesAfter']
    assert isolated['originalFullFailurePreserved'] is True and isolated['fullSuiteSingleInvocationPassed'] is False
    assert isolated['combinedDistinctTestCountIfIsolatedPassed']==710 and packet['all710DistinctTestBodiesPassedAcrossTwoRuns'] is True
    assert packet['fullSuiteSingleInvocationPassed'] is False and packet['originalFullFailurePreserved'] is True and packet['newLengthPruneFullSuiteQualified'] is False
    source_path=Path(packet['newFullSourceManifestPath']);runtime_path=Path(packet['newRuntime128ManifestPath'])
    assert sha(source_path)==packet['newFullSourceManifestSha256']=='db0a04811022bc58f3ff6009c35ab661412f6925602e34b7673c8ff8cc26f9bc'
    assert sha(runtime_path)==packet['newRuntime128ManifestSha256']==RUNTIME_SHA
    full=json.loads(source_path.read_bytes());runtime=json.loads(runtime_path.read_bytes())
    assert full['sourceFileCount']==933 and runtime['sourceFileCount']==128
    verify_files(Path(full['sourceDirectory']),full['sourceFiles'])
    indexed={r['path']:r for r in full['sourceFiles']}
    assert len(indexed)==933 and all(indexed[r['path']]==r for r in runtime['sourceFiles'])
    assert packet['old706ExplicitlyHistoricalNotCurrentQualification'] is True and packet['allElevenBenchmarksExecuted'] is False and packet['allElevenBenchmarksQualified'] is False
    assert sha(ROOT/'source/lib/coupled-pair-routing.ts')=='13464cb3a6fd0caa879b22f1f146f842f69ec4cbd95f4d49ee379c26ff666bc1'
    assert sha(ROOT/'source/lib/coupled-handoff-length-bound.ts')=='131b199be1ca2f08cc47da8dc77ffe401420d524687a6f10e759d489d5c96991'
    for stem,session,exit_code in [('lengthPruneFullSuite',89346,2),('lengthPruneIsolated9',8618,0)]:
        closed_path=Path(packet[stem+'RootCollectedReceiptPath']);assert sha(closed_path)==packet[stem+'RootCollectedReceiptSha256']
        closed=json.loads(closed_path.read_bytes());assert closed['sessionId']==session and closed['toolExitCode']==exit_code
        assert closed['postauditSha256']==packet[stem+'ReceiptSha256']
    assert closed['all710DistinctTestBodiesPassedAcrossTwoRuns'] is True and closed['fullSuiteSingleInvocationPassed'] is False


def dependency_check():
    verifier = module('stage_trusted_dependencies', BASE / 'verify-installed-dependencies.py')
    result = verifier.verify(BASE / 'dependencies/archive-receipt.json', '1a49a60909258b542c7f4899e6378fa9f10c1cea08ef1aaf4b5366480dbf71b7', BASE / 'audit-installed-dependencies.py')
    assert result['treeSha256'] == '47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
    return result


def root_authority(path, expected_sha, prepared_sha, scope, policy=None):
    raw = Path(path).read_bytes()
    assert expected_sha and hashlib.sha256(raw).hexdigest() == expected_sha
    value = json.loads(raw)
    assert value['authorizedByRoot'] is True and value['scope'] == scope
    assert value['preparedManifestSha256'] == prepared_sha
    assert re.fullmatch('[0-9a-f]{32,128}', value['approvalToken'])
    if policy is not None:
        assert value['policy'] == policy
    assert value['previousPublicCollected'] is True and value['previousRootOwnedDiagnosticStop'] is True
    closed_path = Path(value['previousPublicCollectedReceiptPath'])
    assert closed_path.resolve() == PREVIOUS_PUBLIC_CLOSED_PATH
    assert value['previousPublicCollectedReceiptSha256'] == PREVIOUS_PUBLIC_CLOSED_SHA
    closed_raw = closed_path.read_bytes()
    assert hashlib.sha256(closed_raw).hexdigest() == PREVIOUS_PUBLIC_CLOSED_SHA
    closed = json.loads(closed_raw)
    assert closed['sessionId'] == 8501 and closed['toolExitCode']==2 and closed['rootEarlyDiagnosticStop'] is True and closed['naturalOutputPresent'] is False
    assert closed['postauditSha256']=='02aa09a95e3baa8da878696fdb85d93042c58dc82d3ffb1054f9538d7fccd15f'
    previous_post=Path('/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-cohort-actual-props-patched-fanout-public-v2-next/EXECUTION-postaudit.json')
    assert sha(previous_post)==closed['postauditSha256']
    closed_post=json.loads(previous_post.read_bytes())
    assert closed_post['sourceAndArtifactHeld'] is True and closed_post['dependenciesBefore']==closed_post['dependenciesAfter']
    execution = closed['execution']
    assert execution['cleanupOwnedGroupEmpty'] is True and execution['exitCode'] == -15 and execution['diagnosticStopped'] is False and execution['stopReasons']==[] and not any(execution['oomDelta'].values())
    assert value['previousPublicOwnedPgid'] == execution['pgid'] == PREVIOUS_PUBLIC_OWNED_PGID
    assert PREVIOUS_PUBLIC_OWNED_PGID > 0 and PREVIOUS_PUBLIC_OWNED_PGID != os.getpid()
    owned_scope = module('global_selection_closed_public_scope', BASE / 'process_scope.py')
    assert not owned_scope.owned(PREVIOUS_PUBLIC_OWNED_PGID)
    return value


def controlled_run(scope, name, command, policy, reserve, environment=None):
    baseline = scope.memory()

    def gate(current):
        assert current['current'] + policy['rssBytes'] + reserve < policy['sharedBytes'], 'Strict prefork reserve required'
        assert all(current['events'][key] == baseline['events'][key] for key in scope.OOM_KEYS)

    return scope.run_guarded(command, ROOT, ROOT / name, policy, environment or {}, before_spawn=gate)


def clean(execution):
    return execution['exitCode'] == 0 and not execution['diagnosticStopped'] and execution.get('cleanupOwnedGroupEmpty') and not any(execution.get('oomDelta', {}).values())








def reuse_light(packet):
    value = json.loads(Path(packet['lightReceiptPath']).read_bytes())
    preservation = json.loads(Path(packet['lightSourcePreservationPath']).read_bytes())
    assert value['passed'] is True and value['nativeRouterCadInvoked'] is False and clean(value['execution'])
    assert value['scriptSha256'] == sha(ROOT / 'light-checks.sh') and value['lightCommandSha256'] == sha(ROOT / 'LIGHT_COMMAND.json')
    assert preservation['allSourceRowsHeldAfterLightCheck'] is True and preservation['nativeCalls'] is False
    assert preservation['preparedManifestSha256'] == packet['freshLightSourceManifestSha256']
    rows = [json.loads(line) for line in Path(packet['lightLogPath']).read_text().splitlines() if line.startswith('{')]
    assert len(rows) == 1 and rows[0]['passed'] is True and rows[0]['assertions'] == 7844
    assert rows[0]['syntheticOnly'] is True and rows[0]['actualNativeRoutingExecuted'] is False
    return {'scope': 'Reused exact fresh root-run unbundled Bun synthetic7844 plus staticTypeScript only; no historical observer pass relabeled or native parity conferred', 'execution': value['execution'], 'sourcePreservation': preservation, 'syntheticReport': rows[0], 'receiptPath': packet['lightReceiptPath'], 'receiptSha256': packet['lightReceiptSha256']}




def freeze(packet, prepared_sha, peer_path, peer_sha):
    assert peer_path and peer_sha and sha(peer_path) == peer_sha
    assert not (ROOT / 'FINAL-manifest.json').exists()
    candidate = json.loads((ROOT / 'QUALIFIED-candidate-manifest.json').read_bytes())
    assert candidate['actualPrivateFanoutBundleQualified'] is True
    verify_private_fanout_build(packet,json.loads((ROOT/'build-receipt.json').read_bytes()))
    verify_files(ROOT, candidate['files'])
    assert candidate['preparedManifestSha256'] == prepared_sha and candidate['nodeArtifactSha256'] == sha(ROOT / 'runner.cjs')
    receipt = json.loads((ROOT / 'error-capture-qualification-receipt.json').read_bytes())
    assert receipt['passed'] is True and sha(ROOT / 'error-capture-qualification-receipt.json') == candidate['qualificationReceiptSha256']
    peer = json.loads(Path(peer_path).read_bytes())
    assert peer['candidateManifestSha256'] == sha(ROOT / 'QUALIFIED-candidate-manifest.json') and peer['qualificationReceiptSha256'] == candidate['qualificationReceiptSha256'] and peer['approvedForRootLaunch'] is True
    final = {**candidate, 'peerReviewPath': str(Path(peer_path).resolve()), 'peerReviewSha256': peer_sha, 'candidateManifestSha256': sha(ROOT / 'QUALIFIED-candidate-manifest.json')}
    write_new(ROOT / 'FINAL-manifest.json', final)
    print(json.dumps({'nodeArtifactQualified': True, 'finalManifestSha256': sha(ROOT / 'FINAL-manifest.json'), 'actualG350Routing': False}))
    return 0


def launch(packet, prepared_sha, authority_path, authority_sha):
    assert (ROOT / 'FINAL-manifest.json').is_file(), 'Actual build/native/peer qualification required'
    final = json.loads((ROOT / 'FINAL-manifest.json').read_bytes())
    verify_files(ROOT, final['files'])
    assert final['finiteArtifactList'] is True and final['nodeArtifactQualified'] is True
    assert final['policy'] == PUBLIC_POLICY and final['requestedOptions'] == OPTIONS and final['observationMode'] == OBSERVATION_MODE
    assert final['sourceManifestSha256'] == RUNTIME_SHA and final['sourceClosureSha256'] == RUNTIME_CLOSURE
    assert sha(final['peerReviewPath']) == final['peerReviewSha256'] and sha(ROOT / 'QUALIFIED-candidate-manifest.json') == final['candidateManifestSha256']
    assert final['inheritedEnvironment'] == packet['inheritedEnvironment']
    assert final['nodeArtifactSha256'] == sha(ROOT / 'runner.cjs')
    build_qualification=json.loads((ROOT/'error-capture-qualification-receipt.json').read_bytes())
    assert build_qualification['passed'] is True and len(build_qualification['results'])==2 and all(clean(row['execution']) for row in build_qualification['results'])
    bridge=module('v11_final_props_launch_binding',Path(packet['v12eCBridgeModulePath']))
    assert bridge.verify_actual_authored_props(ROOT/'actual-final-v12e-c-authored-props.json')==build_qualification['actualFinalReactProps']
    authority = root_authority(authority_path, authority_sha, prepared_sha, ROOT_SCOPE, PUBLIC_POLICY)
    final_sha = sha(ROOT / 'FINAL-manifest.json')
    assert final['actualPrivateFanoutBundleQualified'] is True and final['privateSelectionClassOriginQualified'] is True
    verify_private_fanout_build(packet,json.loads((ROOT/'build-receipt.json').read_bytes()))
    assert authority['packetSha256'] == final_sha
    assert not (ROOT / 'run').exists(), 'Fresh actual run directory required'
    before_deps = dependency_check()
    scope = module('stage_public_owned_scope', BASE / 'process_scope.py')
    execution = controlled_run(scope, 'run', [NODE, str(ROOT / 'runner.cjs'), '--run-one-approved'], PUBLIC_POLICY, 1024**3, {'G350_NODE_UNINSTRUMENTED_APPROVED': '1', 'G350_NODE_RECEIPT_PATH': str(Path(authority_path).resolve()), 'G350_NODE_RECEIPT_SHA256': authority_sha})
    verify_files(ROOT, final['files'])
    prepared()
    after_deps = dependency_check()
    result_path = ROOT / 'run' / 'result.json'
    result = json.loads(result_path.read_bytes()) if result_path.is_file() else None
    post_memory = scope.memory()
    post_oom_delta = {key: post_memory['events'][key] - execution['memoryBefore']['events'][key] for key in scope.OOM_KEYS}
    identity = result is not None and result.get('engine') == 'v25.6.1' and result.get('execArgv') == [] and result.get('inheritedNodeOptions') == '' and result.get('inheritedNodePath') == packet['inheritedEnvironment']['NODE_PATH'] and result.get('packetSha256') == final_sha and result.get('sourceCommit') is None and result.get('sourceFileCount') == 128 and result.get('sourceManifestSha256') == RUNTIME_SHA and result.get('sourceClosureSha256') == RUNTIME_CLOSURE and result.get('nodeArtifactSha256') == final['nodeArtifactSha256'] and result.get('inputSha256') == packet['inputBindings']['input.json']['sha256'] and result.get('originalInputSha256') == packet['inputBindings']['original-unrestricted-input.json']['sha256'] and result.get('requestedOptions') == OPTIONS and result.get('actualOptions') == OPTIONS
    physical = result is not None and result.get('publicPipelineExecuted') is True and result.get('originalDefaultCap') == 800_000 and result.get('capUnchanged') is True and result.get('requestedOptionsHeld') is True and result.get('inputUnchanged') is True and result.get('fullHardwareHeld') is True and result.get('fixedReferencesHeld') is True and result.get('suppliedPhysicalReferences') == 2
    terminal = result.get('terminal') if result is not None else None
    terminal_held = isinstance(terminal, dict) and terminal.get('defaultCap') == 800_000 and terminal.get('termination') in ['NATURAL_SOLVED', 'NATURAL_FAILED', 'ORIGINAL_CAP_REACHED_UNRESOLVED'] and isinstance(terminal.get('publicSteps'), int) and 0 <= terminal['publicSteps'] <= 800_000
    output_held = result is not None and result.get('naturalOutputGateHeld') is True
    output_path = ROOT / 'run' / 'natural-public-output.json'
    if terminal_held and terminal['termination'] == 'NATURAL_SOLVED':
        item = result.get('publicOutput')
        output_held = output_held and isinstance(item, dict) and item.get('path') == 'natural-public-output.json' and output_path.is_file() and output_path.stat().st_size == item.get('bytes') and sha(output_path) == item.get('sha256') and result.get('actualSolverState', {}).get('solved') is True and result.get('actualSolverState', {}).get('failed') is False and result.get('actualSolverState', {}).get('actualTraceCount') == 49
        if output_held:
            actual = json.loads(output_path.read_bytes())
            original = json.loads((ROOT / 'input.json').read_bytes())
            expected_names = {connection['name'] for connection in original['connections']}
            names = [trace.get('connection_name', trace.get('source_trace_id')) for trace in actual.get('traces', [])[2:]]
            output_held = len(actual.get('traces', [])) == 51 and actual['traces'][:2] == original['traces'] and len(names) == 49 and len(set(names)) == 49 and set(names) == expected_names and {key: value for key, value in actual.items() if key != 'traces'} == {key: value for key, value in original.items() if key != 'traces'}
    elif terminal_held:
        output_held = output_held and result.get('publicOutput') is None and not output_path.exists()
    observations = result is not None and result.get('observationMode') == OBSERVATION_MODE and result.get('factoryOrSiteTelemetryInstalled') is False and result.get('moduleReplacementInstalled') is False and result.get('gridOriginalMethodPrimitiveTelemetryInstalled') is True and result.get('gridConstructorReplacementInstalled') is False and result.get('writeErrors') == 0 and 0 <= result.get('progressRows', -1) <= 64 and 0 <= result.get('progressBytes', -1) <= 24*1024 and result.get('accepted49') is False and result.get('tiEligibleBoard') is False and result.get('fabricationReady') is False
    bank = result.get('positiveBankStats') if result is not None else None
    bank_held = isinstance(bank, dict) and bank.get('observationErrors') == 0 and bank.get('expectedOrdinaryCount') == 43 and bank.get('retainedInstances') is False and bank.get('retainedBankGeometry') is False and bank.get('weakRefUsed') is False and result.get('statsBindingsRestored') is True and 0 <= result.get('statsWrites', -1) <= 1602 and 0 <= result.get('statsBytes', -1) <= 128*1024
    stage = result.get('stagePrimitives') if result is not None else None
    stage_held = isinstance(stage, dict) and stage.get('observationErrors') == 0 and stage.get('snapshotOverflows') == 0 and stage.get('retainedInstances') is False and stage.get('retainedGeometryObjects') is False and stage.get('retainedBankValues') is False and stage.get('weakRefUsed') is False and stage.get('additionalGridCalls') == 0 and stage.get('constructorReplacementInstalled') is False and result.get('stageBindingsRestored') is True
    telemetry = result.get('stageTelemetry') if result is not None else None
    telemetry_held = isinstance(telemetry, dict) and telemetry.get('failedPublications') == 0 and telemetry.get('rejectedRows') == 0 and 0 <= telemetry.get('retainedRows', -1) <= 16 and 0 <= telemetry.get('serializedBytes', -1) <= 128*1024 and 0 <= telemetry.get('successfulPublications', -1) <= 1603
    rolling_path = ROOT / 'run' / 'latest-stage-primitives.jsonl'
    rolling = None
    if rolling_path.is_file():
        assert rolling_path.stat().st_size <= 128*1024
        rolling = [json.loads(line) for line in rolling_path.read_text().splitlines()]
        assert 0 < len(rolling) <= 16
        for row in rolling:
            assert row['packetSha256'] == final_sha and row['sourceManifestSha256'] == RUNTIME_SHA and row['inputSha256'] == packet['inputBindings']['input.json']['sha256']
            assert row['diagnosticOnly'] is True and row['accepted49'] is False
            assert row['publicationKind'] in ['periodic-public-hook', 'last-observed-public-hook']
            public = row['publicStepBinding']
            assert isinstance(public['publicSteps'], int) and 0 <= public['publicSteps'] <= 800_000 and public['defaultCap'] == 800_000
            assert public['elapsedMs'] <= row['publishedElapsedMs']
    global_selection = result.get('globalSelectionStats') if result is not None else None
    global_held = isinstance(global_selection, dict) and global_selection.get('totals', {}).get('observationErrors') == 0 and global_selection.get('totals', {}).get('snapshotOverflows') == 0 and global_selection.get('retainedDomains') is False and global_selection.get('retainedCandidates') is False and global_selection.get('retainedGeometry') is False and global_selection.get('weakRefsUsed') is False and global_selection.get('callbackArgumentsReplaced') is False and global_selection.get('additionalSolverCalls') == 0 and result.get('selectionBindingsRestored') is True
    failure_fields=result.get('actualSolverState') if result is not None else None
    error_capture_held=isinstance(failure_fields,dict) and all(failure_fields.get(key) is None or (isinstance(failure_fields.get(key),str) and len(failure_fields[key])<=1024) for key in ['error','failureCode']) and all(failure_fields.get(key) in ['string','null','absent','accessor','unsupported'] for key in ['errorFieldKind','failureCodeFieldKind']) and all(type(failure_fields.get(key)) is bool for key in ['errorTruncated','failureCodeTruncated'])
    private_stats=result.get('privateSelectionStats') if result is not None else None
    private_held=isinstance(private_stats,dict) and private_stats.get('observationErrors')==0 and private_stats.get('overflows')==0 and private_stats.get('retainedGeometry') is False and private_stats.get('additionalOriginalCalls')==0 and result.get('privateSelectionRestored') is True and 0<=private_stats.get('retainedRows',-1)<=16
    private_path=ROOT/'run/latest-private-selection-primitives.jsonl'
    if private_path.exists():
        assert private_path.stat().st_size<=2048
        private_rows=[json.loads(line) for line in private_path.read_text().splitlines()];assert 0<len(private_rows)<=16
        for row in private_rows:assert list(row)==['n','p','t'] and type(row['n']) is int and row['n']>0 and row['p'] in [0,1,2] and type(row['t']) in [int,float] and math.isfinite(row['t']) and row['t']>=0
    valid = private_held and error_capture_held and global_held and clean(execution) and not any(post_oom_delta.values()) and before_deps == after_deps and result is not None and result.get('diagnosticQualified') is True and result.get('originalException') is None and identity and physical and terminal_held and output_held and observations and bank_held and stage_held and telemetry_held and rolling is not None
    receipt = {'execution': execution, 'dependenciesBefore': before_deps, 'dependenciesAfter': after_deps, 'sourceAndArtifactHeld': True, 'result': result, 'lastStagePrimitivePublicRows': rolling, 'postflightOomDelta': post_oom_delta, 'trustConjuncts': {'identityHeld': identity, 'physicalInputAndCapHeld': physical, 'originalTerminalHeld': terminal_held, 'naturalOutputGateHeld': output_held, 'boundedOriginalMethodObservationsHeld': observations, 'boundedBankObservationsHeld': bank_held, 'boundedStagePrimitiveObservationsHeld': stage_held, 'boundedStepBoundTelemetryHeld': telemetry_held, 'boundedGlobalSelectionObserved': global_held, 'boundedOwnDataPublicFailureFieldsHeld':error_capture_held}, 'diagnosticTrustEligible': valid, 'actualG350Routing': True, 'accepted49': False, 'fabricationReady': False}
    write_new(ROOT / 'EXECUTION-postaudit.json', receipt)
    print(json.dumps({'diagnosticTrustEligible': valid, 'accepted49': False}))
    return 0 if valid else 2


def main():
    parser = argparse.ArgumentParser()
    select = parser.add_mutually_exclusive_group(required=True)
    select.add_argument('--preflight', action='store_true')
    select.add_argument('--qualify-build-only', action='store_true')
    select.add_argument('--freeze-qualified', action='store_true')
    select.add_argument('--launch', action='store_true')
    parser.add_argument('--root-receipt', type=Path)
    parser.add_argument('--root-receipt-sha256')
    parser.add_argument('--peer-review', type=Path)
    parser.add_argument('--peer-review-sha256')
    args = parser.parse_args()
    packet, prepared_sha = prepared()
    if args.preflight:
        dependency_check()
        scope = module('global_selection_preflight_memory', BASE / 'process_scope.py')
        assert scope.memory()['current'] + PUBLIC_POLICY['rssBytes'] + 1024**3 < PUBLIC_POLICY['sharedBytes']
        print(json.dumps({'preparedManifestSha256': prepared_sha, 'phase': 'PREPARED_SOURCE_ONLY', 'nodeArtifactPresent': (ROOT / 'runner.cjs').exists(), 'finalArtifactVerified': False, 'actualG350Routing': False}))
        return 0
    if args.qualify_build_only:
        assert args.root_receipt and args.root_receipt_sha256
        return qualify_build_only(packet,prepared_sha,args.root_receipt,args.root_receipt_sha256)
    if args.freeze_qualified:
        dependency_check()
        return freeze(packet, prepared_sha, args.peer_review, args.peer_review_sha256)
    assert args.root_receipt and args.root_receipt_sha256
    return launch(packet, prepared_sha, args.root_receipt, args.root_receipt_sha256)


if __name__ == '__main__':
    raise SystemExit(main())
