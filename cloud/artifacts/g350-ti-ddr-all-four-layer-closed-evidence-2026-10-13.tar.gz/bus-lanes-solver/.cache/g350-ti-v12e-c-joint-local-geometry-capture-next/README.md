Source-only packet for the missing joint local geometry. After Root collects
and closes public session 78137, run exactly one original patched local fanout
call at attempt zero on the actual authored C-cohort input 786455. Preserve the
raw returned 49 handoff connections, 96 local traces and 96 full-depth via
points, with byte and geometry hashes. Reuse the old 196 individual/four whole
local calls explicitly; do not repeat them or merge their individual records.

Original bounds: 60 seconds, 1 GiB owned RSS, 24 GiB shared, 2 GiB prefork
reserve, original owned-process cleanup and installed dependency checks.
Core geometry and native17 are reused; the measured C layer metadata bridge is
already qualified. No Grid, public routing, native checker, export, snapshot,
manufacturing acceptance or complete CPU-to-RAM interconnect claim.

Root authority must include previousPublicCollectedReceiptPath, its SHA256,
and previousPublicPostauditSha256 for collected session 78137. This packet is
prepared only: no import, preflight, worker or API call has run.
