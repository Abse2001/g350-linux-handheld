#!/usr/bin/env python3
"""SOURCE ONLY: Root runs this read-only KiCad 10 verification after fresh export.

This does not save/refill the board, repair a net, suppress a DRC finding, or
qualify timing, SI, manufacturing, or the rest of the board.
"""
import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import re
import time

RAW_SHA = '33584d197a1bb45a0dc76ac0a69e7016866a2369f1750c72d5eedc41ef444594'
CLI_SHA = '2135bc7f5e27b72ddfaa9b65586c905897e4222f989328ebc0434b1d1961c19c'
TOL = 1e-5
LAYERS = ('top', 'inner1', 'inner2', 'bottom')

def need(ok, message):
    if not ok: raise ValueError(message)

def digest(data): return hashlib.sha256(data).hexdigest()

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ('board', 'expected', 'bridge', 'drc'):
        ap.add_argument('--' + name, type=Path, required=True)
        ap.add_argument('--' + name + '-sha', required=True)
    ap.add_argument('--drc-exit-code', type=int, required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--budget-ms', type=int, default=165000)
    args = ap.parse_args()
    need(1000 <= args.budget_ms <= 165000 and not args.output.exists(), 'Fresh report and bounded budget')
    paths = {n: getattr(args, n).resolve() for n in ('board', 'expected', 'bridge', 'drc')}
    need(len({p.parent for p in paths.values()}) == 1 and args.output.parent.resolve() == paths['board'].parent,
         'All export artifacts/report belong to the same fresh owned output directory')
    need(paths['board'].parent.name.startswith('g350-source272-kicad49-') and paths['board'].parent.parent.name == 'dist',
         'Use the reviewed fresh Source272 dist directory')
    blobs = {}
    for n, p in paths.items():
        h = getattr(args, n + '_sha')
        need(re.fullmatch('[0-9a-f]{64}', h) is not None and p.is_file() and not p.is_symlink(), 'Explicit regular-file SHA ' + n)
        blobs[n] = p.read_bytes(); need(digest(blobs[n]) == h, 'Exact input ' + n)
    expected, bridge, drc = [json.loads(blobs[n]) for n in ('expected', 'bridge', 'drc')]
    need(expected['scope'] == 'SOURCE272_KICAD49_EXPECTED_GEOMETRY_AND_AUTHENTIC_OWNERSHIP_NOT_CAD_QUALIFICATION'
         and expected['inputBindings']['raw']['sha256'] == RAW_SHA and expected['stockCli']['sha256'] == CLI_SHA,
         'Reviewed Source272 catalog and stock CLI binding')
    need(bridge['scope'] == 'SOURCE272_EXPLICIT_SERIALIZER_VIA_NET_KEY_BRIDGE_NO_GEOMETRY_CHANGE'
         and bridge['expectedCatalog']['sha256'] == args.expected_sha and bridge['addedViaKeyCount'] == 103
         and bridge['exactInversePassed'] is True and bridge['geometryLayersDimensionsOrNumericIdsChanged'] is False,
         'Explicit metadata-only serializer representation, not an original raw export')
    original = Path(bridge['originalRawByteIdenticalCopy']['path']).resolve()
    representation = Path(bridge['exportRepresentation']['path']).resolve()
    need(original.parent == representation.parent == paths['board'].parent, 'Owned export inputs')
    original_bytes, represented_bytes = original.read_bytes(), representation.read_bytes()
    need(digest(original_bytes) == RAW_SHA and digest(represented_bytes) == bridge['exportRepresentation']['sha256'], 'Actual immutable copies')
    raw, represented = json.loads(original_bytes), json.loads(represented_bytes)
    inverse = copy.deepcopy(represented)
    changed_ids = set()
    for c in bridge['changes']:
        i = c['rawIndex']; need(raw[i] == c['before'] and represented[i] == c['after'], 'Exact via metadata inverse row')
        a, b = c['before'], c['after']
        need(a['type'] == b['type'] == 'pcb_via' and a['pcb_via_id'] == c['actualPcbViaId'] not in changed_ids,
             'Unique actual via metadata edit')
        changed_ids.add(c['actualPcbViaId'])
        test = copy.deepcopy(b); need('subcircuit_connectivity_map_key' not in a, 'No overwritten via key')
        need(test.pop('subcircuit_connectivity_map_key') == c['addedKey'] and test == a, 'Only the missing via key was added')
        inverse[i] = a
    need(len(changed_ids) == 103 and inverse == raw, 'Full original array inverse including field presence')
    need(isinstance(drc.get('violations'), list) and isinstance(drc.get('unconnected_items'), list)
         and Path(str(drc.get('source', ''))).name == paths['board'].name and str(drc.get('kicad_version', '')).startswith('10.0.6'),
         'Full current KiCad10 DRC JSON, never a filtered or inherited report')
    report = {'scope': 'SOURCE272_FRESH_KICAD10_READ_ONLY_GEOMETRY_AND_49_OWNED_NUMERIC_CONNECTIVITY',
        'inputBindings': {n: {'path': str(p), 'sha256': getattr(args, n + '_sha')} for n, p in paths.items()},
        'originalRawSha256': RAW_SHA, 'stockCliSha256': CLI_SHA, 'serializerBridgeExplicit': True,
        'fullUnfilteredDrc': drc, 'drcExitCode': args.drc_exit_code,
        'checks': [], 'signalResults': [], 'failures': [], 'complete': False,
        'boardSavedOrRefilled': False, 'originalRawEdited': False, 'stockCliEdited': False,
        'sourceTimingObservations': expected['originalTimingObservations'], 'originalSourceRuleBridge': expected['originalSourceRuleBridge'],
        'all49Accepted': False, 'fullBoardPassed': False, 'electricalTimingQualified': False,
        'tiQualified': False, 'referenceContinuityQualified': False, 'returnPathSiQualified': False,
        'planeGeometryTransferQualified': False, 'maskTentingTransferVerified': False,
        'cadManufacturingQualified': False, 'fabricationReady': False}
    started = time.monotonic()
    fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    os.close(fd)
    def save():
        # Only this freshly created owned report is replaced during this run.
        tmp = args.output.with_name(args.output.name + '.owned-tmp')
        with tmp.open('x') as f:
            json.dump(report, f, indent=2, allow_nan=False); f.write('\n'); os.fchmod(f.fileno(), 0o600)
        os.replace(tmp, args.output)
    def budget(): need((time.monotonic() - started) * 1000 < args.budget_ms, 'Read-only checker budget exhausted')
    def checked(name, details): report['checks'].append({'name': name, 'passed': True, 'details': details}); save()
    save()
    try:
        import wx
        wx.Log.SetLogLevel(wx.LOG_Error)
        application = wx.App(False)
        import pcbnew
        version = pcbnew.GetBuildVersion() if hasattr(pcbnew, 'GetBuildVersion') else pcbnew.Version()
        need(str(version).startswith('10.0.6'), 'Use the pinned KiCad 10.0.6 environment')
        board = pcbnew.LoadBoard(str(paths['board']))
        layer_ids = dict(zip(LAYERS, (pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu, pcbnew.B_Cu)))
        need(board.GetCopperLayerCount() == 4 and all(board.IsLayerEnabled(v) for v in layer_ids.values()), 'Exact four enabled copper layers')
        checked('pinnedKiCadAndFourLayers', {'version': str(version), 'layers': {k: board.GetLayerName(v) for k, v in layer_ids.items()}})
        mm = pcbnew.ToMM
        def point(v): return (mm(v.x), mm(v.y))
        def source_point(q): return (100 + q['x'], 100 - q['y'])
        def close(a, b): return math.dist(a, b) <= TOL
        def uid(item): return item.m_Uuid.AsString()
        def angle_distance(a, b): return abs((a - b + 180) % 360 - 180)
        footprints = list(board.GetFootprints())
        need(len(footprints) == expected['expectedCounts']['representedPcbComponents'] == 514, 'All 514 physical representations, 280 genuine parts')
        part_fps, matched_fp_ids = {}, set()
        for row in expected['parts']:
            budget(); source, c = row['source'], row['pcb']
            matches = [f for f in footprints if f.GetReference() == source['name'] and close(point(f.GetPosition()), source_point(c['center']))]
            need(len(matches) == 1, 'Unique real part ' + source['name'])
            f = matches[0]
            need(uid(f) not in matched_fp_ids and angle_distance(f.GetOrientationDegrees(), c.get('rotation', 0)) <= TOL
                 and f.GetLayer() == layer_ids[c['layer']], 'Part position/layer/rotation ' + source['name'])
            matched_fp_ids.add(uid(f)); part_fps[source['name']] = f
        extras = [f for f in footprints if uid(f) not in matched_fp_ids]
        need(len(extras) == 234 and all(len(list(f.Pads())) == 0 for f in extras), 'Only the 234 known empty via-component footprint representations remain')
        checked('all280RealParts', {'realParts': len(part_fps), 'emptyViaRepresentations': len(extras)})
        land_pads, used_pad_ids = {}, set()
        shape_names = {'circle': pcbnew.PAD_SHAPE_CIRCLE, 'rect': pcbnew.PAD_SHAPE_RECT, 'polygon': pcbnew.PAD_SHAPE_CUSTOM}
        for e in expected['lands']:
            budget(); q = e['raw']; candidates = list(part_fps[e['reference']].Pads())
            if q.get('shape') == 'polygon':
                want = source_point({'x': sum(p['x'] for p in q['points']) / len(q['points']), 'y': sum(p['y'] for p in q['points']) / len(q['points'])})
            else: want = source_point(q)
            candidates = [p for p in candidates if p.GetNumber() == e['pin'] and close(point(p.GetPosition()), want) and uid(p) not in used_pad_ids]
            need(len(candidates) == 1, 'Bijective actual land ' + e['reference'] + '.' + e['pin'])
            p = candidates[0]; used_pad_ids.add(uid(p)); land_pads[e['pcbPort']['pcb_port_id']] = p
            is_pth = q['type'] == 'pcb_plated_hole'
            want_layers = set(LAYERS if is_pth else [q['layer']])
            need({k for k, v in layer_ids.items() if p.GetLayerSet().Contains(v)} == want_layers, 'Actual land copper layer set')
            if is_pth:
                need(q['shape'] == 'pill' and p.GetShape() == pcbnew.PAD_SHAPE_OVAL
                     and close(point(p.GetSize()), (q['outer_width'], q['outer_height']))
                     and close(point(p.GetDrillSize()), (q['hole_width'], q['hole_height'])), 'All four genuine pill PTH lands and drills')
                # These actual four holes are at 180 degrees; compare their physical extents too.
                need(abs(mm(p.GetBoundingBox().GetWidth()) - q['outer_width']) <= TOL
                     and abs(mm(p.GetBoundingBox().GetHeight()) - q['outer_height']) <= TOL, 'PTH physical orientation')
            elif q['shape'] == 'polygon':
                need(p.GetShape() == pcbnew.PAD_SHAPE_CUSTOM, 'Actual custom SMT polygon')
                poly = p.GetEffectivePolygon(layer_ids[q['layer']])
                need(poly.OutlineCount() == 1 and poly.HoleCount(0) == 0, 'Exact single filled custom pad outline')
                outline = poly.Outline(0); actual = [point(outline.CPoint(i)) for i in range(outline.PointCount())]
                wanted = []
                for v in q['points']:
                    v = source_point(v)
                    if not wanted or math.dist(v, wanted[-1]) > 1e-9: wanted.append(v)
                if math.dist(wanted[0], wanted[-1]) < 1e-9: wanted.pop()
                need(len(actual) == len(wanted) and all(min(math.dist(a, w) for w in wanted) <= TOL for a in actual)
                     and all(min(math.dist(a, w) for a in actual) <= TOL for w in wanted), 'Full physical polygon vertices, never only a bounding box')
            else:
                need(q['shape'] in ('circle', 'rect'), 'Unsupported actual SMT shape remains a failure')
                radius = q.get('corner_radius', q.get('rect_border_radius', 0))
                shape = pcbnew.PAD_SHAPE_ROUNDRECT if radius else shape_names[q['shape']]
                need(p.GetShape() == shape, 'Actual SMT shape')
                size = (2*q['radius'], 2*q['radius']) if q['shape'] == 'circle' else (q['width'], q['height'])
                need(abs(mm(p.GetBoundingBox().GetWidth()) - size[0]) <= TOL
                     and abs(mm(p.GetBoundingBox().GetHeight()) - size[1]) <= TOL, 'Actual world-space copper land extents')
                if radius: need(abs(mm(p.GetRoundRectCornerRadius(layer_ids[q['layer']])) - radius) <= TOL, 'Actual roundrect copper radius')
        all_part_pads = [p for f in part_fps.values() for p in f.Pads()]
        unlisted_pads = [p for p in all_part_pads if uid(p) not in used_pad_ids]
        need(len(used_pad_ids) == 1165 and len(unlisted_pads) == 2
             and all(p.GetAttribute() == pcbnew.PAD_ATTRIB_NPTH for p in unlisted_pads), '1165 lands bijective; only two existing NPTH mechanical holes outside land scope')
        checked('all1165SemanticLands', {'matchedLands': 1165, 'existingNpthOutsideLandScope': 2})
        items = list(board.GetTracks()); native_vias = [t for t in items if isinstance(t, pcbnew.PCB_VIA)]
        native_tracks = [t for t in items if not isinstance(t, pcbnew.PCB_VIA)]
        need(len(native_vias) == 234 and len(native_tracks) == len(expected['wireSegments'])
             and not any(isinstance(t, pcbnew.PCB_ARC) for t in native_tracks), 'No omitted, extra, or arc-substituted actual via/wire objects')
        matched_vias, used_via_ids = {}, set()
        for e in expected['vias']:
            budget(); q = e['raw']
            found = [v for v in native_vias if close(point(v.GetPosition()), source_point(q)) and uid(v) not in used_via_ids]
            need(len(found) == 1, 'Unique exported actual via ' + e['actualPcbViaId'])
            v = found[0]; used_via_ids.add(uid(v))
            need(v.TopLayer() == pcbnew.F_Cu and v.BottomLayer() == pcbnew.B_Cu
                 and abs(mm(v.GetDrillValue()) - q['hole_diameter']) <= TOL
                 and all(abs(mm(v.GetWidth(layer)) - q['outer_diameter']) <= TOL for layer in layer_ids.values())
                 and v.GetNetCode() != 0 and v.GetNetname() == e['expectedNetName'], 'Real fullspan dimensions/layers/authenticated electrical net ' + e['actualPcbViaId'])
            matched_vias[e['actualPcbViaId']] = v
        checked('all234FullspanViasAndAuthenticatedNets', {'vias': len(matched_vias), 'serializerBridgedSignalViaKeys': 103})
        buckets = {}
        for t in native_tracks: buckets.setdefault((t.GetLayer(), t.GetNetname()), []).append(t)
        mapped_tracks, used_track_ids = [], set()
        for e in expected['wireSegments']:
            budget(); a, b = source_point(e['a']), source_point(e['b'])
            found = [t for t in buckets.get((layer_ids[e['layer']], e['expectedNetName']), []) if uid(t) not in used_track_ids
                     and abs(mm(t.GetWidth()) - e['width']) <= TOL
                     and ((close(point(t.GetStart()), a) and close(point(t.GetEnd()), b)) or (close(point(t.GetStart()), b) and close(point(t.GetEnd()), a)))]
            need(len(found) == 1, 'Bijective actual wire geometry/net ' + e['actualPcbTraceId'] + ':' + str(e['routeIndex']))
            t = found[0]; used_track_ids.add(uid(t)); mapped_tracks.append((e, t))
        checked('allActualWireSegments', {'wireSegments': len(mapped_tracks), 'includingReferenceWires': True, 'geometryToleranceMm': TOL})
        board.BuildConnectivity(); connectivity = board.GetConnectivity()
        native_types = [pcbnew.PCB_PAD_T, pcbnew.PCB_TRACE_T, pcbnew.PCB_ARC_T, pcbnew.PCB_VIA_T]
        signal_nets = set()
        for s in expected['signals']:
            budget(); endpoints = [land_pads[e['pcbPort']['pcb_port_id']] for e in s['endpoints']]
            need(all(p.GetNetname() == s['expectedNetName'] for p in endpoints)
                 and endpoints[0].GetNetCode() == endpoints[1].GetNetCode() != 0
                 and endpoints[0].GetNetCode() not in signal_nets, 'Authentic distinct numeric signal net')
            signal_nets.add(endpoints[0].GetNetCode())
            # Nodes cluster actual same-owner endpoints within the declared geometry
            # tolerance; no foreign item, alias label, or same-net pour can add an edge.
            parent, coords, spatial = [], [], {}
            def node(layer, xy):
                bx, by = math.floor(xy[0]/TOL), math.floor(xy[1]/TOL)
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        for i in spatial.get((layer, bx+dx, by+dy), []):
                            if close(coords[i], xy): return i
                i = len(parent); parent.append(i); coords.append(xy); spatial.setdefault((layer, bx, by), []).append(i); return i
            def root(i):
                while parent[i] != i: parent[i] = parent[parent[i]]; i = parent[i]
                return i
            def union(a, b): parent[root(b)] = root(a)
            own = [(e, t) for e, t in mapped_tracks if e['originalOwner'] == s['originalSourceTraceId']]
            for e, t in own: union(node(t.GetLayer(), point(t.GetStart())), node(t.GetLayer(), point(t.GetEnd())))
            for vid in s['viaIds']:
                v = matched_vias[vid]; ns = [node(layer, point(v.GetPosition())) for layer in layer_ids.values()]
                for n in ns[1:]: union(ns[0], n)
            ends = [node(pcbnew.F_Cu, point(p.GetPosition())) for p in endpoints]
            owned_connected = root(ends[0]) == root(ends[1])
            # Native APIs may return immediate neighbors or an entire connected
            # cluster. Explicit types and visited-UUID BFS support either contract.
            # Only this owner's mapped items and its two real pads are traversed;
            # no independent geometric graph edge is used by this native BFS.
            allowed = {uid(p): p for p in endpoints}
            allowed.update({uid(t): t for _, t in own})
            allowed.update({uid(matched_vias[v]): matched_vias[v] for v in s['viaIds']})
            actual_connected, frontier, native_queries = {uid(endpoints[0])}, [endpoints[0]], 0
            while frontier and not set(allowed) <= actual_connected:
                budget(); current = frontier.pop(); native_queries += 1
                for item in connectivity.GetConnectedItems(current, native_types, False):
                    identity = uid(item)
                    if identity in allowed and identity not in actual_connected:
                        actual_connected.add(identity); frontier.append(allowed[identity])
            native_connected = uid(endpoints[1]) in actual_connected
            own_ids = {uid(t) for _, t in own} | {uid(matched_vias[v]) for v in s['viaIds']}
            every_owned_item_connected = own_ids <= actual_connected
            every_owned_graph_node_connected = all(root(i) == root(ends[0]) for i in range(len(parent)))
            result = {'originalSourceTraceId': s['originalSourceTraceId'], 'actualSourceTraceId': s['actualSourceTraceId'], 'name': s['name'],
                'endpoints': [{'reference': e['reference'], 'pin': e['pin'], 'actualOriginalPcbPortId': e['pcbPort']['pcb_port_id'],
                               'actualOriginalSourcePortId': e['sourcePort']['source_port_id'], 'kicadPadUuid': uid(p)} for e, p in zip(s['endpoints'], endpoints)],
                'netName': s['expectedNetName'], 'netCode': endpoints[0].GetNetCode(), 'ownedWireSegments': len(own), 'ownedViaIds': s['viaIds'],
                'ownedNumericGraphConnected': owned_connected, 'nativeNumericPadToPadConnected': native_connected,
                'everyOwnedGraphNodeConnected': every_owned_graph_node_connected, 'everyOwnedItemNativeConnected': every_owned_item_connected,
                'nativeTraversal': {'visitedUuidCount': len(actual_connected), 'queryCount': native_queries, 'explicitPadTrackArcViaTypes': True, 'ignoreNetcodes': False, 'foreignItemsTraversed': False},
                'ownedGraphUsesForeignCopperOrPourEdges': False, 'geometryNodeToleranceMm': TOL}
            report['signalResults'].append(result); save()
            need(owned_connected and native_connected and every_owned_graph_node_connected and every_owned_item_connected,
                 'Both graphs and every actual owned item must connect ' + s['originalSourceTraceId'])
        need(len(report['signalResults']) == len(signal_nets) == 49, 'All 49 independent numeric signal graphs')
        checked('all49OwnedAndNativeNumericGraphs', {'connectedSignals': 49, 'foreignCopperEdgesUsed': False})
        report['scoped49GeometryAndConnectivityPassed'] = True
        report['complete'] = True
    except Exception as exc:
        report['failures'].append({'type': type(exc).__name__, 'message': str(exc)})
        report['scoped49GeometryAndConnectivityPassed'] = False
    finally:
        same = all(digest(p.read_bytes()) == getattr(args, n + '_sha') for n, p in paths.items())
        same = same and digest(original.read_bytes()) == RAW_SHA and digest(representation.read_bytes()) == bridge['exportRepresentation']['sha256']
        report['allInputsUnchanged'] = same
        if not same:
            report['complete'] = False; report['scoped49GeometryAndConnectivityPassed'] = False
            report['failures'].append({'type': 'InputMutation', 'message': 'Read-only input hashes changed'})
        report['elapsedSeconds'] = time.monotonic() - started
        save()
    print(json.dumps({'report': str(args.output), 'complete': report['complete'], 'scoped49GeometryAndConnectivityPassed': report['scoped49GeometryAndConnectivityPassed'],
                      'fullDrcViolationsRetained': len(drc['violations']), 'fullDrcUnconnectedItemsRetained': len(drc['unconnected_items']), 'fabricationReady': False}))
    need(report['complete'] and report['scoped49GeometryAndConnectivityPassed'], 'Read-only scoped KiCad verification failed; full findings retained')

if __name__ == '__main__': main()
