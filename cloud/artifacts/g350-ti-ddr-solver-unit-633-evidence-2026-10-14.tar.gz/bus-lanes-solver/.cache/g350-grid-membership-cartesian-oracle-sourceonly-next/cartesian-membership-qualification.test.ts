import { expect, test } from "bun:test"
import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { createHash } from "node:crypto"

// Qualification-only: run the exact candidate's type-free membership block.
// No solver/grid import, replacement test runner, or timeout override.
const candidatePath = path.join(import.meta.dir, "grid-native-length-bounds.candidate.ts")
const candidate = fs.readFileSync(candidatePath, "utf8")
const manifest = JSON.parse(fs.readFileSync(path.join(import.meta.dir, "SOURCE-manifest.json"), "utf8"))
assert.equal(createHash("sha256").update(candidate).digest("hex"), manifest.candidateSha256)
const begin = candidate.indexOf("  const fullXPoints = new Set(")
const end = candidate.indexOf("  const original = complete(reference)", begin)
assert.ok(begin >= 0 && end > begin)
const exactBlock = candidate.slice(begin, end)
const runMembership = new Function("full", "clipped", "expect", exactBlock)

test("Cartesian membership matches the original exhaustive JSON Set for every query", () => {
  const fields = [
    { xs: [0], ys: [0] },
    { xs: [-0], ys: [-1.5, 0, 2.5] },
    { xs: [-2, -.01016, 0, .01016, 3], ys: [0] },
    { xs: [-3.117, -3.0662, -3.0154, -2.9646], ys: [6.9936, 7.00376, 7.01392] },
    { xs: [1e12, 1e12 + .125, 1e12 + .25], ys: [-1e12, -1e12 + .25] },
    { xs: [-0, 0, Number.MIN_VALUE], ys: [-Number.MIN_VALUE, -0, 0] },
    // Preserve the original JSON-string predicate's null normalization too.
    { xs: [NaN, Infinity, -Infinity, 1], ys: [NaN, Infinity, -Infinity, 2] },
  ]
  let exhaustiveQueries = 0
  for (const { xs, ys } of fields) {
    const grid = {
      nx: xs.length,
      ny: ys.length,
      cellCount: xs.length * ys.length,
      point(id: number) { return { x: xs[id % xs.length], y: ys[Math.floor(id / xs.length)] } },
    }
    const original = new Set(Array.from({ length: grid.cellCount }, (_, id) => JSON.stringify(grid.point(id))))
    const queryXs = [...xs, -0, 0, -99, 99, Number.MIN_VALUE, -Number.MIN_VALUE, NaN, Infinity, -Infinity]
    const queryYs = [...ys, -0, 0, -99, 99, Number.MIN_VALUE, -Number.MIN_VALUE, NaN, Infinity, -Infinity]
    const queries = queryXs.flatMap(x => queryYs.map(y => ({ x, y })))
    const expected = queries.map(point => original.has(JSON.stringify(point)))
    const actual: boolean[] = []
    runMembership(grid, { cellCount: queries.length, point: (id: number) => queries[id] }, (value: boolean) => ({
      toBe(required: boolean) { assert.equal(required, true); actual.push(value) },
    }))
    expect(actual).toEqual(expected)
    expect(actual).toHaveLength(queries.length)
    exhaustiveQueries += queries.length
  }
  expect(exhaustiveQueries).toBeGreaterThan(1000)
})
