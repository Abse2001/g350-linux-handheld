import { runBoundedRouting } from "./source/lib/run-bounded-routing"

/** Stop only after an actual original yield, closing through original RETURN. */
export function captureUntilEnclosedBoundary(
  module: any,
  args: readonly unknown[],
  boundaryAttempted: () => boolean,
  testOriginalOverride?: (...args: any[]) => Generator<any, any, any>,
) {
  const original = testOriginalOverride ?? module.routeCoupledPair
  const state = {
    originalFactories: 1,
    originalNextCalls: 0,
    originalReturnCalls: 0,
    originalThrowCalls: 0,
    chargedYields: 0,
    naturalCompletion: false,
    originalTerminalMethod: null as string | null,
    diagnosticBoundaryStopped: false,
    boundedDone: false,
    rawResult: null as any,
  }
  const work = Reflect.apply(original, undefined, [...args]) as Generator<
    any,
    any,
    any
  >
  const advance = (method: "next" | "return" | "throw", values: any[]) => {
    if (method === "next") state.originalNextCalls++
    else if (method === "return") state.originalReturnCalls++
    else state.originalThrowCalls++
    const result = Reflect.apply(work[method], work, values) as IteratorResult<
      any,
      any
    >
    if (result.done && state.originalTerminalMethod === null) {
      state.originalTerminalMethod = method
      state.naturalCompletion = method === "next"
      state.rawResult = result.value
    }
    return result
  }
  const observed: any = {
    next: (...values: any[]) => advance("next", values),
    return: (...values: any[]) => advance("return", values),
    throw: (...values: any[]) => advance("throw", values),
    [Symbol.iterator]() {
      return this
    },
  }
  const bounded = runBoundedRouting(observed, 6000)
  let closed = false
  try {
    while (true) {
      const result = bounded.next()
      if (result.done) {
        closed = state.boundedDone = true
        state.rawResult = result.value
        break
      }
      state.chargedYields++
      if (boundaryAttempted()) {
        const returned = bounded.return(null)
        closed = state.boundedDone = returned.done === true
        state.diagnosticBoundaryStopped = true
        break
      }
    }
  } finally {
    if (!closed) bounded.return(null)
  }
  return state
}
