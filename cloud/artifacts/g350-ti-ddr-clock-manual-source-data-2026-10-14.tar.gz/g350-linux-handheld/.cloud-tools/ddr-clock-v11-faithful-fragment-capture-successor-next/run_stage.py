"""One future Root-authorized stage. No CLI/routing/native/CAD execution."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def require(value,message):
 if not value:raise ValueError(message)
def main():
 phase=sys.argv[1] if len(sys.argv)==2 else None
 require(phase in ('capture','types','core') and os.environ.get('G350_CLOCK_SERIAL_STAGE')==phase,'One exact Root stage required')
 packet=ROOT/'PREPARED-manifest.json';m=read(packet);packet_sha=sha(packet)
 require(os.environ.get('G350_CLOCK_SERIAL_PACKET_SHA')==packet_sha,'Prepared guard packet changed')
 authority=Path(os.environ['G350_CLOCK_SERIAL_ROOT_RECEIPT']);a=read(authority)
 require(sha(authority)==os.environ['G350_CLOCK_SERIAL_ROOT_RECEIPT_SHA'] and a.get('authorizedByRoot') is True and a.get('phase')==phase and a.get('packetSha256')==packet_sha and a.get('clockSourceManifestSha256')==m['clockSourceManifestSha256'],'Exact Root receipt changed')
 run=ROOT/('run-'+phase);require(run.is_dir(),'Owned process guard output required')
 report={'phase':phase,'packetSha256':packet_sha,'clockSourceManifestSha256':m['clockSourceManifestSha256'],'commands':[],'passed':False,'actualSourceCaptureCalls':0,'actualTypeCalls':0,'actualCoreCalls':0,'nativeExplicitCalls':0,'cliCalls':0,'routingCalls':0,'cadCalls':0,'accepted49':False,'fabricationReady':False}
 def save():(run/'result.json').write_text(json.dumps(report,indent=2)+'\n')
 def command(name,argv,cwd,env=None):
  started=time.monotonic()
  with (run/(name+'.log')).open('xb') as out:r=subprocess.run(argv,cwd=cwd,env={**os.environ,**(env or {})},stdout=out,stderr=subprocess.STDOUT,check=False)
  report['commands'].append({'name':name,'argv':argv,'cwd':str(cwd),'exitCode':r.returncode,'seconds':time.monotonic()-started});save()
  require(r.returncode==0,'Actual stage command failed: '+name)
 save()
 try:
  if phase=='capture':
   actual=run/'source-capture.json';diagnostic=run/'source-tree-diagnostic.json';report['actualSourceCaptureCalls']=1
   command('pure-source-inverse',[m['bun'],'--smol',m['captureWorker'],str(actual),str(diagnostic)],Path(m['sourceWorkingDirectory']),{'G350_CLOCK_FIDELITY_SOURCE_APPROVED':'1'})
   c=read(actual)
   require(c['actualPureReactEvaluated'] is True and c['exactInverseSourceProjectionPassed'] is True and c['originalReactElementCount']==2228 and c['proposedReactElementCount']==2232 and c['proposedLiteralCount']-c['originalLiteralCount']==4 and c['originalLiteralCount']+c['originalFragmentContainerCount']==2228 and c['proposedLiteralCount']+c['proposedFragmentContainerCount']==2232 and c['originalFragmentContainerCount']==c['proposedFragmentContainerCount'] and c['allOriginalFragmentTypesKeysPropsAndChildOrderCompared'] is True and c['onlyActualReactFragmentIdentityAllowed'] is True and c['unknownElementSymbolsFunctionsRejected'] is True and c['originalLiteralTypesKeysPropsAndChildOrderCompared'] is True and c['allOriginalReturnedSourceMetadataCompared'] is True and c['addedRealLayerPorts']==4 and c['changedPCBOnlyElements']==6 and c['changedPCBProperties']==8 and c['coreRendered'] is False and c['circuitConstructedByThisWorker'] is False and c['transitiveFrozenSourceImportsCoreDefinitions'] is True and c['coreDirectlyImportedByThisWorker'] is False and c['nativeExecuted'] is False and c['cadExecuted'] is False,'Actual Source inverse result failed or import labeling changed')
   require(c['actualTreeDiagnosticPath']==str(diagnostic) and c['actualTreeDiagnosticSha256']==sha(diagnostic),'Actual preassertion tree diagnostic must be bound')
   report.update(capturePath=str(actual),captureSha256=sha(actual),diagnosticPath=str(diagnostic),diagnosticSha256=sha(diagnostic),actualInverseSourcePassed=True)
  elif phase=='types':
   report['actualTypeCalls']=1
   command('strict-original-flags-new-clock-source',m['typecheckCommand'],Path(m['typeWorkingDirectory']))
   report['typecheckPassed']=True
  else:
   actual=run/'raw-core.json';control=run/'core-controls.json';report['actualCoreCalls']=1
   command('one-pinned-core-real-layer-ports',[m['bun'],'--smol',m['coreWorker'],str(actual),str(control)],Path(m['coreWorkingDirectory']),{'G350_CLOCK_FIDELITY_CORE_APPROVED':'1'})
   c=read(control)
   require(c['freshCoreControlPassed'] is True and c['rawCorePath']==str(actual) and c['rawCoreSha256']==sha(actual) and c['originalFullClockLengthsAssignedDirectSourceIds'] is True and len(c['clocks'])==2 and all(row['passed'] is True for row in c['checks']),'Actual fresh Core Source/physical control failed')
   report.update(actualCorePath=str(actual),actualCoreSha256=sha(actual),coreControlsPath=str(control),coreControlsSha256=sha(control),freshCoreControlPassed=True)
  report['passed']=True;save();print(json.dumps({'phase':phase,'passed':True,'actualCoreCalls':report['actualCoreCalls'],'accepted49':False}));return 0
 except BaseException as error:
  report['failure']=type(error).__name__+': '+str(error)
  for label,name in [('capture','source-capture.json'),('sourceTreeDiagnostic','source-tree-diagnostic.json'),('rawCore','raw-core.json'),('coreControls','core-controls.json')]:
   path=run/name
   if path.is_file():report[label+'RetainedPath']=str(path);report[label+'RetainedSha256']=sha(path)
  save();raise
if __name__=='__main__':raise SystemExit(main())
