from pathlib import Path
import argparse, hashlib, importlib.util, json, re, stat, sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT.parent / 'g350-coupled-handoff-length-prune-canonical-fullsuite-smol-2g-successor-next'
BASE = ROOT.parent / 'g350-count-conditioned-site-recovery-next'
POLICY = {'wallSeconds': 300, 'rssBytes': 2*1024**3, 'sharedBytes': 24*1024**3,
          'sampleSeconds': .05, 'termGraceSeconds': 5}
RESERVE = 2*1024**3

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''): h.update(block)
    return h.hexdigest()

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec); spec.loader.exec_module(loaded)
    return loaded

def verify():
    raw = (ROOT / 'PREPARED.json').read_bytes(); packet = json.loads(raw)
    for row in packet['files'] + packet['externalFiles']:
        path = Path(row['path'])
        assert path.is_file() and not path.is_symlink() and sha(path) == row['sha256']
        assert path.stat().st_size == row['bytes'] and stat.S_IMODE(path.stat().st_mode) == row['mode']
    original = module('canonical_handoff_held_fullsuite_guard', ORIGINAL / 'guard.py')
    old_packet, old_digest, canonical_guard, scope = original.verify()
    assert old_digest == packet['originalPacketSha256'] == 'd983c907363dc3bcd0319fee1e5e79bf4158cf2905993a8f33ac0447f4eb6e4b'
    assert old_packet['sourceDirectory'] == packet['sourceDirectory']
    assert old_packet['policy'] == POLICY
    assert packet['policy'] == POLICY
    assert old_packet['preforkReserveBytes'] == packet['preforkReserveBytes'] == RESERVE
    assert old_packet['discoveredTestFileCount'] == packet['discoveredTestFileCount'] == 186
    assert old_packet['command'][1] == '--smol'
    assert packet['command'] == [old_packet['command'][0], *old_packet['command'][2:]]
    previous = json.loads((ORIGINAL / 'EXECUTION-postaudit.json').read_bytes())
    execution = previous['execution']
    assert previous['fullSuitePassed'] is False and previous['sourceAndArtifactsHeld'] is True
    assert previous['dependenciesBefore'] == previous['dependenciesAfter']
    assert previous['actualCounters'] == {'pass': 632, 'fail': 1, 'tests': 633, 'files': 186}
    assert execution['pgid'] == 304736 and execution['exitCode'] == 1
    assert execution['diagnosticStopped'] is False and execution['stopReasons'] == []
    assert execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values())
    collection = json.loads(Path(packet['originalRootCollectionPath']).read_bytes())
    assert collection['sessionId'] == 5452 and collection['toolExitCode'] == 2
    scope = module('canonical_handoff_original_owned_scope', BASE / 'process_scope.py')
    assert not scope.owned(304736)
    return packet, hashlib.sha256(raw).hexdigest(), canonical_guard, scope

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--root-receipt'); parser.add_argument('--root-receipt-sha256')
    args = parser.parse_args(); packet, digest, original, scope = verify()
    if args.preflight_only:
        print(json.dumps({'preflightPassed': True, 'packetSha256': digest, 'sourceOnly': True})); return 0
    assert args.run and args.root_receipt and args.root_receipt_sha256
    authority = json.loads(Path(args.root_receipt).read_bytes())
    assert sha(args.root_receipt) == args.root_receipt_sha256
    assert authority['authorizedByRoot'] is True and authority['scope'] == packet['scope']
    assert authority['packetSha256'] == digest and authority['policy'] == POLICY
    assert re.fullmatch('[0-9a-f]{32,128}', authority['approvalToken'])
    assert not (ROOT / 'run').exists()
    before = original.dependencies(); baseline = scope.memory()
    def gate(now):
        assert now['current'] + POLICY['rssBytes'] + RESERVE < POLICY['sharedBytes'], 'Strict prefork reserve required'
        assert all(now['events'][k] == baseline['events'][k] for k in scope.OOM_KEYS)
    actual = scope.run_guarded(packet['command'], Path(packet['sourceDirectory']), ROOT / 'run',
        POLICY, {'GIT_OPTIONAL_LOCKS': '0'}, before_spawn=gate)
    verify(); after = original.dependencies(); assert before == after
    log_path = ROOT / 'run/child.log'
    log = log_path.read_text(errors='replace') if log_path.is_file() else ''
    summaries = re.findall(r'^Ran (\d+) tests across (\d+) files?\.', log, re.M)
    passes = re.findall(r'^\s*(\d+) pass\s*$', log, re.M)
    failures = re.findall(r'^\s*(\d+) fail\s*$', log, re.M)
    counts = {'pass': int(passes[-1]) if passes else None,
              'fail': int(failures[-1]) if failures else None,
              'tests': int(summaries[-1][0]) if summaries else None,
              'files': int(summaries[-1][1]) if summaries else None}
    passed = (actual['exitCode'] == 0 and not actual['diagnosticStopped']
        and actual['cleanupOwnedGroupEmpty'] and not any(actual['oomDelta'].values())
        and counts['tests'] is not None and counts['tests'] > 0
        and counts['pass'] == counts['tests'] and counts['fail'] == 0
        and counts['files'] == packet['discoveredTestFileCount'])
    receipt = {'execution': actual, 'dependenciesBefore': before, 'dependenciesAfter': after,
        'sourceAndArtifactsHeld': True, 'packetSha256': digest, 'fullSuitePassed': passed,
        'actualCounters': counts, 'childLogSha256': sha(log_path),
        'originalRssStoppedOutcomePreserved': True, 'originalSmolTimeoutFailurePreserved': True, 'sameFrozenSourceAndTests': True,
        'typecheckRepeated': False, 'wholeSuiteExecuted': True, 'accepted49': False,
        'allElevenBenchmarksExecuted': False}
    (ROOT / 'EXECUTION-postaudit.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'fullSuitePassed': passed, 'actualCounters': counts}))
    return 0 if passed else 2

if __name__ == '__main__': raise SystemExit(main())
