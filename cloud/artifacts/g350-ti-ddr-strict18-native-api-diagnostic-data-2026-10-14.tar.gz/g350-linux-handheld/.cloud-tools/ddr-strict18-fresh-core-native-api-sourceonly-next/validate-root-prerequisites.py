"""Read-only stdlib Root binding validator. Not authorization; no worker launch/imports."""
import argparse,hashlib,json,re,stat
from pathlib import Path
BOARD=Path('/workspace/g350-linux-handheld');BUS=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
SOURCE18='be1969ab1a99af7e823213c44166505eaf765048e6809fcd5f2fbd6aea5bd15e'
CORE18='6c4bf7ee94347c8cb21307b22d6ef231e136589a77752f0702f34fa8d3ab2c4d'
SDK='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2';SOLVER='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
ACTUAL={'capture':{'path':str(BUS/'strict18-source-capture-86442-COLLECTED-root.json'),'sha256':'958629c84d3b3da1245e2ac38bd356240eba6a3bafa5f5f2c8b84cc109b1c6be','tool':86442,'scope':'ACTUAL_STRICT18_MANUAL_SOURCE_CAPTURE'},'types':{'path':str(BUS/'strict18-types-45112-COLLECTED-root.json'),'sha256':'d5d4b470069ba51e9ec181c2117b79dd4640d301e92d0eef0c20528eb435d597','tool':45112,'scope':'ACTUAL_STRICT18_FUNCTIONAL_STRICT_TYPECHECK'},'core':{'path':str(BUS/'strict18-core-36930-COLLECTED-root.json'),'sha256':'9c36f2ea1f655a5ac7472ed032a7c414555d1f23ab67dcb53beea02c31387cfc','tool':36930,'scope':'ACTUAL_FRESH_STRICT18_MANUAL_CORE279_SOURCE_CONTROL'}}
def require(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 p=Path(p);require(p.is_file()and not p.is_symlink(),'Regular input '+str(p));return json.loads(p.read_bytes())
def exact(row):require(sha(row['path'])==row['sha256'],'Exact hash '+row['path']);return read(row['path'])
def verifyrows(rows):
 for r in rows:
  p=Path(r['path']);st=p.lstat();require(stat.S_ISREG(st.st_mode)and not p.is_symlink(),'Regular boundSource');require(st.st_size==r['bytes']and stat.S_IMODE(st.st_mode)==r['mode']and sha(p)==r['sha256'],'Exact boundSource '+str(p))
def validate_collection(c,p,phase):
 expected=ACTUAL[phase]
 require(c['authorizedByRoot']is True and c['toolSessionId']==expected['tool']and c['scope']==expected['scope'],'Root actual phase/session/scope')
 require(c['toolSessionCollected']is True and c['toolExitCode']==c['toolWrapperExitCode']==0 and c['passed']is True,'Actual collected natural0')
 require(c['sourceManifestSha256']==SOURCE18 and p['sourceManifestSha256']==SOURCE18,'Exact Source147')
 if phase!='capture':require(c['coreSourceManifestSha256']==p['coreSourceManifestSha256']==CORE18,'Exact owned-alias CoreSource')
 require(c['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True and p['passed']is True,'Actual SourceSDK held')
 e=c['execution'];require(e==p['execution']and e['exitCode']==0 and e['diagnosticStopped']is False and e['cleanupOwnedGroupEmpty']is True and not any(e['oomDelta'].values()),'Exact actual closed0OOM execution')
 require(p['dependenciesBefore']==p['dependenciesAfter']and p['dependenciesAfter']['treeSha256']==SDK,'Actual Ce3 before/after')
 require(p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['solverDependenciesAfter']['treeSha256']==SOLVER,'Actual47633 before/after')
 require(c['accepted49']is False and c['fabricationReady']is False,'No claimed broadqualification')
 return e['pgid']
def validate_binding(manifest,authority,manifest_sha):
 require(authority.get('authorizedByRoot')is True and authority.get('scope')==manifest['scope']and authority.get('packetSha256')==manifest_sha,'Unbound authority template refuses')
 require(authority.get('rootFullGuardReadPassed')is True and authority.get('noConcurrentRootWorker')is True and authority.get('allPreviousRootWorkersCollected')is True,'Root fullread/serial closure')
 require(re.fullmatch('[0-9a-f]{32,128}',authority.get('approvalToken',''))is not None,'Fresh Root token')
 require(manifest.get('sourceManifestSha256')and authority.get('sourceManifestSha256')==manifest['sourceManifestSha256'],'Exact newNativeSource manifest')
 require(authority.get('coreSourceManifestSha256')==CORE18 and authority.get('freshArtifacts')==manifest['actualFreshArtifacts'],'Exact fresh Core279 authority')
 require(authority.get('policy')==manifest['policy']and manifest['policy']['rssBytes']<=1073741824 and manifest['policy']['sharedBytes']==32212254720,'Original bounded Native1GiB/shared30GiB policy')
 require(authority.get('requiredActualCollections')==manifest['requiredActualCollections'],'Exact actual capture/types/Core links')
 verifyrows(manifest['files']);verifyrows(manifest['externalFiles'])
 peer=exact(authority['nativeSourcePeerReview']);require(peer['sourceManifestSha256']==manifest['sourceManifestSha256']and peer['decision']=='GO_SOURCE_ONLY_TO_ROOT_READ_AND_GUARDED_STRICT18_NATIVE_ALL3_APIS','Finite newNative source peer required')
 pgids=[]
 for phase,expected in ACTUAL.items():
  r=manifest['requiredActualCollections'][phase];require(r==expected,'No old2clock receipt reuse')
  c=exact(r);p=exact({'path':c['postauditPath'],'sha256':c['postauditSha256']});pgids.append(validate_collection(c,p,phase));verifyrows(p.get('outputFiles',[]))
 core=exact(ACTUAL['core']);post=read(core['postauditPath']);a=manifest['actualFreshArtifacts'];require(post['rawCorePath']==a['actualCorePath']and post['rawCoreSha256']==a['actualCoreSha256']and post['coreControlsPath']==a['coreControlsPath']and post['coreControlsSha256']==a['coreControlsSha256'],'Actual Root Core artifacts')
 require(sha(a['actualCorePath'])==a['actualCoreSha256'],'Actual raw held');ctl=exact({'path':a['coreControlsPath'],'sha256':a['coreControlsSha256']});require(ctl['rawCorePath']==a['actualCorePath']and ctl['rawCoreSha256']==a['actualCoreSha256']and ctl['freshCoreControlPassed']is True and len(ctl['checks'])==120 and all(r['passed']is True for r in ctl['checks']),'Actual120Core controls')
 require(ctl['automaticCoreSrjForThisForkMustNotBeUsed']is True and ctl['expectedMissingOriginalSignalCount']==31,'Manual/incomplete49 contract')
 return {'actualPreviousPgids':pgids,'rootOuterMustIndependentlyRequireOwnedGroupsEmptyNow':True,'rootOuterMustReinventoryCe3And47633BeforeAndAfter':True,'rootOuterMustRequireSharedCurrentPlusRssPlus1GiBReserveBelow30GiB':True,'authorizedByThisValidator':False,'actualApplicationCalls':0}
def main():
 p=argparse.ArgumentParser();p.add_argument('binding',type=Path);p.add_argument('binding_sha');p.add_argument('root_authority',type=Path);p.add_argument('root_authority_sha');a=p.parse_args();m=exact({'path':str(a.binding),'sha256':a.binding_sha});r=exact({'path':str(a.root_authority),'sha256':a.root_authority_sha});print(json.dumps(validate_binding(m,r,a.binding_sha)))
if __name__=='__main__':main()
