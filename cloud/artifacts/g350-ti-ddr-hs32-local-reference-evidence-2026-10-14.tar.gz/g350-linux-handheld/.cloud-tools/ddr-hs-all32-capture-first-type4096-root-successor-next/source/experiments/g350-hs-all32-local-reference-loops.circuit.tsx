import {buildJointHsReferenceSource} from "../hs-reference-overlay"
export default()=>buildJointHsReferenceSource().element
