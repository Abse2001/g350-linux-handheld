"""Root serial offline KiCad diagnostic of exact18; API angle failures retained."""
import fcntl,importlib.util,json,secrets,stat,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
s=importlib.util.spec_from_file_location('strict18_capture_stdlib_cad',ROOT/'run-strict18-source-capture-root.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
PACKET=c.BOARD/'.cloud-tools/ddr-strict18-fresh-kicad-angle-diagnostic-successor-next'
SOURCE_SHA='0b62792415eefd3cdb6f2f9fae29e5d78ce597396d7f8b8d5b011a0a3283bad9'
OUT=PACKET/'run-cad'
POLICY={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
def main():
 assert len(sys.argv)==3
 receipt=Path(sys.argv[1]);assert c.sha(receipt)==sys.argv[2]
 cc,cp,ce=c.guard.collected({'path':str(receipt),'sha256':sys.argv[2]},positive=True)
 assert cc['toolSessionId']==10835 and cc['sourceManifestSha256']=='0cb11e58347f30e8e810dc1f783b48a9225485e8157e7222ddda55dba394fb9a'
 cli=c.read(cp['resultPath']);assert cli['exportPassed'] and cli['apiAnglesFailed'] and cli['complete18Accepted'] is False
 m=c.read(PACKET/'SOURCE-manifest.json')
 def bindings():
  assert c.sha(PACKET/'SOURCE-manifest.json')==SOURCE_SHA
  for row in m['files']+m['externalFiles']:c.guard.source_guard.binding(row)
  for name in ('node_modules','.pnp.cjs','.pnp.loader.mjs','.yarn'):
   p=PACKET/name;assert not p.exists() and not p.is_symlink()
 bindings();_,ssha=c.bindings();_,oldsha,before,sbefore,_=c.guard.checked()
 prior=c.read(c.BOARD/'.cloud-tools/ddr-strict18-fresh-json-cli-angle-diagnostic-successor-next/run-cli/ROOT_AUTHORITY.json')['actualPriorCollectedRows']+[{'path':str(receipt),'sha256':sys.argv[2]}]
 def closed():
  for row in prior:assert c.guard.process_scope.owned(c.guard.collected(row)[2]['pgid'])==[]
 closed();assert not OUT.exists() and not OUT.is_symlink();OUT.mkdir();output=OUT/'output';output.mkdir()
 name='g350-strict18-fresh-cad-'+secrets.token_hex(8)+'-'+secrets.token_hex(8)
 docker=['bash',str(c.BOARD/'scripts/cloud-docker.sh')]
 def container_empty():
  result=subprocess.run(docker+['ps','--all','--quiet','--filter','name=^/'+name+'$'],capture_output=True,text=True,timeout=20);assert result.returncode==0;return not result.stdout.strip()
 assert container_empty()
 authority=c.read(PACKET/'AUTHORITY_TEMPLATE_NO_AUTHORIZATION.json');authority.update(authorizedByRoot=True,sourceManifestSha256=SOURCE_SHA,actualPreviousScopesCollectedAndEmpty=True,noConcurrentRootWorker=True,rootFullWorkerReadPassed=True,outputDirectory=str(output),actualCliCollection={'path':str(receipt),'sha256':sys.argv[2]},actualCliReport={'path':cp['resultPath'],'sha256':cp['resultSha256']},actualExport={'path':cli['outputPath'],'sha256':cli['outputSha256']},actualPriorCollectedRows=prior,containerName=name,policy=POLICY,containerMemoryBytes=2147483648,approvalToken=secrets.token_hex(32))
 ap=OUT/'ROOT_AUTHORITY.json'
 with ap.open('x')as f:json.dump(authority,f,indent=2);f.write('\n')
 ap.chmod(0o600);ah=c.sha(ap)
 def prefork(mem):
  closed();assert mem['current']+POLICY['rssBytes']+2147483648+1073741824<POLICY['sharedBytes']
 argv=['bash',str(PACKET/'run-kicad-offline.sh'),str(output),name,str(PACKET/'inspect_strict18.py'),'--root-receipt',str(ap),'--root-receipt-sha256',ah,'--output-directory',str(output)]
 execution=None;error=None;container_error=None
 with (ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  try:execution=c.guard.process_scope.run_guarded(argv,str(c.BOARD),OUT/'owned',POLICY,{'G350_STRICT18_CAD_ROOT_GUARDED':'1'},before_spawn=prefork)
  except BaseException as ex:
   error=type(ex).__name__+': '+str(ex)
   if (OUT/'owned/execution.json').is_file():execution=c.read(OUT/'owned/execution.json')
  empty=False
  try:
   if not container_empty():
    result=subprocess.run(docker+['rm','--force',name],capture_output=True,text=True,timeout=20);assert result.returncode==0
   empty=container_empty()
  except BaseException as ex:container_error=type(ex).__name__+': '+str(ex)
  after=None;safter=None;held=False;post_error=None
  try:
   _,nsha,after,safter,_=c.guard.checked();_,asource=c.bindings();closed();bindings()
   held=oldsha==nsha and ssha==asource and before==after and sbefore==safter and c.sha(receipt)==sys.argv[2] and c.sha(ap)==ah
  except BaseException as ex:post_error=type(ex).__name__+': '+str(ex)
  rp=output/'kicad-strict18-report.json';report=c.read(rp)if rp.is_file()else None
  passed=held and empty and error is None and container_error is None and post_error is None and execution is not None and execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values()) and report is not None and report['passed'] and report['diagnosticCompleted'] and report['allInputBytesHeld'] and report['actualLocalPhysicalApproachCount']==96 and report['actual18PhysicalCpuRamGraphCount']==18 and report['apiAnglesFailed'] and report['complete18Accepted'] is False
  files=[{'path':str(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':c.sha(p)}for p in sorted([*OUT.iterdir(),*output.iterdir()])if p.is_file()and not p.is_symlink()]
  post={'scope':m['scope'],'sourceManifestSha256':SOURCE_SHA,'execution':execution,'sourceAndDependenciesHeld':held,'dependenciesBefore':before,'dependenciesAfter':after,'solverDependenciesBefore':sbefore,'solverDependenciesAfter':safter,'runFailure':error,'postverificationFailure':post_error,'containerCleanupFailure':container_error,'containerName':name,'ownedContainerRemoved':empty,'outputFiles':files,'resultPath':str(rp),'resultSha256':c.sha(rp)if report else None,'passed':bool(passed),'cadCalls':1 if report else 0,'cliCalls':0,'coreCalls':0,'nativeCalls':0,'expectedMissingOriginalSignalCount':31,'apiAnglesFailed':True,'complete18Accepted':False,'referenceQualified':False,'electricalTimingQualified':False,'accepted49':False,'fabricationReady':False}
  with (OUT/'POSTAUDIT.json').open('x')as f:json.dump(post,f,indent=2);f.write('\n')
  print(json.dumps({k:post[k]for k in ('passed','sourceAndDependenciesHeld','runFailure','postverificationFailure','ownedContainerRemoved','containerCleanupFailure','execution')}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
