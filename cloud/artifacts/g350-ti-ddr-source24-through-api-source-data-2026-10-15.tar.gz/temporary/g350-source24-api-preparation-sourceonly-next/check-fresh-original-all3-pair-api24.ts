import fs from "node:fs"
import crypto from "node:crypto"
import assert from "node:assert/strict"
import type { SimpleRouteJson, Trace } from "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/types"
const [manifestPath,manifestSha,authorityPath,authoritySha,nativePath,outputPath,...extra]=process.argv.slice(2)
assert.ok(manifestPath&&manifestSha&&authorityPath&&authoritySha&&nativePath&&outputPath&&!extra.length&&!fs.existsSync(outputPath))
assert.equal(process.env.G350_MOVED24_FRESH_NATIVE_APPROVED,"1");assert.equal(process.versions.bun,"1.3.14")
const digest=(b:Buffer)=>crypto.createHash("sha256").update(b).digest("hex")
const load=(p:string,h?:string)=>{const b=fs.readFileSync(p);if(h)assert.equal(digest(b),h);return JSON.parse(b.toString())}
try {
const manifest=load(manifestPath,manifestSha),authority=load(authorityPath,authoritySha)
assert.equal(authority.authorizedByRoot,true);assert.equal(authority.packetSha256,manifestSha);assert.equal(authority.scope,manifest.scope)
for(const row of [...manifest.files,...manifest.externalFiles]){const st=fs.lstatSync(row.path);assert(st.isFile()&&!st.isSymbolicLink());const b=fs.readFileSync(row.path);assert.equal(b.length,row.bytes);assert.equal(st.mode&0o777,row.mode);assert.equal(digest(b),row.sha256)}
const artifacts=manifest.actualFreshArtifacts;assert.deepEqual(authority.freshArtifacts,artifacts)
assert.equal(typeof artifacts.actualCorePath,"string");assert.equal(typeof artifacts.actualCoreSha256,"string");
const raw=fs.readFileSync(artifacts.actualCorePath);assert.equal(digest(raw),artifacts.actualCoreSha256)
const core=JSON.parse(raw.toString()) as Array<Record<string,any>>,native=load(nativePath)
// Native was collected in a prior Root scope; its packet is bound separately.
assert.equal(nativePath,manifest.actualNativeReportPath)
assert.equal(digest(fs.readFileSync(nativePath)),manifest.actualNativeReportSha256)
assert.equal(native.packetSha256,manifest.nativeQualificationPacketSha256)
assert.equal(native.actualCoreSha256,artifacts.actualCoreSha256)
assert.equal(native.checkCount,18);assert.equal(native.physicalErrors,0);assert.equal(native.physicalCpuRamConnectedCarrierCount,24);assert.equal(native.actualNativePairFindings.length,0)
// Source24 physical material and all endpoint IDs must be freshly projected AFTER
// its Native ownership proof. An old631/B262 file is never an accepted binding.
for(const key of ["authorized49InputPath","authorized49InputSha256","fresh49ProjectionProofPath","fresh49ProjectionProofSha256","source24ProposalPath","source24ProposalSha256"])assert.equal(typeof manifest[key],"string",`Future binding absent: ${key}`)
const input=load(manifest.authorized49InputPath,manifest.authorized49InputSha256) as SimpleRouteJson
const projectionProof=load(manifest.fresh49ProjectionProofPath,manifest.fresh49ProjectionProofSha256)
assert.equal(projectionProof.actualCoreSha256,artifacts.actualCoreSha256)
assert.equal(projectionProof.actualNativeReportSha256,digest(fs.readFileSync(nativePath)))
assert.equal(projectionProof.constructorInputSha256,manifest.authorized49InputSha256)
assert.equal(projectionProof.sourceManifestSha256,manifest.genuineSource24ManifestSha256)
assert.equal(projectionProof.originalSource24ProposalSha256,manifest.source24ProposalSha256)
const proposal=load(manifest.source24ProposalPath,manifest.source24ProposalSha256)
const static24={records:proposal.selected24NormalizedRecords}
assert.equal(static24.records.length,24)
const updatedPairs={candidates:Object.fromEntries(proposal.selected24OriginalCarriers.filter((c:Record<string,any>)=>["source_trace_15","source_trace_16","source_trace_27","source_trace_28","source_trace_33","source_trace_34"].includes(c.originalSourceTraceId)).map((c:Record<string,any>)=>[c.originalSourceTraceId,{layer:c.carrierLayer,path:c.expectedCarrierPath,coupledSection:c.coupledSection}]))}
assert.deepEqual(Object.keys(updatedPairs.candidates).sort(),["source_trace_15","source_trace_16","source_trace_27","source_trace_28","source_trace_33","source_trace_34"].sort())
assert.equal(input.connections.length,49);assert.equal(input.traces!.length,263);assert.equal(input.obstacles.length,1298);assert.equal(input.layerCount,4)
assert.equal(input.differentialPairs!.length,3);assert(input.differentialPairs!.every(p=>p.lengthTolerance===.127&&p.traceGap===.12))
assert.equal(core.filter(r=>r.type==="pcb_via").length,227);assert.equal(core.filter(r=>r.type==="pcb_trace").length,287)
assert.equal(core.filter(r=>r.type==="pcb_port").length,1653)
assert.equal(input.traces!.flatMap(t=>t.route).filter(p=>p.route_type==="via").length,98)
const ram14map=native.actualOwnershipProof.signalMappings.find((m:Record<string,any>)=>m.originalSourceTraceId==="source_trace_14"&&m.side===1)
assert(ram14map)
const ram14via=core.find(r=>r.type==="pcb_via"&&r.pcb_via_id===ram14map.actualViaId)!
assert(ram14via&&Math.hypot(ram14via.x-2.4,ram14via.y-12)<1e-9)
const ram14request=input.connections.find(c=>c.name==="source_trace_14")!.pointsToConnect[1]
assert(Math.hypot(ram14request.x-ram14via.x,ram14request.y-ram14via.y)<1e-9,"Fresh49 must include actual relocated barrel")
const signature=JSON.stringify(core),bindings=native.actualOwnershipProof.carriers
assert.equal(bindings.length,24)
const projections:Array<Record<string,any>>=[]
const traces:Trace[]=bindings.map((binding:Record<string,any>)=>{
 const direct=core.filter(r=>r.type==="pcb_trace"&&r.source_trace_id===binding.originalSourceTraceId)
 assert.equal(direct.length,3);assert.deepEqual(direct.map(t=>t.pcb_trace_id),binding.actualDirectPcbTraceIds)
 const body=direct.find(t=>t.pcb_trace_id===binding.actualCarrierPcbTraceId)!
 assert(body&&body.route.every((p:Record<string,any>)=>p.route_type==="wire"&&p.layer===binding.carrierLayer&&p.width===.1016))
 const record=static24.records.find((r:Record<string,any>)=>r.sourceTraceId===binding.originalSourceTraceId)!
 assert(record&&record.layer===binding.carrierLayer&&record.path.length===body.route.length)
 const delta=Math.max(...record.path.map((p:Record<string,any>,i:number)=>Math.hypot(p.x-body.route[i].x,p.y-body.route[i].y)))
 assert(delta<1e-9)
 let coupledSection=record.coupledSection
 const pair=updatedPairs.candidates[binding.originalSourceTraceId]
 if(pair){
  assert.equal(pair.layer,binding.carrierLayer);assert.equal(pair.path.length,body.route.length)
  assert(pair.path.every((p:Record<string,any>,i:number)=>Math.hypot(p.x-body.route[i].x,p.y-body.route[i].y)<1e-9),"Coupled-section evidence must cover the complete authentic NEW physical carrier")
  coupledSection=pair.coupledSection
  assert(Array.isArray(coupledSection)&&coupledSection.length===2&&coupledSection.every(Number.isInteger)&&coupledSection[0]>=0&&coupledSection[0]<coupledSection[1]&&coupledSection[1]<body.route.length)
 }
 projections.push({originalSourceTraceId:binding.originalSourceTraceId,actualCarrierPcbTraceId:body.pcb_trace_id,actualDirectPcbTraceIds:binding.actualDirectPcbTraceIds,maximumCoordinateDeltaMm:delta,carrierLayer:binding.carrierLayer,coupledSection:coupledSection??null})
 return {...body,connection_name:binding.originalSourceTraceId,coupledSection} as Trace
})
// Geometry view names remain original49. Only endpoint layer/ID anchors for the
// actually completed24 are derived from their genuine fresh physical aliases.
const byName=new Map(bindings.map((b:Record<string,any>)=>[b.originalSourceTraceId,b]))
const apiInput:SimpleRouteJson={...input,connections:input.connections.map(c=>{
 const b=byName.get(c.name) as Record<string,any>|undefined;if(!b)return c
 const ids=[b.actualCpuCarrierLayerPcbPortId,b.actualRamCarrierLayerPcbPortId]
 return {...c,pointsToConnect:c.pointsToConnect.map((p,i)=>{
  const actualPort=core.find(r=>r.type==="pcb_port"&&r.pcb_port_id===ids[i])!
  assert(actualPort&&actualPort.layers.includes(b.carrierLayer),"Authentic physical carrier alias required")
  return {...p,x:actualPort.x,y:actualPort.y,layer:b.carrierLayer,pointId:actualPort.pcb_port_id,pcb_port_id:actualPort.pcb_port_id}
 })}
})}
const dataSignature=JSON.stringify({input,apiInput,static24,updatedPairs,traces})
// Load unchanged private implementations only after all actual Root/data bindings pass.
const {VectorScene, routeCopper, fixedCopper}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/vector-scene")
const {tuningPathIsSelfClear}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/length-tuning")
const {sharedPairSpacingReports}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/shared-pair-spacing")
const {exteriorPairSpacingReports}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/exterior-pair-spacing")
const {pairCouplingReports}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/pair-coupling")
const {pairLengthReports, busLengthReports, fixedRouteLength}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/route-lengths")
const {routeAnglesAreConventional}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/route-angle-validation")
const fixed=fixedCopper(apiInput)
const continuity=traces.map(t=>{
 const c=apiInput.connections.find(c=>c.name===t.connection_name)!,b=byName.get(t.connection_name!) as Record<string,any>
 assert(c&&b.actualSourceOwnedPhysicalGraph.physicallyConnected)
 assert(Math.hypot(t.route[0].x-c.pointsToConnect[0].x,t.route[0].y-c.pointsToConnect[0].y)<1e-9)
 assert(Math.hypot(t.route.at(-1)!.x-c.pointsToConnect[1].x,t.route.at(-1)!.y-c.pointsToConnect[1].y)<1e-9)
 const others=traces.filter(other=>other!==t).flatMap(routeCopper)
 const scene=new VectorScene(apiInput,c,.1016,[...fixed,...others])
 return {connectionName:t.connection_name,actualCarrierPcbTraceId:t.pcb_trace_id,pathVisible:scene.pathVisible(t.route),segmentsVisible:t.route.slice(1).map((p,i)=>scene.visible(t.route[i],p)),selfClear:tuningPathIsSelfClear(t.route,.2032),conventionalAngles:routeAnglesAreConventional([t]),fixedPlanarLength:fixedRouteLength(apiInput,t.connection_name!),foreignActual24AndOriginalFixedCopperIncluded:true}
})
const shared=sharedPairSpacingReports(apiInput,traces),exterior=exteriorPairSpacingReports(apiInput,traces),coupling=pairCouplingReports(apiInput,traces),pairLengths=pairLengthReports(apiInput,traces)
assert.equal(shared.length,3);assert.equal(exterior.length,3);assert.equal(coupling.length,3);assert.equal(pairLengths.length,3)
// The pinned Trace type supports one contiguous coupledSection. Both real
// shared meanders are evaluated; geometry stays identical between metadata views.
const primaryName=proposal.primaryCoupledSectionView,secondaryName=proposal.secondaryCoupledSectionView
assert.equal(primaryName,"lower_coupled_U");assert.equal(secondaryName,"early_reflected_meander")
assert.equal(proposal.singleCoupledSectionCoversBoth,false)
assert.equal(proposal.bothActualSharedMeandersMustBeChecked,true)
const views=proposal.dqs1CouplingViews
assert.equal(views.length,2)
const secondaryView=views.find((v:Record<string,any>)=>v.name===secondaryName)!
assert(secondaryView)
const secondaryTraces:Trace[]=traces.map(t=>{
 const range=secondaryView.ranges[t.connection_name!]
 if(!range)return t
 assert(["source_trace_27","source_trace_28"].includes(t.connection_name!))
 assert(Array.isArray(range)&&range.length===2&&range.every(Number.isInteger)&&range[0]>=0&&range[0]<range[1]&&range[1]<t.route.length)
 return {...t,coupledSection:[...range] as [number,number]}
})
const strip=(t:Trace)=>{const {coupledSection,...rest}=t;return rest}
assert.deepEqual(secondaryTraces.map(strip),traces.map(strip),"Metadata view cannot alter copper or endpoints")
const dqs1Pairs=apiInput.differentialPairs!.filter(p=>p.connectionNames.includes("source_trace_27")&&p.connectionNames.includes("source_trace_28"))
assert.equal(dqs1Pairs.length,1)
const secondaryInput={...apiInput,differentialPairs:dqs1Pairs}
const secondarySignature=JSON.stringify({secondaryInput,secondaryTraces})
const secondaryShared=sharedPairSpacingReports(secondaryInput,secondaryTraces),secondaryExterior=exteriorPairSpacingReports(secondaryInput,secondaryTraces),secondaryCoupling=pairCouplingReports(secondaryInput,secondaryTraces)
assert.equal(secondaryShared.length,1);assert.equal(secondaryExterior.length,1);assert.equal(secondaryCoupling.length,1)
const secondViewPassed=secondaryShared.every(r=>r.matched)&&secondaryExterior.every(r=>r.matched)&&secondaryCoupling.every(r=>r.matched)
const originalAll49BusReports=busLengthReports(apiInput,traces)
const completedNames=new Set(traces.map(t=>t.connection_name))
const cohortViews=apiInput.buses!.filter(b=>b.busId!=="DDR_RESET").map(b=>({...b,connectionNames:b.connectionNames.filter(n=>completedNames.has(n))}))
const loadedCohortBusReports=busLengthReports({...apiInput,buses:cohortViews},traces)
const byte1=loadedCohortBusReports.find(b=>b.busId==="DDR_BYTE1")!
assert.equal(byte1.lengths.length,11)
const held=signature===JSON.stringify(core)&&dataSignature===JSON.stringify({input,apiInput,static24,updatedPairs,traces})&&secondarySignature===JSON.stringify({secondaryInput,secondaryTraces})
const report={scope:"ACTUAL_MOVED24_FRESH_CORE_ALL3_UNCHANGED_ORIGINAL_PRIVATE_API_DIAGNOSTIC",packetSha256:manifestSha,actualCorePath:artifacts.actualCorePath,actualCoreSha256:artifacts.actualCoreSha256,actualNativeReportPath:nativePath,actualNativeReportSha256:digest(fs.readFileSync(nativePath)),actualCarrierProjections:projections,updatedAuthenticPairEvidence:{path:manifest.source24ProposalPath,sha256:manifest.source24ProposalSha256,field:"selected24OriginalCarriers[].coupledSection",bothRealDqs1CoupledViews:views},stale21316IndicesOr068fSource28GeometryUsed:false,actualNumericPhysicalGraphsRequired:true,actualClockGeometryUsed:true,originalPrivateContinuousApiImplementationsUnchanged:true,automaticCoreSrjUsed:false,original49Input:{path:manifest.authorized49InputPath,sha256:manifest.authorized49InputSha256},completeHardwareSignalsRequested:49,actualCompleteOriginalSignalCount:24,expectedMissingOriginalSignalCount:25,fresh49ProjectionProof:{path:manifest.fresh49ProjectionProofPath,sha256:manifest.fresh49ProjectionProofSha256,actualCoreSha256:projectionProof.actualCoreSha256},fullOriginalBusRostersAndConstraintsHeld:true,originalFullDifferentialPairArrayUnchanged:true,all3DifferentialPairsInvokedAgainstFreshCopper:true,actualLayerAndEndpointIdViewDerivedFromFreshPhysicalOwnedAliases:true,rawCoreOrAuthoritativeInputRetagged:false,exactMaterialHeld:held,continuity,shared,exterior,coupling,pairLengths,secondaryDqs1View:{name:secondaryName,geometryAndEndpointsUnchanged:true,shared:secondaryShared,exterior:secondaryExterior,coupling:secondaryCoupling,passed:secondViewPassed},checkInventory:{continuityRows:24,primaryBooleanPredicates:24*4+3*4,secondaryDqs1BooleanPredicates:3,primaryPlusSecondaryBooleanPredicates:24*4+3*4+3,loadedCohortBusGatesAdditional:3,immutableDataGateAdditional:1},originalAll49BusReports,loadedCohortBusReports,loadedCohortViews:cohortViews,loadedCohortsExplicitlyPartial:{DDR_BYTE0:5,DDR_BYTE1:11,DDR_COMMAND_CLOCK:8},onlyByte1FullElevenPresent:true,originalFullByte0AndCaStillIncomplete:true,nativeManufacturingCheckerExecuted:false,coreRenderedByThisWorker:false,freshCadExecuted:false,originalGridOrPublicSolverExecuted:false,fullCohortTimingPassed:false,electricalDelayModelQualified:false,referenceQualified:false,complete24Accepted:false,accepted49:false,fabricationReady:false,allOriginalApiLoaded24ChecksPassed:held&&secondViewPassed&&continuity.every(r=>r.pathVisible&&r.segmentsVisible.every(Boolean)&&r.selfClear&&r.conventionalAngles)&&shared.every(r=>r.matched)&&exterior.every(r=>r.matched)&&coupling.every(r=>r.matched)&&pairLengths.every(r=>r.matched)&&loadedCohortBusReports.every(r=>r.aboveMinimumLength&&r.withinLengthLimit&&r.matched)}
fs.writeFileSync(outputPath,`${JSON.stringify(report,null,2)}\n`,{flag:"wx",mode:0o600})
assert.equal(report.allOriginalApiLoaded24ChecksPassed,true,"Complete actual diagnostics retained before assertion; never relax a failed original API")
console.log(JSON.stringify({scope:report.scope,allOriginalApiLoaded24ChecksPassed:true,expectedMissingOriginalSignalCount:25,accepted49:false,outputPath}))

} catch(error) {
 if(!fs.existsSync(outputPath))fs.writeFileSync(outputPath,JSON.stringify({scope:"UNRESOLVED_MOVED24_ORIGINAL_API_PRECONDITION_OR_PROJECTION",passed:false,failure:String(error),actualRawCoreOrInputEdited:false,rawAndFailureDiagnosticPreserved:true,accepted49:false,referenceQualified:false,electricalTimingQualified:false,fabricationReady:false},null,2)+"\n",{flag:"wx",mode:0o600})
 throw error
}
