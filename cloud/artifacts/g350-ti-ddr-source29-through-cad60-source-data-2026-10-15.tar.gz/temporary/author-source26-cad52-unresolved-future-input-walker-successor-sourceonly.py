from pathlib import Path
import json, hashlib, stat, difflib, ast, copy
OLD=Path('/tmp/g350-source26-cad52-actual51-flat-wrapper-root-guard-sourceonly-next')
NEW=Path('/tmp/g350-source26-cad52-future-metadata-walker-successor-sourceonly-next')
assert not NEW.exists() or not list(NEW.iterdir())
NEW.mkdir(mode=0o700,exist_ok=True)
def pin(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
 return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def write(p,data):
 with p.open('xb') as f:f.write(data)
 p.chmod(0o600)
def write_json(p,data):write(p,(json.dumps(data,indent=2)+'\n').encode())
manifest=json.loads((OLD/'SOURCE-manifest.json').read_text())
expected=[{'field':'newCadAuthority','path':'/tmp/g350-source26-cad-root-20261015-after51/ROOT_CAD_AUTHORITY.json','sha256':None,'bytes':None,'mode':None,'RootCreatesAfterReview':True},{'field':'actualSourceZonePins','path':'/tmp/g350-source26-cad-root-20261015-after51/SOURCE_ZONE_PINS.json','sha256':None,'bytes':None,'mode':None,'RootDerivesAfterReview':True}]
source=(OLD/'run-source26-cad52-root.proposal.py').read_text()
needle=' no_git_redirects()\n def bindings():\n'
assert source.count(needle)==1
block=' # Exactly two future metadata records are not concrete inputs; the whole copy document remains pinned.\n assert cad26_copies[\'unresolvedFutureRows\']=='+repr(expected)+'\n cad26_concrete_copies={k:v for k,v in cad26_copies.items()if k!=\'unresolvedFutureRows\'}\n'
changed=source.replace(needle,' no_git_redirects()\n'+block+' def bindings():\n')
needle2='cad26_contract,cad26_wrapper,cad26_copies,read(gm['
assert changed.count(needle2)==1
changed=changed.replace(needle2,'cad26_contract,cad26_wrapper,cad26_concrete_copies,read(gm[')
assert changed.replace(block,'').replace('cad26_contract,cad26_wrapper,cad26_concrete_copies,read(gm[',needle2)==source
ast.parse(changed)
for row in manifest['files']:
 p=Path(row['path']);assert p.parent==OLD and pin(p)==row
 write(NEW/p.name, changed.encode() if p.name=='run-source26-cad52-root.proposal.py' else p.read_bytes())
def remap(v):
 if isinstance(v,dict):
  if all(k in v for k in ('path','sha256','bytes','mode')) and Path(v['path']).parent==OLD:
   result=copy.deepcopy(v);result.update(pin(NEW/Path(v['path']).name));return result
  return {k:remap(x)for k,x in v.items()}
 if isinstance(v,list):return [remap(x)for x in v]
 return v
m=remap(manifest)
patch=''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='56fd-reviewed-parent/run-source26-cad52-root.proposal.py',tofile='new-sourceonly/run-source26-cad52-root.proposal.py'))
write(NEW/'EXACT_UNRESOLVED_FUTURE_METADATA_WALKER_DELTA.patch',patch.encode())
copy_pin=manifest['cad26SnapshotCopyInputsPin'];assert pin(copy_pin['path'])==copy_pin
copy_input=json.loads(Path(copy_pin['path']).read_text());assert copy_input['unresolvedFutureRows']==expected
# Pure Source/data controls, never evaluating the guard or any supplied helper.
def walk(v):
 if isinstance(v,dict):
  if all(k in v for k in ('path','sha256','bytes','mode')):yield v
  else:
   for x in v.values():yield from walk(x)
 elif isinstance(v,list):
  for x in v:yield from walk(x)
def concrete(doc):
 assert doc['unresolvedFutureRows']==expected
 return {k:v for k,v in doc.items()if k!='unresolvedFutureRows'}
prior=list(walk(copy_input));after=list(walk(concrete(copy_input)))
assert len(prior)==70 and len(after)==68
assert [r for r in prior if r not in expected]==after
assert len(copy_input['snapshots'])==48
for row in after:assert pin(row['path'])=={k:row[k]for k in('path','sha256','bytes','mode')}
refusals=[]
for label,change in [('missing',lambda d:d.pop('unresolvedFutureRows')),('one-row',lambda d:d['unresolvedFutureRows'].pop()),('wrong-path',lambda d:d['unresolvedFutureRows'][0].__setitem__('path','/tmp/other.json')),('nonnull-hash',lambda d:d['unresolvedFutureRows'][1].__setitem__('sha256','0'*64)),('extra-row',lambda d:d['unresolvedFutureRows'].append(dict(d['unresolvedFutureRows'][0]))),('unexpected-field',lambda d:d['unresolvedFutureRows'][0].__setitem__('extra',True))]:
 d=copy.deepcopy(copy_input);change(d)
 try:concrete(d)
 except (AssertionError,KeyError):refusals.append(label)
 else:raise AssertionError(label)
receipt=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress/source26-cad-26079-SOURCE-PREFLIGHT-REFUSAL-NO-SDK-COLLECTED-root.json')
r=json.loads(receipt.read_text());assert r['toolSessionId']==26079 and r['toolSessionCollected']is True and r['toolWrapperExitCode']==1 and r['sourceManifestSha256']==pin(OLD/'SOURCE-manifest.json')['sha256']
assert r['sdkOrOperationalHelperImported']is False and r['ownedChildrenSpawned']==0 and r['postauditProduced']is False and r['unresolvedFutureRows']==expected and r['actualClosedSdkScopeCountRemains']==51
proof=dict(scope='SOURCE_ONLY_EXACT_FUTURE_METADATA_EXCLUSION_AND_INPUT_BINDING_PROOF',parentManifestPin=pin(OLD/'SOURCE-manifest.json'),parentGuardPin=pin(OLD/'run-source26-cad52-root.proposal.py'),copyInputPin=copy_pin,actualPreflightRefusalPin=pin(receipt),guardDeltaPin=pin(NEW/'EXACT_UNRESOLVED_FUTURE_METADATA_WALKER_DELTA.patch'),oldRowOccurrences=70,newConcreteRowOccurrences=68,excludedRowsExactly=expected,allOtherRowOccurrencesByteEquivalent=True,all48SnapshotOriginalRowsRetainedAndPinned=True,sourceInverseExact=True,guardAstParsed=True,ownPureStdlibNegativeControls=refusals,ownPureStdlibPositiveControlsPassed=True,operationalCodeImportedOrExecuted=False,SDKOrAppOrProcessInvoked=False,workspaceWrites=False,plannedFirstActualSdkScope=52,actualClosedSdkScopeCount=51,Source26Accepted=False,fabricationReady=False)
write_json(NEW/'SOURCE_ONLY_WALKER_PROOF.json',proof)
m.update(scope='SOURCE_ONLY_SOURCE26_CAD52_TWO_EXACT_UNRESOLVED_METADATA_ROWS_WALKER_SUCCESSOR',status='AUTHOR_DONE_SOURCE_ONLY_UNEXECUTED_REQUIRES_ROOT_AND_INDEPENDENT_PEER',historicalCad52ConcreteInputWalkerManifestPin=pin(OLD/'SOURCE-manifest.json'),historicalCad52ConcreteInputWalkerGuardPin=pin(OLD/'run-source26-cad52-root.proposal.py'),historicalCad52CombinedPeerPin=pin('/tmp/g350-source26-cad52-independent-combined-source-peer.json'),actual26079SourcePreflightRefusalPin=pin(receipt),exactUnresolvedMetadataRows=expected,onlyUnresolvedFutureRowsExcludedFromConcreteCopyInputWalking=True,copyInputWholeFileSha256StillRequired=copy_pin['sha256'],sourcePreflightRefusalDoesNotIncrementSdkScope=True,actualClosedSdkScopeCountRemains=51,plannedFirstActualSdkScopeRemains=52)
m['files']=[pin(p)for p in sorted(NEW.iterdir())if p.is_file()]
extra=[pin(OLD/'SOURCE-manifest.json'),pin(OLD/'run-source26-cad52-root.proposal.py'),pin('/tmp/g350-source26-cad52-independent-combined-source-peer.json'),pin(receipt),pin(Path(__file__))]
by={p['path']:p for p in m['externalFiles']}
for p in extra:
 assert p['path']not in by or by[p['path']]==p
 by[p['path']]=p
m['externalFiles']=list(by.values());m['ownFileCountExcludingManifest']=len(m['files']);m['externalFileCount']=len(m['externalFiles'])
write_json(NEW/'SOURCE-manifest.json',m)
print(json.dumps(dict(manifest=pin(NEW/'SOURCE-manifest.json'),guard=pin(NEW/'run-source26-cad52-root.proposal.py'),delta=pin(NEW/'EXACT_UNRESOLVED_FUTURE_METADATA_WALKER_DELTA.patch'),proof=pin(NEW/'SOURCE_ONLY_WALKER_PROOF.json'),own=len(m['files']),external=len(m['externalFiles'])),indent=2))
