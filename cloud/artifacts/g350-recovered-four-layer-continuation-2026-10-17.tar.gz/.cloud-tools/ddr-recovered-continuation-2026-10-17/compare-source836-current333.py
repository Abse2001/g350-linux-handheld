#!/usr/bin/env python3
"""Read-only literal copper comparison. No SDK, CAD, or checker imports."""
import collections
import hashlib
import json
import math
from pathlib import Path
import resource
import signal

resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
resource.setrlimit(resource.RLIMIT_CPU, (55, 55))
signal.alarm(58)
ROOT = Path('/workspace/g350-linux-handheld')
OLD = ROOT / 'dist/g350-ddr-ground-preserving-clean-corners-source-836/compiled.circuit.json'
NOW = Path('/tmp/g350-both-bytes-ca18-model328-core333-raw.json')
PLAN = Path('/tmp/g350-four-body-ca18-strong-self-root-20261017-run328/byte0-result.candidate.json')
SUMMARY = ROOT / 'checks/integrated/g350-clean-corners-forward-progress/summary.json'
OUT = ROOT / '.cloud-tools/recovery-2026-10-17/source836-current333-planar-comparison.json'
LAYERS = ['top', 'inner1', 'inner2', 'bottom']

def load(path):
    data = path.read_bytes()
    return json.loads(data), {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def analyze(rows):
    bytype = collections.defaultdict(list)
    for row in rows:
        bytype[row['type']].append(row)
    src = {r['source_trace_id']:r for r in bytype['source_trace']}
    ports = {r['source_port_id']:r for r in bytype['source_port']}
    components = {r['source_component_id']:r for r in bytype['source_component']}
    pcbports = {r['source_port_id']:r for r in bytype['pcb_port']}
    traces = collections.defaultdict(list)
    vias = collections.defaultdict(list)
    for t in bytype['pcb_trace']:
        owner = t.get('source_trace_id', t.get('connection_name'))
        traces[owner].append(t)
    owners_by_pcbport = collections.defaultdict(set)
    for owner, owned in traces.items():
        if owner not in {f'source_trace_{i}' for i in range(49)}:
            continue
        for t in owned:
            for p in t['route']:
                for field in ['start_pcb_port_id','end_pcb_port_id']:
                    if p.get(field):
                        owners_by_pcbport[p[field]].add(owner)
    netkeys = {src[f'source_trace_{i}']['subcircuit_connectivity_map_key']:f'source_trace_{i}' for i in range(49)}
    for v in bytype['pcb_via']:
        owner = netkeys.get(v.get('subcircuit_connectivity_map_key'))
        explicit_owners = set().union(*(owners_by_pcbport[p] for p in v.get('pcb_port_ids',[])))
        if explicit_owners:
            assert len(explicit_owners)==1, (v,explicit_owners)
            explicit_owner = next(iter(explicit_owners))
            assert owner in [None,explicit_owner], (owner,explicit_owner,v)
            owner = explicit_owner
        if owner:
            vias[owner].append(v)
    signals = {}
    irregular = []
    for i in range(49):
        owner = f'source_trace_{i}'
        lengths = collections.Counter()
        counts = collections.Counter()
        routevia = []
        for t in traces[owner]:
            route = t['route']
            routevia.extend(p for p in route if p.get('route_type') == 'via')
            for a, b in zip(route, route[1:]):
                d = math.hypot(b['x']-a['x'],b['y']-a['y'])
                if a.get('route_type') == b.get('route_type') == 'wire' and a.get('layer') == b.get('layer'):
                    if d > 1e-12:
                        lengths[a['layer']] += d
                        counts[a['layer']] += 1
                elif d > 1e-9:
                    irregular.append({'owner':owner,'pcb_trace_id':t['pcb_trace_id'],'a':a,'b':b,'xyGapMm':d})
        endpoints = []
        for sid in src[owner]['connected_source_port_ids']:
            sp = ports[sid]
            pp = pcbports[sid]
            endpoints.append({'source_port_id':sid,'component':components[sp['source_component_id']]['name'],
                              'pin_number':sp.get('pin_number'),'name':sp.get('name'),
                              'port_hints':sp.get('port_hints'), 'x':pp['x'],'y':pp['y'],'layers':pp['layers']})
        signals[owner] = {'name':src[owner]['name'],'literalPlanarLengthMm':sum(lengths.values()),
                          'layerPlanarLengthMm':dict(lengths),'nonzeroWireSegmentsByLayer':dict(counts),
                          'pcbTracePieces':len(traces[owner]),'routeViaTokens':len(routevia),
                          'actualFullspanViaCount':len(vias[owner]),
                          'vias':[{'id':v['pcb_via_id'],'x':v['x'],'y':v['y'],'layers':v['layers'],
                                   'hole_diameter':v['hole_diameter'],'outer_diameter':v['outer_diameter'],
                                   'requested_from_layer':v.get('from_layer'),'requested_to_layer':v.get('to_layer')}
                                  for v in vias[owner]],'numericEndpoints':endpoints}
        points=[p for t in traces[owner] for p in t['route']]
        signals[owner]['routeXyBounds'] = {'minX':min(p['x'] for p in points),'maxX':max(p['x'] for p in points),
                                           'minY':min(p['y'] for p in points),'maxY':max(p['y'] for p in points)}
    groups = {}
    for bus in bytype['source_bus']:
        if not bus['name'].startswith('DDR_'):
            continue
        members = bus['source_trace_ids']
        values = {sid:signals[sid]['literalPlanarLengthMm'] for sid in members}
        modeled = {sid:signals[sid]['literalPlanarLengthMm'] + 1.6*signals[sid]['routeViaTokens'] for sid in members}
        groups[bus['name']] = {'members':members,'literalPlanarLengthMm':values,
                               'literalPlanarSkewMm':max(values.values())-min(values.values()),
                               'limitMm':bus.get('max_length_skew'),
                               'literalPlanarPass':None if 'max_length_skew' not in bus else max(values.values())-min(values.values()) <= bus['max_length_skew']+1e-9,
                               'historicalToken1p6ModelSkewMm':max(modeled.values())-min(modeled.values()),
                               'routeViaTokenCounts':{sid:signals[sid]['routeViaTokens'] for sid in members}}
    layerstats = {}
    for layer in LAYERS:
        owners = [sid for sid,s in signals.items() if s['layerPlanarLengthMm'].get(layer,0)>1e-12]
        layerstats[layer] = {'ownerCount':len(owners),'owners':owners,
                             'nonzeroWireSegmentCount':sum(s['nonzeroWireSegmentsByLayer'].get(layer,0) for s in signals.values()),
                             'literalPlanarLengthMm':sum(s['layerPlanarLengthMm'].get(layer,0) for s in signals.values())}
    realpcbs = {components[p['source_component_id']]['name']:p for p in bytype['pcb_component'] if p.get('source_component_id') in components}
    identity = {r['name']:{k:r.get(k) for k in ['ftype','manufacturer_part_number','supplier_part_numbers']} for r in components.values()}
    pose = {name:{k:p.get(k) for k in ['center','rotation','layer']} for name,p in realpcbs.items()}
    board=bytype['pcb_board'][0]
    return {'signals':signals,'groups':groups,'ddrLayerStats':layerstats,'identity':identity,'placements':pose,
            'counts':dict(collections.Counter(r['type'] for r in rows)), 'nonzeroIrregularAdjacentRouteGaps':irregular,
            'actualDdrViaCount':sum(len(v) for v in vias.values()),
            'boardThicknessMm':board['thickness'],
            'sumFullDepthDdrBarrelSpansMm':board['thickness']*sum(len(v) for v in vias.values()),
            'allDdrViasHaveFourPhysicalLayers':all(v['layers']==LAYERS for vs in vias.values() for v in vs),
            'allDdrViasUseStandardDimensions':all(v['hole_diameter']==.254 and v['outer_diameter']==.4572 for vs in vias.values() for v in vs)}

oldrows, oldinfo = load(OLD)
assert oldinfo['sha256'] == 'c30da726262185a29e5a7c05009a97553ae454147c81a4d2f4c6d0632298d936'
nowrows, nowinfo = load(NOW)
plan, planinfo = load(PLAN)
summary, summaryinfo = load(SUMMARY)
old, now = analyze(oldrows), analyze(nowrows)
rules = plan['full49FanoutInput']['buses']
for result in [old,now]:
    result['comparisonToCurrentPlanAbsoluteLengthRules'] = []
    for rule in rules:
        values = {s:result['signals'][s]['literalPlanarLengthMm'] for s in rule['connectionNames']}
        below = [{'owner':s,'mm':v} for s,v in values.items() if 'minLength' in rule and v < rule['minLength']-1e-9]
        above = [{'owner':s,'mm':v} for s,v in values.items() if 'maxLength' in rule and v > rule['maxLength']+1e-9]
        result['comparisonToCurrentPlanAbsoluteLengthRules'].append({'busId':rule['busId'],'minLengthMm':rule.get('minLength'),
                                                                    'maxLengthMm':rule.get('maxLength'),'belowMin':below,'aboveMax':above})

posechanges = {name:{'source836':old['placements'][name],'source333':now['placements'][name]}
               for name in old['placements'] if old['placements'][name]!=now['placements'].get(name)}
identitychanges = {name:{'source836':v,'source333':now['identity'].get(name)} for name,v in old['identity'].items() if v!=now['identity'].get(name)}
endpointchanges = []
for sid in old['signals']:
    a,b=old['signals'][sid]['numericEndpoints'],now['signals'][sid]['numericEndpoints']
    if a!=b:
        endpointchanges.append({'owner':sid,'source836':a,'source333':b})
logicalidentitiesequal = all([{k:p[k] for k in ['component','pin_number','name','port_hints']} for p in old['signals'][sid]['numericEndpoints']]
                           == [{k:p[k] for k in ['component','pin_number','name','port_hints']} for p in now['signals'][sid]['numericEndpoints']]
                           for sid in old['signals'])
report = {'kind':'READ_ONLY_LITERAL_PLANAR_COMPARISON_NOT_ROUTING_OR_QUALIFICATION',
          'inputs':{'source836':oldinfo,'source333':nowinfo,'currentPlan':planinfo,'historicalSource836Summary':summaryinfo},
          'measurement':'Sum positive Euclidean distances between adjacent same-layer wire tokens for all physical trace pieces carrying each of the original 49 source_trace IDs. Vias add zero planar length. Actual via ownership comes from original connectivity keys, or explicit via pcb_port_ids shared with owned trace endpoints; no coordinate proximity inference.',
          'historicalModelCaution':'Historical route-token model adds 1.6 mm per via token. Current333 explicit physical via components split wire pieces and have no route via tokens; modeled columns are not comparable between representations and are not electrical delay.',
          'viaSpanCaution':'All enumerated DDR via records are standard full-depth through barrels on a 1.6 mm board. Sum of full-depth barrel spans describes manufactured copper, not traversed electrical length or delay. Generic current333 from_layer/top and to_layer/bottom fields describe physical full-depth helpers; they do not identify actual connected signal layer traversal.',
          'qualificationCaution':'No connectivity, clearance, SI, CAD, native checks or editable replay executed. Source836 archived full-board qualification is historical. No fallback promotion.',
          'currentBoundCaution':'11.8/14.2/20.95–22.29 mm rules are read from current Model328 plan. Source836 compiled buses contain skew rules but no absolute length bounds. Comparing Source836 to current bounds is counterfactual, not a retrospective native violation claim.',
          'topologyStudyRecommendation':{
              'fallbackCanBeDirectlyPromoted':False,
              'whyNot':'All three literal planar groups fail 0.635 mm, every bounded data/CA signal exceeds current absolute maximum, and 23 real placements differ. Historical DRC pass does not qualify changed placements/copper.',
              'potentialTransferableStrategy':'Use alternate owned CPU dogbone quadrants and multiple layer changes to reach outside-package aisles, then perform bounded real length tuning; do not transplant historical coordinates or full 41–51 mm paths.',
              'historicallyClearCpuEgressExamplesNotCurrentPreflighted':[
                  {'owner':'source_trace_7','numericCpuPin':39,'source836DogboneMm':[-5.6,14.4],'currentDogboneMm':[-4.8,14.4]},
                  {'owner':'source_trace_9','numericCpuPin':23,'source836DogboneMm':[-4,13.6],'currentDogboneMm':[-3.2,13.6]},
                  {'owner':'source_trace_20','numericCpuPin':20,'source836DogboneMm':[-6.4,13.6],'currentDogboneMm':[-5.6,13.6]},
                  {'owner':'source_trace_22','numericCpuPin':42,'source836DogboneMm':[-3.2,14.4],'currentDogboneMm':[-2.4,14.4]}],
              'requiredBeforeAdoption':'Retire/replace only the real owned barrel and branch with explicit inverse; retain numeric pads, all full-depth barrel dimensions, original reference identities and untouched copper. Jointly preflight all foreign pads/barrels/traces/holes on four layers, complete all49, check unchanged current absolute/skew limits, regenerate pours, editable-source replay, native and independent CAD/SI checks.',
              'currentViabilityProvenByThisComparison':False},
          'historicalSource836SummarySelected':{k:summary[k] for k in ['status','buildExitCode','connectedDdrSignals','parts','numLayers','ramRotationDegrees','standardThroughVias','kicadErrors','kicadWarnings','kicadUnconnectedItems','danglingTracks','danglingVias','ignoredKiCadRules','kiCadExclusions','allLayerGerberShorts']},
          'source836':old,'source333':now,
          'comparison':{'all280ComponentIdentitiesEqual':not identitychanges and len(old['identity'])==len(now['identity'])==280,
                        'identityChanges':identitychanges,'realComponentPlacementChanges':posechanges,
                        'all49NumericEndpointIdentitiesEqual':logicalidentitiesequal,
                        'numericEndpointsWithAnyChangedCoordinateOrMetadata':endpointchanges},
          'fabricationReady':False}
OUT.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'out':str(OUT),'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),
                  'oldGroups':{k:v['literalPlanarSkewMm'] for k,v in old['groups'].items()},
                  'nowGroups':{k:v['literalPlanarSkewMm'] for k,v in now['groups'].items()},
                  'oldDdrViaCount':old['actualDdrViaCount'],'nowDdrViaCount':now['actualDdrViaCount'],
                  'identityEqual':report['comparison']['all280ComponentIdentitiesEqual'],
                  'placementChanges':len(posechanges),'endpointIdentitiesEqual':logicalidentitiesequal,
                  'irregularOld':len(old['nonzeroIrregularAdjacentRouteGaps']),'irregularNow':len(now['nonzeroIrregularAdjacentRouteGaps'])},indent=2))
