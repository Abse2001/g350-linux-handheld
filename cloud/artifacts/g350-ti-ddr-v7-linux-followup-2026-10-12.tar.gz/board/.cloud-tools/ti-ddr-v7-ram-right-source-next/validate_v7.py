"""Exact fresh V7 rigid physical delta qualification; pure validation, never routing."""
import copy,math
from validate_layout import GEOMETRY,LOGIC,by_id,equivalent,expected_geometry,typed
from validate_v6 import validate as validate_v6,placement_metrics,courtyard_box
MOVED=('U_RAM',*(f'C_DDR_RAM_{i}' for i in range(1,13)),'C_DDR_RAM_BULK1','C_DDR_RAM_BULK2','C_VREF_RAM_CA','C_VREF_RAM_DQ','R_DDR_ZQ')
DX=1.2

def require(value,message):
 if not value:raise ValueError(message)

def names_and_components(circuit):
 src=by_id(circuit,'source_component');parts=by_id(circuit,'pcb_component')
 return {pid:src.get(e['source_component_id'],{}).get('name',e['source_component_id']) for pid,e in parts.items()},parts

def translated_routes(row,dx):
 result=copy.deepcopy(row)
 for p in result['route']:p['x']+=dx
 return result

def validate_delta(v6,compiled,poses):
 require(len(MOVED)==18 and set(poses['parts'])==set(MOVED),'Exact18 original moved parts required')
 require(set(poses['references'])=={'V_TI_RAM7_POWER','V_TI_RAM7_GROUND'},'Exactly two existing reference primitives')
 for kind in LOGIC:equivalent(typed(v6,kind),typed(compiled,kind),'unchangedLogical.'+kind)
 equivalent(typed(v6,'source_manually_placed_via'),typed(compiled,'source_manually_placed_via'),'unchangedManualViaLogic')
 old_names,old_parts=names_and_components(v6);_,new_parts=names_and_components(compiled)
 moved={pid for pid,name in old_names.items() if name in MOVED};via_ids={pid for pid,e in old_parts.items() if e['source_component_id'] in {'source_manually_placed_via_0','source_manually_placed_via_1'}}
 require(len(moved)==18 and len(via_ids)==2,'18 real parts plus2 original via alias components')
 all_moved=moved|via_ids;changed=[]
 for pid in moved:
  old=old_parts[pid];name=old_names[pid];target=poses['parts'][name]
  require(abs(target['pcbX']-old['center']['x']-DX)<1e-9 and target['pcbY']==old['center']['y'] and target['layer']==old['layer'] and target['pcbRotation']==old['rotation'],'Nonrigid declared part: '+name)
 for kind in GEOMETRY:
  before,after=by_id(v6,kind),by_id(compiled,kind);require(set(before)==set(after),'Geometry ID set changed: '+kind)
  for ident,row in before.items():
   owner=row.get('pcb_component_id')
   if owner in all_moved:
    old=old_parts[owner];pose={'pcbX':old['center']['x']+DX,'pcbY':old['center']['y'],'layer':old['layer'],'pcbRotation':old['rotation']};wanted=expected_geometry(row,old,pose)
   else:wanted=row
   equivalent(wanted,after[ident],'freshRigidDelta.'+ident)
   if row!=after[ident]:changed.append({'type':kind,'id':ident,'owner':owner,'originalPart':old_names.get(owner),'declaredRigidMovement':owner in all_moved})
 require(all(c['declaredRigidMovement'] for c in changed),'Unexpected geometry movement')
 equivalent(typed(v6,'pcb_board'),typed(compiled,'pcb_board'),'unchangedBoard')
 before_vias,after_vias=by_id(v6,'pcb_via'),by_id(compiled,'pcb_via');require(set(before_vias)==set(after_vias)=={'pcb_via_0','pcb_via_1'},'Exact original two barrels')
 for ident,row in before_vias.items():
  wanted={**row,'x':row['x']+DX};equivalent(wanted,after_vias[ident],'rigidReferenceVia.'+ident)
 before_traces,after_traces=by_id(v6,'pcb_trace'),by_id(compiled,'pcb_trace');require(set(before_traces)==set(after_traces)=={'pcb_trace_0','pcb_trace_1'},'Only original2 reference stubs')
 for ident,row in before_traces.items():equivalent(translated_routes(row,DX),after_traces[ident],'rigidReferenceTrace.'+ident)
 # This inverse is exclusively a validation view. No synthetic circuit output is
 # written or supplied to Core/source/native checks or any solver.
 normalized=copy.deepcopy(compiled)
 for index,row in enumerate(normalized):
  if row['type'] in GEOMETRY and row.get('pcb_component_id') in all_moved:
   pid=row['pcb_component_id'];new=new_parts[pid];old=old_parts[pid];pose={'pcbX':old['center']['x'],'pcbY':old['center']['y'],'layer':old['layer'],'pcbRotation':old['rotation']};normalized[index]=expected_geometry(row,new,pose)
  elif row['type']=='pcb_via':row['x']-=DX
  elif row['type']=='pcb_trace':normalized[index]=translated_routes(row,-DX)
 return normalized,changed

def courtyard_metrics(compiled):
 names,parts=names_and_components(compiled);courts=[e for e in compiled if e['type'].startswith('pcb_courtyard_')];rows=[]
 for own in courts:
  name=names[own['pcb_component_id']]
  if name not in MOVED:continue
  a=courtyard_box(own);gaps=[]
  for other in courts:
   if other['pcb_component_id']==own['pcb_component_id'] or other.get('layer')!=own.get('layer'):continue
   b=courtyard_box(other);gap=math.hypot(max(a[0]-b[1],b[0]-a[1],0),max(a[2]-b[3],b[2]-a[3],0));gaps.append((gap,names[other['pcb_component_id']]))
  require(gaps,'Other same-layer courtyard missing');gap,neighbor=min(gaps);require(gap>=.05-1e-9,'Moved part same-layer courtyard below.05: '+name);rows.append({'name':name,'gapMm':gap,'nearestPart':neighbor})
 require({e['name'] for e in rows}==set(MOVED),'All18 moved courtyards required')
 ram=next(e for e in courts if names[e['pcb_component_id']]=='U_RAM');cpu=next(e for e in courts if names[e['pcb_component_id']]=='U_SOC');a,b=courtyard_box(ram),courtyard_box(cpu);cpu_gap=math.hypot(max(a[0]-b[1],b[0]-a[1],0),max(a[2]-b[3],b[2]-a[3],0));require(abs(cpu_gap-.892964)<1e-7,'RAM/CPU courtyard gap changed')
 return {'requiredMarginMm':.05,'all18MovedPartMarginsQualified':True,'minimumGapMm':min(r['gapMm'] for r in rows),'rows':rows,'cpuRamCourtyardGapMm':cpu_gap}

def validate(base,v5,v6,compiled,poses,old_table,declarations):
 normalized,changes=validate_delta(v6,compiled,poses)
 original=validate_v6(base,v5,normalized,old_table,declarations)
 metrics=placement_metrics(compiled);courts=courtyard_metrics(compiled)
 require(len(typed(compiled,'source_component'))==280 and len(typed(compiled,'source_port'))==1165,'Original280parts/1161ports plus4existing reference aliases')
 return {'passed':True,'validationMethod':'Fresh compiled delta first, then inverse-translation-only validation view through unchanged V6 inventory/reference validator; normalized view never emitted or routed','priorV6InventoryValidation':original,'originalLogicalInventoryExact':True,'only18RealPartsAnd2ReferenceAliasComponentsTranslated':True,'unchangedCpuCpu13AndAllOtherParts':True,'rigidDeltaMm':{'x':DX,'y':0},'movedPartNames':list(MOVED),'changedGeometry':changes,'originalParts':280,'originalPhysicalContacts':1161,'existingReferenceAliasPorts':4,'fixedPhysicalReferences':2,'ddrSignals':49,'placementMetrics':metrics,'courtyardMetrics':courts,'signalRoutingPerformed':False,'accepted49':False,'fabricationReady':False}

def synthetic_control(v6):
 """For pure validator tests ONLY. Never an actual source, exported input or route."""
 result=copy.deepcopy(v6);names,parts=names_and_components(v6);moving={p for p,n in names.items() if n in MOVED or str(n).startswith('source_manually_placed_via_')}
 for i,row in enumerate(result):
  pid=row.get('pcb_component_id')
  if row['type'] in GEOMETRY and pid in moving:
   old=parts[pid];pose={'pcbX':old['center']['x']+DX,'pcbY':old['center']['y'],'layer':old['layer'],'pcbRotation':old['rotation']};result[i]=expected_geometry(row,old,pose)
  elif row['type']=='pcb_via':row['x']+=DX
  elif row['type']=='pcb_trace':result[i]=translated_routes(row,DX)
 return result
