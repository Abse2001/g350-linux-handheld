"""Pure Python stdlib power-reference geometry planning; not routing SDK execution."""
from pathlib import Path
import json,math,hashlib,copy,heapq,time
exec(Path('/tmp/g350-cap8-cpu-cycle-placement-screen-v2-sourceonly.py').read_text().split("if __name__")[0])
PP=pads(0,7.9,0)
for q in PP:q['radius']=max(q['width'],q['height'])/2;q['holeRadius']=0;q['owner']=q['id'];q['bbox']=bbox(q)
CELL=.25
class Query:
 def __init__(self,os,ownVia,ownPad):
  self.os=[o for o in os+PP if o['id'] not in {ownVia,ownPad}];self.buckets={};self.cache={}
  for k,o in enumerate(self.os):
   if o['kind']=='wire':r=.1+.1016
   elif o['kind']=='via' or o.get('shape')=='circle':r=.1+.2
   else:r=.1+.1016
   bb=o['bbox']
   for i in range(math.floor((bb[0]-r)/CELL),math.floor((bb[1]+r)/CELL)+1):
    for j in range(math.floor((bb[2]-r)/CELL),math.floor((bb[3]+r)/CELL)+1):
     for l in o['layers']:self.buckets.setdefault((i,j,l),set()).add(k)
 def contacts(self,a,b,l):
  ids=set()
  for i in range(math.floor(min(a['x'],b['x'])/CELL),math.floor(max(a['x'],b['x'])/CELL)+1):
   for j in range(math.floor(min(a['y'],b['y'])/CELL),math.floor(max(a['y'],b['y'])/CELL)+1):ids.update(self.buckets.get((i,j,l),set()))
  out=[]
  for k in ids:
   o=self.os[k]
   if o['kind']=='wire':d=sd(a,b,o['a'],o['b']);need=.1+o['radius']+.1016
   elif o['kind']=='via' or o.get('shape')=='circle':d=pd(o['p'],a,b);need=.1+max(o['radius']+.1016,o['holeRadius']+.2)
   else:d=srect(a,b,o);need=.1+.1016
   if d<need-1e-8:out.append(o)
  return out
 def legal(self,a,b,l):
  key=(l,a,b) if a<b else(l,b,a)
  if key not in self.cache:self.cache[key]=not self.contacts({'x':a[0],'y':a[1]},{'x':b[0],'y':b[1]},l)
  return self.cache[key]

def astar(start,end,layer,Q,step=.05,bounds=(-2.5,2.5,7,11.5),limit=150000):
 def asnode(q):return round(q[0]/step),round(q[1]/step)
 def xy(p):return (p[0]*step,p[1]*step)
 S=asnode(start);E=asnode(end);assert math.dist(start,xy(S))<1e-8 and math.dist(end,xy(E))<1e-8
 dirs=[(1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1)];opens=[(math.dist(start,end),0,S)];dist={S:0};prev={};count=0
 while opens and count<limit:
  _,cost,a=heapq.heappop(opens)
  if cost>dist[a]+1e-9:continue
  count+=1
  if a==E:
   path=[a]
   while path[-1] in prev:path.append(prev[path[-1]])
   path.reverse();pts=[xy(n) for n in path];simp=[pts[0]];lastdir=None
   for u,v in zip(pts,pts[1:]):
    d=(round((v[0]-u[0])/step),round((v[1]-u[1])/step))
    if lastdir is not None and d!=lastdir:simp.append(u)
    lastdir=d
   simp.append(pts[-1]);return {'found':True,'layer':layer,'path':simp,'lengthMm':cost,'states':count,'cache':len(Q.cache)}
  ax,ay=xy(a)
  for dx,dy in dirs:
   b=(a[0]+dx,a[1]+dy);bx,by=xy(b)
   if not(bounds[0]<=bx<=bounds[1] and bounds[2]<=by<=bounds[3]):continue
   nc=cost+step*math.hypot(dx,dy)
   if nc>=dist.get(b,1e99)-1e-9 or not Q.legal((ax,ay),(bx,by),layer):continue
   dist[b]=nc;prev[b]=a;heapq.heappush(opens,(nc+math.hypot(bx-end[0],by-end[1]),nc,b))
 return {'found':False,'layer':layer,'states':count,'cache':len(Q.cache)}
if __name__=='__main__':
 free=[];objects.extend(PP)
 for i in range(-150,-9,5):
  for j in range(740,871,5):
   q={'x':i/100,'y':j/100}
   if not vc(q):free.append(q)
 for q in PP:objects.remove(q)
 print('GNDfree',free,flush=True)
 results=[]
 for owner,start,end,ownvia,ownpad in [('VDD',(1.05,7.85),(1.2,11),'pcb_via_54','pcb_smtpad_730')]+[('GND',(v['x'],v['y']),(-1.2,10.2),'pcb_via_55','pcb_smtpad_729') for v in free[:10]]:
  Q=Query(objects,ownvia,ownpad)
  for layer in ('inner2','inner1','top','bottom'):
   r=astar(start,end,layer,Q);r.update({'owner':owner,'start':start,'end':end});results.append(r);print(r,flush=True)
   if r['found']:break
 out='/tmp/g350-cap8-power-reference-astar-report.json';Path(out).write_text(json.dumps({'scope':'PURE_STDLIB_POWER_REFERENCE_PLANNING_NOT_SDK_OR_NATIVE','capCenter':[0,7.9],'rotation':0,'groundFreeViaSites':free,'results':results,'fabricationReady':False},indent=2)+'\n');print('sha',hashlib.sha256(Path(out).read_bytes()).hexdigest(),flush=True)
