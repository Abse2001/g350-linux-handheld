"""Pure V11 explicit layer-policy bridge; no Core/native/router/CAD execution.
Actual V10 Core geometry/17 zero checks are inherited, not rerun. A separately
root-guarded pure React capture must pass before public routing initialization.
"""
from pathlib import Path
import hashlib, json, stat, copy, importlib.util
ROOT = Path(__file__).resolve().parent
PARENT = Path('/workspace/bus-lanes-solver/.cache/g350-ti-v10-actual-core-input-provenance-next')
PARENT_MANIFEST_SHA = '808973497c8fc33ef8e012fd0026eaef024aa12bf8505a71b9875fa6b84ccf97'
PARENT_MODULE_SHA = '01e95ae701a257138c3869840107b07ca8e628916995c13d719daf7e8a958d87'
INPUT_SHA = '171ab7893fa92315e2b5ef39afb35145a5c4a6dff9b04ca45ec2afdc3f3babd5'
UNRESTRICTED_SHA = 'ff2eee3ce065e6264d6d9fa20b61a964f21fd3b13ed220f032a916807f076b60'
SOURCE_SHA = '2312aa3be3feb3b95a25ea7df72d46344ce3837f4cbff4353872744f67c80613'
def require(value, message):
    if not value: raise ValueError(message)
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path): return json.loads(Path(path).read_bytes())
def rows(directory, items):
    for item in items:
        p=Path(item['path']) if directory is None else directory/item['path']
        require(p.is_file() and not p.is_symlink(), 'Missing or symlinked binding: '+str(p))
        require(p.stat().st_size==item['bytes'] and sha(p)==item['sha256'] and stat.S_IMODE(p.stat().st_mode)==item['mode'], 'Binding differs: '+str(p))
def verify(expected_manifest_sha256):
    require(sha(ROOT/'SOURCE-INPUT-manifest.json')==expected_manifest_sha256, 'Exact frozen V11 source bridge manifest required')
    m=load(ROOT/'SOURCE-INPUT-manifest.json');rows(ROOT,m['files']);rows(None,m['externalFiles'])
    require(sha(PARENT/'v10_input_provenance.py')==PARENT_MODULE_SHA, 'Frozen independent V10 binder changed')
    spec=importlib.util.spec_from_file_location('g350_frozen_v10_source_input_provenance',PARENT/'v10_input_provenance.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    inherited=module.verify(PARENT_MANIFEST_SHA)
    require(inherited['inputSha256']=='ff1560b02b15c8d46ce27d3b93778daa4bb160601b676165878914ff50d79f7a' and inherited['freshCircuitSha256']==SOURCE_SHA, 'Exact actual V10 inherited geometry required')
    require(sha(ROOT/'input.json')==INPUT_SHA and sha(ROOT/'original-unrestricted-input.json')==UNRESTRICTED_SHA, 'Exact V11/unchanged unrestricted input bytes required')
    old=load(PARENT/'input.json');actual=load(ROOT/'input.json');expected=copy.deepcopy(old)
    changed=[]
    for i,b in enumerate(expected['buses']):
        if b['busId']=='DDR_BYTE1':
            require(b['allowedLayers']==b['preferredLayers']==['bottom'], 'Original BYTE1 Bottom policy required')
            b['allowedLayers']=['top'];b['preferredLayers']=['top'];changed=[i]
    require(len(changed)==1 and actual==expected, 'Only two BYTE1 native layer-list values may change')
    policy=load(ROOT/'v11-layer-policy.json');original_policy=load(PARENT/'authored-layer-policy-authority.json')
    expected_policy=copy.deepcopy(original_policy)
    for group in expected_policy['groups']:
        if group['nativeBus']['busId']=='DDR_BYTE1':
            group['nativeBus']['allowedLayers']=['top'];group['nativeBus']['preferredLayers']=['top']
    expected_policy['allocation']={'top':37,'bottom':12}
    require(policy==expected_policy and actual['buses']==[g['nativeBus'] for g in policy['groups']], 'Only authorized whole BYTE1 source policy layer lists may change')
    allocation={layer:sum(len(bus['connectionNames']) for bus in actual['buses'] if bus['allowedLayers']==[layer]) for layer in ['top','bottom']}
    require(allocation=={'top':37,'bottom':12}, 'Whole-cohort37Top/12Bottom required')
    circuit=load(PARENT/'actual-v10-layout.circuit.json');source_buses={e['name']:e for e in circuit if e['type']=='source_bus'}
    for group in policy['groups']:
        b=group['nativeBus'];c=source_buses[b['busId']]
        require(c['source_trace_ids']==b['connectionNames'] and c.get('max_length_skew')==b.get('maxLengthSkew'), 'Actual pinned Core group roster/skew changed')
        require(not any(key in c for key in ['allowedLayers','preferredLayers','minLength','maxLength']), 'Do not attribute omitted layer/window fields to source_bus JSON')
    for pair in policy['pairs']:
        c=source_buses[pair['name']];p=pair['nativePair']
        require(c['source_trace_ids']==p['connectionNames'] and c['max_length_skew']==p['lengthTolerance'], 'Actual Core differential-pair roster/skew changed')
    before=load(PARENT/'actual-authored-layer-policy-proof.json')['authoredPolicyProof'];expected_props=copy.deepcopy(before)
    for group in expected_props['groups']:
        if group['busId']=='DDR_BYTE1':
            group['pcbAllowedLayers']=['top'];group['preferredLayers']=['top']
    derived=load(ROOT/'derived-final-authored-props.json')
    require(derived['authoredPolicyProof']==expected_props and derived['actualV10FinalPropsProofSha256']==sha(PARENT/'actual-authored-layer-policy-proof.json') and derived['actualCoreCircuitSha256']==SOURCE_SHA, 'Final props derivation must exactly bind actual V10 and two BYTE1 prop changes')
    require(derived['actualV11ReactEvaluationPerformed'] is False and derived['newCoreBuildPerformed'] is False and derived['newNativePlacementCheckPerformed'] is False, 'Pure derivation must not claim freshly executed source checks')
    require(derived['allocation']==allocation and derived['inheritedActualNativePlacementChecks']==17 and derived['inheritedActualNativePlacementErrors']==0 and derived['accepted49'] is False and derived['fabricationReady'] is False, 'Honest inherited physical proof/acceptance flags required')
    for g,authored in zip(policy['groups'],expected_props['groups']):
        b=g['nativeBus']
        require(authored['busId']==b['busId'] and authored['connections']==g['logicalConnections'] and authored['pcbTraceWidth']==b['traceWidth'] and authored['pcbAllowedLayers']==b['allowedLayers'] and authored['preferredLayers']==b['preferredLayers'], 'Authored whole-cohort props differ from native bridge')
        for key in ['maxLengthSkew','minLength','maxLength']: require(authored.get(key)==b.get(key), 'Original source bridge '+key+' changed')
    return {'scope':'PURE_V11_AUTHORED_LAYER_POLICY_TO_INHERITED_ACTUAL_CORE_GEOMETRY_BRIDGE', 'inputSha256':INPUT_SHA,'unrestrictedInputSha256':UNRESTRICTED_SHA,'freshCircuitSha256':SOURCE_SHA,'allocation':allocation,'nativePlacementChecks':17,'nativePlacementErrors':0,'nativePlacementChecksInheritedNotRerun':True,'physicalInputExactlyHeld':True,'onlyLayerListsChanged':True,'routingRequests':49,'obstacles':856,'fixedReferences':2,'actualV11ReactEvaluationPerformed':False,'actualFinalReactEvaluationRequiredBeforeMain':True,'captureScript':str(ROOT/'capture-v11-authored-props.ts'),'newCoreBuildPerformed':False,'nativeCoreOrRouterApiInvoked':False,'accepted49':False,'fabricationReady':False}
def verify_producer_inputs(producer_directory, expected_manifest_sha256):
    result=verify(expected_manifest_sha256);p=Path(producer_directory)
    require(sha(p/'input.json')==INPUT_SHA and sha(p/'original-unrestricted-input.json')==UNRESTRICTED_SHA, 'Fresh producer inputs must exactly match V11 policy bridge')
    return result
def verify_actual_authored_props(output_path):
    """Caller must separately bind this output to clean root-guarded capture execution."""
    expected={'scope':'PURE_REAL_FINAL_REACT_PROPS_EVALUATION_ONLY','actualFinalReactTreeEvaluated':True,'derivedProofSha256':sha(ROOT/'derived-final-authored-props.json'),'authoredPolicyProof':load(ROOT/'derived-final-authored-props.json')['authoredPolicyProof'],'allocation':{'top':37,'bottom':12},'coreRenderCalled':False,'nativePlacementChecksInvoked':False,'routingSolverInstantiated':False,'accepted49':False,'fabricationReady':False}
    require(load(output_path)==expected, 'Actual final authored React prop capture differs from exact frozen V11 projection')
    return {'actualFinalReactTreeEvaluated':True,'captureSha256':sha(output_path),'derivedProofSha256':expected['derivedProofSha256'],'newCoreBuildPerformed':False,'newNativePlacementCheckPerformed':False,'accepted49':False,'fabricationReady':False}
