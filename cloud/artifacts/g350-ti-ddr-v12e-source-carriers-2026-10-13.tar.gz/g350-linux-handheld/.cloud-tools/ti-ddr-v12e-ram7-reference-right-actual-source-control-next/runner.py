"""One routing-disabled pinned Core build, actual projection and forward proof.

All execution is deferred until exact root authority and fresh output gates.
No signal routing or CAD export is performed.
"""
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def exclusive_json(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')


def main():
    if sys.argv[1:] != ['--one-root-approved-source-forward'] or os.environ.get('G350_TI_V12E_SOURCE_FORWARD_APPROVED') != '1':
        raise ValueError('Exact root source-forward authority required')
    packet_path = ROOT / 'CONTROL-manifest.json'
    packet_sha = sha(packet_path)
    if os.environ.get('G350_TI_V12E_SOURCE_FORWARD_PACKET_SHA') != packet_sha:
        raise ValueError('Frozen packet differs')
    packet = json.loads(packet_path.read_bytes())
    receipt_path = Path(os.environ['G350_TI_V12E_SOURCE_FORWARD_RECEIPT_PATH'])
    if sha(receipt_path) != os.environ['G350_TI_V12E_SOURCE_FORWARD_RECEIPT_SHA']:
        raise ValueError('Root receipt bytes differ')
    receipt = json.loads(receipt_path.read_bytes())
    if not (receipt['authorizedByRoot'] is True and
            receipt['scope'] == 'one-routing-disabled-pinned-core-v12e-three-rigid-x-props-forward-control' and
            receipt['packetSha256'] == packet_sha and receipt['policy'] == packet['policy'] and
            receipt['layerPolicyProjectionBridgeAuthorized'] is True and
            receipt['layerPolicyAuthoritySha256'] == packet['layerPolicyAuthority']['sha256'] and
            receipt['baselineV12dInputSha256'] == 'ff3de67bc83c036b7780561690806227b3981c9eee88920497c6a7e9889f56aa'):
        raise ValueError('Root receipt scope differs')
    run = ROOT / 'run'
    actual_file = ROOT / packet['freshOutput']
    if not run.is_dir() or actual_file.exists() or actual_file.parent.exists() or (ROOT / 'output').exists():
        raise ValueError('Fresh exclusive actual source/projection outputs required')
    report = {'scope': 'ACTUAL_V12E_ROUTING_DISABLED_SOURCE_AND_AUTHORED_POLICY_FORWARD_CONTROL',
              'packetSha256': packet_sha, 'commands': [], 'sourceBuildCount': 0,
              'actualSourceAndInputQualified': False, 'accepted49': False,
              'electricalTimingQualified': False, 'fabricationReady': False,
              'signalRoutingPerformed': False, 'cadPerformed': False}
    def save():
        (run / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    def command(name, argv, cwd):
        started = time.monotonic()
        with (run / (name + '.log')).open('xb') as log:
            process = subprocess.run(argv, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=False)
        report['commands'].append({'name': name, 'argv': argv, 'exitCode': process.returncode,
                                   'wallSeconds': time.monotonic() - started})
        save()
        if process.returncode != 0:
            raise ValueError('Actual source-forward stage failed: ' + name)
    try:
        print(json.dumps({'phase': 'one-pinned-routing-disabled-build', 'signalRoutingPerformed': False}), flush=True)
        report['sourceBuildCount'] = 1
        command('actual-source-build', packet['buildCommand'], ROOT / 'source')
        if not actual_file.is_file() or actual_file.is_symlink():
            raise ValueError('Actual fresh Core output absent')
        actual_raw = actual_file.read_bytes()
        copied = run / 'fresh-layout.circuit.json'
        copied.write_bytes(actual_raw)
        actual_sha = sha(copied)
        if sha(actual_file) != actual_sha:
            raise ValueError('Actual source bytes changed during copy')
        report['actualSourceArtifact'] = {'path': packet['freshOutput'], 'bytes': len(actual_raw), 'sha256': actual_sha}
        report['actualSourceBytesCopiedWithoutReserialization'] = True
        save()
        print(json.dumps({'phase': 'actual-pinned-core-projection', 'sourceSha256': actual_sha}), flush=True)
        command('actual-core-projection', [packet['bun'], '--smol', str(ROOT / 'capture-v12e.ts'),
                packet['coreEntry'], str(copied), actual_sha], ROOT)
        print(json.dumps({'phase': 'all17-pinned-native-placement-and-existing-reference-checks'}), flush=True)
        command('actual-native-placement', [packet['bun'], '--smol', str(ROOT / 'check-native-physical.mjs'),
                str(copied), actual_sha, str(run / 'native-physical.json')], ROOT)
        print(json.dumps({'phase': 'pure-forward-source-projection-proof'}), flush=True)
        command('actual-forward-proof', [sys.executable, '-B', str(ROOT / 'verify_actual_core.py'),
                '--actual-circuit', str(copied), '--actual-circuit-sha256', actual_sha,
                '--actual-ddr-input', str(ROOT / 'output/ddr-input.json'),
                '--output', str(run / 'validated-input')], ROOT)
        physical = json.loads((run / 'native-physical.json').read_bytes())
        proof = json.loads((run / 'validated-input/actual-source-validation.json').read_bytes())
        if physical['sourceSha256'] != actual_sha or physical['physicalErrors'] != 0 or physical['checkCount'] != 17:
            raise ValueError('All17 actual native placement/reference checks must be zero')
        if proof['actualCircuitSha256'] != actual_sha or proof['emittedValidatedInputsUseActualRawCoreGeometry'] is not True:
            raise ValueError('Actual source/projection proof differs')
        if sha(copied) != actual_sha or sha(actual_file) != actual_sha:
            raise ValueError('Actual source artifact changed')
        report.update(actualSourceAndInputQualified=True, actualSourceForwardProof=proof,
                      explicitLayerPolicyProjectionBridgeUsed=True,
                      layerPolicyDerivedFromFinalAuthoredPropsAndActualCoreRoster=True,
                      wholeCohortAllocation={'top':11,'inner1':26,'inner2':11,'bottom':1},
                      nativePhysicalCounts=physical['counts'], nativePhysicalErrors=0,
                      nativePhysicalCheckCount=17,
                      validatedInputSha256=proof['validatedInputSha256'],
                      validatedUnrestrictedInputSha256=proof['validatedUnrestrictedInputSha256'],
                      allOriginalSourceLogicAnd49NumericContactIdentityVerificationRequired=True,
                      sourceOnly=True, actualDdr49RouteProduced=False)
        save()
        print(json.dumps({'actualSourceAndInputQualified': True,
                          'inputSha256': report['validatedInputSha256'],
                          'actualDdr49RouteProduced': False, 'fabricationReady': False}), flush=True)
        return 0
    except BaseException as error:
        report['originalFailure'] = str(error)
        save()
        raise


if __name__ == '__main__':
    raise SystemExit(main())
