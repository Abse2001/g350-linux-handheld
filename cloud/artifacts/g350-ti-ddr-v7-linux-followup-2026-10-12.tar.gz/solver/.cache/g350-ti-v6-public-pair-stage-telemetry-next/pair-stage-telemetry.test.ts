import { expect, mock, test } from "bun:test"
import { createHash } from "node:crypto"
import { installPairStageTelemetry } from "./pair-stage-telemetry"
import { runBoundedRouting } from "./fixtures/bounded"
import * as livePlanner from "./fixtures/planner"
import * as liveCoupled from "./fixtures/coupled"
import * as liveBounded from "./fixtures/bounded"
import * as liveSites from "./fixtures/sites"
// This consumer is loaded before module replacement, matching the real runner.
import { consume, siteEntry, currentBindings } from "./fixtures/consumer"

const input = {
  connections: ["P", "N"].map((name) => ({
    name,
    pointsToConnect: [{ layer: "top" }],
  })),
  differentialPairs: [{ connectionNames: ["P", "N"] }],
  feedback: undefined,
}
const tuple = [
  {
    connection_name: "P",
    route: [
      { x: 0, y: 0 },
      { x: 1, y: 1 },
    ],
  },
]
const hashTuple = (value: unknown[]) =>
  createHash("sha256").update(JSON.stringify(value)).digest("hex")
const empty = function* () {
  return null
}
const modules = (
  coupled: (...args: any[]) => any = empty,
  planner: (...args: any[]) => any = empty,
) => ({
  coupled: { routeCoupledPair: coupled, extra: Symbol("coupled") },
  planner: { planSharedPairCorridors: planner, extra: Symbol("planner") },
  bounded: { runBoundedRouting, extra: Symbol("bounded") },
  sites: { negotiateSignalSites: empty, extra: Symbol("sites") },
})
const caught = (work: () => unknown) => {
  try {
    work()
  } catch (error) {
    return error
  }
  throw Error("Expected original throw")
}

test("iterator result/error identity, exact argument counts, feedback and self-iteration survive observation", () => {
  const expectedError = Error("original method")
  const seen: { method: string; receiver: unknown; args: unknown[] }[] = []
  const results = {
    next: { done: false, value: tuple },
    return: { done: true, value: null },
    throw: { done: false, value: undefined },
  }
  const raw = {
    next(...args: unknown[]) {
      seen.push({ method: "next", receiver: this, args })
      return results.next
    },
    return(...args: unknown[]) {
      seen.push({ method: "return", receiver: this, args })
      return results.return
    },
    throw(...args: unknown[]) {
      seen.push({ method: "throw", receiver: this, args })
      if (args[0] === expectedError) throw expectedError
      return results.throw
    },
    [Symbol.iterator](...args: unknown[]) {
      seen.push({ method: "iterator", receiver: this, args })
      return this
    },
  }
  const fixture = modules(function (this: unknown, ...args: unknown[]) {
    seen.push({ method: "factory", receiver: this, args })
    return raw
  })
  const receiver = { exact: true },
    factoryArgs = [input, input.differentialPairs[0], [], { variant: 2 }]
  const profile = installPairStageTelemetry(
    fixture,
    () => {},
    undefined,
    hashTuple,
  )
  try {
    const work = Reflect.apply(
      fixture.coupled.routeCoupledPair,
      receiver,
      factoryArgs,
    )
    expect(seen[0]?.receiver).toBe(receiver)
    for (let i = 0; i < factoryArgs.length; i++)
      expect(seen[0]?.args[i]).toBe(factoryArgs[i])
    expect(work[Symbol.iterator]()).toBe(work)
    expect(work.next()).toBe(results.next)
    expect(work.next(undefined)).toBe(results.next)
    expect(work.next(tuple)).toBe(results.next)
    expect(work.throw(undefined)).toBe(results.throw)
    expect(caught(() => work.throw(expectedError))).toBe(expectedError)
    expect(work.return(tuple)).toBe(results.return)
    expect(
      seen
        .filter((call) => call.method === "next")
        .map((call) => call.args.length)
        .join(","),
    ).toBe("0,1,1")
    expect(seen.slice(1).every((call) => call.receiver === raw)).toBe(true)
    expect(profile.snapshot().errors).toBe(1)
    expect(profile.snapshot().rows[0]?.argumentCount).toBe(4)
    expect(profile.snapshot().rows[0]?.preferPackageOnlyTuning).toBe(null)
    expect(profile.snapshot().rows[0]?.precheckEnclosedTerminals).toBe(null)
  } finally {
    profile.restore()
  }
})

test("borrowed next targets its supplied tracked receiver; extracted native next retains TypeError", () => {
  const raw: Generator<unknown, unknown, unknown>[] = []
  const fixture = modules(function* () {
    yield 1
    yield 2
    return null
  })
  const originalFactory = fixture.coupled.routeCoupledPair
  fixture.coupled.routeCoupledPair = (...args: any[]) => {
    const result = originalFactory(...args)
    raw.push(result)
    return result
  }
  const profile = installPairStageTelemetry(fixture, () => {})
  try {
    const first = fixture.coupled.routeCoupledPair(),
      second = fixture.coupled.routeCoupledPair()
    const borrowed = first.next
    expect(
      (Reflect.apply(borrowed, second, []) as IteratorResult<number>).value,
    ).toBe(1)
    expect(second.next().value).toBe(2)
    expect(first.next().value).toBe(1)
    expect(caught(() => borrowed())).toBeInstanceOf(TypeError)
    expect(profile.snapshot().rows[0]?.next).toBe(1)
    expect(profile.snapshot().rows[1]?.next).toBe(2)
    expect(raw.length).toBe(2)
  } finally {
    profile.restore()
  }
})

test("natural body/null and repeated terminal operations remain distinct from cleanup", () => {
  const fixture = modules(function* (body: boolean) {
    return body ? tuple : null
  })
  const profile = installPairStageTelemetry(
    fixture,
    () => {},
    undefined,
    hashTuple,
  )
  try {
    const body = fixture.coupled.routeCoupledPair(true),
      nullWork = fixture.coupled.routeCoupledPair(false)
    expect(body.next().value).toBe(tuple)
    body.next()
    body.return(null)
    body.next()
    expect(nullWork.next().value).toBe(null)
    const snapshot = profile.snapshot()
    expect(snapshot.naturalBody).toBe(1)
    expect(snapshot.naturalNull).toBe(1)
    expect(snapshot.rows[0]?.completion).toBe("natural-next-body")
    expect(snapshot.rows[0]?.shapeHash).toBe(hashTuple(tuple))
    expect(snapshot.rows[0]?.traceCount).toBe(1)
    expect(snapshot.rows[0]?.pointCount).toBe(2)
    expect(snapshot.rows[1]?.completion).toBe("natural-next-null")
  } finally {
    profile.restore()
  }
})

test("return with a yielding finally is forwarded once and never drained or relabeled natural", () => {
  let finallyEntries = 0,
    afterYield = 0
  const fixture = modules(function* () {
    try {
      yield "ordinary"
    } finally {
      finallyEntries++
      yield "cleanup-yield"
      afterYield++
    }
    return tuple
  })
  const profile = installPairStageTelemetry(fixture, () => {})
  try {
    const work = fixture.coupled.routeCoupledPair()
    expect(work.next().value).toBe("ordinary")
    const returned = work.return(null)
    expect(returned.done).toBe(false)
    expect(returned.value).toBe("cleanup-yield")
    expect(finallyEntries).toBe(1)
    expect(afterYield).toBe(0)
    expect(work.next().done).toBe(true)
    expect(afterYield).toBe(1)
    expect(profile.snapshot().naturalBody).toBe(0)
    expect(profile.snapshot().rows[0]?.completion).toBe("caller-close-unknown")
  } finally {
    profile.restore()
  }
})

test("original6000 bounded cap uses6001 raw NEXT calls and one cleanup without replacing raw NEXT state", () => {
  const fixture = modules(function* () {
    while (true) {
      try {
        yield undefined
      } catch {
        yield undefined
      }
    }
  })
  const profile = installPairStageTelemetry(fixture, () => {})
  try {
    const raw = fixture.coupled.routeCoupledPair()
    const work = fixture.bounded.runBoundedRouting(raw, 6000)
    let result = work.next(),
      yields = 0
    while (!result.done) {
      yields++
      result = work.next()
    }
    expect(yields).toBe(6000)
    expect(result.value).toBe(null)
    const snapshot = profile.snapshot()
    expect(snapshot.rows[0]?.next).toBe(6001)
    expect(snapshot.rows[0]?.return).toBe(1)
    expect(snapshot.rows[0]?.completion).toBe("caller-close-unknown")
    expect(snapshot.rows[1]?.linkedChildId).toBe(snapshot.rows[0]?.id)
    expect(snapshot.rows[1]?.completion).toBe("bounded-6000-cap-null")
    expect(snapshot.capNull).toBe(1)
    expect(snapshot.observationErrors).toBe(0)
    const thrownRaw = fixture.coupled.routeCoupledPair()
    const altered = fixture.bounded.runBoundedRouting(thrownRaw, 6000)
    let alteredResult = altered.next()
    thrownRaw.throw(Error("external resume changes source history"))
    while (!alteredResult.done) alteredResult = altered.next()
    const afterThrow = profile.snapshot()
    expect(afterThrow.rows[2]?.throw).toBe(1)
    expect(afterThrow.rows[3]?.completion).toBe("bounded-null-unknown")
    expect(afterThrow.capNull).toBe(1)
  } finally {
    profile.restore()
  }
})

test("natural child null and caller-closed bounded iterator never become a6000 cap", () => {
  const fixture = modules(function* (end: boolean) {
    if (end) return null
    while (true) yield undefined
  })
  const profile = installPairStageTelemetry(fixture, () => {})
  try {
    const natural = fixture.bounded.runBoundedRouting(
      fixture.coupled.routeCoupledPair(true),
      6000,
    )
    expect(natural.next().value).toBe(null)
    const closed = fixture.bounded.runBoundedRouting(
      fixture.coupled.routeCoupledPair(false),
      6000,
    )
    closed.next()
    closed.return(null)
    const snapshot = profile.snapshot()
    expect(snapshot.rows[1]?.completion).toBe("child-natural-null")
    expect(snapshot.rows[3]?.completion).toBe("caller-close-unknown")
    expect(snapshot.capNull).toBe(0)
  } finally {
    profile.restore()
  }
})

test("planner offers hash transient tuples; site entry preserves its original iterator; limits continue aggregates", () => {
  const siteRaw = empty()
  const fixture = modules(empty, function* () {
    yield tuple
    return undefined
  })
  fixture.sites.negotiateSignalSites = () => siteRaw
  const profile = installPairStageTelemetry(
    fixture,
    () => {
      throw Error("observer only")
    },
    undefined,
    hashTuple,
  )
  try {
    expect(fixture.sites.negotiateSignalSites()).toBe(siteRaw)
    expect(fixture.sites.negotiateSignalSites()).toBe(siteRaw)
    for (let i = 0; i < 140; i++)
      fixture.planner
        .planSharedPairCorridors(input, new Map(), true, { variant: i })
        .next()
    const snapshot = profile.snapshot()
    expect(snapshot.rows.length).toBe(64)
    expect(snapshot.events.length).toBe(128)
    expect(snapshot.factories).toBe(142)
    expect(snapshot.offers).toBe(140)
    expect(snapshot.droppedEvents > 0).toBe(true)
    expect(snapshot.observationErrors > 0).toBe(true)
    expect(snapshot.rows[2]?.shapeHash).toBe(hashTuple(tuple))
    expect(snapshot.events.at(-1)?.kind).toBe("planner-tuple-offer")
    expect(snapshot.events.at(-1)?.traceCount).toBe(1)
    expect(snapshot.events.at(-1)?.pointCount).toBe(2)
    expect(snapshot.events.at(-1)?.shapeHash).toBe(hashTuple(tuple))
    expect(
      snapshot.rows.every((row) =>
        Object.values(row).every(
          (value) =>
            value === null ||
            ["number", "string", "boolean"].includes(typeof value),
        ),
      ),
    ).toBe(true)
  } finally {
    profile.restore()
  }
})

test("non-self Symbol.iterator results retain exact identity even when the other iterator is tracked", () => {
  let iteratorReturn: unknown
  const raw = [0, 1].map(() => ({
    next() {
      return { done: true, value: null }
    },
    [Symbol.iterator]() {
      return iteratorReturn ?? this
    },
  }))
  const fixture = modules((index: number) => raw[index])
  const profile = installPairStageTelemetry(fixture, () => {})
  try {
    const first = fixture.coupled.routeCoupledPair(0)
    const second = fixture.coupled.routeCoupledPair(1)
    expect(first[Symbol.iterator]()).toBe(first)
    expect(second[Symbol.iterator]()).toBe(second)
    iteratorReturn = raw[1]
    expect(first[Symbol.iterator]()).toBe(raw[1])
    expect(first[Symbol.iterator]()).not.toBe(second)
  } finally {
    profile.restore()
  }
})

test("already-imported fake consumers observe complete Bun live-export replacement and restoration", () => {
  const fixture = {
    planner: livePlanner,
    coupled: liveCoupled,
    bounded: liveBounded,
    sites: liveSites,
  }
  const original: Record<string, Record<string, any>> = {
    planner: { ...livePlanner },
    coupled: { ...liveCoupled },
    bounded: { ...liveBounded },
    sites: { ...liveSites },
  }
  const before = currentBindings()
  const profile = installPairStageTelemetry(
    fixture,
    () => {},
    (key, exports) => {
      const path = new URL(`./fixtures/${key}.ts`, import.meta.url).pathname
      const extraName = `${key}Extra`
      expect(exports[extraName]).toBe(original[key]?.[extraName])
      mock.module(path, () => exports)
    },
    hashTuple,
  )
  try {
    expect(currentBindings().planSharedPairCorridors).not.toBe(
      before.planSharedPairCorridors,
    )
    const work = consume(input)
    expect(work.next().done).toBe(false)
    const offered = work.next()
    expect(Array.isArray(offered.value)).toBe(true)
    expect(work.next().done).toBe(true)
    const sites = siteEntry(input)
    expect(sites.next().value).toBe(input)
    const snapshot = profile.snapshot()
    expect(snapshot.factories).toBe(4)
    expect(snapshot.groups).toBeDefined()
    expect(snapshot.rows.map((row) => row.kind).join(",")).toBe(
      "planner,coupled,bounded,sites",
    )
    expect(snapshot.offers).toBe(1)
    expect(snapshot.rows[1]?.completion).toBe("natural-next-body")
    expect(snapshot.rows[2]?.completion).toBe("natural-next-body")
    expect(snapshot.rows[3]?.next).toBe(0)
    expect(snapshot.observationErrors).toBe(0)
  } finally {
    profile.restore()
  }
  const after = currentBindings()
  expect(after.planSharedPairCorridors).toBe(before.planSharedPairCorridors)
  expect(after.routeCoupledPair).toBe(before.routeCoupledPair)
  expect(after.runBoundedRouting).toBe(before.runBoundedRouting)
  expect(after.negotiateSignalSites).toBe(before.negotiateSignalSites)
})

test("restoration attempts all four modules and installation cleanup preserves the original error", () => {
  const fixture = modules()
  const originals = {
    planner: { ...fixture.planner },
    coupled: { ...fixture.coupled },
    bounded: { ...fixture.bounded },
    sites: { ...fixture.sites },
  }
  const restoreError = Error("one restore callback")
  const attempts: string[] = []
  let failRestore = false
  const profile = installPairStageTelemetry(
    fixture,
    () => {},
    (key, exports) => {
      Object.assign(fixture[key], exports)
      if (failRestore) {
        attempts.push(key)
        if (key === "planner") throw restoreError
      }
    },
  )
  failRestore = true
  expect(caught(() => profile.restore())).toBe(restoreError)
  expect(attempts.join(",")).toBe("planner,coupled,bounded,sites")
  expect(fixture.planner.planSharedPairCorridors).toBe(
    originals.planner.planSharedPairCorridors,
  )
  expect(fixture.coupled.routeCoupledPair).toBe(
    originals.coupled.routeCoupledPair,
  )
  expect(fixture.bounded.runBoundedRouting).toBe(
    originals.bounded.runBoundedRouting,
  )
  expect(fixture.sites.negotiateSignalSites).toBe(
    originals.sites.negotiateSignalSites,
  )
  failRestore = false
  profile.restore()

  const installError = Error("original install callback")
  const cleanupError = Error("secondary cleanup callback")
  const installAttempts: string[] = []
  let installationFailed = false
  const observed = caught(() =>
    installPairStageTelemetry(
      fixture,
      () => {},
      (key, exports) => {
        Object.assign(fixture[key], exports)
        if (!installationFailed) {
          installationFailed = true
          throw installError
        }
        installAttempts.push(key)
        if (key === "planner") throw cleanupError
      },
    ),
  )
  expect(observed).toBe(installError)
  expect(installAttempts.join(",")).toBe("planner,coupled,bounded,sites")
  expect(fixture.planner.planSharedPairCorridors).toBe(
    originals.planner.planSharedPairCorridors,
  )
  expect(fixture.coupled.routeCoupledPair).toBe(
    originals.coupled.routeCoupledPair,
  )
  expect(fixture.bounded.runBoundedRouting).toBe(
    originals.bounded.runBoundedRouting,
  )
  expect(fixture.sites.negotiateSignalSites).toBe(
    originals.sites.negotiateSignalSites,
  )
})
