# Canonical-only coupled handoff length proposal

This proposal is based on c1151212, whose latest fetched upstream ancestor is d8583e4. It changes only coupled-pair-routing.ts and adds one helper and four focused tests. V5's 19 experimental changes are excluded.

The necessary bound checks each original rail endpoint against both carrier terminals. The final bevel can visit within 1.5 trace widths of that endpoint, so subtracting twice that radius preserves its possible shortening. Fixed copper is subtracted by the existing maximumCarrierLength API; no via depth or new timing model is inferred. The completion gate and bevel order are unchanged.

No maximum length means Infinity; the helper immediately returns false. Thus old no-cap benchmark inputs take the same candidate sequence and search calls. qualification-only contains a byte-exact original module and three proposed controls: old/new generated traces and yield counts on a blocked pair without a cap; the same under a loose finite cap; and distant finite handoffs under no cap/Infinity. That witness is for qualification only and is not part of adoption.patch.

Root must assemble a clean c115 source copy, overlay the three source files, then overlay the two qualification-only witness files at their lib/tests paths. Do not overlay any V5 source. Run the four new tests and three witness controls, followed by the existing regression files enumerated in PREPARED-canonical-source-proposal.json. All checks are unexecuted in this source-only handoff. Infinity is a helper no-op control, not a newly valid pipeline input; existing bus-max-length.test.ts still rejects nonfinite declared limits.

Full-suite and benchmark acceptance remain outstanding. No dependencies, source pins, hardware, native checker patch, work budgets or canonical worktree files were changed.
