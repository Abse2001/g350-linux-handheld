import { Children, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { buildCombinedLocalSource } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-signal96-joint-native-sourceonly-next/combined-source-overlay"
import { registerClockInnerPorts } from "./clock-source-overlay"
import proposal from "./clock-fidelity-source-proposal.json"
type Props = Record<string, unknown> & { name?: string; children?: ReactNode }

/** Explicit Source successor: preserve every original logical clock and bus;
 * apply only six declared PCB-render property changes in a new wrapper.
 * No existing file, physical reference geometry or Native registry is edited. */
export function buildCombinedClockV11FidelitySource() {
  const base = buildCombinedLocalSource(), clocks = proposal.clockCarriers
  const owners = clocks.flatMap(c => [c.cpu, c.ram])
  let boards = 0, addedPorts = 0, logicalClockChanges = 0, localClockRenderingChanges = 0
  const changed: Array<{ name: string; action: string; before: Record<string, unknown> }> = []
  const seenVias = new Set<string>()
  function append(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const props = { ...node.props }
    const children = Children.toArray(props.children).map(append)
    const owner = owners.find(o => o.viaName === props.name)
    if (owner) {
      if (node.type !== "via" || props.pcbX !== owner.viaXY.x || props.pcbY !== owner.viaXY.y
        || props.fromLayer !== "top" || props.toLayer !== "bottom" || props.outerDiameter !== .4572 || props.holeDiameter !== .254
        || children.length !== 0 || seenVias.has(owner.viaName)) throw Error("Four unchanged real full-span clock vias required")
      seenVias.add(owner.viaName); children.push(<port name="inner1" layer="inner1" />); addedPorts++
    }
    const clock = clocks.find(c => c.originalLogicalTraceName === props.name)
    if (clock) {
      const cpu = `${clock.cpu.package}.pin${clock.cpu.numericPin}`, ram = `${clock.ram.package}.pin${clock.ram.numericPin}`
      if (node.type !== "trace" || props.from !== cpu || props.to !== ram || props.path !== undefined
        || props.pcbPath !== undefined || props.pcbPaths !== undefined || props.pcbPathRelativeTo !== undefined)
        throw Error("Original two numeric clock traces, without existing manual routes, required")
      changed.push({ name: props.name!, action: "ADD_ORIGINAL_CLOCK_THREE_PCB_PATHS_ONLY", before: { from: props.from, to: props.to } })
      props.pcbPaths = clock.threePcbPaths
      props.pcbPathRelativeTo = clock.pcbPathRelativeTo
      logicalClockChanges++
    }
    const localOwner = owners.find(o => o.traceName === props.name)
    if (localOwner) {
      if (node.type !== "trace" || props.from !== `${localOwner.package}.pin${localOwner.numericPin}`
        || props.to !== `.${localOwner.viaName} > port.top` || props.thickness !== .1016
        || !Array.isArray(props.pcbPath) || props.pcbPath.length !== 0 || props.pcbPaths !== undefined
        || props.pcbPathRelativeTo !== `.${localOwner.viaName} > port.top`)
        throw Error("Original four exact Top local prototype branches required")
      changed.push({ name: props.name!, action: "OMIT_DUPLICATE_TOP_PCB_RENDER_KEEP_SOURCE_CONNECTION", before: { pcbPath: props.pcbPath } })
      // The same Top copper now appears under its original numeric clock ID,
      // letting the untouched Native length aggregator include both Top stubs.
      delete props.pcbPath
      localClockRenderingChanges++
    }
    if (node.type === "board") {
      boards++
      if (props.layers !== 4 || props.routeRemaining !== false || (props.pcbX ?? 0) !== 0 || (props.pcbY ?? 0) !== 0 || (props.pcbRotation ?? 0) !== 0)
        throw Error("Original routing-disabled four-layer identity board required")
    }
    return cloneElement(node as ReactElement<Props>, props, ...children)
  }
  const element = append(base.element)
  if (boards !== 1 || addedPorts !== 4 || logicalClockChanges !== 2 || localClockRenderingChanges !== 4 || seenVias.size !== 4)
    throw Error("Exactly four real ports and six explicit PCB-only changes required")
  return { ...base, element, clockSourceProposal: proposal, exactDeclaredPcbOnlyChanges: changed,
    clockSourceFidelity: { original49LogicalEndpointsAndBusMembershipUnchanged: true, addedRealLayerPorts: 4,
      originalLiteralElements: 2228, proposedLiteralElements: 2232, physicalReferenceVias: 129, physicalSignalVias: 96,
      physicalViaPrimitivesInNewClockPaths: 0, unchangedReferenceTraces: 165, retainedLocalTopTraceRenderings: 92,
      clockTopTraceRenderingsUnderOriginalSourceIds: 4, clockInner1TraceRenderingsUnderOriginalSourceIds: 2,
      proposedPhysicalTraceCount: 263, rawSourceIdsMustPassFreshCore: true, sourceExecuted: false, coreRendered: false,
      originalNativeClockLengthsExecuted: false, freshCadExecuted: false, accepted49: false, fabricationReady: false } }
}
export { registerClockInnerPorts }
export default () => buildCombinedClockV11FidelitySource().element
