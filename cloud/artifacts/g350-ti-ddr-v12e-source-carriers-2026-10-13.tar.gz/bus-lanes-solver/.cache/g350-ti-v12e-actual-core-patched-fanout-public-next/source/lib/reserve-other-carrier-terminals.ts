import type { Connection, SimpleRouteJson } from "./types"
import type { Copper } from "./vector-scene"

const ownersOf = (connection: Connection) => [
  ...new Set(
    [
      connection.name,
      connection.source_trace_id,
      ...connection.pointsToConnect.flatMap((point) => [
        point.pointId,
        point.pcb_port_id,
      ]),
    ].filter((owner): owner is string => !!owner),
  ),
]

/** Provisional copper protects every other net's existing landing on the
 * paired carrier. It reserves no new sites or drilled holes. */
export function reserveOtherCarrierTerminals(
  input: SimpleRouteJson,
  pair: NonNullable<SimpleRouteJson["differentialPairs"]>[number],
): Copper[] {
  const pairConnections = input.connections.filter((connection) =>
    pair.connectionNames.includes(connection.name),
  )
  const layer = pairConnections[0]?.pointsToConnect[0]?.layer
  if (!layer) return []
  const pairOwners = new Set(pairConnections.flatMap(ownersOf))
  const layers = Array.from({ length: input.layerCount }, (_, i) =>
    i === 0 ? "top" : i === input.layerCount - 1 ? "bottom" : `inner${i}`,
  )
  const reservations: Copper[] = []
  for (const connection of input.connections) {
    const owners = ownersOf(connection)
    if (owners.some((owner) => pairOwners.has(owner))) continue
    const width =
      input.buses?.find((bus) => bus.connectionNames.includes(connection.name))
        ?.traceWidth ??
      connection.nominalTraceWidth ??
      connection.width ??
      input.minTraceWidth
    for (const point of connection.pointsToConnect) {
      if (point.layer !== layer) continue
      let radius = width / 2
      // Only a supplied, owned via at this exact landing can justify reserving
      // a larger land. A carrier layer or minViaPadDiameter alone cannot.
      for (const trace of input.traces ?? []) {
        if (
          ![trace.connection_name, trace.source_trace_id].some(
            (owner) => owner && owners.includes(owner),
          )
        )
          continue
        for (const via of trace.route) {
          if (
            via.route_type !== "via" ||
            via.x !== point.x ||
            via.y !== point.y ||
            !Number.isFinite(via.via_diameter) ||
            !(via.via_diameter! > 0)
          )
            continue
          const from = layers.indexOf(via.from_layer),
            to = layers.indexOf(via.to_layer)
          if (from < 0 || to < 0) continue
          const physicalSpan = layers.slice(
            Math.min(from, to),
            Math.max(from, to) + 1,
          )
          const span = via.layers ?? physicalSpan
          if (physicalSpan.includes(layer) && span.includes(layer))
            radius = Math.max(radius, via.via_diameter! / 2)
        }
      }
      const duplicate = reservations.find(
        (copper) =>
          copper.a.x === point.x &&
          copper.a.y === point.y &&
          copper.owners.some((owner) => owners.includes(owner)),
      )
      if (duplicate) {
        duplicate.radius = Math.max(duplicate.radius, radius)
        duplicate.owners = [...new Set([...duplicate.owners, ...owners])]
      } else {
        const center = { x: point.x, y: point.y }
        reservations.push({ a: center, b: center, radius, layer, owners })
      }
    }
  }
  return reservations
}
