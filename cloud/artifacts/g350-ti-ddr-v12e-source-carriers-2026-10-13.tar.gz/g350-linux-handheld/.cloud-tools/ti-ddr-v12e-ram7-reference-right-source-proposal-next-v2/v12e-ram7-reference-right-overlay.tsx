import {Children, cloneElement, isValidElement, type ReactElement, type ReactNode} from "react"
import {buildV12dSource} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12d-byte0-top-reset-bottom-next/v12d-final-layer-overlay"

type Props=Record<string,unknown>&{name?:string;children?:ReactNode}
const moves=[
 {name:"C_DDR_RAM_7",oldX:6.8,pcbX:8.2,pcbY:8.75},
 {name:"V_TI_RAM7_POWER",oldX:7.85,pcbX:9.25,pcbY:8.75},
 {name:"V_TI_RAM7_GROUND",oldX:7.65,pcbX:9.05,pcbY:8.15},
] as const
const close=(a:unknown,b:number,label:string)=>{
 if(typeof a!=="number"||!Number.isFinite(a)||Math.abs(a-b)>1e-9)throw Error("V12e original placement mismatch: "+label)
}
/** New source-only proposal. Exactly one real cap and its two same-net owned
 * reference aliases move rigidly +1.4X. All49 CPU/RAM contacts stay fixed. The
 * original relative manual-path props stay untouched, so each owned reference
 * stub follows both endpoints. No Core/render/native/router call here. */
export function buildV12eSource(){
 const base=buildV12dSource();const changed=new Map<string,Record<string,unknown>>()
 const manualPaths=new Map<string,unknown>()
 function apply(node:ReactNode):ReactNode{
  if(!isValidElement<Props>(node))return node
  const p={...node.props};const move=moves.find(m=>m.name===p.name)
  if(move){
   if(changed.has(move.name))throw Error("Exactly three named placement props required")
   close(p.pcbX,move.oldX,move.name+" X");close(p.pcbY,move.pcbY,move.name+" Y")
   if(move.name==="C_DDR_RAM_7"){
    if(p.layer!=="bottom")throw Error("RAM7 capacitor must stay Bottom")
    close(p.pcbRotation,0,"RAM7 capacitor rotation")
   }else{
    if(node.type!=="via"||p.fromLayer!=="top"||p.toLayer!=="bottom"||
     p.outerDiameter!==.4572||p.holeDiameter!==.254||
     p.connectsTo!==(move.name==="V_TI_RAM7_POWER"?"net.DDR_1V5":"net.GND"))
     throw Error("Original two full-depth same-net reference via declarations required")
   }
   p.pcbX=move.pcbX
   changed.set(move.name,{name:move.name,oldX:move.oldX,pcbX:p.pcbX,pcbY:p.pcbY})
  }
  if(node.type==="trace"&&["TI_RAM7_POWER_BYPASS","TI_RAM7_GROUND_BYPASS"].includes(p.name??"")){
   if(manualPaths.has(p.name!))throw Error("Exactly two original manual reference traces required")
   manualPaths.set(p.name!,{name:p.name,from:p.from,to:p.to,thickness:p.thickness,pcbPath:p.pcbPath})
  }
  return cloneElement(node as ReactElement<Props>,p,...Children.toArray(node.props.children).map(apply))
 }
 const element=apply(base.element)
 if(changed.size!==3||manualPaths.size!==2)throw Error("One cap, two owned vias and two original manual stubs required")
 return {...base,element,placementProposal:{rigidTranslationMm:{x:1.4,y:0},
  changedProps:moves.map(m=>changed.get(m.name)!),manualReferencePathPropsUnchanged:[...manualPaths.values()],
  original49CpuRamContactsMoved:false,actualNewCoreForwardPerformed:false,actualNewNativePlacementChecksPerformed:false,
  referenceQualified:false,TIplaneArrangement:false,accepted49:false,fabricationReady:false}}
}
export default()=>buildV12eSource().element
