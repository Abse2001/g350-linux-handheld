"""Stdlib-only future actual Source/types/Core0 prerequisite verifier.

No template is authorization. Root supplies real collected artifacts after
execution; this module never launches/imports SDK/Core/Native applications.
"""
import argparse,hashlib,json,re,stat
from pathlib import Path
BOARD=Path('/workspace/g350-linux-handheld')
SOURCE18='deb65c68de4f7852e9ca1f693251574affaab4fb7ce27a07dfd70144e2641707'
CORE18='1159cf6013a1a32820568ae1a2c87e35b9a77176698c07c92a5de803dd2b9dd9'
SDK='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'
SOLVER='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
ACTUAL={
 'capture':{'phase':'capture','path':'/workspace/bus-lanes-solver/.cache/root-routing-progress/strict18-smooth-capture-16609-COLLECTED-root.json','sha256':'d1f2c7086869239768e9e2451c5295649d24c906650849891787355b5410c02e','tool':16609,'scope':'ACTUAL_SMOOTHED_STRICT18_CAPTURE_SOURCE_SUCCESSOR'},
 'types':{'phase':'types','path':'/workspace/bus-lanes-solver/.cache/root-routing-progress/strict18-smooth-types-99816-COLLECTED-root.json','sha256':'9fad326409268b7eb8f45813772db16dc698092592bade987450cd62c7b8090e','tool':99816,'scope':'ACTUAL_SMOOTHED_STRICT18_TYPES_SOURCE_SUCCESSOR'},
 'core':{'phase':'core','path':'/workspace/bus-lanes-solver/.cache/root-routing-progress/strict18-smooth-core-56795-COLLECTED-root.json','sha256':'8a0e5d76e9c1a85584c8ebf78db4abc438b5d1c94caf0f77b745f07c62755494','tool':56795,'scope':'ACTUAL_SMOOTHED_STRICT18_CORE_SOURCE_SUCCESSOR'}
}
def require(value,label):
 if not value:raise ValueError(label)
def sha(path):
 digest=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):digest.update(block)
 return digest.hexdigest()
def read(path):
 path=Path(path);require(path.is_absolute() and path.is_file() and not path.is_symlink() and path.stat().st_size<=32*1024*1024,'Concrete finite regular JSON input');return json.loads(path.read_bytes())
def exact(row):
 require(isinstance(row.get('sha256'),str) and re.fullmatch('[0-9a-f]{64}',row['sha256']) and sha(row['path'])==row['sha256'],'Exact actual bound artifact');return read(row['path'])
def verifyrows(rows):
 for row in rows:
  path=Path(row['path']);state=path.lstat();require(path.is_absolute() and stat.S_ISREG(state.st_mode) and not path.is_symlink(),'Regular bound Source')
  require(state.st_size==row['bytes'] and stat.S_IMODE(state.st_mode)==row['mode'] and sha(path)==row['sha256'],'Exact Source bytes/mode '+str(path))
def validate_collection(collection,post,phase,expected):
 require(expected.get('phase')==phase and isinstance(expected.get('tool'),int) and expected['tool']>0 and isinstance(expected.get('scope'),str),'Actual phase/session/scope binding, never a future template')
 require(collection['authorizedByRoot'] is True and collection['toolSessionId']==expected['tool'] and collection['scope']==expected['scope'],'Exact actual Root phase/session/scope')
 scope=collection['scope'].upper();require(('SOURCE' in scope and 'CAPTURE' in scope) if phase=='capture' else ('TYPE' in scope if phase=='types' else 'CORE' in scope),'Collection describes its actual required stage')
 require(collection['toolSessionCollected'] is True and collection['toolExitCode']==collection['toolWrapperExitCode']==0 and collection['passed'] is True,'Actual collected natural0 required; old failed54946 is not success')
 require(collection['sourceManifestSha256']==post['sourceManifestSha256']==SOURCE18,'Actual new smoothed Source147, not old be196')
 if phase!='capture':require(collection['coreSourceManifestSha256']==post['coreSourceManifestSha256']==CORE18,'Actual new Core1159, not old6c4')
 require(collection['sourceAndDependenciesHeld'] is True and post['sourceAndDependenciesHeld'] is True and post['passed'] is True,'Actual Source/SDK held')
 execution=collection['execution'];require(execution==post['execution'] and execution['exitCode']==0 and execution['diagnosticStopped'] is False and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values()),'Actual clean closed0/OOM0 execution')
 require(post['dependenciesBefore']==post['dependenciesAfter'] and post['dependenciesAfter']['treeSha256']==SDK,'Exact Ce3 before/after')
 require(post['solverDependenciesBefore']==post['solverDependenciesAfter'] and post['solverDependenciesAfter']['treeSha256']==SOLVER,'Exact47633 before/after')
 require(collection['accepted49'] is False and collection['fabricationReady'] is False,'No broader qualification')
 if phase=='core':require(collection['coreCalls']==1,'One actual fresh Core render')
 return execution['pgid']
def validate_binding(manifest,authority,manifest_sha):
 require(authority.get('authorizedByRoot') is True and authority.get('scope')==manifest['scope'] and authority.get('packetSha256')==manifest_sha,'A source-only template cannot authorize')
 require(authority.get('rootFullGuardReadPassed') is True and authority.get('noConcurrentRootWorker') is True and authority.get('allPreviousRootWorkersCollected') is True,'Actual Root full read/serial closure')
 require(re.fullmatch('[0-9a-f]{32,128}',authority.get('approvalToken','')) is not None,'Fresh Root finite token')
 require(manifest.get('sourceManifestSha256') and authority.get('sourceManifestSha256')==manifest['sourceManifestSha256'],'Exact new Native/API Source seal')
 require(authority.get('coreSourceManifestSha256')==manifest.get('coreSourceManifestSha256')==CORE18 and authority.get('freshArtifacts')==manifest['actualFreshArtifacts'],'Exact future actual smoothed Core authority')
 policy=manifest['policy'];require(authority.get('policy')==policy and policy['wallSeconds']<=90 and policy['rssBytes']<=1073741824 and policy['sharedBytes']==32212254720 and manifest['preforkReserveBytes']==1073741824,'Original bounded Native1GiB/shared30GiB+1GiBreserve policy')
 require(authority.get('requiredActualCollections')==manifest['requiredActualCollections']==ACTUAL,'All three exact actual new preceding stage bindings')
 verifyrows(manifest['files']);verifyrows(manifest['externalFiles'])
 peer=exact(authority['nativeSourcePeerReview']);require(peer['sourceManifestSha256']==manifest['sourceManifestSha256'] and peer['decision']=='GO_SOURCE_ONLY_TO_ROOT_READ_AND_GUARDED_SMOOTH_STRICT18_NATIVE_ALL3_APIS','Finite source-only peer review')
 pgids=[];posts={}
 for phase in ['capture','types','core']:
  row=manifest['requiredActualCollections'][phase];collection=exact(row);post=exact({'path':collection['postauditPath'],'sha256':collection['postauditSha256']});posts[phase]=post
  pgids.append(validate_collection(collection,post,phase,row));verifyrows(post.get('outputFiles',[]))
 artifacts=manifest['actualFreshArtifacts'];post=posts['core'];require(post['rawCorePath']==artifacts['actualCorePath'] and post['rawCoreSha256']==artifacts['actualCoreSha256'] and post['coreControlsPath']==artifacts['coreControlsPath'] and post['coreControlsSha256']==artifacts['coreControlsSha256'],'Artifacts must be actual fresh Core0 outputs')
 raw=exact({'path':artifacts['actualCorePath'],'sha256':artifacts['actualCoreSha256']});controls=exact({'path':artifacts['coreControlsPath'],'sha256':artifacts['coreControlsSha256']})
 require(all(any(row['path']==path and row['sha256']==digest for row in post['outputFiles']) for path,digest in [(artifacts['actualCorePath'],artifacts['actualCoreSha256']),(artifacts['coreControlsPath'],artifacts['coreControlsSha256'])]),'Actual raw/controls collected as outputs')
 require(controls['rawCorePath']==artifacts['actualCorePath'] and controls['rawCoreSha256']==artifacts['actualCoreSha256'] and controls['freshCoreControlPassed'] is True and len(controls['checks'])==120 and all(c['passed'] is True for c in controls['checks']),'Actual120 new Core controls')
 require(controls['automaticCoreSrjForThisForkMustNotBeUsed'] is True and controls['expectedMissingOriginalSignalCount']==31,'Manual18/incomplete49 contract')
 require(sum(r['type']=='pcb_via' for r in raw)==225 and sum(r['type']=='pcb_trace' for r in raw)==279,'Actual preserved225/279 inventory')
 return {'actualPreviousPgids':pgids,'rootOuterMustIndependentlyRequireOwnedGroupsEmptyNow':True,'rootOuterMustReinventoryCe3And47633BeforeAndAfter':True,'rootOuterMustRequireSharedCurrentPlusRssPlus1GiBReserveBelow30GiB':True,'authorizedByThisValidator':False,'actualApplicationCalls':0}
def main():
 parser=argparse.ArgumentParser();parser.add_argument('binding',type=Path);parser.add_argument('binding_sha');parser.add_argument('root_authority',type=Path);parser.add_argument('root_authority_sha');args=parser.parse_args();manifest=exact({'path':str(args.binding),'sha256':args.binding_sha});authority=exact({'path':str(args.root_authority),'sha256':args.root_authority_sha});print(json.dumps(validate_binding(manifest,authority,args.binding_sha)))
if __name__=='__main__':main()
