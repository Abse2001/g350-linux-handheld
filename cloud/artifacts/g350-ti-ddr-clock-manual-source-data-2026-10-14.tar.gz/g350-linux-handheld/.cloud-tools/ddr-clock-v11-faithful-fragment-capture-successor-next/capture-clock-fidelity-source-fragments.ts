/** Root-only Source evaluation. Frozen ancestors load Core definitions;
 * this worker constructs/renders no Circuit. Known Fragments remain intact. */
import { Children, Fragment, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { readFileSync, writeFileSync, existsSync } from "node:fs"
import { createHash } from "node:crypto"
import assert from "node:assert/strict"
import { buildCombinedLocalSource } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-signal96-joint-native-sourceonly-next/combined-source-overlay"
import { buildCombinedClockV11FidelitySource } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-signal96-clock-v11-source-contract-next/clock-fidelity-source-overlay"
import proposal from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-signal96-clock-v11-source-contract-next/clock-fidelity-source-proposal.json"
const [output, diagnostic, ...extra] = process.argv.slice(2)
assert.equal(process.env.G350_CLOCK_FIDELITY_SOURCE_APPROVED, "1")
assert.ok(output && diagnostic && extra.length === 0 && output !== diagnostic && !existsSync(output) && !existsSync(diagnostic))
assert.equal(process.versions.bun, "1.3.14")
type Row = { kind: "literal" | "fragment" | "primitive" | "unsupported"; isReactElement: boolean; type: string; key: string | null;
  props: Record<string, unknown>; children: Row[]; value?: unknown }
const actualFragmentIdentity: unknown = Fragment
const digest = (raw: string | Buffer) => createHash("sha256").update(raw).digest("hex")
function identity(node: ReactNode): ReactNode {
  if (!isValidElement<Record<string, unknown>>(node)) return node
  return cloneElement(node as ReactElement<Record<string, unknown>>, { ...node.props },
    ...Children.toArray(node.props.children as ReactNode).map(identity))
}
function snapshot(node: ReactNode): Row {
  if (!isValidElement<Record<string, unknown> & { children?: ReactNode }>(node)) {
    const allowed = node === null || node === undefined || typeof node === "boolean" || typeof node === "string" || typeof node === "number"
    return { kind: allowed ? "primitive" : "unsupported", isReactElement: false, type: typeof node, key: null, value: node,
      props: {}, children: [] }
  }
  const { children, ...props } = node.props
  // The actual imported Fragment identity is the sole permitted container.
  // A different Symbol with an identical printed name still fails closed.
  const actualType: unknown = node.type
  const kind = typeof actualType === "string" ? "literal" : typeof actualType === "symbol" && actualType === actualFragmentIdentity ? "fragment" : "unsupported"
  const type = kind === "literal" ? actualType as string : kind === "fragment" ? "React.Fragment"
    : `${typeof actualType}:${typeof actualType === "function" ? actualType.name : String(actualType)}`
  return { kind, isReactElement: true, type, key: node.key, props, children: Children.toArray(children).map(snapshot) }
}
const baselineSource = buildCombinedLocalSource()
const baseline = snapshot(identity(baselineSource.element)), source = buildCombinedClockV11FidelitySource(), actual = snapshot(source.element)
function flatten(row: Row): Row[] { return [row, ...row.children.flatMap(flatten)] }
const oldRows = flatten(baseline), rows = flatten(actual)
const counts = (all: Row[]) => ({ literalStrings: all.filter(r => r.kind === "literal").length,
  fragmentContainers: all.filter(r => r.kind === "fragment").length,
  primitiveChildren: all.filter(r => r.kind === "primitive").length,
  unsupportedTypes: all.filter(r => r.kind === "unsupported").length,
  reactElements: all.filter(r => r.isReactElement).length })
const beforeCounts = counts(oldRows), afterCounts = counts(rows)
const unsupported = (all: Row[]) => all.filter(r => r.kind === "unsupported").map(r => ({ type: r.type, key: r.key, name: r.props.name }))
// Preserve actual diagnostics before any allowed-type/count/inverse assertion.
// These descriptors record functions/Symbols as data and never invoke them.
const diagnosticReplacer = (_key: string, value: unknown) => typeof value === "symbol"
  ? { diagnosticSymbol: String(value), globalSymbolKey: Symbol.keyFor(value) ?? null }
  : typeof value === "function" ? { diagnosticFunction: value.name, functionSourceSha256: digest(value.toString()) } : value
const diagnosticReport = { scope: "ACTUAL_SOURCE_TREE_DIAGNOSTIC_BEFORE_FRAGMENT_AND_INVERSE_ASSERTIONS",
  beforeCounts, afterCounts, beforeUnsupportedTypes: unsupported(oldRows), afterUnsupportedTypes: unsupported(rows),
  recognizedFragmentIdentity: String(actualFragmentIdentity), fragmentGlobalSymbolKey: typeof actualFragmentIdentity === "symbol" ? Symbol.keyFor(actualFragmentIdentity) : null,
  actualBaselineTree: baseline, actualProposedTree: actual, inverseChecksExecutedWhenDiagnosticWasWritten: false,
  transitiveFrozenSourceImportsCoreDefinitions: true, circuitConstructedByThisWorker: false,
  coreRendered: false, nativeExecuted: false, cadExecuted: false, fabricationReady: false }
writeFileSync(diagnostic, `${JSON.stringify(diagnosticReport, diagnosticReplacer, 2)}\n`, { flag: "wx", mode: 0o600 })
assert.equal(typeof actualFragmentIdentity, "symbol", "The exact pinned React.Fragment Symbol is required")
assert.equal(beforeCounts.unsupportedTypes, 0, "Unknown element Symbols/functions and unknown primitive types remain unsupported")
assert.equal(afterCounts.unsupportedTypes, 0, "Only actual React.Fragment containers are supported")
assert.equal(beforeCounts.reactElements, 2228); assert.equal(afterCounts.reactElements, 2232)
assert.equal(afterCounts.literalStrings-beforeCounts.literalStrings, 4, "Exactly four real literal Port elements added")
assert.equal(afterCounts.fragmentContainers, beforeCounts.fragmentContainers, "No Fragment container removed or added")
const rawActual = JSON.stringify(actual, diagnosticReplacer)
function cloneSnapshot(row: Row): Row { return { ...row, props: { ...row.props }, children: row.children.map(cloneSnapshot) } }
const restored = cloneSnapshot(actual), changes = source.exactDeclaredPcbOnlyChanges
const viaNames = new Set(proposal.clockCarriers.flatMap(c => [c.cpu.viaName, c.ram.viaName]))
let removedPorts = 0, inverseClockChanges = 0, inverseTopChanges = 0
for (const row of flatten(restored)) {
  if (row.kind === "literal" && viaNames.has(String(row.props.name))) {
    const remove = row.children.filter(c => c.kind === "literal" && c.type === "port" && c.props.name === "inner1" && c.props.layer === "inner1")
    assert.equal(remove.length, 1); row.children = row.children.filter(c => c !== remove[0]); removedPorts++
  }
  const change = changes.find(c => c.name === row.props.name)
  if (!change) continue
  assert.equal(row.kind, "literal"); assert.equal(row.type, "trace")
  if (change.action === "ADD_ORIGINAL_CLOCK_THREE_PCB_PATHS_ONLY") {
    delete row.props.pcbPaths; delete row.props.pcbPathRelativeTo; inverseClockChanges++
  } else { row.props.pcbPath = []; inverseTopChanges++ }
}
assert.equal(removedPorts, 4); assert.equal(inverseClockChanges, 2); assert.equal(inverseTopChanges, 4)
function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`
  if (value && typeof value === "object") return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical((value as Record<string, unknown>)[k])}`).join(",")}}`
  if (typeof value === "function") return `function:${value.toString()}`
  if (typeof value === "symbol") return `symbol:${String(value)}`
  return JSON.stringify(value) ?? "undefined"
}
assert.equal(canonical(restored), canonical(baseline), "Full inverse retains every literal/Fragment type, key, props and child order")
for (const key of Object.keys(baselineSource).filter(k => k !== "element"))
  assert.equal(canonical((source as Record<string, unknown>)[key]), canonical((baselineSource as Record<string, unknown>)[key]), `Original source metadata: ${key}`)
assert.equal(JSON.stringify(actual, diagnosticReplacer), rawActual, "Projection must not mutate actual proposed Source")
for (const clock of proposal.clockCarriers) {
  const row = rows.find(r => r.kind === "literal" && r.type === "trace" && r.props.name === clock.originalLogicalTraceName)!
  assert.equal(row.props.from, `${clock.cpu.package}.pin${clock.cpu.numericPin}`)
  assert.equal(row.props.to, `${clock.ram.package}.pin${clock.ram.numericPin}`)
  assert.equal(JSON.stringify(row.props.pcbPaths), JSON.stringify(clock.threePcbPaths))
}
const report = { scope: "ACTUAL_FRAGMENT_PRESERVING_CLOCK_FIDELITY_SOURCE_CAPTURE",
  proposalSha256: digest(readFileSync(new URL("../ddr-package101-signal96-clock-v11-source-contract-next/clock-fidelity-source-proposal.json", import.meta.url))),
  actualPureReactEvaluated: true, originalReactElementCount: beforeCounts.reactElements, proposedReactElementCount: afterCounts.reactElements,
  originalLiteralCount: beforeCounts.literalStrings, proposedLiteralCount: afterCounts.literalStrings,
  originalFragmentContainerCount: beforeCounts.fragmentContainers, proposedFragmentContainerCount: afterCounts.fragmentContainers,
  actualTreeDiagnosticPath: diagnostic, actualTreeDiagnosticSha256: digest(readFileSync(diagnostic)),
  exactInverseSourceProjectionPassed: true, originalLiteralTypesKeysPropsAndChildOrderCompared: true,
  allOriginalFragmentTypesKeysPropsAndChildOrderCompared: true, onlyActualReactFragmentIdentityAllowed: true,
  unknownElementSymbolsFunctionsRejected: true, allOriginalReturnedSourceMetadataCompared: true,
  addedRealLayerPorts: 4, changedPCBOnlyElements: 6, changedPCBProperties: 8,
  original49LogicalEndpointsBusMembershipAndNamedRailsUnchanged: true,
  actualSourceSnapshot: actual, declaredPCBOnlyChanges: changes,
  coreDirectlyImportedByThisWorker: false, transitiveFrozenSourceImportsCoreDefinitions: true,
  circuitConstructedByThisWorker: false, coreRendered: false, nativeExecuted: false, cadExecuted: false,
  actualPortMatchesRegistered: false, fullClockLengthNativeQualified: false, accepted49: false, fabricationReady: false }
writeFileSync(output, `${JSON.stringify(report, diagnosticReplacer, 2)}\n`, { flag: "wx", mode: 0o600 })
console.log(JSON.stringify({ scope: report.scope, originalReactElementCount: beforeCounts.reactElements,
  proposedReactElementCount: afterCounts.reactElements, originalLiteralCount: beforeCounts.literalStrings,
  proposedLiteralCount: afterCounts.literalStrings, fragmentContainers: beforeCounts.fragmentContainers,
  exactInverseSourceProjectionPassed: true, coreRendered: false, output, diagnostic }))
