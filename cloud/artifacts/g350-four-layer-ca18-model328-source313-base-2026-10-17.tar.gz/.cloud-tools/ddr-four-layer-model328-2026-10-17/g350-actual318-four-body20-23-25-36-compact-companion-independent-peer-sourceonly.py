"""Own stdlib compact companion verification, including true old failure pairs."""
exec(open('/tmp/g350-actual260-ca233-compatibility-sourceonly.py').read().split('if __name__')[0])
CP='/tmp/g350-actual318-four-body20-23-25-36-preferred-self-compact-companion-v3-report.json';CS='b26321aeef17b0af39852acb028f7ac092d8e0890d4db14ef5f32c7b57386205'
def pin(path,h):
 b=Path(path).read_bytes();assert hashlib.sha256(b).hexdigest()==h;return json.loads(b)
c=pin(CP,CS);m=pin(c['mainProofPath'],c['mainProofSha256']);assert c['mainProofSha256']=='3629499aaf79d74c300a77692accaba815eee80e3c7ba0ffc8c5358afa27cfeb';base=pin(c['inputPath'],c['inputSha256']);assert c['inputSha256']=='be1a7d412678c7942b3f3e22a8b4828826c3c90c806ff6257b74cbf528f7f731'
assert hashlib.sha256(Path(c['inputReportPath']).read_bytes()).hexdigest()==c['inputReportSha256']
strict=lambda a,b:json.dumps(a,separators=(',',':'))==json.dumps(b,separators=(',',':'))
def runs(t):
 z=[];cur=[]
 for i,p in enumerate(t['route']):
  if p['route_type']=='wire':cur.append((i,p))
  else:
   if cur:z.append(cur)
   cur=[]
 if cur:z.append(cur)
 return z
def resolve(ref):
 assert ref['path']==c['mainProofPath']and ref['sha256']==c['mainProofSha256'];q=m
 for x in ref['jsonPointer'].split('/')[1:]:q=q[int(x)]if isinstance(q,list)else q[x.replace('~1','/').replace('~0','~')]
 return q
by={x['owner']:x for x in m['bodyInverses']};summ=[]
for ownrow in c['allPerOwnerPerRunRows']:
 n=ownrow['owner'];iv=by[n];before=runs(iv['before']);after=runs(iv['after']);beforeFailures=[]
 for r in before:beforeFailures.append({tuple(z['segments'])for z in self_math([p for i,p in r],.3048)['failures']})
 failures=0
 for ri,rr in enumerate(ownrow['afterRunRows']):
  run=after[ri];assert rr['wholeRouteWireIndices']==[i for i,p in run]
  actual=self_math([p for i,p in run],.3048);pairs={tuple(z['segments'])for z in actual['failures']};assert pairs=={tuple(x[:2])for x in rr['preferredFailureMatrix']}
  assert resolve(rr['preferredFullRowsRef'])['failures']==actual['failures']
  assert resolve(rr['nativeFullRowsRef'])['passedPureMath']and rr['nativeSelfPassed']
  assert resolve(rr['allPreferredAllowedContiguousCornerAndMonotoneRowsRef'])==actual['allowedCloseLocalCornerPairs']
  for z in rr['preferredFailureMatrix']:
   a,b,wa,wb,bri,ba,bb,bwa,bwb,*truth=z;assert all(x is True for x in truth)
   assert(a,b)in pairs and(ba,bb)in beforeFailures[bri]
   assert run[a][0]==wa and run[b][0]==wb and before[bri][ba][0]==bwa and before[bri][bb][0]==bwb
   assert strict(run[a][1],before[bri][ba][1])and strict(run[a+1][1],before[bri][ba+1][1])and strict(run[b][1],before[bri][bb][1])and strict(run[b+1][1],before[bri][bb+1][1]);failures+=1
 assert failures==ownrow['inheritedPreferredFailureCount']and ownrow['introducedPreferredFailureCount']==0
 summ.append({'owner':n,'allPreferredAfterFailurePairsRecomputed':failures,'allPairsAlsoFailActualBeforeMath':True,'allFourObjectsOrderedLiteral':True})
cross=[];t=by['source_trace_25']['after'];rs=runs(t)
for z in c['source25BottomCrossRunChecks']:
 # The companion's matrices explicitly reference whole trace segment starts.
 vals=[]
 for a,b,wa,wb,d,na,pr in z['allPairMatrix']:
  aa,ab=t['route'][wa:wa+2];ba,bb=t['route'][wb:wb+2];assert aa['layer']==ab['layer']==ba['layer']==bb['layer']=='bottom';measured=sd(aa,ab,ba,bb);assert abs(measured-d)<1e-9 and na and pr and measured>=.3048-1e-8;vals.append(measured)
 # Every distinct pair across the two Bottom runs must be present exactly once.
 bot=[r for r in rs if r[0][1]['layer']=='bottom'];assert len(bot)==2
 expected={(a[0],b[0])for a in bot[0][:-1]for b in bot[1][:-1]};observed={(x[2],x[3])for x in z['allPairMatrix']};assert observed==expected
 cross.append({'pairCount':len(vals),'minimumMm':min(vals),'allActualPairsChecked':True,'nativeAnd3WPassed':True})
R={'scope':'INDEPENDENT_OWN_STDLIB_PREFERRED_SELF_COMPACT_COMPANION_TRUE_BEFORE_FAILURE_AND_NUMERIC_ENDPOINT_IDENTITY_PEER','companionPath':CP,'companionSha256':CS,'mainProofPath':c['mainProofPath'],'mainProofSha256':c['mainProofSha256'],'perOwner':summ,'source25CrossRunAudit':cross,'allJsonPointerRowsResolved':True,'independentCompanionPeerPassed':True,'SDKExecuted':False,'nativeExecuted':False,'sourceCoreDerived':False,'fullBoardTIQualification':False,'fabricationReady':False}
out=Path('/tmp/g350-actual318-four-body20-23-25-36-compact-companion-independent-peer-report.json');out.open('x').write(json.dumps(R,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'perOwner':summ,'crossRun':cross}))
