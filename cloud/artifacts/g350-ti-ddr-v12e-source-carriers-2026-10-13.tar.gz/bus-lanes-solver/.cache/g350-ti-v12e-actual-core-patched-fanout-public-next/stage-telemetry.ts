/** Bounded serialized public-hook telemetry; stores strings, never search objects. */
export const STAGE_TELEMETRY_LIMITS = {
  publicStepInterval: 5000,
  rollingRows: 16,
  serializedBytes: 128 * 1024,
  writes: 1603,
}

export function createStageTelemetry() {
  const rows: Array<{ raw: string; bytes: number }> = []
  let bytes = 0
  let droppedRows = 0
  let rejectedRows = 0
  let successfulPublications = 0
  let failedPublications = 0
  let lastBucket = -1
  const encode = (publicSteps: number, row: unknown, force = false): string | null => {
    if (!Number.isSafeInteger(publicSteps) || publicSteps < 0 || publicSteps > 8_000_000)
      throw Error("Original public step range required")
    const bucket = Math.floor(publicSteps / STAGE_TELEMETRY_LIMITS.publicStepInterval)
    if (!force && bucket === lastBucket) return null
    lastBucket = bucket
    const raw = `${JSON.stringify(row)}\n`
    const size = new TextEncoder().encode(raw).byteLength
    if (size > STAGE_TELEMETRY_LIMITS.serializedBytes) {
      rejectedRows++
      return null
    }
    while (rows.length >= STAGE_TELEMETRY_LIMITS.rollingRows || bytes + size > STAGE_TELEMETRY_LIMITS.serializedBytes) {
      bytes -= rows.shift()!.bytes
      droppedRows++
    }
    rows.push({ raw, bytes: size })
    bytes += size
    return rows.map(row => row.raw).join("")
  }
  return {
    encode,
    recordPublication(success: boolean) {
      if (success) successfulPublications++
      else failedPublications++
    },
    canPublish() {
      return successfulPublications + failedPublications < STAGE_TELEMETRY_LIMITS.writes
    },
    snapshot() {
      return { limits: { ...STAGE_TELEMETRY_LIMITS }, retainedRows: rows.length, serializedBytes: bytes, droppedRows, rejectedRows, successfulPublications, failedPublications, lastBucket, retainedInstances: false, retainedGeometry: false }
    },
  }
}
