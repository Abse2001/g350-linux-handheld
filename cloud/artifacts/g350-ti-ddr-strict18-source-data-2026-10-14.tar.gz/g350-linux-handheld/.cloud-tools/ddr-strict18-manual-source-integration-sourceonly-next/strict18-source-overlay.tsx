import { Children, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { buildManualPairClockV11Source, registerClockInnerPorts } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-clock-v11-manual-pair-source-successor-next/manual-pair-source-overlay"
import proposal from "./strict18-source-proposal.json"
type Props = Record<string, unknown> & { name?: string; children?: ReactNode }

/** Source-only manual successor. Every physical path is owned by its original
 * numeric Source trace; local logical branches remain without duplicate copper.
 * No planes, barrels, footprints, original constraints or ancestor files change. */
export function buildStrict18ManualSource() {
  const base = buildManualPairClockV11Source()
  const changed = new Set<string>(), suppressed = new Set<string>(), added = new Set<string>()
  let boards = 0
  const widenedBuses = new Set<string>()
  function fork(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const props = { ...node.props }, children = Children.toArray(props.children).map(fork)
    const layerFork = proposal.authorizedAllFourLayerFork.sourceBusAllowedLayerChanges.find(change => change.busId === props.name)
    if (layerFork) {
      if (node.type !== "bus" || widenedBuses.has(layerFork.busId)
        || JSON.stringify(props.pcbAllowedLayers) !== JSON.stringify(layerFork.originalAllowedLayers)
        || JSON.stringify(props.preferredLayers) !== JSON.stringify(layerFork.preferredLayersHeld))
        throw Error("Exact original authored class-bus allowed/preferred layers required")
      // Explicit user-authorized four-layer fork. Only this rendering/routing
      // layer list changes; original logical and timing constraints remain.
      props.pcbAllowedLayers = [...layerFork.newAllowedLayers]
      widenedBuses.add(layerFork.busId)
    }
    const requestedPorts = proposal.addedRealInnerLayerPorts.filter(port => port.viaName === props.name)
    if (requestedPorts.length) {
      if (requestedPorts.length !== 1 || node.type !== "via" || children.length !== 0
        || props.pcbX !== requestedPorts[0].viaXY.x || props.pcbY !== requestedPorts[0].viaXY.y
        || props.fromLayer !== "top" || props.toLayer !== "bottom" || props.outerDiameter !== .4572 || props.holeDiameter !== .254)
        throw Error("Unchanged genuine Source signal barrel with no prior children required")
      const port = requestedPorts[0], key = `${port.viaName}:${port.layer}`
      if ((port.layer !== "inner1" && port.layer !== "inner2") || added.has(key)) throw Error("One genuine new inner layer Port required")
      children.push(<port name={port.layer} layer={port.layer as "inner1" | "inner2"} />)
      added.add(key)
    }
    const change = proposal.newOriginalSignalChanges.find(change => change.originalLogicalTraceName === props.name)
    if (change) {
      if (node.type !== "trace" || changed.has(change.originalSourceTraceId) || props.from !== change.originalNumericFrom
        || props.to !== change.originalNumericTo || props.path !== undefined || props.pcbPath !== undefined
        || props.pcbPaths !== undefined || props.pcbPathRelativeTo !== undefined)
        throw Error("One untouched original numeric Source trace without pre-existing manual copper required")
      props.pcbPaths = change.newPcbPaths
      props.pcbPathRelativeTo = change.newPcbPathRelativeTo
      changed.add(change.originalSourceTraceId)
    }
    const owner = proposal.newOriginalSignalChanges.flatMap(change => [change.cpu, change.ram]).find(owner => owner.traceName === props.name)
    if (owner) {
      if (node.type !== "trace" || suppressed.has(owner.traceName) || props.from !== `${owner.package}.pin${owner.numericPin}`
        || props.to !== `.${owner.viaName} > port.top` || props.thickness !== .1016
        || !Array.isArray(props.pcbPath) || props.pcbPath.length !== 0 || props.pcbPaths !== undefined
        || props.pcbPathRelativeTo !== `.${owner.viaName} > port.top`)
        throw Error("Exactly32 original numeric-to-Top local branches required")
      // cloneElement omission does not remove old props. Explicit undefined is
      // the actually tested manual7ff suppression contract; logical props stay.
      props.pcbPath = undefined
      suppressed.add(owner.traceName)
    }
    if (node.type === "board") {
      boards++
      if (props.layers !== 4 || props.routeRemaining !== false || (props.pcbX ?? 0) !== 0
        || (props.pcbY ?? 0) !== 0 || (props.pcbRotation ?? 0) !== 0) throw Error("Original manual four-layer board required")
    }
    return cloneElement(node as ReactElement<Props>, props, ...children)
  }
  const element = fork(base.element)
  if (boards !== 1 || changed.size !== 16 || suppressed.size !== 32 || added.size !== 24 || widenedBuses.size !== 4)
    throw Error("Exact16 direct originals/32 local suppressions/24 real Ports required")
  return { ...base, element, strict18SourceProposal: proposal,
    strict18SourceIntegration: { scope: "UNEXECUTED_MANUAL_SOURCE_ONLY_STATIC18_INTEGRATION", original144AncestorFilesUnchanged: true,
      originalClock33_34PropsHeld: true, original49LogicAnd8BusesAnd98NamedRailsHeld: true,
      explicitAuthorizedBusAllowedLayerFork: proposal.authorizedAllFourLayerFork,
      addedRealPorts: [...added], changedOriginalIds: [...changed], suppressedLocalTraceNames: [...suppressed],
      physicalBarrelCountHeld: 225, expectedPhysicalTraceCount: 279, sourcePortIdsMustBeDerivedFromActualFreshCore: true,
      referenceShadowUnqualified: true, automaticCoreSrjForThisForkMustNotBeUsed: true,
      originalCouplingAPIsRequiredAgainstActualFreshGeometry: true, sourceExecuted: false,
      coreRendered: false, nativeExecuted: false, cadExecuted: false, complete18Accepted: false, fabricationReady: false } }
}

type Via = { componentName: string; props: Props; pcb_via_id?: string | null }
type Port = { componentName: string; props: Props; parent: unknown; matchedComponents: unknown[];
  source_port_id?: string | null; pcb_port_id?: string | null; registerMatch(component: unknown): void; getAvailablePcbLayers(): string[] }
type Circuit = { _hasRenderedAtleastOnce?: boolean; schematicDisabled?: boolean; selectOne(selector: string, options?: { type?: string }): unknown }

/** Match actual newly declared Port children to their existing Via before the
 * first render. Reuse the four qualified clock registrations unchanged. */
export function registerStrict18InnerPorts(circuitUnknown: unknown) {
  const circuit = circuitUnknown as Circuit
  if (circuit._hasRenderedAtleastOnce || circuit.schematicDisabled !== true) throw Error("Actual PCB-only unrendered circuit required")
  const clock = registerClockInnerPorts(circuitUnknown), registrations: Array<{ viaName: string; layer: string; xy: { x: number; y: number }; numericSelector: string }> = []
  for (const requested of proposal.addedRealInnerLayerPorts) {
    const via = circuit.selectOne(`.${requested.viaName}`) as Via | null
    const port = circuit.selectOne(`.${requested.viaName} > port.${requested.layer}`, { type: "port" }) as Port | null
    if (!via || via.componentName !== "Via" || via.props.name !== requested.viaName
      || via.props.pcbX !== requested.viaXY.x || via.props.pcbY !== requested.viaXY.y || via.props.fromLayer !== "top"
      || via.props.toLayer !== "bottom" || via.props.outerDiameter !== .4572 || via.props.holeDiameter !== .254
      || !port || port.componentName !== "Port" || port.parent !== via || port.props.name !== requested.layer
      || port.props.layer !== requested.layer || port.source_port_id || port.pcb_port_id || via.pcb_via_id
      || port.getAvailablePcbLayers().join(",") !== requested.layer || port.matchedComponents.some(owner => owner !== via))
      throw Error("Actual unrendered real layer child and its one existing full-span barrel required")
    if (!port.matchedComponents.includes(via)) port.registerMatch(via)
    if (port.matchedComponents.length !== 1 || port.matchedComponents[0] !== via) throw Error("Exact genuine Port/Via ownership match required")
    registrations.push({ viaName: requested.viaName, layer: requested.layer, xy: requested.viaXY, numericSelector: requested.numericSelector })
  }
  if (registrations.length !== 24 || clock.registrations.length !== 4) throw Error("Exactly28 real inner-Port matches required")
  return { unchangedQualifiedClockRegistrations: clock.registrations, newStrict18Registrations: registrations,
    physicalViaAdded: false, sourceExecuted: false, coreRendered: false, nativeExecuted: false }
}
export default () => buildStrict18ManualSource().element
