/** FOCUSED47 SOURCE ONLY (original32-check worker remains frozen): authored without executing/importing this worker or its dependencies.
 * Root executes this read-only diagnostic under its external 180s/2GB guard.
 * No missing-route/timing findings are filtered, waived, or converted to acceptance.
 */
import * as fs from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { pathToFileURL } from 'node:url'
import { resolve } from 'node:path'

const CHECKS = '/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js'
const CHECKS_SHA = '1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc'
const PLAN224 = '/tmp/g350-manual47-projector-root-20261016-run224/byte0-result.json'
const PLAN224_SHA = '0f462f73f6fed6232f22c1bfb757474aa370a511ac45bfd9301a5bcb30795abf'
const CANDIDATE223_SHA = 'ddaa4efd8d20f16cefca89b9166e834a956113194beed6f0f13903e346e36ea0'
const PRIOR185 = '/tmp/g350-native45-root-20261016-run185/byte0-result.json'
const PRIOR185_SHA = 'fd4517b48526b1cddb77de5227646d195c5786f09db2dcb2c3477d4e16912c88'
const sha = (data: string | Uint8Array) => createHash('sha256').update(data).digest('hex')
const insist = (condition: unknown, message: string): asserts condition => { if (!condition) throw new Error(message) }
const clone = <T>(value: T): T => structuredClone(value)
const diagnostic = (error: any) => ({ name: error?.name ?? 'Error', message: String(error?.message ?? error), stack: error?.stack ?? null })

// The physical10 are exactly the public g350-ddr-physical-checks.mjs roster.
const PHYSICAL10 = [
  'checkEachPcbTraceNonOverlapping', 'checkViaPadClearance', 'checkViaTraceClearance',
  'checkPcbTraceSelfShorts', 'checkCopperToBoardEdgeClearance', 'checkDifferentNetViaSpacing',
  'checkHoleTraceClearance', 'checkPadTraceClearance', 'checkViasInPads', 'checkViasOffBoard',
]
// Preserve the full historical32 roster; this successor executes only the
// explicitly requested physical/contiguity/constraint checks below.
const ORIGINAL32_NAMES = [
  'checkSourceTracesHavePcbTraces', 'checkEachPcbPortConnectedToPcbTraces',
  'checkSourceTracesMatchPcbTraceThickness', 'checkPcbTraceLengths',
  'checkPcbBusLengthSkew', 'checkPcbRoutingConstraints', 'checkPcbTraceViaCounts',
  'checkTracesAreContiguous', 'checkDanglingTraces',
  ...PHYSICAL10,
  'checkSameNetViaSpacing', 'checkCopperPourShorts', 'checkPadPadClearance',
  'checkPcbTracesOutOfBoard', 'checkPcbBendZoneTraces',
  'checkPcbComponentsOutOfBoard', 'checkPcbComponentOverCutout',
  'checkPcbCopperOverKeepout', 'checkPcbComponentOverlap',
  'checkPinMustBeConnected', 'checkSameNameNetsAreConnected',
  'checkSourcePinVoltageCompatibility', 'checkTwoTerminalSwitchContactsOnDifferentNets',
]

const CHECK_NAMES = [...PHYSICAL10, 'checkTracesAreContiguous', 'checkDanglingTraces', 'checkPcbBusLengthSkew', 'checkPcbRoutingConstraints', 'checkPcbTraceViaCounts', 'checkCopperPourShorts']
const NOT_RETESTED_NAMES = ORIGINAL32_NAMES.filter(name => !CHECK_NAMES.includes(name))

function bridgeObservations(raw: any[], controls: any) {
  const projection = controls.logical49Projection
  const graphs = new Map(controls.physicalGraphs.map((g: any) => [g.originalSourceTraceId, g]))
  const pcbTraces = raw.filter((r: any) => r.type === 'pcb_trace')
  const rows = projection.map((p: any) => {
    const connected = (graphs.get(p.originalSourceTraceId) as any)?.physicallyConnectedByActualOwnedNumericIdGraph === true
    const owned = pcbTraces.filter((t: any) => t.source_trace_id === p.actualSourceTraceId)
    let planarLengthMm = 0
    for (const trace of owned) {
      const route = trace.route ?? []
      for (let i = 1; i < route.length; i++) {
        const a = route[i - 1], b = route[i]
        if (a.route_type !== 'wire' || b.route_type !== 'wire' || a.layer !== b.layer) continue
        insist([a.x, a.y, b.x, b.y].every(Number.isFinite), `Nonfinite wire in ${trace.pcb_trace_id}`)
        planarLengthMm += Math.hypot(b.x - a.x, b.y - a.y)
      }
    }
    return { originalSourceTraceId: p.originalSourceTraceId, actualSourceTraceId: p.actualSourceTraceId,
      name: p.name, connected, pcbTraceIds: owned.map((t: any) => t.pcb_trace_id),
      planarLengthMm: connected ? planarLengthMm : null }
  })
  const byName = new Map(rows.map((r: any) => [r.name, r]))
  const findings: any[] = []
  const cohorts = controls.sourceRuleBridge.effectiveCohorts.map((bus: any) => {
    const props = bus.props, members = props.connections.map((name: string) => {
      const row: any = byName.get(name)
      insist(row, `Effective bus ${bus.name} has unmapped member ${name}`)
      if (!row.connected) findings.push({ kind: 'missing_logical_owner', cohort: bus.name, ...row })
      else {
        if (Number.isFinite(props.minLength) && row.planarLengthMm < props.minLength - 1e-8)
          findings.push({ kind: 'below_source_minimum_length', cohort: bus.name, minimumMm: props.minLength, ...row })
        if (Number.isFinite(props.maxLength) && row.planarLengthMm > props.maxLength + 1e-8)
          findings.push({ kind: 'above_source_maximum_length', cohort: bus.name, maximumMm: props.maxLength, ...row })
      }
      return row
    })
    const measured = members.filter((r: any) => r.connected).map((r: any) => r.planarLengthMm)
    const skew = measured.length >= 2 ? Math.max(...measured) - Math.min(...measured) : null
    if (skew !== null && skew > props.maxLengthSkew + 1e-8)
      findings.push({ kind: 'source_cohort_length_skew', cohort: bus.name, measuredMm: skew, maximumMm: props.maxLengthSkew })
    return { name: bus.name, originalMemberNames: props.connections, minLengthMm: props.minLength ?? null,
      maxLengthMm: props.maxLength ?? null, maxLengthSkewMm: props.maxLengthSkew,
      routedMembers: measured.length, totalMembers: members.length, routedSubsetSkewMm: skew, members }
  })
  return { observationsOnly: true, usedAsAcceptanceGate: false, measurementsFromExactRawRows: true,
    lengthModel: 'Sum same-layer consecutive wire-center segments for each mapped fresh source_trace; no guessed via depth; disconnected owners remain null, never zero.',
    electricalDelayQualified: false, all49Complete: false, rows, cohorts, findings,
    preservedCoreTimingObservations: controls.timingObservations,
    sourceRuleBridge: controls.sourceRuleBridge }
}

export async function runPartial47FocusedNativeChecks(options: { inputPath: string; inputSha256: string; controlsPath: string; controlsSha256: string; output: string; budgetMs?: number }) {
  const started = performance.now()
  const budgetMs = options.budgetMs ?? 165_000
  insist(Number.isInteger(budgetMs) && budgetMs >= 1_000 && budgetMs <= 165_000, 'budget-ms must be integer 1000..165000')
  insist(/^[0-9a-f]{64}$/.test(options.inputSha256) && /^[0-9a-f]{64}$/.test(options.controlsSha256), 'Mandatory exact lowercase64-hex raw and controls SHA256 pins')
  const rawPath = resolve(options.inputPath), controlsPath = resolve(options.controlsPath)
  const RAW_SHA = options.inputSha256, CONTROLS_SHA = options.controlsSha256
  const output = resolve(options.output)
  insist(![rawPath, controlsPath, CHECKS, PRIOR185, PLAN224].includes(output), 'Output must be a separate fresh file')
  const [rawBytes, controlsBytes, checksBytes, priorBytes, planBytes] = await Promise.all([fs.readFile(rawPath), fs.readFile(controlsPath), fs.readFile(CHECKS), fs.readFile(PRIOR185), fs.readFile(PLAN224)])
  insist(sha(rawBytes) === RAW_SHA, 'Provided fresh raw SHA mismatch')
  insist(sha(controlsBytes) === CONTROLS_SHA, 'Provided fresh controls SHA mismatch')
  insist(sha(checksBytes) === CHECKS_SHA, 'Reviewed @tscircuit/checks dist SHA mismatch')
  insist(sha(priorBytes) === PRIOR185_SHA, 'Frozen original185 native report SHA mismatch')
  insist(sha(planBytes) === PLAN224_SHA, 'Exact reviewed Source224 routing plan SHA mismatch')
  const raw = JSON.parse(rawBytes.toString('utf8')), controls = JSON.parse(controlsBytes.toString('utf8')), prior185 = JSON.parse(priorBytes.toString('utf8')), plan224 = JSON.parse(planBytes.toString('utf8'))
  insist(Array.isArray(raw), 'Raw must be exact Circuit JSON array')
  insist(controls.rawCoreSha256 === RAW_SHA && controls.partialCoreControlPassed === true && controls.partialDiagnosticReplayControlsPassed === true, 'Fresh Core controls not passed or not bound to exact supplied raw bytes')
  insist(Array.isArray(controls.checks) && controls.checks.length === 35 && controls.checks.every((c: any) => c.passed === true), 'Expected all35 fresh replay controls passed')
  insist(controls.expectedConnectedOwners === 47 && controls.expectedPendingOwners === 2, 'Expected exact partial47/2 graph inventory')
  insist(controls.logical49Projection.length === 49 && controls.physicalGraphs.length === 49, 'Expected preserved49 logical owners/graphs')
  insist(controls.physicalGraphs.filter((g: any) => g.physicallyConnectedByActualOwnedNumericIdGraph === true).length === 47, 'Expected exactly47 fresh connected owner graphs')
  const allOwners = Array.from({length:49}, (_, i) => 'source_trace_' + i)
  const pending = ['source_trace_26', 'source_trace_30']
  const roster = (a: any, b: string[]) => Array.isArray(a) && a.length === b.length && new Set(a).size === a.length && a.every((v: string) => b.includes(v))
  insist(roster(controls.logical49Projection.map((p: any) => p.originalSourceTraceId), allOwners)
    && roster(controls.physicalGraphs.map((p: any) => p.originalSourceTraceId), allOwners), 'Exact original49 logical and physical-graph owner partition')
  insist(roster(controls.pendingOwnerIds, pending)
    && roster(controls.physicalGraphs.filter((g: any) => g.physicallyConnectedByActualOwnedNumericIdGraph !== true).map((g: any) => g.originalSourceTraceId), pending)
    && roster(controls.routedOwnerIds, allOwners.filter(sid => !pending.includes(sid))), 'Pending owners must be exactly26/30 and47 routed owners their complement')
  insist(plan224.scope === 'SOURCE33B_PARTIAL_MIXED_JOINED_EDITABLE_PLAN_SOURCE_PROJECTION_ONLY'
    && plan224.partialLayerProfile === 'compact-four-layer-partial'
    && plan224.inputBindings.candidate.sha256 === CANDIDATE223_SHA
    && roster(plan224.pendingOwnerIds, pending)
    && roster(plan224.routedOwnerIds, allOwners.filter(sid => !pending.includes(sid)))
    && plan224.replacedOriginals.length === 49 && plan224.projectedGeometry.length === 47,
    'Exact reviewed Source224 current223 partial47 plan and49 logical roster required')
  const newViaCount = plan224.newVias.length
  const expectedPhysicalVias = 129 + newViaCount
  insist(Number.isInteger(newViaCount) && newViaCount === 98 && expectedPhysicalVias === 227
    && plan224.innerPortRegistrations.length === 82 && plan224.auxiliaryLocalTraces.length === 4
    && plan224.dynamicCounts.expectedPcbVias === expectedPhysicalVias
    && plan224.dynamicCounts.expectedSourceVias === expectedPhysicalVias
    && plan224.dynamicCounts.routedOwners === 47 && plan224.dynamicCounts.pendingOwners === 2,
    'Reviewed Source224 inventory must derive129 retained references+98 new vias=227')
  insist(controls.planSha256 === PLAN224_SHA
    && controls.expectedCounts.physicalVias === expectedPhysicalVias
    && controls.expectedCounts.newVias === newViaCount
    && controls.expectedCounts.newInnerPorts === 82
    && controls.expectedCounts.auxiliaryLocalTraces === 4
    && controls.expectedCounts.routedOwners === 47 && controls.expectedCounts.pendingOwners === 2,
    'Fresh Core controls must bind the exact reviewed Source224 plan inventory')
  const physicalVias = raw.filter((r: any) => r.type === 'pcb_via')
  const layers = ['top', 'inner1', 'inner2', 'bottom']
  insist(physicalVias.length === expectedPhysicalVias
    && new Set(physicalVias.map((v: any) => v.pcb_via_id)).size === expectedPhysicalVias
    && physicalVias.every((v: any) => roster(v.layers, layers) && v.outer_diameter === .4572 && v.hole_diameter === .254),
    'Expected227 genuine unique fullspan .4572/.254 fresh physical vias')
  insist(CHECK_NAMES.length === 16 && new Set(CHECK_NAMES).size === 16 && NOT_RETESTED_NAMES.length === 16, 'Exact focused16/historical16 split including fresh regenerated-pour shorts check')
  insist(prior185.scope === 'PARTIAL45_ACTUAL182_NATIVE_CHECK_DIAGNOSTIC' && prior185.completed === true
    && prior185.results.length === 32 && prior185.results.every((r: any) => r.state === 'completed' && Array.isArray(r.findings))
    && roster(prior185.results.map((r: any) => r.name), ORIGINAL32_NAMES), 'Frozen185 must retain all32 completed checks and unfiltered findings')
  const rawCanonicalSha256 = sha(JSON.stringify(raw))
  const results: any[] = []
  const report: any = {
    scope: 'PARTIAL47_PLAN224_FOCUSED16_FRESH_CORE_NATIVE_CHECK_DIAGNOSTIC',
    inputBindings: { raw: { path: rawPath, sha256: RAW_SHA }, controls: { path: controlsPath, sha256: CONTROLS_SHA },
      checks: { path: CHECKS, sha256: CHECKS_SHA, package: '@tscircuit/checks', version: '0.0.242' },
      reviewedSourcePlan224: { path: PLAN224, sha256: PLAN224_SHA, candidate223Sha256: CANDIDATE223_SHA, retainedReferenceVias: 129, newVias: newViaCount, expectedPhysicalVias, routedOwners: 47, pendingOwners: 2 } },
    budgetMs, externalRootGuardRequired: { maximumWallMs: 180_000, memoryMb: 2048 },
    nativeExecuted: false, completed: false, currentCheck: null, requestedCheckNames: CHECK_NAMES,
    physical10: PHYSICAL10, results, allFindingsRetainedWithoutFilteringOrDedupe: true,
    prior185Evidence: { path: PRIOR185, sha256: PRIOR185_SHA, scope: prior185.scope, inputBindings: prior185.inputBindings,
      completeOriginal32Results: prior185.results, allOriginalFindingsRetained: true, inheritedQualification: false },
    notRetestedChecks: NOT_RETESTED_NAMES.map(name => ({ name, state: 'NOT_RETESTED',
      reason: 'Explicit focused16 run; original185 findings retained as historical evidence only',
      historical185Result: prior185.results.find((r: any) => r.name === name), inheritedQualification: false })),
    rawInputEdited: false, rawCanonicalSha256,
    coreReplayControlsPassed: true, logical49Projection: controls.logical49Projection,
    corePhysicalGraphs: controls.physicalGraphs, routedOwnerIds: controls.routedOwnerIds,
    pendingOwnerIds: controls.pendingOwnerIds, sourceTiming: bridgeObservations(raw, controls),
    customViaTrackManufacturing: { executed: false, qualified: false,
      reason: 'Fresh227 manually placed vias require a separate current-input authenticated SourceTrace-only UF/real all-layer alias diagnostic. No old225 ownership or clearance result is inherited, and no undefined-owner exemption is used.',
      originalCustomHelperExecuted: false, allThroughViaBarrelsManufacturingQualified: false },
    nativeScopeLimits: [
      'Native checkHoleTraceClearance checks nonplated pcb_hole clearance, not all via/PTH drill pairs.',
      'Native inline via-count checks do not prove the budget of separately declared manual vias.',
      'Native self-short checks on individual pcb_trace rows do not prove whole split-route/barrel self-clearance.',
      'Core may omit source bus absolute bounds; explicit bridge observations are separate from native findings.',
      'Native missing-source findings may consider same-net auxiliary copper; two pending Core graphs remain explicit regardless of native finding count.',
      'No cached prior-scene physical, coupling, manufacturer, or electrical qualification is inherited.'
    ],
    all49Accepted: false, full49Accepted: false, fullBoardPassed: false, electricalTimingQualified: false,
    fabricationReady: false, wholeMixedC31Validated: false, wholeMixedNativeQualified: false,
    allThroughViaBarrelsPhysicalQualified: false,
  }
  // Exclusive initial creation prevents replacement of an existing result or raw file.
  await fs.writeFile(output, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' })
  const save = async () => {
    report.elapsedMs = performance.now() - started
    report.completedCheckCount = results.filter(r => r.state === 'completed').length
    report.exceptionCount = results.filter(r => r.state === 'exception').length
    report.totalReturnedFindingCount = results.reduce((n, r) => n + (r.findings?.length ?? 0), 0)
    report.rawFileUnchanged = sha(await fs.readFile(rawPath)) === RAW_SHA
    report.controlsFileUnchanged = sha(await fs.readFile(controlsPath)) === CONTROLS_SHA
    report.prior185FileUnchanged = sha(await fs.readFile(PRIOR185)) === PRIOR185_SHA
    report.reviewedPlan224FileUnchanged = sha(await fs.readFile(PLAN224)) === PLAN224_SHA
    insist(report.rawFileUnchanged && report.controlsFileUnchanged && report.prior185FileUnchanged && report.reviewedPlan224FileUnchanged && sha(JSON.stringify(raw)) === rawCanonicalSha256, 'Exact raw input changed during diagnostic')
    const tmp = output + '.next'
    await fs.writeFile(tmp, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' })
    await fs.rename(tmp, output)
  }
  try {
    // Root-only execution. Hashing and diagnostic creation occur before this import.
    const native: any = await import(pathToFileURL(CHECKS).href)
    for (const name of CHECK_NAMES) {
      if (performance.now() - started >= budgetMs - 500) {
        results.push({ name, state: 'not_run_budget', findings: null })
        await save()
        continue
      }
      const result: any = { name, state: 'running', findings: null }
      results.push(result); report.currentCheck = name
      await save() // Preserve current check before a synchronous native call can block.
      const checkStarted = performance.now()
      try {
        insist(typeof native[name] === 'function', `Missing reviewed native export ${name}`)
        const checkInput = clone(raw), checkInputSha = sha(JSON.stringify(checkInput))
        report.nativeExecuted = true
        const findings = await native[name](checkInput)
        insist(Array.isArray(findings), `${name} returned nonarray findings`)
        result.findings = findings // No expected-error filter, suppression, consolidation, or dedupe.
        result.findingCount = findings.length
        result.checkInputMutated = sha(JSON.stringify(checkInput)) !== checkInputSha
        result.state = 'completed'
      } catch (error) { result.state = 'exception'; result.error = diagnostic(error) }
      result.elapsedMs = performance.now() - checkStarted
      report.currentCheck = null
      await save()
    }
    report.completed = results.length === CHECK_NAMES.length && results.every(r => r.state === 'completed')
    report.allRequestedNativeChecksReturnedNoFindings = report.completed && results.every(r => r.findings.length === 0)
    // Even zero findings cannot make the two pending routes or incomplete electrical model ready.
    report.all32FreshNativeChecksExecuted = false
    report.onlyFocused16WereRetested = true
    report.finished = true
    await save()
  } catch (error) {
    report.workerError = diagnostic(error); report.finished = false; report.completed = false
    await save()
    throw error
  }
  return report
}

if (import.meta.main) {
  const args = process.argv.slice(2), opts: Record<string, string> = {}
  for (let i = 0; i < args.length; i += 2) {
    insist(/^--(?:input|input-sha|controls|controls-sha|output|budget-ms)$/.test(args[i]) && args[i + 1] !== undefined, `Unknown/missing CLI argument ${args[i]}`)
    insist(!(args[i] in opts), `Duplicate CLI argument ${args[i]}`)
    opts[args[i]] = args[i + 1]
  }
  for (const key of ['--input', '--input-sha', '--controls', '--controls-sha', '--output']) insist(opts[key], `Required ${key}`)
  await runPartial47FocusedNativeChecks({ inputPath: opts['--input'], inputSha256: opts['--input-sha'],
    controlsPath: opts['--controls'], controlsSha256: opts['--controls-sha'], output: opts['--output'],
    budgetMs: opts['--budget-ms'] === undefined ? undefined : Number(opts['--budget-ms']) })
}
