from pathlib import Path
import argparse,hashlib,importlib.util,json,os,re,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent/'g350-ti-v12e-actual-core-patched-fanout-public-next'
BASE=ROOT.parent/'g350-count-conditioned-site-recovery-next'
POLICY={'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
RESERVE=2*1024**3
BUN='/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def verify():
 raw=(ROOT/'SOURCE-manifest.json').read_bytes();p=json.loads(raw)
 for r in p['files']+p['externalFiles']:
  f=Path(r['path']);assert f.is_file() and not f.is_symlink() and sha(f)==r['sha256'] and f.stat().st_size==r['bytes'] and (f.stat().st_mode&0o777)==r['mode']
 parent=module('held_v12d_public_source',PARENT/'global-selection-guard.py');parent.prepared()
 closed=json.loads(Path(p['closedRootReceiptPath']).read_bytes());assert closed['sessionId']==47861 and closed['collectedExitCode']==0 and closed['execution']['cleanupOwnedGroupEmpty'] is True and closed['diagnosticTrustEligible'] is True
 assert closed['execution']['pgid']==281921 and not any(closed['execution']['oomDelta'].values())
 scope=module('original_local_dogbone_owned_scope',BASE/'process_scope.py');assert not scope.owned(281921)
 return p,hashlib.sha256(raw).hexdigest(),parent,scope
def main():
 a=argparse.ArgumentParser();a.add_argument('--preflight-only',action='store_true');a.add_argument('--run',action='store_true');a.add_argument('--root-receipt');a.add_argument('--root-receipt-sha256');args=a.parse_args()
 p,p_sha,parent,scope=verify()
 if args.preflight_only:print(json.dumps({'preflightPassed':True,'packetSha256':p_sha,'sourceOnly':True}));return 0
 assert args.run and args.root_receipt and args.root_receipt_sha256
 auth=json.loads(Path(args.root_receipt).read_bytes());assert sha(args.root_receipt)==args.root_receipt_sha256 and auth['authorizedByRoot'] is True and auth['scope']==p['scope'] and auth['packetSha256']==p_sha and auth['policy']==POLICY and re.fullmatch('[0-9a-f]{32,128}',auth['approvalToken'])
 assert not (ROOT/'run').exists();before=parent.dependency_check();baseline=scope.memory()
 def gate(now):
  assert now['current']+POLICY['rssBytes']+RESERVE<POLICY['sharedBytes'],'Strict prefork reserve required'
  assert all(now['events'][k]==baseline['events'][k] for k in scope.OOM_KEYS)
 execution=scope.run_guarded([BUN,'--smol',str(ROOT/'diagnose.ts'),'--run-one-approved'],ROOT,ROOT/'run',POLICY,{'G350_LOCAL_DOGBONE_APPROVED':'1','G350_LOCAL_DOGBONE_AUTH_PATH':str(Path(args.root_receipt).resolve()),'G350_LOCAL_DOGBONE_AUTH_SHA':args.root_receipt_sha256},before_spawn=gate)
 verify();after=parent.dependency_check();assert before==after
 result=json.loads((ROOT/'run/result.json').read_bytes()) if (ROOT/'run/result.json').is_file() else None
 clean=execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values())
 valid=clean and result is not None and result['patchedIndividualCalls']==196 and result['patchedWholeCalls']==4 and result['endpointCandidateApiCalls']==0 and result['CoreForwarded'] is True and result['cohortTargetMapHypothesisOnly'] is True and result['sourceClassMetadataOverlayAlreadyForwarded'] is False and result['inputUnchanged'] is True and result['noGridNoNativeChecker'] is True and not result['otherErrorNames']
 receipt={'execution':execution,'dependenciesBefore':before,'dependenciesAfter':after,'sourceAndArtifactsHeld':True,'packetSha256':p_sha,'resultSha256':sha(ROOT/'run/result.json') if result is not None else None,'diagnosticTrustEligible':valid,'accepted49':False,'physicalAcceptanceClaimed':False}
 (ROOT/'EXECUTION-postaudit.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'diagnosticTrustEligible':valid,'resultSha256':receipt['resultSha256']}));return 0 if valid else 2
if __name__=='__main__':raise SystemExit(main())
