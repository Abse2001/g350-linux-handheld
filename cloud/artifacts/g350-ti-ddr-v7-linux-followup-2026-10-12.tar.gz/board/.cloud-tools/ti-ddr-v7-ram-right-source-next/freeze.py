"""Freeze isolatedV7 source-only PREP; no Circuit/native/Core/export calls."""
from pathlib import Path
import json,os,stat
from inventory import sha,tree
ROOT=Path(__file__).resolve().parent;BOARD=Path('/workspace/g350-linux-handheld');OLD=BOARD/'.cloud-tools/ti-ddr-v6-alternate-cohort-env-next'
ENTRY='experiments/am3352-g350-ti-top-bottom-ddr-v7-ram-right-layout.circuit.tsx';POLICY={'wallSeconds':60,'rssBytes':2*1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
assert not(ROOT/'packet-manifest.json').exists() and not(ROOT/'run').exists() and not(ROOT/'root-launch-receipt.json').exists()
old=json.loads((OLD/'packet-manifest.json').read_bytes());source_rows=[r for r in old['files'] if r['path'].startswith('source/')];assert len(source_rows)==118
for row in source_rows:assert sha(OLD/row['path'])==row['sha256'] and sha(ROOT/row['path'])==row['sha256'],row['path']
actual={str(p.relative_to(ROOT)) for p in (ROOT/'source').rglob('*') if p.is_file() and not p.is_symlink()}
assert actual=={r['path'] for r in source_rows}|{'source/'+ENTRY,'source/lib/am3352/placement/g350-ti-top-bottom-ddr-v7-translation.json'}
assert sha(ROOT/'process_scope.py')=='7bdc74b15af3ba5b2c306d34a816b48cf8b9d68479b0c06a57f43787d4a4a993'
def item(p):
 assert not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)}
# Bind exact immutable source/physical inputs and installed pins, never mutable
# board HEAD/index/docs or default source. New source is entirely self-contained.
external=[item(OLD/n) for n in ['packet-manifest.json','run/fresh-layout.circuit.json','run/result.json','run/postflight.json','validation-report.json']]
external += [item(p) for p in [BOARD/'cloud/env.sh',BOARD/'bun.lock',BOARD/'package-lock.json',BOARD/'package.json',BOARD/'tscircuit.config.json',BOARD/'tsconfig.json',BOARD/'node_modules/@tscircuit/checks/dist/index.js',BOARD/'node_modules/@tscircuit/core/dist/index.js',BOARD/'node_modules/@tscircuit/core/package.json',BOARD/'node_modules/tscircuit/cli.mjs',BOARD/'.cloud-tools/node/bin/node',BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe',Path('/workspace/bus-lanes-solver/tests/fixtures/g350-am3352/metadata.json'),BOARD/'.cloud-tools/ti-ddr-rule-audit/v7-translation-handoff.json',BOARD/'.cloud-tools/ti-ddr-rule-audit/ram-translation-proposal.json',BOARD/'.cloud-tools/ti-ddr-rule-audit/propose-ram-translation.py'] if p.is_file()]
assert sha(ROOT/'inputs/v7-translation-handoff.json')=='13fc543101dcc527caf622e445881d7631e6bf2f9de9683b9fa198e414dcbb4e'
deps=tree(BOARD/'node_modules')
for k in ['treeSha256','regularFiles','regularBytes','symlinks','directories']:assert deps[k]==old['dependencyTree'][k],k
(ROOT/'dependency-tree.json').write_text(json.dumps(deps,indent=2)+'\n')
resolver=[p.replace(str(OLD),str(ROOT)) for p in old['resolverMustRemainAbsent']]
for name in resolver:assert not(Path(name).exists() or Path(name).is_symlink())
template={'authorizedByRoot':False,'scope':'one-ti-v7-ram-right-source-only-no-router-no-cad','packetSha256':'FROZEN_PEER_REVIEWED_PACKET_REQUIRED','policy':POLICY,'approvalToken':'ROOT_DELEGATED_ONE_SOURCE_EXPORT_NONCE_REQUIRED','accepted49':False}
(ROOT/'launch-receipt.TEMPLATE.json').write_text(json.dumps(template,indent=2)+'\n')
files=[]
for current,dirs,names in os.walk(ROOT,followlinks=False):
 dirs[:]=[d for d in dirs if d!='__pycache__' and not(Path(current)/d).is_symlink()]
 for name in names:
  p=Path(current)/name
  if p.is_symlink():continue
  assert stat.S_ISREG(p.lstat().st_mode)
  files.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)})
files.sort(key=lambda r:r['path']);m={'schemaVersion':1,'scope':'one-ti-v7-ram-right-source-only-no-router-no-cad','policy':POLICY,'sourceEntry':ENTRY,'sourceFileCount':120,'originalCommand':[str(BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),str(BOARD/'node_modules/tscircuit/cli.mjs'),'build',ENTRY,'--routing-disabled','--disable-parts-engine'],'freshOutput':'source/dist/experiments/am3352-g350-ti-top-bottom-ddr-v7-ram-right-layout/circuit.json','planeDeclarations':old['planeDeclarations'],'pinnedVersions':old['pinnedVersions'],'pinnedRuntimeVersions':old['pinnedRuntimeVersions'],'nativeChecksPatchSha256':old['nativeChecksPatchSha256'],'dependencyTree':{k:v for k,v in deps.items() if k!='items'},'dependencyTreeManifestSha256':sha(ROOT/'dependency-tree.json'),'files':files,'externalFiles':external,'resolverMustRemainAbsent':sorted(set(resolver)),'baseV6PacketSha256':sha(OLD/'packet-manifest.json'),'baseV6LayoutSha256':sha(OLD/'run/fresh-layout.circuit.json'),'all118PriorSourceFilesUnchanged':True,'newSourceFilesOnly':[ENTRY,'lib/am3352/placement/g350-ti-top-bottom-ddr-v7-translation.json'],'rigid18RealPartTranslationMm':{'x':1.2,'y':0},'referenceBarrelsAndStubsRigidlyTranslated':2,'freshTiEndpointAuditRequired':True,'prospectiveByte0MaxPlanarMm':13.2,'prospectiveByte1MaxPlanarMm':14.4,'prospectiveCommandMinMaxPlanarMm':[21.15,23.69],'actualCircuitExecuted':False,'cadRequested':False,'autoroutingRequested':False,'rootDelegatedOneSourceBuild':True,'mutableGitBindingsExcluded':True,'accepted49':False,'fabricationReady':False}
(ROOT/'packet-manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'packetSha256':sha(ROOT/'packet-manifest.json'),'sourceFileCount':120,'files':len(files),'external':len(external),'dependencyTreeSha256':deps['treeSha256'],'actualCircuitExecuted':False}))
