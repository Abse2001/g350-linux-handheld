import { strict as assert } from "node:assert"
import { createHash } from "node:crypto"
export const fingerprint = (value: unknown) =>
  createHash("sha256").update(JSON.stringify(value)).digest("hex")
export function runCapturedGridProbe(
  capture: any,
  api: {
    Scene: new (...args: any[]) => any
    Grid: new (...args: any[]) => any
  },
) {
  const before = fingerprint(capture)
  const scene = new api.Scene(
    capture.input,
    capture.connection,
    capture.width,
    capture.copper,
  )
  assert.ok(
    fingerprint({
      input: scene.input,
      connection: scene.connection,
      width: scene.width,
      margin: scene.margin,
      owners: [...scene.owners],
      copper: scene.copper,
    }) ===
      fingerprint({
        input: capture.input,
        connection: capture.connection,
        width: capture.width,
        margin: capture.margin,
        owners: capture.owners,
        copper: capture.copper,
      }),
    "Captured exact Scene parity changed",
  )
  let check: any,
    steps = 0,
    cancelCalls = 0,
    snapshot: any,
    constructorSeconds: number
  const start = performance.now()
  check = new api.Grid(scene, capture.start, capture.end, [], 4, undefined, {
    checkReachability: true,
  })
  constructorSeconds = (performance.now() - start) / 1000
  try {
    while (!check.solved && !check.failed && check.expanded < 500000) {
      check.step()
      steps++
    }
    snapshot = {
      solved: check.solved,
      failed: check.failed,
      expanded: check.expanded,
      steps,
      nx: check.nx,
      ny: check.ny,
      cellCount: check.cellCount,
      result: check.solved ? structuredClone(check.result) : null,
    }
    if (snapshot.solved)
      assert.ok(
        scene.pathVisible(snapshot.result),
        "Solved Grid result must retain exact visibility",
      )
  } finally {
    check.cancel()
    cancelCalls++
  }
  assert.ok(
    fingerprint(capture) === before,
    "Original captured input/Cu mutated",
  )
  const status = snapshot.solved
    ? "EXACT_GRID_POSITIVE_WITNESS"
    : snapshot.failed
      ? "FINITE_OFFERED_GRID_DISCONNECTED_OR_COMPLETED_FAILURE"
      : "BOUNDED_GRID_UNKNOWN"
  return {
    status,
    sceneParityHeld: true,
    inputAndCopperHeld: true,
    originalGridCalls: 1,
    gridOptionalChanges: ["checkReachability:true"],
    beforeCancelSnapshotTaken: true,
    cancelCalls,
    gridCapExpanded: 500000,
    constructorSeconds,
    beforeCancel: snapshot,
    afterCancel: {
      solved: check.solved,
      failed: check.failed,
      expanded: check.expanded,
    },
    positiveWitness: snapshot.solved ? snapshot.result : null,
    physicalTrappingProven: false,
    universalPhysicalInfeasibility: false,
    unknownNeverPromotedToReachable: true,
    originalRoutingFactories: 0,
    nativeCheckerCalls: 0,
    acceptedClock: false,
    accepted49: false,
    fabricationReady: false,
  }
}
