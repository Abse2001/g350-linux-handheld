import {
  orderCapturesByOriginalJobIdentity,
  type OriginalCapture,
} from "./identity-order"
import { length } from "./source/lib/geometry"
import { fixedRouteLength } from "./source/lib/route-lengths"
import type { SimpleRouteJson, Trace } from "./source/lib/types"

/** Original source planar arithmetic; no route/search/checker or tuning call. */
export function actualPairLengthReportsByJobIdentity(
  allocation: SimpleRouteJson,
  captures: OriginalCapture[],
) {
  const ordered = orderCapturesByOriginalJobIdentity(allocation, captures)
  const byJobId = new Map(ordered.map((capture) => [capture.jobId, capture]))
  return (allocation.differentialPairs ?? []).map((pair, index) => {
    const capture = byJobId.get(index + 1)!
    const completeNaturalBody =
      capture?.terminalMethod === "next" &&
      Array.isArray(capture.result) &&
      capture.result.length === 2 &&
      new Set(capture.result.map((trace: any) => trace.connection_name))
        .size === 2 &&
      capture.result.every(
        (trace: any) =>
          pair.connectionNames.includes(trace.connection_name) &&
          Array.isArray(trace.route) &&
          trace.route.length >= 2 &&
          trace.route.every(
            (point: any) =>
              Number.isFinite(point.x) && Number.isFinite(point.y),
          ),
      )
    if (!completeNaturalBody)
      return {
        jobId: index + 1,
        connectionNames: pair.connectionNames,
        completeNaturalBody: false,
        terminalMethod: capture?.terminalMethod ?? null,
        members: null,
        pairPlanarSkewMm: null,
        pairViaChargedSkewMm: null,
        absolutePlanarBoundsQualified: false,
        fullBusOr49TimingQualified: false,
      }
    const traces = capture.result as Trace[]
    const members = pair.connectionNames.map((name) => {
      const trace = traces.find((item) => item.connection_name === name)!
      const bodyPlanarLengthMm = length(trace.route)
      const ownedEscapePlanarLengthMm = fixedRouteLength(allocation, name)
      const totalPlanarLengthMm = bodyPlanarLengthMm + ownedEscapePlanarLengthMm
      const vias = [
        ...trace.route,
        ...(allocation.traces ?? [])
          .filter(
            (item) =>
              item.connection_name === name ||
              item.source_trace_id ===
                (allocation.connections.find(
                  (connection) => connection.name === name,
                )?.source_trace_id ?? name),
          )
          .flatMap((item) => item.route),
      ].filter((point) => point.route_type === "via")
      const fullspanViaCount = vias.length
      const bus = allocation.buses?.find((item) =>
        item.connectionNames.includes(name),
      )
      const minLengthMm = bus?.minLength ?? null,
        maxLengthMm = bus?.maxLength ?? null
      return {
        name,
        bodyPlanarLengthMm,
        ownedEscapePlanarLengthMm,
        totalPlanarLengthMm,
        fullspanViaCount,
        viaChargedLengthMm: totalPlanarLengthMm + 1.6 * fullspanViaCount,
        minPlanarLengthMm: minLengthMm,
        maxPlanarLengthMm: maxLengthMm,
        withinAbsolutePlanarBounds:
          (minLengthMm === null || totalPlanarLengthMm >= minLengthMm - 1e-7) &&
          (maxLengthMm === null || totalPlanarLengthMm <= maxLengthMm + 1e-7),
      }
    })
    const pairPlanarSkewMm = Math.abs(
      members[0].totalPlanarLengthMm - members[1].totalPlanarLengthMm,
    )
    const pairViaChargedSkewMm = Math.abs(
      members[0].viaChargedLengthMm - members[1].viaChargedLengthMm,
    )
    return {
      jobId: index + 1,
      connectionNames: pair.connectionNames,
      completeNaturalBody: true,
      terminalMethod: capture.terminalMethod,
      members,
      pairPlanarSkewMm,
      pairViaChargedSkewMm,
      declaredPairSkewMm: pair.lengthTolerance,
      pairPlanarSkewQualified: pairPlanarSkewMm <= pair.lengthTolerance + 1e-7,
      pairViaChargedSkewQualified:
        pairViaChargedSkewMm <= pair.lengthTolerance + 1e-7,
      absolutePlanarBoundsQualified: members.every(
        (member) => member.withinAbsolutePlanarBounds,
      ),
      fullBusOr49TimingQualified: false,
    }
  })
}
