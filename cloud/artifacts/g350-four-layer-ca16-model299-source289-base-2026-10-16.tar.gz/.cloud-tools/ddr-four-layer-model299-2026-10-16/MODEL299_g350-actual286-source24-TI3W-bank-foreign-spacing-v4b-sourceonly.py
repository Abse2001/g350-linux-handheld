"""Own stdlib full49 reciprocal Source24 corrected header, no source runtime."""
exec(open('/tmp/g350-actual286-ca20-22-24-25-retiming-finite-helper.py').read())
p=Path('/tmp/g350-actual286-source24-TI3W-bank-local-report.json');assert hashlib.sha256(p.read_bytes()).hexdigest()=='ba7aa073525b6f296059bc219b064a5a126a196a1ddfb3fd6b9f41c65ae57764';R=json.loads(p.read_bytes());after=copy.deepcopy(R['bodyInverse']['after']);old=B['source_trace_24']
for i in [2,3,4,5]:after['route'][i]['y']-=.14
for i in [16,17,18,19]:after['route'][i]['x']+=.14
assert after['route'][0]==old['route'][0] and after['route'][-1]==old['route'][-1]
ss=makeScene({'source_trace_24':after});rows=[]
for n,t in B.items():
 z=after if n=='source_trace_24' else t;cs=ss.contacts(z);rows.append({'owner':n,'contacts':cs,'clear':not cs})
assert len(rows)==49 and all(r['clear'] for r in rows),[r for r in rows if not r['clear']]
sm=self_math(after['route']);assert sm['passedPureMath'];allow={tuple(r['segments']) for r in sm['allowedCloseLocalCornerPairs']};ds=[{'segments':[i,j],'distanceMm':sd(after['route'][i],after['route'][i+1],after['route'][j],after['route'][j+1])} for i in range(len(after['route'])-1) for j in range(i+2,len(after['route'])-1) if (i,j) not in allow];bank=min((r for r in ds if 7<=r['segments'][0] and r['segments'][1]<=31),key=lambda z:z['distanceMm']);assert bank['distanceMm']>=.3048-1e-8
hs=[math.degrees(math.atan2(b['y']-a['y'],b['x']-a['x'])) for a,b in zip(after['route'],after['route'][1:])];err=max(abs(h-round(h/45)*45) for h in hs);turn=max(abs((b-a+180)%360-180) for a,b in zip(hs,hs[1:]));assert err<1e-8 and turn<45+1e-8
vwhole=whole(after);assert abs(vwhole-R['wholeLengthMm'])<1e-8 and 20.950002<=vwhole<=21.585658
classByOwner={n:b['busId'] for b in f['buses'] for n in b['connectionNames']};assert classByOwner['source_trace_24']=='DDR_COMMAND_CLOCK';pairs=[]
for t in [*f['traces'],*B.values()]:
 n=owner(t)
 if n=='source_trace_24' or n not in classByOwner:continue
 need=.3048 if classByOwner[n]=='DDR_COMMAND_CLOCK' else .4064
 for i,(a,b) in enumerate(zip(after['route'],after['route'][1:])):
  for j,(u,v) in enumerate(zip(t['route'],t['route'][1:])):
   if u['route_type']!=v['route_type'] or u['route_type']!='wire' or u['layer']!=v['layer'] or a['layer']!=u['layer']:continue
   d=sd(a,b,u,v)
   if d<1:pairs.append({'source24Segment':i,'otherOwner':n,'otherId':t['pcb_trace_id'],'otherSegment':j,'otherClass':classByOwner[n],'requiredClassCenterlineMm':need,'actualCenterlineMm':d,'parallel':abs((b['x']-a['x'])*(v['y']-u['y'])-(b['y']-a['y'])*(v['x']-u['x']))<1e-8})
bad=[p for p in pairs if p['actualCenterlineMm']<p['requiredClassCenterlineMm']-1e-8];assert not bad,bad
ownLanding=[]
for side,t in enumerate(t for t in f['traces'] if owner(t)=='source_trace_24'):
 v=next(x for x in t['route'] if x['route_type']=='via');segments=list(zip(after['route'],after['route'][1:]));inc=0 if side==0 else len(segments)-1;ne=min(({'segment':i,'distanceMm':pd(v,a,b)} for i,(a,b) in enumerate(segments) if i!=inc),key=lambda z:z['distanceMm']);assert ne['distanceMm']>=.381-1e-8;ownLanding.append({'side':side,'literalOwnedWorkingBranch':t,'onlyIncidentSegmentExcluded':inc,'nearestNonincidentSegment':ne,'requiredOwnLandAvoidanceAfterFirstExitMm':.381,'passed':True})
R.update(scope='PURE_STDLIB_ACTUAL286_SOURCE24_TI3W_BANK_AND_FOREIGN_DDR_CLASS_SPACING_HEADER_FIX_FULL49_NOT_WHOLE_TI_QUALIFICATION',bodyInverse={'owner':'source_trace_24','index':c['carrierTraces'].index(old),'before':old,'after':after},wholeLengthMm=vwhole,allEdgesOctilinearMaximumHeadingErrorDegrees=err,maximumLocalTurnDegrees=turn,pureNativeStyleSelfMath=sm,minimumWholeBodyNonlocalPair=min(ds,key=lambda z:z['distanceMm']),ownWorkingBarrelAfterFirstExitReports=ownLanding,all49ReciprocalForeignRows=rows,changedBodyForeignContacts=[],all49ForeignContactsZero=True,localNonparallelTerminalBendPairsBelow3W=[r for r in ds if r['distanceMm']<.3048-1e-8],supersededV3PureProof={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},headerFix={'points2Through5YDeltaMm':-.14,'middleBankPoints16Through19XDeltaMm':.14,'lowerFoldHeldLiteral':True,'lengthCompensationMm':.28,'allChangesSource24Only':True},source24ForeignDdrClassSpacingAudit={'noExceptionWaiversApplied':True,'sameClass3WCenterlineMm':.3048,'otherDdrClass4WCenterlineMm':.4064,'allForeignCarrierAndWorkingWireSegmentsChecked':True,'subGuidancePairs':bad,'subGuidancePairCount':0,'nearestPairs':sorted(pairs,key=lambda z:z['actualCenterlineMm'])[:20],'wholeTiRoutingQualified':False})
R['bank']['minimumNonlocalPair']=bank
out=Path('/tmp/g350-actual286-source24-TI3W-bank-foreign-spacing-v4b-report.json');out.open('x').write(json.dumps(R,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'sourceSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'whole':vwhole,'classNearest':R['source24ForeignDdrClassSpacingAudit']['nearestPairs'][0],'all49foreignzero':True,'selfPassed':True},indent=2))
