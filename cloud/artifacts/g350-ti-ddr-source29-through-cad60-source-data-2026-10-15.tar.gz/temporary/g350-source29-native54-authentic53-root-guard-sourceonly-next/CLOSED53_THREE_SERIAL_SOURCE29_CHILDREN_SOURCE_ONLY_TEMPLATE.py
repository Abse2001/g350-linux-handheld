 def closed53():
  prior=closed52();assert prior['actualClosedScopeCount']==52
  for key in('actual53CollectionPin','actual53PostauditPin','actual53CapturePin','actual53DiagnosticPin','actual53CoreRawPin','actual53CoreControlsPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert len(proposal['actual53PhasePostauditPins'])==3
  assert proposal['actual53ToolSessionId']==36688
  for row in proposal['actual53PhasePostauditPins']:binding(row)
  r=read(proposal['actual53CollectionPin']['path']);p=read(proposal['actual53PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual53ToolSessionId'])is int and r['toolSessionId']==proposal['actual53ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE29_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH52_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='capture-types-core-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual53GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual53PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert len(p['phases'])==3 and p['orderedPhaseNames']==p['expectedPhaseNames']==['capture','types','core']and p['notAttemptedPhaseNames']==[]
  identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()
  assert identity['pid']==500295 and [row['execution']['pgid']for row in p['phases']]==[500361,500419,500510]
  for doc in(r,p):
   for key in('historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','allThreeChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansCaptureStrictTypesAndRawCore29Only','batchScopeContainsThreeSerialOwnedChildren','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('batchFailure','finalVerificationFailure'):assert doc[key]is None
   for key in('Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
   assert doc['newRoutesAdopted']==0 and doc['CoreCalls']==doc['CoreChildInvocations']==doc['captureChildInvocations']==doc['typesChildInvocations']==1 and doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  previous=None;owned=[]
  for phase,row,pin in zip(('capture','types','core'),p['phases'],proposal['actual53PhasePostauditPins']):
   assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
   for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and sha(pin['path'])==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   e=row['execution'];h.finite(e,0);assert e['policy']==batch29['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and c.guard.process_scope.owned(e['pgid'])==[]and e['pgid']not in owned
   owned.append(e['pgid'])
   if previous is not None:assert previous['endedAt']<=e['startedAt']
   previous=e
   for output in row['outputFiles']:binding(output)
   for key in('Source29Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
   assert row['nativeCalls']==row['originalApiCalls']==row['cliCalls']==row['cadCalls']==0
  capture,types,core=p['phases'];assert capture['result']['sourceCapturePin']==proposal['actual53CapturePin']and capture['result']['sourceDiagnosticPin']==proposal['actual53DiagnosticPin']and core['result']['rawCorePin']==proposal['actual53CoreRawPin']and core['result']['coreControlsPin']==proposal['actual53CoreControlsPin']
  assert capture['result']==inspect29_capture(dict(capture=Path(proposal['actual53CapturePin']['path']),diagnostic=Path(proposal['actual53DiagnosticPin']['path'])))
  assert types['result']==dict(strictNoEmitTypecheckNatural0=True,actualPriorCapturePin=proposal['actual53CapturePin'])and types['outputFiles']==[]
  assert core['result']==inspect29_core(dict(raw=Path(proposal['actual53CoreRawPin']['path']),controls=Path(proposal['actual53CoreControlsPin']['path'])),proposal['actual53CapturePin'])
  bun=str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe')
  assert capture['command']==[bun,'--smol',proposal['promoted29CapturePin']['path'],proposal['actual53CapturePin']['path'],proposal['actual53DiagnosticPin']['path']]
  assert types['command']==['bash',proposal['promoted29TypesPin']['path']]
  assert core['command']==[bun,'--smol',proposal['promoted29CorePin']['path'],proposal['actual53CoreRawPin']['path'],proposal['actual53CoreControlsPin']['path'],proposal['actual53CapturePin']['path']]
  prior['actual53Source29ThreeSerialCaptureTypesCoreCollectionPin']={'path':proposal['actual53CollectionPin']['path'],'sha256':proposal['actual53CollectionPin']['sha256']};prior['actualClosedScopeCount']=53;prior['actual53ThreeChildrenDoNotQualifyNativeOrFull49']=True
  return prior
