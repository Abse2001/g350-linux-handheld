// Source-only literal192 addition proposal; not evaluated or rendered.
import {Children,cloneElement,isValidElement,type ReactElement,type ReactNode} from 'react'
import {buildPackageApproachSource} from '/workspace/g350-linux-handheld/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/package-approaches-overlay'
import proposal from './signal-source-proposal.json'
type Props=Record<string,unknown>&{name?:string;children?:ReactNode}
type Owner={originalSourceTraceId:string;originalPcbPortId:string;originalSourcePortId:string;package:string;numericPin:number;viaName:string;traceName:string;padXY:{x:number;y:number};viaXY:{x:number;y:number};carrierLayer:string;viaLayers:string[];topStub:Array<{route_type:string;x:number;y:number;width:number;layer:string}>}
export function buildCombinedLocalSource(){
 const owners=proposal.owners as Owner[]
 if(owners.length!==96||new Set(owners.map(o=>o.viaName)).size!==96||new Set(owners.map(o=>o.traceName)).size!==96||new Set(owners.map(o=>o.originalPcbPortId)).size!==96)throw Error('Exactly96 original numeric signal fanout owners required')
 const base=buildPackageApproachSource();let boards=0;const names=new Set<string>()
 function append(node:ReactNode):ReactNode{
  if(!isValidElement<Props>(node))return node
  const props={...node.props};if(props.name)names.add(props.name)
  const children=Children.toArray(props.children).map(append)
  if(node.type==='board'){
   boards++;if(props.layers!==4||props.routeRemaining!==false||(props.pcbX??0)!==0||(props.pcbY??0)!==0||(props.pcbRotation??0)!==0)throw Error('Original routing-disabled identity frame four-layer board required')
   for(const owner of owners){
    if(names.has(owner.viaName)||names.has(owner.traceName))throw Error('New signal source name collides with preserved source')
    if(owner.viaLayers.join(',')!=='top,inner1,inner2,bottom'||!['inner1','inner2','bottom'].includes(owner.carrierLayer)||!['U_SOC','U_RAM'].includes(owner.package)||!Number.isInteger(owner.numericPin))throw Error('Actual original numeric pad and full-depth signal span required')
    const [a,b]=owner.topStub
    if(owner.topStub.length!==2||a.route_type!=='wire'||b.route_type!=='wire'||a.layer!=='top'||b.layer!=='top'||a.width!==.1016||b.width!==.1016||a.x!==owner.padXY.x||a.y!==owner.padXY.y||b.x!==owner.viaXY.x||b.y!==owner.viaXY.y)throw Error('Exact captured Top signal centerline required')
    const viaTop=`.${owner.viaName} > port.top`
    children.push(
     <via name={owner.viaName} pcbX={owner.viaXY.x} pcbY={owner.viaXY.y} fromLayer='top' toLayer='bottom' outerDiameter={.4572} holeDiameter={.254} tented='top_and_bottom_tented'/>,
     <trace name={owner.traceName} from={`${owner.package}.pin${owner.numericPin}`} to={viaTop} thickness={.1016} pcbPathRelativeTo={viaTop} pcbPath={[]}/>,
    )
   }
  }
  return cloneElement(node as ReactElement<Props>,props,...children)
 }
 const element=append(base.element);if(boards!==1)throw Error('One original board required')
 return {...base,element,signalLocalSourceProposal:{retainedPackage101LiteralElements:2036,addedSignalViaLiteralElements:96,addedTopSignalTraceLiteralElements:96,proposedLiteralElements:2228,original49LogicalRequestsUnchanged:true,signalCpuRamInterconnectsClaimed:false,newCoreBuildPerformed:false,newNativeChecksPerformed:false,filledReferencesQualified:false,referenceQualified:false,accepted49:false,fabricationReady:false}}
}
export default()=>buildCombinedLocalSource().element
