"""Use unchanged audited owned monitor for all preparation tests, no native run."""
import hashlib,importlib.util,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/bus-lanes-solver')
POLICY={'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def sources():
 p=REPO/'.cache/topology-default-c115121-smol-14400/prepared-manifest.json';x=json.loads(p.read_bytes());assert len(x['sourceHashes'])==177
 for name,expected in x['sourceHashes'].items():assert sha(ROOT/'source'/name)==expected and sha(p.parent/'frozen'/name)==expected
 return {'sourceMemberCount':177,'sourceMapSha256':hashlib.sha256(json.dumps(x['sourceHashes'],sort_keys=True).encode()).hexdigest()}
def deps():
 donor=json.loads((REPO/'.cache/g350-ti-public-cohort-first-three-pairs-next/packet-manifest.json').read_bytes());v=module('verifier',ROOT/'verify-installed-dependencies.py');r=v.verify(ROOT/'dependencies/archive-receipt.json',donor['dependencyReceiptSha256'],ROOT/'audit-installed-dependencies.py');assert r['treeSha256']==donor['dependencyTreeSha256'] and r['archiveSha256']==donor['dependencyArchiveSha256'];return r
beforeSource=sources();beforeDeps=deps();scope=module('prep_owned_scope',ROOT/'process_scope.py');before=scope.memory();assert before['current']+3*1024**3<POLICY['sharedBytes']
def before_spawn(fresh):
 assert fresh['current']+3*1024**3<POLICY['sharedBytes']
 assert all(fresh['events'][k]==before['events'][k] for k in ['oom','oom_kill','oom_group_kill'])
execution=scope.run_guarded(['python3',str(ROOT/'prep-tests-driver.py')],ROOT,ROOT/'prep-validation/owned-scope-cap-owner',POLICY,before_spawn=before_spawn)
afterSource=sources();afterDeps=deps();after=scope.memory();assert beforeSource==afterSource and beforeDeps==afterDeps
report={'policy':POLICY,'execution':execution,'sourceBefore':beforeSource,'sourceAfter':afterSource,'dependenciesBefore':beforeDeps,'dependenciesAfter':afterDeps,'memoryBefore':before,'memoryAfter':after,'originalSourceFunctionsInvoked':False,'nativeCheckerInvoked':False,'routingInvoked':False,'inputSourceAndDependencyHeld':True}
(ROOT/'prep-validation/cap-owner-bounded-scope-audit.json').write_text(json.dumps(report,indent=2)+'\n')
assert execution['exitCode']==0 and execution['cleanupOwnedGroupEmpty'] is True and not execution['diagnosticStopped']
assert all(after['events'][k]==before['events'][k] for k in ['oom','oom_kill','oom_group_kill'])
print(json.dumps({'actualExitCode':execution['exitCode'],'ownedCleanup':execution['cleanupOwnedGroupEmpty'],'sourceAndDepsHeld':True,'oomDelta0':True,'nativeCheckerInvoked':False}))
