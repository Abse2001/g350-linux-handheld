"""Freeze original C115 source and ACTUAL prefix data; no source helpers called."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import stat
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/bus-lanes-solver')
PREPARED=REPO/'.cache/topology-default-c115121-smol-14400/prepared-manifest.json'
PARENT=REPO/'.cache/g350-ti-public-cohort-first-three-pairs-next'
LAYOUT=Path('/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v5-reference-export-next/run/fresh-layout.circuit.json')
def item(path,relative=False):
 raw=path.read_bytes();return {'path':str(path.relative_to(ROOT)) if relative else str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':stat.S_IMODE(path.stat().st_mode)}
assert not (ROOT/'packet-manifest.json').exists()
for name in ['run','root-launch-receipt.json']:assert not (ROOT/name).exists() and not (ROOT/name).is_symlink()
p=json.loads(PREPARED.read_bytes());assert len(p['sourceHashes'])==177
members=[]
for name,expected in p['sourceHashes'].items():
 copied=item(ROOT/'source'/name,True);assert copied['sha256']==expected;assert item(PREPARED.parent/'frozen'/name)['sha256']==expected;members.append(copied)
(ROOT/'source-freeze.json').write_text(json.dumps({'sourceCommit':'c1151212be7b9de4b34b07436d135d874e6c0466','libTree':'6c2f08dac7b248f94c2fd1125545031eeaa01e13','sourceFiles':members,'currentMainSourceClaimed':False},indent=2)+'\n')
donor=json.loads((PARENT/'packet-manifest.json').read_bytes())
assert item(PARENT/'packet-manifest.json')['sha256']=='a64bd1d658039d46b3ec4974207c650ec544680b675978740462d12edb71d464'
origins={'native-input.json':PARENT/'original-unrestricted-input.json','parent-result.json':PARENT/'run/result.json','parent-postflight.json':PARENT/'run/postflight.json','all-owned-approaches.json':PARENT/'run/all-owned-approaches.json',**{f'job-{i}.json':PARENT/f'run/observed/job-{i}.json' for i in [1,2,3]}}
for name,origin in origins.items():assert item(ROOT/name)['sha256']==item(origin)['sha256']
assert item(ROOT/'native-input.json')['sha256']=='7e4aeb59ba9c4e4419b33031ce3350a0262ecdbebd5cb85716e4d3599dd91f71'
assert item(ROOT/'parent-result.json')['sha256']=='470320e3e062b4b4713efc7abacd373283ac1ab15020ec55e796c0b58568633a'
assert item(LAYOUT)['sha256']=='98a50b122e6a550c3020c935886d6832dbae34e333ea135e28e9bc555c973d5e'
registry=json.loads((ROOT/'physical-reference-registry.json').read_bytes());layout=json.loads(LAYOUT.read_bytes())
for key,typ,ids in [('sourceTraces','source_trace',['source_trace_932','source_trace_933']),('pcbPorts','pcb_port',['pcb_port_727','pcb_port_728','pcb_port_1162','pcb_port_1164']),('physicalVias','pcb_via',['pcb_via_0','pcb_via_1']),('physicalStubs','pcb_trace',['pcb_trace_0','pcb_trace_1'])]:
 field=typ+'_id';assert registry[key]==[r for r in layout if r.get('type')==typ and r.get(field) in ids]
PREDECESSOR=REPO/'.cache/g350-ti-public-cohort-partial-native-safe-next/packet-manifest.json'
assert item(PREDECESSOR)['sha256']=='3a72c28e314c1e5f9dc4c891047ab2dafdd54f0ed7ac09a854c89213ffdeeb67'
INCIDENT=REPO/".cache/g350-partial-native-prep-resource-incident.json"
assert item(INCIDENT)["sha256"]=="96046a94f7d12dfb36cbaf4dba680c412d58b750fc8f7599a2a65309bf5010bf"
HISTORICAL_RESULT=PREDECESSOR.parent/"run/result.json"
HISTORICAL_POST=PREDECESSOR.parent/"run/postflight.json"
assert item(HISTORICAL_RESULT)["sha256"]=="3260d4cc6558b68049c968fd594e06578799626d8f15343a52fedcb930e18a43"
assert item(HISTORICAL_POST)["sha256"]=="33ad435ccf030b03117a43b3ea93677415417573c46048a109e84086eec49226"
external=[HISTORICAL_RESULT,HISTORICAL_POST,INCIDENT,PREDECESSOR,PREPARED,PARENT/'packet-manifest.json',*origins.values(),LAYOUT,REPO/'package.json',REPO/'tsconfig.json',REPO/'bunfig.toml',Path('/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe')]
absent=[name.replace(str(PARENT),str(ROOT)) for name in donor['requiredAbsentRuntimeFiles']]
for name in absent:assert not Path(name).exists() and not Path(name).is_symlink(),name
files=[item(path,True) for path in sorted(ROOT.rglob('*')) if path.is_file() and not path.is_symlink() and not any(x in ['run','__pycache__','prep-validation'] for x in path.relative_to(ROOT).parts) and path.name!='packet-manifest.json']
manifest={'schemaVersion':5,'referenceDrcOwnersSemanticOnly':True,'referenceComponentTerminals':'Only actual cap727/728; via aliases remainsourceContacts/viaAliasContacts+physicalCu','originalDrcCallsPerActualSuite':2,'negativeRealComponentEndpointControl':'Clone onlysource932 physicaloutput barrel ontoactualcap727; unchanged DRC mustreject; neverobservedCu','largeCaptureInvariantDiagnosticBounded':True,'preparationTestsOwnedResourceGuard':{'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5},'predecessorPacketSha256':item(PREDECESSOR)['sha256'],'predecessorPreservedImmutable':True,'parentCaptureSummaryValidation':'Exact original argumentSha256/resultSha256 projection with remaining fields and chronological order held','preparedUtc':datetime.now(timezone.utc).isoformat(),'sourceRevision':'c1151212be7b9de4b34b07436d135d874e6c0466','libTree':'6c2f08dac7b248f94c2fd1125545031eeaa01e13','originalPreparedPath':str(PREPARED),'originalSourceMemberCount':177,'files':files,'externalFiles':[item(path) for path in external],'requiredAbsentRuntimeFiles':absent,'policy':{'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5},'qualificationScope':'partial-four-natural-strobe-paths','inputCounts':{'nativeSignals':49,'obstacles':856,'ownedApproaches':24,'fixedReferences':2,'drcOwners':51},'expectedOutputCounts':{'naturalCarriers':4,'joinedDqs0Approaches':4,'retainedOtherApproaches':20,'allPhysicalTraces':26,'uniqueCopperVias':26},'dependencyReceiptSha256':donor['dependencyReceiptSha256'],'dependencyTreeSha256':donor['dependencyTreeSha256'],'dependencyArchiveSha256':donor['dependencyArchiveSha256'],'inputBindings':{name:item(ROOT/name,True) for name in [*origins,'physical-reference-registry.json']},'parentPrefixPacketSha256':item(PARENT/'packet-manifest.json')['sha256'],'parentPrefixResultSha256':item(PARENT/'run/result.json')['sha256'],'parentPrefixRootActual':'6479','physicalSourceLayoutSha256':item(LAYOUT)['sha256'],'sourceChecks':['original joinSignalEscapes per owner','original validateG350PathIntegrity generated DDR and reference separately','original nativeSignalGeometryIsValid','pinned fanout validateRoutedCopperDrc explicit51owner view','original pairLengthReports','original pairCouplingReports','original exteriorPairSpacingReports','original boardOutlineViolations','original generatedEscapeHolesConflict full physical pairs'],'originalUnrestrictedInputHeld':True,'referenceOwnerRegistrationChangesHardware':False,'physicalFailureIsNotDiagnosticExecutionFailure':True,'sourceCallsAtPreparation':0,'newInitializerCalls':0,'newRoutingCalls':0,'rootActualGoRequired':True,'wholeBusMatchingQualified':False,'full49Qualified':False,'electricalTimingQualified':False,'accepted49':False,'fabricationReady':False,'currentMainC115Claimed':False}
(ROOT/'packet-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'packetSha256':item(ROOT/'packet-manifest.json')['sha256'],'localFiles':len(files),'externalFiles':len(external),'sourceMembers':177}))
