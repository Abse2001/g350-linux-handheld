"""Source-only stage-controller proposal; only explicit qualified root launch runs routing.

Uses the exact bound Linux owned-process helper and original policies. Preparing
or importing this file does not spawn children or import solver/native modules.
"""
from pathlib import Path
import argparse, datetime, hashlib, importlib.util, json, math, os, re, stat, sys
sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parent
BASE = Path('/workspace/bus-lanes-solver/.cache/g350-count-conditioned-site-recovery-next')
QUAL = Path('/workspace/bus-lanes-solver/.cache/g350-positive-native-bank-replay-v5-next')
PARENT = Path('/workspace/bus-lanes-solver/.cache/g350-ti-v7-v5-stage-primitives-point-annotation-overload-public-next')
NODE = '/workspace/g350-linux-handheld/.cloud-tools/node/bin/node'
BUN = '/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
SMALL_POLICY = {'wallSeconds': 60, 'rssBytes': 1024**3, 'sharedBytes': 24*1024**3, 'sampleSeconds': .05, 'termGraceSeconds': 5}
PUBLIC_POLICY = {'wallSeconds': 1200, 'rssBytes': 5*1024**3, 'sharedBytes': 26*1024**3, 'sampleSeconds': .05, 'termGraceSeconds': 5}
RUNTIME_SHA = '383dab3993fbd2128ad67bf3220f1342ef6252edad5c118264c9232ee03541b5'
RUNTIME_CLOSURE = '3f221c12ec2bf0040728eb3839ed60376a30f805ac46a6a1e768f3ff28bcdc7c'
OPTIONS = {'maxBusViaCountSkew': 0, 'maxPairViaCountSkew': 0, 'precheckEnclosedTerminals': True, 'originalCorridorTuningCandidates': 4096}
OBSERVATION_MODE = 'PRIMITIVE_GRID_REPLAY_STATS_AND_PUBLIC_STEP_ONLY'
ROOT_SCOPE = 'one-node25-v5-runtime127-ti-v12d-byte0-top-reset-bottom-public-control'
QUAL_SCOPE = 'one-node25-v5-runtime127-ti-v12d-byte0-top-reset-bottom-build-control'
PREVIOUS_PUBLIC_CLOSED_PATH = Path('/workspace/bus-lanes-solver/.cache/root-routing-progress/v12c-actual-COLLECTED-root.json')
PREVIOUS_PUBLIC_CLOSED_SHA = 'da96396b0aa572ff128aadd215ca206d51a3a49970c161ec973ef543061bc3a6'
PREVIOUS_PUBLIC_OWNED_PGID = 277916
CONTROL_NAMES = ['qualification-build', 'api-bun', 'api-node', 'stats-bun', 'stats-node', 'stage-bundledBun', 'stage-bundledNode'] + [
    'native-' + fixture + '-' + engine + ('-observed' if observed else '-plain')
    for fixture in ['common', 'replay']
    for engine in ['unbundledBun', 'bundledBun', 'bundledNode']
    for observed in [False, True]
]
BUILD_ARTIFACTS = [
    prefix + suffix
    for prefix in ['runner', 'api-controls', 'native-controls', 'stats-controls', 'stage-controls']
    for suffix in ['.cjs']
] + ['bundle-metafile.json', 'build-receipt.json'] + [
    prefix + suffix
    for prefix in ['api-controls', 'native-controls', 'stats-controls', 'stage-controls']
    for suffix in ['-metafile.json', '-build-receipt.json']
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def write_new(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def verify_files(directory, rows):
    for row in rows:
        path = Path(row['path']) if directory is None else directory / row['path']
        assert not path.is_symlink() and path.is_file(), str(path)
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], str(path)
        assert stat.S_IMODE(path.stat().st_mode) == row['mode'], str(path)



FAMILY_SHA = 'ec6b1cee5ecac0ace96d79b97f70d2e409941878dbf25dbc2af74c1a6e39dacb'
FAMILY = Path('/workspace/bus-lanes-solver/.cache/g350-ti-v7-v5-cross-family-selection-qualification-v2-next')
V10_CONTEXT = Path('/workspace/bus-lanes-solver/.cache/g350-ti-v10-actual-core-input-provenance-next')
V10_CONTEXT_SHA = '808973497c8fc33ef8e012fd0026eaef024aa12bf8505a71b9875fa6b84ccf97'
NODE5_NAMES = ['build-deterministic', 'node-caller-plain', 'node-caller-observed', 'node-native-common-observed', 'node-native-replay-observed']
NODE5_OUTPUTS = ['runner.cjs', 'bundle-metafile.json', 'build-receipt.json'] + [prefix + suffix for prefix in ['api-controls', 'native-controls', 'stats-controls', 'stage-controls', 'selection-controls', 'caller-selection-controls'] for suffix in ['.cjs', '-metafile.json', '-build-receipt.json']]

def verify_family_and_v10(packet):
    assert sha(ROOT / 'CROSS-FAMILY-QUALIFIED.json') == packet['inheritedFamilyReceiptSha256'] == FAMILY_SHA
    proof = json.loads((ROOT / 'CROSS-FAMILY-QUALIFIED.json').read_bytes())
    assert proof['passed'] is True and proof['preparedManifestSha256'] == '64d84c729f54379a56a1ab0ced70968f863ec1fae12f79d78f8628e0a8c1d3d5'
    assert proof['observerSha256'] == sha(ROOT / 'global-selection-primitives.ts') == '941e161193e6e4c5d45e26d15760761ff75bec70ee70481da4b3a430a48c78bd'
    for field in ['source164Runtime127AndCompiled21ArtifactsHeld', 'sameNineNetPhysicsYieldsAndRawStates', 'candidateConnectionOrCarrierOwnerOwnDataOnly', 'unknownGetterMixedShapesFailClosed', 'originalCallbackAndAllArgumentsReceiverResultsErrorsPreserved', 'dependenciesMainGitHeldOomZeroAndGroupsEmpty']:
        assert proof[field] is True
    assert proof['unbundledGlobalObserverQualified'] is False and proof['actualG350Routing'] is False and proof['accepted49'] is False
    assert len(proof['actualOriginalNativeNineNetCallerBothEngines']) == 2
    assert all(row['actualNative9CallerPlainObservedParity'] is True and row['poolHits'] > 0 and row['pruneHits'] > 0 and row['assignments'] > 0 for row in proof['actualOriginalNativeNineNetCallerBothEngines'])
    assert len(proof['physics1879And4275HistoricalParities']) == 4 and all(row['fullHistoricalLedgerParityExcludingOnlyGlobalSelection'] is True and row['assertions'] in [1879,4275] for row in proof['physics1879And4275HistoricalParities'])
    assert proof['runtimeLibraryManifestSha256'] == RUNTIME_SHA and proof['runtimeClosureSha256'] == RUNTIME_CLOSURE
    binding = module('v10_pure_input_context', V10_CONTEXT / 'v10_input_provenance.py')
    binding.verify(V10_CONTEXT_SHA)
    bridge = module('v11_pure_layer_bridge', Path(packet['v12dBridgeModulePath']))
    actual = bridge.verify_producer_inputs(ROOT, packet['v12dBridgeManifestSha256'])
    assert actual['signalLayersAllowed']==['top','inner1','inner2','bottom'] and actual['naturallyDerivedGenericDefaultCap']==800_000 and actual['nativePlacementChecks']==17
    assert actual['referenceQualified'] is False and actual['TIplaneArrangement'] is False
    assert actual['physicalInputExactlyHeld'] is True and actual['onlyLayerListsChanged'] is True

def node5_ledger(path):
    rows=[]
    for line in Path(path).read_text().splitlines():
        try: value=json.loads(line)
        except json.JSONDecodeError: continue
        if isinstance(value,dict) and ('mode' in value or 'fixtureReport' in value): rows.append(value)
    assert len(rows)==1
    return rows[0]

def selection_semantics_without_elapsed(value):
    assert isinstance(value,dict)
    result=json.loads(json.dumps(value))
    last=result.get('last')
    if last is not None:
        assert isinstance(last,dict) and 'elapsedMs' in last
        elapsed=last.pop('elapsedMs')
        assert type(elapsed) in [int,float] and math.isfinite(elapsed) and elapsed>=0
    return result

def node5_rows(packet):
    rows=list(packet['files'])
    relative=NODE5_OUTPUTS + ['node5-qualification-receipt.json'] + ['qualification-node5/'+name+'/'+part for name in NODE5_NAMES for part in ['execution.json','child.log','memory.jsonl']] + ['qualification-node5/'+name+'-argv.json' for name in NODE5_NAMES]
    for name in relative:
        path=ROOT/name
        assert path.is_file() and not path.is_symlink()
        rows.append({'path':name,'sha256':sha(path),'bytes':path.stat().st_size,'mode':stat.S_IMODE(path.stat().st_mode)})
    assert len({row['path'] for row in rows})==len(rows)
    return rows

def qualify_build_only(packet, prepared_sha, authority_path, authority_sha):
    root_authority(authority_path, authority_sha, prepared_sha, QUAL_SCOPE, SMALL_POLICY)
    assert not any((ROOT/name).exists() for name in ['runner.cjs','error-capture-qualification','QUALIFIED-candidate-manifest.json','FINAL-manifest.json'])
    before_deps = dependency_check()
    scope = module('error_capture_qualification_scope', BASE/'process_scope.py')
    run = ROOT/'error-capture-qualification'; run.mkdir(); (run/'tmp').mkdir()
    results = []
    for name, argv in [('build-deterministic', [NODE,str(ROOT/'build.cjs')])]:
        arg_path=run/(name+'-argv.json');write_new(arg_path,argv)
        execution=controlled_run(scope,'error-capture-qualification/'+name,[BUN,'--smol',str(ROOT/'build-leader.ts'),str(arg_path)],SMALL_POLICY,2*1024**3,{'TMPDIR':str(run/'tmp')})
        results.append({'name':name,'execution':execution})
        if not clean(execution):
            write_new(ROOT/'error-capture-qualification-receipt.json',{'passed':False,'results':results,'scope':'Fresh deterministic build only; no solver/native calls'})
            return 1
        prepared()
    assert (ROOT/'inherited-final-v12d-authored-props.json').stat().st_size <= 64*1024
    bridge=module('v11_actual_final_props',Path(packet['v12dBridgeModulePath']))
    final_props=bridge.verify_actual_authored_props(ROOT/'inherited-final-v12d-authored-props.json')
    assert final_props['actualFinalReactTreeEvaluated'] is True and final_props['derivedProofSha256']==packet['v12dDerivedAuthoredPropsSha256']
    build=json.loads((ROOT/'build-receipt.json').read_bytes()); assert build['deterministicTwoBuilds'] is True and build['bundleSha256']==sha(ROOT/'runner.cjs')
    after_deps=dependency_check();prepared();assert before_deps==after_deps
    receipt={'passed':True,'scope':'Fresh deterministic build with owned-leader drain; clean actual V12d final React props reused from root66868; no Core/native/router calls or pure/native repeats','results':results,'actualFinalReactProps':final_props,'inheritedActualReactExecution':packet['actualV12dReactExecution'],'inheritedActualReactReceiptSha256':packet['actualV12dReactReceiptSha256'],'inheritedPure11ReceiptSha256':packet['parentErrorCaptureReceiptSha256'],'dependenciesBefore':before_deps,'dependenciesAfter':after_deps,'preparedManifestSha256':prepared_sha,'parentFinalSha256':packet['parentFinalSha256'],'actualG350Routing':False,'accepted49':False}
    write_new(ROOT/'error-capture-qualification-receipt.json',receipt)
    rows=list(packet['files'])
    for name in ['runner.cjs','bundle-metafile.json','build-receipt.json','error-fields-controls.cjs','error-fields-controls-metafile.json','error-fields-controls-build-receipt.json','error-capture-qualification-receipt.json']:
        path=ROOT/name;rows.append({'path':name,'sha256':sha(path),'bytes':path.stat().st_size,'mode':stat.S_IMODE(path.stat().st_mode)})
    candidate={**packet,'files':rows,'nodeArtifactQualified':True,'nodeArtifactSha256':sha(ROOT/'runner.cjs'),'preparedManifestSha256':prepared_sha,'qualificationReceiptSha256':sha(ROOT/'error-capture-qualification-receipt.json'),'scope':'Qualified bounded public-error capture; original Node5 physics/caller proof reused; root final/public authority pending'}
    write_new(ROOT/'QUALIFIED-candidate-manifest.json',candidate)
    print(json.dumps({'passed':True,'candidateManifestSha256':sha(ROOT/'QUALIFIED-candidate-manifest.json'),'qualificationReceiptSha256':candidate['qualificationReceiptSha256'],'actualG350Routing':False}))
    return 0


def prepared():
    path = ROOT / 'PREPARED-controller-manifest-v1.json'
    packet = json.loads(path.read_bytes())
    verify_files(ROOT, packet['files'])
    verify_files(None, packet['externalFiles'])
    assert packet['sourceManifestSha256'] == RUNTIME_SHA and packet['sourceClosureSha256'] == RUNTIME_CLOSURE
    assert packet['requestedOptions'] == OPTIONS and packet['policy'] == PUBLIC_POLICY
    assert packet['nodeArtifactQualified'] is False and packet['actualG350Routing'] is False
    assert packet['unbundledGlobalObserverQualified'] is False
    parent=json.loads(Path(packet['parentFinalPath']).read_bytes())
    assert sha(packet['parentFinalPath'])==packet['parentFinalSha256']=='00ac5e6e77e8db247ad9747e0c873167f4ebb8cbe5c5a7cf6d517146e4414534'
    assert parent['nodeArtifactQualified'] is True and parent['sourceManifestSha256']==RUNTIME_SHA
    receipt=json.loads(Path(packet['parentNode5ReceiptPath']).read_bytes())
    assert sha(packet['parentNode5ReceiptPath'])==packet['parentNode5ReceiptSha256']==parent['parentNode5ReceiptSha256']
    assert receipt['passed'] is True and len(receipt['results'])==5 and all(clean(row['execution']) for row in receipt['results'])
    fields=json.loads(Path(packet['parentErrorCaptureReceiptPath']).read_bytes())
    assert sha(packet['parentErrorCaptureReceiptPath'])==packet['parentErrorCaptureReceiptSha256']==parent['parentErrorCaptureReceiptSha256']=='9651257869158ce301134d35d257cc3cf658d29e16bd6cc5cf7d28dbbe11f7c7'
    assert fields['passed'] is True and fields['controls']['assertions']==11 and all(clean(row['execution']) for row in fields['results'])
    react_receipt=json.loads(Path(packet['actualV12dReactReceiptPath']).read_bytes())
    assert sha(packet['actualV12dReactReceiptPath'])==packet['actualV12dReactReceiptSha256']
    assert clean(react_receipt['execution'])
    assert sha(ROOT/'inherited-final-v12d-authored-props.json')==packet['actualV12dReactCaptureSha256']
    bridge=module('inherited_v12d_final_props',Path(packet['v12dBridgeModulePath']))
    assert bridge.verify_actual_authored_props(ROOT/'inherited-final-v12d-authored-props.json')['actualFinalReactTreeEvaluated'] is True
    assert packet['observationMode'] == OBSERVATION_MODE and packet['finiteArtifactList'] is True
    assert os.environ.get('NODE_OPTIONS', '') == '', 'Reject nonempty NODE_OPTIONS; do not silently override it'
    assert os.environ.get('NODE_PATH', '') == packet['inheritedEnvironment']['NODE_PATH']
    for link in [ROOT / 'node_modules', ROOT / 'source' / 'node_modules']:
        assert link.is_symlink() and os.readlink(link) == '/workspace/bus-lanes-solver/node_modules'
        assert link.resolve() == Path('/workspace/bus-lanes-solver/node_modules')
    runtime = json.loads((ROOT / 'qualified-runtime-library-manifest.json').read_bytes())
    assert sha(ROOT / 'qualified-runtime-library-manifest.json') == RUNTIME_SHA
    verify_files(ROOT / 'source', runtime['files'])
    expected = {row['path'] for row in runtime['files'] if row['path'].startswith('lib/')}
    actual = {str(path.relative_to(ROOT / 'source')) for path in (ROOT / 'source' / 'lib').rglob('*') if path.is_file() or path.is_symlink()}
    assert actual == expected, 'Unlisted production resolver/source entry'
    assert sha(QUAL / 'qualified-source-manifest.json') == '4369714a5cdd69e6aed9261f279c73a08ac7e32123232efef86f9e97917eb9a8'
    full = json.loads((QUAL / 'qualified-source-manifest.json').read_bytes())
    verify_files(QUAL / 'source', [{**row, 'mode': full['filesystemModes'][row['path']]} for row in full['sourceFiles']])
    assert sha(QUAL / 'RELEASE.json') == packet['qualifiedReleaseSha256']
    assert json.loads((QUAL / 'RELEASE.json').read_bytes())['currentFullUnitQualified'] is True
    return packet, sha(path)


def dependency_check():
    verifier = module('stage_trusted_dependencies', BASE / 'verify-installed-dependencies.py')
    result = verifier.verify(BASE / 'dependencies/archive-receipt.json', '1a49a60909258b542c7f4899e6378fa9f10c1cea08ef1aaf4b5366480dbf71b7', BASE / 'audit-installed-dependencies.py')
    assert result['treeSha256'] == '47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
    return result


def root_authority(path, expected_sha, prepared_sha, scope, policy=None):
    raw = Path(path).read_bytes()
    assert expected_sha and hashlib.sha256(raw).hexdigest() == expected_sha
    value = json.loads(raw)
    assert value['authorizedByRoot'] is True and value['scope'] == scope
    assert value['preparedManifestSha256'] == prepared_sha
    assert re.fullmatch('[0-9a-f]{32,128}', value['approvalToken'])
    if policy is not None:
        assert value['policy'] == policy
    assert value['previousPublicCollected'] is True
    closed_path = Path(value['previousPublicCollectedReceiptPath'])
    assert closed_path.resolve() == PREVIOUS_PUBLIC_CLOSED_PATH
    assert value['previousPublicCollectedReceiptSha256'] == PREVIOUS_PUBLIC_CLOSED_SHA
    closed_raw = closed_path.read_bytes()
    assert hashlib.sha256(closed_raw).hexdigest() == PREVIOUS_PUBLIC_CLOSED_SHA
    closed = json.loads(closed_raw)
    assert closed['sessionId'] == 82651 and closed['collectedExitCode'] == 0 and closed['naturalFailure'] is True
    assert closed['postauditSha256']=='afbaff708649b388fd1e62c274343d79f104c16ac9411220a4cb49d55dc95117'
    previous_post=Path('/workspace/bus-lanes-solver/.cache/g350-ti-v12c-distinct-cohort-public-next/EXECUTION-postaudit.json')
    assert sha(previous_post)==closed['postauditSha256']
    closed_post=json.loads(previous_post.read_bytes())
    assert closed_post['sourceAndArtifactHeld'] is True and closed_post['dependenciesBefore']==closed_post['dependenciesAfter']
    execution = closed['execution']
    assert execution['cleanupOwnedGroupEmpty'] is True and execution['exitCode'] == 0 and execution['diagnosticStopped'] is False and not any(execution['oomDelta'].values())
    assert value['previousPublicOwnedPgid'] == execution['pgid'] == PREVIOUS_PUBLIC_OWNED_PGID
    assert PREVIOUS_PUBLIC_OWNED_PGID > 0 and PREVIOUS_PUBLIC_OWNED_PGID != os.getpid()
    owned_scope = module('global_selection_closed_public_scope', BASE / 'process_scope.py')
    assert not owned_scope.owned(PREVIOUS_PUBLIC_OWNED_PGID)
    return value


def controlled_run(scope, name, command, policy, reserve, environment=None):
    baseline = scope.memory()

    def gate(current):
        assert current['current'] + policy['rssBytes'] + reserve < policy['sharedBytes'], 'Strict prefork reserve required'
        assert all(current['events'][key] == baseline['events'][key] for key in scope.OOM_KEYS)

    return scope.run_guarded(command, ROOT, ROOT / name, policy, environment or {}, before_spawn=gate)


def clean(execution):
    return execution['exitCode'] == 0 and not execution['diagnosticStopped'] and execution.get('cleanupOwnedGroupEmpty') and not any(execution.get('oomDelta', {}).values())








def reuse_light(packet):
    value = json.loads(Path(packet['lightReceiptPath']).read_bytes())
    preservation = json.loads(Path(packet['lightSourcePreservationPath']).read_bytes())
    assert value['passed'] is True and value['nativeRouterCadInvoked'] is False and clean(value['execution'])
    assert value['scriptSha256'] == sha(ROOT / 'light-checks.sh') and value['lightCommandSha256'] == sha(ROOT / 'LIGHT_COMMAND.json')
    assert preservation['allSourceRowsHeldAfterLightCheck'] is True and preservation['nativeCalls'] is False
    assert preservation['preparedManifestSha256'] == packet['freshLightSourceManifestSha256']
    rows = [json.loads(line) for line in Path(packet['lightLogPath']).read_text().splitlines() if line.startswith('{')]
    assert len(rows) == 1 and rows[0]['passed'] is True and rows[0]['assertions'] == 7844
    assert rows[0]['syntheticOnly'] is True and rows[0]['actualNativeRoutingExecuted'] is False
    return {'scope': 'Reused exact fresh root-run unbundled Bun synthetic7844 plus staticTypeScript only; no historical observer pass relabeled or native parity conferred', 'execution': value['execution'], 'sourcePreservation': preservation, 'syntheticReport': rows[0], 'receiptPath': packet['lightReceiptPath'], 'receiptSha256': packet['lightReceiptSha256']}




def freeze(packet, prepared_sha, peer_path, peer_sha):
    assert peer_path and peer_sha and sha(peer_path) == peer_sha
    assert not (ROOT / 'FINAL-manifest.json').exists()
    candidate = json.loads((ROOT / 'QUALIFIED-candidate-manifest.json').read_bytes())
    verify_files(ROOT, candidate['files'])
    assert candidate['preparedManifestSha256'] == prepared_sha and candidate['nodeArtifactSha256'] == sha(ROOT / 'runner.cjs')
    receipt = json.loads((ROOT / 'error-capture-qualification-receipt.json').read_bytes())
    assert receipt['passed'] is True and sha(ROOT / 'error-capture-qualification-receipt.json') == candidate['qualificationReceiptSha256']
    peer = json.loads(Path(peer_path).read_bytes())
    assert peer['candidateManifestSha256'] == sha(ROOT / 'QUALIFIED-candidate-manifest.json') and peer['qualificationReceiptSha256'] == candidate['qualificationReceiptSha256'] and peer['approvedForRootLaunch'] is True
    final = {**candidate, 'peerReviewPath': str(Path(peer_path).resolve()), 'peerReviewSha256': peer_sha, 'candidateManifestSha256': sha(ROOT / 'QUALIFIED-candidate-manifest.json')}
    write_new(ROOT / 'FINAL-manifest.json', final)
    print(json.dumps({'nodeArtifactQualified': True, 'finalManifestSha256': sha(ROOT / 'FINAL-manifest.json'), 'actualG350Routing': False}))
    return 0


def launch(packet, prepared_sha, authority_path, authority_sha):
    assert (ROOT / 'FINAL-manifest.json').is_file(), 'Actual build/native/peer qualification required'
    final = json.loads((ROOT / 'FINAL-manifest.json').read_bytes())
    verify_files(ROOT, final['files'])
    assert final['finiteArtifactList'] is True and final['nodeArtifactQualified'] is True
    assert final['policy'] == PUBLIC_POLICY and final['requestedOptions'] == OPTIONS and final['observationMode'] == OBSERVATION_MODE
    assert final['sourceManifestSha256'] == RUNTIME_SHA and final['sourceClosureSha256'] == RUNTIME_CLOSURE
    assert sha(final['peerReviewPath']) == final['peerReviewSha256'] and sha(ROOT / 'QUALIFIED-candidate-manifest.json') == final['candidateManifestSha256']
    assert final['inheritedEnvironment'] == packet['inheritedEnvironment']
    assert final['nodeArtifactSha256'] == sha(ROOT / 'runner.cjs')
    build_qualification=json.loads((ROOT/'error-capture-qualification-receipt.json').read_bytes())
    assert build_qualification['passed'] is True and len(build_qualification['results'])==1 and all(clean(row['execution']) for row in build_qualification['results'])
    bridge=module('v11_final_props_launch_binding',Path(packet['v12dBridgeModulePath']))
    assert bridge.verify_actual_authored_props(ROOT/'inherited-final-v12d-authored-props.json')==build_qualification['actualFinalReactProps']
    authority = root_authority(authority_path, authority_sha, prepared_sha, ROOT_SCOPE, PUBLIC_POLICY)
    final_sha = sha(ROOT / 'FINAL-manifest.json')
    assert authority['packetSha256'] == final_sha
    assert not (ROOT / 'run').exists(), 'Fresh actual run directory required'
    before_deps = dependency_check()
    scope = module('stage_public_owned_scope', BASE / 'process_scope.py')
    execution = controlled_run(scope, 'run', [NODE, str(ROOT / 'runner.cjs'), '--run-one-approved'], PUBLIC_POLICY, 1024**3, {'G350_NODE_UNINSTRUMENTED_APPROVED': '1', 'G350_NODE_RECEIPT_PATH': str(Path(authority_path).resolve()), 'G350_NODE_RECEIPT_SHA256': authority_sha})
    verify_files(ROOT, final['files'])
    prepared()
    after_deps = dependency_check()
    result_path = ROOT / 'run' / 'result.json'
    result = json.loads(result_path.read_bytes()) if result_path.is_file() else None
    post_memory = scope.memory()
    post_oom_delta = {key: post_memory['events'][key] - execution['memoryBefore']['events'][key] for key in scope.OOM_KEYS}
    identity = result is not None and result.get('engine') == 'v25.6.1' and result.get('execArgv') == [] and result.get('inheritedNodeOptions') == '' and result.get('inheritedNodePath') == packet['inheritedEnvironment']['NODE_PATH'] and result.get('packetSha256') == final_sha and result.get('sourceCommit') is None and result.get('sourceFileCount') == 127 and result.get('sourceManifestSha256') == RUNTIME_SHA and result.get('sourceClosureSha256') == RUNTIME_CLOSURE and result.get('nodeArtifactSha256') == final['nodeArtifactSha256'] and result.get('inputSha256') == packet['inputBindings']['input.json']['sha256'] and result.get('originalInputSha256') == packet['inputBindings']['original-unrestricted-input.json']['sha256'] and result.get('requestedOptions') == OPTIONS and result.get('actualOptions') == OPTIONS
    physical = result is not None and result.get('publicPipelineExecuted') is True and result.get('originalDefaultCap') == 800_000 and result.get('capUnchanged') is True and result.get('requestedOptionsHeld') is True and result.get('inputUnchanged') is True and result.get('fullHardwareHeld') is True and result.get('fixedReferencesHeld') is True and result.get('suppliedPhysicalReferences') == 2
    terminal = result.get('terminal') if result is not None else None
    terminal_held = isinstance(terminal, dict) and terminal.get('defaultCap') == 800_000 and terminal.get('termination') in ['NATURAL_SOLVED', 'NATURAL_FAILED', 'ORIGINAL_CAP_REACHED_UNRESOLVED'] and isinstance(terminal.get('publicSteps'), int) and 0 <= terminal['publicSteps'] <= 800_000
    output_held = result is not None and result.get('naturalOutputGateHeld') is True
    output_path = ROOT / 'run' / 'natural-public-output.json'
    if terminal_held and terminal['termination'] == 'NATURAL_SOLVED':
        item = result.get('publicOutput')
        output_held = output_held and isinstance(item, dict) and item.get('path') == 'natural-public-output.json' and output_path.is_file() and output_path.stat().st_size == item.get('bytes') and sha(output_path) == item.get('sha256') and result.get('actualSolverState', {}).get('solved') is True and result.get('actualSolverState', {}).get('failed') is False and result.get('actualSolverState', {}).get('actualTraceCount') == 49
        if output_held:
            actual = json.loads(output_path.read_bytes())
            original = json.loads((ROOT / 'input.json').read_bytes())
            expected_names = {connection['name'] for connection in original['connections']}
            names = [trace.get('connection_name', trace.get('source_trace_id')) for trace in actual.get('traces', [])[2:]]
            output_held = len(actual.get('traces', [])) == 51 and actual['traces'][:2] == original['traces'] and len(names) == 49 and len(set(names)) == 49 and set(names) == expected_names and {key: value for key, value in actual.items() if key != 'traces'} == {key: value for key, value in original.items() if key != 'traces'}
    elif terminal_held:
        output_held = output_held and result.get('publicOutput') is None and not output_path.exists()
    observations = result is not None and result.get('observationMode') == OBSERVATION_MODE and result.get('factoryOrSiteTelemetryInstalled') is False and result.get('moduleReplacementInstalled') is False and result.get('gridOriginalMethodPrimitiveTelemetryInstalled') is True and result.get('gridConstructorReplacementInstalled') is False and result.get('writeErrors') == 0 and 0 <= result.get('progressRows', -1) <= 64 and 0 <= result.get('progressBytes', -1) <= 24*1024 and result.get('accepted49') is False and result.get('tiEligibleBoard') is False and result.get('fabricationReady') is False
    bank = result.get('positiveBankStats') if result is not None else None
    bank_held = isinstance(bank, dict) and bank.get('observationErrors') == 0 and bank.get('expectedOrdinaryCount') == 43 and bank.get('retainedInstances') is False and bank.get('retainedBankGeometry') is False and bank.get('weakRefUsed') is False and result.get('statsBindingsRestored') is True and 0 <= result.get('statsWrites', -1) <= 1602 and 0 <= result.get('statsBytes', -1) <= 128*1024
    stage = result.get('stagePrimitives') if result is not None else None
    stage_held = isinstance(stage, dict) and stage.get('observationErrors') == 0 and stage.get('snapshotOverflows') == 0 and stage.get('retainedInstances') is False and stage.get('retainedGeometryObjects') is False and stage.get('retainedBankValues') is False and stage.get('weakRefUsed') is False and stage.get('additionalGridCalls') == 0 and stage.get('constructorReplacementInstalled') is False and result.get('stageBindingsRestored') is True
    telemetry = result.get('stageTelemetry') if result is not None else None
    telemetry_held = isinstance(telemetry, dict) and telemetry.get('failedPublications') == 0 and telemetry.get('rejectedRows') == 0 and 0 <= telemetry.get('retainedRows', -1) <= 16 and 0 <= telemetry.get('serializedBytes', -1) <= 128*1024 and 0 <= telemetry.get('successfulPublications', -1) <= 1603
    rolling_path = ROOT / 'run' / 'latest-stage-primitives.jsonl'
    rolling = None
    if rolling_path.is_file():
        assert rolling_path.stat().st_size <= 128*1024
        rolling = [json.loads(line) for line in rolling_path.read_text().splitlines()]
        assert 0 < len(rolling) <= 16
        for row in rolling:
            assert row['packetSha256'] == final_sha and row['sourceManifestSha256'] == RUNTIME_SHA and row['inputSha256'] == packet['inputBindings']['input.json']['sha256']
            assert row['diagnosticOnly'] is True and row['accepted49'] is False
            assert row['publicationKind'] in ['periodic-public-hook', 'last-observed-public-hook']
            public = row['publicStepBinding']
            assert isinstance(public['publicSteps'], int) and 0 <= public['publicSteps'] <= 800_000 and public['defaultCap'] == 800_000
            assert public['elapsedMs'] <= row['publishedElapsedMs']
    global_selection = result.get('globalSelectionStats') if result is not None else None
    global_held = isinstance(global_selection, dict) and global_selection.get('totals', {}).get('observationErrors') == 0 and global_selection.get('totals', {}).get('snapshotOverflows') == 0 and global_selection.get('retainedDomains') is False and global_selection.get('retainedCandidates') is False and global_selection.get('retainedGeometry') is False and global_selection.get('weakRefsUsed') is False and global_selection.get('callbackArgumentsReplaced') is False and global_selection.get('additionalSolverCalls') == 0 and result.get('selectionBindingsRestored') is True
    failure_fields=result.get('actualSolverState') if result is not None else None
    error_capture_held=isinstance(failure_fields,dict) and all(failure_fields.get(key) is None or (isinstance(failure_fields.get(key),str) and len(failure_fields[key])<=1024) for key in ['error','failureCode']) and all(failure_fields.get(key) in ['string','null','absent','accessor','unsupported'] for key in ['errorFieldKind','failureCodeFieldKind']) and all(type(failure_fields.get(key)) is bool for key in ['errorTruncated','failureCodeTruncated'])
    valid = error_capture_held and global_held and clean(execution) and not any(post_oom_delta.values()) and before_deps == after_deps and result is not None and result.get('diagnosticQualified') is True and result.get('originalException') is None and identity and physical and terminal_held and output_held and observations and bank_held and stage_held and telemetry_held and rolling is not None
    receipt = {'execution': execution, 'dependenciesBefore': before_deps, 'dependenciesAfter': after_deps, 'sourceAndArtifactHeld': True, 'result': result, 'lastStagePrimitivePublicRows': rolling, 'postflightOomDelta': post_oom_delta, 'trustConjuncts': {'identityHeld': identity, 'physicalInputAndCapHeld': physical, 'originalTerminalHeld': terminal_held, 'naturalOutputGateHeld': output_held, 'boundedOriginalMethodObservationsHeld': observations, 'boundedBankObservationsHeld': bank_held, 'boundedStagePrimitiveObservationsHeld': stage_held, 'boundedStepBoundTelemetryHeld': telemetry_held, 'boundedGlobalSelectionObserved': global_held, 'boundedOwnDataPublicFailureFieldsHeld':error_capture_held}, 'diagnosticTrustEligible': valid, 'actualG350Routing': True, 'accepted49': False, 'fabricationReady': False}
    write_new(ROOT / 'EXECUTION-postaudit.json', receipt)
    print(json.dumps({'diagnosticTrustEligible': valid, 'accepted49': False}))
    return 0 if valid else 2


def main():
    parser = argparse.ArgumentParser()
    select = parser.add_mutually_exclusive_group(required=True)
    select.add_argument('--preflight', action='store_true')
    select.add_argument('--qualify-build-only', action='store_true')
    select.add_argument('--freeze-qualified', action='store_true')
    select.add_argument('--launch', action='store_true')
    parser.add_argument('--root-receipt', type=Path)
    parser.add_argument('--root-receipt-sha256')
    parser.add_argument('--peer-review', type=Path)
    parser.add_argument('--peer-review-sha256')
    args = parser.parse_args()
    packet, prepared_sha = prepared()
    if args.preflight:
        dependency_check()
        scope = module('global_selection_preflight_memory', BASE / 'process_scope.py')
        assert scope.memory()['current'] + PUBLIC_POLICY['rssBytes'] + 1024**3 < PUBLIC_POLICY['sharedBytes']
        print(json.dumps({'preparedManifestSha256': prepared_sha, 'phase': 'PREPARED_SOURCE_ONLY', 'nodeArtifactPresent': (ROOT / 'runner.cjs').exists(), 'finalArtifactVerified': False, 'actualG350Routing': False}))
        return 0
    if args.qualify_build_only:
        assert args.root_receipt and args.root_receipt_sha256
        return qualify_build_only(packet,prepared_sha,args.root_receipt,args.root_receipt_sha256)
    if args.freeze_qualified:
        dependency_check()
        return freeze(packet, prepared_sha, args.peer_review, args.peer_review_sha256)
    assert args.root_receipt and args.root_receipt_sha256
    return launch(packet, prepared_sha, args.root_receipt, args.root_receipt_sha256)


if __name__ == '__main__':
    raise SystemExit(main())
