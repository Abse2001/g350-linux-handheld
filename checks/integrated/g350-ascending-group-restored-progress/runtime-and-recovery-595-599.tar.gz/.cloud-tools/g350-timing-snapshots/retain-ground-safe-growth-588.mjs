import fs from 'node:fs'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {createG350PlanarPlanningValidator} from '../../scripts/lib/g350-ddr-planar-planning-validator.mjs'
import {fillG350LockedGround} from '../../scripts/lib/g350-locked-ground-fill.mjs'
import {ddrRouteLength} from '../../scripts/lib/g350-full-board-length-tuning.mjs'
const [basePath,donorPath,root,excludeText='DDR_A9']=process.argv.slice(2)
assert(basePath&&donorPath&&root&&!fs.existsSync(root))
const read=p=>JSON.parse(fs.readFileSync(p)).filter(e=>!e.type.includes('error')),base=read(basePath),donor=read(donorPath),c=structuredClone(base)
const excludes=new Set(excludeText.split(','));assert(excludes.size&&[...excludes].every(n=>n.startsWith('DDR_')))
const strip=p=>Object.fromEntries(Object.entries(p).filter(([k])=>!['copper_pour_id','is_inside_copper_pour'].includes(k)))
const names=new Map(base.filter(e=>e.type==='source_trace').map(e=>[e.source_trace_id,e.name]))
for(const type of ['source_trace','source_bus','source_port','source_net','source_component','pcb_board','pcb_component','pcb_port','pcb_smtpad','pcb_via','pcb_hole','pcb_plated_hole'])assert.deepEqual(base.filter(e=>e.type===type),donor.filter(e=>e.type===type),type)
const changed=[]
for(const t of c.filter(e=>e.type==='pcb_trace'&&names.get(e.source_trace_id)?.startsWith('DDR_')&&!excludes.has(names.get(e.source_trace_id)))){
 const d=donor.find(e=>e.type==='pcb_trace'&&e.pcb_trace_id===t.pcb_trace_id);assert(d&&d.source_trace_id===t.source_trace_id)
 const route=d.route.map(strip),original=t.route.map(strip)
 assert.deepEqual(route.filter(p=>p.route_type==='via'),original.filter(p=>p.route_type==='via'))
 assert.deepEqual([route[0],route.at(-1)],[original[0],original.at(-1)])
 if(JSON.stringify(route)===JSON.stringify(original))continue
 changed.push({signal:names.get(t.source_trace_id),beforeMm:ddrRouteLength(t.route),afterMm:ddrRouteLength(route)})
 t.route=route;delete t.trace_length
}
assert(changed.length)
assert.deepEqual(c.filter(e=>e.type!=='pcb_trace'||!names.get(e.source_trace_id)?.startsWith('DDR_')||excludes.has(names.get(e.source_trace_id))),base.filter(e=>e.type!=='pcb_trace'||!names.get(e.source_trace_id)?.startsWith('DDR_')||excludes.has(names.get(e.source_trace_id))))
const counts=createG350PlanarPlanningValidator(base).complete(c);assert(Object.values(counts).every(n=>n===0))
fs.mkdirSync(root);fs.copyFileSync('.cloud-tools/g350-timing-snapshots/retain-ground-safe-growth-588.mjs',root+'/merge.executed.mjs')
fs.writeFileSync(root+'/candidate.circuit.json',JSON.stringify(c,null,2)+'\n')
const g=await fillG350LockedGround(c);fs.writeFileSync(root+'/fresh-filled.circuit.json',JSON.stringify(g.circuit,null,2)+'\n')
const groups=c.filter(e=>e.type==='source_bus'&&e.name.startsWith('DDR_')&&e.max_length_skew!==undefined).map(b=>{const lengths=c.filter(e=>e.type==='pcb_trace'&&b.source_trace_ids.includes(e.source_trace_id)).map(t=>ddrRouteLength(t.route));return {name:b.name,skewMm:Math.max(...lengths)-Math.min(...lengths),limitMm:b.max_length_skew}})
assert(groups.filter(g=>g.name==='DDR_BYTE0'||g.name.endsWith('_PAIR')).every(g=>g.skewMm<=g.limitMm))
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex')
const report={inputs:[basePath,donorPath].map(path=>({path,sha256:hash(path)})),excludedSignals:[...excludes],changed,counts,groundPortErrors:g.portErrors,groups,passed:g.portErrors===0,barrelsEndpointsForeignGeometryExactlyPreserved:true,requiresFreshSourceNumericCadGerber:true,fabricationReady:false}
fs.writeFileSync(root+'/report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));process.exitCode=report.passed?0:1
