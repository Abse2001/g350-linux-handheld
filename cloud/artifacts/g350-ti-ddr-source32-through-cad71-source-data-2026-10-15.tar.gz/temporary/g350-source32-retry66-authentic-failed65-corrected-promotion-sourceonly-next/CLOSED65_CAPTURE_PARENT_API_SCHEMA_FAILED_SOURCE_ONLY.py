 def closed65():
  prior=closed64();assert prior['actualClosedScopeCount']==64
  for key in('actual65FailedCollectionPin','actual65PostauditPin','actual65CapturePhasePostPin','actual65CaptureChildLogPin','actual65FailedGuardManifestPin','actual65FailedSourceManifestPin','actual65FailedCaptureWorkerPin'):binding(proposal[key])
  r=read(proposal['actual65FailedCollectionPin']['path']);p=read(proposal['actual65PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==36546 and r['toolExitCode']==r['toolWrapperExitCode']==2
  assert r['postauditPath']==proposal['actual65PostauditPin']['path']and r['postauditSha256']==proposal['actual65PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['toolSessionCollected']is False
  for key,value in p.items():
   if key!='toolSessionCollected':assert r[key]==value,'Failed65 Root receipt preserves its original POST: '+key
  for doc in(r,p):
   assert doc['scope']=='ROOT_SOURCE32_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH64_AUTHENTIC_PRIOR_CLOSURES'and doc['phase']=='capture-types-core-batch'and doc['sourceManifestSha256']==proposal['actual65FailedSourceManifestPin']['sha256']and doc['rootGuardProposalManifestSha256']==proposal['actual65FailedGuardManifestPin']['sha256']
   assert doc['orderedPhaseNames']==['capture']and doc['expectedPhaseNames']==['capture','types','core']and doc['notAttemptedPhaseNames']==['types','core']and len(doc['phases'])==1
   for key in('historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passedMeansCaptureStrictTypesAndRawCore32Only','batchScopeContainsThreeSerialOwnedChildren','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   assert doc['allThreeChildrenNaturallyCompleted']is doc['passed']is False and doc['batchFailure']=='Phase capture failed; later phases not attempted'and doc['finalVerificationFailure']is None
   assert doc['captureChildInvocations']==1 and all(doc[key]==0 for key in('CoreCalls','typesChildInvocations','CoreChildInvocations','nativeCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'))
   for key in('Source32Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  row=p['phases'][0];assert row['phase']=='capture'and row['postauditPath']==proposal['actual65CapturePhasePostPin']['path']and row['postauditSha256']==proposal['actual65CapturePhasePostPin']['sha256']and read(row['postauditPath'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
  assert row['sourceAndDependenciesHeld']is row['ownedGroupEmptyActuallyObserved']is row['stageNaturallyCompleted']is True and row['ownedChildNatural0']is row['passed']is False and row['result']is None and row['outputFiles']==[]
  assert row['runFailure']is row['postverificationFailure']is row['outputBindingFailure']is None and row['resultInspectionFailure']=='AssertionError: '
  assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
  assert row['guardIdentityBefore']==row['guardIdentityAfter']==p['sameGuardIdentity']and p['sameGuardIdentity']['pid']==518922
  assert all(row[key]==0 for key in('CoreCalls','CoreChildInvocations','nativeCalls','originalApiCalls','cliCalls','cadCalls'))
  e=row['execution'];assert e['pid']==e['pgid']==518995 and e['currentGuardPid']==518922 and e['exitCode']==1 and e['accepted']is False and e['diagnosticStopped']is False and e['stopReasons']==[]and e['cleanupOwnedGroupEmpty']is True
  assert e['policy']=={'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}and e['signalErrors']==[]and e['signalErrorCount']==0 and e['oomDelta']and all(v==0 for v in e['oomDelta'].values())and e['endedAt']>=e['startedAt']and 0<e['wallSeconds']<60
  assert e['command']==row['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',proposal['actual65FailedCaptureWorkerPin']['path'],str(Path(proposal['actual65PostauditPin']['path']).parent/'capture/output/source-capture.json'),str(Path(proposal['actual65PostauditPin']['path']).parent/'capture/output/source-tree-diagnostic.json')]
  assert e['freshLeaderIdentity']['pid']==e['freshLeaderIdentity']['pgid']==e['freshLeaderIdentity']['sid']==518995 and e['freshLeaderIdentity']['argv']==e['command']
  assert c.guard.process_scope.owned(518995)==[]and not Path('/proc/518922').exists()
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is r['captureChildNatural1BeforeTypesAndCore']is True and r['independentlyObservedOwnedGroupMembers']=={'518995':[]}and r['independentProcReadErrors']==[]and r['currentCheckedConnections']==29 and r['currentMissingConnections']==20 and r['partialAdoptionPerformedByThisCollection']is False
  log=Path(proposal['actual65CaptureChildLogPin']['path']).read_text();assert 'error: Actual29 API131 uses its preserved legacy result-key spelling without retagging'in log and 'requireFutureQualifiedParent29'in log and 'source32.circuit.tsx:135:2'in log and 'Bun v1.3.14'in log
  prior['actual65Source32CapturePreconditionFailedCollectionPin']={k:proposal['actual65FailedCollectionPin'][k]for k in('path','sha256')}
  prior['actual65OnlyCaptureNatural1TypesCoreUnattemptedNoOutputsNoQualification']=True
  prior['actual65SourceSdkGitAndOriginalFloorHeldWithoutRelabelingCaptureFailure']=True
  prior['actual65Parent29ApiPropertyLookupFailureRequiresNewSourceAndFreshCapture']=True
  prior['actualClosedScopeCount']=65
  return prior

