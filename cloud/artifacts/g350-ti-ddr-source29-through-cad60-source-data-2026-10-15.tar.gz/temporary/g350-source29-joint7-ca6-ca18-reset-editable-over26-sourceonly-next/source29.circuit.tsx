// Source declarations only. This module never injects Circuit JSON or assigns fresh IDs.
// Genuine promoted26 import is pinned; actual parent qualification remains deliberately unbound.
import { Children, cloneElement, createElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { buildOwnerMoved26Source, registerOwnerMoved26InnerPorts } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-source26-reset-source3-editable-source-stages-sourceonly-next/source26.circuit"
import data from "./source29-proposal.json"
import type { Source29Proposal } from "./source29-types"
const proposal = data as unknown as Source29Proposal
const plan = proposal.source29Delta
const fields = ["pcbPath", "pcbPaths", "pcbPathRelativeTo"] as const
type Props = Record<string, unknown> & { name?: string; children?: ReactNode }
const canonical = (v: unknown): string => Array.isArray(v) ? `[${v.map(canonical).join(",")}]`
  : v && typeof v === "object" ? `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical((v as Record<string, unknown>)[k])}`).join(",")}}` : JSON.stringify(v) ?? "undefined"
const mm = (v: unknown): number => {
  if (typeof v === "number" && Number.isFinite(v)) return v
  if (typeof v === "string" && /^-?\d+(?:\.\d+)?mm$/.test(v)) return Number(v.slice(0, -2))
  throw Error("A finite genuine millimeter value is required")
}
const routeProps = (p: Props) => Object.fromEntries(fields.filter(k => p[k] !== undefined).map(k => [k, p[k]]))
function requireSealedShape() {
  if (proposal.scope !== "UNEXECUTED_EDITABLE_SOURCE29_SOURCE7_SOURCE6_SOURCE18_AND_RESET_REPAIR_SUCCESSOR_OF_PROMOTED_SOURCE26"
    || proposal.promotedParent26Source.sha256 !== "126266323739fb916b0ba1180b61265f23078a32af5938de61a24318bc57dbba"
    || proposal.parent26Proposal.sha256 !== "c6f7d64f945f64a8fe746685760e5d996bad8850faef4d03a831edcd403c5fff"
    || proposal.sealedSource7Geometry.sha256 !== "566615ece9d7ccb0bc7ba84092fc79cbc8d1191134b5e492f8214a65c4ebcff2"
    || plan.sealedCandidatePins.length !== 2 || plan.sealedCandidatePins[0].sha256 !== proposal.sealedSource7Geometry.sha256
    || plan.sealedCandidatePins[1].sha256 !== proposal.sealedJoint29Geometry.sha256
    || proposal.sealedJoint29Geometry.sha256 !== "2bd2ae7e5e92375dfeb3734165e63cc655e6487a62881d2dfda10c17a6ea427e"
    || plan.movedVia.name !== "V_TI_SIGNAL_source_trace_7_1"
    || canonical(plan.routeChanges.map(r => r.originalSourceTraceId)) !== canonical(["source_trace_7", "source_trace_6", "source_trace_18", "source_trace_10"])
    || canonical(plan.newSixInnerPorts.map(p => `${p.viaName}:${p.layer}`).sort()) !== canonical(["V_TI_SIGNAL_source_trace_18_0:inner2", "V_TI_SIGNAL_source_trace_18_1:inner2", "V_TI_SIGNAL_source_trace_6_0:inner2", "V_TI_SIGNAL_source_trace_6_1:inner2", "V_TI_SIGNAL_source_trace_7_0:inner1", "V_TI_SIGNAL_source_trace_7_1:inner1"])
    || plan.localSuppressions.length !== 6 || proposal.all49OriginalLogicalTraces.length !== 49
    || proposal.expectedCounts.carrierPaths !== 29 || proposal.expectedCounts.physicalTraces !== 292
    || proposal.expectedCounts.innerLiteralPorts !== 46 || proposal.expectedCounts.expectedSourcePorts !== 1661
    || proposal.expectedCounts.expectedReactElements !== 2278 || proposal.expectedCounts.remainingOriginal49Requests !== 20
    || proposal.primaryCoupledSectionView !== "lower_coupled_U" || proposal.secondaryCoupledSectionView !== "early_reflected_meander"
    || proposal.singleCoupledSectionCoversBoth !== false || proposal.bothActualSharedMeandersMustBeChecked !== true)
    throw Error("The exact reviewed Source26/Source7/Source6/Source18/Reset declaration contract is required")
}
function requireFutureQualifiedParent26() {
  if (proposal.actualParent26Qualification === null || Object.values(proposal.actualParent26Stages).some(pin => pin === null))
    throw Error("Source29 is preparation only: all actual Source26 qualification stages must be bound in a new immutable successor before use")
  throw Error("Prepared Source29 runtime is sealed off pending Root's authentic qualified-parent successor")
}
/** One existing RAM144 move and original Source7+Source6+Source18 and Reset repair route declarations,
 * six local suppressions and six genuine Inner1/Inner2 Port children; parent26 held. */
export function buildOwnerMoved29Source() {
  requireSealedShape()
  requireFutureQualifiedParent26()
  const base = buildOwnerMoved26Source()
  const moved = new Set<string>(), changed = new Set<string>(), locals = new Set<string>(), ports = new Set<string>(), logical = new Set<string>()
  let boards = 0
  function fork(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const props: Props = { ...node.props }
    const children = Children.toArray(props.children).map(fork)
    if (props.name === plan.movedVia.name) {
      if (node.type !== "via" || mm(props.pcbX) !== plan.movedVia.before.x || mm(props.pcbY) !== plan.movedVia.before.y
        || props.fromLayer !== "top" || props.toLayer !== "bottom" || mm(props.outerDiameter) !== .4572 || mm(props.holeDiameter) !== .254
        || moved.has(props.name)) throw Error("Exact parent existing full-span RAM owner required")
      props.pcbX = plan.movedVia.after.x; props.pcbY = plan.movedVia.after.y; moved.add(props.name)
    }
    const requested = plan.newSixInnerPorts.find(p => p.viaName === props.name)
    if (requested) {
      if (node.type !== "via" || children.length !== 0 || props.fromLayer !== "top" || props.toLayer !== "bottom"
        || mm(props.outerDiameter) !== .4572 || mm(props.holeDiameter) !== .254
        || mm(props.pcbX) !== requested.viaXY.x || mm(props.pcbY) !== requested.viaXY.y || ports.has(requested.viaName))
        throw Error("An existing exact full-span owner must receive one genuine requested inner Port")
      children.push(createElement("port", { name: requested.layer, layer: requested.layer })); ports.add(requested.viaName)
    }
    const change = plan.routeChanges.find(c => c.logicalName === props.name)
    if (change) {
      if (node.type !== "trace" || props.from !== change.fromSelector || props.to !== change.toSelector || props.path !== undefined
        || canonical(routeProps(props)) !== canonical(change.beforeRouteProps) || changed.has(change.originalSourceTraceId))
        throw Error("Exact parent original numeric route declaration required")
      for (const field of fields) props[field] = undefined
      props.pcbPaths = change.after.newPcbPaths; props.pcbPathRelativeTo = change.after.newPcbPathRelativeTo
      changed.add(change.originalSourceTraceId)
    }
    const local = plan.localSuppressions.find(c => c.traceName === props.name)
    if (local) {
      if (node.type !== "trace" || props.from !== local.numericSelector || props.to !== `.${local.viaName} > port.top`
        || mm(props.thickness) !== .1016 || props.pcbPathRelativeTo !== `.${local.viaName} > port.top`
        || props.pcbPaths !== undefined || canonical(props.pcbPath) !== "[]" || locals.has(local.traceName))
        throw Error("Exact parent Source7/Source6/Source18/Reset Top local declaration required")
      props.pcbPath = undefined; locals.add(local.traceName)
    }
    const original = proposal.all49OriginalLogicalTraces.find(row => row.name === props.name)
    if (original) {
      if (node.type !== "trace" || props.from !== original.from || props.to !== original.to || logical.has(original.originalSourceTraceId))
        throw Error("Every original49 numeric pad-to-pad logical owner must remain exact")
      logical.add(original.originalSourceTraceId)
    }
    if (node.type === "board") {
      boards++
      if (props.layers !== 4 || props.routeRemaining !== false || (props.pcbX ?? 0) !== 0 || (props.pcbY ?? 0) !== 0 || (props.pcbRotation ?? 0) !== 0)
        throw Error("Existing manual unrotated four-layer board required")
    }
    return cloneElement(node as ReactElement<Props>, props, ...children)
  }
  const element = fork(base.element)
  if (boards !== 1 || moved.size !== 1 || changed.size !== 4 || locals.size !== 6 || ports.size !== 6 || logical.size !== 49)
    throw Error("Exact narrow Source29 declaration delta required")
  return { ...base, element, ownerMoved29Proposal: data, ownerMoved29SourceIntegration: {
    scope: "UNQUALIFIED_SOURCE29_EDITABLE_DECLARATIONS", changedViaNames: [...moved], changedOriginalSourceTraceIds: [...changed],
    changedLocalTraceNames: [...locals], newRealPortParents: [...ports], expectedCounts: proposal.expectedCounts,
    newBarrelsAdded: false, circuitJsonInjectionOrIdAssignment: false, source29ActualCoreQualified: false,
    bothDqs1CoupledViewsRequireFreshOriginalApi: true, singleCoupledSectionCoversBoth: false,
    automaticCoreSrjForManualPairBusForkMustNotBeUsed: true, all49Accepted: false, referenceQualified: false, electricalTimingPassed: false, fabricationReady: false,
  } }
}
type Via = { componentName: string; props: Props; pcb_via_id?: string | null; source_manually_placed_via_id?: string | null }
type Port = { componentName: string; props: Props; parent: unknown; matchedComponents: unknown[]; source_port_id?: string | null; pcb_port_id?: string | null; registerMatch(component: unknown): void; getAvailablePcbLayers(): string[] }
type Circuit = { _hasRenderedAtleastOnce?: boolean; schematicDisabled?: boolean; selectOne(selector: string, options?: { type?: string }): unknown }
/** Public matches only, before first render. Core must allocate fresh IDs. */
export function registerOwnerMoved29InnerPorts(circuitUnknown: unknown) {
  requireSealedShape()
  requireFutureQualifiedParent26()
  const circuit = circuitUnknown as Circuit
  if (circuit._hasRenderedAtleastOnce || circuit.schematicDisabled !== true) throw Error("Unrendered actual PCB-only Circuit required")
  const prior = registerOwnerMoved26InnerPorts(circuitUnknown)
  if (prior.registrations.length !== 40) throw Error("Exactly40 held real parent registrations required")
  const registrations = [...prior.registrations]
  for (const requested of plan.newSixInnerPorts) {
    const via = circuit.selectOne(`.${requested.viaName}`) as Via | null
    const port = circuit.selectOne(`.${requested.viaName} > port.${requested.layer}`, { type: "port" }) as Port | null
    if (!via || via.componentName !== "Via" || via.props.name !== requested.viaName || via.props.fromLayer !== "top" || via.props.toLayer !== "bottom"
      || mm(via.props.outerDiameter) !== .4572 || mm(via.props.holeDiameter) !== .254
      || mm(via.props.pcbX) !== requested.viaXY.x || mm(via.props.pcbY) !== requested.viaXY.y
      || !port || port.componentName !== "Port" || port.parent !== via || port.props.name !== requested.layer || port.props.layer !== requested.layer
      || port.source_port_id || port.pcb_port_id || via.pcb_via_id || via.source_manually_placed_via_id
      || port.getAvailablePcbLayers().join(",") !== requested.layer || port.matchedComponents.some(owner => owner !== via))
      throw Error("One genuine unrendered requested inner Port and its exact existing full-span Via required")
    if (!port.matchedComponents.includes(via)) port.registerMatch(via)
    if (port.matchedComponents.length !== 1 || port.matchedComponents[0] !== via) throw Error("Exact public owner registration required")
    registrations.push({ viaName: requested.viaName, layer: requested.layer, xy: requested.viaXY, numericSelector: requested.numericSelector })
  }
  if (registrations.length !== 46 || new Set(registrations.map(row => `${row.viaName}:${row.layer}`)).size !== 46)
    throw Error("Exactly46 unique real inner registrations required")
  return { registrations, extraPhysicalViaFromPortRegistration: false, coreRendered: false, nativeExecuted: false }
}
export default () => buildOwnerMoved29Source().element
