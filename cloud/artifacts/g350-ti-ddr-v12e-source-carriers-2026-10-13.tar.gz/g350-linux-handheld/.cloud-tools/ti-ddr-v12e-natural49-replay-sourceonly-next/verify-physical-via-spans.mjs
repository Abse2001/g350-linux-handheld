/** Future read-only serializer audit: never render, export, route or rewrite data. */
import assert from 'node:assert/strict'
import {readFileSync,writeFileSync} from 'node:fs'
import {createHash} from 'node:crypto'
const [mode,inputPath,inputSha,naturalPath,naturalSha,corePath,coreSha,reportPath,...extra]=process.argv.slice(2)
assert(['natural','core'].includes(mode)&&inputPath&&naturalPath&&reportPath&&!extra.length)
const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex')
assert.equal(hash(inputPath),inputSha);assert.equal(inputSha,'dc67beee6b0e901f914835cd0fe27fad0060066e3213001574a98eefb8c44fa8');assert.equal(hash(naturalPath),naturalSha)
const input=JSON.parse(readFileSync(inputPath)),natural=JSON.parse(readFileSync(naturalPath)),layers=['top','inner1','inner2','bottom']
assert.equal(input.layerCount,4);assert.deepEqual(input.allowedLayers,layers);assert.equal(input.connections.length,49);assert.equal(natural.traces.length,51);assert.deepEqual(natural.traces.slice(0,2),input.traces)
assert.deepEqual({...natural,traces:undefined},{...input,traces:undefined})
const names=new Set(input.connections.map(c=>c.name));const signals=natural.traces.slice(2)
assert.equal(new Set(signals.map(t=>t.source_trace_id)).size,49);assert(signals.every(t=>names.has(t.source_trace_id)&&t.connection_name===t.source_trace_id))
const primitive=p=>({x:p.x,y:p.y,from_layer:p.from_layer,to_layer:p.to_layer,layers:p.layers,via_diameter:p.via_diameter,via_hole_diameter:p.via_hole_diameter})
const byOwner=new Map();let routeViaTransitions=0
for(const trace of signals){
 const vias=trace.route.filter(p=>p.route_type==='via')
 for(const via of vias){assert(Number.isFinite(via.x)&&Number.isFinite(via.y));assert(layers.includes(via.from_layer)&&layers.includes(via.to_layer)&&via.from_layer!==via.to_layer);assert.deepEqual(via.layers,layers);assert.equal(via.via_diameter,.4572);assert.equal(via.via_hole_diameter,.254)}
 byOwner.set(trace.source_trace_id,vias.map(primitive));routeViaTransitions+=vias.length
}
let physicalViaRecords=null,actualCoreTraceCount=null
if(mode==='core'){
 assert(corePath&&coreSha);assert.equal(hash(corePath),coreSha)
 const core=JSON.parse(readFileSync(corePath));assert(Array.isArray(core))
 const traces=core.filter(r=>r.type==='pcb_trace'),vias=core.filter(r=>r.type==='pcb_via');actualCoreTraceCount=traces.length
 const actualSignals=traces.filter(t=>names.has(t.source_trace_id));assert.equal(actualSignals.length,49);assert.equal(new Set(actualSignals.map(t=>t.source_trace_id)).size,49)
 for(const trace of actualSignals){
  const actual=trace.route.filter(p=>p.route_type==='via').map(primitive)
  // The pinned Core serializer intentionally omits route via.layers. Preserve
  // this declared schema behavior; prove the full span in native pcb_via below.
  assert(actual.every(p=>p.layers===undefined),'Pinned Core route-layer omission changed; review the seam')
  assert.deepEqual(actual,byOwner.get(trace.source_trace_id).map(p=>({...p,layers:undefined})),'Core must preserve original logical transition/XY/dimensions while omitting only declared route-layer metadata')
 }
 for(const via of vias){assert.deepEqual(via.layers,layers);assert.equal(via.outer_diameter,.4572);assert.equal(via.hole_diameter,.254)}
 const fixedIds=new Set(['pcb_via_0','pcb_via_1']);assert.equal(vias.filter(v=>fixedIds.has(v.pcb_via_id)).length,2)
 const traceIds=new Map(actualSignals.map(t=>[t.pcb_trace_id,t.source_trace_id]));const actualHoles=new Set(),expectedHoles=new Set()
 for(const [owner,points]of byOwner)for(const point of points)expectedHoles.add(JSON.stringify([owner,point.x,point.y,.4572,.254,layers]))
 for(const via of vias){
  if(fixedIds.has(via.pcb_via_id))continue
  const owner=traceIds.get(via.pcb_trace_id);assert(owner,'Every generated physical via must belong to one of the49 actual Core traces')
  const key=JSON.stringify([owner,via.x,via.y,via.outer_diameter,via.hole_diameter,via.layers]);assert(!actualHoles.has(key),'No duplicate physical through-hole records');actualHoles.add(key)
 }
 assert.deepEqual([...actualHoles].sort(),[...expectedHoles].sort(),'Core physical via XY/dimensions/span/ownership must match original routed through holes')
 physicalViaRecords=vias.length
}else{assert(corePath==='-'&&coreSha==='-')}
writeFileSync(reportPath,JSON.stringify({scope:'READONLY_FULL4_PHYSICAL_VIA_POINT_LAYERS_AND_CORE_RECORD_AUDIT',mode,nativeInputSha256:inputSha,naturalOutputSha256:naturalSha,actualCoreSha256:mode==='core'?coreSha:null,signals:49,routeViaTransitions,physicalViaRecords,actualCoreTraceCount,allOriginalLogicalTransitionsRetained:true,nodeInputPointLayersExplicitFull4:true,coreRouteViaLayersRetained:mode==='core'?false:null,coreRouteLayerMetadataOmissionMatchesPinnedSchema:mode==='core'?true:null,physicalSpanRetainedInCoreNativeViaRecords:mode==='core'?true:null,rawDataMutated:false,coreRendererCalled:false,exporterCalled:false,nativeCheckerCalled:false,routerCalled:false,referenceQualified:false,TIplaneArrangement:false,accepted49:false,fabricationReady:false},null,2)+'\n',{flag:'wx',mode:0o600})
