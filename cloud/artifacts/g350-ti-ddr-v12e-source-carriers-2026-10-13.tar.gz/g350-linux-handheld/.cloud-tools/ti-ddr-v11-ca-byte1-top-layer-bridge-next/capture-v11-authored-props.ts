import {readFileSync, writeFileSync} from "node:fs"
import {createHash} from "node:crypto"
import {resolve} from "node:path"
import {buildV11Source} from "./v11-final-layer-overlay"

if (import.meta.main) {
  const [output, ...extra] = process.argv.slice(2)
  if (!output || extra.length) throw Error("Usage: bun --smol capture-v11-authored-props.ts FRESH_OUTPUT_JSON")
  const expectedPath = resolve(import.meta.dir, "derived-final-authored-props.json")
  const expectedBytes = readFileSync(expectedPath)
  const expected = JSON.parse(expectedBytes.toString())
  const actual = buildV11Source().authoredPolicyProof
  if (JSON.stringify(actual) !== JSON.stringify(expected.authoredPolicyProof))
    throw Error("Actual final V11 React props differ from frozen pure derivation")
  writeFileSync(output, JSON.stringify({scope: "PURE_REAL_FINAL_REACT_PROPS_EVALUATION_ONLY",
    actualFinalReactTreeEvaluated: true, derivedProofSha256: createHash("sha256").update(expectedBytes).digest("hex"),
    authoredPolicyProof: actual, allocation: {top:37,bottom:12},
    coreRenderCalled: false, nativePlacementChecksInvoked: false, routingSolverInstantiated: false,
    accepted49: false, fabricationReady: false}, null, 2) + "\n", {flag:"wx", mode:0o600})
}
