import { expect, test } from "bun:test"
import { createHash } from "node:crypto"
import fs from "node:fs"
import { sameHardware } from "./input-parity"
import type { SimpleRouteJson } from "./source/lib"

const raw = fs.readFileSync(`${import.meta.dir}/input.json`)
const originalRaw = fs.readFileSync(
  `${import.meta.dir}/original-unrestricted-input.json`,
)
const sha = (bytes: Buffer) => createHash("sha256").update(bytes).digest("hex")
const input: SimpleRouteJson = JSON.parse(raw.toString())
const original: SimpleRouteJson = JSON.parse(originalRaw.toString())

test("actual V6dc14/477a pure hardware equality normalizes plural arrays; V1 singular control fails", () => {
  expect(sha(raw)).toBe(
    "dc14a2e24414e66179ae7d8ddc72f8216b1faef2c7d9c8f739cf57de05dd93a1",
  )
  expect(sha(originalRaw)).toBe(
    "477a0ec386e1e3be556d8ea3418c615db718c4f2275c9a9fa118c91a3250b2ca",
  )
  const before = JSON.stringify(input)
  expect(sameHardware(input, original)).toBe(true)
  const legacy = structuredClone(input)
  for (let index = 0; index < legacy.buses!.length; index++) {
    legacy.buses![index]!.allowedLayers = original.buses![index]!.allowedLayers
    legacy.buses![index]!.preferredLayer =
      original.buses![index]!.preferredLayer
  }
  expect(JSON.stringify(legacy) === JSON.stringify(original)).toBe(false)
  expect(JSON.stringify(input) === before).toBe(true)
})

test("physical and timing changes remain rejected, including an invented singular preference", () => {
  const changed = structuredClone(input)
  changed.obstacles[0]!.center.x += 0.01
  expect(sameHardware(changed, original)).toBe(false)
  const limit = structuredClone(input)
  limit.buses![1]!.maxLength = 14.5
  expect(sameHardware(limit, original)).toBe(false)
  const singular = structuredClone(input)
  singular.buses![1]!.preferredLayer = "top"
  expect(sameHardware(singular, original)).toBe(false)
})

test("normalization preserves absent original per-bus fields", () => {
  const bare = structuredClone(original)
  delete bare.buses![0]!.allowedLayers
  delete bare.buses![0]!.preferredLayers
  const derived = structuredClone(bare)
  derived.buses![0]!.allowedLayers = ["bottom"]
  derived.buses![0]!.preferredLayers = ["bottom"]
  const before = JSON.stringify(derived)
  expect(sameHardware(derived, bare)).toBe(true)
  expect(JSON.stringify(derived) === before).toBe(true)
  expect(Object.hasOwn(bare.buses![0]!, "preferredLayers")).toBe(false)
})
