#!/usr/bin/env python3
"""SOURCE ONLY: Root-run Source333 evidence increment and restoration-only smoke.

No SDK/native/CAD/application modules are imported or executed. Build copies the
closed331--336 plus339--341 evidence into a new /tmp checkpoint, then publishes a new regular
deterministic archive. Verify executes only the two existing pinned restorers.
Every actual target and dependency link is checked before the zero-write test.
"""
import argparse, datetime, gzip, hashlib, json, os, re, shutil, stat, subprocess, sys, tarfile, tempfile
from pathlib import Path, PurePosixPath

BOARD = Path('/workspace/g350-linux-handheld')
BASE = Path('/tmp/g350-model328-portable-increment-20261017')
BASE_REL = '.cloud-tools/ddr-four-layer-model328-2026-10-17'
BASE_STEM = 'g350-four-layer-ca18-model328-source313-base-2026-10-17'
BASE_ARCHIVE_SHA = '81ca12343d2bbf9fa73d9266f8a9c6d61c7016372e6cb533d82c9a9a91c4bd16'
BASE_MANIFEST_SHA = 'f2a00832ed9f21b21f40a87e1c9f1659ff9cfde1bb3b875629724f5fb437a5ba'
BASE_PINS = {
    'PROGRESS.json': '9510b250806278770f4263877b5183e500406695e672cdd741fd745eac69b49e',
    'README.md': 'a336f4e8e6d5d908f59e49a8a1d0e986be645abc9b27059a066f620e7780fde2',
    'WORKSPACE_HASH_INDEX.json': 'ecedf4a069b52db68f5de6b752517fb11cf5441dea0779de9f115912e4e27600',
    'WORKSPACE_RESTORE_MANIFEST.json': '115245af64ce5624a79bf0475a3c807678b6f0db5de25da540169a8c82129ac5',
}
SAVED = Path('/tmp/g350-source333-portable-increment-20261017')
SAVED_REL = '.cloud-tools/ddr-four-layer-source333-2026-10-17'
STEM = 'g350-four-layer-both-bytes-ca18-connected49-source333-2026-10-17'
SCOPE = 'PORTABLE_SOURCE333_CA18_WIDE_EDITABLE_CONNECTED49_SCOPED_POUR_MARGIN_CHECKPOINT'
PROFILE = Path('/tmp/g350-source333-portable-increment-profile-sourceonly.json')
PROFILE_SHA = 'c465a4ede80f0a0e882325d8cecc6645bf025a1550685136f2518a83ed258cca'
PAYLOAD_COUNT, PAYLOAD_BYTES, LOCAL_TARGETS, MEMBERS, TOTAL_TARGETS = 65, 87962305, 67, 71, 368
CANDIDATE_SHA = '056cac41c6a654b417f6c088d871b8aab41bdaf1bfd42f570acd9dd42d7a09c8'
PLAN_SHA = '7a10f9b14d9e6656ad7033279fdfdf2ca60047e855fdc9c36466cc9223250103'
CAPTURE_SHA = 'a164a7b04c44096c8d0f9cdcc33fd09d0d4a2e37047f699aebd38aa527cc4237'
RAW_SHA = 'fcb39e6bb43d972f8d511671ffe30b40819d53aeaeb48fd05d8017f30667990d'
CONTROL_SHA = '435bf9061803ed2c903eeba7085e1f2b4bc77f6cdd7fd8137f024df9b49f1f38'
SOLVER_ROOT = '/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib'
RESTORER = BOARD/'scripts/restore-g350-routing-evidence.py'
RESTORER_SHA = '148bad0fc4132ece5f78f18b05e4bc71d79019312343eda954ed7ca91874a643'
HELPER = BOARD/'scripts/restore-g350-four-layer-routing-workspace.py'
HELPER_SHA = '6c5d321a256eadf58697f0f565b5bffa4a55491fce39ed0db7e7675604b6f3cc'
META = ('README.md', 'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json')
FALSE = dict.fromkeys(('all49Accepted', 'fullBoardPassed', 'nativeBoardPassed', 'fullTimingPassed',
    'electricalTimingQualified', 'tiQualified', 'referenceContinuityQualified', 'cadQualified',
    'defaultBoardPromoted', 'fabricationReady', 'currentPourQualified', 'ownNetReentryQualified', 'freshPdnPlaneConnectivityQualified', 'referenceWireGeometryIncluded'), False)

def need(value, message):
    if not value:
        raise ValueError(message)

def regular(path):
    return path.is_file() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)

def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            result.update(block)
        os.posix_fadvise(stream.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return result.hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def md(path):
    return {'bytes': path.stat().st_size, 'sha256': sha(path), 'mode': stat.S_IMODE(path.stat().st_mode)}

def exact(path, row):
    need(regular(path) and md(path) == {key: row[key] for key in ('bytes', 'sha256', 'mode')}, 'Exact bytes/hash/mode '+str(path))

def relative(name):
    path = PurePosixPath(name)
    need(path.parts and not path.is_absolute() and '..' not in path.parts and str(path) == name and '\\' not in name, 'Canonical relative member')
    return Path(*path.parts)

def write(path, data):
    with path.open('x') as stream:
        os.fchmod(stream.fileno(), 0o600)
        json.dump(data, stream, indent=2, allow_nan=False)
        stream.write('\n')

def publish(temporary, final):
    os.link(temporary, final)
    temporary.unlink()

def base_controls(args):
    need(args.model328_archive_sha == BASE_ARCHIVE_SHA and args.model328_manifest_sha == BASE_MANIFEST_SHA, 'Explicit reviewed Model328 archive pins')
    for name, digest in BASE_PINS.items():
        need(regular(BASE/name) and sha(BASE/name) == digest, 'Frozen Model328 metadata '+name)
    index, manifest, progress = [read(BASE/name) for name in ('WORKSPACE_HASH_INDEX.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'PROGRESS.json')]
    need(len(index['files']) == 65 and len(manifest['files']) == 62 and len(manifest['baseDependencyRestoreFiles']) == 239, 'Exact Model328 base66/62/239')
    need(manifest['solverSourceRoot'] == SOLVER_ROOT and progress['primaryCandidate']['candidateSha256'] == CANDIDATE_SHA, 'Real solver root/current model328')
    need({path.name for path in BASE.iterdir()} == {row['path'] for row in index['files']} | {'WORKSPACE_HASH_INDEX.json'}, 'Complete immutable Model328 inventory')
    for row in index['files']:
        exact(BASE/relative(row['path']), row)
    targets = [{'baseSavedDirectory': BASE_REL, **row} for row in manifest['files']] + manifest['baseDependencyRestoreFiles']
    need(len(targets) == len({row['restorePath'] for row in targets}) == 301, 'Unique301 existing base targets')
    for row in targets:
        exact(Path(row['restorePath']), row)
    archive = BOARD/('cloud/artifacts/'+BASE_STEM+'.tar.gz')
    metadata = archive.with_name(BASE_STEM+'.manifest.json')
    for path, digest in ((archive, BASE_ARCHIVE_SHA), (metadata, BASE_MANIFEST_SHA)):
        need(regular(path) and sha(path) == digest, 'Actual published Model328 archive/manifest')
    am = read(metadata)
    need(am['scope'] == 'PORTABLE_MODEL328_FOUR_BODY_CA18_INCREMENT_NOT_FRESH_SOURCE' and am['archive']['sha256'] == BASE_ARCHIVE_SHA and am['archive']['bytes'] == archive.stat().st_size, 'Exact Model328 archive metadata')
    need(len(am['files']) == 66 and am['workspaceRestoreTargetCount'] == 62 and am['baseRestoreTargetCount'] == 239, 'Complete portable Model328 closure')
    need(am['snapshotPins'] == {BASE_REL+'/'+name: digest for name, digest in BASE_PINS.items()}, 'All four Model328 metadata pins')
    for row in am['files']:
        member = relative(row['path'])
        need(member.parent.as_posix() == BASE_REL, 'Only exact base canonical folder')
        exact(BASE/member.name, row)
    for dependency in progress['baseArchiveDependenciesInRestoreOrder']:
        for key, digest in (('path', dependency['sha256']), ('manifest', dependency['manifestSha256'])):
            path = BOARD/relative(dependency[key])
            need(regular(path) and sha(path) == digest, 'All six prior archive dependencies unchanged')
    dependency = {**am['archive'], 'manifest': metadata.relative_to(BOARD).as_posix(), 'manifestSha256': BASE_MANIFEST_SHA,
        'mustBeRestoredFirst': True, 'payloadCopiedByThisCollector': False}
    return manifest, progress, targets, dependency

def pour_evidence(profile, by_name, controls, raw):
    declaration = profile['pourEvidence']
    load = lambda name: read(Path(by_name[name]['restorePath']))
    need(by_name['POUR_AUDITOR_SOURCE.py']['sha256'] == '88063399195e856c97a818771c0502e838a7f825e0bff20bfb5f915625ddd03d'
         and by_name['POUR_COMBINER_SOURCE.py']['sha256'] == '501121232ce3f4e095f19ffc8416f86404f349ccc0af53bdb4e6d4404c7402d9',
         'Reviewed fresh Source333 literal audit and coverage sources retained')
    aggregate = load(declaration['aggregateSavedPath'])
    need(by_name[declaration['aggregateSavedPath']]['sha256'] == declaration['aggregateSha256'],
         'Exact actual closed Source333 coverage aggregate')
    pour_ids = [r['pcb_copper_pour_id'] for r in raw if r['type'] == 'pcb_copper_pour']
    owners = {r['actualSourceTraceId'] for r in controls['logical49Projection']}
    count = 0
    for trace in raw:
        if trace['type'] != 'pcb_trace' or trace.get('source_trace_id') not in owners:
            continue
        for a, b in zip(trace['route'], trace['route'][1:]):
            if a['route_type'] == b['route_type'] == 'wire' and a['layer'] == b['layer'] and (a['x'], a['y']) != (b['x'], b['y']):
                count += 1
    need(len(pour_ids) == len(set(pour_ids)) == 19 and count == 5573,
         'Actual current19-pour and49-owner5573 nonzero wire catalogue; no old5623 inherited')
    expected_bindings = {'raw': RAW_SHA, 'controls': CONTROL_SHA,
        'current236Ownership': profile['authSha256'], 'reviewedSourcePlan331': PLAN_SHA}
    completed = []
    excluded = []
    for i, contribution in enumerate(declaration['contributions']):
        name = contribution['savedPath']
        report = load(name)
        need(by_name[name]['sha256'] == contribution['sha256']
             and aggregate['inputBindings']['report_'+str(i)]['sha256'] == contribution['sha256'],
             'Coverage aggregate binds each whole retained contribution')
        for result in (report, aggregate):
            need(result['inputFilesUnchanged'] is True
                 and result['auditSourceSha256'] == by_name['POUR_AUDITOR_SOURCE.py']['sha256']
                 and all(result['inputBindings'][key]['sha256'] == value for key, value in expected_bindings.items())
                 and result['actualRawPourIds'] == pour_ids and result['actualRawPourCount'] == 19
                 and result['actualViaCount'] == 236 and result['wireSegmentCount'] == count
                 and result['violations'] == [] and result['unsupportedGeometry'] == []
                 and result['requiredForeignViaPourEdgeMm'] == result['requiredForeignWirePourEdgeMm'] == .1016,
                 'Exact current Source333 raw/control/auth/plan/catalogue and unchanged literal margin')
            need(all(result[key] is False for key in ('ownNetReentryQualified', 'freshPdnPlaneConnectivityQualified',
                'referenceWireGeometryIncluded', 'all49Accepted', 'full49Accepted', 'fullBoardPassed',
                'electricalTimingQualified', 'nativeExecuted', 'cadExecuted', 'fabricationReady')),
                'Literal foreign margins do not qualify own routes, PDN/reference continuity, timing, CAD or fabrication')
        need(all(report[key] == [] for key in ('globalIdentityFailures', 'viaIdentityFailures', 'unknownPourIdentities')),
             'Whole literal report retains no unknown or unsupported identity')
        for row in report['pourReports']:
            if row['state'] == 'COMPLETED':
                completed.append(row['pcbCopperPourId'])
            else:
                need(row['state'] == 'BOUNDED_PARTIAL', 'Only explicit bounded partial comparisons excluded')
                excluded.append({'report': 'report_'+str(i), 'pcbCopperPourId': row['pcbCopperPourId'],
                    'state': row['state'], 'viaChecksExcluded': len(row['viaChecks']),
                    'wireChecksExcluded': len(row['wireChecks'])})
    need(len(completed) == len(set(completed)) == 19 and set(completed) == set(pour_ids)
         and aggregate['completed'] is True and aggregate['literalForeignPourMarginClear'] is True
         and aggregate['completedPourCount'] == 19 and aggregate['completedPourIds'] == pour_ids
         and aggregate['wireOwnerCount'] == 49 and aggregate['identityFailures'] == []
         and aggregate['sameExactRawControlsAuthAcrossAllContributions'] is True
         and aggregate['allCompletedComparisonRostersReconstructedFromExactRaw'] is True
         and aggregate['excludedBoundedPartialReports'] == excluded
         and .1016 <= aggregate['minimumForeignEdgeGapMm'] < 100000,
         'Exact reconstructed all19 coverage; every bounded partial row is retained but excluded from qualification')
    for row in declaration['closedScopes']:
        receipt = load(row['receiptSavedPath'])
        execution = receipt['execution']
        need(receipt['scope'] == row['scope'] and receipt['sourcePinsUnchanged'] is True
             and receipt['protectedFilesUnchanged'] is True and execution['exitCode'] == 0
             and execution['cleanupOwnedGroupEmpty'] is True and execution['diagnosticStopped'] is False
             and execution == load(row['executionSavedPath']), 'Whole closed Root pour execution receipts retained')
        need(execution['policy']['wallSeconds'] == 180 and execution['policy']['rssBytes'] == 2*1024**3
             and execution['policy']['sharedBytes'] == 30*1024**3, 'Original180s/2GiB/30GiB external resource policy')
    observed = {'currentSourceScope': 333, 'aggregateSha256': declaration['aggregateSha256'],
        'savedAggregate': declaration['aggregateSavedPath'], 'actualPours': 19, 'actualVias': 236,
        'routedWireSegments': count, 'routedWireOwners': 49, 'scopedForeignPourMarginPassed': True,
        'minimumForeignEdgeGapMm': aggregate['minimumForeignEdgeGapMm'], 'requiredForeignEdgeGapMm': .1016,
        'boundedComparisonsExcluded': excluded, 'wholeContributionReportsRetained': True,
        'referenceWireGeometryIncluded': False, 'ownNetReentryQualified': False,
        'freshPdnPlaneConnectivityQualified': False, 'wholeBoardQualified': False,
        'tiQualified': False, 'cadQualified': False, 'fabricationReady': False}
    need(profile['scopedPourMarginEvidence'] == observed, 'Frozen profile agrees with actual fresh scoped margin evidence')
    return observed


def evidence():
    need(regular(PROFILE) and sha(PROFILE) == PROFILE_SHA, 'Frozen Source333 profile')
    profile = read(PROFILE)
    rows = profile['artifacts']
    need(len(rows) == len({r['savedPath'] for r in rows}) == len({r['restorePath'] for r in rows}) == PAYLOAD_COUNT, 'Unique exact65 payloads')
    need(sum(r['bytes'] for r in rows) == profile['plannedPayloadBytes'] == PAYLOAD_BYTES, 'Measured closed payload bytes')
    need(not ({r['savedPath'] for r in rows} & set(META)), 'No metadata alias collisions')
    for row in rows:
        need(Path(row['restorePath']).is_absolute() and Path(row['restorePath']).is_relative_to('/tmp'), 'Tmp-only actual restore targets')
        need(relative(row['savedPath']).parent == Path('.'), 'Flat explicit aliases')
        exact(Path(row['restorePath']), row)
    by_name = {r['savedPath']: r for r in rows}
    load = lambda name: read(Path(by_name[name]['restorePath']))
    plan, capture, controls, raw = [load(name) for name in ('source-plan.json', 'source-capture.json', 'core-controls.json', 'raw-core.json')]
    need([by_name[name]['sha256'] for name in ('source-plan.json', 'source-capture.json', 'core-controls.json', 'raw-core.json')] == [PLAN_SHA, CAPTURE_SHA, CONTROL_SHA, RAW_SHA], 'Exact331/332/333 bindings')
    need(plan['inputBindings']['candidate']['sha256'] == CANDIDATE_SHA and len(plan['routedOwnerIds']) == 49 and plan['pendingOwnerIds'] == [], 'Actual model328 all49 plan')
    need(len(plan['newVias']) == 105 and len(plan['innerPortRegistrations']) == 82 and all(v['name'].startswith('V_BOTH_BYTES_CA18_WIDE_MATCH49_') for v in plan['newVias']), 'Unique replay namespace/N105/I82')
    need(capture['passed'] is True and capture['fullInverseSourceTreePassed'] is True and capture['parentNormalizationInversePassed'] is True and capture['planSha256'] == PLAN_SHA and capture['candidateSha256'] == CANDIDATE_SHA, 'Actual332 complete capture inverse')
    need(controls['rawCoreSha256'] == RAW_SHA and controls['planSha256'] == PLAN_SHA and controls['actualCaptureSha256'] == CAPTURE_SHA and controls['candidateSha256'] == CANDIDATE_SHA, 'Fresh Core333 actual byte bindings')
    need(controls['freshCoreControlPassed'] is True and controls['freshCoreDerived'] is True and len(controls['checks']) == 35 and all(q['passed'] is True for q in controls['checks']), 'All35 fresh controls')
    owners = {'source_trace_'+str(i) for i in range(49)}
    need({r['originalSourceTraceId'] for r in controls['logical49Projection']} == owners and all(r['passed'] is True for r in controls['logical49Projection']), 'Original49 actual semantic ownership')
    need(len(controls['physicalGraphs']) == 49 and all(r['physicallyConnectedByActualOwnedNumericIdGraph'] is True for r in controls['physicalGraphs']) and controls['pendingOwnerIds'] == [] and controls['all49Connected'] is True, 'All49 actual owned numeric graphs')
    expected = {'physicalVias': 236, 'pcbComponents': 516, 'sourceAndPcbPorts': 1719, 'sourceTraces': 1097, 'physicalTraces': 319, 'reactElements': 2229, 'newSignalVias': 105, 'newPdnVias': 2, 'routedWireRuns': 154, 'auxiliaryLocalTraces': 0}
    need(all(controls['expectedCounts'][k] == v for k, v in expected.items()), 'Exact current actual inventory')
    need(isinstance(raw, list) and sum(r['type'] == 'pcb_copper_pour' for r in raw) == 19, 'Nineteen current pours remain unqualified')
    timing = controls['timingObservations']
    need([r['withinTolerance'] for r in timing['cohorts']] == [True, True, False] and len(timing['pairs']) == 3 and all(r['withinTolerance'] is True for r in timing['pairs']), 'Observed both bytes/pairs pass; CA still fails')
    focused, auth, complement = [load('RUN'+str(n)+'_byte0-result.json') for n in (334, 335, 336)]
    for report in (focused, complement):
        need(report['completed'] is True and report['finished'] is True and report['completedCheckCount'] == 16 and report['exceptionCount'] == 0 and report['allPinnedInputsUnchanged'] is True, 'Actual fresh complete16 no exceptions')
        need(report['inputBindings']['raw']['sha256'] == RAW_SHA and report['inputBindings']['controls']['sha256'] == CONTROL_SHA and report['inputBindings']['reviewedSourcePlan']['sha256'] == PLAN_SHA, 'Same actual313 inputs for native union')
        need(len(report['results']) == 16 and all(r['state'] == 'completed' and r['findingCount'] == len(r['findings']) and r['checkInputMutated'] is False for r in report['results']), 'All unfiltered native result objects retained')
    results = focused['results'] + complement['results']
    names = [r['name'] for r in results]
    need(len(names) == len(set(names)) == 32 and set(names) == set(complement['original32CheckNames']), 'Exact disjoint original32 roster')
    summary = [{'name': r['name'], 'findingCount': len(r['findings'])} for r in results]
    need(summary == profile['native32ObservedCheckSummary'] and sum(r['findingCount'] for r in summary) == 951, 'Actual full32 total951')
    nonzero = {r['name']: len(r['findings']) for r in results if r['findings']}
    need(nonzero == {'checkPcbBusLengthSkew': 1, 'checkSourceTracesHavePcbTraces': 70, 'checkEachPcbPortConnectedToPcbTraces': 718, 'checkSourceTracesMatchPcbTraceThickness': 162}, 'Exact unfiltered951 distribution; no board pass')
    audit = complement['direct49ThicknessWarningAudit']
    need(audit['completed'] is True and audit['totalUnfilteredThicknessFindingCount'] == 162 and audit['direct49FindingCount'] == 0 and audit['direct49Findings'] == [] and audit['unresolvedFindingSourceIdentities'] == [] and audit['zeroDirect49ThicknessWarnings'] is True and audit['findingsFilteredOrWaived'] is False, 'Current direct49 thickness audit0 without filtering')
    need(auth['complete'] is True and auth['executed'] is True and auth['actualViaCount'] == auth['completedViaCount'] == len(auth['viaReports']) == 236 and auth['foreignViaTrackCopperClearancePassed'] is True and auth['exactInputFilesUnchanged'] is True, 'Actual335 all236 authenticated')
    need(all(auth[k] == [] for k in ('violations', 'ambiguousVias', 'identityFailures', 'invalidSegments', 'unresolvedSegmentOwners')), 'No auth/foreign-track ambiguity or violation')
    need(auth['inputBindings']['raw']['sha256'] == RAW_SHA and auth['inputBindings']['controls']['sha256'] == CONTROL_SHA and auth['inputBindings']['plan']['sha256'] == PLAN_SHA, 'Auth335 binds same actual Source333')
    for n in range(331, 337):
        receipt = load('RUN'+str(n)+'_COLLECTED.json')
        execution = receipt['execution']
        need(receipt['scope'] == n and receipt['sourcePinsUnchanged'] is True and receipt['protectedFilesUnchanged'] is True and execution['exitCode'] == 0 and execution['cleanupOwnedGroupEmpty'] is True and execution['diagnosticStopped'] is False, 'Actual closed'+str(n)+' passed/no owned process')
        need(load('RUN'+str(n)+'_owned_execution.json') == execution, 'Literal execution closure'+str(n))
        need(execution['policy']['wallSeconds'] == 180 and execution['policy']['rssBytes'] == 2*1024**3 and execution['policy']['sharedBytes'] == 30*1024**3, 'Original bounded resource policy')
    need(profile['authSha256'] == by_name['RUN335_byte0-result.json']['sha256']
         and auth['wireSegmentCount'] == 5747, 'Exact current all-wire auth catalogue distinct from5573 scoped DDR segments')
    pour_evidence(profile, by_name, controls, raw)
    root_summary = load('ROOT_SOURCE333_VALIDATION.json')
    need(by_name['ROOT_SOURCE333_VALIDATION.json']['sha256'] == '417ac24e4f468ec94286ba36403432d9a32ce422f3350d57a17d0da8b7270f0c'
         and root_summary['editableCore'] == 333 and root_summary['physicalModel'] == 328
         and root_summary['freshCoreControls'] == {'total': 35, 'passed': 35}
         and root_summary['actualNumericDdrGraphs']['connected'] == 49
         and root_summary['native32']['totalReturnedFindings'] == 951
         and root_summary['viaTrack']['authenticatedVias'] == 236
         and root_summary['pourMargin']['completedPours'] == 19
         and root_summary['ddrWireSegments'] == 5573
         and all(root_summary[k] is False for k in ('regeneratedPlaneContinuityQualified', 'referenceQualified',
             'tiQualified', 'electricalTimingQualified', 'all49Accepted', 'fullBoardPassed', 'fabricationReady')),
         'Exact whole Root Source333 summary retained with broad qualification boundaries false')
    return profile, rows, controls, summary

def build(args):
    need(not SAVED.exists(), 'Fresh Source333 staging folder')
    base, progress, base_targets, dependency = base_controls(args)
    profile, payloads, controls, summary = evidence()
    need(shutil.disk_usage('/tmp').free > profile['plannedPayloadBytes']+1024**3, 'Measured tmp payload plus1GiB reserve')
    need(int(Path('/sys/fs/cgroup/memory.current').read_text())+128*1024**2+1024**3 < 30*1024**3, 'Shared30GiB plus1GiB reserve')
    archive = BOARD/('cloud/artifacts/'+STEM+'.tar.gz')
    manifest_path = archive.with_name(STEM+'.manifest.json')
    need(not archive.exists() and not manifest_path.exists(), 'New immutable archive pair')
    SAVED.mkdir(mode=0o700)
    rows = []
    extras = [(PROFILE, 'SOURCE333_CHECKPOINT_PROFILE.json'), (Path(__file__).resolve(), 'SOURCE333_PORTABLE_INCREMENT_SOURCE.py')]
    source_rows = payloads + [{'restorePath': str(p), 'savedPath': name, **md(p)} for p, name in extras]
    need(len(source_rows) == len({r['savedPath'] for r in source_rows}) == LOCAL_TARGETS and not ({r['restorePath'] for r in source_rows} & {r['restorePath'] for r in base_targets}), 'Unique67 local plus301 base targets')
    for row in source_rows:
        source, destination = Path(row['restorePath']), SAVED/row['savedPath']
        exact(source, row)
        with source.open('rb') as src, destination.open('xb') as dst:
            shutil.copyfileobj(src, dst, 1048576)
            os.fchmod(dst.fileno(), row['mode'])
        exact(destination, row)
        rows.append(row)
    dependencies = progress['baseArchiveDependenciesInRestoreOrder']+[dependency]
    checkpoint = {'scope': SCOPE, 'candidateSha256': CANDIDATE_SHA, 'candidateBaseSavedDirectory': BASE_REL,
        'savedCandidate': progress['primaryCandidate']['savedCandidate'], 'coreScope': 333, 'planSha256': PLAN_SHA,
        'captureSha256': CAPTURE_SHA, 'rawCoreSha256': RAW_SHA, 'controlsSha256': CONTROL_SHA,
        'savedRawCore': 'raw-core.json', 'savedControls': 'core-controls.json', 'savedPlan': 'source-plan.json',
        'savedCapture': 'source-capture.json', 'routedOwners': 49, 'pendingOwnerIds': [], 'freshCoreControlsPassed': 35,
        'all49OwnedNumericGraphsPassed': True, 'byte0PlanarSkewPassed': True, 'byte1PlanarSkewPassed': True,
        'caMinimumPassingCount': 18, 'caUnderMinimumCount': 8, 'caPlanarSkewPassed': False,
        'freshOriginal32Completed': True, 'nativeExceptionCount': 0, 'nativeTotalFindings': 951,
        'authenticatedViaCount': 236, 'authenticatedForeignViaTrackPassed': True,
        'actualCurrentPourCount': 19, 'scopedForeignPourMarginEvidence': profile['scopedPourMarginEvidence'], 'previousSourceOrCadQualificationInherited': False, **FALSE}
    common = {'scope': SCOPE, 'frozenCheckpoint': True, 'updatedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'latestClosedScopeIncluded': profile['latestClosedScopeIncluded'], 'primaryCandidate': checkpoint, 'latestSourceVerifiedCheckpoint': checkpoint,
        'latestEditableSourceSavedDirectory': SAVED_REL, 'latestEditableSourceCoreScope': 333,
        'baseArchiveDependency': dependency, 'baseArchiveDependenciesInRestoreOrder': dependencies,
        'laterWorkRequiresNewSavedDirectory': True, 'source272CadQualificationInherited': False,
        'source289NativeQualificationInherited': False, 'source313QualificationInherited': False, 'sdkExecutedByCollector': False, **FALSE}
    restore = {**common, 'solverSourceRoot': SOLVER_ROOT, 'files': rows, 'baseDependencyRestoreFiles': base_targets,
        'immutableWorkspaceAssets': [], 'immutableAssetsRestoredByBaseArchives': base['immutableAssetsRestoredByBaseArchives']}
    write(SAVED/'WORKSPACE_RESTORE_MANIFEST.json', restore)
    with (SAVED/'README.md').open('x') as stream:
        os.fchmod(stream.fileno(), 0o600)
        stream.write('Source333:49 editable connected signal routes;35 fresh Core controls PASS.\n'
            'Resume raw-core.json, core-controls.json, source-plan.json and source-capture.json here.\n'
            'Candidate328 is in the required Model328 base;20/23/25/36 changed from318, including2 new25 fullspan vias.\n'
            'Both byte cohorts and all3 pairs pass planar skew; CA18/26 meet20.95mm,8 remain short.\n'
            'FullCA skew17.6628187566mm FAILS. WholeTI/electrical/default/fabrication remain false.\n'
            'Fresh334+336 complete all32 native checks:951 unfiltered findings,0 exceptions.\n'
            'Findings:1 CA skew,70 missing source traces,718 unconnected ports,162 thickness warnings.\n'
            'Current49 direct logical DDR owners have0 thickness warnings; broader findings are retained.\n'
            'Fresh335 authenticates236 vias,0 ambiguity/identity/foreign-track findings over5747 physical wire segments.\n'
            'Fresh339 plus340 retry and341 aggregate pass scoped .1016mm foreign margins for19 pours/236vias/5573 DDR segments.\n'
            'Whole339 bounded108 comparisons are retained and excluded; fresh340 completed108 supplies qualification.\n'
            'Reference wires,own-net reentry and freshPDN/reference continuity remain unqualified.\n'
            'No Source313 pour or Source272 CAD qualification is inherited.\n'
            'Restore209→228→248→257→272-v2→289→Model299→Source313→Model318→Model328,then Source333.\n'
            'Only stdlib copying/archiving and restoration checks execute here; no SDK/native/CAD/geometry.\n')
    write(SAVED/'PROGRESS.json', {**common, 'currentTimingObservations': controls['timingObservations'],
        'native32ObservedCheckSummary': summary, 'fullNativeFindingsRetained': True,
        'evidence': rows, 'archiveCreatedByOwnStdlib': True})
    index = [{'path': p.name, **md(p)} for p in sorted(SAVED.iterdir())]
    write(SAVED/'WORKSPACE_HASH_INDEX.json', {'scope': SCOPE, 'files': index, 'selfExcluded': True, 'frozenCheckpoint': True})
    members = [{'path': SAVED_REL+'/'+p.name, '_source': p, **md(p)} for p in sorted(SAVED.iterdir())]
    need(len(members) == MEMBERS and len(index) == MEMBERS-1 and len(rows) == LOCAL_TARGETS, 'Exact71members/index70/67targets')
    temporary = durable = metadata_temporary = None
    try:
        fd, name = tempfile.mkstemp(prefix='g350-source333-', suffix='.tar.gz', dir='/tmp')
        temporary = Path(name)
        with os.fdopen(fd, 'wb') as output:
            os.fchmod(output.fileno(), 0o600)
            with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=6) as gz:
                with tarfile.open(mode='w|', fileobj=gz, format=tarfile.PAX_FORMAT) as tf:
                    for row in members:
                        exact(row['_source'], row)
                        info = tarfile.TarInfo(row['path'])
                        info.size, info.mode, info.mtime = row['bytes'], row['mode'], 0
                        info.uid = info.gid = 0
                        info.uname = info.gname = ''
                        with row['_source'].open('rb') as source:
                            tf.addfile(info, source)
                        exact(row['_source'], row)
            output.flush()
            os.fsync(output.fileno())
        base_controls(args)
        evidence()
        for row in source_rows:
            exact(Path(row['restorePath']), row)
        actual = {'path': archive.relative_to(BOARD).as_posix(), **md(temporary)}
        am = {'schemaVersion': 1, 'scope': SCOPE, 'regularFilesOnly': True, 'historicalDataOnly': True, 'archive': actual,
            'files': [{k: v for k, v in row.items() if k != '_source'} for row in members],
            'inputDirectories': [SAVED_REL], 'extraWorkspaceAssetMembers': [], 'baseArchiveDependenciesInRestoreOrder': dependencies,
            'baseArchivesIncluded': False, 'workspaceRestoreTargetCount': LOCAL_TARGETS, 'baseRestoreTargetCount': 301,
            'snapshotPins': {SAVED_REL+'/'+name: sha(SAVED/name) for name in META},
            'primaryCandidate': {'baseSavedDirectory': BASE_REL, 'path': BASE_REL+'/'+checkpoint['savedCandidate'], 'sha256': CANDIDATE_SHA},
            'latestSourceVerifiedCheckpoint': checkpoint, 'latestEditableSourceCoreScope': 333, 'solverSourceRoot': SOLVER_ROOT, **FALSE}
        fd, name = tempfile.mkstemp(prefix='.'+manifest_path.name+'.', suffix='.partial', dir=manifest_path.parent)
        metadata_temporary = Path(name)
        with os.fdopen(fd, 'w') as stream:
            os.fchmod(stream.fileno(), 0o600)
            json.dump(am, stream, indent=2, allow_nan=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        need(shutil.disk_usage(archive.parent).free > temporary.stat().st_size+256*1024**2, 'Measured compressed archive plus256MiB durable reserve')
        fd, name = tempfile.mkstemp(prefix='.'+archive.name+'.', suffix='.partial', dir=archive.parent)
        durable = Path(name)
        with temporary.open('rb') as source, os.fdopen(fd, 'wb') as output:
            shutil.copyfileobj(source, output, 1048576)
            os.fchmod(output.fileno(), 0o600)
            output.flush()
            os.fsync(output.fileno())
        exact(durable, actual)
        need(shutil.disk_usage(archive.parent).free > 256*1024**2, '256MiB durable reserve retained after copy')
        publish(durable, archive)
        durable = None
        publish(metadata_temporary, manifest_path)
        metadata_temporary = None
        print(json.dumps({'archive': str(archive), 'archiveSha256': sha(archive), 'manifest': str(manifest_path),
            'manifestSha256': sha(manifest_path), 'members': MEMBERS, 'tmpTargets': LOCAL_TARGETS, 'baseTargets': 301,
            'latestEditableSource': 333, 'nativeFindings': 951, 'currentPoursQualified': False, 'sdkExecuted': False}))
    finally:
        for path in (temporary, durable, metadata_temporary):
            if path is not None and path.exists():
                path.unlink()

def verify(args):
    _, _, base_targets, _ = base_controls(args)
    evidence()
    archive = BOARD/('cloud/artifacts/'+STEM+'.tar.gz')
    metadata = archive.with_name(STEM+'.manifest.json')
    for path, digest in ((archive, args.archive_sha), (metadata, args.manifest_sha)):
        need(digest and re.fullmatch('[0-9a-f]{64}', digest) and regular(path) and sha(path) == digest, 'Explicit actual Source333 archive hashes')
    am = read(metadata)
    need(am['scope'] == SCOPE and am['archive']['sha256'] == args.archive_sha and len(am['files']) == MEMBERS, 'Exact71-member Source333 increment')
    for path, digest in ((RESTORER, RESTORER_SHA), (HELPER, HELPER_SHA)):
        need(regular(path) and sha(path) == digest, 'Pinned existing restoration helper')
    prior_umask = os.umask(0o077)
    owned = Path(tempfile.mkdtemp(prefix='g350-source333-smoke-', dir='/tmp'))
    destination = owned/'extracted'
    commands = []
    def run(argv):
        result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=120, check=False)
        commands.append({'argv': argv, 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
        need(result.returncode == 0, 'Restoration-only verifier returned success')
        return result.stdout
    try:
        command = [sys.executable, str(RESTORER), str(metadata), '--destination', str(destination)]
        need(run(command+['--verify-archive']).strip() == f'Verified {MEMBERS} evidence members; restored 0', 'Exact archive verification')
        expected_members = {r['path']: r for r in am['files']}
        need(len(expected_members) == MEMBERS, 'Unique regular archive member roster')
        seen = set()
        with tarfile.open(archive, 'r|gz') as tf:
            for member in tf:
                name = str(relative(member.name))
                need(member.isfile() and name in expected_members and name not in seen, 'Only exact regular members')
                row = expected_members[name]
                need(member.size == row['bytes'] and stat.S_IMODE(member.mode) == row['mode']
                     and member.uid == member.gid == 0 and member.uname == member.gname == '' and member.mtime == 0,
                     'Normalized exact tar headers')
                stream = tf.extractfile(member); need(stream is not None, 'Readable regular archive payload')
                h = hashlib.sha256(); size = 0
                for block in iter(lambda: stream.read(1048576), b''):
                    h.update(block); size += len(block)
                need(size == row['bytes'] and h.hexdigest() == row['sha256'], 'Full archive member hash')
                seen.add(name)
        need(seen == set(expected_members), 'No omitted archive member')
        need(run(command).strip() == f'Verified {MEMBERS} evidence members; restored {MEMBERS}', 'Isolated71-file extraction')
        need({p.relative_to(destination).as_posix() for p in destination.rglob('*') if p.is_file()} == {r['path'] for r in am['files']}, 'Only exact regular extracted members')
        for row in am['files']:
            exact(destination/relative(row['path']), row)
        for name, digest in am['snapshotPins'].items():
            need(sha(destination/relative(name)) == digest, 'All extracted metadata pins')
        saved = destination/SAVED_REL
        manifest = read(saved/'WORKSPACE_RESTORE_MANIFEST.json')
        need(len(manifest['files']) == LOCAL_TARGETS and manifest['baseDependencyRestoreFiles'] == base_targets and manifest['solverSourceRoot'] == SOLVER_ROOT and manifest['latestEditableSourceCoreScope'] == 333, 'Exact compatible67+301 restore schema')
        targets = manifest['files']+base_targets
        need(len(targets) == len({r['restorePath'] for r in targets}) == TOTAL_TARGETS, 'All current distinct actual targets exist before no-op restore')
        for row in targets:
            exact(Path(row['restorePath']), row)
        link = Path(SOLVER_ROOT).parent/'node_modules'
        need(link.is_symlink() and link.resolve() == (BOARD.parent/'bus-lanes-solver/node_modules').resolve(), 'Exact preexisting dependency symlink')
        link_id = (link.lstat().st_dev, link.lstat().st_ino, link.lstat().st_mtime_ns, link.lstat().st_ctime_ns, os.readlink(link))
        result = json.loads(run([sys.executable, str(HELPER), '--saved-directory', str(saved), '--restore']))
        need(result['savedFilesVerified'] == LOCAL_TARGETS and result['restoredFiles'] == 0 and result['mode'] == 'restore' and result['routingExecuted'] is False and result['all49Accepted'] is False and result['fabricationReady'] is False, 'Actual unchanged restore branch writes zero files')
        for row in targets:
            exact(Path(row['restorePath']), row)
        need((link.lstat().st_dev, link.lstat().st_ino, link.lstat().st_mtime_ns, link.lstat().st_ctime_ns, os.readlink(link)) == link_id, 'Dependency link unchanged')
        base_controls(args)
        evidence()
        need(sha(archive) == args.archive_sha and sha(metadata) == args.manifest_sha, 'Archive inputs unchanged')
        shutil.rmtree(destination)
        write(owned/'REPORT.json', {'scope': 'SOURCE333_ISOLATED71_EXTRACTION_AND368_TARGET_NOOP_RESTORE', 'passed': True,
            'commands': commands, 'archiveSha256': args.archive_sha, 'manifestSha256': args.manifest_sha,
            'normalizedHeadersAndAllMemberHashesVerified': True, 'isolatedPayloadRemoved': True, 'allActualTargetsUnchanged': True, 'actualTargetCount': TOTAL_TARGETS, 'existingHelperRestoreCodePathExecuted': True,
            'restoredWorkspaceFiles': 0, 'latestEditableSource': 333, 'sdkExecuted': False, **FALSE})
        print(json.dumps({'report': str(owned/'REPORT.json'), 'sha256': sha(owned/'REPORT.json'), 'passed': True, 'sdkExecuted': False}))
    except BaseException as error:
        write(owned/'FAILURE.json', {'passed': False, 'error': str(error), 'commands': commands, 'isolatedPayloadPreserved': destination.exists(), **FALSE})
        raise
    finally:
        os.umask(prior_umask)

def main():
    need(PROFILE_SHA is not None and all(isinstance(x, int) and x > 0 for x in (PAYLOAD_COUNT, PAYLOAD_BYTES, LOCAL_TARGETS, MEMBERS, TOTAL_TARGETS)), 'Frozen exact Source333 profile and inventory required')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['build', 'verify'])
    parser.add_argument('--model328-archive-sha', required=True)
    parser.add_argument('--model328-manifest-sha', required=True)
    parser.add_argument('--archive-sha')
    parser.add_argument('--manifest-sha')
    args = parser.parse_args()
    (build if args.mode == 'build' else verify)(args)

if __name__ == '__main__':
    main()
