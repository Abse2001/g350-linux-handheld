/** One quarantined Root-owned public generation; original release qualification failed. */
import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { createHash } from "node:crypto"
const HERE=import.meta.dirname
const hash=(bytes:Buffer|string)=>createHash("sha256").update(bytes).digest("hex")
const read=(p:string,expected:string)=>{
  const bytes=fs.readFileSync(p);assert.equal(hash(bytes),expected,`Changed sealed input ${p}`)
  return JSON.parse(bytes.toString())
}
const manifestBytes=fs.readFileSync(path.join(HERE,"SOURCE-manifest.json"))
const manifest=JSON.parse(manifestBytes.toString())
const authority=JSON.parse(fs.readFileSync(process.argv[2]!,"utf8"))
assert.equal(authority.authorizedByRoot,true)
assert.equal(authority.scope,"ROOT_ONE_FRESH_RESET227_QUARANTINED_PAIRED_FALLBACK_PUBLIC_DIAGNOSTIC")
assert.equal(authority.sourceManifestSha256,hash(manifestBytes))
assert.equal(authority.rootOwns90s2GiBFiniteGuardFullSdkAnd120SourceBeforeAfter,true)
assert.equal(authority.actualFull644AndAll11RequiredCollectionsClosedAndAccepted,false)
assert.equal(authority.actualFull644CollectionClosedAndAccepted,true)
assert.equal(authority.actualOriginalElevenScopeThreadCompleteClosedWithFailure,true)
assert.equal(authority.originalAll11AcceptanceClaimed,false)
assert.equal(authority.diagnosticOnlyNotReleaseQualification,true)
assert.equal(authority.peerSourceOnlyGoReviewedByRoot,true)
assert.equal(authority.outputDirectory,path.join(HERE,"run-generation","output"))
for(const row of [...manifest.files,...manifest.externalFiles,...manifest.solverSourceFiles,...manifest.originalSolverSourceFiles]){
  assert.equal(hash(fs.readFileSync(row.path)),row.sha256,`Changed source ${row.path}`)
}
const numeric=read(manifest.numericInputPin.path,manifest.numericInputPin.sha256)
const original=read(manifest.cleanCarrierViewPin.path,manifest.cleanCarrierViewPin.sha256)
const input=read(manifest.initialLayerOnlyInputPin.path,manifest.initialLayerOnlyInputPin.sha256)
assert.equal(input.connections.length,49);assert.equal(input.traces.length,263)
assert.deepEqual(Object.keys(input),Object.keys(original))
for(const key of Object.keys(original))if(key!=="connections")assert.deepEqual(input[key],original[key])
for(const key of Object.keys(numeric))if(key!=="connections")assert.deepEqual(input[key],numeric[key])
const byte0=new Set<string>(numeric.buses.find((b:any)=>b.busId==="DDR_BYTE0").connectionNames)
assert.equal(byte0.size,11)
const inverse=structuredClone(input)
let layerChanges=0
for(const [index,c] of input.connections.entries()){
  const before=original.connections[index];assert.equal(c.name,before.name)
  for(const key of Object.keys(c))if(key!=="pointsToConnect")assert.deepEqual(c[key],before[key])
  assert.equal(c.pointsToConnect.length,2)
  for(const [side,p] of c.pointsToConnect.entries()){
    const prior=before.pointsToConnect[side]
    assert.equal(p.layers,undefined)
    assert.deepEqual(Object.keys(p),Object.keys(prior))
    for(const key of Object.keys(prior))if(key!=="layer")assert.deepEqual(p[key],prior[key])
    if(byte0.has(c.name)){assert.equal(prior.layer,"bottom");assert.equal(p.layer,"inner1");layerChanges++}
    else assert.equal(p.layer,prior.layer)
    inverse.connections[index].pointsToConnect[side].layer=prior.layer
  }
  assert.equal(c.pointsToConnect[0].layer,c.pointsToConnect[1].layer)
}
assert.equal(layerChanges,22);assert.deepEqual(inverse,original)
const terminalLayers=new Map<string,string[]>()
const endpointProof:any[]=[]
const physical=["top","inner1","inner2","bottom"]
for(const c of input.connections){
  const logical=numeric.connections.find((v:any)=>v.name===c.name)
  assert.ok(logical);assert.equal(c.source_trace_id,logical.source_trace_id)
  const branches=numeric.traces.filter((t:any)=>t.source_trace_id===c.source_trace_id)
  assert.equal(branches.length,2)
  const barrels=branches.map((t:any,side:number)=>{
    const via=t.route.filter((p:any)=>p.route_type==="via");assert.equal(via.length,1)
    const v=via[0];assert.equal(v.via_diameter,.4572);assert.equal(v.via_hole_diameter,.254)
    assert.deepEqual(new Set(v.layers),new Set(physical))
    assert.ok(Math.hypot(v.x-c.pointsToConnect[side].x,v.y-c.pointsToConnect[side].y)<1e-8)
    assert.equal(t.route[0].layer,"top")
    assert.ok(Math.hypot(t.route[0].x-logical.pointsToConnect[side].x,t.route[0].y-logical.pointsToConnect[side].y)<1e-8)
    if(c.name==="source_trace_10"){
      const owner=manifest.proposedResetViaOwners[side]
      assert.equal(owner.sourceTraceId,c.name)
      assert.equal(c.pointsToConnect[side].proposed_owned_via_id,owner.proposedViaId)
      assert.deepEqual(Object.keys(c.pointsToConnect[side]).sort(),["layer","proposed_owned_via_id","x","y"])
    }
    return {sourceOnlyFixedBranchId:t.pcb_trace_id,sourceOnlyHypothesis:true,x:v.x,y:v.y,padDiameter:v.via_diameter,holeDiameter:v.via_hole_diameter,layers:[...v.layers]}
  })
  const allowed=physical.filter(layer=>barrels.every((v:any)=>v.layers.includes(layer))&&input.allowedLayers.includes(layer)&&input.buses.every((b:any)=>!b.connectionNames.includes(c.name)||!b.allowedLayers||b.allowedLayers.includes(layer)))
  assert.deepEqual(allowed,physical)
  terminalLayers.set(c.name,allowed)
  endpointProof.push({name:c.name,actualNumericContacts:logical.pointsToConnect,authenticOwnedFullSpanBarrels:barrels,availableLayers:allowed})
}
assert.equal(terminalLayers.size,49)
assert.equal(endpointProof.reduce((v:number,r:any)=>v+r.authenticOwnedFullSpanBarrels.length,0),98)
assert.deepEqual(input.buses,numeric.buses);assert.deepEqual(input.differentialPairs,numeric.differentialPairs)
const output=authority.outputDirectory
fs.mkdirSync(output,{recursive:false})
const save=(name:string,obj:unknown)=>fs.writeFileSync(path.join(output,name),JSON.stringify(obj,null,2)+"\n",{flag:"wx"})
save("ACTUAL_CONSTRUCTOR_INPUT.json",input)
save("AUTHENTIC_INPUT_AND_TERMINAL_MAP.json",{initialLayerChanges:22,inversePreservesOriginalCleanView:true,endpointProof,terminalLayers:[...terminalLayers],fixed263RowsHeld:true,numeric49ContactsHeld:true,physicalViaCount:227})
const {BusLanesSolver}=await import("/workspace/bus-lanes-solver/.cache/paired-layer-fallback-sourceonly-next/lib/bus-lanes-solver.ts")
const options={smoothTuning:true,denseSearch:true,maxSearchIterations:40000}
const solver=new BusLanesSolver(input,options,terminalLayers)
assert.equal(solver.MAX_ITERATIONS,40000)
const started=Date.now();let checkpoints=0;let lastCheckpointIteration=-1;let checkpointBytes=0
const CHECKPOINT_LIMIT=41
const CHECKPOINT_TOTAL_BYTE_LIMIT=40000000
const CHECKPOINT_SINGLE_BYTE_LIMIT=960000
const capture=(value:any,byteLimit:number)=>{
  const encoded=JSON.stringify(value)
  if(encoded===undefined)return {value:undefined,complete:true,bytes:0}
  const bytes=Buffer.byteLength(encoded)
  return bytes<=byteLimit?{value,complete:true,bytes}:{value:{omittedForDiagnosticByteCap:true,encodedJsonBytes:bytes,encodedJsonSha256:hash(encoded),arrayLength:Array.isArray(value)?value.length:undefined},complete:false,bytes}
}
const inputMaterialHash=(value:any)=>hash(JSON.stringify(Object.fromEntries(Object.entries(value).filter(([key])=>key!=="connections"))))
const originalMaterialHash=inputMaterialHash(input)
const rawState=(reason:string,checkpointOnly=false)=>{
  const best=capture((solver as any).bestPartial,checkpointOnly?64000:1048576)
  const paired=capture((solver as any).pairedTraces,checkpointOnly?64000:1048576)
  const publicTraces=checkpointOnly?capture(solver.traces,720000):{value:solver.traces,complete:true,bytes:0}
  return {reason,elapsedMs:Date.now()-started,iterations:solver.iterations,MAX_ITERATIONS:solver.MAX_ITERATIONS,phase:solver.phase,solved:solver.solved,failed:solver.failed,error:solver.error,failureCode:solver.failureCode,stats:solver.stats,traces:publicTraces.value,completePublicGeometry:publicTraces.complete,actualPublicTraceCount:solver.traces.length,originalPrivateDiagnosticOnly:true,originalPrivateBestPartial:best.value,originalPrivateBestPartialComplete:best.complete,originalPrivatePairedTraces:paired.value,originalPrivatePairedTracesComplete:paired.complete,...(checkpointOnly?{actualCurrentConnections:solver.input.connections,inputOtherFieldsSha256:inputMaterialHash(solver.input),inputOtherFieldsMatchOriginal:inputMaterialHash(solver.input)===originalMaterialHash,reconstructCurrentInputFromImmutablePinAndActualConnections:true}:{actualCurrentInput:solver.input}),constructorCalls:1,publicStepCalls:solver.iterations,outerRootGuardOwnsResourceStopAndCleanup:true,noSignalOrSdkCancellationHooksInstalled:true,sourceCoreNativeCadCalls:0,sourceOnlyHypothesis:true,referenceQualified:false,electricalTimingPassed:false,all49Accepted:false,fabricationReady:false}
}
const checkpoint=(reason:string)=>{
  if(checkpoints>=CHECKPOINT_LIMIT||lastCheckpointIteration===solver.iterations)return
  const state:any=rawState(reason,true)
  let encoded=JSON.stringify(state,null,2)+"\n"
  if(Buffer.byteLength(encoded)>CHECKPOINT_SINGLE_BYTE_LIMIT){
    state.traces=capture(solver.traces,0).value;state.completePublicGeometry=false
    state.stats=capture(solver.stats,0).value
    encoded=JSON.stringify(state,null,2)+"\n"
  }
  assert.ok(Buffer.byteLength(encoded)<=CHECKPOINT_SINGLE_BYTE_LIMIT,"Bounded checkpoint exceeded byte contract")
  assert.ok(checkpointBytes+Buffer.byteLength(encoded)<=CHECKPOINT_TOTAL_BYTE_LIMIT)
  fs.writeFileSync(path.join(output,`CHECKPOINT-${String(solver.iterations).padStart(5,"0")}.json`),encoded,{flag:"wx"})
  checkpointBytes+=Buffer.byteLength(encoded)
  checkpoints++;lastCheckpointIteration=solver.iterations
}
// No signal listeners or SDK cancellation/failure hooks: Root owns resource stops.
let thrown:string|null=null
try{
  checkpoint("Before first original step")
  while(!solver.solved&&!solver.failed){
    solver.step()
    if(solver.iterations%1000===0)checkpoint("After original step returned")
  }
}catch(error){thrown=String(error)}
// Full failing/partial geometry and phase precede every result/postcondition assertion.
save("RAW_FINAL_STATE.json",{...rawState("Natural SDK completion or thrown original step"),thrown})
if(solver.solved&&!thrown)save("SOLVED_OUTPUT.json",solver.getOutput())
for(const pin of [manifest.numericInputPin,manifest.cleanCarrierViewPin,manifest.initialLayerOnlyInputPin])read(pin.path,pin.sha256)
assert.equal(inputMaterialHash(solver.input),originalMaterialHash)
assert.equal(solver.input.connections.length,49)
for(const [index,c] of solver.input.connections.entries()){
  const prior=input.connections[index]
  assert.deepEqual(Object.fromEntries(Object.entries(c).filter(([key])=>key!=="pointsToConnect")),Object.fromEntries(Object.entries(prior).filter(([key])=>key!=="pointsToConnect")))
  assert.equal(c.pointsToConnect.length,2)
  for(const [side,point] of c.pointsToConnect.entries()){
    assert.deepEqual(Object.fromEntries(Object.entries(point).filter(([key])=>key!=="layer")),Object.fromEntries(Object.entries(prior.pointsToConnect[side]).filter(([key])=>key!=="layer")))
    assert.ok(terminalLayers.get(c.name)!.includes(point.layer))
  }
  assert.equal(c.pointsToConnect[0].layer,c.pointsToConnect[1].layer)
}
const names=solver.traces.map(t=>t.connection_name??t.source_trace_id)
save("DIAGNOSTIC_RESULT.json",{scope:authority.scope,diagnosticOnlyNotReleaseQualification:true,originalAll11AcceptanceClaimed:false,fixReleaseQualificationPassed:false,publicConstructorCalls:1,originalStepCalls:solver.iterations,naturalSdkSolved:solver.solved,naturalSdkFailed:solver.failed,thrown,phase:solver.phase,error:solver.error,failureCode:solver.failureCode,actualGeneratedCarrierCount:names.length,actualUniqueGeneratedCarrierCount:new Set(names).size,missingOriginal49:input.connections.map((c:any)=>c.name).filter((n:string)=>!names.includes(n)),getOutputCalledOnlyWhenSolved:solver.solved&&!thrown,allOriginal263FixedRowsAnd49NumericContactsHeld:true,actualConstructorInputOtherFieldsAndOwnedEndpointsHeld:true,independentActualOutputGeometryPairMetersAndFullConstraintsRequired:true,oneInitial22FieldLayerOnlyProjection:true,verifiedPairedFallbackSource:true,max40000Rationale:"Previous first paired layer used9900 original steps;40k provides room for roughly four attempts at the observed9900-step first-layer cost;90s/2GiB remain, completeness not guaranteed",checkpointCount:checkpoints,checkpointBytes,checkpointByteLimit:CHECKPOINT_TOTAL_BYTE_LIMIT,maximumCheckpointCount:CHECKPOINT_LIMIT,all4LayerAuthorityDerivedFrom98AuthenticFullSpanBarrels:true,fullSourceIntegrationOwned4AndReset2Unrun:true,uncoupledLengthDiagnosticsNeverImplyAbsentWholeCouplingLimitPass:true,sourceCoreNativeCliCadCalls:0,referenceQualified:false,electricalTimingPassed:false,all49Accepted:false,fabricationReady:false})
process.exitCode=solver.solved&&!thrown?0:1
