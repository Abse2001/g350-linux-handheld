export type Point = { x: number; y: number }
export type Pin = { path: string; sha256: string; bytes?: number; mode?: number }
export type InnerPort = { viaName: string; layer: "inner1"; viaXY: Point; numericSelector: string }
export type RouteChange = {
  originalSourceTraceId: string; logicalName: string; fromSelector: string; toSelector: string
  beforeRouteProps: Record<string, unknown>
  after: { newPcbPaths: unknown[]; newPcbPathRelativeTo: string }
}
export type Source26Delta = {
  sealedCandidatePin: Pin; sealedResetCandidatePin: Pin
  movedVia: { name: string; before: Point; after: Point }
  routeChanges: RouteChange[]
  localSuppressions: { traceName: string; numericSelector: string; viaName: string }[]
  newTwoInnerPorts: InnerPort[]
}
export type Source26Proposal = {
  scope: string; parent24Source: Pin; sealedSource3Geometry: Pin; sealedResetGeometry: Pin
  source26Delta: Source26Delta
  expectedCounts: { carrierPaths: number; physicalTraces: number; innerLiteralPorts: number; expectedSourcePorts: number; expectedReactElements: number; remainingOriginal49Requests: number }
  all49OriginalLogicalTraces: { originalSourceTraceId: string; name: string; from: string; to: string }[]
  primaryCoupledSectionView: string; secondaryCoupledSectionView: string
  singleCoupledSectionCoversBoth: boolean; bothActualSharedMeandersMustBeChecked: boolean
}
