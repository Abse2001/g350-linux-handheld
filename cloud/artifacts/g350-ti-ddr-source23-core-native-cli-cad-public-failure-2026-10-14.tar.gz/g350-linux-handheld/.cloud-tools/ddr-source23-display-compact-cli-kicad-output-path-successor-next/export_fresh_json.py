"""Future Root-only byte-exact genuine Source23 CLI export after actual Core0/Native0/API0."""
import argparse,importlib.util,json,os,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;BOARD=ROOT.parent.parent
CONTRACT=ROOT/'artifact_contract.py'
sp=importlib.util.spec_from_file_location('source23_stdlib_artifacts',CONTRACT);a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--root-receipt',type=Path,required=True);parser.add_argument('--root-receipt-sha256',required=True);parser.add_argument('--output-directory',type=Path,required=True);args=parser.parse_args()
 a.require(os.environ.get('G350_SOURCE23_FRESH_JSON_CLI_ROOT_GUARDED')=='1','Actual owned Root CLI guard required')
 manifest=ROOT/'SOURCE-manifest.json';m=json.loads(manifest.read_bytes());packet=a.sha(manifest)
 for r in m['files']+m['externalFiles']:a.binding(r)
 auth=a.authority({'path':str(args.root_receipt),'sha256':args.root_receipt_sha256},packet,m['scope'])
 raw,controls=a.actual_core();signal=a.load({'path':str(a.SIGNAL_PROPOSAL),'sha256':a.SIGNAL_SHA});_,signals,carriers,segments=a.derive_owned(raw,controls,signal)
 native,_=a.native_prerequisite(auth,carriers)
 run=args.output_directory.resolve();a.require(run.is_dir() and not run.is_symlink() and str(run)==auth['outputDirectory'] and not any(run.iterdir()),'Fresh exclusive Root-owned CLI output required')
 copy=run/'fresh-source23.circuit.json';output=run/'g350-source23.kicad_pcb';log=run/'pinned-cli.log';report=run/'cli-export-report.json'
 data=a.RAW.read_bytes()
 with copy.open('xb') as stream:stream.write(data)
 copy.chmod(0o600);a.require(a.sha(copy)==a.RAW_SHA,'Only byte-identical suffix copy allowed')
 argv=[m['bun'],'--smol',m['cliMainPath'],'export',str(copy),'--format','kicad_pcb','--output',str(output),'--disable-parts-engine']
 result={'scope':m['scope'],'sourceManifestSha256':packet,'actualCorePath':str(a.RAW),'actualCoreSha256':a.RAW_SHA,'coreControlsSha256':a.CONTROLS_SHA,'actualNativeReport':auth['actualNativeReport'],'recognizedCircuitJsonInputPath':str(copy),'recognizedCircuitJsonSha256':a.sha(copy),'actualSourceSegmentCount':segments,'actualPhysicalViaCount':227,'actualPhysicalTraceCount':286,'actualSourceOwnedCarrierCount':23,'sourceOnlyMissingRoutes':26,'byteIdenticalCopyOnly':True,'originalRawEdited':False,'sourceModuleEvaluated':False,'sourcePortHookReplayedByCli':False,'automaticCoreSrjUsed':False,'nativeOrCoreOrCadCalls':0,'cliCalls':1,'exportPassed':False,'apiAnglesFailed':False,'actualOriginalApiReport':a.ACTUAL_API,'actualNativeStageResult':a.ACTUAL_RESULT,'nativeApiCombinedStagePassed':True,'complete23Accepted':False,'referenceQualified':False,'electricalTimingQualified':False,'accepted49':False,'fabricationReady':False,'argv':argv}
 start=time.monotonic()
 try:
  with log.open('xb') as stream:child=subprocess.run(argv,cwd=BOARD,stdout=stream,stderr=subprocess.STDOUT,check=False)
  result.update(cliExitCode=child.returncode,wallSeconds=time.monotonic()-start,outputPath=str(output),outputSha256=a.sha(output) if output.is_file() else None,logPath=str(log),logSha256=a.sha(log))
  a.require(child.returncode==0 and output.is_file() and not output.is_symlink() and output.stat().st_size>0,'CLI failed; exact output/log retained')
  a.require(a.sha(copy)==a.RAW_SHA and a.sha(a.RAW)==a.RAW_SHA and a.sha(a.CONTROLS)==a.CONTROLS_SHA,'Actual Core/copy/control bytes held')
  for r in m['files']+m['externalFiles']:a.binding(r)
  a.require(a.sha(args.root_receipt)==args.root_receipt_sha256,'Root authority held');result['exportPassed']=True
 except BaseException as error:result['failure']=type(error).__name__+': '+str(error)
 with report.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
 report.chmod(0o600);print(json.dumps({'exportPassed':result['exportPassed'],'report':str(report),'output':str(output),'sourceOwnedCarriers':23,'missingRoutes':26,'freshKiCadStillRequired':True,'fabricationReady':False}));return 0 if result['exportPassed'] else 2
if __name__=='__main__':raise SystemExit(main())
