"""Pure stdlib physical geometry planner for two actual cap power refs. No runtime."""
from pathlib import Path
import json,math,hashlib,copy,heapq,time
exec(Path('/tmp/g350-cap8-power-reference-astar-sourceonly.py').read_text().rsplit("\nif __name__",1)[0])
objects[:]=[o for o in objects if o['id']!='planned_D12_head_cap_screen']
def pathtrace(name,paths):
 t={'type':'pcb_trace','pcb_trace_id':name,'connection_name':'source_trace_26','source_trace_id':'source_trace_26','route':[]}
 for j,(layer,pts) in enumerate(paths):
  if j:
   x,y=pts[0];prev=paths[j-1][0];t['route'].append({'route_type':'via','x':x,'y':y,'from_layer':prev,'to_layer':layer,'layers':L,'via_diameter':.4572,'via_hole_diameter':.254})
  for x,y in pts:t['route'].append({'route_type':'wire','x':x,'y':y,'layer':layer,'width':.1016})
 return t
DP=[('inner1',[(0,15.2),(-.4134,14.7866),(-.4134,12.6634),(0,12.25)]),('inner2',[(0,12.25),(.6,12.25),(.8,12.05),(.8,8.35),(1.2,7.95)]),('top',[(1.2,7.95),(1.35,7.8),(3,7.8),(4.8,6),(4.8,5.8)])];d12=pathtrace('planned_D12_final_cap8_screen',DP);append(d12)

class Query3(Query):
 def __init__(self,os,ownVia,ownPad):
  super().__init__(os,ownVia,ownPad);self.vcache={};self.os3=[o for o in os+PP if o['id'] not in {ownVia,ownPad}]
 def via_legal(self,q):
  if q in self.vcache:return self.vcache[q]
  p={'x':q[0],'y':q[1]}
  for o in self.os3:
   bb=o['bbox'];r=.4286
   if q[0]<bb[0]-r or q[0]>bb[1]+r or q[1]<bb[2]-r or q[1]>bb[3]+r:continue
   if o['kind']=='wire':d=pd(p,o['a'],o['b']);need=max(.2286+.1016,.127+.2)+o['radius']
   elif o['kind']=='via':d=math.dist(q,(o['p']['x'],o['p']['y']));need=max(.2286+o['radius']+.15,.127+o['holeRadius']+.254)
   elif o.get('shape')=='circle':d=math.dist(q,(o['p']['x'],o['p']['y']));need=max(.2286+o['radius']+(.15 if o.get('isVia') else .1016),.127+o['holeRadius']+.254 if o['holeRadius'] else 0)
   else:d=prect(p,o);need=.2286+.1016
   if d<need-1e-8:self.vcache[q]=False;return False
  self.vcache[q]=True;return True

def astar3(start,end,Q,step=.1,bounds=(-4,3,4,12),limit=200000):
 dirs=[(1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1)];E=(round(end[0]/step),round(end[1]/step));opens=[];dist={};prev={};count=0;S=(start[0],start[1],'bottom')
 for dx in range(-5,6):
  for dy in range(-5,6):
   x=(round(start[0]/step)+dx)*step;y=(round(start[1]/step)+dy)*step
   if not Q.legal(start,(x,y),'bottom'):continue
   a=(round(x/step),round(y/step),3);d=math.dist(start,(x,y));dist[a]=d;prev[a]=None;heapq.heappush(opens,(d+math.dist((x,y),end),d,a))
 while opens and count<limit:
  _,cost,a=heapq.heappop(opens)
  if cost>dist[a]+1e-9:continue
  count+=1;ax,ay=a[0]*step,a[1]*step;l=L[a[2]]
  if (a[0],a[1])==E:
   path=[a]
   while prev[path[-1]] is not None:path.append(prev[path[-1]])
   path.reverse();pts=[{'x':start[0],'y':start[1],'layer':'bottom'}]+[{'x':n[0]*step,'y':n[1]*step,'layer':L[n[2]]} for n in path];simp=[pts[0]];lastdir=None
   for i,(u,v) in enumerate(zip(pts,pts[1:])):
    d=(round((v['x']-u['x'])/step,6),round((v['y']-u['y'])/step,6),u['layer'],v['layer'])
    if lastdir is not None and d!=lastdir:simp.append(u)
    lastdir=d
   simp.append(pts[-1]);return {'found':True,'path':simp,'lengthPlusViaCost':cost,'states':count,'cache':len(Q.cache),'vcache':len(Q.vcache)}
  neighbors=[]
  for dx,dy in dirs:
   b=(a[0]+dx,a[1]+dy,a[2]);bx,by=b[0]*step,b[1]*step
   if bounds[0]<=bx<=bounds[1] and bounds[2]<=by<=bounds[3] and Q.legal((ax,ay),(bx,by),l):neighbors.append((b,step*math.hypot(dx,dy)))
  if Q.via_legal((ax,ay)):
   for li in range(4):
    if li!=a[2]:neighbors.append(((a[0],a[1],li),1.5))
  for b,inc in neighbors:
   nc=cost+inc
   if nc>=dist.get(b,1e99)-1e-9:continue
   dist[b]=nc;prev[b]=a;heapq.heappush(opens,(nc+math.hypot(b[0]*step-end[0],b[1]*step-end[1]),nc,b))
 return {'found':False,'states':count,'cache':len(Q.cache),'vcache':len(Q.vcache)}

if __name__=='__main__':
 results=[]
 for owner,start,end,viaId,padId in [('VDD',(.420116,7.9),(1.2,11),'pcb_via_54','pcb_smtpad_730'),('GND',(-.420116,7.9),(-1.2,10.2),'pcb_via_55','pcb_smtpad_729')]:
  Q=Query3(objects,viaId,padId);r=astar3(start,end,Q,step=.05);r['owner']=owner;results.append(r);print(r,flush=True)
 out='/tmp/g350-cap8-power-3d-astar-own-terminal-bound-report.json';Path(out).write_text(json.dumps({'scope':'PURE_STDLIB_JOINT_CPUCYCLE_AND_FINAL_D12_POWER_REFERENCE_PLAN_NOT_ACCEPTANCE','capCenter':[0,7.9],'rotation':0,'d12Paths':DP,'results':results,'nativeExecuted':False,'fabricationReady':False},indent=2)+'\n');print('sha',hashlib.sha256(Path(out).read_bytes()).hexdigest(),flush=True)
