"""Source-only proposal: strict actual Core forward, run only by Root.

This compares the accepted64-HS Core, including all original hardware/net/pad
records, against one future actual Core. Only declared source branches, alias
records, barrels and their exact foreign-reference antipads are permitted.
"""
from pathlib import Path
import collections, hashlib, json, math, sys

BOARD=Path('/workspace/g350-linux-handheld')
BASE=BOARD/'.cloud-tools/ddr-hs-all32-capture-first-type4096-root-successor-next/run-core/fresh-core.circuit.json'
PROPOSAL=BOARD/'.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/grouped-proposal.json'
BASE_SHA='384628cd46c2b5cb5b32a94d442651eda3c604c8acf19bd85fc68b728f529769'
TOLERANCE=1e-7
EXPECTED_ACTUAL_SHA="ed33a0a335b1fbf0da9adcdeacaa954b655c3c4964c600efb6ef3c72aef4040e"
ALLOWED_TOP_ALIAS_IDS={"source_port_"+str(i) for i in (1167,1171,1175,1215,1225,1227,1269)}

def require(value,message):
    if not value:raise ValueError(message)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def key(row):
    field=row['type']+'_id';require(field in row,'Missing concrete row identity')
    return row['type'],row[field]

def equivalent(a,b,label):
    if isinstance(a,dict) and isinstance(b,dict):
        require(a.keys()==b.keys(),'Original fields changed: '+label)
        for k in a:equivalent(a[k],b[k],label+'.'+k)
    elif isinstance(a,list) and isinstance(b,list):
        require(len(a)==len(b),'Original list inventory changed: '+label)
        for i,(x,y) in enumerate(zip(a,b)):equivalent(x,y,label+':'+str(i))
    elif type(a) in (int,float) and type(b) in (int,float):
        require(math.isfinite(a) and math.isfinite(b) and abs(a-b)<=TOLERANCE,'Original numeric geometry changed: '+label)
    else:require(type(a)==type(b) and a==b,'Original value/type changed: '+label)

def main():
    require(len(sys.argv)==4,'Fresh actual Core/hash/output required')
    actual_path,expected,output=Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3])
    require(not output.exists() and sha(actual_path)==expected==EXPECTED_ACTUAL_SHA,'Fresh exclusive exact already-rendered Core ed33 required')
    require(sha(BASE)==BASE_SHA,'Accepted HS64 Core changed')
    old,actual=json.loads(BASE.read_bytes()),json.loads(actual_path.read_bytes())
    proposal=json.loads(PROPOSAL.read_bytes())
    owners,groups=proposal['owners'],proposal['viaGroups']
    new_groups=[g for g in groups if g['reuseAcceptedHsViaId'] is None]
    require(len(owners)==101 and len(groups)==72 and len(new_groups)==65,'Exact101/72/65 proposal required')
    require(len({o['ownerKey'] for o in owners})==101 and len({g['key'] for g in groups})==72,'Duplicate numeric owner/canonical group')
    old_rows=[r for r in old if r['type']!='source_project_metadata']
    new_rows=[r for r in actual if r['type']!='source_project_metadata']
    before={key(r):r for r in old_rows};after={key(r):r for r in new_rows}
    require(len(before)==len(old_rows) and len(after)==len(new_rows),'Duplicate concrete identity')
    require(before.keys()<=after.keys(),'Original row removed')
    added=after.keys()-before.keys()
    allowed={'source_manually_placed_via':65,'source_port':130,'pcb_component':65,'pcb_port':130,'source_trace':101,'pcb_trace':101,'pcb_via':65}
    require(collections.Counter(k[0] for k in added)==collections.Counter(allowed),'Undeclared new physical/source record')
    require(sum(r['type']=='source_project_metadata' for r in actual)<=1,'Unexpected generated filesystem metadata')
    alias_extensions=[]
    def one(values,message):
        require(len(values)==1,message);return values[0]
    old_by_type=lambda kind:[r for r in old if r['type']==kind]
    actual_by_type=lambda kind:[r for r in actual if r['type']==kind]
    for source_id in sorted(ALLOWED_TOP_ALIAS_IDS):
        b=before[('source_port',source_id)];a=after[('source_port',source_id)]
        require('subcircuit_connectivity_map_key' not in b and a.keys()==b.keys()|{'subcircuit_connectivity_map_key'},'Only one absent alias map-key field may be added')
        stripped=dict(a);del stripped['subcircuit_connectivity_map_key'];require(stripped==b,'Every other original Top source-alias field must be exact')
        require(b['name']=='top' and b['port_hints']==['top'],'Only the original unused Top alias is eligible')
        manual=before[('source_manually_placed_via',b['source_component_id'])]
        require(after[key(manual)]==manual and manual['source_net_id'] in ('source_net_0','source_net_5'),'Original manually owned known-rail via source must be exact')
        top=one([p for p in old_by_type('pcb_port') if p['source_port_id']==source_id],'Exactly one original Top physical alias required')
        require(top['layers']==['top'] and after[key(top)]==top,'Original Top physical alias must remain exact')
        via=one([v for v in old_by_type('pcb_via') if top['pcb_port_id'] in v['pcb_port_ids']],'Exactly one original owned full-through barrel required')
        require(via['source_net_id']==manual['source_net_id'] and after[key(via)]==via,'Original reused known-rail barrel must remain exact')
        require(via['layers']==['top','inner1','inner2','bottom'] and via['outer_diameter']==.4572 and via['hole_diameter']==.254,'Original four-layer barrel dimensions must hold')
        bottom=one([p for p in old_by_type('pcb_port') if p['pcb_port_id'] in via['pcb_port_ids'] and p['layers']==['bottom']],'Exactly one original Bottom alias required')
        bottom_source=before[('source_port',bottom['source_port_id'])]
        require(after[key(bottom)]==bottom and after[key(bottom_source)]==bottom_source,'Retained Bottom aliases remain exact')
        require(bottom_source['source_component_id']==b['source_component_id'] and bottom_source['name']=='bottom','Original Top and Bottom must belong to the same authored via')
        known_key=bottom_source.get('subcircuit_connectivity_map_key')
        require(isinstance(known_key,str) and known_key and a['subcircuit_connectivity_map_key']==known_key==via['subcircuit_connectivity_map_key'],'Added key must equal exact original Bottom/barrel known-rail key')
        retained=one([t for t in old_by_type('source_trace') if bottom_source['source_port_id'] in t.get('connected_source_port_ids',[]) and t.get('connected_source_net_ids')==[manual['source_net_id']]],'Retained original numeric cap-to-Bottom branch must identify this known rail')
        require(after[key(retained)]==retained and retained['subcircuit_connectivity_map_key']==known_key,'Original Bottom source trace/key remains exact')
        group=one([g for g in groups if g['reuseAcceptedHsViaId']==via['pcb_via_id']],'Exactly one declared canonical reuse group required')
        require(group['source_net_id']==manual['source_net_id'] and group['x']==via['x'] and group['y']==via['y'],'Declared reuse must retain exact original rail/XY')
        group_owners=[o for o in owners if o['viaGroupKey']==group['key']]
        require(group_owners and sorted(o['ownerKey'] for o in group_owners)==sorted(group['ownerKeys']),'Every exact reused-site owner must be listed')
        new_branches=[]
        for owner in group_owners:
            require(owner['source_net_id']==manual['source_net_id'],'No foreign numeric owner may activate a reused alias')
            numeric=before[('source_port',owner['source_port_id'])];numeric_actual=after[key(numeric)]
            require(numeric==numeric_actual and numeric['pin_number']==owner['numericPin'],'Original package numeric source terminal remains exact')
            package=before[('source_component',numeric['source_component_id'])]
            require(package['name']==owner['package'] and after[key(package)]==package,'Original package identity remains exact')
            trace=one([t for t in actual_by_type('source_trace') if t.get('name')==owner['traceName']],'Exactly one new named numeric-to-via branch required')
            require(key(trace) in added and trace.get('connected_source_net_ids')==[manual['source_net_id']],'New branch must resolve only the same exact existing rail')
            require(sorted(trace['connected_source_port_ids'])==sorted([source_id,owner['source_port_id']]),'New branch must bind this exact original Top alias and original numeric package terminal')
            require(trace['subcircuit_connectivity_map_key']==known_key,'New named branch key must equal original Bottom/barrel key')
            new_branches.append({'ownerKey':owner['ownerKey'],'numericSourcePortId':owner['source_port_id'],'newSourceTraceId':trace['source_trace_id']})
        alias_extensions.append({'sourcePortId':source_id,'oldOptionalMapKeyAbsent':True,'onlyAddedField':'subcircuit_connectivity_map_key','addedKnownKey':known_key,'originalBottomSourcePortId':bottom_source['source_port_id'],'originalPcbViaId':via['pcb_via_id'],'originalSourceManuallyPlacedViaId':manual['source_manually_placed_via_id'],'sourceNetId':manual['source_net_id'],'declaredViaGroupKey':group['key'],'newExactNumericBranches':new_branches,'allOriginalOtherFieldsAndPhysicalRowsExact':True})
    require(len(alias_extensions)==7,'Exactly seven proved reused Top alias extensions required')
    pours=[]
    for ident,b in before.items():
        a=after[ident]
        if b['type']=='source_port' and b['source_port_id'] in ALLOWED_TOP_ALIAS_IDS:
            continue  # All seven narrowly proved records above, not a generic metadata waiver.
        if b['type']!='pcb_copper_pour':
            equivalent(b,a,'original.'+str(ident));continue
        original_brep,new_brep=b['brep_shape'],a['brep_shape']
        pb,pa=dict(b),dict(a);del pb['brep_shape'];del pa['brep_shape']
        equivalent(pb,pa,'retained-reference-owner')
        require(original_brep['outer_ring']==new_brep['outer_ring'],'Original reference outline changed')
        import shapely
        from shapely.geometry import Polygon
        from shapely.ops import unary_union
        require(shapely.__version__=='2.1.2','Pinned Shapely required')
        def polygon(brep):
            shape=Polygon([(p['x'],p['y']) for p in brep['outer_ring']['vertices']],[[ (p['x'],p['y']) for p in ring['vertices']] for ring in brep['inner_rings']])
            require(shape.is_valid and not shape.is_empty,'Invalid source reference BREP; no repair allowed')
            return shape
        old_shape,new_shape=polygon(original_brep),polygon(new_brep)
        foreign=[g for g in new_groups if g['source_net_id']!=b['source_net_id']]
        require(all(g['source_net_id'] in ('source_net_0','source_net_5') for g in foreign),'Unknown new reference owner')
        cuts=[Polygon([(round(g['x']+.3486*math.sin(i*math.pi/16),6),round(g['y']-.3486*math.cos(i*math.pi/16),6)) for i in range(32)]) for g in foreign]
        expected_shape=old_shape.difference(unary_union(cuts))
        require(expected_shape.is_valid and not expected_shape.is_empty,'Explicit owned cut union invalid')
        require(new_shape.boundary.hausdorff_distance(expected_shape.boundary)<=1e-6,'Unowned new reference boundary change')
        require(new_shape.symmetric_difference(expected_shape).area<=1e-6*(new_shape.length+expected_shape.length),'Copper change outside exact new owned antipads')
        pours.append({'pcb_copper_pour_id':b['pcb_copper_pour_id'],'source_net_id':b['source_net_id'],'layer':b['layer'],'newForeignOwnedViaCuts':len(foreign),'outerRingExact':True,'originalCopperMinusOnlyDeclaredNewAntipads':True,'serializationBoundaryToleranceMm':1e-6})
    for kind in ('pcb_trace','pcb_via'):
        held=[r for r in old if r['type']==kind]
        require(len(held)==64 and all(after[key(r)]==r for r in held),'Accepted HS64 physical records must be exact')
    for kind,count in [('source_component',280),('pcb_smtpad',1161),('source_net',98),('source_bus',8),('pcb_trace',165),('pcb_via',129)]:
        require(sum(r['type']==kind for r in actual)==count,'Unexpected actual inventory: '+kind)
    # The accepted64 base already proves frozen original0e/217 board links.
    # Every one of its source/pad/net/trace records is retained here, not reduced
    # to an incorrect assertion that newly authored branches total217 traces.
    report={'scope':'STRICT_ACCEPTED_HS64_CORE_PLUS101_DECLARED_PACKAGE_TOP_BRANCHES_AND65_CANONICAL_VIAS','actualCoreSha256':expected,'acceptedHsCoreSha256':BASE_SHA,'proposalSha256':sha(PROPOSAL),'sourceForwardPassed':True,'allAcceptedHs64PhysicalRecordsExact':True,'original217BoardLinksHeldThroughExactAcceptedSourceRecords':True,'allOriginalHardwareAndNumericSourcePortsHeld':True,'originalOptionalTopAliasKeyAdditionsOnly':alias_extensions,'allOtherOriginalSourcePortFieldsExact':True,'original280Parts1161ContactsHeld':True,'newSourceBranchesAreAdditionalConnectionsToExistingRails':True,'addedRecordCounts':dict(collections.Counter(k[0] for k in added)),'retainedReferenceCutProofs':pours,'registeredHs8GroundPadAndStripGeometryRecordsHeld':True,'noPhysicalPreservationClaimForAnyIntentionalNewDrillContact':True,'freshNumericGraphNativeManufacturingAndCadStillRequired':True,'referenceQualified':False,'accepted49':False,'fabricationReady':False}
    with output.open('x') as file:json.dump(report,file,indent=2);file.write('\n')
    print(json.dumps({'sourceForwardPassed':True,'only7ProvedOriginalTopAliasKeyAdditions':True,'allAcceptedHs64PhysicalRecordsExact':True,'newPackageBranches':101,'newCanonicalVias':65,'accepted49':False}))

if __name__=='__main__':main()
