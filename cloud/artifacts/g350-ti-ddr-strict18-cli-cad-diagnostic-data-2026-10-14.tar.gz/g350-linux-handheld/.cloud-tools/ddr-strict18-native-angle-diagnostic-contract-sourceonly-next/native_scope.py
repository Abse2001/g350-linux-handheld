"""Stdlib-only exact actual54946 Native0/API-angle-failure diagnostic gate.

This is a deliberate export diagnostic, never an accepted Native/API stage.
The original all-zero contract remains immutable and still refuses wrapper2.
"""
import importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
ORIGINAL=ROOT.parent/'ddr-strict18-export-contract-sourceonly-next/artifact_contract.py'
spec=importlib.util.spec_from_file_location('original_strict18_artifact_contract',ORIGINAL)
original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
# Preserve every original Source/owner/Core/CLI-success primitive unchanged.
for key,value in vars(original).items():
 if not key.startswith('_'):globals()[key]=value
NATIVE_ROOT=BOARD/'.cloud-tools/ddr-strict18-fresh-core-native-api-sourceonly-next/run-native'
ACTUAL_COLLECTION={'path':'/workspace/bus-lanes-solver/.cache/root-routing-progress/strict18-native-api-54946-COLLECTED-root.json','sha256':'cd33a0a3a87e2bc28c549c11c6f09dbbead34ad1ce7f0e42fbbdd36935d25b57'}
ACTUAL_POST={'path':str(NATIVE_ROOT/'POSTAUDIT.json'),'sha256':'a3f6d7f84713537ff3c302d79d6722ac07b615bddad27c269224373bc16c100e'}
ACTUAL_RESULT={'path':str(NATIVE_ROOT/'result.json'),'sha256':'635e1b46f0dc2602b9c56f1962fa86b676c3df6b6342f962a8bb2f28d801f656'}
ACTUAL_NATIVE={'path':str(NATIVE_ROOT/'native18-report.json'),'sha256':'b631993e831388065c51de581fcf169cc2fca046556098406198b2244e834f3d'}
ACTUAL_API={'path':str(NATIVE_ROOT/'actual-original-all3-pair-api.json'),'sha256':'3f4695644ea1da654e238d3c23ed5bfbc98cd5bae074759a3fd1d7d9fc4ad15c'}
NATIVE_SOURCE_SHA='1e7dea55939ef59d1cf2873ad7ac8d27fc460897ed24430ec2e943b2b77c317c'
BOUND_SHA='35dd7e75ee66f3c17616ffc42a966d3181e22df3c1ac87cf4b3cc0a158c0c447'
ANGLE_FAILURES={'source_trace_15','source_trace_16','source_trace_28'}

def validate_diagnostic_scope(collection,post,result,report,api,carriers,ix):
 require(collection.get('authorizedByRoot') is True and collection.get('toolSessionCollected') is True and collection.get('toolSessionId')==54946,'Exact actual collected Root54946 required')
 require(collection.get('toolExitCode')==collection.get('toolWrapperExitCode')==2 and collection.get('passed') is False and post.get('passed') is False and result.get('passed') is False,'Preserve authentic wrapper2/overall failed stage')
 require(collection.get('nativePhysicalChildExitCode')==0 and collection.get('nativePhysicalChildPassed') is True and collection.get('all3ApiChildExitCode')==1,'Actual Native child0 and API child1 must remain distinct')
 require(collection['postauditPath']==ACTUAL_POST['path'] and collection['postauditSha256']==ACTUAL_POST['sha256'],'Exact actual postaudit binding')
 require(collection['sourceManifestSha256']==post['sourceManifestSha256']==result['sourceManifestSha256']==report['sourceManifestSha256']==NATIVE_SOURCE_SHA and collection['packetSha256']==post['packetSha256']==result['packetSha256']==report['packetSha256']==api['packetSha256']==BOUND_SHA,'Exact unchanged source/bound packet provenance')
 execution=post['execution'];require(collection['execution']==execution and execution['exitCode']==2 and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values()) and execution['diagnosticStopped'] is False and not execution['stopReasons'] and execution['signalErrorCount']==0,'Actual failed-angle scope must be cleanly collected with no OOM/unclean stop')
 require(collection['sourceAndDependenciesHeld'] is True and post['sourceAndDependenciesHeld'] is True and post['dependenciesBefore']==post['dependenciesAfter'] and post['solverDependenciesBefore']==post['solverDependenciesAfter'] and post['runFailure'] is None and post['postverificationFailure'] is None,'Actual immutable Source/SDK inventories held')
 require(post['resultPath']==ACTUAL_RESULT['path'] and post['resultSha256']==ACTUAL_RESULT['sha256'],'Actual result binding')
 require([(c['phase'],c['exitCode']) for c in result['commands']]==[('native',0),('original3pairAPI',1)] and result['nativeCalls']==post['nativeCalls']==1 and result['original3PairApiCalls']==post['original3PairApiCalls']==1,'Actual child result commands retained with API failure')
 require(result['actualNativeReportPath']==ACTUAL_NATIVE['path'] and result['actualNativeReportSha256']==ACTUAL_NATIVE['sha256'] and result['actualOriginal3PairApiReportPath']==ACTUAL_API['path'] and result['actualOriginal3PairApiReportSha256']==ACTUAL_API['sha256'],'Actual Native/API output bindings retained')
 require(result['actualCoreSha256']==report['actualCoreSha256']==api['actualCoreSha256']==RAW_SHA and result['actualCoreControlsSha256']==report['actualCoreControlsSha256']==CONTROLS_SHA,'Actual fresh Core bytes/controls unchanged')
 require(report['checkCount']==18 and len(report['counts'])==18 and not any(report['counts'].values()) and report['physicalErrors']==0 and report['actualNativePairFindings']==[] and report['physicalCpuRamConnectedCarrierCount']==18 and report['expectedMissingOriginalSignalCount']==31,'Actual Native physical18/pair findings0 and18 graphs required')
 proof=report['actualOwnershipProof'];require([len(proof[k]) for k in ['referenceMappings','signalMappings','clocks','carriers']]==[165,96,2,18],'Complete actual reference/96/18 ownership proof retained')
 for expected in carriers:
  match=one([r for r in proof['carriers'] if r['originalSourceTraceId']==expected['originalSourceTraceId']],'Native real matching Source carrier')
  for key,value in expected.items():require(abs(match[key]-value)<1e-8 if key=='wholePlanarLengthMm' else (set(match[key])==set(value) if key=='actualDirectPcbTraceIds' else match[key]==value),'Native actual carrier differs: '+key)
  graph=match['actualSourceOwnedPhysicalGraph'];require(graph['physicallyConnected'] is True and graph['logicalMapAloneNotUsed'] is True,'Genuine physical graph required')
  edges=[]
  for trace_id in expected['actualDirectPcbTraceIds']:
   trace=ix['pcb_trace'][trace_id];edges.append({'fromActualId':trace['route'][0]['start_pcb_port_id'],'toActualId':trace['route'][-1]['end_pcb_port_id'],'basis':'ACTUAL_FRESH_SOURCE_OWNED_WIRE_PATH','actualPcbTraceId':trace_id,'actualSourceTraceId':expected['originalSourceTraceId']})
  for via_id in [expected['actualCpuViaId'],expected['actualRamViaId']]:
   for port_id in ix['pcb_via'][via_id]['pcb_port_ids']:
    port=ix['pcb_port'][port_id];owner=ix['source_port'][port['source_port_id']]['source_component_id'];require(owner in ix['source_manually_placed_via'],'Authentic fullspan Source via owner')
    edges.append({'fromActualId':port_id,'toActualId':via_id,'basis':'ACTUAL_FULLSPAN_BARREL_OWNED_ALIAS','actualSourceViaOwner':owner})
  require(sorted(json.dumps(e,sort_keys=True) for e in graph['actualEdges'])==sorted(json.dumps(e,sort_keys=True) for e in edges),'Every published physical graph edge has an authentic fresh Source owner')
  pairs={frozenset([e['fromActualId'],e['toActualId']]) for e in edges};path=graph['actualNumericCpuToRamIdPath'];require(path[0]==expected['actualCpuNumericPcbPortId'] and path[-1]==expected['actualRamNumericPcbPortId'] and len(path)==len(set(path)) and all(frozenset([p,q]) in pairs for p,q in zip(path,path[1:])),'Actual numeric CPU/RAM physical path uses genuine copper/barrels')
 require(api['actualNativeReportPath']==ACTUAL_NATIVE['path'] and api['actualNativeReportSha256']==ACTUAL_NATIVE['sha256'] and api['exactMaterialHeld'] is True and api['allOriginalApiLoaded18ChecksPassed'] is False and api['actualCompleteOriginalSignalCount']==18 and api['expectedMissingOriginalSignalCount']==31,'Retain actual failed API and immutable material')
 continuity=api['continuity'];require(len(continuity)==18 and {r['connectionName'] for r in continuity}=={c['originalSourceTraceId'] for c in carriers},'All18 original API observations retained')
 for row in continuity:
  expected=one([c for c in carriers if c['originalSourceTraceId']==row['connectionName']],'Original API real Source owner');require(row['actualCarrierPcbTraceId']==expected['actualCarrierPcbTraceId'] and row['pathVisible'] is True and row['segmentsVisible'] and all(row['segmentsVisible']) and row['selfClear'] is True and row['foreignActual18AndOriginalFixedCopperIncluded'] is True,'No hidden continuity/self/foreign failure')
  require(row['conventionalAngles'] is (row['connectionName'] not in ANGLE_FAILURES),'Exact three unrelaxed original angle failures required')
 for key in ['shared','exterior','coupling','pairLengths']:
  require(len(api[key])==3 and all(r['matched'] is True for r in api[key]),'Actual all3 '+key+' assertions remain passing and unchanged')
 require(len(api['loadedCohortBusReports'])==3 and all(r['matched'] is True and r['aboveMinimumLength'] is True and r['withinLengthLimit'] is True for r in api['loadedCohortBusReports']),'Actual loaded cohort length assertions retained')
 require(api['fullOriginalBusRostersAndConstraintsHeld'] is True and api['originalFullDifferentialPairArrayUnchanged'] is True and api['all3DifferentialPairsInvokedAgainstFreshCopper'] is True and api['originalPrivateContinuousApiImplementationsUnchanged'] is True and api['rawCoreOrAuthoritativeInputRetagged'] is False,'Original rules/API and geometry must remain intact')
 for value in [post,result,report]:require(value['accepted49'] is False and value['fabricationReady'] is False and value['referenceQualified'] is False and value['electricalTimingQualified'] is False,'No broader readiness qualification from diagnostic')
 require(api['accepted49'] is False and api['fabricationReady'] is False and api['referenceQualified'] is False and api['electricalDelayModelQualified'] is False,'API electrical/reference qualification remains false')
 for value in [post,result,report,api]:require(value['complete18Accepted'] is False,'Complete18 remains unaccepted because angles failed')
 return {'apiAnglesFailed':True,'actualOriginalApiAngleFailures':sorted(ANGLE_FAILURES),'actualNativePhysicalChildExitCode':0,'actualCollectedToolWrapperExitCode':2,'actualOriginalApiChildExitCode':1,'complete18Accepted':False}

def native_prerequisite(authority,carriers):
 require(authority['actualNativeCollection']==ACTUAL_COLLECTION and authority['actualNativeReport']==ACTUAL_NATIVE,'Diagnostic may inspect only actual54946/b631 physical Native output')
 collection=load(ACTUAL_COLLECTION);post=load(ACTUAL_POST)
 result=produced(post,ACTUAL_RESULT);report=produced(post,ACTUAL_NATIVE);api=produced(post,ACTUAL_API)
 raw,_=actual_core();ix={k:index(raw,k) for k in ['pcb_trace','pcb_via','pcb_port','source_port','source_manually_placed_via']}
 validate_diagnostic_scope(collection,post,result,report,api,carriers,ix)
 return report,post
