"""Targeted authorization/closure tests, no actual process or routing."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import sys
import unittest
from unittest.mock import MagicMock, patch

spec = importlib.util.spec_from_file_location("mixed_prefix_guard", Path(__file__).with_name("guard.py"))
guard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(guard)


class GuardTests(unittest.TestCase):
    def test_generic_owned_monitor_uses_exact_60s1GiB24GiB_policy(self):
        scope = guard.import_module("owned_scope_test", guard.ROOT / "process_scope.py")
        memory = {"current": 0, "events": {key: 0 for key in guard.OOM_KEYS}}
        self.assertEqual(scope.reasons(60, [], memory, memory, guard.POLICY), ["WALL_STOP"])
        self.assertEqual(scope.reasons(0, [{"rss": 1073741824}], memory, memory, guard.POLICY), ["OWNED_RSS_STOP"])
        self.assertEqual(scope.reasons(0, [], {**memory, "current": 25769803776}, memory, guard.POLICY), ["SHARED_MEMORY_STOP"])
        self.assertEqual(scope.reasons(59.99, [{"rss": 1073741823}], memory, memory, guard.POLICY), [])

    def test_strict_headroom_retains_own1GiB_plus2GiB_under24(self):
        guard.require_headroom(20 * 1024 ** 3)
        with self.assertRaises(ValueError):
            guard.require_headroom(int(21 * 1024 ** 3))

    def test_one_search_receipt_rejects_changed_scope_cap_and_authorization(self):
        value = {"authorizedByRoot": True, "packetSha256": "p", "policy": guard.POLICY,
                 "scope": "one-c115-public-cohort-partial-native-check", "approvalToken": "a" * 64}
        guard.require_receipt(value, "p")
        for bad in [dict(value, authorizedByRoot=False), dict(value, scope="full49"),
                    dict(value, policy={**guard.POLICY, "wallSeconds": 61}), dict(value, packetSha256="wrong")]:
            with self.assertRaises(ValueError):
                guard.require_receipt(bad, "p")

    def test_receipt_hash_and_parse_use_exactly_one_raw_read(self):
        value = {"authorizedByRoot": True, "packetSha256": "p", "policy": guard.POLICY,
                 "scope": "one-c115-public-cohort-partial-native-check", "approvalToken": "a" * 64}
        raw = json.dumps(value).encode()
        path = MagicMock()
        path.read_bytes.side_effect = [raw, b"changed afterward"]
        with patch.object(guard, "Path", return_value=path):
            parsed, digest = guard.read_receipt("mock", hashlib.sha256(raw).hexdigest(), "p")
        self.assertEqual(parsed, value)
        self.assertEqual(digest, hashlib.sha256(raw).hexdigest())
        path.read_bytes.assert_called_once()

    def test_nearest_node_modules_unlisted_file_and_fifo_fail_closed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "source/lib").mkdir(parents=True)
            (root / "source/scripts").mkdir()
            (root / "source/lib/a.ts").write_text("a")
            (root / "node_modules").symlink_to(guard.REPO / "node_modules", target_is_directory=True)
            (root / "source/node_modules").symlink_to(guard.REPO / "node_modules", target_is_directory=True)
            manifest = {"files": [{"path": "source/lib/a.ts"}]}
            with patch.object(guard, "ROOT", root):
                guard.validate_source_roots(manifest)
                (root / "source/lib/node_modules").symlink_to(guard.REPO / "node_modules", target_is_directory=True)
                with self.assertRaises(ValueError): guard.validate_source_roots(manifest)
                (root / "source/lib/node_modules").unlink()
                extra = root / "source/lib/extra.ts"
                extra.write_text("unlisted")
                with self.assertRaises(ValueError): guard.validate_source_roots(manifest)
                extra.unlink()
                os.mkfifo(extra)
                with self.assertRaises(ValueError): guard.validate_source_roots(manifest)

    def test_copied_authority_is_rejected_before_manifest_or_dependency_calls(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "root-launch-receipt.json").write_text('{"authorizedByRoot": true}')
            with patch.object(guard, "ROOT", root), patch.object(sys, "argv", ["guard.py", "--preflight"]), patch.object(guard, "checked_manifest") as manifest, patch.object(guard, "checked_provenance") as deps:
                with self.assertRaisesRegex(ValueError, "Fresh authority"):
                    guard.main()
                manifest.assert_not_called()
                deps.assert_not_called()


if __name__ == "__main__":
    unittest.main()
