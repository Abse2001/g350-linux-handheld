def closed50():
 prior=closed49();assert prior['actualClosedScopeCount']==49
 for key in('actual50CollectionPin','actual50PostauditPin','actual50ModelPin','actual50ProofPin','actual50ApiReportPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
 assert len(proposal['actual50PhasePostauditPins'])==2
 for pin in proposal['actual50PhasePostauditPins']:binding(pin)
 r=read(proposal['actual50CollectionPin']['path']);p=read(proposal['actual50PostauditPin']['path'])
 assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual50ToolSessionId'])is int and r['toolSessionId']==proposal['actual50ToolSessionId']and r['toolWrapperExitCode']==0
 assert r['scope']==p['scope']=='ROOT_SOURCE26_FRESH49_PROJECTION_AND_ORIGINAL_API119_WITH49_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='projection-api-batch'
 assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['native26PreparationPin']['sha256']and r['coreSourceManifestSha256']==p['coreSourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual50GuardManifestPin']['sha256']
 assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual50PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
 assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
 assert len(p['phases'])==2 and p['orderedPhaseNames']==p['expectedPhaseNames']==['projection','api']and p['notAttemptedPhaseNames']==[]
 identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()
 for doc in(r,p):
  for key in('guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','bothChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansFresh49ProjectionAndOriginalLoaded26Api119Only','hardwareAcceptanceCheckpointUnchanged','projectionPassed','apiPassed','projectionBeforeApiSeriallyEnforced','originalApiMethodInvocationCountNotInstrumented'):assert doc[key]is True
  for key in('batchFailure','finalVerificationFailure','originalApiCalls'):assert doc[key]is None
  for key in('Source26Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
  assert doc['originalApiBooleanPredicates']==119 and doc['CoreCalls']==doc['nativeCalls']==doc['cliCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
 assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
 owned=[];previous=None
 for phase,row,pin in zip(('projection','api'),p['phases'],proposal['actual50PhasePostauditPins']):
  assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
  for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
  for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
  assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
  assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
  e=row['execution'];h.finite(e,0);assert e['policy']==api26_contract['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and e['pgid']not in owned and c.guard.process_scope.owned(e['pgid'])==[];owned.append(e['pgid'])
  if previous is not None:assert previous['endedAt']<=e['startedAt']
  previous=e
  binding(row['packetPin'])
  if row['authorityPin']is not None:binding(row['authorityPin'])
  for output in row['outputFiles']:binding(output)
  for key in('Source26Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
  assert row['CoreCalls']==row['nativeCalls']==row['cliCalls']==row['cadCalls']==0
 projection,api=p['phases'];assert p['projectionExecution']==projection['execution']and p['apiExecution']==api['execution']and len(projection['outputFiles'])==5 and len(api['outputFiles'])==1
 assert projection['result']==dict(actualFresh49Model=proposal['actual50ModelPin'],actualFresh49ProjectionProof=proposal['actual50ProofPin'],source26FreshFull49ProjectionPassed=True,actual49Requests=49,actualFixedTraces=263,actualHardObstacles=1298,actualSignalViaEvents=98,zeroSelected26CarrierBodiesSeeded=True)
 assert api['result']==dict(actualOriginalApiReportPin=proposal['actual50ApiReportPin'],originalApiLoaded26ChecksPassed=True,originalApiBooleanPredicates=119,apiMethodInvocationCount=None,methodCountNotInstrumented=True,bothDqs1CoupledViewsPassed=True,loadedCohortsExplicitlyPartial=dict(DDR_BYTE0=6,DDR_BYTE1=11,DDR_COMMAND_CLOCK=8))and api['originalApiCalls']is None and api['originalApiBooleanPredicates']==119
 assert p['actualFresh49Model']==proposal['actual50ModelPin']and p['actualFresh49ProjectionProof']==proposal['actual50ProofPin']and p['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and p['actualNativeReport']==proposal['actual49ReportPin']
 proof=read(proposal['actual50ProofPin']['path']);model=read(proposal['actual50ModelPin']['path']);v=read(proposal['actual50ApiReportPin']['path'])
 assert proof['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and proof['actualNativeReportSha256']==proposal['actual49ReportPin']['sha256']and proof['constructorInputSha256']==proposal['actual50ModelPin']['sha256']and proof['sourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and proof['originalSource26ProposalSha256']==proposal['promoted26ProposalPin']['sha256']and proof['exactFullInverseToFresh26Parent']is True
 assert len(model['connections'])==49 and len(model['traces'])==263 and len(model['obstacles'])==1298 and model['layerCount']==4 and sum(q['route_type']=='via'for t in model['traces']for q in t['route'])==98
 assert v['scope']=='ACTUAL_MOVED26_FRESH_CORE_ALL3_UNCHANGED_ORIGINAL_PRIVATE_API_DIAGNOSTIC'and v['packetSha256']==api['packetPin']['sha256']and v['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and v['actualNativeReportSha256']==proposal['actual49ReportPin']['sha256']and v['original49Input']=={k:proposal['actual50ModelPin'][k]for k in('path','sha256')}
 assert v['actualCompleteOriginalSignalCount']==26 and v['expectedMissingOriginalSignalCount']==23 and v['allOriginalApiLoaded26ChecksPassed']is True and v['checkInventory']['primaryBooleanPredicates']==116 and v['checkInventory']['secondaryDqs1BooleanPredicates']==3 and v['checkInventory']['primaryPlusSecondaryBooleanPredicates']==119
 assert v['secondaryDqs1View']['geometryAndEndpointsUnchanged']is v['secondaryDqs1View']['passed']is v['exactMaterialHeld']is v['fullOriginalBusRostersAndConstraintsHeld']is v['originalPrivateContinuousApiImplementationsUnchanged']is True
 for key in('complete26Accepted','accepted49','fabricationReady','referenceQualified','fullCohortTimingPassed','electricalDelayModelQualified'):assert v[key]is False
 assert {proposal['actual50ModelPin']['path'],proposal['actual50ProofPin']['path']}.issubset({x['path']for x in projection['outputFiles']})and api['outputFiles']==[proposal['actual50ApiReportPin']]
 assert projection['command']==[api26_contract['pythonInterpreterPin']['path'],'-B',api26_contract['projectorPin']['path'],projection['packetPin']['path'],projection['packetPin']['sha256'],str(Path(proposal['actual50ModelPin']['path']).parent)]
 assert api['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',api26_contract['apiWorkerPin']['path'],api['packetPin']['path'],api['packetPin']['sha256'],api['authorityPin']['path'],api['authorityPin']['sha256'],proposal['actual49ReportPin']['path'],proposal['actual50ApiReportPin']['path']]
 prior['actual50Fresh49AndOriginalApi119CollectionPin']={'path':proposal['actual50CollectionPin']['path'],'sha256':proposal['actual50CollectionPin']['sha256']};prior['actualClosedScopeCount']=50;prior['actual50TwoChildrenDoNotQualifyCliCadFull49OrElectrical']=True
 return prior
