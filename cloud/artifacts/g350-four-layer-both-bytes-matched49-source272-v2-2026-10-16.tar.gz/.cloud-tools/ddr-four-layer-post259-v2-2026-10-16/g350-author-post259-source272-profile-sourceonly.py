#!/usr/bin/env python3
"""Own-stdlib public byte catalog only; no SDK/application import or geometry."""
import hashlib,json,os,re,stat
from pathlib import Path
OUT=Path('/tmp/g350-post259-source272-checkpoint-profile-sourceonly.json')
ROOT=Path('/workspace/g350-linux-handheld')
RUNS={
260:'/tmp/g350-actual253-byte1-retimed49-root-20261016-run260',
261:'/tmp/g350-byte1-matched49-projector-root-20261016-run261',
262:'/tmp/g350-byte1-matched49-capture-root-20261016-run262',
263:'/tmp/g350-byte1-matched49-capture-obj-step-root-20261016-run263',
264:'/tmp/g350-byte1-matched49-core-obj-step-root-20261016-run264',
265:'/tmp/g350-ca15-retimed49-root-20261016-run265',
266:'/tmp/g350-byte1-matched49-via-track-root-20261016-run266',
267:'/tmp/g350-byte1-matched49-native-root-20261016-run267',
268:'/tmp/g350-both-bytes-retimed49-root-20261016-run268',
269:'/tmp/g350-both-bytes-ca9-matched49-projector-root-20261016-run269',
270:'/tmp/g350-both-bytes-ca9-matched49-capture-root-20261016-run270',
271:'/tmp/g350-both-bytes-ca9-matched49-core-root-20261016-run271',
272:'/tmp/g350-both-bytes-ca9-matched49-core-smol-root-20261016-run272',
273:'/tmp/g350-both-bytes-ca9-matched49-native-root-20261016-run273',
274:'/tmp/g350-both-bytes-ca9-matched49-via-track-root-20261016-run274'}
DENIED=('ROOT_AUTHORITY','PRIVATE_CONTEXT','CONTEXT_BODY','BOUND_CONTEXT','AUTHORITY_PACKET')
def safe(p):return p.is_absolute() and str(p).startswith('/tmp/g350-') and p.resolve().is_relative_to('/tmp') and not any(s in str(p).upper() for s in DENIED) and p.is_file() and not p.is_symlink()
def meta(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1048576):h.update(b)
  if hasattr(os,'posix_fadvise'):os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 return {'bytes':p.stat().st_size,'sha256':h.hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode)}
catalog={}
for rel in ('.cloud-tools/ddr-four-layer-manual-2026-10-16','.cloud-tools/ddr-four-layer-post209-2026-10-16','.cloud-tools/ddr-four-layer-post232-2026-10-16','.cloud-tools/ddr-four-layer-post252-2026-10-16'):
 m=json.loads((ROOT/rel/'WORKSPACE_RESTORE_MANIFEST.json').read_bytes())
 for row in m['files']:catalog[row['restorePath']]=row
artifacts={};bindings={};runs=[];sources=set()
def add(p,role,force=False):
 p=Path(p)
 if not safe(p):return
 d=meta(p)
 if not force and str(p) in catalog and all(catalog[str(p)].get(k)==v for k,v in d.items()):return
 assert not re.search(r'run(?:27[5-9]|2[89][0-9]|[3-9][0-9]{2})',str(p)),'Later runtime excluded'
 artifacts[str(p)]={'path':str(p),'role':role,**d}
 if p.suffix in ('.py','.ts','.tsx','.mjs'):sources.add(p)
def pin_rows(value):
 if isinstance(value,dict):
  if isinstance(value.get('path'),str) and re.fullmatch('[0-9a-f]{64}',str(value.get('sha256',''))):
   p=Path(value['path'])
   if safe(p):assert meta(p)['sha256']==value['sha256'];add(p,'EXACT_PUBLIC_INPUT_BINDING')
  for v in value.values():pin_rows(v)
 elif isinstance(value,list):
  for v in value:pin_rows(v)
for scope,folder in RUNS.items():
 d=Path(folder);receipt=json.loads((d/'COLLECTED.json').read_bytes());assert receipt['scope']==scope and receipt['closedAt']
 runs.append({'scope':scope,'folder':folder,'closureSha256':meta(d/'COLLECTED.json')['sha256'],'exitCode':receipt['execution']['exitCode']})
 for p in sorted(d.glob('byte0-result*.json')):add(p,'CLOSED_SCOPE_'+str(scope)+'_OUTPUT',True)
 add(d/'COLLECTED.json','CLOSED_SCOPE_'+str(scope)+'_RECEIPT',True)
 for n in ('execution.json','child.log','memory.jsonl'):add(d/'owned'/n,'CLOSED_SCOPE_'+str(scope)+'_PUBLIC_RUNTIME',True)
 for arg in receipt['execution']['command']:
  p=Path(arg)
  if safe(p):add(p,'CLOSED_SCOPE_'+str(scope)+'_EXPLICIT_COMMAND_INPUT',p.suffix in ('.ts','.py'))
 report=d/'byte0-result.json'
 if report.exists():pin_rows(json.loads(report.read_bytes()).get('inputBindings',{}))
extra=[
'/tmp/g350-both-bytes-ca9-matched49-core272-raw.json',
'/tmp/g350-source272-all16-literal-pour-margin-root-aggregate-20261016.json',
'/tmp/g350-source272-new-pdn-annular-same-polygon-root-20261016.json',
'/tmp/g350-plan269-fresh-core-two-pdn-same-polygon-annular-contact-sourceonly.py',
'/tmp/g350-source49-plan269-both-bytes-matched-literal-selected-pour-clearance-audit-sourceonly.py',
'/tmp/g350-source49-plan269-both-bytes-matched-literal-pour-coverage-combiner-sourceonly.py',
'/tmp/g350-route-bounded-explicit-input-smol-root-20261016.py',
'/tmp/g350-plot-source272-both-bytes-matched49-root-sourceonly.py',
*[f'/tmp/g350-source272-literal-pour-batch{i}-root-20261016.json' for i in range(1,5)],
*[f'/tmp/g350-source272-both-bytes-matched49-root-20261016-plot/SOURCE272_BOTH_BYTES_MATCHED_CAP12_CAP8_PDN_CONNECTED49_FOUR_LAYER_MILESTONE.{e}' for e in ('png','svg')]]
for name in extra:
 p=Path(name);assert safe(p),name;add(p,'SOURCE272_EXACT_SCOPED_CHECKPOINT_EVIDENCE',True)
 if p.suffix=='.json':
  value=json.loads(p.read_bytes())
  if isinstance(value,dict):pin_rows(value.get('inputBindings',{}))
visited=set()
for _ in range(2):
 for p in sorted(sources-visited):
  visited.add(p)
  for v in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]",p.read_text()):add(Path(v),'EXPLICIT_PUBLIC_SOURCE_DEPENDENCY')
doc={'scope':'POST259_SOURCE272_CONNECTED49_BOTH_BYTES_MATCHED_CA_UNMATCHED_FROZEN_PROFILE',
 'schemaVersion':1,'latestClosedScopeIncluded':274,'runs':runs,'artifacts':sorted(artifacts.values(),key=lambda r:r['path']),
 'candidateSha256':'fcc50ba7874af9724526a443367f70eeb42bff6179eb07ef8fd3ff929c0c6c77',
 'rawSha256':'33584d197a1bb45a0dc76ac0a69e7016866a2369f1750c72d5eedc41ef444594',
 'controlsSha256':'32eec52a75348a996f7fbfd4271b2318c9bf4c39229fd67a289d97835aa63ec4',
 'frozenCheckpoint':True,'rootRenderedAndViewedPlot':True,'routedOwners':49,'pendingOwnerIds':[],
 'bothBytePlanarSkewsPassed':True,'caMinimumPassingCount':9,'caTotalCount':26,'caSkewPassed':False,
 'failed262STEPParsePreserved':True,'failed271RSSStopPreserved':True,'source264IndependentNotInherited':True,
 'excludedLaterScopes':[275,276,277],'profileAuthoredUsingOwnStdlibOnly':True,
 'sdkExecutedByProfileAuthor':False,'collectorExecutedByProfileAuthor':False,
 'fullTimingPassed':False,'tiQualified':False,'referenceContinuityQualified':False,'electricalTimingQualified':False,
 'cadQualified':False,'all49Accepted':False,'fabricationReady':False}
with OUT.open('x') as f:json.dump(doc,f,indent=2,allow_nan=False);f.write('\n');os.fchmod(f.fileno(),0o600)
print(json.dumps({'profile':str(OUT),'sha256':meta(OUT)['sha256'],'artifacts':len(artifacts)}))
