"""Root-authorized pure stdlib geometry only; no solver/runtime execution."""
from pathlib import Path
import json,math,hashlib
baseLib=Path('/tmp/g350-d12-fixed-corridor-portals-sourceonly.py').read_text().split("if __name__")[0]
baseLib=baseLib.replace("raw=json.load(open('/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json'))", "p=load(SCENE_PATH,SCENE_PIN);f=p['full49FanoutInput']\nraw=json.load(open('/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json'))")
baseLib=baseLib.replace("if owner(t)=='source_trace_26':continue","if owner(t)=='source_trace_'+str(FOCUS):continue").replace("if 'source_trace_26' in o.get('connectedTo',[]):continue","if 'source_trace_'+str(FOCUS) in o.get('connectedTo',[]):continue")
baseLib=baseLib.replace("elif o['shape']=='circle':d=math.hypot(q['x']-o['p']['x'],q['y']-o['p']['y']);need=max(.2286+o['radius']+.15", "elif o['shape']=='circle':d=math.hypot(q['x']-o['p']['x'],q['y']-o['p']['y']);need=max(.2286+o['radius']+(.15 if o.get('isVia') else .1016)")
baseLib=baseLib.replace("d=pointRect(q,o);need=.2286+.15", "d=pointRect(q,o);need=.2286+.1016")
def focus(n,p,pin):
 g={'FOCUS':n,'SCENE_PATH':p,'SCENE_PIN':pin};exec(baseLib,g);return g
