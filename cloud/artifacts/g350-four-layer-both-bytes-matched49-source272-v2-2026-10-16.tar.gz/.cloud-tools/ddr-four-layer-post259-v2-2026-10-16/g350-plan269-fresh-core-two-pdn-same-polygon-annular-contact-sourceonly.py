#!/usr/bin/env python3
"""SOURCE ONLY annular-contact successor: author has not executed this file or any SDK.

Root-run proof of two local PDN connections in actual fresh plan269 Core filled BREPs.
The preserved Source257 negative is historical only; no old polygon result is inherited.
New PDN disks still require FULL OD containment. A named original GND barrel may
use a proven complete positive-width annular contact band rather than full OD.
Every identity comes from fresh typed Core rows and a completed current-via
authentication. Captured numeric suffixes and older filled polygons are unused.
This proves the two disk-to-same-island contacts, not board/timing acceptance.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys
import time

PLAN = Path('/tmp/g350-both-bytes-ca9-matched49-projector-root-20261016-run269/byte0-result.json')
PLAN_SHA = '4bb8153b7dddfcd73b78dad9d07483c239967680bdd25ef53b5487da46fbb107'
CANDIDATE_SHA = 'fcc50ba7874af9724526a443367f70eeb42bff6179eb07ef8fd3ff929c0c6c77'
DESCRIPTOR = Path('/tmp/g350-current243-cap8-two-declared-pdn-nodes-Vdd72-descriptor-v2-sourceonly.json')
DESCRIPTOR_SHA = '20e698e6225f7aa0759aa4acf70103c5f90f3894ae94726336e098598b3f3976'
CAP8_PROFILE = 'CAP8_AT_0_7P9_TWO_NEW_PLANE_VIAS_VDD7P2'
POLICY = 'ONLY SourceTrace connected_source_port_ids and connected_source_net_ids; no PCB/copper/via alias/geometric union'
LAYERS = ['top', 'inner1', 'inner2', 'bottom']
ALL49 = ['source_trace_' + str(i) for i in range(49)]
EPS = 1e-9
PRIOR = Path('/tmp/g350-source257-new-pdn-same-polygon-root-20261016.json')
PRIOR_SHA = 'a7e83cfb76a258eb211b00e962c74ce7ba46f60a1aa864bb53f61eea43deece8'
PRIOR_SOURCE = Path('/tmp/g350-plan254-fresh-two-pdn-same-polygon-contact-sourceonly.py')
PRIOR_SOURCE_SHA = 'c437815a3ac2f486d7c0540835517a6ebfd0147a096db927643d986267d52081'
HISTORICAL_RAW257_SHA = 'db3cc308c41304d57c37ca027de5bfa45379e149c1eb313940eed65050807d6d'
HISTORICAL_CONTROLS257_SHA = 'cdfdef69b8e2893167d7a826dbc6dc9e2cdbd0491b17d0653dac1f2b0dfa36c6'
HISTORICAL_AUTH259_SHA = 'bd06f6163f4ae2258e375f67b0b55ee562bbb2071d58dd6952176ee03704166a'
AUTH_SCOPE = 'EXPLICITLY_PINNED_M49_PLAN269_BOTH_BYTES_MATCHED_CAP12_CAP8_TWO_PDN_AUTHENTICATED_234_MANUAL_VIA_TRACK_MANUFACTURING_DIAGNOSTIC'
CAPTURE270_SHA = 'a370b9a6e2b05a72f84be9696beff79adad3bd9fd7cfa16045319b5dd381c6ec'
TARGETS = [
    {'name': 'V_CAP8_REPLAY_DDR_1V5', 'netName': 'DDR_1V5', 'layer': 'inner2', 'xy': [.4, 7.2]},
    {'name': 'V_CAP8_REPLAY_GND', 'netName': 'GND', 'layer': 'inner1', 'xy': [-1.6, 7.4]},
]


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def is_sha(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def read_pin(path, expected):
    require(is_sha(expected), 'Mandatory lowercase64-hex SHA256')
    data = path.read_bytes()
    require(digest(data) == expected, 'Input SHA256 mismatch: ' + str(path))
    return json.loads(data)


def unique_index(rows, key):
    out = {}
    for row in rows:
        value = row.get(key)
        require(isinstance(value, str) and value not in out, 'Unique typed identity required: ' + key)
        out[value] = row
    return out


def same_roster(a, b):
    return isinstance(a, list) and len(a) == len(b) and len(set(a)) == len(a) and set(a) == set(b)


def xy(p):
    a = (p['x'], p['y'])
    require(all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in a), 'Finite literal XY')
    return a


def near(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1]) <= EPS


class Uf:
    def __init__(self):
        self.parent = {}

    def add(self, item):
        self.parent.setdefault(item, item)

    def root(self, item):
        if item not in self.parent:
            return None
        if self.parent[item] != item:
            self.parent[item] = self.root(self.parent[item])
        return self.parent[item]

    def union(self, a, b):
        self.add(a)
        self.add(b)
        self.parent[self.root(b)] = self.root(a)


def point_segment(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    den = dx * dx + dy * dy
    t = 0.0 if den == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / den))
    closest = (a[0] + t * dx, a[1] + t * dy)
    return math.hypot(p[0] - closest[0], p[1] - closest[1]), closest


def prepare_ring(raw, label):
    require(isinstance(raw, dict) and isinstance(raw.get('vertices'), list), 'Literal BREP ring vertices required')
    points = [xy(p) for p in raw['vertices']]
    if len(points) > 1 and points[0] == points[-1]:
        points = points[:-1]
    require(len(points) >= 3 and len(set(points)) >= 3, 'Nondegenerate BREP ring: ' + label)
    area = sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(points, points[1:] + points[:1])) / 2
    require(abs(area) > EPS, 'Nonzero-area BREP ring: ' + label)
    return {'label': label, 'points': points, 'signedAreaMm2': area,
            'edges': list(zip(points, points[1:] + points[:1]))}


def location(p, ring):
    """Return boundary/interior/exterior; no bounding-box-only verdict."""
    inside = False
    for a, b in ring['edges']:
        if point_segment(p, a, b)[0] <= EPS:
            return 'boundary'
        if (a[1] > p[1]) != (b[1] > p[1]) and p[0] < a[0] + (p[1] - a[1]) * (b[0] - a[0]) / (b[1] - a[1]):
            inside = not inside
    return 'interior' if inside else 'exterior'


def disk_proof(center, radius, region):
    outer = location(center, region['rings'][0])
    holes = [location(center, r) for r in region['rings'][1:]]
    nearest = None
    ring_proofs = []
    for r in region['rings']:
        best = None
        for i, (a, b) in enumerate(r['edges']):
            distance, closest = point_segment(center, a, b)
            item = {'ring': r['label'], 'edgeIndex': i, 'edge': [a, b], 'closestPoint': closest, 'distanceMm': distance}
            if best is None or distance < best['distanceMm']:
                best = item
        ring_proofs.append(best)
        if nearest is None or best['distanceMm'] < nearest['distanceMm']:
            nearest = best
    inside_filled = outer == 'interior' and all(v == 'exterior' for v in holes)
    margin = nearest['distanceMm'] - radius
    return {'center': center, 'landRadiusMm': radius, 'outerLocation': outer, 'holeLocations': holes,
            'centerStrictlyInsideFilledRegion': inside_filled, 'minimumBoundaryDistanceMm': nearest['distanceMm'],
            'wholeLandDiskBoundaryMarginMm': margin, 'nearestBoundary': nearest,
            'allRingMinimumDistances': ring_proofs, 'wholeLandDiskInThisFilledPolygon': inside_filled and margin >= -EPS}


def main():
    parser = argparse.ArgumentParser()
    for key in ('input', 'controls', 'auth', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    for key in ('input-sha', 'controls-sha', 'auth-sha', 'auth-scope'):
        parser.add_argument('--' + key, required=True)
    parser.add_argument('--budget-ms', type=int, default=165000)
    args = parser.parse_args()
    require(1000 <= args.budget_ms <= 165000 and not args.output.exists(), 'Fresh output and1000..165000ms budget required')
    require(args.output.resolve() not in {p.resolve() for p in (args.input, args.controls, args.auth, PLAN, DESCRIPTOR)}, 'Output cannot replace any input')
    require(all(is_sha(v) for v in (args.input_sha, args.controls_sha, args.auth_sha)), 'Explicit actual raw/control/auth SHA256 arguments required')
    require(args.auth_scope == AUTH_SCOPE, 'Explicit reviewed plan269 current234 authentication scope required')
    prior = read_pin(PRIOR, PRIOR_SHA)
    require(digest(PRIOR_SOURCE.read_bytes()) == PRIOR_SOURCE_SHA, 'Frozen prior sufficient-condition Source preserved')
    require(prior.get('passed') is False and prior.get('newPdnLocalPlaneContactsQualified') is False
            and prior.get('inputBindings', {}).get('raw', {}).get('sha256') == HISTORICAL_RAW257_SHA
            and prior.get('inputBindings', {}).get('controls', {}).get('sha256') == HISTORICAL_CONTROLS257_SHA
            and prior.get('inputBindings', {}).get('auth', {}).get('sha256') == HISTORICAL_AUTH259_SHA,
            'Retain exact historical Source257 negative full-held-disk result; it is not a result on the current raw')
    started = time.monotonic()
    pins = [(args.input, args.input_sha), (args.controls, args.controls_sha), (args.auth, args.auth_sha), (PLAN, PLAN_SHA), (DESCRIPTOR, DESCRIPTOR_SHA)]
    raw, controls, auth, plan, declaration = [read_pin(p, s) for p, s in pins]
    require(isinstance(raw, list), 'Actual fresh Core array required')
    require(controls.get('rawCoreSha256') == args.input_sha and controls.get('planSha256') == PLAN_SHA
            and controls.get('candidateSha256') == CANDIDATE_SHA and controls.get('explicitPlanSha256') == PLAN_SHA
            and controls.get('actualCaptureSha256') == CAPTURE270_SHA,
            'Fresh controls must bind exact raw, actual269 plan and actual268 candidate')
    require(controls.get('freshCoreDerived') is True and controls.get('sourceNumericIdsDerivedFromActualRows') is True
            and controls.get('capturedIdsUsedAsFreshIds') is False and controls.get('circuitJsonGeometryEdited') is False
            and controls.get('rawIdsAssigned') is False and controls.get('immutableInputPinsUnchanged') is True,
            'Fresh unedited Core/actual numeric-ID provenance required')
    require(controls.get('partialCoreControlPassed') is True and controls.get('freshCoreControlPassed') is True
            and controls.get('partialDiagnosticReplayControlsPassed') is True and len(controls.get('checks', [])) == 35
            and all(c.get('passed') is True for c in controls['checks']), 'All35 fresh actual Core controls must pass')
    require(controls.get('expectedConnectedOwners') == 49 and controls.get('expectedPendingOwners') == 0
            and same_roster(controls.get('routedOwnerIds'), ALL49) and controls.get('pendingOwnerIds') == [], 'Exact49/0 partition required')
    require(same_roster([r.get('originalSourceTraceId') for r in controls.get('logical49Projection', [])], ALL49)
            and all(r.get('passed') is True for r in controls['logical49Projection'])
            and same_roster([r.get('originalSourceTraceId') for r in controls.get('physicalGraphs', [])], ALL49)
            and all(r.get('physicallyConnectedByActualOwnedNumericIdGraph') is True for r in controls['physicalGraphs']),
            'All49 actual logical numeric graphs must connect')
    require(plan.get('inputBindings', {}).get('candidate', {}).get('sha256') == CANDIDATE_SHA
            and same_roster(plan.get('routedOwnerIds'), ALL49) and plan.get('pendingOwnerIds') == [], 'Exact reviewed plan269 candidate and owner roster')
    cap8 = plan.get('cap8HardwareDelta', {})
    require(cap8.get('profile') == CAP8_PROFILE and cap8.get('originalDeclaration') == declaration
            and cap8.get('descriptorBinding', {}).get('sha256') == DESCRIPTOR_SHA
            and controls.get('cap8HardwareDelta') == cap8 and controls.get('cap8HardwareDeltaProfile') == CAP8_PROFILE,
            'Exact cap8 descriptor/profile in both actual plan and current controls')
    n, i, r, a, p, j = (len(plan.get('newVias', [])), len(plan.get('innerPortRegistrations', [])),
                        sum(len(g['wireRuns']) for g in plan.get('projectedGeometry', [])), len(plan.get('auxiliaryLocalTraces', [])),
                        len(cap8.get('pdnVias', [])), len(cap8.get('innerPortRegistrations', [])))
    require((n, i, r, a, p, j) == (103, 80, 152, 0, 2, 4), 'Actual269 N103/I80/R152/A0/P2/J4 required')
    expected = {'physicalVias': 234, 'pcbComponents': 514, 'sourceAndPcbPorts': 1713, 'sourceTraces': 1097,
                'physicalTraces': 317, 'reactElements': 2225, 'newVias': 105, 'newSignalVias': 103,
                'newPdnVias': 2, 'newInnerPorts': 84, 'newSignalInnerPorts': 80, 'newPdnInnerPorts': 4,
                'routedWireRuns': 152, 'auxiliaryLocalTraces': 0, 'routedOwners': 49, 'pendingOwners': 0}
    require(all(controls.get('expectedCounts', {}).get(k) == v for k, v in expected.items()), 'Exact current234 Core inventory')
    rows = lambda kind: [row for row in raw if row.get('type') == kind]
    for kind, count in [('source_component', 280), ('source_manually_placed_via', 234), ('pcb_via', 234), ('pcb_component', 514),
                        ('source_port', 1713), ('pcb_port', 1713), ('source_trace', 1097), ('pcb_trace', 317)]:
        require(len(rows(kind)) == count, 'Actual typed Core count: ' + kind)
    tables = {kind: unique_index(rows(kind), key) for kind, key in [('pcb_via', 'pcb_via_id'), ('pcb_port', 'pcb_port_id'),
              ('source_port', 'source_port_id'), ('pcb_component', 'pcb_component_id'), ('source_manually_placed_via', 'source_manually_placed_via_id'),
              ('source_trace', 'source_trace_id'), ('source_net', 'source_net_id')]}
    vias, pp, sp, pc, manual, sources, nets = [tables[k] for k in ('pcb_via', 'pcb_port', 'source_port', 'pcb_component', 'source_manually_placed_via', 'source_trace', 'source_net')]
    require(auth.get('scope') == args.auth_scope and auth.get('complete') is True and auth.get('actualViaCount') == 234
            and auth.get('completedViaCount') == 234 and auth.get('logicalUfPolicy') == POLICY
            and auth.get('exactInputFilesUnchanged') is True and auth.get('foreignViaTrackCopperClearancePassed') is True
            and auth.get('requiredCopperEdgeClearanceMm') == .1016, 'Completed current234 authentic ownership/foreign-track result required')
    for key, sha in [('raw', args.input_sha), ('controls', args.controls_sha), ('plan', PLAN_SHA), ('candidate', CANDIDATE_SHA)]:
        require(auth.get('inputBindings', {}).get(key, {}).get('sha256') == sha, 'Current auth binding: ' + key)
    require(auth.get('expectedConnectedOwners') == 49 and auth.get('expectedPendingOwners') == 0
            and same_roster(auth.get('routedOwnerIds'), ALL49) and auth.get('pendingOwnerIds') == [], 'Auth exact49/0 owner roster')
    require(all(auth.get(k) == [] for k in ('violations', 'ambiguousVias', 'identityFailures', 'invalidSegments', 'unresolvedSegmentOwners')), 'No unresolved/ambiguous/foreign-track failures')
    auth_rows = unique_index(auth.get('viaReports', []), 'pcbViaId')
    require(set(auth_rows) == set(vias), 'Auth covers exact234 current via IDs')
    uf, declarations = Uf(), []
    for sid, trace in sources.items():
        uf.add(sid)
        ports, net_ids = trace.get('connected_source_port_ids', []), trace.get('connected_source_net_ids', [])
        require(isinstance(ports, list) and isinstance(net_ids, list), 'Actual Source declaration arrays')
        for port in ports:
            require(port in sp, 'Source declaration uses actual source port')
            uf.union(sid, port)
        for net in net_ids:
            require(net in nets, 'Source declaration uses actual SourceNet')
            uf.union(sid, net)
        declarations.append({'sourceTraceId': sid, 'connectedSourcePortIds': ports, 'connectedSourceNetIds': net_ids})
    require(auth.get('declaredLogicalSources') == declarations, 'Independently reconstructed Source-only declarations match auth')
    alias_use = {}
    incident_by_alias = {}
    physical_trace_index = unique_index(rows('pcb_trace'), 'pcb_trace_id')
    for trace in physical_trace_index.values():
        for endpoint in trace.get('route', []):
            for key in ('start_pcb_port_id', 'end_pcb_port_id'):
                if endpoint.get(key):
                    incident_by_alias.setdefault(endpoint[key], []).append((trace, endpoint))
    for vid, v in vias.items():
        for alias in v.get('pcb_port_ids', []):
            alias_use.setdefault(alias, []).append(vid)
    identities = {}
    for vid, via in vias.items():
        proof = auth_rows[vid]
        require(same_roster(via.get('layers'), LAYERS) and via.get('from_layer') == 'top' and via.get('to_layer') == 'bottom'
                and via.get('outer_diameter') == .4572 and via.get('hole_diameter') == .254, 'All234 actual fullspan/dimension controls')
        aliases, mids, cids, layer_list, roots = [], set(), set(), [], set()
        for alias in via.get('pcb_port_ids', []):
            port = pp.get(alias)
            source = sp.get(port.get('source_port_id')) if port else None
            part = pc.get(port.get('pcb_component_id')) if port else None
            mv = manual.get(source.get('source_component_id')) if source else None
            require(port is not None and source is not None and part is not None and mv is not None
                    and alias_use.get(alias) == [vid] and near(xy(port), xy(via)) and near(xy(part['center']), xy(via))
                    and part.get('source_component_id') == source.get('source_component_id') and part.get('rotation') == 0
                    and part.get('layer') == 'top' and abs(part.get('width', 0) - .4572) <= EPS and abs(part.get('height', 0) - .4572) <= EPS
                    and len(port.get('layers', [])) == 1 and port['layers'][0] in LAYERS and source.get('name') == port['layers'][0],
                    'Actual typed via/component/port identity chain, with unique physical alias')
            mids.add(source['source_component_id']); cids.add(part['pcb_component_id']); layer_list.append(port['layers'][0])
            root = uf.root(source['source_port_id'])
            if root is not None:
                roots.add(root)
            for trace, endpoint in incident_by_alias.get(alias, []):
                trace_root = uf.root(trace.get('source_trace_id'))
                require(trace_root is not None and endpoint.get('route_type') == 'wire'
                        and endpoint.get('layer') == port['layers'][0] and near(xy(endpoint), xy(port)),
                        'Actual named SourceTrace incident via alias has exact physical endpoint/layer')
                roots.add(trace_root)
            aliases.append({'actualPcbPortId': alias, 'actualSourcePortId': source['source_port_id'], 'layer': port['layers'][0]})
        require(len(mids) == 1 and len(cids) == 1 and len(layer_list) == len(set(layer_list)) and {'top', 'bottom'} <= set(layer_list), 'One genuine manual/physical via with unique layer aliases')
        for field, table in [('source_trace_id', sources), ('source_net_id', nets)]:
            if via.get(field):
                require(via[field] in table and uf.root(via[field]) is not None, 'Actual explicit via Source owner')
                roots.add(uf.root(via[field]))
        if via.get('pcb_trace_id'):
            owner = physical_trace_index.get(via['pcb_trace_id'])
            require(owner is not None and uf.root(owner.get('source_trace_id')) is not None, 'Explicit actual PCB-trace owner must resolve through real SourceTrace')
            roots.add(uf.root(owner['source_trace_id']))
        root = proof.get('selectedLogicalRoot')
        require(proof.get('aliasIdentityAuthenticated') is True and proof.get('logicalOwnerResolved') is True
                and near(xy(proof['xy']), xy(via)) and proof.get('outerDiameter') == .4572 and proof.get('holeDiameter') == .254
                and same_roster(proof.get('layers'), LAYERS) and root is not None and roots and roots == {root},
                'Current234 authentication agrees with independently typed Source-derived via identity/root')
        identities[vid] = {'actualPcbViaId': vid, 'actualManualViaSourceId': next(iter(mids)),
                           'actualPcbComponentId': next(iter(cids)), 'xy': xy(via), 'logicalSourceRoot': root, 'aliases': aliases}
    held = controls.get('heldViaChecks', [])
    generated = controls.get('generatedViaChecks', [])
    require(len(held) == 129 and all(v.get('passed') is True for v in held)
            and len({v.get('name') for v in held}) == 129 and len({v.get('actualFreshPcbViaId') for v in held}) == 129,
            'All129 original held reference barrels, named and actual-ID unique')
    held_ids = {v['actualFreshPcbViaId'] for v in held}
    require(held_ids <= set(vias) and len(generated) == 105 and all(v.get('passed') is True for v in generated)
            and {v['actualPcbViaId'] for v in generated}.isdisjoint(held_ids)
            and {v['actualPcbViaId'] for v in generated} | held_ids == set(vias), 'Exact129 held +105 real generated current via partition')
    for v in held:
        actual = identities[v['actualFreshPcbViaId']]
        require(same_roster([a['actualFreshPcbPortId'] for a in v.get('aliases', [])], [a['actualPcbPortId'] for a in actual['aliases']])
                and all(a.get('authentic') is True for a in v['aliases']), 'Held actual aliases match independently typed identities')
    pours = rows('pcb_copper_pour')
    unique_index(pours, 'pcb_copper_pour_id')
    require(pours, 'Actual freshly generated filled BREP polygons required')
    prepared, examined, errors, results = {}, [], [], []
    for target in TARGETS:
        require((time.monotonic() - started) * 1000 < args.budget_ms, 'Bounded proof time expired')
        selected = [v for v in generated if v.get('name') == target['name']]
        net_rows = [v for v in nets.values() if v.get('name') == target['netName']]
        require(len(selected) == 1 and len(net_rows) == 1, 'One authentic named new PDN via and unique named actual SourceNet')
        selected, net = selected[0], net_rows[0]
        vid, nid = selected['actualPcbViaId'], net['source_net_id']
        via, ident = vias[vid], identities[vid]
        require(selected.get('generatedKind') == 'PDN' and selected.get('declaredNetPassed') is True
                and selected.get('declaredNetName') == target['netName'] and selected.get('actualDeclaredNetId') == nid
                and selected.get('actualViaSourceId') == ident['actualManualViaSourceId']
                and selected.get('actualPcbComponentId') == ident['actualPcbComponentId']
                and via.get('source_net_id') == nid and manual[ident['actualManualViaSourceId']].get('source_net_id') == nid
                and near(xy(via), target['xy']) and ident['logicalSourceRoot'] == uf.root(nid)
                and same_roster([a['layer'] for a in ident['aliases']], LAYERS), 'Actual declared PDN source/physical identity/net/layers/XY chain')
        compatible = [p for p in pours if p.get('layer') == target['layer'] and p.get('source_net_id') == nid]
        require(compatible, 'At least one fresh BREP for actual target net/layer')
        trials = []
        for pour in compatible:
            require((time.monotonic() - started) * 1000 < args.budget_ms, 'Bounded proof time expired')
            pid = pour['pcb_copper_pour_id']
            if pid not in prepared:
                require(pour.get('shape') == 'brep' and isinstance(pour.get('brep_shape'), dict), 'Actual BREP only; no polygon approximation')
                brep = pour['brep_shape']
                rings = [prepare_ring(brep.get('outer_ring'), 'outer')] + [prepare_ring(r, 'hole_' + str(i)) for i, r in enumerate(brep.get('inner_rings', []))]
                prepared[pid] = {'rings': rings}
                examined.append({'actualPcbCopperPourId': pid, 'actualSourceNetId': nid, 'actualLayer': pour['layer'],
                                 'literalBrepShape': brep, 'ringInventory': [{'label': r['label'], 'vertexCount': len(r['points']), 'signedAreaMm2': r['signedAreaMm2']} for r in rings]})
            region = prepared[pid]
            new_disk = disk_proof(xy(via), via['outer_diameter'] / 2, region)
            witnesses = []
            annular_witnesses = []
            for h in held:
                hid = h['actualFreshPcbViaId']
                hi = identities[hid]
                if hi['logicalSourceRoot'] != uf.root(nid):
                    continue
                incident = []
                alias_ids = {a['actualPcbPortId'] for a in hi['aliases']}
                for trace in rows('pcb_trace'):
                    if uf.root(trace.get('source_trace_id')) != uf.root(nid):
                        continue
                    for endpoint in [trace.get('route', [{}])[0], trace.get('route', [{}])[-1]]:
                        port_id = endpoint.get('start_pcb_port_id') or endpoint.get('end_pcb_port_id')
                        if port_id in alias_ids:
                            require(endpoint.get('route_type') == 'wire' and near(xy(endpoint), xy(vias[hid]))
                                    and endpoint.get('layer') in pp[port_id]['layers'], 'Authentic held reference incident owned physical endpoint')
                            incident.append({'actualPcbTraceId': trace['pcb_trace_id'], 'actualSourceTraceId': trace['source_trace_id'],
                                             'actualPcbPortId': port_id, 'layer': endpoint['layer']})
                if not incident:
                    continue
                disk = disk_proof(xy(vias[hid]), vias[hid]['outer_diameter'] / 2, region)
                if disk['wholeLandDiskInThisFilledPolygon']:
                    witnesses.append({'heldSourceViaName': h['name'], **hi, 'explicitActualSourceNetId': vias[hid].get('source_net_id'),
                                      'sameActualSourceNetBySourceDeclarations': nid, 'incidentOwnedReferenceEndpoints': incident, 'diskProof': disk})
                if target['netName'] == 'GND' and h['name'] == 'V_TI_PKG_SITE_010_GND':
                    # Fullspan plated metal joins the Top package ground stub to
                    # this Inner1 annular band. No polygon or via is enlarged.
                    ram_sources = [s for s in rows('source_component') if s.get('name') == 'U_RAM']
                    require(len(ram_sources) == 1, 'One authentic real RAM source component')
                    ram_sp = [p for p in sp.values() if p.get('source_component_id') == ram_sources[0]['source_component_id'] and p.get('pin_number') == 14]
                    require(len(ram_sp) == 1, 'Actual numeric U_RAM.pin14 ground Source port')
                    ram_pp = [p for p in pp.values() if p.get('source_port_id') == ram_sp[0]['source_port_id']]
                    tops = [a for a in hi['aliases'] if a['layer'] == 'top']
                    ground_sources = [s for s in sources.values() if s.get('name') == 'TI_PKG_U_RAM_PIN14_GND']
                    require(len(ram_pp) == 1 and len(tops) == 1 and len(ground_sources) == 1, 'Unique actual RAM land, held Top alias and named package ground SourceTrace')
                    gs = ground_sources[0]
                    ground_wires = [t for t in physical_trace_index.values() if t.get('source_trace_id') == gs['source_trace_id']]
                    require(len(ground_wires) == 1, 'One actual owned Top package ground physical trace')
                    gw = ground_wires[0]; route = gw.get('route', [])
                    require(nets[nid].get('name') == 'GND' and vias[hid].get('source_net_id') == nid
                            and manual[hi['actualManualViaSourceId']].get('source_net_id') == nid
                            and same_roster(gs.get('connected_source_port_ids'), [ram_sp[0]['source_port_id'], tops[0]['actualSourcePortId']])
                            and gs.get('connected_source_net_ids') == [nid]
                            and uf.root(ram_sp[0]['source_port_id']) == uf.root(nid)
                            and near(xy(vias[hid]), (-3.2, 11.2)) and len(route) == 2
                            and route[0].get('start_pcb_port_id') == tops[0]['actualPcbPortId']
                            and route[-1].get('end_pcb_port_id') == ram_pp[0]['pcb_port_id']
                            and near(xy(route[0]), xy(vias[hid])) and near(xy(route[-1]), xy(ram_pp[0]))
                            and same_roster(ram_pp[0].get('layers'), ['top'])
                            and all(p.get('route_type') == 'wire' and p.get('layer') == 'top' and p.get('width') == .2 for p in route),
                            'Held site010 actual plated barrel/Top alias/package GND Source net and numeric RAM pin14 wire chain')
                    hole_radius = vias[hid]['hole_diameter'] / 2
                    outer_radius = vias[hid]['outer_diameter'] / 2
                    guaranteed_radius = min(outer_radius, disk['minimumBoundaryDistanceMm']) - EPS
                    band = guaranteed_radius - hole_radius
                    annular_pass = disk['centerStrictlyInsideFilledRegion'] and band > 1e-6
                    # The entire disk up to guaranteed_radius is in the exact
                    # filled region. Removing its drill disk leaves a complete
                    # positive-width annulus in both plated land and same pour.
                    annular_witnesses.append({'heldSourceViaName': h['name'], **hi,
                        'actualSourceNetId': nid, 'actualSourceNetName': 'GND',
                        'authenticPackageGroundSourceTrace': gs, 'authenticPackageGroundPcbTrace': gw,
                        'actualRamNumericSourcePort': ram_sp[0], 'actualRamNumericPcbPort': ram_pp[0],
                        'actualHeldTopAlias': tops[0], 'fullHeldLandDiskProof': disk,
                        'fullHeldLandDiskSufficientConditionPassed': disk['wholeLandDiskInThisFilledPolygon'],
                        'holeRadiusMm': hole_radius, 'outerLandRadiusMm': outer_radius,
                        'guaranteedFilledDiskRadiusMm': guaranteed_radius,
                        'guaranteedCompleteAnnularContactBandWidthMm': band,
                        'guaranteedCompleteAnnularContactAreaMm2': math.pi * max(0, guaranteed_radius**2 - hole_radius**2),
                        'minimumStrictlyPositiveBandMm': 1e-6,
                        'actualFullspanPlatedBarrelJoinsTopPackageReferenceToThisInner1Annulus': True,
                        'noGeometryOrRuleChange': True, 'passed': annular_pass})
            trial = {'actualPcbCopperPourId': pid, 'actualLayer': pour['layer'], 'actualSourceNetId': nid,
                     'newPdnLandDisk': new_disk, 'heldSameNetFullLandWitnesses': witnesses, 'heldSameNetAnnularContactWitnesses': annular_witnesses,
                     'passed': new_disk['wholeLandDiskInThisFilledPolygon'] and (bool(witnesses) or any(a['passed'] for a in annular_witnesses))}
            trials.append(trial)
        ok = any(t['passed'] for t in trials)
        if not ok:
            errors.append({'kind': 'NO_SINGLE_FRESH_FILLED_POLYGON_HAS_FULL_NEW_PDN_LAND_AND_AUTHENTIC_HELD_SAME_NET_FULL_LAND_OR_PROVEN_COMPLETE_PLATED_ANNULUS', 'target': target})
        results.append({'sourceViaName': target['name'], 'actualSourceNetName': target['netName'], 'actualSourceNetId': nid,
                        'referenceLayer': target['layer'], 'newPdnIdentity': ident, 'polygonTrials': trials, 'passed': ok})
    for pin_path, pin_sha in pins:
        require(digest(pin_path.read_bytes()) == pin_sha, 'Pinned input changed during proof: ' + str(pin_path))
    require(digest(PRIOR.read_bytes()) == PRIOR_SHA and digest(PRIOR_SOURCE.read_bytes()) == PRIOR_SOURCE_SHA, 'Prior negative report and Source remain immutable')
    passed = len(results) == 2 and all(r['passed'] for r in results) and not errors
    report = {'scope': 'PLAN269_FRESH_CORE_TWO_NEW_PDN_FULL_LAND_PLUS_HELD_ANNULAR_BAND_SAME_FILLED_POLYGON_CONTACT_PROOF', 'passed': passed,
              'newPdnLocalPlaneContactsQualified': passed, 'exactInputFilesUnchanged': True,
              'inputBindings': {k: {'path': str(p), 'sha256': s} for k, (p, s) in zip(['raw', 'controls', 'auth', 'plan', 'descriptor'], pins)},
              'priorFullHeldDiskSufficientConditionReport': {'path': str(PRIOR), 'sha256': PRIOR_SHA, 'passed': False, 'source': {'path': str(PRIOR_SOURCE), 'sha256': PRIOR_SOURCE_SHA}, 'preservedWithoutEdits': True, 'sufficientConditionWasStricterThanElectricalContact': True, 'historicalOnly': True, 'currentRawEvidence': False, 'currentQualificationInherited': False},
              'geometryOrManufacturingRulesChanged': False, 'source257ContactQualificationInherited': False, 'source264ContactQualificationInherited': False, 'candidateBinding': plan['inputBindings']['candidate'], 'authScope': args.auth_scope, 'logicalUfPolicy': POLICY,
              'actualViaCount': 234, 'heldOriginalReferenceViaCount': 129, 'actualRealPartCount': 280,
              'expectedConnectedOwners': 49, 'expectedPendingOwners': 0, 'inventory': expected,
              'actualFreshPourRoster': [{'actualPcbCopperPourId': p['pcb_copper_pour_id'], 'layer': p.get('layer'), 'sourceNetId': p.get('source_net_id'), 'shape': p.get('shape')} for p in pours],
              'distanceModel': 'Exact literal fresh vertex-defined BREP outer minus every hole. Strict center containment and minimum distance to every closed ring edge >= actual full .2286mm land radius. One authentic held same-SourceNet full land disk OR the specifically authenticated plated site010 GND complete positive-width annulus must pass in the identical polygon. Annular outer radius is min(actualOD/2, every-ring boundary distance) minus1e-9; inner radius is actualdrill/2. New PDN disk requirement is unchanged FULL OD.',
              'geometryEpsilonMm': EPS, 'examinedFilledPolygons': examined, 'newPdnPlaneContactResults': results, 'errors': errors,
              'elapsedMs': (time.monotonic() - started) * 1000, 'regeneratedPlaneContinuityQualified': False,
              'ddrReferencePlaneContinuityQualified': False, 'electricalTimingQualified': False, 'wholeBoardPassed': False,
              'cadQualified': False, 'all49Accepted': False, 'fabricationReady': False}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as f:
        json.dump(report, f, indent=2, allow_nan=False)
        f.write('\n')
    print(json.dumps({'output': str(args.output), 'passed': passed, 'newPdnLocalPlaneContactsQualified': passed, 'errors': len(errors)}))
    return 0 if passed else 2


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print(json.dumps({'scope': 'PLAN269_FRESH_CORE_TWO_PDN_ANNULAR_CONTACT_PROOF_FAILURE', 'type': type(error).__name__, 'message': str(error)}), file=sys.stderr)
        sys.exit(2)
