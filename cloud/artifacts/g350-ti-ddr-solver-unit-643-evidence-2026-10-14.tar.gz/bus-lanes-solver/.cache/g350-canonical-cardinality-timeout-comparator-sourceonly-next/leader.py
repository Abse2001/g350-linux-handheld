from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, sys, time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
assert os.environ.get('G350_TIMEOUT_COMPARATOR_APPROVED') == '1'
packet = json.loads((ROOT / 'PREPARED.json').read_bytes())
spec = importlib.util.spec_from_file_location('comparator_owned_scope', packet['processScopePath'])
scope = importlib.util.module_from_spec(spec); spec.loader.exec_module(scope)

def environment_record():
    return {name: {'present': name in os.environ,
                  'valueSha256': hashlib.sha256(os.environ[name].encode()).hexdigest()
                  if name in os.environ else None}
            for name in packet['environmentNames']}

def cpu_record():
    path = Path('/sys/fs/cgroup/cpu.stat')
    return {name: int(value) for name, value in
            (line.split() for line in path.read_text().splitlines())} if path.is_file() else None

def parse_log(path):
    text = path.read_text(errors='replace')
    summaries = re.findall(r'^Ran (\d+) tests across (\d+) files?\.', text, re.M)
    passes = re.findall(r'^\s*(\d+) pass\s*$', text, re.M)
    failures = re.findall(r'^\s*(\d+) fail\s*$', text, re.M)
    expectations = re.findall(r'^\s*(\d+) expect\(\) calls\s*$', text, re.M)
    cases = []; filename = None
    for line in text.splitlines():
        if line.startswith('tests/') and line.endswith(':'): filename = line[:-1]
        match = re.fullmatch(r'\((pass|fail)\) (.*?) \[([\d.]+)ms\]', line)
        if match:
            cases.append({'file': filename, 'status': match[1], 'name': match[2],
                          'milliseconds': float(match[3]), 'timeoutMilliseconds': None})
        timeout = re.search(r'this test timed out after (\d+)ms', line)
        if timeout and cases: cases[-1]['timeoutMilliseconds'] = int(timeout[1])
    counts = {'pass': int(passes[-1]) if passes else None,
              'fail': int(failures[-1]) if failures else None,
              'tests': int(summaries[-1][0]) if summaries else None,
              'files': int(summaries[-1][1]) if summaries else None,
              'expectCalls': int(expectations[-1]) if expectations else None}
    return counts, cases

environment = environment_record(); steps = []
for item in packet['stages']:
    assert environment_record() == environment
    assert not [p for p in scope.owned(os.getpgrp()) if p['pid'] != os.getpid()]
    log_path = ROOT / 'run' / (item['name'] + '-child.log')
    (ROOT / 'run/phase.json').write_text(json.dumps({'phase': item['name'], 'completed': steps}) + '\n')
    before_cpu = cpu_record(); started = time.monotonic()
    with log_path.open('wb') as output:
        child = subprocess.Popen(item['command'], cwd=item['sourceDirectory'],
                                 stdout=output, stderr=subprocess.STDOUT, shell=False)
        _, status, usage = os.wait4(child.pid, 0)
        child.returncode = os.waitstatus_to_exitcode(status)
    elapsed = time.monotonic() - started
    counts, cases = parse_log(log_path)
    row = {'name': item['name'], 'command': item['command'],
           'sourceDirectory': item['sourceDirectory'], 'exitCode': child.returncode,
           'wallSeconds': elapsed, 'userCpuSeconds': usage.ru_utime,
           'systemCpuSeconds': usage.ru_stime, 'peakChildRssBytes': usage.ru_maxrss * 1024,
           'minorFaults': usage.ru_minflt, 'majorFaults': usage.ru_majflt,
           'voluntaryContextSwitches': usage.ru_nvcsw,
           'involuntaryContextSwitches': usage.ru_nivcsw,
           'cgroupCpuBefore': before_cpu, 'cgroupCpuAfter': cpu_record(),
           'environmentPresenceAndHashes': environment, 'logPath': str(log_path),
           'logSha256': hashlib.sha256(log_path.read_bytes()).hexdigest(),
           'actualCounters': counts, 'cases': cases,
           'testsPassed': child.returncode == 0 and counts['pass'] == 9
                          and counts['fail'] == 0 and counts['tests'] == 9
                          and counts['files'] == 2 and len(cases) == 9}
    steps.append(row)
    (ROOT / 'run/steps.json').write_text(json.dumps(steps, indent=2) + '\n')
    print(json.dumps({'stage': row['name'], 'exitCode': row['exitCode'],
                      'wallSeconds': elapsed, 'actualCounters': counts,
                      'testsPassed': row['testsPassed']}), flush=True)
    assert not [p for p in scope.owned(os.getpgrp()) if p['pid'] != os.getpid()]
assert environment_record() == environment
(ROOT / 'run/result.json').write_text(json.dumps({
    'diagnosticStagesCompleted': len(steps) == 2, 'steps': steps,
    'oldTestsPassed': steps[0]['testsPassed'], 'newTestsPassed': steps[1]['testsPassed'],
    'wholeSuiteExecuted': False, 'allElevenBenchmarksExecuted': False,
    'accepted49': False, 'fabricationReady': False}, indent=2) + '\n')
# Diagnostic collection succeeds even when an original test reports failure.
# Each original child exit and timeout is retained above; no passing claim follows.
