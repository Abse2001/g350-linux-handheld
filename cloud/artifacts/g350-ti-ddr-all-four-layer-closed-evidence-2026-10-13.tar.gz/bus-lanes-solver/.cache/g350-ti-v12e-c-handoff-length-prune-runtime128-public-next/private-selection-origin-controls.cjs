"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/source/lib/geometry.ts.cjs
var require_geometry_ts = __commonJS({
  "qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/source/lib/geometry.ts.cjs"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.length = void 0;
    exports2.distance = distance;
    exports2.pointSegmentDistance = pointSegmentDistance;
    exports2.pointSegmentDistanceToPoints = pointSegmentDistanceToPoints;
    exports2.segmentDistance = segmentDistance;
    exports2.simplify = simplify;
    exports2.segmentsTooClose = segmentsTooClose;
    function distance(a, b) {
      const dx = a.x - b.x, dy = a.y - b.y;
      return Math.sqrt(dx * dx + dy * dy);
    }
    function pointSegmentDistance(p, edge) {
      return pointSegmentDistanceToPoints(p, edge[0], edge[1]);
    }
    function pointSegmentDistanceToPoints(p, a, b) {
      const dx = b.x - a.x, dy = b.y - a.y;
      if (dx === 0 && dy === 0)
        return distance(p, a);
      const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy || 1)));
      const ex = p.x - a.x - t * dx, ey = p.y - a.y - t * dy;
      return Math.sqrt(ex * ex + ey * ey);
    }
    var cross = (a, b, c) => (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
    function segmentDistance(ab, cd) {
      const [a, b] = ab, [c, d] = cd;
      if (Math.max(a.x, b.x) >= Math.min(c.x, d.x) && Math.max(c.x, d.x) >= Math.min(a.x, b.x) && Math.max(a.y, b.y) >= Math.min(c.y, d.y) && Math.max(c.y, d.y) >= Math.min(a.y, b.y) && cross(a, b, c) * cross(a, b, d) <= 0 && cross(c, d, a) * cross(c, d, b) <= 0)
        return 0;
      return Math.min(pointSegmentDistance(a, cd), pointSegmentDistance(b, cd), pointSegmentDistance(c, ab), pointSegmentDistance(d, ab));
    }
    var length = (path) => path.slice(1).reduce((sum, p, i) => sum + distance(path[i], p), 0);
    exports2.length = length;
    function simplify(path) {
      const result2 = [];
      for (const [index, point] of path.entries()) {
        if (result2.length && distance(result2.at(-1), point) < 1e-12) {
          if (index === path.length - 1)
            result2[result2.length - 1] = point;
          continue;
        }
        while (result2.length > 1) {
          const a = result2[result2.length - 2], b = result2.at(-1);
          const ux = b.x - a.x, uy = b.y - a.y;
          const vx = point.x - b.x, vy = point.y - b.y;
          const scale = Math.hypot(ux, uy) * Math.hypot(vx, vy);
          if (ux * vx + uy * vy <= 0 || Math.abs(ux * vy - uy * vx) > scale * 1e-8 || pointSegmentDistance(b, [a, point]) > 1e-10)
            break;
          result2.pop();
        }
        result2.push(point);
      }
      return result2;
    }
    function segmentsTooClose(ab, cd, required) {
      const [a, b] = ab, [c, d] = cd;
      if (Math.max(a.x, b.x) + required < Math.min(c.x, d.x) || Math.max(c.x, d.x) + required < Math.min(a.x, b.x) || Math.max(a.y, b.y) + required < Math.min(c.y, d.y) || Math.max(c.y, d.y) + required < Math.min(a.y, b.y))
        return false;
      return segmentDistance(ab, cd) < required;
    }
  }
});

// qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/source/lib/route-conflict-index.ts.cjs
var require_route_conflict_index_ts = __commonJS({
  "qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/source/lib/route-conflict-index.ts.cjs"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RouteConflictIndex = void 0;
    var geometry_1 = require_geometry_ts();
    var RouteConflictIndex = class {
      geometry = /* @__PURE__ */ new WeakMap();
      conflicts = /* @__PURE__ */ new WeakMap();
      getGeometry(route) {
        const cached = this.geometry.get(route);
        if (cached)
          return cached;
        const edges = [];
        const bounds = new Float64Array(Math.max(0, route.length - 1) * 4);
        let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
        for (let i = 1; i < route.length; i++) {
          const a = route[i - 1], b = route[i], offset = (i - 1) * 4;
          edges.push([a, b]);
          bounds[offset] = Math.min(a.x, b.x);
          bounds[offset + 1] = Math.max(a.x, b.x);
          bounds[offset + 2] = Math.min(a.y, b.y);
          bounds[offset + 3] = Math.max(a.y, b.y);
          minX = Math.min(minX, bounds[offset]);
          maxX = Math.max(maxX, bounds[offset + 1]);
          minY = Math.min(minY, bounds[offset + 2]);
          maxY = Math.max(maxY, bounds[offset + 3]);
        }
        const result2 = { edges, bounds, minX, maxX, minY, maxY };
        this.geometry.set(route, result2);
        return result2;
      }
      firstConflict(first, second, required) {
        let row = this.conflicts.get(first);
        const cached = row?.get(second);
        if (cached?.required === required)
          return cached.result;
        if (!row) {
          row = /* @__PURE__ */ new WeakMap();
          this.conflicts.set(first, row);
        }
        const a = this.getGeometry(first), b = this.getGeometry(second);
        let result2 = null;
        if (a.maxX + required >= b.minX && b.maxX + required >= a.minX && a.maxY + required >= b.minY && b.maxY + required >= a.minY) {
          conflict: for (let i = 0; i < a.edges.length; i++) {
            const ai = i * 4;
            for (let j = 0; j < b.edges.length; j++) {
              const bj = j * 4;
              if (a.bounds[ai + 1] + required < b.bounds[bj] || b.bounds[bj + 1] + required < a.bounds[ai] || a.bounds[ai + 3] + required < b.bounds[bj + 2] || b.bounds[bj + 3] + required < a.bounds[ai + 2])
                continue;
              if ((0, geometry_1.segmentDistance)(a.edges[i], b.edges[j]) < required) {
                result2 = [i + 1, j + 1];
                break conflict;
              }
            }
          }
        }
        row.set(second, { required, result: result2 });
        return result2;
      }
    };
    exports2.RouteConflictIndex = RouteConflictIndex;
  }
});

// qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/source/lib/select-route-candidates.ts.cjs
var require_select_route_candidates_ts = __commonJS({
  "qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/source/lib/select-route-candidates.ts.cjs"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RouteCandidatePool = void 0;
    var geometry_1 = require_geometry_ts();
    var route_conflict_index_1 = require_route_conflict_index_ts();
    var CandidateConflicts = class {
      bits = new Uint8Array(0);
      sparse = /* @__PURE__ */ new Map();
      get(id) {
        if (id >= 4096)
          return this.sparse.get(id);
        const value = this.bits[id];
        return value ? value === 2 : void 0;
      }
      set(id, value) {
        if (id >= 4096) {
          this.sparse.set(id, value);
          return;
        }
        if (id >= this.bits.length) {
          const next = new Uint8Array(Math.max(16, 2 ** Math.ceil(Math.log2(id + 1))));
          next.set(this.bits);
          this.bits = next;
        }
        this.bits[id] = value ? 2 : 1;
      }
      keys() {
        return this.sparse.keys();
      }
      delete(id) {
        this.sparse.delete(id);
      }
    };
    var RouteCandidatePool = class {
      clearance;
      limit;
      pools = /* @__PURE__ */ new Map();
      nextId = 0;
      additions = 0;
      assignments = /* @__PURE__ */ new Map();
      routeConflicts = new route_conflict_index_1.RouteConflictIndex();
      signatures = /* @__PURE__ */ new Map();
      routeSignatures = /* @__PURE__ */ new WeakMap();
      revision = 0;
      selection;
      constructor(clearance, limit = 120) {
        this.clearance = clearance;
        this.limit = limit;
      }
      add(unit, traces) {
        const pool2 = this.pools.get(unit) ?? [];
        let signatures = this.signatures.get(unit);
        if (!signatures) {
          signatures = /* @__PURE__ */ new Set();
          this.signatures.set(unit, signatures);
        }
        const signature = `[${traces.map((trace) => {
          let value = this.routeSignatures.get(trace.route);
          if (value === void 0) {
            value = JSON.stringify(trace.route);
            this.routeSignatures.set(trace.route, value);
          }
          return value;
        }).join(",")}]`;
        if (signatures.has(signature))
          return;
        const lengths = traces.map((trace) => (0, geometry_1.length)(trace.route));
        const candidate = {
          traces,
          key: signature,
          length: lengths.reduce((sum, value) => sum + value, 0),
          peak: Math.max(...lengths),
          layers: [...new Set(traces.map((t) => t.route[0].layer))],
          singleLayer: traces.every((t) => t.route[0].layer === traces[0].route[0].layer) ? traces[0].route[0].layer : void 0,
          conflicts: new CandidateConflicts(),
          id: this.nextId++
        };
        pool2.push(candidate);
        signatures.add(signature);
        if (pool2.length > this.limit)
          signatures.delete(pool2.shift().key);
        this.pools.set(unit, pool2);
        this.additions++;
        this.revision++;
      }
      transformUnit(unit, transform) {
        const alternatives = this.pools.get(unit) ?? [];
        this.pools.delete(unit);
        this.signatures.delete(unit);
        this.revision++;
        for (const candidate of alternatives) {
          const traces = transform(candidate.traces);
          if (traces)
            this.add(unit, traces);
        }
      }
      hasEveryUnit(units) {
        return units.every((unit) => !!this.pools.get(unit)?.length);
      }
      /** Small unresolved domain set for generating fresh conditional routes.
       * A bounded search failure is a refinement hint, not an impossibility proof. */
      unresolvedUnits(units) {
        if (this.compatible(units.map((n) => this.pools.get(n) ?? []), 5e5))
          return null;
        let subset = units.slice();
        for (const unit of units) {
          const remaining = subset.filter((n) => n !== unit);
          if (!this.compatible(remaining.map((n) => this.pools.get(n) ?? []), 5e5))
            subset = remaining;
        }
        return subset;
      }
      conditionalRoutes(units, trial, completion = []) {
        if (!units.length)
          return [];
        const pivot = trial % units.length, index = Math.floor(trial / units.length);
        const domains = units.map((n, i) => {
          const pool2 = this.pools.get(n) ?? [];
          return trial < 0 || i !== pivot || !pool2.length ? pool2 : [pool2[index % pool2.length]];
        });
        let selected = this.compatible(domains, 5e5);
        if (!selected)
          return null;
        const extended = selected.map((candidate) => [candidate]);
        for (const unit of completion) {
          if (units.includes(unit))
            continue;
          const domain = this.pools.get(unit) ?? [];
          const next = this.compatible([...extended, domain]);
          if (!next)
            continue;
          extended.push(domain);
          selected = next;
        }
        return selected.flatMap((candidate) => candidate.traces);
      }
      get revisionNumber() {
        return this.revision;
      }
      collides(a, b) {
        if (a.singleLayer !== void 0 && b.singleLayer !== void 0 && a.singleLayer !== b.singleLayer)
          return false;
        const low = a.id < b.id ? a : b;
        const high = Math.max(a.id, b.id);
        const row = low.conflicts;
        const cached = row.get(high);
        if (cached !== void 0)
          return cached;
        if (!a.layers.some((layer) => b.layers.includes(layer))) {
          row.set(high, false);
          return false;
        }
        for (const first of a.traces)
          for (const second of b.traces) {
            if (first.route[0].layer !== second.route[0].layer)
              continue;
            const required = (first.route[0].width + second.route[0].width) / 2 + this.clearance - 1e-8;
            if (this.routeConflicts.firstConflict(first.route, second.route, required)) {
              row.set(high, true);
              return true;
            }
          }
        row.set(high, false);
        return false;
      }
      compatible(domains, searchBudget = 5e4) {
        const key = `${searchBudget}:` + domains.map((domain) => domain.map((c) => c.id).join(",")).join(";");
        if (this.assignments.has(key))
          return this.assignments.get(key);
        const result2 = this.computeCompatible(domains, searchBudget);
        if (this.assignments.size >= 128)
          this.assignments.delete(this.assignments.keys().next().value);
        this.assignments.set(key, result2);
        return result2;
      }
      computeCompatible(domains, searchBudget) {
        if (domains.some((domain) => !domain.length))
          return null;
        const layers = domains.map((domain) => new Set(domain.flatMap((candidate) => candidate.layers)));
        const pending = new Set(domains.map((_, i) => i));
        const components = [];
        while (pending.size) {
          const component = [pending.values().next().value];
          pending.delete(component[0]);
          for (let j = 0; j < component.length; j++)
            for (const i of pending) {
              if (![...layers[i]].some((layer) => layers[component[j]].has(layer)))
                continue;
              pending.delete(i);
              component.push(i);
            }
          components.push(component);
        }
        if (components.length > 1) {
          const combined = [];
          for (const component of components) {
            const result2 = this.compatible(component.map((i) => domains[i]), searchBudget);
            if (!result2)
              return null;
            component.forEach((index, i) => {
              combined[index] = result2[i];
            });
          }
          return combined;
        }
        const selected = domains.map(() => void 0);
        const visit = (remaining) => {
          if (--searchBudget < 0)
            return null;
          let next = -1;
          for (let i = 0; i < remaining.length; i++) {
            if (selected[i])
              continue;
            if (!remaining[i].length)
              return null;
            if (next < 0 || remaining[i].length < remaining[next].length)
              next = i;
          }
          if (next < 0)
            return selected;
          for (const candidate of remaining[next]) {
            selected[next] = candidate;
            const filtered = remaining.map((domain, i) => selected[i] ? domain : domain.filter((other) => !this.collides(candidate, other)));
            const result2 = visit(filtered);
            if (result2)
              return result2.slice();
            selected[next] = void 0;
            if (searchBudget < 0)
              break;
          }
          return null;
        };
        return visit(domains.map((domain) => [...domain].sort((a, b) => a.length - b.length)));
      }
      pruneConflicts() {
        const active = new Set([...this.pools.values()].flat().map((candidate) => candidate.id));
        for (const pool2 of this.pools.values())
          for (const candidate of pool2)
            for (const other of candidate.conflicts.keys())
              if (!active.has(other))
                candidate.conflicts.delete(other);
        this.additions = 0;
      }
      select(units, matchingGroups = []) {
        const key = JSON.stringify([units, matchingGroups]);
        if (this.selection?.revision === this.revision && this.selection.key === key)
          return this.selection.result?.slice() ?? null;
        const result2 = this.computeSelection(units, matchingGroups);
        this.selection = { revision: this.revision, key, result: result2 };
        return result2?.slice() ?? null;
      }
      computeSelection(units, matchingGroups) {
        if (this.additions >= 100)
          this.pruneConflicts();
        let domains = units.map((unit) => this.pools.get(unit) ?? []);
        let best = this.compatible(domains);
        if (!best)
          return null;
        const peak = (candidate) => candidate.peak;
        for (const group of [units, ...matchingGroups]) {
          const indices = new Set(group.map((name) => units.indexOf(name)).filter((i) => i >= 0));
          if (!indices.size)
            continue;
          let ceiling = Math.max(...best.filter((_, i) => indices.has(i)).map(peak));
          const levels = [
            ...new Set(domains.flatMap((domain, i) => indices.has(i) ? domain.map(peak) : []))
          ].filter((n) => n < ceiling).sort((a, b) => a - b);
          let lo = 0, hi = levels.length - 1;
          while (lo <= hi) {
            const mid = lo + hi >> 1;
            const choice = this.compatible(domains.map((domain, i) => indices.has(i) ? domain.filter((c) => peak(c) <= levels[mid]) : domain));
            if (choice) {
              best = choice;
              ceiling = levels[mid];
              hi = mid - 1;
            } else
              lo = mid + 1;
          }
          domains = domains.map((domain, i) => indices.has(i) ? domain.filter((c) => peak(c) <= ceiling) : domain);
        }
        return best.flatMap((c) => c.traces);
      }
    };
    exports2.RouteCandidatePool = RouteCandidatePool;
  }
});

// qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/private-selection-primitives.ts.cjs
var require_private_selection_primitives_ts = __commonJS({
  "qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/private-selection-primitives.ts.cjs"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.installPrivateSelectionPrimitives = installPrivateSelectionPrimitives;
    function installPrivateSelectionPrimitives(prototype, clock, publish) {
      const descriptor = Object.getOwnPropertyDescriptor(prototype, "computeSelection");
      if (!descriptor || !("value" in descriptor) || typeof descriptor.value !== "function" || descriptor.get !== void 0 || descriptor.set !== void 0 || descriptor.configurable !== true || descriptor.writable !== true || descriptor.enumerable !== false)
        throw Error("Expected original own configurable writable computeSelection method");
      const original = descriptor.value;
      const rows2 = [];
      let calls = 0, entered = 0, returned = 0, threw = 0, observationErrors = 0;
      let overflows = 0, restored = false;
      const record = (n, p) => {
        try {
          const t = clock();
          if (!Number.isFinite(t) || t < 0) {
            observationErrors++;
            return;
          }
          const rounded = Math.round(t * 1e3) / 1e3;
          if (!Number.isFinite(rounded) || rounded < 0) {
            observationErrors++;
            return;
          }
          const row = JSON.stringify({ n, p, t: rounded }) + "\n";
          if (row.length > 128) {
            overflows++;
            return;
          }
          rows2.push(row);
          if (rows2.length > 16)
            rows2.shift();
          publish(row, rows2.join(""));
        } catch {
          observationErrors++;
        }
      };
      function observed(...args) {
        if (calls >= Number.MAX_SAFE_INTEGER) {
          overflows++;
          return Reflect.apply(original, this, args);
        }
        const n = ++calls;
        entered++;
        record(n, 0);
        let result2;
        try {
          result2 = Reflect.apply(original, this, args);
        } catch (error) {
          threw++;
          record(n, 2);
          throw error;
        }
        returned++;
        record(n, 1);
        return result2;
      }
      Object.defineProperty(prototype, "computeSelection", { ...descriptor, value: observed });
      return {
        snapshot: () => ({
          calls,
          entered,
          returned,
          threw,
          observationErrors,
          overflows,
          retainedRows: rows2.length,
          retainedGeometry: false,
          additionalOriginalCalls: 0
        }),
        restore: () => {
          if (restored)
            return true;
          const current = Object.getOwnPropertyDescriptor(prototype, "computeSelection");
          if (current?.value !== observed) {
            observationErrors++;
            return false;
          }
          Object.defineProperty(prototype, "computeSelection", descriptor);
          restored = true;
          return true;
        }
      };
    }
  }
});

// qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/private-selection-origin-controls.ts.cjs
var __importDefault = exports && exports.__importDefault || function(mod) {
  return mod && mod.__esModule ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var strict_1 = __importDefault(require("node:assert/strict"));
var node_fs_1 = __importDefault(require("node:fs"));
var node_path_1 = __importDefault(require("node:path"));
var select_route_candidates_1 = require_select_route_candidates_ts();
var select_route_candidates_ts_1 = require_select_route_candidates_ts();
var private_selection_primitives_1 = require_private_selection_primitives_ts();
strict_1.default.equal(process.env.G350_PRIVATE_CLASS_ORIGIN_APPROVED, "1");
strict_1.default.deepEqual(process.argv.slice(2), ["--run-one-approved"]);
strict_1.default.equal(process.version, "v25.6.1");
strict_1.default.deepEqual(process.execArgv, []);
strict_1.default.equal(select_route_candidates_1.RouteCandidatePool, select_route_candidates_ts_1.RouteCandidatePool);
strict_1.default.equal(select_route_candidates_1.RouteCandidatePool.prototype, select_route_candidates_ts_1.RouteCandidatePool.prototype);
var before = Object.getOwnPropertyDescriptor(select_route_candidates_1.RouteCandidatePool.prototype, "computeSelection");
strict_1.default.equal(before.enumerable, false);
strict_1.default.equal(before.writable, true);
strict_1.default.equal(before.configurable, true);
var rows = [];
var observer = (0, private_selection_primitives_1.installPrivateSelectionPrimitives)(select_route_candidates_1.RouteCandidatePool.prototype, () => 1, (row, rolling) => {
  strict_1.default.ok(Buffer.byteLength(row) <= 128 && Buffer.byteLength(rolling) <= 2048);
  rows.push(row);
});
var pool = new select_route_candidates_ts_1.RouteCandidatePool(0.1524);
strict_1.default.equal(pool.select(["origin-only-missing-domain"]), null);
strict_1.default.equal(observer.snapshot().calls, 1);
strict_1.default.equal(pool.select(["origin-only-missing-domain"]), null);
strict_1.default.equal(observer.snapshot().calls, 1);
strict_1.default.equal(observer.snapshot().observationErrors, 0);
strict_1.default.equal(observer.restore(), true);
strict_1.default.deepEqual(Object.getOwnPropertyDescriptor(select_route_candidates_1.RouteCandidatePool.prototype, "computeSelection"), before);
strict_1.default.deepEqual(rows.map((row) => JSON.parse(row).p), [0, 1]);
var result = { passed: true, engine: process.version, classConstructorAndPrototypeIdentity: true, actualCopiedPrivateClassReachedByOriginalSelectExactlyOnce: true, cachedSelectAddsNoComputeCall: true, exactDescriptorRestored: true, publicBundleSourceOriginParityStillCheckedByController: true, noGridNoNativeChecker: true, actualBoardRoutingPerformed: false, accepted49: false, fabricationReady: false };
node_fs_1.default.writeFileSync(node_path_1.default.join(process.env.G350_PRIVATE_CLASS_ORIGIN_DIRECTORY, "class-origin-result.json"), JSON.stringify(result, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(result));
