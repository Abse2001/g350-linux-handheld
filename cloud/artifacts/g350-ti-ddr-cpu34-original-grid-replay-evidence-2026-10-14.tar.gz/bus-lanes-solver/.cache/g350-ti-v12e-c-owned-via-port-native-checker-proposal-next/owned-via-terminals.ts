import assert from "node:assert/strict"
import type { SimpleRouteJson, SimplifiedPcbTrace } from "@tscircuit/capacity-autorouter"
import { buildNativeReferenceRegistry, type CoreRecord } from "../g350-ti-v12e-c-clock-native-port-corrective-sourceonly-next/reference-registry"

export interface OwnedViaTerminalRegistry { readonly entryCount: number }
type ViaPoint = Extract<SimplifiedPcbTrace["route"][number], { route_type: "via" }>
type Endpoint = { connectionName: string; point: SimpleRouteJson["connections"][number]["pointsToConnect"][number] }
type Descriptor = { owner: string; source: string; net: string; traceId: string; viaId: string; portId: string;
  x: number; y: number; layer: string; layers: string[]; outer: number; hole: number; from: string; to: string }
const authenticRegistries = new WeakMap<OwnedViaTerminalRegistry, readonly Descriptor[]>()
const sameXY = (a: CoreRecord, b: CoreRecord) => a.x === b.x && a.y === b.y
const sameLayers = (a: unknown, b: readonly string[]) => Array.isArray(a) && a.length === b.length
  && a.every((layer, index) => layer === b[index])
const meta = (record: unknown, key: string): any => (record as CoreRecord)?.[key] ?? {}
const key = (connection: SimpleRouteJson["connections"][number]) => connection.netConnectionName ?? connection.rootConnectionName ?? connection.name

/** The token cannot be authored by supplying arbitrary descriptors. The factory
 * derives its two entries from verified native Core/source-reference ownership. */
export function createOwnedViaTerminalRegistry(core: CoreRecord[], input: SimpleRouteJson): OwnedViaTerminalRegistry {
  const proof = buildNativeReferenceRegistry(core, input as unknown as Parameters<typeof buildNativeReferenceRegistry>[1])
  assert.equal(proof.entries.length, 2)
  const descriptors = proof.entries.map(entry => {
    assert.equal(core.filter(row => row.type === "pcb_via" && row.pcb_via_id === entry.viaId).length, 1)
    assert.equal(core.filter(row => row.type === "pcb_smtpad" && row.pcb_port_id === entry.viaPortId).length, 0)
    const otherPorts = core.filter(row => row.type === "pcb_port" && sameXY(row, entry.via)
      && !entry.via.pcb_port_ids.includes(row.pcb_port_id))
    assert.equal(otherPorts.length, 0, "Owned via terminal cannot conceal a coincident foreign or SMT port")
    return Object.freeze({ owner: entry.connectionName, source: entry.sourceTraceId, net: entry.sourceNetId,
      traceId: entry.pcbTraceId, viaId: entry.viaId, portId: entry.viaPortId,
      x: entry.via.x, y: entry.via.y, layer: entry.viaPort.layers[0], layers: Object.freeze([...entry.via.layers]) as unknown as string[],
      outer: entry.via.outer_diameter, hole: entry.via.hole_diameter, from: entry.via.from_layer, to: entry.via.to_layer })
  })
  const token = Object.freeze({ entryCount: descriptors.length })
  authenticRegistries.set(token, Object.freeze(descriptors))
  return token
}

export function isRegisteredOwnedViaEndpoint(params: {
  registry?: OwnedViaTerminalRegistry; inputSrj: SimpleRouteJson; routedSrj: SimpleRouteJson;
  trace: SimplifiedPcbTrace; viaPoint: ViaPoint; endpoints: Endpoint[]
}): boolean {
  const entries = params.registry && authenticRegistries.get(params.registry)
  if (!entries) return false
  const { inputSrj, routedSrj, trace, viaPoint, endpoints } = params
  if (inputSrj.layerCount !== 4 || routedSrj.layerCount !== 4) return false
  const id = meta(viaPoint, "circuitJsonMetadata").pcb_via_id
  const matches = entries.filter(entry => entry.viaId === id)
  if (matches.length !== 1) return false
  const d = matches[0]!
  if (trace.connection_name !== d.owner || meta(trace, "source_trace_id") !== d.source || trace.pcb_trace_id !== d.traceId
    || meta(trace, "physicalContextMetadata").source_net_id !== d.net
    || meta(trace, "physicalContextMetadata").pcb_via_id !== d.viaId
    || !sameXY(viaPoint, d) || viaPoint.via_diameter !== d.outer || viaPoint.via_hole_diameter !== d.hole
    || !sameLayers(meta(viaPoint, "layers"), d.layers) || viaPoint.from_layer !== d.from || viaPoint.to_layer !== d.to) return false
  const physical = (routedSrj.traces ?? []).flatMap(row => row.route.filter(point => point.route_type === "via")
    .map(point => ({ trace: row, point })))
    .filter(({ point }) => sameXY(point, d) || meta(point, "circuitJsonMetadata").pcb_via_id === d.viaId)
  if (physical.length !== 1 || physical[0]!.trace !== trace || physical[0]!.point !== viaPoint) return false
  // Every coincident endpoint is checked. A first matching owned endpoint must
  // never conceal an unrelated SMT port, a foreign owner or an unknown port.
  const coincident = endpoints.filter(({ point }) => Math.hypot(point.x - viaPoint.x, point.y - viaPoint.y) <= 1e-6)
  if (!coincident.length) return false
  for (const endpoint of coincident) {
    const point = endpoint.point
    const pointLayer = "layer" in point ? point.layer : undefined
    const pointLayers = "layers" in point ? point.layers : undefined
    if (endpoint.connectionName !== d.owner || !sameXY(point, d) || pointLayer !== d.layer
      || (point.pcb_port_id ?? point.pointId) !== d.portId
      || (point.pcb_port_id !== undefined && point.pcb_port_id !== d.portId)
      || (point.pointId !== undefined && point.pointId !== d.portId)
      || (pointLayers !== undefined && !sameLayers(pointLayers, [d.layer]))) return false
    for (const srj of [inputSrj, routedSrj]) {
      const owners = srj.connections.filter(connection => connection.name === endpoint.connectionName)
      if (owners.length !== 1 || key(owners[0]!) !== d.owner
        || meta(owners[0], "source_trace_id") !== d.source) return false
    }
  }
  return true
}
