# Cap12 +0.79 editable Source replay (Source-only handoff)

The only authorized hardware change is C_DDR_RAM_12 Bottom rotation180, center(6,4.7) to (6.79,4.7); its two typed pads/ports translate +0.79 X, and its exact two .2 Bottom references reroute through the declared 45-degree middle points. All other 279 real part placements, 1163 lands, 163 references and all 129 reference vias remain held. No authored helper has been executed by its Source author.

Passed routing candidate to bind: `/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json`, SHA `cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720`. It has 48 routed owners; source_trace_26 / DDR_D12 remains pending. Its actual Root worker was v4 SHA `c59dc40e2698664a55e43d809905521df4bc54113516556473ab123ace3cf930`. Critical companion API qualification is separate. No fresh Source/Core/native/CAD/fabrication qualification is inherited.

Frozen new Source files:

- Hardware helper `/tmp/g350-cap12point79-hardware-delta-v2-sourceonly.ts`, SHA `f78c28a11b973e524ecac17867589186ad1fff0ff901cf993fec88d3a58fabef`.
- Projector `/tmp/g350-cap12point79-partial-projector-v2-sourceonly.ts`, SHA `1d448e11101bdb3dcfaaf72027adcf5f1ea20fa431a0a0a0a3034d8bbcc0f4cb`.
- React overlay `/tmp/g350-cap12point79-partial-replay-overlay-sourceonly.ts`, SHA `5022522eadef74bcb2fcb0c3c603339d7f9a18d6fa3bdc3c2754fcde7226d4b2`.
- Capture/Core wrapper `/tmp/g350-cap12point79-partial-capture-core-v2-sourceonly.ts`, SHA `0eea72375bdc45680f5b0835214d1c22cff351bb2283063b4b68a6b9b56d8694`.

The helper requires the exact original captured typed bijection: 280 actual source_component owners plus 230 actual source_manually_placed_via owners biject to all 510 captured pcb_component rows. Fresh Core PCB count is 280 plus actual physical vias. Captured row IDs are mapping provenance only; the fresh Core supplies actual new IDs.

Root runs the following commands only under its execution guard. Substitute separate new output paths and the actual plan/capture hashes produced by preceding stages. Use the released165 projection input below, rather than the routing candidate as --input; the hardware helper derives only the explicit two-reference/two-pad changes.

```sh
bun /tmp/g350-cap12point79-partial-projector-v2-sourceonly.ts \
  --caller-intent ROOT_AUTHORIZED_PROJECT_COMPACT_PARTIAL_MIXED_JOINED_V2 \
  --input /tmp/g350-all49-fresh-root-20261016-input92/input.json \
  --candidate /tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json \
  --candidate-sha cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720 \
  --contacts /tmp/g350-all49-fresh-root-20261016-input92/contacts.json \
  --proof /tmp/g350-all49-fresh-root-20261016-input92/proof.json \
  --proposal /tmp/g350-source33b-exact-roster-types-retry-after86-sourceonly-next/source33b-proposal.json \
  --raw-core /tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json \
  --raw-core-sha d2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607 \
  --namespace V_CAP12_243 \
  --output NEW_PLAN.json

bun /tmp/g350-cap12point79-partial-capture-core-v2-sourceonly.ts \
  --caller-intent ROOT_AUTHORIZED_PARTIAL_MIXED_EDITABLE_REPLAY \
  --stage capture \
  --plan NEW_PLAN.json --plan-sha ACTUAL_PLAN_SHA \
  --candidate-sha cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720 \
  --overlay /tmp/g350-cap12point79-partial-replay-overlay-sourceonly.ts \
  --output NEW_CAPTURE.json

bun /tmp/g350-cap12point79-partial-capture-core-v2-sourceonly.ts \
  --caller-intent ROOT_AUTHORIZED_PARTIAL_MIXED_EDITABLE_REPLAY \
  --stage core \
  --plan NEW_PLAN.json --plan-sha ACTUAL_PLAN_SHA \
  --candidate-sha cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720 \
  --overlay /tmp/g350-cap12point79-partial-replay-overlay-sourceonly.ts \
  --capture NEW_CAPTURE.json --capture-sha ACTUAL_CAPTURE_SHA \
  --raw-output NEW_RAW.json --output NEW_CONTROLS.json
```

The reference interior XY frame is the held CPU component origin(0,20), selected by U_SOC.pin7, not the cap's rotated component origin and not the CPU numeric-pad center. The overlay recreates exactly the three changed intrinsic literals and retains the full presence-aware route, hardware and React-key inverse.

All49 original numeric logical traces, original four-layer rules, pending material and variable-N real via/inner-port inventory remain explicit. This partial replay never sets all49Accepted, electricalTimingQualified, referenceQualified or fabricationReady true. Fresh Core fidelity, native checks, critical coupling and literal-pour checks remain independent actual executions.
