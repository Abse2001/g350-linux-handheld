import { strict as assert } from "node:assert"
import { isDeepStrictEqual } from "node:util"
import type { SimpleRouteJson } from "./source/lib/types"

export interface OriginalCapture {
  jobId: number
  arguments: unknown[]
  terminalMethod: string | null
  result: unknown
}

/** Cooperative completion order is not pair order. Explicit original first-job
 * identity and full source pair declaration must agree before association. */
export function orderCapturesByOriginalJobIdentity(
  allocation: SimpleRouteJson,
  captures: OriginalCapture[],
) {
  const pairs = allocation.differentialPairs ?? []
  assert.equal(
    captures.length,
    pairs.length,
    "Complete original first-job inventory required",
  )
  const byId = new Map<number, OriginalCapture>()
  for (const capture of captures) {
    assert.ok(
      Number.isInteger(capture.jobId) &&
        capture.jobId >= 1 &&
        capture.jobId <= pairs.length,
      "Original jobId out of range",
    )
    assert.ok(!byId.has(capture.jobId), "Duplicate original jobId")
    assert.ok(
      Array.isArray(capture.arguments) &&
        isDeepStrictEqual(capture.arguments[1], pairs[capture.jobId - 1]),
      "Original jobId/pair declaration identity differs",
    )
    byId.set(capture.jobId, capture)
  }
  return pairs.map((_, index) => {
    const capture = byId.get(index + 1)
    assert.ok(capture, "Missing original first job")
    return capture
  })
}
