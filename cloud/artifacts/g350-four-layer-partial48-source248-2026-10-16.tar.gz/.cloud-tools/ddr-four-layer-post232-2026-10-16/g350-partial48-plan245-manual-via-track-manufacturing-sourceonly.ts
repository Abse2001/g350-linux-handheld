/** SOURCE ONLY; author did not execute/import this module or geometry code.
 * Optional Root-run diagnostic for explicitly pinned fresh M48 Circuit JSON.
 * Exact scope: cap12 +X.79, 48 connected owners, pending26, 229 fullspan vias.
 * Logical UF
 * contains ONLY SourceTrace declarations. Copper/aliases never union nets.
 * A same-net exemption is foreign-clearance bookkeeping, not own-route proof.
 */
import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
type Row=Record<string,any>
const LAYERS=['top','inner1','inner2','bottom'],COORD_EPS=1e-8,MANUFACTURING_EPS=1e-6,REQUIRED=.1016
const PENDING=['source_trace_26'],ORIGINAL49=Array.from({length:49},(_,i)=>'source_trace_'+i)
const PLAN='/tmp/g350-cap12-48-projector-root-20261016-run245/byte0-result.json'
const PLAN_SHA='f57834ed51009d0a88df6a70beb6ea188284bae978516d8f389e254295425d64'
const CANDIDATE='/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json'
const CANDIDATE_SHA='cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
const CAP_PROFILE='CAP12_TRANSLATE_X_0P79_ONLY',CAP_WORKER_SHA='c59dc40e2698664a55e43d809905521df4bc54113516556473ab123ace3cf930'
const HISTORICAL={native185:{path:'/tmp/g350-native45-root-20261016-run185/byte0-result.json',sha256:'fd4517b48526b1cddb77de5227646d195c5786f09db2dcb2c3477d4e16912c88'},viaOwner186:{path:'/tmp/g350-via-track45-root-20261016-run186/byte0-result.json',sha256:'d934351cbda92b92ba3554ad1c318c0130db1bc44d612bc26df3ac82b9f85b24'},historicalOnly:true,currentQualificationInherited:false}
const insist=(v:unknown,m:string):asserts v=>{if(!v)throw Error(m)}
const sha=(b:string|Uint8Array)=>createHash('sha256').update(b).digest('hex')
const near=(a:Row,b:Row)=>!!a&&!!b&&Number.isFinite(a.x)&&Number.isFinite(a.y)&&Number.isFinite(b.x)&&Number.isFinite(b.y)&&Math.hypot(a.x-b.x,a.y-b.y)<=COORD_EPS
const sameSet=(a:string[],b:string[])=>a.length===b.length&&new Set(a).size===a.length&&a.every(v=>b.includes(v))
const canonical=(v:any):string=>Array.isArray(v)?'['+v.map(canonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v)??'undefined'
const same=(a:any,b:any)=>canonical(a)===canonical(b)
function index(rows:Row[],field:string):Map<string,Row>{const m=new Map<string,Row>();for(const r of rows){insist(typeof r[field]==='string'&&!m.has(r[field]),'Unique actual '+field);m.set(r[field],r)}return m}
class SourceUf {
 private parents=new Map<string,string>()
 has(id:string){return this.parents.has(id)}
 add(id:string){if(!this.parents.has(id))this.parents.set(id,id)}
 root(id:string):string{const p=this.parents.get(id);insist(p!==undefined,'Unknown declared logical ID '+id);if(p!==id){const r=this.root(p);this.parents.set(id,r);return r}return p}
 union(a:string,b:string){this.add(a);this.add(b);const x=this.root(a),y=this.root(b);if(x!==y)this.parents.set(y,x)}
}
export async function runManualViaTrackManufacturing(options:{rawPath:string;rawSha256:string;controlsPath:string;controlsSha256:string;output:string;budgetMs?:number}){
 const started=performance.now(),budgetMs=options.budgetMs??165000
 insist(Number.isInteger(budgetMs)&&budgetMs>=1000&&budgetMs<=165000,'Finite1000..165000ms budget')
 insist(typeof options.rawPath==='string'&&typeof options.controlsPath==='string'&&typeof options.output==='string'
  &&/^[0-9a-f]{64}$/.test(options.rawSha256)&&/^[0-9a-f]{64}$/.test(options.controlsSha256),'Mandatory explicit raw/control paths and lowercase64hex Root pins')
 const rawPath=path.resolve(options.rawPath),controlsPath=path.resolve(options.controlsPath),out=path.resolve(options.output)
 const RAW_SHA=options.rawSha256,CONTROLS_SHA=options.controlsSha256
 insist(rawPath!==controlsPath&&![rawPath,controlsPath].includes(out)&&!fs.existsSync(out),'Fresh separate output and distinct input files required')
 const rawBytes=fs.readFileSync(rawPath),controlBytes=fs.readFileSync(controlsPath)
 insist(sha(rawBytes)===RAW_SHA&&sha(controlBytes)===CONTROLS_SHA,'Exact explicit fresh M48 raw/controls pins required')
 const raw:Row[]=JSON.parse(rawBytes.toString()),controls:Row=JSON.parse(controlBytes.toString())
 const planBytes=fs.readFileSync(PLAN);insist(sha(planBytes)===PLAN_SHA,'Exact reviewed cap12 Source48 PLAN245 required')
 const plan:Row=JSON.parse(planBytes.toString())
 insist(plan.inputBindings?.candidate?.sha256===CANDIDATE_SHA&&plan.inputBindings.candidate.path===CANDIDATE,
  'PLAN245 must bind exact cap12 candidate243; Source233 geometry cannot substitute')
 const cap=plan.cap12HardwareDelta
 insist(plan.hardwareDeltaProfile===CAP_PROFILE&&cap?.profile===CAP_PROFILE
  &&same(cap.candidateBinding,plan.inputBindings.candidate)&&cap.reviewedWorkerSourceSha256===CAP_WORKER_SHA
  &&cap.component?.name==='C_DDR_RAM_12'&&same(cap.component.sourcePlacement,{before:{pcbX:6,pcbY:4.7,layer:'bottom',pcbRotation:180},after:{pcbX:6.79,pcbY:4.7,layer:'bottom',pcbRotation:180}})
  &&Array.isArray(cap.typedSmtPads)&&cap.typedSmtPads.length===2&&Array.isArray(cap.typedPcbPorts)&&cap.typedPcbPorts.length===2
  &&Array.isArray(cap.references)&&cap.references.length===2
  &&same(cap.exactPhysicalScope,{componentCount:280,heldPlacements:279,translatedPlacements:1,totalLands:1165,heldLands:1163,translatedSmtPadsAndPorts:2,totalReferences:165,heldReferences:163,reroutedReferences:2,heldReferenceVias:129}),
  'Exact cap12 +X.79 typed two-pad/port/two-reference delta and literal held hardware scope required')
 insist(Array.isArray(plan.newVias)&&Array.isArray(plan.innerPortRegistrations)&&Array.isArray(plan.auxiliaryLocalTraces)&&Array.isArray(plan.projectedGeometry),
  'Actual plan-derived physical inventory arrays required')
 const N=plan.newVias.length,I=plan.innerPortRegistrations.length,A=plan.auxiliaryLocalTraces.length,R=plan.projectedGeometry.reduce((n:number,g:Row)=>{insist(Array.isArray(g.wireRuns),'Actual projected wire-run arrays required');return n+g.wireRuns.length},0)
 const PHYSICAL_VIAS=129+N,PHYSICAL_TRACES=165+R+A
 insist(N===100&&I===80&&A===2&&R===146&&PHYSICAL_VIAS===229&&PHYSICAL_TRACES===313
  &&plan.projectedGeometry.length===48
  &&sameSet(plan.pendingOwnerIds,PENDING)&&sameSet(plan.routedOwnerIds,ORIGINAL49.filter(id=>!PENDING.includes(id)))
  &&plan.dynamicCounts?.routedOwners===48&&plan.dynamicCounts.pendingOwners===1
  &&plan.dynamicCounts.newViaEvents===N&&plan.dynamicCounts.newInnerRegistrations===I
  &&plan.dynamicCounts.expectedPcbVias===PHYSICAL_VIAS&&plan.dynamicCounts.expectedSourceVias===PHYSICAL_VIAS
  &&plan.dynamicCounts.expectedPhysicalTraces===PHYSICAL_TRACES&&plan.dynamicCounts.routedWireRuns===R
  &&plan.dynamicCounts.auxiliarySourceTraces===A&&plan.dynamicCounts.expectedPcbComponents===409+N
  &&plan.dynamicCounts.expectedSourcePorts===1419+2*N+I&&plan.dynamicCounts.expectedSourceTraces===1097+A
  &&plan.dynamicCounts.expectedReactElements===2036+N+I+A,
  'Exact PLAN245 actual N100/I80/routed146/aux2/physical313 and real48/1 rosters required')
 insist(Array.isArray(raw)&&controls.rawCoreSha256===RAW_SHA&&controls.partialCoreControlPassed===true
  &&controls.partialDiagnosticReplayControlsPassed===true&&Array.isArray(controls.checks)&&controls.checks.length===35&&controls.checks.every((r:Row)=>r.passed===true)
  &&controls.expectedConnectedOwners===48&&controls.expectedPendingOwners===1
  &&controls.planSha256===PLAN_SHA&&controls.candidateSha256===CANDIDATE_SHA
  &&controls.cap12HardwareDeltaProfile===CAP_PROFILE&&same(controls.cap12HardwareDelta,cap)
  &&controls.expectedCounts?.newVias===N&&controls.expectedCounts?.physicalVias===PHYSICAL_VIAS
  &&controls.expectedCounts?.newInnerPorts===I&&controls.expectedCounts?.auxiliaryLocalTraces===A
  &&controls.expectedCounts?.routedWireRuns===R&&controls.expectedCounts?.physicalTraces===PHYSICAL_TRACES
  &&controls.expectedCounts?.pcbComponents===409+N&&controls.expectedCounts?.sourceAndPcbPorts===1419+2*N+I
  &&controls.expectedCounts?.sourceTraces===1097+A&&controls.expectedCounts?.reactElements===2036+N+I+A,
  'All35 passed fresh M48 replay controls bound to PLAN245/candidate243/exact cap12 delta and derived inventory required')
 insist(Array.isArray(controls.pendingOwnerIds)&&sameSet(controls.pendingOwnerIds,PENDING)
  &&Array.isArray(controls.routedOwnerIds)&&sameSet(controls.routedOwnerIds,ORIGINAL49.filter(id=>!PENDING.includes(id)))
  &&Array.isArray(controls.logical49Projection)&&sameSet(controls.logical49Projection.map((r:Row)=>r.originalSourceTraceId),ORIGINAL49)
  &&controls.logical49Projection.every((r:Row)=>r.passed===true),'Exact original49 logical projection and routed48/pending26 rosters required')
 insist(Array.isArray(controls.physicalGraphs)&&sameSet(controls.physicalGraphs.map((r:Row)=>r.originalSourceTraceId),ORIGINAL49)
  &&controls.physicalGraphs.every((r:Row)=>r.physicallyConnectedByActualOwnedNumericIdGraph===!PENDING.includes(r.originalSourceTraceId)),
  'All49 actual owned numeric-ID graphs must prove exactly48 connected and the named1 disconnected')
 const rows=(type:string)=>raw.filter(r=>r.type===type)
 const sourceTraces=index(rows('source_trace'),'source_trace_id'),sourcePorts=index(rows('source_port'),'source_port_id'),sourceNets=index(rows('source_net'),'source_net_id')
 const pcbTraces=index(rows('pcb_trace'),'pcb_trace_id'),pcbPorts=index(rows('pcb_port'),'pcb_port_id'),pcbComponents=index(rows('pcb_component'),'pcb_component_id')
 const manualSources=index(rows('source_manually_placed_via'),'source_manually_placed_via_id'),vias=rows('pcb_via')
 insist(vias.length===PHYSICAL_VIAS&&new Set(vias.map(v=>v.pcb_via_id)).size===PHYSICAL_VIAS,'Exact229 actual physical vias for M48 scope')
 const uf=new SourceUf(),declaredNets=new Set<string>(),logicalDeclarations:Row[]=[]
 for(const [id,t]of sourceTraces){
  uf.add(id)
  const ports=t.connected_source_port_ids??[],nets=t.connected_source_net_ids??[]
  insist(Array.isArray(ports)&&Array.isArray(nets),'Actual SourceTrace declaration arrays')
  for(const port of ports){insist(sourcePorts.has(port),'SourceTrace references nonexistent SourcePort');uf.union(id,port)}
  for(const net of nets){insist(sourceNets.has(net),'SourceTrace references nonexistent SourceNet');declaredNets.add(net);uf.union(id,net)}
  logicalDeclarations.push({sourceTraceId:id,connectedSourcePortIds:[...ports],connectedSourceNetIds:[...nets]})
 }
 const aliasUse=new Map<string,string[]>(),manualUse=new Map<string,string[]>(),componentUse=new Map<string,string[]>()
 for(const via of vias)for(const id of via.pcb_port_ids??[]){const list=aliasUse.get(id)??[];list.push(via.pcb_via_id);aliasUse.set(id,list)}
 const identityRows=vias.map(via=>{
  const errors:string[]=[],aliases:Row[]=[],ids=via.pcb_port_ids
  if(!Array.isArray(ids)||ids.length<2||new Set(ids).size!==ids.length)errors.push('Missing/duplicate actual via alias IDs')
  if(!Number.isFinite(via.outer_diameter)||Math.abs(via.outer_diameter-.4572)>COORD_EPS||!Number.isFinite(via.hole_diameter)||Math.abs(via.hole_diameter-.254)>COORD_EPS
   ||!Array.isArray(via.layers)||!sameSet(via.layers,LAYERS)||via.from_layer!=='top'||via.to_layer!=='bottom')errors.push('Unsupported actual through-via dimensions/span')
  for(const id of Array.isArray(ids)?ids:[]){
   const pp=pcbPorts.get(id),sp=pp?sourcePorts.get(pp.source_port_id):undefined,pc=pp?pcbComponents.get(pp.pcb_component_id):undefined,manual=sp?manualSources.get(sp.source_component_id):undefined
   const layer=pp?.layers?.length===1?pp.layers[0]:null
   const passed=!!pp&&!!sp&&!!pc&&!!manual&&near(pp,via)&&near(pc.center,via)
    &&pc.source_component_id===sp.source_component_id&&pc.layer==='top'&&pc.rotation===0
    &&Math.abs(pc.width-via.outer_diameter)<=COORD_EPS&&Math.abs(pc.height-via.outer_diameter)<=COORD_EPS
    &&LAYERS.includes(layer)&&sp.name===layer&&via.layers.includes(layer)&&aliasUse.get(id)?.length===1
   if(!passed)errors.push('Unauthenticated actual alias '+id)
   aliases.push({pcbPortId:id,sourcePortId:sp?.source_port_id??null,pcbComponentId:pc?.pcb_component_id??null,
    sourceManuallyPlacedViaId:manual?.source_manually_placed_via_id??null,layer,xy:pp?{x:pp.x,y:pp.y}:null,passed})
  }
  const manualIds=[...new Set(aliases.map(a=>a.sourceManuallyPlacedViaId).filter(Boolean))],componentIds=[...new Set(aliases.map(a=>a.pcbComponentId).filter(Boolean))]
  if(manualIds.length!==1||componentIds.length!==1||aliases.some(a=>a.sourceManuallyPlacedViaId!==manualIds[0]||a.pcbComponentId!==componentIds[0]))errors.push('Via aliases do not identify one exact manual Source and PCB component')
  const aliasLayers=aliases.map(a=>a.layer)
  if(!aliasLayers.includes('top')||!aliasLayers.includes('bottom')||new Set(aliasLayers).size!==aliasLayers.length)errors.push('Alias layer roster must contain unique real Top/Bottom and optional real inner ports')
  const manualId=manualIds.length===1?manualIds[0]:null,componentId=componentIds.length===1?componentIds[0]:null
  if(manualId){const list=manualUse.get(manualId)??[];list.push(via.pcb_via_id);manualUse.set(manualId,list)}
  if(componentId){const list=componentUse.get(componentId)??[];list.push(via.pcb_via_id);componentUse.set(componentId,list)}
  return{pcbViaId:via.pcb_via_id,via,aliases,manualId,componentId,errors}
 })
 for(const r of identityRows){if(r.manualId&&manualUse.get(r.manualId)!.length!==1)r.errors.push('Manual Source is shared by distinct physical vias');if(r.componentId&&componentUse.get(r.componentId)!.length!==1)r.errors.push('PCB via component is shared by distinct physical vias')}
 const segments:Row[]=[],invalidSegments:Row[]=[],endpointReferences=new Map<string,Row[]>()
 for(const [id,t]of pcbTraces){
  const actualSource=sourceTraces.get(t.source_trace_id),logicalRoot=actualSource?uf.root(actualSource.source_trace_id):null
  for(let i=0;i<t.route.length;i++){
   const p=t.route[i]
   for(const field of ['start_pcb_port_id','end_pcb_port_id'])if(p[field]){const refs=endpointReferences.get(p[field])??[];refs.push({pcbTraceId:id,sourceTraceId:actualSource?.source_trace_id??null,logicalRoot,routeIndex:i,field,point:p});endpointReferences.set(p[field],refs)}
   if(i===0)continue;const a=t.route[i-1],b=p
   if(a.route_type!=='wire'||b.route_type!=='wire'||a.layer!==b.layer)continue
   const span=Math.hypot(b.x-a.x,b.y-a.y),width=Math.max(a.width??NaN,b.width??NaN,a.end_width??0,b.end_width??0)
   if(![a.x,a.y,b.x,b.y,width,span].every(Number.isFinite)||width<=0||!LAYERS.includes(a.layer)){
    invalidSegments.push({pcbTraceId:id,sourceTraceId:t.source_trace_id??null,segmentStartIndex:i-1,segmentEndIndex:i,reason:'Nonfinite/unsupported wire geometry'});continue
   }
   if(span<=1e-8)continue
   segments.push({pcbTraceId:id,sourceTraceId:actualSource?.source_trace_id??null,logicalRoot,segmentStartIndex:i-1,segmentEndIndex:i,layer:a.layer,width,a:{x:a.x,y:a.y},b:{x:b.x,y:b.y}})
  }
 }
 const originalOwners=new Map<string,string>()
 for(const r of controls.logical49Projection??[])originalOwners.set(r.actualSourceTraceId,r.originalSourceTraceId)
 for(const r of controls.auxiliaryWireChecks??[])originalOwners.set(r.actualFreshSourceTraceId,r.pendingOwner)
 const report:Row={scope:'EXPLICITLY_PINNED_M48_PLAN245_CAP12_AUTHENTICATED_229_MANUAL_VIA_TRACK_MANUFACTURING_DIAGNOSTIC',
  inputBindings:{raw:{path:rawPath,sha256:RAW_SHA},controls:{path:controlsPath,sha256:CONTROLS_SHA},plan:{path:PLAN,sha256:PLAN_SHA},candidate:{path:CANDIDATE,sha256:CANDIDATE_SHA}},historicalEvidenceOnly:HISTORICAL,
  cap12HardwareDeltaProfile:CAP_PROFILE,cap12HardwareDelta:cap,
  planDerivedInventory:{newVias:N,newInnerPorts:I,routedWireRuns:R,auxiliaryLocalTraces:A,physicalVias:PHYSICAL_VIAS,physicalTraces:PHYSICAL_TRACES},
  source236GeometryOrPourQualificationInherited:false,source233TimingQualificationInherited:false,
  budgetMs,requiredCopperEdgeClearanceMm:REQUIRED,manufacturingToleranceMm:MANUFACTURING_EPS,coordinateToleranceMm:COORD_EPS,
  logicalUfPolicy:'ONLY SourceTrace connected_source_port_ids and connected_source_net_ids; no PCB/copper/via alias/geometric union',
  declaredLogicalSources:logicalDeclarations,declaredSourceNetCount:declaredNets.size,actualViaCount:vias.length,wireSegmentCount:segments.length,
  viaReports:[],violations:[],ambiguousVias:[],identityFailures:[],invalidSegments,sameNetExemptions:[],
  unresolvedSegmentOwners:segments.filter(s=>s.logicalRoot===null).map(s=>({pcbTraceId:s.pcbTraceId,segmentEndIndex:s.segmentEndIndex})),
  complete:false,executed:false,foreignViaTrackCopperClearancePassed:false,rawInputEdited:false,
  all49Accepted:false,fullBoardPassed:false,electricalTimingQualified:false,fabricationReady:false,
  ownReentryQualified:false,ownShortcutQualified:false,allThroughViaBarrelsManufacturingQualified:false,
  expectedConnectedOwners:48,expectedPendingOwners:1,pendingOwnerIds:[...PENDING],routedOwnerIds:[...controls.routedOwnerIds],
  scopeLimits:['Same-net exemptions do not prove own nonlocal barrel/track reentry or length preservation.',
   'This is via-to-wire copper spacing only; it does not replace via-via, pad, hole, board, native, reference, coupling, or complete-routing checks.']}
 fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n',{flag:'wx'})
 const save=()=>{report.elapsedMs=performance.now()-started;report.completedViaCount=report.viaReports.length;const tmp=out+'.next';fs.writeFileSync(tmp,JSON.stringify(report,null,2)+'\n',{flag:'wx'});fs.renameSync(tmp,out)}
 try{
  for(const identity of identityRows){
   if(performance.now()-started>=budgetMs-500){report.terminalOutcome='BOUNDED_TIME_EXIT_WITH_UNCHECKED_VIAS';break}
   const via=identity.via,evidence:Row[]=[],unresolvedEvidence:Row[]=[],roots=new Set<string>()
   const addSource=(sourceId:string|undefined,kind:string,detail:Row)=>{const source=sourceId?sourceTraces.get(sourceId):undefined;if(!source){unresolvedEvidence.push({kind,...detail,sourceTraceId:sourceId??null});return}const root=uf.root(source.source_trace_id);roots.add(root);evidence.push({kind,...detail,sourceTraceId:source.source_trace_id,originalSourceOwnerForMappingOnly:originalOwners.get(source.source_trace_id)??null,logicalRoot:root})}
   for(const alias of identity.aliases){
    for(const ref of endpointReferences.get(alias.pcbPortId)??[]){const pp=pcbPorts.get(alias.pcbPortId);if(ref.point.route_type!=='wire'||!pp||!near(ref.point,pp)||ref.point.layer!==alias.layer){unresolvedEvidence.push({kind:'INVALID_DECLARED_ALIAS_ENDPOINT_REFERENCE',...ref});continue}addSource(ref.sourceTraceId,'ACTUAL_TRACE_WIRE_PORT_REFERENCE',{pcbPortId:alias.pcbPortId,pcbTraceId:ref.pcbTraceId,routeIndex:ref.routeIndex,field:ref.field})}
    for(const [sid,t]of sourceTraces)if((t.connected_source_port_ids??[]).includes(alias.sourcePortId))addSource(sid,'DIRECT_SOURCE_TRACE_ALIAS_DECLARATION',{pcbPortId:alias.pcbPortId,sourcePortId:alias.sourcePortId})
   }
   if(via.pcb_trace_id){const t=pcbTraces.get(via.pcb_trace_id);addSource(t?.source_trace_id,'EXPLICIT_LEGACY_VIA_PCB_TRACE_ID',{pcbTraceId:via.pcb_trace_id})}
   if(via.source_trace_id)addSource(via.source_trace_id,'EXPLICIT_LEGACY_VIA_SOURCE_TRACE_ID',{})
   if(via.source_net_id){if(sourceNets.has(via.source_net_id)&&declaredNets.has(via.source_net_id)&&uf.has(via.source_net_id)){const root=uf.root(via.source_net_id);roots.add(root);evidence.push({kind:'EXPLICIT_VIA_REAL_SOURCE_NET_DECLARED_BY_SOURCE_TRACE',sourceNetId:via.source_net_id,logicalRoot:root})}else unresolvedEvidence.push({kind:'UNBOUND_EXPLICIT_VIA_SOURCE_NET',sourceNetId:via.source_net_id})}
   const authenticated=identity.errors.length===0,resolved=authenticated&&roots.size===1&&unresolvedEvidence.length===0,root=resolved?[...roots][0]:null
   const row:Row={pcbViaId:identity.pcbViaId,xy:{x:via.x,y:via.y},layers:via.layers,outerDiameter:via.outer_diameter,holeDiameter:via.hole_diameter,
    aliases:identity.aliases,sourceManuallyPlacedViaId:identity.manualId,pcbComponentId:identity.componentId,
    aliasIdentityAuthenticated:authenticated,identityErrors:identity.errors,ownerEvidence:evidence,unresolvedOwnerEvidence:unresolvedEvidence,
    authenticatedLogicalRoots:[...roots].sort(),logicalOwnerResolved:resolved,selectedLogicalRoot:root,
    checkedForeignSegmentCount:0,boundingBoxClearSegmentCount:0,sameNetExemptSegmentCount:0,violationCount:0}
   if(!authenticated)report.identityFailures.push({pcbViaId:identity.pcbViaId,errors:identity.errors})
   if(!resolved)report.ambiguousVias.push({pcbViaId:identity.pcbViaId,authenticated,roots:[...roots].sort(),unresolvedEvidence,identityErrors:identity.errors,reason:roots.size===0?'NO_AUTHENTICATED_LOGICAL_OWNER':roots.size>1?'MULTIPLE_LOGICAL_OWNERS':'IDENTITY_OR_OWNER_EVIDENCE_UNRESOLVED',noSameNetExemptionApplied:true})
   for(const s of segments){
    if(!via.layers?.includes(s.layer))continue
    if(resolved&&s.logicalRoot!==null&&s.logicalRoot===root){row.sameNetExemptSegmentCount++;report.sameNetExemptions.push({pcbViaId:identity.pcbViaId,pcbTraceId:s.pcbTraceId,sourceTraceId:s.sourceTraceId,segmentStartIndex:s.segmentStartIndex,segmentEndIndex:s.segmentEndIndex,layer:s.layer,authenticatedViaLogicalRoot:root,segmentLogicalRoot:s.logicalRoot,foreignCheckOnly:true,ownReentryQualified:false});continue}
    row.checkedForeignSegmentCount++
    const required=via.outer_diameter/2+s.width/2+REQUIRED
    if(!Number.isFinite(required)||required<=0){row.geometryUnresolved=true;continue}
    if(via.x<Math.min(s.a.x,s.b.x)-required||via.x>Math.max(s.a.x,s.b.x)+required||via.y<Math.min(s.a.y,s.b.y)-required||via.y>Math.max(s.a.y,s.b.y)+required){row.boundingBoxClearSegmentCount++;continue}
    const dx=s.b.x-s.a.x,dy=s.b.y-s.a.y,t=Math.max(0,Math.min(1,((via.x-s.a.x)*dx+(via.y-s.a.y)*dy)/(dx*dx+dy*dy))),closest={x:s.a.x+t*dx,y:s.a.y+t*dy}
    const distance=Math.hypot(via.x-closest.x,via.y-closest.y),clearance=distance-via.outer_diameter/2-s.width/2
    if(distance<required-MANUFACTURING_EPS){row.violationCount++;report.violations.push({pcbViaId:identity.pcbViaId,viaXY:{x:via.x,y:via.y},pcbTraceId:s.pcbTraceId,sourceTraceId:s.sourceTraceId,originalSourceOwnerForMappingOnly:originalOwners.get(s.sourceTraceId)??null,
     segmentStartIndex:s.segmentStartIndex,segmentEndIndex:s.segmentEndIndex,segmentLayer:s.layer,segmentWidthMm:s.width,a:s.a,b:s.b,closestPoint:closest,centerDistanceMm:distance,clearanceMm:clearance,requiredClearanceMm:REQUIRED,
     viaLogicalRoots:[...roots].sort(),segmentLogicalRoot:s.logicalRoot,ownershipClass:resolved&&s.logicalRoot!==null?'AUTHENTICATED_DIFFERENT_LOGICAL_NET':'AMBIGUOUS_OWNER_NO_EXEMPTION',manufacturingEpsilonMm:MANUFACTURING_EPS})}
   }
   report.viaReports.push(row);report.executed=true;save()
  }
  report.complete=report.viaReports.length===vias.length
  report.foreignViaTrackCopperClearancePassed=report.complete&&report.violations.length===0&&report.ambiguousVias.length===0&&report.identityFailures.length===0&&invalidSegments.length===0&&report.unresolvedSegmentOwners.length===0&&report.viaReports.every((r:Row)=>!r.geometryUnresolved)
  report.terminalOutcome=report.complete?'ALL229_VIAS_DIAGNOSED_WITH_UNFILTERED_RESULTS':'BOUNDED_TIME_EXIT_WITH_UNCHECKED_VIAS'
 }catch(error:any){report.exception={name:error?.name??'Error',message:String(error?.message??error),stack:error?.stack??null};report.terminalOutcome='EXCEPTION_PARTIAL_RESULTS_NOT_QUALIFIED';report.foreignViaTrackCopperClearancePassed=false}
 try{report.rawFileUnchanged=sha(fs.readFileSync(rawPath))===RAW_SHA;report.controlsFileUnchanged=sha(fs.readFileSync(controlsPath))===CONTROLS_SHA;report.planFileUnchanged=sha(fs.readFileSync(PLAN))===PLAN_SHA}
 catch(error:any){report.rawFileUnchanged=false;report.controlsFileUnchanged=false;report.planFileUnchanged=false;report.inputRehashError=String(error?.message??error)}
 report.exactInputFilesUnchanged=report.rawFileUnchanged===true&&report.controlsFileUnchanged===true&&report.planFileUnchanged===true
 if(!report.exactInputFilesUnchanged){report.foreignViaTrackCopperClearancePassed=false;report.terminalOutcome='INPUT_BINDING_CHANGED_OR_UNAVAILABLE_NO_QUALIFICATION'}
 save();return report
}
async function cli(){
 const args=new Map<string,string>();for(let i=2;i<process.argv.length;i+=2){const k=process.argv[i],v=process.argv[i+1];insist(['--input','--input-sha','--controls','--controls-sha','--output','--budget-ms'].includes(k)&&v&&!args.has(k),'Invalid CLI '+k);args.set(k,v)}
 insist(['--input','--input-sha','--controls','--controls-sha','--output'].every(k=>args.has(k)),'Mandatory --input --input-sha --controls --controls-sha --output')
 const result=await runManualViaTrackManufacturing({rawPath:args.get('--input')!,rawSha256:args.get('--input-sha')!,controlsPath:args.get('--controls')!,controlsSha256:args.get('--controls-sha')!,output:args.get('--output')!,budgetMs:args.has('--budget-ms')?Number(args.get('--budget-ms')):undefined})
 process.stdout.write(JSON.stringify({output:path.resolve(args.get('--output')!),complete:result.complete,completedViaCount:result.completedViaCount,violationCount:result.violations.length,ambiguousViaCount:result.ambiguousVias.length,foreignViaTrackCopperClearancePassed:result.foreignViaTrackCopperClearancePassed,all49Accepted:false})+'\n')
 if(!result.complete||result.exception||!result.exactInputFilesUnchanged)process.exitCode=2
}
if(import.meta.main)await cli()
