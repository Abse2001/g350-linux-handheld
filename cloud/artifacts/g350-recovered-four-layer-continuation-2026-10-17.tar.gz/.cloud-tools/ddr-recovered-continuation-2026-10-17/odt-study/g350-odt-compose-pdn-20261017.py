"""Compose explicit unaccepted geometric inverses; missing source42 is mandatory.
No SDK, application runtime, CAD or source capture execution.
"""
import importlib.util,json,copy,pathlib,hashlib,collections
spec=importlib.util.spec_from_file_location('odt','/tmp/g350-odt-reconstruction-20261017.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
P=pathlib.Path('/workspace/g350-linux-handheld/.cloud-tools/recovery-2026-10-17/pdn32-study/proposal.packet.json');PIN='a2acf37995e31136ee21ed0216905f1cf2be250b051d7b7032244d7a35622168';assert hashlib.sha256(P.read_bytes()).hexdigest()==PIN;d=json.loads(P.read_bytes())
for iv in d['obstacleInverses']:
 assert m.f['obstacles'][iv['index']]==iv['before'];m.f['obstacles'][iv['index']]=copy.deepcopy(iv['after'])
for iv in d['referenceInverses']:
 assert m.f['traces'][iv['index']]==iv['before'];opts=iv['afterOptions'];m.f['traces'][iv['index']]=copy.deepcopy(opts.get('heldBothOptions',opts.get('A')))
fullobj=m.buildobjects();fullRows=[]
for n in [0,18,2,11]:
 t=m.by[f'source_trace_{n}'];fullRows.append(dict(owner=m.owner(t),contacts=m.contacts(t,fullobj),newWireGuidanceContacts=m.newguidance(t,m.contacts(t,fullobj,True))))
obj=m.buildobjects(excluded_bodies=['source_trace_42']);rows=[]
for n,t in m.by.items():
 if n=='source_trace_42':continue
 rows.append(dict(owner=n,contacts=m.contacts(t,obj),newWireGuidanceContacts=m.newguidance(t,m.contacts(t,obj,True))if n in ['source_trace_0','source_trace_18','source_trace_2','source_trace_11']else[]))
changeobj=[]
for n in [0,18,2,11]:changeobj+=m.mats(m.by[f'source_trace_{n}'])
# Reuse full initialized objects to include expanded boxes, filtering exact changed material IDs.
changeids={m.by[f'source_trace_{n}']['pcb_trace_id']for n in[0,18,2,11]};changeobj=[o for o in obj if o['id']in changeids]
reverse=[dict(owner=m.owner(t),id=t['pcb_trace_id'],contacts=m.contacts(t,changeobj))for t in m.f['traces']]
O=pathlib.Path('/workspace/g350-linux-handheld/.cloud-tools/recovery-2026-10-17/odt-study');O.mkdir(exist_ok=True)
rr=json.loads(pathlib.Path('/tmp/g350-odt-reconstruction-20261017-report.json').read_bytes());packet=dict(scope='UNACCEPTED_MODEL328_ODT_0_18_2_11_PDN32_CAP16_REAL49REQUESTS_ONLY48CARRIERS_MISSING42',inputPath=str(m.P),inputSha256=m.PIN,sourcePdnProposalPath=str(P),sourcePdnProposalSha256=PIN,full49FanoutInput=m.f,carrierTraces=[t for n,t in m.by.items()if n!='source_trace_42'],missingCarrierOwners=['source_trace_42'],bodyInverses=rr['bodyInverses'],workingBranchInverses=rr['branchInverses'],requestInverses=rr['requestInverses'],pdnAndComponentInverses=d,source42OldBodyRetiredForConditionalStudy=m.oldby['source_trace_42'],sourceCoreDerived=False,nativeExecuted=False,fabricationReady=False)
fp=O/'conditional.packet.json';fp.write_text(json.dumps(packet,indent=2)+'\n')
report=dict(scope=packet['scope'],inputSha256=m.PIN,pdnProposalSha256=PIN,fullSceneWithOld42StillPresent=fullRows,conditional48No42ReciprocalRows=rows,conditional263ReferencesReverseAgainstChanged4=reverse,conditional48PhysicalPassed=all(not r['contacts']for r in rows),conditionalChanged4NewWireGuidancePassed=all(not r['newWireGuidanceContacts']for r in rows),conditionalFixed263ReversePassed=all(not r['contacts']for r in reverse),missingCarrierOwners=['source_trace_42'],mustNotPromotePartial=True,packetSha256=hashlib.sha256(fp.read_bytes()).hexdigest(),sourceCoreDerived=False,nativeExecuted=False,fabricationReady=False)
fr=O/'conditional.report.json';fr.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(packetPath=str(fp),packetSha256=report['packetSha256'],reportPath=str(fr),reportSha256=hashlib.sha256(fr.read_bytes()).hexdigest(),fullOld42Conflicts=[dict(owner=r['owner'],count=len(r['contacts']),owners=collections.Counter(z['otherOwner']for z in r['contacts']))for r in fullRows],conditional48PhysicalPassed=report['conditional48PhysicalPassed'],conditionalNewWireGuidancePassed=report['conditionalChanged4NewWireGuidancePassed'],conditional263FixedReversePassed=report['conditionalFixed263ReversePassed'],bad48=[dict(owner=r['owner'],contacts=r['contacts'])for r in rows if r['contacts']])))
