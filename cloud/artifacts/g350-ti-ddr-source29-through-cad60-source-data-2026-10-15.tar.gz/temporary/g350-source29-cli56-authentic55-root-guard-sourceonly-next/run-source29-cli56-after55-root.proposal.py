"""Root-only Source29 CLI56 after authentic Native54/API55; Source-only author never evaluates operational code."""
"""Root-only Source29 API55 two-child controller after authentic Native54; author never evaluates operational code."""
"""Root-only Source29 Native54 template after authentic three-child batch53; unset actual53 gates refuse before operational imports."""
"""Root-only Source29 serial capture/types/Core template; NULL future52/promotion gates refuse before operational imports."""
"""Root-only Source26 fresh offline CAD after authentic CLI51; future exact flat-file wrapper pins refuse this draft."""
"""Root-only Source24 first capture; author performs Source-only construction, never evaluation."""
"""Root-only changed-order direct-compact clock diagnostic; author never evaluates it."""
"""Root-only proposal. Author never imports or executes this guard or SDK."""
import fcntl, hashlib, importlib.util, json, os, re, shutil, stat, sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
PACKET = Path(__file__).resolve().parent
POLICIES = {'full644': {'wallSeconds':360,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}, 'optout9': {'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}}

def read(path): return json.loads(Path(path).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def binding(row):
 p=Path(row['path']);s=p.lstat();assert not p.is_symlink() and stat.S_ISREG(s.st_mode) and sha(p)==row['sha256'] and s.st_size==row['bytes'] and stat.S_IMODE(s.st_mode)==row['mode']
def rows(value):
 if isinstance(value,dict):
  if all(k in value for k in ('path','sha256','bytes','mode')): yield value
  else:
   for v in value.values(): yield from rows(v)
 elif isinstance(value,list):
  for v in value: yield from rows(v)
def write(path,value):
 with path.open('x') as f: json.dump(value,f,indent=2);f.write('\n')
 path.chmod(0o600)
def counts(log):
 found={k:re.findall(r'^\s*(\d+) '+k+r'\s*$',log,re.M) for k in ('pass','fail')}
 return {k:int(v[0]) for k,v in found.items()} if all(len(v)==1 for v in found.values()) else None
def no_git_redirects():
 exact={'GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_NAMESPACE','GIT_REPLACE_REF_BASE','GIT_CONFIG','GIT_CONFIG_COUNT'}
 assert not any(k in exact or k.startswith(('GIT_CONFIG_KEY_','GIT_CONFIG_VALUE_')) for k in os.environ)
def git_inventory():
 root=Path('/workspace/bus-lanes-solver/.git')
 result=[]
 for p in sorted(root.rglob('*')):
  if 'objects' in p.relative_to(root).parts:continue
  assert not p.is_symlink(), 'Real Git metadata must not contain symlink entries'
  if p.is_file():
   s=p.lstat();assert stat.S_ISREG(s.st_mode)
   result.append(dict(path=str(p),sha256=sha(p),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode)))
 return result

import secrets
def closed_through31(c,h,gm,m,bindings,context14_path):
 h.failed_original_eleven()
 context,rows=h.root_current_closed_rows(context14_path);assert len(rows)==14
 bindings();r=c.read(gm['actual24184RawReceiptPin']['path']);q=c.read(gm['actual24184FreshSupplementPin']['path'])
 assert r['scope']=='ROOT_RAW_CURRENT_CORE49_RESULT_AND_DUPLICATE_SCOPE_REFUSAL_COLLECTION' and r['toolSessionCollected']is True
 assert r['observedToolWrapperExitCode']==1 and r['observedToolWrapperRefusedExistingRunDirectory']is True
 assert r['firstGuardToolWrapperExitUnknown']is True and r['firstGuardToolWrapperExitCode']is None and r['naturalOwnedSdkChildExitCode']==1
 assert r['originalStepCalls']==21732 and r['actualUniqueGeneratedCarrierCount']==0 and r['failureCode']=='no_planar_route' and r['passed']is False
 assert c.sha(r['postauditPath'])==r['postauditSha256'];p=c.read(r['postauditPath']);assert p['execution']==r['execution'] and p['sourceAndDependenciesHeld']is True
 h.held_inventory_post(p);h.finite(r['execution'],1)
 assert r['execution']['pgid']==452553 and c.guard.process_scope.owned(452553)==[] and not Path('/proc/452548').exists()
 assert q['rawReceiptSha256']==gm['actual24184RawReceiptPin']['sha256'] and q['rawPostauditSha256']==r['postauditSha256']
 assert q['ownedSdkGroupEmpty']is True and q['recordedFirstGuardAbsent']is True and q['firstToolWrapperExitStillUnknown']is True and q['allCurrentCallerGuardSourceBindingsHeld']is True
 assert q['freshBoardSdk']['treeSha256']==m['boardSdkTreeSha256'] and q['freshSolverSdk']['treeSha256']==gm['solverSdkTreeSha256']
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 # Older recorded Source/Core/native/CLI/CAD/render scopes stay independently empty.
 prior=c.read(c.BOARD/'.cloud-tools/ddr-strict18-smooth-fresh-kicad-sourceonly-next/run-cad/ROOT_AUTHORITY.json')['actualPriorCollectedRows']
 for name in('strict18-smooth-cad-37841-COLLECTED-root.json','context12-buslane-pool-52091-COLLECTED-root.json','context12-reset227-buslane-pool-62531-COLLECTED-root.json'):
  prior.append({'path':str(ROOT/name),'sha256':c.sha(ROOT/name)})
 for r in prior:assert c.guard.process_scope.owned(c.guard.collected(r)[2]['pgid'])==[]
 assert c.guard.process_scope.owned(c.read(ROOT/'smooth18-render-31726-COLLECTED-root.json')['execution']['pgid'])==[]
 pin=gm['actual77568CollectionPin'];u=c.read(pin['path']);p=c.read(u['postauditPath']);v=c.read(gm['actual77568ReportPin']['path'])
 assert u['authorizedByRoot']is True and u['scope']=='ROOT_ONE_FAITHFUL_CURRENT23_ORIGINAL_API_PARTIAL_DIAGNOSTIC' and u['toolSessionId']==77568 and u['toolSessionCollected']is True
 assert u['toolWrapperExitCode']==0 and u['toolExitCode']==0 and u['sourceManifestSha256']==gm['faithfulApiSourcePin']['sha256'] and p['sourceManifestSha256']==u['sourceManifestSha256']
 assert c.sha(u['postauditPath'])==u['postauditSha256']==gm['actual77568PostauditPin']['sha256'] and u['reportSha256']==gm['actual77568ReportPin']['sha256'] and p['resultSha256']==u['reportSha256']
 assert u['execution']==p['execution'] and u['passed']is True and p['passed']is True and u['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True
 h.held_inventory_post(p);h.finite(u['execution'],0);assert u['execution']['pgid']==455504 and c.guard.process_scope.owned(455504)==[]
 assert u['apiDispatchCalls']==100 and p['originalApiDirectCalls']==100 and v['directOriginalApiDispatchCount']==100 and v['actual23RawCarrierCount']==23 and v['all23ContinuousChecksPassed']is True
 assert v['faithfulCurrentInputSha256']==m['initialLayerOnlyInputPin']['sha256'] and v['full49TimingPassed']is False and v['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual97604CollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual97604PostauditPin']['path']);v=c.read(gm['actual97604ObserverPin']['path'])
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_CURRENT631_UNSEEDED_FULL49_PAIR_REJECTION_DIAGNOSTIC' and r['sourceManifestSha256']==gm['callerSourcePin']['sha256'] and r['toolSessionId']==97604 and r['toolSessionCollected']is True
 assert r['toolWrapperExitCode']==2 and r['toolExitCode']==2 and r['passed']is False and r['generationNaturallyCompleted']is True and r['pairObserverCompleted']is True
 assert r['postauditSha256']==gm['actual97604PostauditPin']['sha256'] and c.sha(r['postauditPath'])==r['postauditSha256'] and p['execution']==r['execution'] and p['sourceAndDependenciesHeld']is True
 h.held_inventory_post(p);h.finite(r['execution'],1);assert r['execution']['pgid']==456683 and c.guard.process_scope.owned(456683)==[]
 assert p['ownedGroupEmptyActuallyObserved']is True and p['rootGuardProposalManifestSha256']==gm['parentGuardManifestPin']['sha256'] and p['generationNaturallyCompleted']is True and p['pairObserverCompleted']is True
 assert r['originalStepCalls']==21732 and r['actualUniqueGeneratedCarrierCount']==0 and r['failureCode']=='no_planar_route' and r['fabricationReady']is False
 assert r['pairObserverSha256']==gm['actual97604ObserverPin']['sha256'] and p['pairObserverSha256']==r['pairObserverSha256'] and len(v['rows'])<=12 and gm['actual97604ObserverPin']['bytes']<=65536
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual66744CollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual66744PostauditPin']['path']);v=c.read(gm['actual66744ResultPin']['path'])
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_17_AUTHENTIC_PRIOR_CLOSURES' and r['phase']=='routing' and r['toolSessionId']==66744 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['remaining26CallerSourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==gm['parent18RunnerManifestPin']['sha256'] and r['toolWrapperExitCode']==2 and r['toolExitCode']==2 and r['passed']is False
 assert r['postauditSha256']==gm['actual66744PostauditPin']['sha256'] and c.sha(r['postauditPath'])==r['postauditSha256'] and r['execution']==p['execution'] and r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True
 h.held_inventory_post(p);h.finite(r['execution'],1);assert r['execution']['pgid']==460262 and c.guard.process_scope.owned(460262)==[] and p['ownedGroupEmptyActuallyObserved']is True
 assert r['stageNaturallyCompleted']is True and p['stageNaturallyCompleted']is True and r['originalStepCalls']==v['originalStepCalls']==425 and r['actualUniqueGeneratedCarrierCount']==v['actualUniqueGeneratedCarrierCount']==3 and r['failureCode']==v['failureCode']=='no_planar_route'
 assert r['resultSha256']==p['resultSha256']==gm['actual66744ResultPin']['sha256'] and v['all49Accepted']is False and v['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual3801BaselineCollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual3801BaselinePostauditPin']['path']);log=Path(gm['actual3801BaselineLogPin']['path']).read_text()
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_18_AUTHENTIC_PRIOR_CLOSURES' and r['phase']=='tests' and r['toolSessionId']==3801 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['cornerSourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==gm['parent19RunnerManifestPin']['sha256'] and r['toolWrapperExitCode']==2 and r['toolExitCode']==2 and r['passed']is False
 assert r['postauditSha256']==gm['actual3801BaselinePostauditPin']['sha256'] and c.sha(r['postauditPath'])==r['postauditSha256'] and r['childLogSha256']==gm['actual3801BaselineLogPin']['sha256'] and c.sha(r['childLogPath'])==r['childLogSha256'] and r['execution']==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True and r['stageNaturallyCompleted']is True and p['stageNaturallyCompleted']is True and r['baselineExpectedRedActuallyObserved']is True and p['baselineExpectedRedActuallyObserved']is True
 h.held_inventory_post(p);h.finite(r['execution'],1);assert r['execution']['pgid']==461476 and c.guard.process_scope.owned(461476)==[] and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['actualTestCounts']=={'pass':2,'fail':1,'expect':23} and re.search(r'^\s*2 pass\s*$',log,re.M)and re.search(r'^\s*1 fail\s*$',log,re.M)and re.search(r'^\s*23 expect\(\) calls\s*$',log,re.M)
 witnesses=[json.loads(line)for line in log.splitlines()if line.startswith('{')and '"scope":"FOCUSED_CURRENT631_PAIR_DIAGNOSTIC"'in line];assert len(witnesses)==1 and witnesses[0]==r['exactDiagnosticWitness']
 w=witnesses[0];assert w['inputSha256']=='631ac37009bb602a3a1e67d3ffe7a932669e38ee372d60b29ce196d3c76ddd6d'and w['sourceRoot']=='/workspace/bus-lanes-solver/.cache/paired-layer-fallback-sourceonly-next/lib'and w['naturalGeneratorCompletion']is True and w['originalYieldCount']==5568 and w['returnedCarrierCount']==0 and w['full49Accepted']is False and w['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual86792ResourceCollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual86792ResourcePostauditPin']['path']);log=Path(gm['actual86792ResourceLogPin']['path']).read_text();e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_19_AUTHENTIC_PRIOR_CLOSURES' and r['phase']=='tests' and r['toolSessionId']==86792 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['cornerSourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==gm['parent20RunnerManifestPin']['sha256'] and r['toolWrapperExitCode']==2 and r['toolExitCode']==2
 assert r['postauditSha256']==gm['actual86792ResourcePostauditPin']['sha256'] and c.sha(r['postauditPath'])==r['postauditSha256'] and r['childLogSha256']==gm['actual86792ResourceLogPin']['sha256'] and c.sha(r['childLogPath'])==r['childLogSha256'] and e==p['execution']
 # A resource-stopped scope is closed honestly, never passed through the natural-exit helper.
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p)
 assert e['exitCode']==-15 and e['diagnosticStopped']is True and e['stopReasons']==['OWNED_RSS_STOP'] and e['policy']['rssBytes']==1073741824 and e['peakOwnedRssBytes']==1080479744 and not any(e['oomDelta'].values())
 assert e['cleanupOwnedGroupEmpty']is True and e['pgid']==461945 and c.guard.process_scope.owned(461945)==[] and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['stageNaturallyCompleted']is False and p['stageNaturallyCompleted']is False and r['passed']is False and p['passed']is False and r['actualTestCounts']is None and r['focusedCurrentPairCompletionWitnessPresent']is False
 assert 'FOCUSED_CURRENT631_PAIR_DIAGNOSTIC'not in log and r['resourceStop']=='OWNED_RSS_STOP'and r['all49Accepted']is False and r['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual60763ResourceCollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual60763ResourcePostauditPin']['path']);log=Path(gm['actual60763ResourceLogPin']['path']).read_text();e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_20_AUTHENTIC_PRIOR_CLOSURES' and r['phase']=='tests' and r['toolSessionId']==60763 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['prioritySourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==gm['parent21RunnerManifestPin']['sha256'] and r['toolWrapperExitCode']==2 and r['toolExitCode']==2
 assert r['postauditSha256']==gm['actual60763ResourcePostauditPin']['sha256'] and c.sha(r['postauditPath'])==r['postauditSha256'] and r['childLogSha256']==gm['actual60763ResourceLogPin']['sha256'] and c.sha(r['childLogPath'])==r['childLogSha256'] and e==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p)
 assert e['exitCode']==-15 and e['diagnosticStopped']is True and e['stopReasons']==['OWNED_RSS_STOP']and e['policy']['rssBytes']==1073741824 and e['peakOwnedRssBytes']==1077477376 and not any(e['oomDelta'].values())
 assert e['cleanupOwnedGroupEmpty']is True and e['pgid']==463140 and c.guard.process_scope.owned(463140)==[] and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['stageNaturallyCompleted']is False and p['stageNaturallyCompleted']is False and r['passed']is False and p['passed']is False and r['actualTestCounts']is None and r['focusedCurrentPairCompletionWitnessPresent']is False and 'FOCUSED_CURRENT631_PAIR_DIAGNOSTIC'not in log
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual59592ResourceCollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual59592ResourcePostauditPin']['path']);log=Path(gm['actual59592ResourceLogPin']['path']).read_text();w=c.read(gm['actual59592AllocationWitnessPin']['path']);e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_21_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='tests'and r['toolSessionId']==59592 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['allocationSourcePin']['sha256']and r['rootGuardProposalManifestSha256']==gm['parent24RunnerManifestPin']['sha256']and r['toolWrapperExitCode']==2 and r['toolExitCode']==2
 assert c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual59592ResourcePostauditPin']['sha256']and c.sha(r['childLogPath'])==r['childLogSha256']==gm['actual59592ResourceLogPin']['sha256']and e==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p)
 assert e['exitCode']==-15 and e['diagnosticStopped']is True and e['stopReasons']==['OWNED_RSS_STOP']and e['policy']['rssBytes']==1073741824 and e['peakOwnedRssBytes']==1074499584 and not any(e['oomDelta'].values())
 assert e['cleanupOwnedGroupEmpty']is True and e['pgid']==464228 and c.guard.process_scope.owned(464228)==[]and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['stageNaturallyCompleted']is False and p['stageNaturallyCompleted']is False and r['passed']is False and p['passed']is False and r['actualTestCounts']is None and r['focusedCurrentPairCompletionWitnessPresent']is False and 'FOCUSED_CURRENT631_PAIR_DIAGNOSTIC'not in log
 assert r['allocationDiagnosticEvidenceAvailable']is True and p['allocationDiagnosticEvidenceAvailable']is True and r['allocationWitnessSha256']==p['allocationWitnessSha256']==gm['actual59592AllocationWitnessPin']['sha256']and r['allocationWitnessBytes']==5561 and w['observedEvents']==3629 and len(w['events'])==8 and w['full49Accepted']is False and w['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 for spec in gm['source14ObservedClosedRows']:
  r=c.read(spec['receiptPin']['path']);p=c.read(spec['postPin']['path']);v=c.read(spec['resultPin']['path']);e=r['execution']
  assert r['authorizedByRoot']is True and r['scope']==spec['scope']and r['phase']=='routing'and r['toolSessionId']==spec['toolSessionId']and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['sourceManifestSha256']==spec['sourceManifestSha256']and c.sha(r['postauditPath'])==r['postauditSha256']==spec['postPin']['sha256']and r['resultSha256']==p['resultSha256']==spec['resultPin']['sha256']and e==p['execution']
  assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p);h.finite(e,0)
  assert e['pgid']==spec['pgid']and c.guard.process_scope.owned(spec['pgid'])==[]and r['independentlyObservedOwnedGroupEmpty']is True and p['ownedGroupEmptyActuallyObserved']is True
  assert r['diagnosticCompleted']is True and p['diagnosticCompleted']is True and r['passed']is True and p['passed']is True and r['originalGridSolvedCandidate']is False and r['candidateTotalPlanarWithinWindow']is False
  assert v['diagnosticCompleted']is True and v['termination']=='NATURAL_FAILED'and v['originalStepCalls']==0 and v['terminalBeforeCancel']=={'expanded':0,'solved':False,'failed':True}and v['candidatePath']is None and v['totalPlanarWithinWindow']is False and v['sourceNativeCheckedCountRemains23']is True and v['all49Accepted']is False and v['fabricationReady']is False
  if spec['toolSessionId']==42702:assert v['constructorFailureReason']=='REACHABILITY_COMPONENT_REJECTION'and v['constructorAttachments']=={'starts':8,'ends':8,'cellCount':1413721}
  for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual24627ResourceCollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual24627ResourcePostauditPin']['path']);log=Path(gm['actual24627ResourceLogPin']['path']).read_text();w=c.read(gm['actual24627AllocationWitnessPin']['path']);e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_24_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='tests'and r['toolSessionId']==24627 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['stampReuseSourcePin']['sha256']and r['rootGuardProposalManifestSha256']==gm['parent26RunnerManifestPin']['sha256']and r['toolWrapperExitCode']==r['toolExitCode']==2
 assert c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual24627ResourcePostauditPin']['sha256']and c.sha(r['childLogPath'])==r['childLogSha256']==gm['actual24627ResourceLogPin']['sha256']and e==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p)
 assert e['exitCode']==-15 and e['diagnosticStopped']is True and e['stopReasons']==['OWNED_RSS_STOP']and e['policy']['rssBytes']==1073741824 and not any(e['oomDelta'].values())and e['cleanupOwnedGroupEmpty']is True
 assert e['pgid']==465869 and c.guard.process_scope.owned(465869)==[]and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['stageNaturallyCompleted']is False and p['stageNaturallyCompleted']is False and r['passed']is False and p['passed']is False and r['actualTestCounts']is None and r['focusedCurrentPairCompletionWitnessPresent']is False and 'FOCUSED_CURRENT631_PAIR_DIAGNOSTIC'not in log
 assert r['allocationDiagnosticEvidenceAvailable']is True and p['allocationDiagnosticEvidenceAvailable']is True and r['allocationWitnessSha256']==p['allocationWitnessSha256']==gm['actual24627AllocationWitnessPin']['sha256']and w['observedEvents']==3733 and len(w['events'])==8 and w['full49Accepted']is False and w['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 r=c.read(gm['actual59892CollectionPin']['path']);p=c.read(gm['actual59892PostauditPin']['path']);v=c.read(gm['actual59892ResultPin']['path']);e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_25_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='routing'and r['toolSessionId']==59892 and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==0
 assert r['sourceManifestSha256']=='251c339a040a43ec0c5dcfb428157e37cdd2ecc07d7de134a505e932c4bf237b'and c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual59892PostauditPin']['sha256']and r['resultSha256']==p['resultSha256']==gm['actual59892ResultPin']['sha256']and e==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p);h.finite(e,0)
 assert e['pgid']==466570 and c.guard.process_scope.owned(466570)==[]and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['diagnosticCompleted']is True and p['diagnosticCompleted']is True and r['passed']is True and p['passed']is True and r['originalGridSolvedCandidate']is False and r['candidateTotalPlanarWithinWindow']is False
 assert v['diagnosticCompleted']is True and v['termination']=='ALL_REMAINING_LAYERS_TESTED'and v['attemptedLayers']==['top','inner2','bottom']and v['originalGridConstructorCalls']==3 and v['totalExpanded']==383387 and len(v['rows'])==3 and all(x['termination']=='NATURAL_FAILED'and x['terminalBeforeCancel']['solved']is False and x['totalPlanarWithinWindow']is False for x in v['rows'])and v['all49Accepted']is False and v['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 r=c.read(gm['actual60822CollectionPin']['path']);p=c.read(gm['actual60822PostauditPin']['path']);log=Path(gm['actual60822LogPin']['path']).read_text();w=c.read(gm['actual60822AllocationWitnessPin']['path']);e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_26_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='tests'and r['toolSessionId']==60822 and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==2
 assert r['sourceManifestSha256']==gm['scratchCapacitySourcePin']['sha256']and c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual60822PostauditPin']['sha256']and c.sha(r['childLogPath'])==r['childLogSha256']==gm['actual60822LogPin']['sha256']and e==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p);h.finite(e,1)
 assert e['pgid']==468148 and c.guard.process_scope.owned(468148)==[]and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['stageNaturallyCompleted']is True and p['stageNaturallyCompleted']is True and r['testSuiteCompleted']is True and r['passed']is False and p['passed']is False and r['actualTestCounts']=={'pass':6,'fail':1,'expect':3865}and r['observedEarlyNamedPassCount']==6
 rows27=[json.loads(line)for line in log.splitlines()if line.startswith('{')and '"scope":"FOCUSED_CURRENT631_PAIR_DIAGNOSTIC"'in line];assert len(rows27)==1 and rows27[0]==r['focusedCurrentPairWitness']
 witness27=rows27[0];assert witness27['inputSha256']=='631ac37009bb602a3a1e67d3ffe7a932669e38ee372d60b29ce196d3c76ddd6d'and witness27['sourceRoot']=='/workspace/bus-lanes-solver/.cache/paired-grid-scratch-capacity-reuse-sourceonly-next/lib'and witness27['naturalGeneratorCompletion']is False and witness27['originalYieldCount']==40000 and witness27['returnedCarrierCount']==0 and witness27['full49Accepted']is False and witness27['fabricationReady']is False
 assert r['originalPairGeneratorNaturallyCompleted']is False and r['originalPairGeneratorYieldCapReached']is True and r['originalPairReturnedCarrierCount']==0 and r['allocationDiagnosticEvidenceAvailable']is True and p['allocationDiagnosticEvidenceAvailable']is True
 assert r['allocationWitnessSha256']==p['allocationWitnessSha256']==gm['actual60822AllocationWitnessPin']['sha256']and w['observedEvents']==3795 and len(w['events'])==8 and w['full49Accepted']is False and w['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 for spec29 in gm['actualOwned156ClosedRows']:
  r=c.read(spec29['receiptPin']['path']);p=c.read(spec29['postPin']['path']);v=c.read(spec29['resultPin']['path']);e=r['execution']
  assert r['authorizedByRoot']is True and r['scope']==spec29['scope']and r['phase']=='routing'and r['toolSessionId']==spec29['toolSessionId']and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['sourceManifestSha256']==spec29['sourcePin']['sha256']and p['sourceManifestSha256']==r['sourceManifestSha256']and c.sha(r['postauditPath'])==r['postauditSha256']==spec29['postPin']['sha256']and r['resultSha256']==p['resultSha256']==spec29['resultPin']['sha256']and e==p['execution']
  assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p);h.finite(e,0)
  assert e['pgid']==spec29['pgid']and c.guard.process_scope.owned(spec29['pgid'])==[]and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
  assert r['diagnosticCompleted']is True and p['diagnosticCompleted']is True and r['passed']is True and p['passed']is True and r['originalGridSolvedCandidate']is False and r['candidateTotalPlanarWithinWindow']is False and r['newRoutesAdopted']==0 and r['sourceNativeCheckedCount']==23
  assert v['diagnosticCompleted']is True and v['candidatePath']is None and v['winningLayer']is None and v['faithfulFull49InputSha256']=='631ac37009bb602a3a1e67d3ffe7a932669e38ee372d60b29ce196d3c76ddd6d'and v['all23BodiesRemainFixed']is True and v['all285OtherTracesAndAll1298ObstaclesAndAll23BodiesHeld']is True and v['sourceNativeCheckedCountRemains23']is True and v['all49Accepted']is False and v['fabricationReady']is False
  if spec29['toolSessionId']==88558:
   assert v['termination']=='SHARED_EXPANSION_CAP'and v['totalExpanded']==399999 and v['attemptedLayers']==['inner2','bottom']and v['originalStepCalls']==800 and len(v['rows'])==2
   assert v['rows'][0]['termination']=='NATURAL_FAILED'and v['rows'][0]['terminalBeforeCancel']=={'expanded':0,'solved':False,'failed':True}
   assert v['rows'][1]['termination']=='SHARED_EXPANSION_CAP'and v['rows'][1]['terminalBeforeCancel']=={'expanded':399999,'solved':False,'failed':False}
  else:
   assert spec29['toolSessionId']==32392 and v['termination']=='ALL_REMAINING_LAYERS_TESTED'and v['totalExpanded']==478323 and v['attemptedLayers']==['bottom']and v['originalStepCalls']==957 and len(v['rows'])==1
   assert v['rows'][0]['termination']=='NATURAL_FAILED'and v['rows'][0]['terminalBeforeCancel']=={'expanded':478323,'solved':False,'failed':True}
  for f in p['outputFiles']:c.guard.source_guard.binding(f)
 r=c.read(gm['actual63101IdentityRefusalPin']['path']);p=c.read(gm['actual63101PostauditPin']['path']);log=Path(gm['actual63101LogPin']['path']).read_text();e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_29_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='tests'and r['toolSessionId']==63101 and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==2
 assert r['sourceManifestSha256']==gm['compactFrontSourcePin']['sha256']and r['rootGuardProposalManifestSha256']==gm['parent30RunnerManifestPin']['sha256']and r['rootStageContractSha256']==gm['actual63101StageContractPin']['sha256']and e==p['execution']
 assert c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual63101PostauditPin']['sha256']and c.sha(r['childLogPath'])==r['childLogSha256']==gm['actual63101LogPin']['sha256']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p)
 # The old exception path did not save an exit status or leader row. Keep unknowns.
 assert e['exitCode']is None and e['diagnosticStopped']is True and e['stopReasons']==[]and e['guardError']=='RuntimeError'and 'freshLeaderIdentity'not in e and 'oomDelta'not in e
 assert r['childExitCodeUnknown']is True and r['childExitCode']is None and r['freshLeaderIdentityWasNotSaved']is True and r['guardStoppedDuringFreshLeaderIdentityCheck']is True
 assert r['runFailure']==p['runFailure']=='RuntimeError: Fresh owned leader command/session differs'and r['stageNaturallyCompleted']is False and p['stageNaturallyCompleted']is False and r['passed']is False and p['passed']is False
 assert e['pgid']==470139 and e['currentGuardPid']==470135 and c.guard.process_scope.owned(470139)==[]and not Path('/proc/470135').exists()and r['independentlyObservedOwnedGroupEmpty']is True and r['independentlyObservedGuardAbsent']is True and p['ownedGroupEmptyActuallyObserved']is True
 assert r['actualTestCounts']is None and r['testSuiteCompleted']is False and r['observedEarlyNamedPassCount']==0 and r['observedEarlyNamedPasses']==[]and r['focusedCurrentPairCompletionWitnessPresent']is False and r['allocationDiagnosticEvidenceAvailable']is False and 'FOCUSED_CURRENT631_PAIR_DIAGNOSTIC'not in log
 assert r['newRoutesAdopted']==0 and r['all49Accepted']is False and r['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 r=c.read(gm['actual85694CollectionPin']['path']);p=c.read(gm['actual85694PostauditPin']['path']);log=Path(gm['actual85694LogPin']['path']).read_text();w=c.read(gm['actual85694AllocationWitnessPin']['path']);e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_30_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='tests'and r['toolSessionId']==85694 and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==0
 assert r['sourceManifestSha256']==gm['compactFrontSourcePin']['sha256']and r['rootGuardProposalManifestSha256']==gm['parent31RunnerManifestPin']['sha256']and r['rootStageContractSha256']==gm['actual85694StageContractPin']['sha256']and e==p['execution']
 assert c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual85694PostauditPin']['sha256']and c.sha(r['childLogPath'])==r['childLogSha256']==gm['actual85694LogPin']['sha256']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p);h.finite(e,0)
 assert e['pgid']==470739 and e['currentGuardPid']==470734 and c.guard.process_scope.owned(470739)==[]and not Path('/proc/470734').exists()and r['independentlyObservedOwnedGroupEmpty']is True and r['independentlyObservedGuardAbsent']is True and p['ownedGroupEmptyActuallyObserved']is True
 assert r['stageNaturallyCompleted']is True and p['stageNaturallyCompleted']is True and r['passed']is True and p['passed']is True and r['testSuiteCompleted']is True and r['actualTestCounts']=={'pass':9,'fail':0,'expect':1269}and r['observedEarlyNamedPassCount']==8
 rows31=[json.loads(line)for line in log.splitlines()if line.startswith('{')and '"scope":"FOCUSED_CURRENT631_PAIR_DIAGNOSTIC"'in line];assert len(rows31)==1 and rows31[0]==r['focusedCurrentPairWitness']
 witness31=rows31[0];assert witness31['inputSha256']=='631ac37009bb602a3a1e67d3ffe7a932669e38ee372d60b29ce196d3c76ddd6d'and witness31['sourceRoot']=='/workspace/bus-lanes-solver/.cache/paired-compact-front-portals-truthful-witness-successor-next/lib'and witness31['naturalGeneratorCompletion']is True and witness31['originalYieldCount']==5573 and witness31['returnedCarrierCount']==2 and witness31['full49Accepted']is False and witness31['fabricationReady']is False
 assert r['originalPairGeneratorNaturallyCompleted']is True and r['originalPairGeneratorYieldCapReached']is False and r['originalPairReturnedCarrierCount']==2 and r['allocationDiagnosticEvidenceAvailable']is True and p['allocationDiagnosticEvidenceAvailable']is True
 assert r['allocationWitnessSha256']==p['allocationWitnessSha256']==gm['actual85694AllocationWitnessPin']['sha256']and w['observedEvents']==1149 and len(w['events'])==8 and w['routingOrderAndPredicatesUnchanged']is False and w['originalLegacyAndCornerOrderAndPredicatesPreserved']is True and w['compactFrontFallbackAdded']is True and w['full49Accepted']is False and w['fabricationReady']is False
 assert r['newRoutesAdopted']==0 and r['all49Accepted']is False and r['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 return {'context14Binding':context,'current14Rows':rows,'special15RawReceipt':gm['actual24184RawReceiptPin'],'special15FreshSupplement':gm['actual24184FreshSupplementPin'],'actual16Api77568Receipt':gm['actual77568CollectionPin'],'actual17Pair97604Receipt':gm['actual97604CollectionPin'],'actual18Remaining66744Receipt':gm['actual66744CollectionPin'],'actual19Baseline3801Receipt':gm['actual3801BaselineCollectionPin'],'actual20Resource86792Receipt':gm['actual86792ResourceCollectionPin'],'actual21Resource60763Receipt':gm['actual60763ResourceCollectionPin'],'actual22Resource59592Receipt':gm['actual59592ResourceCollectionPin'],'actual23And24Source14Diagnostics':gm['source14ObservedClosedRows'],'actual25Resource24627Receipt':pin,'actual26RemainingLayers59892Receipt':gm['actual59892CollectionPin'],'actual27Scratch60822Receipt':gm['actual60822CollectionPin'],'actual28And29Owned156Diagnostics':gm['actualOwned156ClosedRows'],'actual30IdentityRefusal63101Receipt':gm['actual63101IdentityRefusalPin'],'unknown63101ChildExitAndLeaderSnapshotPreserved':True,'actual31NinePass85694Receipt':gm['actual85694CollectionPin'],'focusedPairPassIsNotFull49Qualification':True,'completedTestSuiteIsNotNaturalPairCompletion':True,'source14DiagnosticPassedIsNotGridRoutePass':True,'resourceStopsAreNotNaturalFailuresOrPasses':True,'actualClosedScopeCount':31,'originalWrapperExitUnknownPreserved':True}


def closed_through32(c,h,gm,m,bindings,context14_path,proposal):
 previous=closed_through31(c,h,gm,m,bindings,context14_path)
 assert previous['actualClosedScopeCount']==31 and previous['originalWrapperExitUnknownPreserved'] is True
 r=read(proposal['actual32CollectionPin']['path']);p=read(proposal['actual32PostauditPin']['path']);v=read(proposal['actual32ResultPin']['path']);e=r['execution']
 assert r['authorizedByRoot'] is True and r['toolSessionId']==60819 and r['toolSessionCollected'] is True and r['toolWrapperExitCode']==r['toolExitCode']==2
 assert r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_31_AUTHENTIC_PRIOR_CLOSURES' and r['phase']=='routing' and r['sourceManifestSha256']=='d92577c2ca8ac798640e9d04ee32ebd43fcc1599374556ca02617913bbe7f48b'
 assert r['rootGuardProposalManifestSha256']==proposal['reviewedThrough31ManifestPin']['sha256'] and r['rootStageContractSha256']=='9799d63254635dbde7e89a2fe0fde043dcd81d0b63e0409f44f2b561b2ffc3ab'
 assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual32PostauditPin']['sha256'] and sha(r['resultPath'])==r['resultSha256']==proposal['actual32ResultPin']['sha256'] and e==p['execution']
 assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is True and r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True and r['passed'] is p['passed'] is False
 h.held_inventory_post(p);h.finite(e,1)
 assert e['pgid']==471806 and e['currentGuardPid']==471801 and c.guard.process_scope.owned(471806)==[] and not Path('/proc/471801').exists()
 assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is p['ownedGroupEmptyActuallyObserved'] is True
 assert r['originalStepCalls']==v['originalStepCalls']==40000 and r['actualUniqueGeneratedCarrierCount']==v['actualUniqueGeneratedCarrierCount']==4
 assert r['generatedNames']==['source_trace_15','source_trace_16','source_trace_28','source_trace_27'] and r['failureCode']==v['failureCode']=='search_budget_exhausted'
 assert v['naturalSdkFailed'] is True and v['naturalSdkSolved'] is False and v['thrown'] is None and r['all49Accepted'] is v['all49Accepted'] is False and r['fabricationReady'] is v['fabricationReady'] is False
 for f in p['outputFiles']:binding(f)
 return {'through31':previous,'actual32CollectionPin':proposal['actual32CollectionPin'],'actualClosedScopeCount':32,'originalWrapperUnknownAndOriginalElevenFailurePreserved':True}

def main():
 assert not sys.flags.optimize and len(sys.argv)==6
 source_sha,peer_path,peer_sha,context14_path,out=sys.argv[1:]
 peer_path,context14_path,out=Path(peer_path),Path(context14_path),Path(out)
 assert all(re.fullmatch('[0-9a-f]{64}',v)for v in(source_sha,peer_sha))and sha(PACKET/'SOURCE-manifest.json')==source_sha
 proposal=read(PACKET/'SOURCE-manifest.json')
 assert proposal['actual55Sealed']is proposal['cli29ActivationSealed']is True
 for key in('actual55CollectionPin','actual55PostauditPin','actual55ModelPin','actual55ProofPin','actual55ApiReportPin','actual55GuardManifestPin','cli29PreparationPin','cli29ActivationPeerPin'):assert isinstance(proposal[key],dict)
 assert proposal['actual55ToolSessionId']==20574 and isinstance(proposal['actual55PhasePostauditPins'],list)and len(proposal['actual55PhasePostauditPins'])==2
 assert proposal['actual54Sealed']is True
 for key in('actual54CollectionPin','actual54PostauditPin','actual54ReportPin','actual54BoundManifestPin','actual54AuthorityPin','actual54GuardManifestPin'):assert isinstance(proposal[key],dict)
 assert (proposal['actual54ToolSessionId'],proposal['actual54Pgid'],proposal['actual54GuardPid'])==(90477,501788,501737)
 assert proposal['actual53Sealed']is True
 for key in('actual53CollectionPin','actual53PostauditPin','actual53CapturePin','actual53DiagnosticPin','actual53CoreRawPin','actual53CoreControlsPin','actual53GuardManifestPin'):assert isinstance(proposal[key],dict)
 assert type(proposal['actual53ToolSessionId'])is int and isinstance(proposal['actual53PhasePostauditPins'],list)and len(proposal['actual53PhasePostauditPins'])==3
 assert proposal['actual52AndSource29PromotionSealed']is True
 for key in('actual52CollectionPin','actual52PostauditPin','actual52ResultPin','actual52ResourcePin','actual52ZonePinsPin','actual52GuardManifestPin','prepared29ActivationManifestPin','promoted29ManifestPin','promoted29ModulePin','promoted29ProposalPin','promoted29CapturePin','promoted29TypesPin','promoted29CorePin'):assert isinstance(proposal[key],dict)
 for key in('actual52ToolSessionId','actual52ZonePgid','actual52CadPgid','actual52GuardPid'):assert type(proposal[key])is int
 assert isinstance(proposal['actual52ContainerName'],str)
 # Sealed-successor and required authentic pins are checked before helper imports.
 assert proposal['status']=='AUTHOR_DONE_SOURCE29_CLI56_AFTER_AUTHENTIC55_ROOT_REVIEW_REQUIRED_UNRUN'
 assert proposal['cad26FlatWrapperSealed']is proposal['actual51Sealed']is proposal['cli26ActivationSealed']is proposal['actual50Sealed']is proposal['actual49Sealed']is proposal['actual48Sealed']is proposal['future47AndPromotionSealed']is True
 for key in('actual51CollectionPin','actual51PostauditPin','actual51ReportPin','actual51ExportPin','actual51AuthorityPin','cad26WrapperSourcePin','cad26SnapshotWrapperPin','cad26SnapshotCheckerPin','cad26ResourceReporterPin'):assert isinstance(proposal[key],dict)
 for key in('cli26PreparationPin','actual50CollectionPin','actual50PostauditPin','actual50ModelPin','actual50ProofPin','actual50ApiReportPin'):assert isinstance(proposal[key],dict)
 assert type(proposal['actual50ToolSessionId'])is int and len(proposal['actual50PhasePostauditPins'])==2
 for key in('actual49CollectionPin','actual49PostauditPin','actual49ReportPin','actual49BoundManifestPin','actual49AuthorityPin'):assert isinstance(proposal[key],dict)
 assert type(proposal['actual49ToolSessionId'])is int
 for key in('actual48CollectionPin','actual48PostauditPin','actual48CapturePin','actual48DiagnosticPin','actual48CoreRawPin','actual48CoreControlsPin','actual47CollectionPin','actual47PostauditPin','actual47ResultPin','promoted26ManifestPin','promoted26ModulePin','promoted26ProposalPin','promoted26CapturePin','promoted26TypesPin','promoted26CorePin'):assert isinstance(proposal[key],dict)
 assert type(proposal['actual48ToolSessionId'])is int and len(proposal['actual48PhasePostauditPins'])==3
 regression=read(proposal['reviewedRegressionManifestPin']['path']);base=read(regression['regressionBaseSourcePin']['path'])
 gm=read(regression['reviewedThrough31ManifestPin']['path']);m=read(gm['callerSourcePin']['path']);clock=read(proposal['clockCallerSourcePin']['path'])
 stage=read(proposal['source24StagesManifestPin']['path']);declaration=read(stage['parentEditableCandidateManifest']['path']);source23=read(stage['genuineParentSource']['path'])
 native_preparation=read(proposal['nativePreparationPin']['path']);api_preparation=read(proposal['apiPreparationPin']['path']);cli_preparation=read(proposal['cliPreparationPin']['path'])
 # All historical command checks retain the executed CAD46 contract aliases.
 historicalCad46=read(proposal['historicalCad46ManifestPin']['path']);contract=read(proposal['historicalCad46ContractPin']['path']);batch=read(proposal['batchContractPin']['path'])
 prepared26=read(proposal['prepared26ManifestPin']['path']);promoted26=read(proposal['promoted26ManifestPin']['path']);data26=read(proposal['promoted26ProposalPin']['path'])
 native26_preparation=read(proposal['native26PreparationPin']['path']);native26_template=read(proposal['native26TemplatePin']['path']);native_contract=read(proposal['native26StageContractPin']['path'])
 api26_contract=read(proposal['api26StageContractPin']['path']);assert api26_contract['requiredPriorScopeCount']==49 and api26_contract['orderedPhases']==['projection','api']and api26_contract['sharedReserveBytes']==1073741824
 cli26_preparation=read(proposal['cli26PreparationPin']['path']);cli26_contract=read(proposal['cli26StageContractPin']['path']);cli26_policy={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 cad26_contract=read(proposal['cad26StageContractPin']['path']);cad26_wrapper=read(proposal['cad26WrapperSourcePin']['path']);cad26_copies=read(proposal['cad26SnapshotCopyInputsPin']['path'])
 assert cad26_contract['requiredPriorScopeCount']==51 and cad26_contract['zonePinsPolicy']=={'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}and cad26_contract['cadPolicy']=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5,'diskFreeGuard':{'path':'/var/lib/docker','minimumFreeBytes':134217728}}
 assert cad26_contract['vfsOverheadBufferBytes']==201326592 and cad26_contract['sampledDiskMinimumFreeBytes']==134217728 and cad26_contract['noImageLoadBuildPull']is True and cad26_copies['runtimeSourceManifest']==proposal['cli26PreparationPin']
 assert cli26_contract['requiredPriorScopeCount']==50 and cli26_contract['phase']=='cli'and cli26_contract['policy']==cli26_policy and cli26_contract['sharedReserveBytes']==1073741824 and cli26_contract['cliWorkerPin']in cli26_preparation['files']
 assert cli26_preparation['genuineSourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and cli26_preparation['requiresNativeSourceManifestSha256']==cli26_preparation['requiresApiSourceManifestSha256']==proposal['native26PreparationPin']['sha256']
 assert cli26_preparation['actualPrerequisites']['actualApiCollection']==proposal['actual50CollectionPin']and cli26_preparation['actualPrerequisites']['actualNativeCollection']==proposal['actual49CollectionPin']and cli26_preparation['actualPrerequisites']['actualCoreRaw']==proposal['actual48CoreRawPin']and cli26_preparation['actualPrerequisites']['actualCoreControls']==proposal['actual48CoreControlsPin']
 assert api26_contract['apiWorkerPin']in native26_preparation['files']and api26_contract['projectorPin']in native26_preparation['files']and api26_contract['apiWorkerPin']['sha256']=='05d243c3e63c9ad23f5a2efbb2fdac96d7de8ba4e6ae6182e4ded58aa12a6491'and api26_contract['projectorPin']['sha256']=='e20c01c5e957d42c74c04f2b6819040c57e505348bbbda04863b094dc9ce92a3'
 policy={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 assert native_contract['phase']=='native'and native_contract['policy']==policy and native_contract['sharedReserveBytes']==1073741824 and native_contract['requiredPriorScopeCount']==48
 assert native_contract['workerPin']in native26_preparation['files']and native_contract['workerPin']['sha256']=='1440e321428bcfb9512ecd03b9b2f055b9cc901949efb0f9dec1a023d98609eb'
 assert native26_preparation['knownPromotedSource26Manifest']==proposal['promoted26ManifestPin']and native26_preparation['knownPromotedSource26Proposal']==proposal['promoted26ProposalPin']
 assert batch['requiredPriorScopeCount']==47 and batch['orderedPhases']==['capture','types','core']and batch['sharedReserveBytes']==1073741824
 assert len(stage['baseline169SourceBindings'])==stage['baseline169Count']==169 and stage['baseline169ByteDelta']==[]and stage['expandedLocalSourceAndControllerImportClosureCount']==176
 assert stage['boardSdkTreeSha256']=='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'and stage['solverSdkTreeSha256']=='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
 assert stage['reviewedRuntimeChecksBundle']['sha256']=='1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc'
 prepared29=read(proposal['prepared29ActivationManifestPin']['path']);promoted29=read(proposal['promoted29ManifestPin']['path']);data29=read(proposal['promoted29ProposalPin']['path']);batch29=read(proposal['source29BatchContractPin']['path'])
 assert batch29['requiredPriorScopeCount']==52 and batch29['orderedPhases']==['capture','types','core']and batch29['sharedReserveBytes']==1073741824
 native29_preparation=read(proposal['native29PreparationPin']['path']);native29_template=read(proposal['native29TemplatePin']['path']);native29_contract=read(proposal['native29StageContractPin']['path'])
 policy29={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 assert native29_contract['phase']=='native'and native29_contract['policy']==policy29 and native29_contract['sharedReserveBytes']==1073741824 and native29_contract['requiredPriorScopeCount']==53
 assert native29_contract['workerPin']in native29_preparation['files']and native29_contract['workerPin']['sha256']=='02928a080a47f7b4ca15c2febe935c51eb21dcfb6aeb57b3f18742958e8fe0f0'
 assert native29_preparation['knownPromotedSource29Manifest']==proposal['promoted29ManifestPin']and native29_preparation['knownPromotedSource29Proposal']==proposal['promoted29ProposalPin']and native29_preparation['allThreeWorkersKnownPromotedConstantsBound']is True
 assert native29_contract['native29PreparationPin']==proposal['native29PreparationPin']and native29_contract['promoted29ManifestPin']==proposal['promoted29ManifestPin']and native29_contract['expectedPhysicalChecks']==18 and native29_contract['expectedConnectedOriginals']==29 and native29_contract['expectedMissingOriginals']==20
 assert native29_contract['expectedPhysicalTraceCount']==292 and native29_contract['expectedInnerAliasCount']==46 and native29_contract['expectedPhysicalPortCount']==1661
 assert native29_template['coreSourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and native29_template['source29ProposalPath']==proposal['promoted29ProposalPin']['path']and native29_template['source29ProposalSha256']==proposal['promoted29ProposalPin']['sha256']
 api29_contract=read(proposal['api29StageContractPin']['path']);assert api29_contract['requiredPriorScopeCount']==54 and api29_contract['orderedPhases']==['projection','api']and api29_contract['sharedReserveBytes']==1073741824
 assert api29_contract['apiWorkerPin']in native29_preparation['files']and api29_contract['projectorPin']in native29_preparation['files']and api29_contract['apiWorkerPin']['sha256']=='e46819f54ad494b545b84c8805605174777c5473e7cbe2c4b5fc2a130815448a'and api29_contract['projectorPin']['sha256']=='58953778f6fc604d6abf53644dc6340be934da37e831fa427154355830710807'
 assert api29_contract['primaryBooleanPredicates']==128 and api29_contract['secondaryDqs1BooleanPredicates']==3 and api29_contract['totalBooleanPredicates']==131 and api29_contract['expectedLoadedCohortSizes']=={'DDR_BYTE0':6,'DDR_BYTE1':11,'DDR_COMMAND_CLOCK':11}and api29_contract['expectedSignalStubSerializedPrimitives']==414 and api29_contract['heldSourceClosureCount']==186
 cli29_preparation=read(proposal['cli29PreparationPin']['path']);cli29_contract=read(proposal['cli29StageContractPin']['path']);cli29_policy={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 assert cli29_contract['requiredPriorScopeCount']==55 and cli29_contract['phase']=='cli'and cli29_contract['policy']==cli29_policy and cli29_contract['sharedReserveBytes']==1073741824 and cli29_contract['cliWorkerPin']in cli29_preparation['files']
 assert cli29_preparation['genuineSourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and cli29_preparation['requiresNativeSourceManifestSha256']==cli29_preparation['requiresApiSourceManifestSha256']==proposal['native29PreparationPin']['sha256']
 assert cli29_preparation['actualPrerequisites']['actualApiCollection']==proposal['actual55CollectionPin']and cli29_preparation['actualPrerequisites']['actualNativeCollection']==proposal['actual54CollectionPin']and cli29_preparation['actualPrerequisites']['actualCoreRaw']==proposal['actual53CoreRawPin']and cli29_preparation['actualPrerequisites']['actualCoreControls']==proposal['actual53CoreControlsPin']
 no_git_redirects()
 # Exactly two future metadata records are not concrete inputs; the whole copy document remains pinned.
 assert cad26_copies['unresolvedFutureRows']==[{'field': 'newCadAuthority', 'path': '/tmp/g350-source26-cad-root-20261015-after51/ROOT_CAD_AUTHORITY.json', 'sha256': None, 'bytes': None, 'mode': None, 'RootCreatesAfterReview': True}, {'field': 'actualSourceZonePins', 'path': '/tmp/g350-source26-cad-root-20261015-after51/SOURCE_ZONE_PINS.json', 'sha256': None, 'bytes': None, 'mode': None, 'RootDerivesAfterReview': True}]
 cad26_concrete_copies={k:v for k,v in cad26_copies.items()if k!='unresolvedFutureRows'}
 def bindings():
  assert sha(PACKET/'SOURCE-manifest.json')==source_sha
  for row in proposal['runtimeBindings']:binding(row)
  seen={}
  for doc in(proposal,historicalCad46,contract,regression,base,gm,m,clock,stage,declaration,source23,native_preparation,api_preparation,cli_preparation,prepared26,promoted26,data26,batch,native26_preparation,native26_template,native_contract,api26_contract,cli26_preparation,cli26_contract,cad26_contract,cad26_wrapper,cad26_concrete_copies,prepared29,promoted29,data29,batch29,native29_preparation,native29_template,native29_contract,api29_contract,cli29_preparation,cli29_contract,read(gm['faithfulApiSourcePin']['path']),read(stage['sourceProposal']['path'])):
   for row in rows(doc):
    row={k:row[k]for k in('path','sha256','bytes','mode')};assert row['path']not in seen or seen[row['path']]==row
    seen[row['path']]=row;binding(row)
  assert promoted26['baseline176SourceBindings']==prepared26['baseline176SourceBindings']==stage['expandedLocalSourceAndControllerImportClosure']
  closure=promoted26['expandedHeldSourceAndControllerClosure'];assert len(closure)==promoted26['expandedHeldSourceAndControllerClosureCount']==181
  held={r['path']:r for r in closure};assert len(held)==181 and all(held[r['path']]==r for r in stage['expandedLocalSourceAndControllerImportClosure'])
  target=Path(prepared26['intendedWorkspacePromotionDirectory']);assert target==Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-source26-reset-source3-editable-source-stages-sourceonly-next')
  prior_paths={r['path']for r in stage['expandedLocalSourceAndControllerImportClosure']};additions=[r for r in closure if r['path']not in prior_paths]
  old_by_name={Path(r['path']).name:r for r in prepared26['files']}
  assert len(additions)==5 and {Path(r['path']).name for r in additions}=={'source26.circuit.tsx','source26-proposal.json','source26-types.ts','capture-source26.ts','render-source26-core.ts'}
  for row in additions:
   assert Path(row['path']).parent==target and {k:row[k]for k in('sha256','bytes','mode')}=={k:old_by_name[Path(row['path']).name][k]for k in('sha256','bytes','mode')}
  for key,name in(('promoted26ModulePin','source26.circuit.tsx'),('promoted26ProposalPin','source26-proposal.json'),('promoted26CapturePin','capture-source26.ts'),('promoted26CorePin','render-source26-core.ts')):assert proposal[key]in additions and Path(proposal[key]['path']).name==name
  assert Path(proposal['promoted26TypesPin']['path'])==target/'typecheck-source26.sh'and {k:proposal['promoted26TypesPin'][k]for k in('sha256','bytes','mode')}=={k:old_by_name['typecheck-source26.sh'][k]for k in('sha256','bytes','mode')}
  assert promoted29['parent181HeldSourceBindings']==prepared29['parent181HeldSourceBindings']==promoted26['expandedHeldSourceAndControllerClosure']
  closure29=promoted29['expandedHeldSourceAndControllerClosure'];assert len(closure29)==promoted29['expandedHeldSourceAndControllerClosureCount']==186
  held29={r['path']:r for r in closure29};assert len(held29)==186 and all(held29[r['path']]==r for r in promoted26['expandedHeldSourceAndControllerClosure'])
  target29=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-source29-joint7-ca6-ca18-reset-editable-source-stages-sourceonly-next')
  prior29_paths={r['path']for r in promoted26['expandedHeldSourceAndControllerClosure']};additions29=[r for r in closure29 if r['path']not in prior29_paths];prepared29_by_name={Path(r['path']).name:r for r in prepared29['files']}
  assert len(additions29)==5 and {Path(r['path']).name for r in additions29}=={'source29.circuit.tsx','source29-proposal.json','source29-types.ts','capture-source29.ts','render-source29-core.ts'}
  for row in additions29:assert Path(row['path']).parent==target29 and {k:row[k]for k in('sha256','bytes','mode')}=={k:prepared29_by_name[Path(row['path']).name][k]for k in('sha256','bytes','mode')}
  for key,name in(('promoted29ModulePin','source29.circuit.tsx'),('promoted29ProposalPin','source29-proposal.json'),('promoted29CapturePin','capture-source29.ts'),('promoted29CorePin','render-source29-core.ts')):assert proposal[key]in additions29 and Path(proposal[key]['path']).name==name
  assert Path(proposal['promoted29TypesPin']['path'])==target29/'typecheck-source29.sh'and {k:proposal['promoted29TypesPin'][k]for k in('sha256','bytes','mode')}=={k:prepared29_by_name['typecheck-source29.sh'][k]for k in('sha256','bytes','mode')}
  assert promoted29['source29ProposalPin']==proposal['promoted29ProposalPin']and promoted29['source29ModulePin']==proposal['promoted29ModulePin']and promoted29['captureWorkerPin']==proposal['promoted29CapturePin']and promoted29['coreWorkerPin']==proposal['promoted29CorePin']and promoted29['typecheckWorkerPin']==proposal['promoted29TypesPin']
  assert data29['promotedParent26Source']==proposal['promoted26ManifestPin']and data29['actualParent26Qualification']==proposal['actual52CollectionPin']and data29['actualParent26Stages']['cad']==proposal['actual52ResultPin']
  assert data29['parent26QualificationBindings']['collectionPins']['cad52']==proposal['actual52CollectionPin']and data29['parent26QualificationBindings']['stagePins']['cad']==proposal['actual52ResultPin']and data29['parent26QualificationBindings']['cad52Postaudit']==proposal['actual52PostauditPin']
  assert promoted29['actualParent26QualificationPin']==proposal['actual52CollectionPin']and batch29['actualParent26CadCollectionPin']==proposal['actual52CollectionPin']and batch29['promotedSource29ManifestPin']==proposal['promoted29ManifestPin']
  for row in base['symlinkContracts']:
   p=Path(row['stagePath']);assert p.is_symlink()and os.readlink(p)==row['linkTarget']and str(p.resolve())==row['resolvedTarget']
  assert peer_path.is_file()and not peer_path.is_symlink()and sha(peer_path)==peer_sha
  peer=read(peer_path);assert peer['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and peer['guardProposalManifestSha256']==source_sha and peer['decision']==cli29_contract['expectedPeerDecision']
  prepared_peer=read(proposal['prepared26PeerPin']['path']);assert prepared_peer['candidateManifest']['sha256']==proposal['prepared26ManifestPin']['sha256']and prepared_peer['decision']==proposal['prepared26PeerDecision']
 bindings()
 helper=Path(regression['operationalHelperPin']['path']);binding(regression['operationalHelperPin'])
 spec=importlib.util.spec_from_file_location('source26_batch_existing_root_closure',helper);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);c=h.c
 binding(gm['diagnosticProcessScopePin']);binding(gm['originalProcessScopePin'])
 assert Path(c.guard.process_scope.__file__).resolve()==Path(gm['originalProcessScopePin']['path']).resolve()
 spec=importlib.util.spec_from_file_location('source26_batch_reviewed_process_scope',gm['diagnosticProcessScopePin']['path']);process_runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(process_runner)
 def closed34():
  prior=closed_through32(c,h,gm,m,bindings,context14_path,proposal)
  assert prior['actualClosedScopeCount']==32 and prior['originalWrapperUnknownAndOriginalElevenFailurePreserved'] is True
  for number,phase,scope,expected in ((33,'full644','ROOT_C30_FULL644_WITH32_AUTHENTIC_PRIOR_CLOSURES',{'pass':644,'fail':0}),(34,'optout9','ROOT_C30_OPTOUT9_WITH33_AUTHENTIC_PRIOR_CLOSURES',{'pass':9,'fail':0})):
   r=read(proposal[f'actual{number}CollectionPin']['path']);p=read(proposal[f'actual{number}PostauditPin']['path']);e=r['execution']
   assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolWrapperExitCode']==r['toolExitCode']==0 and r['passed'] is True
   assert type(r['toolSessionId']) is int and r['toolSessionId']>0 and r['scope']==scope and r['phase']==phase
   assert r['sourceManifestSha256']==r['rootGuardProposalManifestSha256']==proposal['reviewedRegressionManifestPin']['sha256']
   assert sha(r['postauditPath'])==r['postauditSha256']==proposal[f'actual{number}PostauditPin']['sha256'] and p['execution']==e and p['sourceManifestSha256']==r['sourceManifestSha256']
   assert p['passed'] is p['stageNaturallyCompleted'] is p['sourceAndDependenciesHeld'] is True and p['observedCounts']==expected and p['actualClosedPriorScopes']==prior
   assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
   assert p['dependenciesBefore']['treeSha256']==base['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==base['solverSdkTreeSha256']
   h.held_inventory_post(p);h.finite(e,0)
   assert c.guard.process_scope.owned(e['pgid'])==[] and p['ownedGroupEmptyActuallyObserved'] is True and p['workspaceFreeBytesFloorHeld'] is True and p['gitMetadataHeld'] is True
   assert not Path('/proc',str(e['currentGuardPid'])).exists()
   assert sha(p['childLogPath'])==p['childLogSha256']==proposal[f'actual{number}ChildLogPin']['sha256'] and counts(Path(p['childLogPath']).read_text())==expected
   assert p['all49Accepted'] is p['referenceQualified'] is p['electricalTimingPassed'] is p['fabricationReady'] is p['fixReleaseQualificationPassed'] is False
   if number==34:
    witness=p['focusedCurrentPairWitness']
    assert isinstance(witness,dict) and witness['scope']=='FOCUSED_CURRENT631_PAIR_DIAGNOSTIC' and witness['inputSha256']=='631ac37009bb602a3a1e67d3ffe7a932669e38ee372d60b29ce196d3c76ddd6d'
    assert witness['sourceRoot']==clock['solverSourceRoot'] and witness['naturalGeneratorCompletion'] is True and witness['returnedCarrierCount']==2 and 0<=witness['originalYieldCount']<40000
    assert witness['allocationObserverInstalledForDdrCase'] is False and witness['diagnosticMode']=='optout' and re.fullmatch('[0-9a-f]{64}',witness['returnedTracesSha256'])
    raw=[json.loads(line) for line in Path(p['childLogPath']).read_text().splitlines() if line.startswith('{') and '"scope":"FOCUSED_CURRENT631_PAIR_DIAGNOSTIC"' in line]
    assert raw==[witness]
   prior[f'actual{number}'+('Full644' if number==33 else 'Optout9')+'CollectionPin']={'path':str(Path(proposal[f'actual{number}CollectionPin']['path']).resolve()),'sha256':proposal[f'actual{number}CollectionPin']['sha256']}
   prior['actualClosedScopeCount']=number
  return prior

 def closed35():
  prior=closed34()
  assert prior['actualClosedScopeCount']==34 and prior['originalWrapperUnknownAndOriginalElevenFailurePreserved'] is True
  r=read(proposal['actual35CollectionPin']['path']);p=read(proposal['actual35PostauditPin']['path']);v=read(proposal['actual35ResultPin']['path']);raw=read(proposal['actual35RawResultPin']['path']);w=read(proposal['actual35AllocationWitnessPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==30459 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_C30_CLOCK_FIRST_VISIT_WITH34_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='clock_diagnostic'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['priorClockCallerSourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['priorClockGuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual35PostauditPin']['sha256'] and e==p['execution'] and p['actualClosed34Scopes']==prior
  assert sha(r['resultPath'])==r['resultSha256']==p['resultSha256']==proposal['actual35ResultPin']['sha256'] and sha(r['rawResultPath'])==r['rawResultSha256']==p['rawResultSha256']==proposal['actual35RawResultPin']['sha256']
  assert sha(r['allocationWitnessPath'])==r['allocationWitnessSha256']==proposal['actual35AllocationWitnessPin']['sha256'] and r['allocationWitnessBytes']<=16384
  assert r['passed'] is p['passed'] is r['diagnosticCompleted'] is p['diagnosticCompleted'] is True and r['passedMeansDiagnosticCompletionOnly'] is p['passedMeansDiagnosticCompletionOnly'] is True and r['testSuccess'] is p['testSuccess'] is None
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['stageNaturallyCompleted'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter'] and p['dependenciesBefore']['treeSha256']==clock['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==clock['solverDependenciesTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['pgid']==476561 and e['currentGuardPid']==476540 and c.guard.process_scope.owned(e['pgid'])==[] and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True
  assert r['pairReturned'] is p['pairReturned'] is r['pairAccepted'] is p['pairAccepted'] is r['clockRoutingQualified'] is p['clockRoutingQualified'] is False
  assert r['termination']==p['termination']==v['termination']=='ORIGINAL_PAIR_YIELD_CAP' and v['diagnosticCompleted'] is True and v['naturalGeneratorCompletion'] is False and v['original40000YieldCapReached'] is True
  assert r['originalPairYieldCount']==v['originalYieldCount']==v['nextCalls']==40000 and r['originalPairGeneratorNaturallyCompleted'] is False and r['originalPairReturnedCarrierCount']==v['returnedCarrierCount']==0 and v['thrown'] is None
  for key in ('naturalGeneratorCompletion','originalYieldCount','nextCalls','original40000YieldCapReached','thrown','returnedCarrierCount'):assert raw[key]==v[key]
  assert raw['traces'] is None and v['rawGeometryComplete'] is True and p['pairYieldCapReached'] is True and p['naturalNullReturned'] is False
  assert w['scope']=='ROOT_OPT_IN_LAST8_GRID_ALLOCATION_WITNESS' and w['inputSha256']==clock['faithfulInputPin']['sha256'] and w['sourceRoot']==clock['solverSourceRoot'] and w['pairNames']==['source_trace_33','source_trace_34'] and w['observedEvents']==2916 and len(w['events'])==8
  assert w['maximumEvents']==8 and w['maximumBytes']==16384 and all(row['event']['pass']=='legacy' for row in w['events'])
  for key in ('all49Accepted','fabricationReady'):assert r[key] is p[key] is v[key] is raw[key] is w[key] is False
  for key in ('originalAll11AcceptanceClaimed','fixReleaseQualificationPassed','referenceQualified','electricalTimingPassed'):assert p[key] is False
  assert p['sourceNativeCheckedCountRemains23'] is True and p['newRoutesAdopted']==r['newRoutesAdopted']==0
  for row in p['outputFiles']:binding(row)
  prior['actual35ClockLegacyYieldCapCollectionPin']={'path':proposal['actual35CollectionPin']['path'],'sha256':proposal['actual35CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=35
  prior['actual35LegacyPairCapIsNotNaturalNullOrNoRoute']=True
  return prior

 def closed36():
  prior=closed35()
  assert prior['actualClosedScopeCount']==35
  r=read(proposal['actual36CollectionPin']['path']);p=read(proposal['actual36PostauditPin']['path']);w=read(proposal['actual36AllocationWitnessPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==64637
  assert r['toolWrapperExitCode']==2 and r['toolExitCode']==-15 and e==p['execution']
  assert r['scope']==p['scope']=='ROOT_C30_CLOCK_DIRECT_COMPACT_WITH35_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='clock_direct_compact_diagnostic'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['clockCallerSourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['directClockGuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual36PostauditPin']['sha256'] and p['actualClosed35Scopes']==prior
  assert e['exitCode']==-15 and e['accepted'] is False and e['diagnosticStopped'] is True and e['stopReasons']==['WALL_STOP']
  assert e['policy']=={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['cleanupOwnedGroupEmpty'] is True and e['signalErrors']==[] and e['signalErrorCount']==0
  assert e['endedAt'] and e['stoppedAt'] and e['wallSeconds']>=90 and e['peakOwnedRssBytes']==528244736
  assert isinstance(e['oomDelta'],dict) and bool(e['oomDelta']) and not any(e['oomDelta'].values())
  assert e['pgid']==477899 and e['currentGuardPid']==477868 and c.guard.process_scope.owned(e['pgid'])==[] and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is p['ownedGroupEmptyActuallyObserved'] is True
  assert r['independentProcReadErrors']==[] and r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==clock['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==clock['solverDependenciesTreeSha256']
  h.held_inventory_post(p)
  for key in ('passed','stageNaturallyCompleted','diagnosticCompleted','pairReturned','pairAccepted','clockRoutingQualified','all49Accepted','fabricationReady'):assert r[key] is p[key] is False
  assert r['testSuccess'] is p['testSuccess'] is r['naturalGeneratorCompletion'] is p['naturalGeneratorCompletion'] is r['termination'] is p['termination'] is None
  assert r['originalPairYieldCount'] is r['originalPairGeneratorNaturallyCompleted'] is r['originalPairReturnedCarrierCount'] is None
  assert r['resultSha256'] is p['resultSha256'] is r['rawResultSha256'] is p['rawResultSha256'] is None
  assert r['resultPath']==p['resultPath'] and r['rawResultPath']==p['rawResultPath']
  assert not Path(r['resultPath']).exists() and not Path(r['rawResultPath']).exists()
  assert p['rawReportedYieldCount'] is p['rawReportedReturnedCarrierCount'] is p['rawGeometryComplete'] is None
  assert p['naturalNullReturned'] is p['pairYieldCapReached'] is False and r['wallStopIsNotNaturalNullOrYieldCap'] is True
  assert sha(r['allocationWitnessPath'])==r['allocationWitnessSha256']==proposal['actual36AllocationWitnessPin']['sha256'] and r['allocationWitnessBytes']==6312
  assert r['allocationObservedEvents']==w['observedEvents']==989 and w['scope']=='ROOT_OPT_IN_LAST8_CLOCK_DIRECT_COMPACT_GRID_ALLOCATION_WITNESS'
  assert w['inputSha256']==clock['faithfulInputPin']['sha256'] and w['sourceRoot']==clock['solverSourceRoot'] and w['pairNames']==['source_trace_33','source_trace_34']
  assert len(w['events'])==w['maximumEvents']==8 and w['maximumBytes']==16384 and all(row['event']['pass']=='compact' for row in w['events'])
  for doc in (r,p,w):
   assert doc['searchOrderChanged'] is doc['directCompactOnly'] is doc['originalC30PredicatesUnchanged'] is True and doc['exactOriginalFull49Call'] is False
  assert w['all49Accepted'] is w['fabricationReady'] is False
  for key in ('originalAll11AcceptanceClaimed','fixReleaseQualificationPassed','referenceQualified','electricalTimingPassed'):assert p[key] is False
  assert p['sourceNativeCheckedCountRemains23'] is True and p['newRoutesAdopted']==r['newRoutesAdopted']==0
  for row in p['outputFiles']:binding(row)
  prior['actual36ClockDirectCompactWallStopCollectionPin']={'path':proposal['actual36CollectionPin']['path'],'sha256':proposal['actual36CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=36
  prior['actual36WallStopIsNotNaturalNullOrYieldCap']=True
  prior['actual36PairYieldNaturalAndReturnCountersRemainUnknown']=True
  return prior

 def closed37():
  prior=closed36();assert prior['actualClosedScopeCount']==36
  r=read(proposal['actual37CollectionPin']['path']);p=read(proposal['actual37PostauditPin']['path']);v=read(proposal['actualSource24CaptureOutputPin']['path']);d=read(proposal['actual37DiagnosticPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==9465 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FIRST_CAPTURE_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='capture'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['source24StagesManifestPin']['sha256']
  assert r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual37GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual37PostauditPin']['sha256'] and p['execution']==e and p['actualClosedPriorScopes']==prior
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['passedMeansSourceCaptureAndFullInverseOnly'] is p['passedMeansSourceCaptureAndFullInverseOnly'] is True
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['policy']=={'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['pgid']==479464 and e['currentGuardPid']==479394 and c.guard.process_scope.owned(e['pgid'])==[] and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['capturePath']==p['capturePath']==proposal['actualSource24CaptureOutputPin']['path'] and sha(r['capturePath'])==r['captureSha256']==p['captureSha256']==proposal['actualSource24CaptureOutputPin']['sha256']
  assert r['diagnosticPath']==p['diagnosticPath']==proposal['actual37DiagnosticPin']['path'] and sha(r['diagnosticPath'])==r['diagnosticSha256']==p['diagnosticSha256']==proposal['actual37DiagnosticPin']['sha256']
  assert r['captureBytes']==1891094 and r['diagnosticBytes']==5664984 and r['expandedSourceWorkerControllerClosureCount']==p['expandedSourceWorkerControllerClosureCount']==176
  assert v['passed'] is v['fullInverseSourceTreePassed'] is v['actualParent23CheckpointHeld'] is True and v['scope']=='ACTUAL_ROOT_SOURCE24_CAPTURE_WITH_AUTHENTIC_PARENT23_FULL_INVERSE'
  assert v['sourceOnlyProposalSha256']==stage['sourceProposal']['sha256'] and v['actualDiagnosticPath']==r['diagnosticPath'] and v['actualDiagnosticSha256']==r['diagnosticSha256']
  assert v['proposedReactElementCount']==2270 and v['genuineNewInnerPortCount']==38 and v['expectedCarrierPaths']==24 and v['missingOriginal49RequestsExpected']==25
  assert v['actualSourceTree']==d['actualProposedSource24Tree'] and v['pureSourceEvaluationExecuted'] is True
  for doc in (r,p):
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True
   for key in ('CoreCalls','nativeCalls','originalApiCalls','cliCalls','cadCalls'):assert doc[key]==0
  for key in ('typesExecuted','coreRendered','nativeExecuted','actualFreshCircuitIdsAssigned','fixReleaseQualificationPassed','originalAll11AcceptanceClaimed'):assert p[key] is False
  assert p['futureActualSource24TypesReceipt'] is p['futureActualSource24CoreReceipt'] is None
  for row in p['outputFiles']:binding(row)
  prior['actual37Source24CaptureCollectionPin']={'path':proposal['actual37CollectionPin']['path'],'sha256':proposal['actual37CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=37;prior['actual37CaptureDoesNotQualifyCoreOrNative']=True
  return prior

 def closed_prior():
  prior=closed37();assert prior['actualClosedScopeCount']==37
  r=read(proposal['actual38CollectionPin']['path']);p=read(proposal['actual38PostauditPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==95941 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_TYPES_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='types'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['source24StagesManifestPin']['sha256']
  assert r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual38GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual38PostauditPin']['sha256'] and p['execution']==e and p['actualClosedPriorScopes']==prior
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['passedMeansCompilerOnly'] is p['passedMeansCompilerOnly'] is True and r['passedMeansSourceCoreControlsOnly'] is p['passedMeansSourceCoreControlsOnly'] is False
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['policy']=={'wallSeconds':120,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['command']==['/bin/bash',stage['typesWorker']['path']]
  assert e['pgid']==480229 and e['currentGuardPid']==480096 and c.guard.process_scope.owned(e['pgid'])==[] and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['capturePath']==p['capturePath']==proposal['actualSource24CaptureOutputPin']['path'] and sha(r['capturePath'])==r['captureSha256']==p['captureSha256']==proposal['actualSource24CaptureOutputPin']['sha256']
  assert r['expandedSourceWorkerControllerClosureCount']==p['expandedSourceWorkerControllerClosureCount']==176
  assert p['rawCorePath'] is p['rawCoreSha256'] is p['coreControlsPath'] is p['coreControlsSha256'] is None
  for doc in (r,p):
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady','coreRendered'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True and doc['typesExecuted'] is True
   for key in ('CoreCalls','nativeCalls','originalApiCalls','cliCalls','cadCalls'):assert doc[key]==0
  for key in ('nativeExecuted','fixReleaseQualificationPassed','originalAll11AcceptanceClaimed'):assert p[key] is False
  assert p['futureActualSource24CoreReceipt'] is None
  for row in p['outputFiles']:binding(row)
  prior['actual38Source24TypesCollectionPin']={'path':proposal['actual38CollectionPin']['path'],'sha256':proposal['actual38CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=38;prior['actual38TypesDoesNotQualifyCoreOrNative']=True
  return prior

 def closed39():
  prior=closed_prior();assert prior['actualClosedScopeCount']==38
  for name in ('actual39CollectionPin','actual39PostauditPin','actualCoreRawPin','actualCoreControlsPin'):
   assert isinstance(proposal.get(name),dict),'Actual collected Core39 is required; draft future pins refuse execution'
   binding(proposal[name])
  r=read(proposal['actual39CollectionPin']['path']);p=read(proposal['actual39PostauditPin']['path']);v=read(proposal['actualCoreControlsPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==43066
  assert r['toolWrapperExitCode']==r['toolExitCode']==0 and r['scope']==p['scope']=='ROOT_SOURCE24_CORE_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='core'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['source24StagesManifestPin']['sha256']
  assert r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual39GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual39PostauditPin']['sha256'] and p['execution']==e and p['actualClosedPriorScopes']==prior
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['passedMeansSourceCoreControlsOnly'] is p['passedMeansSourceCoreControlsOnly'] is True and r['passedMeansCompilerOnly'] is p['passedMeansCompilerOnly'] is False
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['policy']=={'wallSeconds':180,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',stage['coreWorker']['path'],proposal['actualCoreRawPin']['path'],proposal['actualCoreControlsPin']['path'],proposal['actualSource24CaptureOutputPin']['path']]
  assert e['pgid']==480874 and e['currentGuardPid']==480851 and c.guard.process_scope.owned(e['pgid'])==[] and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['rawCorePath']==p['rawCorePath']==proposal['actualCoreRawPin']['path'] and sha(r['rawCorePath'])==r['rawCoreSha256']==p['rawCoreSha256']==proposal['actualCoreRawPin']['sha256']
  assert r['coreControlsPath']==p['coreControlsPath']==proposal['actualCoreControlsPin']['path'] and sha(r['coreControlsPath'])==r['coreControlsSha256']==p['coreControlsSha256']==proposal['actualCoreControlsPin']['sha256']
  assert v['scope']=='ROOT_FRESH_EDITABLE_SOURCE_CORE_OWNER_MOVED_227_JOINT24' and v['rawCorePath']==r['rawCorePath'] and v['rawCoreSha256']==r['rawCoreSha256']
  assert v['freshCoreControlPassed'] is True and len(v['checks'])==29 and all(x['passed'] is True for x in v['checks'])
  assert v['expectedOriginalCarrierCount']==24 and v['expectedMissingOriginalSignalCount']==25 and len(v['carriers'])==24 and len(v['actualSourcePortMatches']['registrations'])==38
  assert len(v['componentProjection'])==280 and len(v['viaProjection'])==227 and len(v['referenceProjection'])==165 and len(v['landProjection'])==1165 and len(v['signalTopProjection'])==98
  for doc in (r,p):
   assert doc['CoreCalls']==1 and doc['coreRendered'] is True and doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady','nativeExecuted'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True
  for row in p['outputFiles']:binding(row)
  prior['actual39Source24CoreCollectionPin']={'path':proposal['actual39CollectionPin']['path'],'sha256':proposal['actual39CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=39;prior['actual39CoreDoesNotQualifyNativeOrApi']=True
  return prior

 def closed40():
  prior=closed39();assert prior['actualClosedScopeCount']==39
  r=read(proposal['actual40CollectionPin']['path']);p=read(proposal['actual40PostauditPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==10372 and r['toolWrapperExitCode']==2 and r['toolExitCode']==-15
  assert r['scope']==p['scope']=='ROOT_SOURCE24_NATIVE18_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='native'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['nativePreparationPin']['sha256']
  assert r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual40GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual40PostauditPin']['sha256'] and p['execution']==e and p['actualClosedPriorScopes']==prior
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p)
  assert e['exitCode']==-15 and e['diagnosticStopped'] is True and e['accepted'] is False and e['stopReasons']==[] and e['guardError']=='RuntimeError'
  assert e['policy']=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['cleanupOwnedGroupEmpty'] is True and e['signalErrors']==[] and e['signalErrorCount']==0 and e['endedAt'] and e['wallSeconds']>0
  assert isinstance(e['oomDelta'],dict) and bool(e['oomDelta']) and not any(e['oomDelta'].values())
  assert e['pgid']==e['pid']==481468 and e['currentGuardPid']==481462 and c.guard.process_scope.owned(481468)==[] and not Path('/proc/481462').exists()
  assert e['freshLeaderIdentity']=={'pid':481468,'pgid':481468,'sid':481468,'start':23675899,'state':'R','rss':12288,'argv':[]}
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['runFailure']==p['runFailure']=='RuntimeError: Fresh owned leader command/session differs' and r['postverificationFailure'] is p['postverificationFailure'] is None
  assert r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is r['resultPassed'] is p['resultPassed'] is r['passed'] is p['passed'] is False
  assert r['nativeCalls'] is p['nativeCalls'] is None and r['reportSha256'] is p['reportSha256'] is None and r['reportPath']==p['reportPath'] and not Path(r['reportPath']).exists()
  assert r['nativeResultUnknown'] is r['identityRefusalIsNotPhysicalCheckFailure'] is r['identityRefusalCauseNotEstablished'] is True
  assert proposal['actual40ChildLogPin']['bytes']==r['childLogBytes']==0
  assert sha(r['boundManifestPath'])==r['boundManifestSha256']==r['packetSha256']==p['packetSha256']==proposal['actual40BoundManifestPin']['sha256']
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',contract['workerPin']['path'],proposal['actual40BoundManifestPin']['path'],proposal['actual40BoundManifestPin']['sha256'],proposal['actual40AuthorityPin']['path'],proposal['actual40AuthorityPin']['sha256'],r['reportPath']]
  assert r['actualCoreSha256']==p['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256']
  for doc in (r,p):
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady','coreRendered'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True and doc['CoreCalls']==0 and doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0
  for row in p['outputFiles']:binding(row)
  prior['actual40NativeIdentityRefusalCollectionPin']={'path':proposal['actual40CollectionPin']['path'],'sha256':proposal['actual40CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=40;prior['actual40NativeResultUnknownNotPhysicalFailure']=True;prior['actual40IdentityRefusalCauseUnestablished']=True
  return prior

 def closed41():
  prior=closed40();assert prior['actualClosedScopeCount']==40
  for name in ('actual41CollectionPin','actual41PostauditPin','actualNativeReportPin','actualNativeBoundManifestPin'):
   assert isinstance(proposal.get(name),dict),'Genuine collected Native success is required; future pins refuse execution'
   binding(proposal[name])
  r=read(proposal['actual41CollectionPin']['path']);p=read(proposal['actual41PostauditPin']['path']);v=read(proposal['actualNativeReportPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==80755 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_NATIVE18_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='native'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['nativePreparationPin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual41GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual41PostauditPin']['sha256'] and p['execution']==e and p['actualClosedPriorScopes']==prior
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter'] and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['policy']=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',contract['workerPin']['path'],proposal['actualNativeBoundManifestPin']['path'],proposal['actualNativeBoundManifestPin']['sha256'],proposal['actualNativeAuthorityPin']['path'],proposal['actualNativeAuthorityPin']['sha256'],proposal['actualNativeReportPin']['path']]
  assert e['pgid']==481983 and e['currentGuardPid']==481960 and c.guard.process_scope.owned(481983)==[] and not Path('/proc/481960').exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['reportPath']==p['reportPath']==proposal['actualNativeReportPin']['path'] and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actualNativeReportPin']['sha256']
  assert r['packetSha256']==p['packetSha256']==v['packetSha256']==proposal['actualNativeBoundManifestPin']['sha256'] and sha(r['boundManifestPath'])==r['boundManifestSha256']==proposal['actualNativeBoundManifestPin']['sha256']
  assert v['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and v['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256'] and v['coreSourceManifestSha256']==proposal['source24StagesManifestPin']['sha256']
  assert v['checkCount']==18 and v['physicalErrors']==0 and v['physicalCpuRamConnectedCarrierCount']==24 and v['actualNativePairFindings']==[] and not any(v['counts'].values())
  for doc in (r,p):
   assert doc['nativeCalls']==18 and doc['CoreCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0 and doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key] is False
  for row in p['outputFiles']:binding(row)
  prior['actual41NativeSuccessCollectionPin']={'path':proposal['actual41CollectionPin']['path'],'sha256':proposal['actual41CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=41;prior['actual41NativePassDoesNotQualifyApiOrCad']=True
  return prior

 def closed42():
  prior=closed41();assert prior['actualClosedScopeCount']==41
  r=read(proposal['actual42CollectionPin']['path']);p=read(proposal['actual42PostauditPin']['path']);v=read(proposal['actualApiReportPin']['path']);pe=p['projectionExecution'];ae=p['apiExecution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==76367 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH49_PROJECTION_AND_API111_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='api'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['apiPreparationPin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual42GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual42PostauditPin']['sha256'] and p['actualClosedPriorScopes']==prior and r['execution']==p['execution']==ae
  assert r['projectionExecution']==pe and r['apiExecution']==ae
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter'] and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p)
  for e,pgid,wall in ((pe,483260,60),(ae,483278,90)):
   h.finite(e,0);assert e['policy']=={'wallSeconds':wall,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
   assert e['pgid']==pgid and e['currentGuardPid']==483233 and c.guard.process_scope.owned(pgid)==[] and not Path('/proc/483233').exists()
  assert r['independentlyObservedProjectionGroupEmpty'] is r['independentlyObservedApiGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  for key in ('projectionOwnedChildWaitReturned','projectionOwnedGroupEmptyActuallyObserved','apiOwnedGroupEmptyActuallyObserved','bothOwnedGroupsIndependentlyObservedEmpty','projectionBeforeApiSeriallyEnforced'):assert r[key] is p[key] is True
  assert pe['endedAt']<=ae['startedAt'] and r['reportPath']==p['reportPath']==proposal['actualApiReportPin']['path'] and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actualApiReportPin']['sha256']
  assert r['packetSha256']==p['packetSha256']==v['packetSha256'] and v['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and v['actualNativeReportSha256']==proposal['actualNativeReportPin']['sha256']
  assert v['allOriginalApiLoaded24ChecksPassed'] is True and v['actualCompleteOriginalSignalCount']==24 and v['expectedMissingOriginalSignalCount']==25
  assert v['checkInventory']['primaryBooleanPredicates']==108 and v['checkInventory']['secondaryDqs1BooleanPredicates']==3 and v['checkInventory']['primaryPlusSecondaryBooleanPredicates']==111
  assert p['actualFresh49Model']==proposal['actualFresh49ModelPin'] and p['actualFresh49ProjectionProof']==proposal['actualFresh49ProofPin']
  assert v['original49Input']=={k:proposal['actualFresh49ModelPin'][k]for k in ('path','sha256')}
  proof=read(proposal['actualFresh49ProofPin']['path']);assert proof['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and proof['actualNativeReportSha256']==proposal['actualNativeReportPin']['sha256'] and proof['constructorInputSha256']==proposal['actualFresh49ModelPin']['sha256'] and proof['exactFullInverseToFresh24Parent'] is True
  for doc in (r,p):
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True and doc['CoreCalls']==doc['nativeCalls']==doc['cliCalls']==doc['cadCalls']==0
  for row in p['outputFiles']:binding(row)
  prior['actual42Api111CollectionPin']={'path':proposal['actual42CollectionPin']['path'],'sha256':proposal['actual42CollectionPin']['sha256']};prior['actualClosedScopeCount']=42;prior['actual42TwoOwnedChildrenGenuinelyClosed']=True
  return prior

 def closed43():
  prior=closed42();assert prior['actualClosedScopeCount']==42
  for key in ('actual43CollectionPin','actual43PostauditPin','actual43GuardManifestPin','actual43AuthorityPin','actual43ChildLogPin','actual43PartialExportPin'):binding(proposal[key])
  r=read(proposal['actual43CollectionPin']['path']);p=read(proposal['actual43PostauditPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==68388 and r['toolWrapperExitCode']==2 and r['toolExitCode']==-15
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH_PINNED_CLI_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='cli'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cliPreparationPin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual43GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual43PostauditPin']['sha256'] and e==p['execution'] and p['actualClosedPriorScopes']==prior
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter'] and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p)
  assert e['exitCode']==-15 and e['diagnosticStopped'] is True and e['accepted'] is False and e['stopReasons']==['OWNED_RSS_STOP'] and 'guardError' not in e
  assert e['policy']=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['peakOwnedRssBytes']==1121136640 and e['peakOwnedRssBytes']>e['policy']['rssBytes'] and e['cleanupOwnedGroupEmpty'] is True and e['signalErrors']==[] and e['signalErrorCount']==0 and e['endedAt'] and 0<e['wallSeconds']<90
  assert isinstance(e['oomDelta'],dict) and bool(e['oomDelta']) and not any(e['oomDelta'].values())
  assert e['pgid']==e['pid']==484702 and e['currentGuardPid']==484660 and c.guard.process_scope.owned(484702)==[] and not Path('/proc/484660').exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['runFailure'] is p['runFailure'] is r['postverificationFailure'] is p['postverificationFailure'] is None
  assert r['resultInspectionFailure']==p['resultInspectionFailure']=='AssertionError: ' and r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is r['resultPassed'] is p['resultPassed'] is r['passed'] is p['passed'] is False
  assert r['cliResultUnknown'] is r['exportNotAcceptedBecauseNoNaturalCli0OrReport'] is r['resourceStopIsNotRoutingFailure'] is r['cliReportAbsent'] is True
  assert r['cliCalls'] is p['cliCalls'] is None and r['reportSha256'] is p['reportSha256'] is None and r['reportPath']==p['reportPath'] and not Path(r['reportPath']).exists()
  assert r['exportPath']==p['exportPath']==proposal['actual43PartialExportPin']['path'] and r['exportSha256']==p['exportSha256']==proposal['actual43PartialExportPin']['sha256'] and proposal['actual43PartialExportPin']['bytes']==3603790
  assert proposal['actual43ChildLogPin']['bytes']==0
  assert e['command']==[contract['pythonInterpreterPin']['path'],'-B',contract['cliWorkerPin']['path'],'--root-receipt',proposal['actual43AuthorityPin']['path'],'--root-receipt-sha256',proposal['actual43AuthorityPin']['sha256'],'--output-directory',str(Path(r['exportPath']).parent)]
  for doc in (r,p):
   assert doc['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and doc['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256']
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cadCalls']==0
  for row in p['outputFiles']:binding(row)
  prior['actual43CliResourceStopCollectionPin']={'path':proposal['actual43CollectionPin']['path'],'sha256':proposal['actual43CollectionPin']['sha256']};prior['actualClosedScopeCount']=43;prior['actual43CliCompletionUnknownResourceStopNotRoutingFailure']=True
  return prior

 def closed44():
  prior=closed43();assert prior['actualClosedScopeCount']==43
  for key in ('actual44CollectionPin','actual44PostauditPin','actual44GuardManifestPin','actual44AuthorityPin','actual44ChildLogPin','actualCliReportPin','actualCliExportPin'):binding(proposal[key])
  r=read(proposal['actual44CollectionPin']['path']);p=read(proposal['actual44PostauditPin']['path']);v=read(proposal['actualCliReportPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==8435 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH_PINNED_CLI_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='cli'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==v['sourceManifestSha256']==proposal['cliPreparationPin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual44GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual44PostauditPin']['sha256'] and e==p['execution'] and p['actualClosedPriorScopes']==prior
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter'] and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['policy']=={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['pgid']==e['pid']==485294 and e['currentGuardPid']==485259 and c.guard.process_scope.owned(485294)==[] and not Path('/proc/485259').exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['runFailure'] is p['runFailure'] is r['postverificationFailure'] is p['postverificationFailure'] is r['resultInspectionFailure'] is p['resultInspectionFailure'] is None
  assert r['reportPath']==p['reportPath']==proposal['actualCliReportPin']['path'] and r['reportSha256']==p['reportSha256']==proposal['actualCliReportPin']['sha256']
  assert r['exportPath']==p['exportPath']==proposal['actualCliExportPin']['path'] and r['exportSha256']==p['exportSha256']==proposal['actualCliExportPin']['sha256']
  assert v['scope']==cli_preparation['scope'] and v['exportPassed'] is True and v['cliExitCode']==0 and v['byteIdenticalCopyOnly'] is True and v['recognizedCircuitJsonSha256']==proposal['actualCoreRawPin']['sha256']
  assert v['outputPath']==proposal['actualCliExportPin']['path'] and v['outputSha256']==proposal['actualCliExportPin']['sha256'] and proposal['actualCliExportPin']['bytes']==3603790
  assert v['actualSourceSegmentCount']==961 and v['actualSourceOwnedCarrierCount']==24 and v['actualPhysicalViaCount']==227 and v['actualPhysicalTraceCount']==287 and v['sourceOnlyMissingRoutes']==25
  assert v['nativeAndOriginalApiStagesPassed'] is True and v['actualNativeReport']==cli_preparation['actualPrerequisites']['actualNativeReport'] and v['actualOriginalApiReport']==cli_preparation['actualPrerequisites']['actualOriginalApiReport']
  assert v['argv']==[cli_preparation['bun'],'--smol',cli_preparation['cliMainPath'],'export',str(Path(v['outputPath']).parent/'fresh-source24.circuit.json'),'--format','kicad_pcb','--output',v['outputPath'],'--disable-parts-engine']
  assert e['command']==[contract['pythonInterpreterPin']['path'],'-B',contract['cliWorkerPin']['path'],'--root-receipt',proposal['actual44AuthorityPin']['path'],'--root-receipt-sha256',proposal['actual44AuthorityPin']['sha256'],'--output-directory',str(Path(v['outputPath']).parent)]
  for key in ('originalRawEdited','sourceModuleEvaluated','sourcePortHookReplayedByCli','automaticCoreSrjUsed','complete24Accepted','referenceQualified','electricalTimingQualified','accepted49','fabricationReady'):assert v[key] is False
  for doc in (r,p):
   assert doc['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and doc['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256']
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cadCalls']==0 and doc['cliCalls']==1
  for row in p['outputFiles']:binding(row)
  prior['actual44SuccessfulCli24ExportCollectionPin']={'path':proposal['actual44CollectionPin']['path'],'sha256':proposal['actual44CollectionPin']['sha256']};prior['actualClosedScopeCount']=44;prior['actual44CliPassDoesNotQualifyCadOrFull49']=True
  return prior

 def closed45():
  prior=closed44();assert prior['actualClosedScopeCount']==44
  for key in ('actual45CollectionPin','actual45PostauditPin','actual45GuardManifestPin','actual45ResourcePin','actual45ZonePinsPin','actual45CadLogPin','actual45ZoneLogPin'):binding(proposal[key])
  r=read(proposal['actual45CollectionPin']['path']);p=read(proposal['actual45PostauditPin']['path']);ze=r['zonePinsExecution'];ce=r['cadExecution'];v=read(proposal['actual45ResourcePin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==29982 and r['toolWrapperExitCode']==2 and r['toolExitCode']==1
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH_OFFLINE_CAD_WITH44_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cliPreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual45GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual45PostauditPin']['sha256']and p['actualClosedPriorScopes']==prior and r['execution']==p['execution']==ce and p['zonePinsExecution']==ze and p['cadExecution']==ce
  assert r['sourceAndDependenciesHeld']is p['sourceAndDependenciesHeld']is p['workspaceFreeBytesFloorHeld']is p['gitMetadataHeld']is True
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  for e,pgid,wall,code in ((ze,486709,60,0),(ce,486716,90,1)):
   h.finite(e,code);assert e['policy']=={'wallSeconds':wall,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
   assert e['pgid']==e['pid']==pgid and e['currentGuardPid']==486687 and c.guard.process_scope.owned(pgid)==[]and not Path('/proc/486687').exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedZoneGroupEmpty']is r['independentlyObservedCadGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert ze['endedAt']<=ce['startedAt']and r['zonePinsChildNatural0']is p['zonePinsChildNatural0']is r['zonePinsOwnedGroupEmptyActuallyObserved']is p['zonePinsOwnedGroupEmptyActuallyObserved']is True
  assert r['cadChildNatural0']is p['cadChildNatural0']is False and r['cadOwnedGroupEmptyActuallyObserved']is p['cadOwnedGroupEmptyActuallyObserved']is r['bothOwnedGroupsIndependentlyObservedEmpty']is p['bothOwnedGroupsIndependentlyObservedEmpty']is r['zoneBeforeCadSeriallyEnforced']is p['zoneBeforeCadSeriallyEnforced']is True
  assert r['resourceGateBlockedBeforeContainer']is p['resourceGateBlockedBeforeContainer']is r['actualCadApplicationCompletionUnknown']is p['actualCadApplicationCompletionUnknown']is True
  assert r['containerAbsenceNotIndependentlyRequeried']is r['priorInitialOwnedContainerAbsenceCheckCompletedByWorker']is r['resourceFailureIsNotPhysicalCheckFailure']is r['noCadReportProduced']is r['zonePinDataDerivationPassed']is True
  assert r['ownedContainerActuallyEmpty']is p['ownedContainerActuallyEmpty']is None and r['ownedContainerName']==p['ownedContainerName']==proposal['previousScope45ContainerName']
  assert r['containerResourceObservations']==p['containerResourceObservations']==v and r['containerResourceObservationsBinding']==p['containerResourceObservationsBinding']==proposal['actual45ResourcePin']
  assert v['imageId']==cli_preparation['imageId']and v['containerName']==proposal['previousScope45ContainerName']and v['cleanupStatusRecorded']is False and v['ownedContainerActuallyEmpty']is v['containerWorkerStatus']is None
  assert v['observations']==[{'phase':'BEFORE_CONTAINER','imageId':cli_preparation['imageId'],'imageSizeBytes':1519935209,'storageDriver':'vfs','dockerRootDir':'/var/lib/docker','freeBytesActuallyObserved':3275755520,'requiredVfsBytes':3308305874,'actualVfsReserveSatisfiedAtObservation':False,'imageAlreadyPresent':True,'noImageLoadBuildPull':True}]
  assert r['runFailure']is p['runFailure']is r['postverificationFailure']is p['postverificationFailure']is None and r['resultInspectionFailure']==p['resultInspectionFailure']=='Resource receipt AssertionError: ; AssertionError: '
  assert r['stageNaturallyCompleted']is p['stageNaturallyCompleted']is r['resultPassed']is p['resultPassed']is r['passed']is p['passed']is False and r['cadCalls']is p['cadCalls']is None
  assert r['reportPath']==p['reportPath']and r['reportSha256']is p['reportSha256']is None and not Path(r['reportPath']).exists()
  zone=read(proposal['actual45ZonePinsPin']['path']);assert zone['actualCoreRawSha256']==proposal['actualCoreRawPin']['sha256']and zone['actualExportPath']==proposal['actualCliExportPin']['path']and zone['actualExportSha256']==proposal['actualCliExportPin']['sha256']and zone['actualSourceKeepoutCount']==2
  assert Path(ce['command'][1]).name=='run-kicad-offline-with-snapshots.sh'and ce['command'][1]==proposal['actual45WrapperPin']['path']and ce['command'][3]==proposal['previousScope45ContainerName']and ce['command'][6]==contract['cadWorkerPin']['path']
  for doc in (r,p):
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23']is True and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==0 and doc['zonePinsChildInvocations']==1
  for item in p['outputFiles']:binding(item)
  prior['actual45VfsReserveRefusalCollectionPin']={'path':proposal['actual45CollectionPin']['path'],'sha256':proposal['actual45CollectionPin']['sha256']};prior['actualClosedScopeCount']=45;prior['actual45CadCompletionUnknownNotPhysicalFailure']=True
  return prior
 def closed46():
  prior=closed45();assert prior['actualClosedScopeCount']==45
  for key in ('actual46CollectionPin','actual46PostauditPin','actual46GuardManifestPin','actual46ResourcePin','actual46RecoveryReportPin','actual46ZonePinsPin','actual46CadLogPin','actual46ZoneLogPin'):binding(proposal[key])
  r=read(proposal['actual46CollectionPin']['path']);p=read(proposal['actual46PostauditPin']['path']);ze=r['zonePinsExecution'];ce=r['cadExecution'];v=read(proposal['actual46ResourcePin']['path']);recovery=read(proposal['actual46RecoveryReportPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==56016 and r['toolWrapperExitCode']==2 and r['toolExitCode']==-15
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH_OFFLINE_CAD_WITH45_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cliPreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual46GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual46PostauditPin']['sha256']and p['actualClosedPriorScopes']==prior and r['execution']==p['execution']==ce and p['zonePinsExecution']==ze and p['cadExecution']==ce
  # Original exit evidence remains failed/unknown, including the broad held flag.
  assert r['sourceAndDependenciesHeld']is p['sourceAndDependenciesHeld']is r['workspaceFreeBytesFloorHeld']is p['workspaceFreeBytesFloorHeld']is r['gitMetadataHeld']is p['gitMetadataHeld']is False
  assert r['originalPostFloorAndSourceHeldBooleansPreservedFalse']is r['originalSdkInventoryBeforeAfterByteIdentical']is True
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.finite(ze,0);assert ze['policy']=={'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert ce['policy']=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5,'diskFreeGuard':{'path':'/var/lib/docker','minimumFreeBytes':134217728}}
  assert ce['exitCode']==-15 and ce['diagnosticStopped']is True and ce['stopReasons']==['OWNED_DISK_FREE_STOP']and ce['accepted']is False and ce['cleanupOwnedGroupEmpty']is True
  assert ce['signalErrors']==[]and ce['signalErrorCount']==0 and isinstance(ce['oomDelta'],dict)and bool(ce['oomDelta'])and not any(ce['oomDelta'].values())
  disk=ce['diskFreeGuard'];assert disk==r['diskFreeGuardActuallyObserved']==p['diskFreeGuardActuallyObserved']=={'path':'/var/lib/docker','minimumFreeBytes':134217728,'beforeAvailableBytes':3270901760,'minimumAvailableBytesObserved':120123392,'lastAvailableBytes':120123392,'sampleCount':274,'readErrorCount':0,'lastReadErrorType':None}
  assert disk['minimumAvailableBytesObserved']<disk['minimumFreeBytes']and 0<ce['stopElapsedSeconds']<=ce['wallSeconds']<90 and ze['endedAt']<=ce['startedAt']
  for e,pgid in ((ze,488591),(ce,488592)):
   assert e['pid']==e['pgid']==pgid and e['currentGuardPid']==488542 and c.guard.process_scope.owned(pgid)==[]and not Path('/proc/488542').exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedZoneGroupEmpty']is r['independentlyObservedCadGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert r['zonePinsChildNatural0']is p['zonePinsChildNatural0']is r['zonePinsOwnedGroupEmptyActuallyObserved']is p['zonePinsOwnedGroupEmptyActuallyObserved']is True
  assert r['cadChildNatural0']is p['cadChildNatural0']is False and r['bothOwnedGroupsIndependentlyObservedEmpty']is p['bothOwnedGroupsIndependentlyObservedEmpty']is r['zoneBeforeCadSeriallyEnforced']is p['zoneBeforeCadSeriallyEnforced']is True
  assert r['runFailure']is p['runFailure']is None and r['postverificationFailure']==p['postverificationFailure']=='AssertionError: 'and r['resultInspectionFailure']==p['resultInspectionFailure']=='Resource receipt AssertionError: ; AssertionError: '
  assert r['ownedContainerActuallyEmpty']is p['ownedContainerActuallyEmpty']is None and r['ownedContainerName']==p['ownedContainerName']==proposal['previousScope46ContainerName']
  assert r['containerResourceObservations']==p['containerResourceObservations']==v and r['containerResourceObservationsBinding']==p['containerResourceObservationsBinding']==proposal['actual46ResourcePin']
  assert v['containerName']==proposal['previousScope46ContainerName']and v['imageId']==cli_preparation['imageId']and v['cleanupStatusRecorded']is False and v['ownedContainerActuallyEmpty']is v['containerWorkerStatus']is None
  assert len(v['observations'])==1 and v['observations'][0]=={'phase':'BEFORE_CONTAINER','imageId':cli_preparation['imageId'],'imageSizeBytes':1519935209,'storageDriver':'vfs','dockerRootDir':'/var/lib/docker','freeBytesActuallyObserved':3270901760,'requiredVfsBytes':3241197010,'actualVfsReserveSatisfiedAtObservation':True,'imageAlreadyPresent':True,'noImageLoadBuildPull':True,'vfsOverheadBufferBytes':201326592,'continuousDiskMinimumFreeBytesExpected':134217728}
  assert r['resourceGateBlockedBeforeContainer']is p['resourceGateBlockedBeforeContainer']is False and r['actualCadApplicationCompletionUnknown']is p['actualCadApplicationCompletionUnknown']is r['actualCadCompletionUnknown']is r['noCadReportProduced']is r['resourceFailureIsNotPhysicalCheckFailure']is True
  assert r['originalContainerStatusAtCadGuardExitRemainsUnknown']is True and r['stageNaturallyCompleted']is p['stageNaturallyCompleted']is r['resultPassed']is p['resultPassed']is r['passed']is p['passed']is False
  assert r['reportPath']==p['reportPath']and r['reportSha256']is p['reportSha256']is r['cadCalls']is p['cadCalls']is None and not Path(r['reportPath']).exists()
  assert p['workspaceFreeBytesBefore']==3270901760 and p['workspaceFreeBytesAfter']==116445184 and r['source24Adopted']is False
  # Authenticate recovery independently; never overwrite the original POST.
  assert r['scope46IncludesTwoExplicitOwnedRecoverySubscopes']is True and r['newSdkScopeOutside46OpenedForRecovery']is False
  assert r['rootCleanupReportBinding']==proposal['actual46RecoveryReportPin']and r['rootCleanupReport']==recovery and r['ownedContainerActuallyEmptyAfterRootRecovery']is r['workspaceFloorRecoveredAfterRootCleanup']is True
  assert recovery=={'scope':'ROOT_EXACT_SCOPE46_OWNED_CONTAINER_AND_SCRATCH_CLEANUP','containerName':proposal['previousScope46ContainerName'],'ownedContainerSeenBeforeCleanup':False,'ownedContainerActuallyAbsentAfterCleanup':True,'ownedScratchPath':'/tmp/g350-source24-fresh-cad.Nl6W3d','ownedScratchRemoved':True,'originalCacheFilesVerifiedUnchanged':12057,'originalCacheSymlinksVerifiedUnchanged':451,'originalCacheBytesVerifiedUnchanged':1158893348,'imageIdHeld':cli_preparation['imageId'],'workspaceFreeBytesBefore':3270901760,'workspaceFreeBytesAfter':3270901760,'originalWorkspaceFloor':3270901760,'originalWorkspaceFloorRecovered':True,'originalPostauditHeld':True,'hardwareOrSourceOrSdkOrOriginalCacheEdited':False,'accepted49':False,'fabricationReady':False}
  attempts=r['rootCleanupAttempts'];assert attempts==proposal['actual46RootCleanupAttempts']and len(attempts)==2
  for attempt,session,code,wrapper,pgid,guard,outcome in zip(attempts,(30363,35917),(1,0),(2,0),(489356,489466),(489355,489465),('OWNED_CONTAINER_CLEANUP_THEN_CACHE_SYMLINK_ASSERTION_REFUSAL','EXACT_OWNED_CLEANUP_AND_ORIGINAL_CACHE_VERIFY_PASS')):
   for key in('executionPin','logPin','sourcePin'):binding(attempt[key])
   e=attempt['execution'];assert read(attempt['executionPin']['path'])==e and attempt['toolSessionCollected']is True and attempt['toolSessionId']==session and attempt['toolWrapperExitCode']==wrapper and attempt['result']==outcome
   h.finite(e,code);assert e['policy']=={'wallSeconds':60,'rssBytes':268435456,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
   assert e['pid']==e['pgid']==pgid and e['currentGuardPid']==guard and c.guard.process_scope.owned(pgid)==[]and not Path('/proc',str(guard)).exists()and attempt['independentlyObservedGroupEmptyAndGuardAbsent']is True
   assert e['command']==['/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3','-B',attempt['sourcePin']['path']]
  assert attempts[0]['execution']['endedAt']<=attempts[1]['execution']['startedAt']and ce['endedAt']<=attempts[0]['execution']['startedAt']
  assert r['actualDiskFloorStopObserved']is r['diskSamplingIsNotKernelReservation']is True
  zone=read(proposal['actual46ZonePinsPin']['path']);assert zone['actualCoreRawSha256']==proposal['actualCoreRawPin']['sha256']and zone['actualExportPath']==proposal['actualCliExportPin']['path']and zone['actualExportSha256']==proposal['actualCliExportPin']['sha256']and zone['actualSourceKeepoutCount']==2
  for doc in(r,p):
   for key in('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23']is True and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==0 and doc['zonePinsChildInvocations']==1
  for item in p['outputFiles']:binding(item)
  prior['actual46RecoveredDiskFloorStopCollectionPin']={'path':proposal['actual46CollectionPin']['path'],'sha256':proposal['actual46CollectionPin']['sha256']};prior['actualClosedScopeCount']=46;prior['actual46CadCompletionUnknownWithSeparateRecovery']=True
  return prior

 def closed47():
  prior=closed46();assert prior['actualClosedScopeCount']==46
  for key in('actual47CollectionPin','actual47PostauditPin','actual47ResultPin','actual47GuardManifestPin','actual47ResourcePin'):binding(proposal[key])
  r=read(proposal['actual47CollectionPin']['path']);p=read(proposal['actual47PostauditPin']['path']);v=read(proposal['actual47ResultPin']['path']);ze=r['zonePinsExecution'];ce=r['cadExecution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==83144 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH_OFFLINE_CAD_WITH46_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cliPreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual47GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual47PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['execution']==p['execution']==ce and p['zonePinsExecution']==ze and p['cadExecution']==ce
  for doc in(r,p):
   for key in('sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','stageNaturallyCompleted','resultPassed','passed','zonePinsChildNatural0','cadChildNatural0','bothOwnedGroupsIndependentlyObservedEmpty','zoneBeforeCadSeriallyEnforced','ownedGroupEmptyActuallyObserved','zonePinsOwnedGroupEmptyActuallyObserved','cadOwnedGroupEmptyActuallyObserved','ownedContainerActuallyEmpty'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('resourceGateBlockedBeforeContainer','actualCadApplicationCompletionUnknown','source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['sourceNativeCheckedCountRemains23']is True and doc['newRoutesAdopted']==0 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==0 and doc['cadCalls']==1 and doc['zonePinsChildInvocations']==1
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  for execution,pgid,wall in((ze,490917,60),(ce,490934,90)):
   h.finite(execution,0);assert execution['pid']==execution['pgid']==pgid and execution['currentGuardPid']==490869 and c.guard.process_scope.owned(pgid)==[]and not Path('/proc/490869').exists()
   expected={'wallSeconds':wall,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
   if pgid==490934:expected['diskFreeGuard']={'path':'/var/lib/docker','minimumFreeBytes':134217728}
   assert execution['policy']==expected
  assert ze['endedAt']<=ce['startedAt']and r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedZoneGroupEmpty']is r['independentlyObservedCadGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert r['reportPath']==p['reportPath']==proposal['actual47ResultPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual47ResultPin']['sha256']and r['actualCadReportPin']==proposal['actual47ResultPin']
  assert r['actualCoreSha256']==p['actualCoreSha256']==proposal['actualCoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256']
  assert v['scope']=='SOURCE24_FRESH_CLI_AND_KICAD_WITH_ACTUAL_CORE_NATIVE_API_BINDINGS'and v['sourceManifestSha256']==proposal['cliPreparationPin']['sha256']and v['passed']is v['diagnosticCompleted']is v['nativeAndOriginalApiStagesPassed']is v['allInputBytesHeld']is True
  assert v['actualCorePath']==proposal['actualCoreRawPin']['path']and v['actualCoreSha256']==proposal['actualCoreRawPin']['sha256']and v['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256']and v['actualExportPath']==proposal['actualCliExportPin']['path']and v['actualExportSha256']==proposal['actualCliExportPin']['sha256']
  assert v['actualDerivedSourceSegmentCount']==961 and v['actualSourceOwnedGraphCount']==v['actual24NonzeroNetGraphCount']==v['actual24PhysicalCpuRamGraphCount']==24 and v['expectedMissingOriginalSignalCount']==25
  assert v['all287SourceTracesMappedBijectively']is True and v['actualLocalNetAgreementCount']==v['actualLocalPhysicalApproachCount']==98 and v['actualLoadedLayerCount']==4 and v['actualRetainedNativeHardwareKeepoutZones']==2 and v['actualNativeCopperPourZones']==0
  for key in('sourceRawOrSdkEdited','rawExportEdited','netRepairPerformed','saveBoardPerformed','refillPerformed','allRuleDrcPerformed','referenceQualified','electricalTimingQualified','accepted49','fabricationReady','complete24Accepted'):assert v[key]is False
  resource=read(proposal['actual47ResourcePin']['path']);assert r['containerResourceObservations']==p['containerResourceObservations']==resource and r['containerResourceObservationsBinding']==p['containerResourceObservationsBinding']==proposal['actual47ResourcePin']
  assert r['ownedContainerName']==p['ownedContainerName']==resource['containerName']==proposal['previousScope47ContainerName']and resource['imageId']==cli_preparation['imageId']and resource['ownedContainerActuallyEmpty']is resource['cleanupStatusRecorded']is True and resource['containerWorkerStatus']==0
  assert resource['previousScope45ContainerAbsenceCheckPassed']is resource['previousScope46ContainerAbsenceCheckPassed']is True and [x['phase']for x in resource['observations']]==['BEFORE_CONTAINER','AFTER_CLEANUP']
  assert all(x['imageId']==cli_preparation['imageId']and x['imageAlreadyPresent']is x['noImageLoadBuildPull']is x['actualVfsReserveSatisfiedAtObservation']is True for x in resource['observations'])
  assert r['ownedContainerAbsenceActuallyObservedByOwnedWorkerAfterCleanup']is r['rootDidNotIndependentlyRequeryDockerAfterNaturalWrapperExit']is True
  disk=r['diskFreeGuardActuallyObserved'];assert disk==p['diskFreeGuardActuallyObserved']==ce['diskFreeGuard']and disk['minimumAvailableBytesObserved']==445816832 and disk['minimumAvailableBytesObserved']>=disk['minimumFreeBytes']==134217728 and disk['readErrorCount']==0
  for item in p['outputFiles']:binding(item)
  prior['actual47SuccessfulSource24CadCollectionPin']={'path':proposal['actual47CollectionPin']['path'],'sha256':proposal['actual47CollectionPin']['sha256']};prior['actualClosedScopeCount']=47;prior['actual47CadPartial24OnlyNotFull49OrElectrical']=True
  return prior

 def guard_identity():
  row=process_runner.process(os.getpid());assert row is not None and row['pid']==os.getpid()
  return {k:row[k]for k in('pid','pgid','sid','start','argv')}
 def file_row(path):
  p=Path(path);s=p.lstat();assert p.is_file()and not p.is_symlink()and stat.S_ISREG(s.st_mode)
  return dict(path=str(p),sha256=sha(p),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
 def read_bounded(path,limit):
  p=Path(path);assert p.is_file()and not p.is_symlink()and 0<p.stat().st_size<=limit
  return read(p)
 def inspect_capture(paths):
  capture,diagnostic=paths['capture'],paths['diagnostic'];r=read_bounded(capture,5242880);d=read_bounded(diagnostic,7340032)
  assert r['scope']=='ACTUAL_ROOT_SOURCE26_CAPTURE_WITH_PARENT24_FULL_INVERSE'and d['scope']=='ACTUAL_SOURCE26_AND_PARENT24_BEFORE_INVERSE_ASSERTIONS'
  for key in('passed','fullInverseSourceTreePassed','actualParent24DeclarationsHeld','original49LogicalTracesHeld','original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse','pureSourceEvaluationExecuted','automaticCoreSrjForThisForkMustNotBeUsed','bothDqs1CoupledViewsRequireFreshOriginalApi'):assert r[key]is True
  for key,value in dict(proposedReactElementCount=2272,previousReactElementCount=2270,genuineNewInnerPortCount=40,exactNewPortDeclarations=2,exactChangedOriginalRouteDeclarations=2,exactChangedLocalSuppressions=4,exactMovedExistingViaCount=1,expectedPhysicalVias=227,expectedPhysicalTraces=289,expectedCarrierPaths=26,missingOriginal49RequestsExpected=23).items():assert r[key]==value
  assert r['movedViaName']=='V_TI_SIGNAL_source_trace_3_0'and r['movedViaCapturedPriorIdProvenanceOnly']=='pcb_via_135'and r['sourceOnlyProposalSha256']==proposal['promoted26ProposalPin']['sha256']
  assert r['actualDiagnosticPath']==str(diagnostic)and r['actualDiagnosticSha256']==sha(diagnostic)and r['actualSourceTree']==d['actualProposedSource26Tree']
  assert d['actualParent24Tree']==read(data26['inputBindings']['actualParent24Capture']['path'])['actualSourceTree']
  assert d['beforeCounts']['reactElements']==2270 and d['afterCounts']['reactElements']==2272 and d['beforeCounts']['unsupported']==d['afterCounts']['unsupported']==0 and d['inverseChecksExecuted']is False
  for key in('circuitConstructed','coreRendered','all49Accepted','fabricationReady'):assert r[key]is d[key]is False
  for key in('source24QualificationInherited','nativeExecuted','cadExecuted','singleCoupledSectionCoversBoth','referenceQualified','electricalTimingPassed'):assert r[key]is False
  return dict(sourceCapturePin=file_row(capture),sourceDiagnosticPin=file_row(diagnostic),fullSourceInversePassed=True,CoreExecuted=False)
 def inspect_core(paths,capture_pin):
  raw,controls=paths['raw'],paths['controls'];core=read_bounded(raw,16777216);r=read_bounded(controls,4194304)
  assert isinstance(core,list)and r['scope']=='ROOT_FRESH_EDITABLE_SOURCE_CORE_OWNER_MOVED_227_RESET_SOURCE3_26'
  assert r['rawCorePath']==str(raw)and r['rawCoreSha256']==sha(raw)and r['actualCapturePath']==capture_pin['path']and r['actualCaptureSha256']==capture_pin['sha256']
  assert r['freshCoreControlPassed']is True and len(r['checks'])==29 and all(x['passed']is True for x in r['checks'])
  expected={'source_component':280,'source_trace':1195,'pcb_component':507,'pcb_smtpad':1161,'pcb_plated_hole':4,'pcb_hole':2,'pcb_via':227,'source_manually_placed_via':227,'pcb_trace':289,'source_port':1655,'pcb_port':1655,'source_net':98,'source_bus':8,'pcb_keepout':2}
  for kind,count in expected.items():assert sum(row['type']==kind for row in core)==count
  assert len(r['carriers'])==26 and all(x['passed']is True for x in r['carriers'])and len(r['signalTopProjection'])==98 and all(x['passed']is True for x in r['signalTopProjection'])
  assert len(r['original49Projection'])==49 and all(x['passed']is True for x in r['original49Projection'])and len(r['viaProjection'])==227 and all(x['passed']is True for x in r['viaProjection'])
  assert len(r['actualSourcePortMatches']['registrations'])==40 and r['expectedOriginalCarrierCount']==26 and r['expectedMissingOriginalSignalCount']==23 and r['actualNonzeroWireSegmentCount']==1001
  event=r['source3OwnerEvent'];assert event['sourceViaName']=='V_TI_SIGNAL_source_trace_3_0'and event['capturedPriorViaIdProvenanceOnly']=='pcb_via_135'and event['freshIdsDerivedFromActualCore']is True and event['capturedIdAssignedToFreshCore']is False
  vp=event['actualViaProjection'];sp=event['actualTopStubProjection'];cp=event['actualCarrierProjection'];assert vp['passed']is sp['passed']is cp['passed']is True and sp['originalSourceTraceId']==cp['originalSourceTraceId']=='source_trace_3'and sp['side']==0
  via=[v for v in core if v['type']=='pcb_via'and v['pcb_via_id']==vp['actualViaId']];assert len(via)==1 and abs(via[0]['x']-6.2)<1e-8 and abs(via[0]['y']-12.4)<1e-8 and via[0]['layers']==['top','inner1','inner2','bottom']and via[0]['outer_diameter']==.4572 and via[0]['hole_diameter']==.254
  stub=[v for v in core if v['type']=='pcb_trace'and v['pcb_trace_id']==sp['actualPcbTraceId']];assert len(stub)==1 and len(stub[0]['route'])==4 and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in stub[0]['route'])
  for key in('sourceNumericAndPhysicalIdsDerivedWithoutAssignment','pcbRoutingDisabled','authoredPourLiteralsHeldByActualSourceInverse','manualPairSourceBusForkHeld','automaticCoreSrjForThisForkMustNotBeUsed','originalCouplingApisRequiredAgainstFreshActualGeometry'):assert r[key]is True
  for key in('circuitJsonGeometryEdited','parent24ActualQualificationInherited','nativeExecuted','cadExecuted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert r[key]is False
  return dict(rawCorePin=file_row(raw),coreControlsPin=file_row(controls),all29CorePredicatesPassed=True,actualCandidateCarrierCount=26,nativeQualificationPerformed=False)

 def closed48():
  prior=closed47();assert prior['actualClosedScopeCount']==47
  for key in('actual48CollectionPin','actual48PostauditPin','actual48CapturePin','actual48DiagnosticPin','actual48CoreRawPin','actual48CoreControlsPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert len(proposal['actual48PhasePostauditPins'])==3
  for row in proposal['actual48PhasePostauditPins']:binding(row)
  r=read(proposal['actual48CollectionPin']['path']);p=read(proposal['actual48PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual48ToolSessionId'])is int and r['toolSessionId']==proposal['actual48ToolSessionId']and r['toolWrapperExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE26_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH47_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='capture-types-core-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual48GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual48PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert len(p['phases'])==3 and p['orderedPhaseNames']==p['expectedPhaseNames']==['capture','types','core']and p['notAttemptedPhaseNames']==[]
  identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()
  for doc in(r,p):
   for key in('historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','allThreeChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansCaptureStrictTypesAndRawCore29Only','batchScopeContainsThreeSerialOwnedChildren','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('batchFailure','finalVerificationFailure'):assert doc[key]is None
   for key in('Source26Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
   assert doc['newRoutesAdopted']==0 and doc['CoreCalls']==doc['CoreChildInvocations']==doc['captureChildInvocations']==doc['typesChildInvocations']==1 and doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  previous=None;owned=[]
  for phase,row,pin in zip(('capture','types','core'),p['phases'],proposal['actual48PhasePostauditPins']):
   assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
   for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and sha(pin['path'])==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   e=row['execution'];h.finite(e,0);assert e['policy']==batch['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and c.guard.process_scope.owned(e['pgid'])==[]and e['pgid']not in owned
   owned.append(e['pgid'])
   if previous is not None:assert previous['endedAt']<=e['startedAt']
   previous=e
   for output in row['outputFiles']:binding(output)
   for key in('Source26Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
   assert row['nativeCalls']==row['originalApiCalls']==row['cliCalls']==row['cadCalls']==0
  capture,types,core=p['phases'];assert capture['result']['sourceCapturePin']==proposal['actual48CapturePin']and capture['result']['sourceDiagnosticPin']==proposal['actual48DiagnosticPin']and core['result']['rawCorePin']==proposal['actual48CoreRawPin']and core['result']['coreControlsPin']==proposal['actual48CoreControlsPin']
  assert capture['result']==inspect_capture(dict(capture=Path(proposal['actual48CapturePin']['path']),diagnostic=Path(proposal['actual48DiagnosticPin']['path'])))
  assert types['result']==dict(strictNoEmitTypecheckNatural0=True,actualPriorCapturePin=proposal['actual48CapturePin'])and types['outputFiles']==[]
  assert core['result']==inspect_core(dict(raw=Path(proposal['actual48CoreRawPin']['path']),controls=Path(proposal['actual48CoreControlsPin']['path'])),proposal['actual48CapturePin'])
  bun=str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe')
  assert capture['command']==[bun,'--smol',proposal['promoted26CapturePin']['path'],proposal['actual48CapturePin']['path'],proposal['actual48DiagnosticPin']['path']]
  assert types['command']==['bash',proposal['promoted26TypesPin']['path']]
  assert core['command']==[bun,'--smol',proposal['promoted26CorePin']['path'],proposal['actual48CoreRawPin']['path'],proposal['actual48CoreControlsPin']['path'],proposal['actual48CapturePin']['path']]
  prior['actual48Source26ThreeSerialCaptureTypesCoreCollectionPin']={'path':proposal['actual48CollectionPin']['path'],'sha256':proposal['actual48CollectionPin']['sha256']};prior['actualClosedScopeCount']=48;prior['actual48ThreeChildrenDoNotQualifyNativeOrFull49']=True
  return prior

 def closed49():
  prior=closed48();assert prior['actualClosedScopeCount']==48
  for key in('actual49CollectionPin','actual49PostauditPin','actual49ReportPin','actual49BoundManifestPin','actual49AuthorityPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  r=read(proposal['actual49CollectionPin']['path']);p=read(proposal['actual49PostauditPin']['path']);v=read(proposal['actual49ReportPin']['path']);e=r['execution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual49ToolSessionId'])is int and r['toolSessionId']==proposal['actual49ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE26_NATIVE18_WITH_AUTHENTIC_48_THREE_STAGE_PRIOR_CLOSURES'and r['phase']==p['phase']=='native'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['native26PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual49GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual49PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['execution']==e
  for doc in(r,p):
   for key in('passed','resultPassed','stageNaturallyCompleted','ownedChildNatural0','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','baseline169SourceHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passedMeansNative18AndActual26NumericPhysicalGraphsOnly','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('Source26Accepted','referenceQualified','electricalTimingPassed','fixReleaseQualificationPassed','originalAll11AcceptanceClaimed','all49Accepted','accepted49','fabricationReady','typesExecuted','coreRendered'):assert doc[key]is False
   assert doc['expandedSourceWorkerControllerClosureCount']==181 and doc['nativeCalls']==18 and doc['CoreCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(e,0);assert e['policy']==native_contract['policy']and type(e['pgid'])is int and e['pgid']>0 and c.guard.process_scope.owned(e['pgid'])==[]and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert r['reportPath']==p['reportPath']==proposal['actual49ReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual49ReportPin']['sha256']
  assert r['boundManifestPath']==p['boundManifestPath']==proposal['actual49BoundManifestPin']['path']and sha(r['boundManifestPath'])==r['boundManifestSha256']==p['boundManifestSha256']==r['packetSha256']==p['packetSha256']==v['packetSha256']==proposal['actual49BoundManifestPin']['sha256']
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',native_contract['workerPin']['path'],proposal['actual49BoundManifestPin']['path'],proposal['actual49BoundManifestPin']['sha256'],proposal['actual49AuthorityPin']['path'],proposal['actual49AuthorityPin']['sha256'],proposal['actual49ReportPin']['path']]
  assert r['coreSourceManifestSha256']==p['coreSourceManifestSha256']==v['coreSourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and r['actualCorePath']==p['actualCorePath']==v['actualCorePath']==proposal['actual48CoreRawPin']['path']and r['actualCoreSha256']==p['actualCoreSha256']==v['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==v['actualCoreControlsSha256']==proposal['actual48CoreControlsPin']['sha256']
  assert v['scope']=='ACTUAL_FRESH_MOVED26_CORE289_NATIVE18_PHYSICAL_AND_NUMERIC_OWNER_GRAPH_QUALIFICATION'and v['sourceManifestSha256']==proposal['native26PreparationPin']['sha256']and v['originalSource26ProposalSha256']==proposal['promoted26ProposalPin']['sha256']
  assert v['checkCount']==len(v['counts'])==18 and not any(v['counts'].values())and v['physicalErrors']==0 and v['physicalCpuRamConnectedCarrierCount']==26 and v['expectedMissingOriginalSignalCount']==23 and v['actualNativePairFindings']==[]
  proof=v['actualOwnershipProof'];assert len(proof['signalMappings'])==98 and len(proof['referenceMappings'])==165 and len(proof['carriers'])==26 and all(x['actualSourceOwnedPhysicalGraph']['physicallyConnected']is x['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is True for x in proof['carriers'])
  for key in('all165ReferencePathsPreserved','all129ReferenceBarrelsPreserved','all98SignalBarrelsAndSource26TopStubsProved','source14RamBarrelAndTopStubChangedOnlyAsExplicitlyProposed','source3CpuBarrelAndFourPointTopStubChangedOnlyAsExplicitlyProposed','source27And28CarriersChangedOnlyAsExplicitlyProposed','all49OriginalLogicalNumericRequestsPreserved','rawCircuitUnmodified','onlyAuthenticRam25Hs8PadAndStripContactRegistered','originalAll3CouplingApisAgainstActualGeometryRequiredSeparately','noCoreRenderPerformed','noRoutingPerformed','noCliOrCadPerformed','full49RoutesUnfinished'):assert v[key]is True
  for key in('circuitJsonGeometryOrIdentitiesEdited','sourceNetFabricationPerformed','globalSameNetManufacturingExemption','fullCohortTimingPassed','electricalTimingQualified','referenceQualified','complete26Accepted','accepted49','fabricationReady'):assert v[key]is False
  for row in p['outputFiles']:binding(row)
  prior['actual49Native26PhysicalSuccessCollectionPin']={'path':proposal['actual49CollectionPin']['path'],'sha256':proposal['actual49CollectionPin']['sha256']};prior['actualClosedScopeCount']=49;prior['actual49NativeDoesNotQualifyOriginalApisCliCadOrFull49']=True
  return prior

 def closed50():
  prior=closed49();assert prior['actualClosedScopeCount']==49
  for key in('actual50CollectionPin','actual50PostauditPin','actual50ModelPin','actual50ProofPin','actual50ApiReportPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert len(proposal['actual50PhasePostauditPins'])==2
  for pin in proposal['actual50PhasePostauditPins']:binding(pin)
  r=read(proposal['actual50CollectionPin']['path']);p=read(proposal['actual50PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual50ToolSessionId'])is int and r['toolSessionId']==proposal['actual50ToolSessionId']and r['toolWrapperExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE26_FRESH49_PROJECTION_AND_ORIGINAL_API119_WITH49_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='projection-api-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['native26PreparationPin']['sha256']and r['coreSourceManifestSha256']==p['coreSourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual50GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual50PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert len(p['phases'])==2 and p['orderedPhaseNames']==p['expectedPhaseNames']==['projection','api']and p['notAttemptedPhaseNames']==[]
  identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()
  for doc in(r,p):
   for key in('guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','bothChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansFresh49ProjectionAndOriginalLoaded26Api119Only','hardwareAcceptanceCheckpointUnchanged','projectionPassed','apiPassed','projectionBeforeApiSeriallyEnforced','originalApiMethodInvocationCountNotInstrumented'):assert doc[key]is True
   for key in('batchFailure','finalVerificationFailure','originalApiCalls'):assert doc[key]is None
   for key in('Source26Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['originalApiBooleanPredicates']==119 and doc['CoreCalls']==doc['nativeCalls']==doc['cliCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  owned=[];previous=None
  for phase,row,pin in zip(('projection','api'),p['phases'],proposal['actual50PhasePostauditPins']):
   assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
   for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   e=row['execution'];h.finite(e,0);assert e['policy']==api26_contract['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and e['pgid']not in owned and c.guard.process_scope.owned(e['pgid'])==[];owned.append(e['pgid'])
   if previous is not None:assert previous['endedAt']<=e['startedAt']
   previous=e
   binding(row['packetPin'])
   if row['authorityPin']is not None:binding(row['authorityPin'])
   for output in row['outputFiles']:binding(output)
   for key in('Source26Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
   assert row['CoreCalls']==row['nativeCalls']==row['cliCalls']==row['cadCalls']==0
  projection,api=p['phases'];assert p['projectionExecution']==projection['execution']and p['apiExecution']==api['execution']and len(projection['outputFiles'])==5 and len(api['outputFiles'])==1
  assert projection['result']==dict(actualFresh49Model=proposal['actual50ModelPin'],actualFresh49ProjectionProof=proposal['actual50ProofPin'],source26FreshFull49ProjectionPassed=True,actual49Requests=49,actualFixedTraces=263,actualHardObstacles=1298,actualSignalViaEvents=98,zeroSelected26CarrierBodiesSeeded=True)
  assert api['result']==dict(actualOriginalApiReportPin=proposal['actual50ApiReportPin'],originalApiLoaded26ChecksPassed=True,originalApiBooleanPredicates=119,apiMethodInvocationCount=None,methodCountNotInstrumented=True,bothDqs1CoupledViewsPassed=True,loadedCohortsExplicitlyPartial=dict(DDR_BYTE0=6,DDR_BYTE1=11,DDR_COMMAND_CLOCK=8))and api['originalApiCalls']is None and api['originalApiBooleanPredicates']==119
  assert p['actualFresh49Model']==proposal['actual50ModelPin']and p['actualFresh49ProjectionProof']==proposal['actual50ProofPin']and p['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and p['actualNativeReport']==proposal['actual49ReportPin']
  proof=read(proposal['actual50ProofPin']['path']);model=read(proposal['actual50ModelPin']['path']);v=read(proposal['actual50ApiReportPin']['path'])
  assert proof['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and proof['actualNativeReportSha256']==proposal['actual49ReportPin']['sha256']and proof['constructorInputSha256']==proposal['actual50ModelPin']['sha256']and proof['sourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and proof['originalSource26ProposalSha256']==proposal['promoted26ProposalPin']['sha256']and proof['exactFullInverseToFresh26Parent']is True
  assert len(model['connections'])==49 and len(model['traces'])==263 and len(model['obstacles'])==1298 and model['layerCount']==4 and sum(q['route_type']=='via'for t in model['traces']for q in t['route'])==98
  assert v['scope']=='ACTUAL_MOVED26_FRESH_CORE_ALL3_UNCHANGED_ORIGINAL_PRIVATE_API_DIAGNOSTIC'and v['packetSha256']==api['packetPin']['sha256']and v['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and v['actualNativeReportSha256']==proposal['actual49ReportPin']['sha256']and v['original49Input']=={k:proposal['actual50ModelPin'][k]for k in('path','sha256')}
  assert v['actualCompleteOriginalSignalCount']==26 and v['expectedMissingOriginalSignalCount']==23 and v['allOriginalApiLoaded26ChecksPassed']is True and v['checkInventory']['primaryBooleanPredicates']==116 and v['checkInventory']['secondaryDqs1BooleanPredicates']==3 and v['checkInventory']['primaryPlusSecondaryBooleanPredicates']==119
  assert v['secondaryDqs1View']['geometryAndEndpointsUnchanged']is v['secondaryDqs1View']['passed']is v['exactMaterialHeld']is v['fullOriginalBusRostersAndConstraintsHeld']is v['originalPrivateContinuousApiImplementationsUnchanged']is True
  for key in('complete26Accepted','accepted49','fabricationReady','referenceQualified','fullCohortTimingPassed','electricalDelayModelQualified'):assert v[key]is False
  assert {proposal['actual50ModelPin']['path'],proposal['actual50ProofPin']['path']}.issubset({x['path']for x in projection['outputFiles']})and api['outputFiles']==[proposal['actual50ApiReportPin']]
  assert projection['command']==[api26_contract['pythonInterpreterPin']['path'],'-B',api26_contract['projectorPin']['path'],projection['packetPin']['path'],projection['packetPin']['sha256'],str(Path(proposal['actual50ModelPin']['path']).parent)]
  assert api['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',api26_contract['apiWorkerPin']['path'],api['packetPin']['path'],api['packetPin']['sha256'],api['authorityPin']['path'],api['authorityPin']['sha256'],proposal['actual49ReportPin']['path'],proposal['actual50ApiReportPin']['path']]
  prior['actual50Fresh49AndOriginalApi119CollectionPin']={'path':proposal['actual50CollectionPin']['path'],'sha256':proposal['actual50CollectionPin']['sha256']};prior['actualClosedScopeCount']=50;prior['actual50TwoChildrenDoNotQualifyCliCadFull49OrElectrical']=True
  return prior

 def closed51():
  prior=closed50();assert prior['actualClosedScopeCount']==50
  for key in('actual51CollectionPin','actual51PostauditPin','actual51ReportPin','actual51ExportPin','actual51AuthorityPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  r=read(proposal['actual51CollectionPin']['path']);p=read(proposal['actual51PostauditPin']['path']);v=read(proposal['actual51ReportPin']['path']);e=r['execution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==14495 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE26_FRESH_PINNED_CLI_WITH50_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cli'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli26PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual51GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual51PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['execution']==e
  for doc in(r,p):
   for key in('passed','resultPassed','stageNaturallyCompleted','ownedChildNatural0','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('Source26Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['cliCalls']==1 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(e,0);assert e['policy']==cli26_policy and e['pid']==e['pgid']==496025 and e['currentGuardPid']==495807 and c.guard.process_scope.owned(496025)==[]and not Path('/proc/495807').exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert e['command']==[cli26_contract['pythonInterpreterPin']['path'],'-B',cli26_contract['cliWorkerPin']['path'],'--root-receipt',proposal['actual51AuthorityPin']['path'],'--root-receipt-sha256',proposal['actual51AuthorityPin']['sha256'],'--output-directory',str(Path(proposal['actual51ExportPin']['path']).parent)]
  assert r['reportPath']==p['reportPath']==proposal['actual51ReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual51ReportPin']['sha256']and r['exportPath']==p['exportPath']==proposal['actual51ExportPin']['path']and sha(r['exportPath'])==r['exportSha256']==p['exportSha256']==proposal['actual51ExportPin']['sha256']
  assert r['actualCoreSha256']==p['actualCoreSha256']==v['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==v['coreControlsSha256']==proposal['actual48CoreControlsPin']['sha256']
  assert v['scope']==cli26_preparation['scope']and v['sourceManifestSha256']==proposal['cli26PreparationPin']['sha256']and v['exportPassed']is v['byteIdenticalCopyOnly']is v['nativeAndOriginalApiStagesPassed']is True and v['cliExitCode']==0
  assert v['recognizedCircuitJsonSha256']==proposal['actual48CoreRawPin']['sha256']and v['outputPath']==proposal['actual51ExportPin']['path']and v['outputSha256']==proposal['actual51ExportPin']['sha256']and v['actualSourceSegmentCount']==1001 and v['actualSourceOwnedCarrierCount']==26 and v['actualPhysicalViaCount']==227 and v['actualPhysicalTraceCount']==289 and v['sourceOnlyMissingRoutes']==23
  assert v['actualNativeReport']==proposal['actual49ReportPin']and v['actualOriginalApiReport']==proposal['actual50ApiReportPin']
  assert v['argv']==[cli26_preparation['bun'],'--smol',cli26_preparation['cliMainPath'],'export',str(Path(proposal['actual51ExportPin']['path']).parent/'fresh-source26.circuit.json'),'--format','kicad_pcb','--output',proposal['actual51ExportPin']['path'],'--disable-parts-engine']
  for key in('originalRawEdited','sourceModuleEvaluated','sourcePortHookReplayedByCli','automaticCoreSrjUsed','complete26Accepted','referenceQualified','electricalTimingQualified','accepted49','fabricationReady'):assert v[key]is False
  for row in p['outputFiles']:binding(row)
  prior['actual51Source26CliSuccessCollectionPin']={'path':proposal['actual51CollectionPin']['path'],'sha256':proposal['actual51CollectionPin']['sha256']};prior['actualClosedScopeCount']=51;prior['actual51CliDoesNotQualifyFreshCadOrFull49']=True
  return prior

 def closed52():
  prior=closed51();assert prior['actualClosedScopeCount']==51
  keys=('actual52CollectionPin','actual52PostauditPin','actual52ResultPin','actual52ResourcePin','actual52ZonePinsPin','actual52GuardManifestPin')
  for key in keys:assert isinstance(proposal[key],dict);binding(proposal[key])
  assert type(proposal['actual52ToolSessionId'])is int and type(proposal['actual52ZonePgid'])is int and type(proposal['actual52CadPgid'])is int and type(proposal['actual52GuardPid'])is int
  assert (proposal['actual52ToolSessionId'],proposal['actual52ZonePgid'],proposal['actual52CadPgid'],proposal['actual52GuardPid'])==(63739,498512,498529,498287)
  r=read(proposal['actual52CollectionPin']['path']);p=read(proposal['actual52PostauditPin']['path']);v=read(proposal['actual52ResultPin']['path']);resources=read(proposal['actual52ResourcePin']['path']);zone=read(proposal['actual52ZonePinsPin']['path']);ze=r['zonePinsExecution'];ce=r['cadExecution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==proposal['actual52ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE26_FRESH_OFFLINE_CAD_WITH51_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli26PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual52GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual52PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior
  assert r['execution']==p['execution']==ce and p['zonePinsExecution']==ze and p['cadExecution']==ce
  for doc in(r,p):
   for key in('passed','resultPassed','stageNaturallyCompleted','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','zonePinsOwnedGroupEmptyActuallyObserved','cadOwnedGroupEmptyActuallyObserved','zonePinsChildNatural0','cadChildNatural0','bothOwnedGroupsIndependentlyObservedEmpty','zoneBeforeCadSeriallyEnforced','workspaceFreeBytesFloorHeld','gitMetadataHeld','ownedContainerActuallyEmpty','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('Source26Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady','resourceGateBlockedBeforeContainer','actualCadApplicationCompletionUnknown'):assert doc[key]is False
   assert doc['cadCalls']==doc['zonePinsChildInvocations']==1 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(ze,0);h.finite(ce,0);assert ze['policy']==cad26_contract['zonePinsPolicy']and ce['policy']==cad26_contract['cadPolicy']and ze['endedAt']<=ce['startedAt']
  assert ze['pid']==ze['pgid']==proposal['actual52ZonePgid']and ce['pid']==ce['pgid']==proposal['actual52CadPgid']and ze['pgid']!=ce['pgid']and ze['currentGuardPid']==ce['currentGuardPid']==proposal['actual52GuardPid']
  assert c.guard.process_scope.owned(ze['pgid'])==c.guard.process_scope.owned(ce['pgid'])==[]and not Path('/proc',str(proposal['actual52GuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedZoneGroupEmpty']is r['independentlyObservedCadGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert r['actualCadReportPin']==proposal['actual52ResultPin']and r['ownedContainerAbsenceActuallyObservedByOwnedWorkerAfterCleanup']is r['rootDidNotIndependentlyRequeryDockerAfterNaturalWrapperExit']is True
  assert r['allCurrent52ScopesCollected']is r['source26NewlyAdoptedForPartialRoutingOnly']is True and r['rootPartialMilestoneAfterCollection']=={'previousCheckedConnections':24,'checkedConnections':26,'missingConnections':23,'fullSignalCount':49,'nativePhysicalChecksAll18Zero':True,'freshKiCadPhysicalGraphCount':26,'electricalTimingPassed':False,'referenceQualified':False,'fabricationReady':False}
  assert r['ownedContainerName']==p['ownedContainerName']==proposal['actual52ContainerName']and resources==r['containerResourceObservations']==p['containerResourceObservations']and p['containerResourceObservationsBinding']==proposal['actual52ResourcePin']
  assert resources['imageId']==cli26_preparation['imageId']and resources['containerName']==proposal['actual52ContainerName']and resources['cleanupStatusRecorded']is resources['ownedContainerActuallyEmpty']is True and resources['containerWorkerStatus']==0
  observations=resources['observations'];assert len(observations)==2 and [x['phase']for x in observations]==['BEFORE_CONTAINER','AFTER_CLEANUP']
  first=observations[0];assert first['imageId']==cli26_preparation['imageId']and first['imageSizeBytes']==1519935209 and first['storageDriver']=='vfs'and first['dockerRootDir']=='/var/lib/docker'and first['requiredVfsBytes']==2*first['imageSizeBytes']+201326592 and first['actualVfsReserveSatisfiedAtObservation']is first['imageAlreadyPresent']is first['noImageLoadBuildPull']is True and first['freeBytesActuallyObserved']>=first['requiredVfsBytes']
  disk=ce['diskFreeGuard'];assert disk['path']=='/var/lib/docker'and disk['minimumFreeBytes']==134217728 and disk['sampleCount']>=2 and disk['readErrorCount']==0 and disk['lastReadErrorType']is None and all(disk[k]>=134217728 for k in('beforeAvailableBytes','minimumAvailableBytesObserved','lastAvailableBytes'))
  assert zone['actualCoreRawSha256']==proposal['actual48CoreRawPin']['sha256']and zone['actualExportPath']==proposal['actual51ExportPin']['path']and zone['actualExportSha256']==proposal['actual51ExportPin']['sha256']and zone['actualSourceKeepoutCount']==2
  assert ce['command'][1]==proposal['cad26SnapshotWrapperPin']['path']and ce['command'][3]==proposal['actual52ContainerName']and ce['command'][6]==cad26_contract['cadWorkerPin']['path']
  assert r['reportPath']==p['reportPath']==proposal['actual52ResultPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual52ResultPin']['sha256']
  assert v['scope']==cli26_preparation['scope']and v['sourceManifestSha256']==proposal['cli26PreparationPin']['sha256']and v['passed']is v['diagnosticCompleted']is v['allInputBytesHeld']is v['nativeAndOriginalApiStagesPassed']is True
  assert v['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and v['actualCoreControlsSha256']==proposal['actual48CoreControlsPin']['sha256']and v['actualExportPath']==proposal['actual51ExportPin']['path']and v['actualExportSha256']==proposal['actual51ExportPin']['sha256']
  assert v['actualKiCadVersion'].startswith('10.0.6')and v['actualLoadedFootprints']==507 and v['actualLoadedVias']==227 and v['actualLoadedSegments']==v['actualDerivedSourceSegmentCount']==1001 and v['actualLoadedLayerCount']==4 and v['actualRetainedNativeHardwareKeepoutZones']==2 and v['actualNativeCopperPourZones']==0 and v['all289SourceTracesMappedBijectively']is True
  assert len(v['signalObservations'])==v['actualLocalNetAgreementCount']==v['actualLocalPhysicalApproachCount']==98 and len(v['actual26GraphObservations'])==v['actual26NonzeroNetGraphCount']==v['actual26PhysicalCpuRamGraphCount']==26 and v['expectedMissingOriginalSignalCount']==23
  for key in('sourceRawOrSdkEdited','rawExportEdited','netRepairPerformed','saveBoardPerformed','refillPerformed','allRuleDrcPerformed','referenceQualified','electricalTimingQualified','complete26Accepted','accepted49','fabricationReady'):assert v[key]is False
  for row in p['outputFiles']:binding(row)
  prior['actual52Source26FreshCadSuccessCollectionPin']={'path':proposal['actual52CollectionPin']['path'],'sha256':proposal['actual52CollectionPin']['sha256']};prior['actualClosedScopeCount']=52;prior['actual52OnlyPartial26GeometryQualifiedAll49ReferenceElectricalStillFalse']=True
  return prior

 def inspect29_capture(paths):
  capture,diagnostic=paths['capture'],paths['diagnostic'];r=read_bounded(capture,5242880);d=read_bounded(diagnostic,7340032)
  assert r['scope']=='ACTUAL_ROOT_SOURCE29_CAPTURE_WITH_PARENT26_FULL_INVERSE'and d['scope']=='ACTUAL_SOURCE29_AND_PARENT26_BEFORE_INVERSE_ASSERTIONS'
  for key in('passed','fullInverseSourceTreePassed','actualParent26DeclarationsHeld','original49LogicalTracesHeld','original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse','pureSourceEvaluationExecuted','automaticCoreSrjForThisForkMustNotBeUsed','bothDqs1CoupledViewsRequireFreshOriginalApi'):assert r[key]is True
  for key,value in dict(proposedReactElementCount=2278,previousReactElementCount=2272,genuineNewInnerPortCount=46,exactNewPortDeclarations=6,exactChangedOriginalRouteDeclarations=4,exactChangedLocalSuppressions=6,exactMovedExistingViaCount=1,expectedPhysicalVias=227,expectedPhysicalTraces=292,expectedCarrierPaths=29,missingOriginal49RequestsExpected=20).items():assert r[key]==value
  assert r['movedViaName']=='V_TI_SIGNAL_source_trace_7_1'and r['movedViaCapturedPriorIdProvenanceOnly']is None and r['sourceOnlyProposalSha256']==proposal['promoted29ProposalPin']['sha256']
  assert r['actualDiagnosticPath']==str(diagnostic)and r['actualDiagnosticSha256']==sha(diagnostic)and r['actualSourceTree']==d['actualProposedSource29Tree']
  assert r['actualParent26CapturePin']=={k:proposal['actual48CapturePin'][k]for k in('path','sha256')}
  assert d['actualParent26Tree']==read(proposal['actual48CapturePin']['path'])['actualSourceTree']
  assert d['beforeCounts']['reactElements']==2272 and d['afterCounts']['reactElements']==2278 and d['beforeCounts']['unsupported']==d['afterCounts']['unsupported']==0 and d['inverseChecksExecuted']is False
  for key in('circuitConstructed','coreRendered','all49Accepted','fabricationReady'):assert r[key]is d[key]is False
  for key in('source26QualificationInherited','nativeExecuted','cadExecuted','singleCoupledSectionCoversBoth','referenceQualified','electricalTimingPassed'):assert r[key]is False
  return dict(sourceCapturePin=file_row(capture),sourceDiagnosticPin=file_row(diagnostic),fullSourceInversePassed=True,CoreExecuted=False)

 def inspect29_core(paths,capture_pin):
  raw,controls=paths['raw'],paths['controls'];core=read_bounded(raw,16777216);r=read_bounded(controls,4194304)
  assert isinstance(core,list)and r['scope']=='ROOT_FRESH_EDITABLE_SOURCE_CORE_OWNER_MOVED_227_SOURCE7_SOURCE6_SOURCE18_RESET_REPAIR_29'
  assert r['rawCorePath']==str(raw)and r['rawCoreSha256']==sha(raw)and r['actualCapturePath']==capture_pin['path']and r['actualCaptureSha256']==capture_pin['sha256']
  assert r['freshCoreControlPassed']is True and len(r['checks'])==29 and all(x['passed']is True for x in r['checks'])
  expected={'source_component':280,'source_trace':1195,'pcb_component':507,'pcb_smtpad':1161,'pcb_plated_hole':4,'pcb_hole':2,'pcb_via':227,'source_manually_placed_via':227,'pcb_trace':292,'source_port':1661,'pcb_port':1661,'source_net':98,'source_bus':8,'pcb_keepout':2}
  for kind,count in expected.items():assert sum(row['type']==kind for row in core)==count
  assert len(r['carriers'])==29 and all(x['passed']is True for x in r['carriers'])and len(r['signalTopProjection'])==98 and all(x['passed']is True for x in r['signalTopProjection'])
  assert len(r['original49Projection'])==49 and all(x['passed']is True for x in r['original49Projection'])and len(r['viaProjection'])==227 and all(x['passed']is True for x in r['viaProjection'])
  assert len(r['actualSourcePortMatches']['registrations'])==46 and r['expectedOriginalCarrierCount']==29 and r['expectedMissingOriginalSignalCount']==20 and r['actualNonzeroWireSegmentCount']==1053
  event=r['source3OwnerEvent'];assert event['sourceViaName']=='V_TI_SIGNAL_source_trace_3_0'and event['capturedPriorViaIdProvenanceOnly']=='pcb_via_135'and event['freshIdsDerivedFromActualCore']is True and event['capturedIdAssignedToFreshCore']is False
  vp=event['actualViaProjection'];sp=event['actualTopStubProjection'];cp=event['actualCarrierProjection'];assert vp['passed']is sp['passed']is cp['passed']is True and sp['originalSourceTraceId']==cp['originalSourceTraceId']=='source_trace_3'and sp['side']==0
  via=[v for v in core if v['type']=='pcb_via'and v['pcb_via_id']==vp['actualViaId']];assert len(via)==1 and abs(via[0]['x']-6.2)<1e-8 and abs(via[0]['y']-12.4)<1e-8 and via[0]['layers']==['top','inner1','inner2','bottom']and via[0]['outer_diameter']==.4572 and via[0]['hole_diameter']==.254
  stub=[v for v in core if v['type']=='pcb_trace'and v['pcb_trace_id']==sp['actualPcbTraceId']];assert len(stub)==1 and len(stub[0]['route'])==4 and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in stub[0]['route'])
  moved7=[x for x in r['viaProjection']if x['sourceViaName']=='V_TI_SIGNAL_source_trace_7_1'];stub7=[x for x in r['signalTopProjection']if x['originalSourceTraceId']=='source_trace_7'and x['side']==1];assert len(moved7)==len(stub7)==1 and moved7[0]['passed']is stub7[0]['passed']is True
  via7=[x for x in core if x['type']=='pcb_via'and x['pcb_via_id']==moved7[0]['actualViaId']];assert len(via7)==1 and abs(via7[0]['x']+7.4)<1e-8 and abs(via7[0]['y']-7.8)<1e-8 and via7[0]['layers']==['top','inner1','inner2','bottom']and via7[0]['outer_diameter']==.4572 and via7[0]['hole_diameter']==.254
  top7=[x for x in core if x['type']=='pcb_trace'and x['pcb_trace_id']==stub7[0]['actualPcbTraceId']];assert len(top7)==1 and len(top7[0]['route'])==13 and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in top7[0]['route'])
  for key in('sourceNumericAndPhysicalIdsDerivedWithoutAssignment','pcbRoutingDisabled','authoredPourLiteralsHeldByActualSourceInverse','manualPairSourceBusForkHeld','automaticCoreSrjForThisForkMustNotBeUsed','originalCouplingApisRequiredAgainstFreshActualGeometry'):assert r[key]is True
  for key in('circuitJsonGeometryEdited','parent26ActualQualificationInherited','nativeExecuted','cadExecuted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert r[key]is False
  return dict(rawCorePin=file_row(raw),coreControlsPin=file_row(controls),all29CorePredicatesPassed=True,actualCandidateCarrierCount=29,nativeQualificationPerformed=False)

 def closed53():
  prior=closed52();assert prior['actualClosedScopeCount']==52
  for key in('actual53CollectionPin','actual53PostauditPin','actual53CapturePin','actual53DiagnosticPin','actual53CoreRawPin','actual53CoreControlsPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert len(proposal['actual53PhasePostauditPins'])==3
  assert proposal['actual53ToolSessionId']==36688
  for row in proposal['actual53PhasePostauditPins']:binding(row)
  r=read(proposal['actual53CollectionPin']['path']);p=read(proposal['actual53PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual53ToolSessionId'])is int and r['toolSessionId']==proposal['actual53ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE29_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH52_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='capture-types-core-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual53GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual53PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert len(p['phases'])==3 and p['orderedPhaseNames']==p['expectedPhaseNames']==['capture','types','core']and p['notAttemptedPhaseNames']==[]
  identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()
  assert identity['pid']==500295 and [row['execution']['pgid']for row in p['phases']]==[500361,500419,500510]
  for doc in(r,p):
   for key in('historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','allThreeChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansCaptureStrictTypesAndRawCore29Only','batchScopeContainsThreeSerialOwnedChildren','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('batchFailure','finalVerificationFailure'):assert doc[key]is None
   for key in('Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
   assert doc['newRoutesAdopted']==0 and doc['CoreCalls']==doc['CoreChildInvocations']==doc['captureChildInvocations']==doc['typesChildInvocations']==1 and doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  previous=None;owned=[]
  for phase,row,pin in zip(('capture','types','core'),p['phases'],proposal['actual53PhasePostauditPins']):
   assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
   for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and sha(pin['path'])==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   e=row['execution'];h.finite(e,0);assert e['policy']==batch29['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and c.guard.process_scope.owned(e['pgid'])==[]and e['pgid']not in owned
   owned.append(e['pgid'])
   if previous is not None:assert previous['endedAt']<=e['startedAt']
   previous=e
   for output in row['outputFiles']:binding(output)
   for key in('Source29Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
   assert row['nativeCalls']==row['originalApiCalls']==row['cliCalls']==row['cadCalls']==0
  capture,types,core=p['phases'];assert capture['result']['sourceCapturePin']==proposal['actual53CapturePin']and capture['result']['sourceDiagnosticPin']==proposal['actual53DiagnosticPin']and core['result']['rawCorePin']==proposal['actual53CoreRawPin']and core['result']['coreControlsPin']==proposal['actual53CoreControlsPin']
  assert capture['result']==inspect29_capture(dict(capture=Path(proposal['actual53CapturePin']['path']),diagnostic=Path(proposal['actual53DiagnosticPin']['path'])))
  assert types['result']==dict(strictNoEmitTypecheckNatural0=True,actualPriorCapturePin=proposal['actual53CapturePin'])and types['outputFiles']==[]
  assert core['result']==inspect29_core(dict(raw=Path(proposal['actual53CoreRawPin']['path']),controls=Path(proposal['actual53CoreControlsPin']['path'])),proposal['actual53CapturePin'])
  bun=str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe')
  assert capture['command']==[bun,'--smol',proposal['promoted29CapturePin']['path'],proposal['actual53CapturePin']['path'],proposal['actual53DiagnosticPin']['path']]
  assert types['command']==['bash',proposal['promoted29TypesPin']['path']]
  assert core['command']==[bun,'--smol',proposal['promoted29CorePin']['path'],proposal['actual53CoreRawPin']['path'],proposal['actual53CoreControlsPin']['path'],proposal['actual53CapturePin']['path']]
  prior['actual53Source29ThreeSerialCaptureTypesCoreCollectionPin']={'path':proposal['actual53CollectionPin']['path'],'sha256':proposal['actual53CollectionPin']['sha256']};prior['actualClosedScopeCount']=53;prior['actual53ThreeChildrenDoNotQualifyNativeOrFull49']=True
  return prior

 def closed54():
  prior=closed53();assert prior['actualClosedScopeCount']==53
  for key in('actual54CollectionPin','actual54PostauditPin','actual54ReportPin','actual54BoundManifestPin','actual54AuthorityPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  r=read(proposal['actual54CollectionPin']['path']);p=read(proposal['actual54PostauditPin']['path']);v=read(proposal['actual54ReportPin']['path']);e=r['execution']
  assert (proposal['actual54ToolSessionId'],proposal['actual54Pgid'],proposal['actual54GuardPid'])==(90477,501788,501737)
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual54ToolSessionId'])is int and r['toolSessionId']==proposal['actual54ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE29_NATIVE18_WITH_AUTHENTIC_53_THREE_STAGE_PRIOR_CLOSURES'and r['phase']==p['phase']=='native'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['native29PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual54GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual54PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['execution']==e
  for doc in(r,p):
   for key in('passed','resultPassed','stageNaturallyCompleted','ownedChildNatural0','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','baseline169SourceHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passedMeansNative18AndActual29NumericPhysicalGraphsOnly','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('Source29Accepted','referenceQualified','electricalTimingPassed','fixReleaseQualificationPassed','originalAll11AcceptanceClaimed','all49Accepted','accepted49','fabricationReady','typesExecuted','coreRendered'):assert doc[key]is False
   assert doc['expandedSourceWorkerControllerClosureCount']==186 and doc['nativeCalls']==18 and doc['CoreCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(e,0);assert e['policy']==native29_contract['policy']and type(e['pgid'])is int and e['pgid']>0 and e['pid']==e['pgid']==proposal['actual54Pgid']and e['currentGuardPid']==proposal['actual54GuardPid']and c.guard.process_scope.owned(e['pgid'])==[]and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert r['reportPath']==p['reportPath']==proposal['actual54ReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual54ReportPin']['sha256']
  assert r['boundManifestPath']==p['boundManifestPath']==proposal['actual54BoundManifestPin']['path']and sha(r['boundManifestPath'])==r['boundManifestSha256']==p['boundManifestSha256']==r['packetSha256']==p['packetSha256']==v['packetSha256']==proposal['actual54BoundManifestPin']['sha256']
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',native29_contract['workerPin']['path'],proposal['actual54BoundManifestPin']['path'],proposal['actual54BoundManifestPin']['sha256'],proposal['actual54AuthorityPin']['path'],proposal['actual54AuthorityPin']['sha256'],proposal['actual54ReportPin']['path']]
  assert r['coreSourceManifestSha256']==p['coreSourceManifestSha256']==v['coreSourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and r['actualCorePath']==p['actualCorePath']==v['actualCorePath']==proposal['actual53CoreRawPin']['path']and r['actualCoreSha256']==p['actualCoreSha256']==v['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==v['actualCoreControlsSha256']==proposal['actual53CoreControlsPin']['sha256']
  assert v['scope']=='ACTUAL_FRESH_MOVED29_CORE292_NATIVE18_PHYSICAL_AND_NUMERIC_OWNER_GRAPH_QUALIFICATION'and v['sourceManifestSha256']==proposal['native29PreparationPin']['sha256']and v['originalSource29ProposalSha256']==proposal['promoted29ProposalPin']['sha256']
  assert v['checkCount']==len(v['counts'])==18 and not any(v['counts'].values())and v['physicalErrors']==0 and v['physicalCpuRamConnectedCarrierCount']==29 and v['expectedMissingOriginalSignalCount']==20 and v['actualNativePairFindings']==[]
  proof=v['actualOwnershipProof'];assert len(proof['signalMappings'])==98 and len(proof['referenceMappings'])==165 and len(proof['carriers'])==29 and all(x['actualSourceOwnedPhysicalGraph']['physicallyConnected']is x['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is True for x in proof['carriers'])
  for key in('all165ReferencePathsPreserved','all129ReferenceBarrelsPreserved','all98SignalBarrelsAndSource29TopStubsProved','source14RamBarrelAndTopStubChangedOnlyAsExplicitlyProposed','source3CpuBarrelAndFourPointTopStubChangedOnlyAsExplicitlyProposed','source27And28CarriersChangedOnlyAsExplicitlyProposed','source7RamBarrelAndThirteenPointTopStubChangedOnlyAsExplicitlyProposed','resetEightVertexCarrierRepairExplicit','all25OtherParent26CarriersExact','all49OriginalLogicalNumericRequestsPreserved','rawCircuitUnmodified','onlyAuthenticRam25Hs8PadAndStripContactRegistered','originalAll3CouplingApisAgainstActualGeometryRequiredSeparately','noCoreRenderPerformed','noRoutingPerformed','noCliOrCadPerformed','full49RoutesUnfinished'):assert v[key]is True
  for key in('circuitJsonGeometryOrIdentitiesEdited','sourceNetFabricationPerformed','globalSameNetManufacturingExemption','fullCohortTimingPassed','electricalTimingQualified','referenceQualified','complete26Accepted','accepted49','fabricationReady'):assert v[key]is False
  for row in p['outputFiles']:binding(row)
  prior['actual54Native29PhysicalSuccessCollectionPin']={'path':proposal['actual54CollectionPin']['path'],'sha256':proposal['actual54CollectionPin']['sha256']};prior['actualClosedScopeCount']=54;prior['actual54NativeDoesNotQualifyOriginalApisCliCadOrFull49']=True
  return prior

 def closed55():
  prior=closed54();assert prior['actualClosedScopeCount']==54
  for key in('actual55CollectionPin','actual55PostauditPin','actual55ModelPin','actual55ProofPin','actual55ApiReportPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert len(proposal['actual55PhasePostauditPins'])==2
  for pin in proposal['actual55PhasePostauditPins']:binding(pin)
  r=read(proposal['actual55CollectionPin']['path']);p=read(proposal['actual55PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual55ToolSessionId'])is int and r['toolSessionId']==proposal['actual55ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE29_FRESH49_PROJECTION_AND_ORIGINAL_API131_WITH54_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='projection-api-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['native29PreparationPin']['sha256']and r['coreSourceManifestSha256']==p['coreSourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual55GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual55PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert len(p['phases'])==2 and p['orderedPhaseNames']==p['expectedPhaseNames']==['projection','api']and p['notAttemptedPhaseNames']==[]
  identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()
  assert proposal['actual55ToolSessionId']==20574 and identity['pid']==502956 and [x['execution']['pgid']for x in p['phases']]==[503042,503380]
  for doc in(r,p):
   for key in('guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','bothChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansFresh49ProjectionAndOriginalLoaded29Api131Only','hardwareAcceptanceCheckpointUnchanged','projectionPassed','apiPassed','projectionBeforeApiSeriallyEnforced','originalApiMethodInvocationCountNotInstrumented'):assert doc[key]is True
   for key in('batchFailure','finalVerificationFailure','originalApiCalls'):assert doc[key]is None
   for key in('Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['originalApiBooleanPredicates']==131 and doc['CoreCalls']==doc['nativeCalls']==doc['cliCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  owned=[];previous=None
  for phase,row,pin in zip(('projection','api'),p['phases'],proposal['actual55PhasePostauditPins']):
   assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
   for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   e=row['execution'];h.finite(e,0);assert e['policy']==api29_contract['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and e['pgid']not in owned and c.guard.process_scope.owned(e['pgid'])==[];owned.append(e['pgid'])
   if previous is not None:assert previous['endedAt']<=e['startedAt']
   previous=e
   binding(row['packetPin'])
   if row['authorityPin']is not None:binding(row['authorityPin'])
   for output in row['outputFiles']:binding(output)
   for key in('Source29Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
   assert row['CoreCalls']==row['nativeCalls']==row['cliCalls']==row['cadCalls']==0
  projection,api=p['phases'];assert p['projectionExecution']==projection['execution']and p['apiExecution']==api['execution']and len(projection['outputFiles'])==5 and len(api['outputFiles'])==1
  assert projection['result']==dict(actualFresh49Model=proposal['actual55ModelPin'],actualFresh49ProjectionProof=proposal['actual55ProofPin'],source29FreshFull49ProjectionPassed=True,actual49Requests=49,actualFixedTraces=263,actualHardObstacles=1298,actualSignalViaEvents=98,zeroSelected26CarrierBodiesSeeded=True)
  assert api['result']==dict(actualOriginalApiReportPin=proposal['actual55ApiReportPin'],originalApiLoaded29ChecksPassed=True,originalApiBooleanPredicates=131,apiMethodInvocationCount=None,methodCountNotInstrumented=True,bothDqs1CoupledViewsPassed=True,loadedCohortsExplicitlyPartial=dict(DDR_BYTE0=6,DDR_BYTE1=11,DDR_COMMAND_CLOCK=11))and api['originalApiCalls']is None and api['originalApiBooleanPredicates']==131
  assert p['actualFresh49Model']==proposal['actual55ModelPin']and p['actualFresh49ProjectionProof']==proposal['actual55ProofPin']and p['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and p['actualNativeReport']==proposal['actual54ReportPin']
  proof=read(proposal['actual55ProofPin']['path']);model=read(proposal['actual55ModelPin']['path']);v=read(proposal['actual55ApiReportPin']['path'])
  assert proof['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and proof['actualNativeReportSha256']==proposal['actual54ReportPin']['sha256']and proof['constructorInputSha256']==proposal['actual55ModelPin']['sha256']and proof['sourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and proof['originalSource29ProposalSha256']==proposal['promoted29ProposalPin']['sha256']and proof['exactFullInverseToFresh29Parent']is True
  assert len(model['connections'])==49 and len(model['traces'])==263 and len(model['obstacles'])==1298 and model['layerCount']==4 and sum(q['route_type']=='via'for t in model['traces']for q in t['route'])==98
  assert v['scope']=='ACTUAL_MOVED29_FRESH_CORE_ALL3_UNCHANGED_ORIGINAL_PRIVATE_API_DIAGNOSTIC'and v['packetSha256']==api['packetPin']['sha256']and v['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and v['actualNativeReportSha256']==proposal['actual54ReportPin']['sha256']and v['original49Input']=={k:proposal['actual55ModelPin'][k]for k in('path','sha256')}
  assert v['actualCompleteOriginalSignalCount']==29 and v['expectedMissingOriginalSignalCount']==20 and v['allOriginalApiLoaded26ChecksPassed']is True and v['checkInventory']['primaryBooleanPredicates']==128 and v['checkInventory']['secondaryDqs1BooleanPredicates']==3 and v['checkInventory']['primaryPlusSecondaryBooleanPredicates']==131
  assert v['secondaryDqs1View']['geometryAndEndpointsUnchanged']is v['secondaryDqs1View']['passed']is v['exactMaterialHeld']is v['fullOriginalBusRostersAndConstraintsHeld']is v['originalPrivateContinuousApiImplementationsUnchanged']is True
  for key in('complete26Accepted','accepted49','fabricationReady','referenceQualified','fullCohortTimingPassed','electricalDelayModelQualified'):assert v[key]is False
  assert {proposal['actual55ModelPin']['path'],proposal['actual55ProofPin']['path']}.issubset({x['path']for x in projection['outputFiles']})and api['outputFiles']==[proposal['actual55ApiReportPin']]
  assert projection['command']==[api29_contract['pythonInterpreterPin']['path'],'-B',api29_contract['projectorPin']['path'],projection['packetPin']['path'],projection['packetPin']['sha256'],str(Path(proposal['actual55ModelPin']['path']).parent)]
  assert api['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',api29_contract['apiWorkerPin']['path'],api['packetPin']['path'],api['packetPin']['sha256'],api['authorityPin']['path'],api['authorityPin']['sha256'],proposal['actual54ReportPin']['path'],proposal['actual55ApiReportPin']['path']]
  prior['actual55Fresh49AndOriginalApi131CollectionPin']={'path':proposal['actual55CollectionPin']['path'],'sha256':proposal['actual55CollectionPin']['sha256']};prior['actualClosedScopeCount']=55;prior['actual55TwoChildrenDoNotQualifyCliCadFull49OrElectrical']=True
  return prior

 assert out.parent==Path('/tmp')and out.name.startswith('g350-source29-cli-root-')and out.resolve()==out and not out.exists()and not out.is_symlink()
 with(ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  prior=closed55();assert prior['actualClosedScopeCount']==cli29_contract['requiredPriorScopeCount']==55
  identity_before=guard_identity();_,native_before,board_before,solver_before,_=c.guard.checked();bindings();git_before=git_inventory();assert git_before==base['gitMetadataFiles']
  assert board_before['treeSha256']==stage['boardSdkTreeSha256']and solver_before['treeSha256']==stage['solverSdkTreeSha256']
  workspace_floor=shutil.disk_usage('/workspace').free;out.mkdir(mode=0o700);(out/'bun-cache').mkdir(mode=0o700);(out/'tmp').mkdir(mode=0o700);output=out/'output';output.mkdir(mode=0o700)
  authority={**cli29_preparation['actualPrerequisites'],'authorizedByRoot':True,'scope':cli29_preparation['scope'],'sourceManifestSha256':proposal['cli29PreparationPin']['sha256'],'genuineSourceManifestSha256':proposal['promoted29ManifestPin']['sha256'],'actualNativeSourceManifestSha256':proposal['native29PreparationPin']['sha256'],'actualApiSourceManifestSha256':proposal['native29PreparationPin']['sha256'],'actualPreviousScopesCollectedAndEmpty':True,'noConcurrentRootWorker':True,'rootFullWorkerReadPassed':True,'rootGuardProposalManifestSha256':source_sha,'actualClosedPriorScopes':prior,'outputDirectory':str(output),'policy':cli29_policy,'nonce':secrets.token_hex(32),'all49Accepted':False,'fabricationReady':False}
  ap=out/'ROOT_AUTHORITY.json';write(ap,authority);authority_sha=sha(ap)
  command=[cli29_contract['pythonInterpreterPin']['path'],'-B',cli29_contract['cliWorkerPin']['path'],'--root-receipt',str(ap),'--root-receipt-sha256',authority_sha,'--output-directory',str(output)]
  environment={'NO_COLOR':'1','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(out/'bun-cache'),'TMPDIR':str(out/'tmp'),'G350_SOURCE29_FRESH_JSON_CLI_ROOT_GUARDED':'1'}
  def invariant_check():
   bindings();no_git_redirects();assert closed55()==prior and guard_identity()==identity_before and sha(ap)==authority_sha and git_inventory()==git_before and shutil.disk_usage('/workspace').free>=workspace_floor
  def prefork(memory):
   invariant_check();assert memory['current']+cli29_policy['rssBytes']+1073741824<cli29_policy['sharedBytes']and shutil.disk_usage('/tmp').free>=536870912
  execution=None;run_error=post_error=inspection_error=None;native_after=board_after=solver_after=None;result=None;result_passed=False;empty=None
  try:execution=process_runner.run_guarded(command,str(c.BOARD),out/'owned',cli29_policy,environment,before_spawn=prefork)
  except BaseException as error:
   run_error=type(error).__name__+': '+str(error)
   try:
    if(out/'owned/execution.json').is_file():execution=read(out/'owned/execution.json')
   except BaseException as parse_error:run_error+='; execution recovery '+type(parse_error).__name__+': '+str(parse_error)
  try:
   _,native_after,board_after,solver_after,_=c.guard.checked();invariant_check();assert native_before==native_after and board_before==board_after and solver_before==solver_after
  except BaseException as error:post_error=type(error).__name__+': '+str(error)
  held=post_error is None and native_before==native_after and board_before==board_after and solver_before==solver_after
  try:
   assert isinstance(execution,dict);empty=c.guard.process_scope.owned(execution['pgid'])==[]
  except BaseException as error:inspection_error='Owned scope '+type(error).__name__+': '+str(error)
  natural=bool(isinstance(execution,dict)and type(execution.get('exitCode'))is int and execution['exitCode']>=0 and execution.get('diagnosticStopped')is False and not execution.get('stopReasons')and execution.get('cleanupOwnedGroupEmpty')is True and isinstance(execution.get('oomDelta'),dict)and bool(execution['oomDelta'])and not any(execution['oomDelta'].values())and empty is True)
  report=output/'cli-export-report.json';export=output/'g350-source29.kicad_pcb'
  try:
   assert held and run_error is post_error is inspection_error is None and natural and execution['exitCode']in(0,1,2);h.finite(execution,execution['exitCode']);assert execution['policy']==cli29_policy and execution['command']==command and execution['currentGuardPid']==identity_before['pid']and guard_identity()==identity_before and 'guardError'not in execution
   assert {p.name for p in output.iterdir()}=={'fresh-source29.circuit.json','g350-source29.kicad_pcb','pinned-cli.log','cli-export-report.json'}
   for path,limit in((report,4194304),(export,33554432),(output/'fresh-source29.circuit.json',16777216),(output/'pinned-cli.log',4194304)):assert path.is_file()and not path.is_symlink()and 0<=path.stat().st_size<=limit
   result=read(report);assert result['scope']==cli29_preparation['scope']and result['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and result['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and result['coreControlsSha256']==proposal['actual53CoreControlsPin']['sha256']
   assert result['exportPassed']is True and result['cliExitCode']==0 and result['byteIdenticalCopyOnly']is True and result['recognizedCircuitJsonSha256']==proposal['actual53CoreRawPin']['sha256']and sha(output/'fresh-source29.circuit.json')==proposal['actual53CoreRawPin']['sha256']
   assert result['outputPath']==str(export)and result['outputSha256']==sha(export)and export.stat().st_size>0 and result['actualSourceSegmentCount']==1053 and result['actualSourceOwnedCarrierCount']==29 and result['actualPhysicalViaCount']==227 and result['actualPhysicalTraceCount']==292 and result['sourceOnlyMissingRoutes']==20
   assert result['nativeAndOriginalApiStagesPassed']is True and result['actualNativeReport']==cli29_preparation['actualPrerequisites']['actualNativeReport']==proposal['actual54ReportPin']and result['actualOriginalApiReport']==cli29_preparation['actualPrerequisites']['actualOriginalApiReport']==proposal['actual55ApiReportPin']
   assert result['argv']==[cli29_preparation['bun'],'--smol',cli29_preparation['cliMainPath'],'export',str(output/'fresh-source29.circuit.json'),'--format','kicad_pcb','--output',str(export),'--disable-parts-engine']
   for key in('originalRawEdited','sourceModuleEvaluated','sourcePortHookReplayedByCli','automaticCoreSrjUsed','complete29Accepted','referenceQualified','electricalTimingQualified','accepted49','fabricationReady'):assert result[key]is False
   result_passed=bool(natural and execution['exitCode']==0)
  except BaseException as error:inspection_error=(inspection_error+'; 'if inspection_error else'')+type(error).__name__+': '+str(error)
  files=[file_row(p)for p in sorted([*out.iterdir(),*output.iterdir()])if p.is_file()and not p.is_symlink()]
  post=dict(scope='ROOT_SOURCE29_FRESH_PINNED_CLI_WITH55_AUTHENTIC_PRIOR_CLOSURES',phase='cli',sourceManifestSha256=proposal['cli29PreparationPin']['sha256'],rootGuardProposalManifestSha256=source_sha,execution=execution,actualClosedPriorScopes=prior,sourceAndDependenciesHeld=held,dependenciesBefore=board_before,dependenciesAfter=board_after,solverDependenciesBefore=solver_before,solverDependenciesAfter=solver_after,runFailure=run_error,postverificationFailure=post_error,resultInspectionFailure=inspection_error,ownedGroupEmptyActuallyObserved=empty,stageNaturallyCompleted=natural,ownedChildNatural0=natural and execution['exitCode']==0,resultPassed=result_passed,passed=result_passed,reportPath=str(report),reportSha256=sha(report)if report.is_file()and not report.is_symlink()else None,exportPath=str(export),exportSha256=sha(export)if export.is_file()and not export.is_symlink()else None,actualCoreSha256=proposal['actual53CoreRawPin']['sha256'],actualCoreControlsSha256=proposal['actual53CoreControlsPin']['sha256'],CoreCalls=0,nativeCalls=0,originalApiCalls=0,cliCalls=1 if isinstance(result,dict)else None,cadCalls=0,Source29Accepted=False,hardwareAcceptanceCheckpointUnchanged=True,newRoutesAdopted=0,referenceQualified=False,electricalTimingPassed=False,all49Accepted=False,accepted49=False,fabricationReady=False,workspaceFreeBytesBefore=workspace_floor,workspaceFreeBytesFloorHeld=post_error is None,gitMetadataHeld=post_error is None,outputFiles=files,toolSessionCollected=False)
  pp=out/'POSTAUDIT.json';write(pp,post);print(json.dumps(dict(passed=result_passed,phase='cli',postauditPath=str(pp),postauditSha256=sha(pp),execution=execution)))
 return 0 if result_passed else 2

if __name__=='__main__':raise SystemExit(main())
