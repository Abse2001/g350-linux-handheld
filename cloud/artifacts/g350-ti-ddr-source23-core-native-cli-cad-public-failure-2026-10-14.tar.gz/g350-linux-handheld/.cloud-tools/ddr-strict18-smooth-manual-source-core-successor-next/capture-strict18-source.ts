/** Root-only pure Source capture; imported ancestors load Core definitions.
 * This worker constructs no Circuit and executes no Core/router/Native/CAD. */
import { Children, Fragment, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { readFileSync, writeFileSync, existsSync } from "node:fs"
import { createHash } from "node:crypto"
import assert from "node:assert/strict"
import { buildManualPairClockV11Source } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-clock-v11-manual-pair-source-successor-next/manual-pair-source-overlay"
import { buildStrict18ManualSource } from "./strict18-source-overlay"
import proposal from "./strict18-source-proposal.json"
const [output, diagnostic, ...extra] = process.argv.slice(2)
assert.equal(process.env.G350_STRICT18_SOURCE_ROOT_GUARDED, "1")
assert.equal(process.versions.bun, "1.3.14")
assert.ok(output && diagnostic && extra.length === 0 && output !== diagnostic && !existsSync(output) && !existsSync(diagnostic))
const sha = (value: string | Buffer) => createHash("sha256").update(value).digest("hex")
for (const binding of Object.values(proposal.inputBindings)) assert.equal(sha(readFileSync(binding.path)), binding.sha256)
assert.equal(sha(readFileSync(proposal.authorizedAllFourLayerFork.routingInputPath)), proposal.authorizedAllFourLayerFork.routingInputSha256)
type Props = Record<string, unknown> & { children?: ReactNode }
type Row = { kind: "literal" | "fragment" | "primitive" | "unsupported"; type: string; key: string | null;
  props: Record<string, unknown>; children: Row[]; value?: unknown }
function identity(node: ReactNode): ReactNode {
  if (!isValidElement<Props>(node)) return node
  return cloneElement(node as ReactElement<Props>, { ...node.props }, ...Children.toArray(node.props.children).map(identity))
}
function snapshot(node: ReactNode): Row {
  if (!isValidElement<Props>(node)) {
    const allowed = node === null || node === undefined || ["boolean", "string", "number"].includes(typeof node)
    return { kind: allowed ? "primitive" : "unsupported", type: typeof node, key: null, value: node, props: {}, children: [] }
  }
  const { children, ...props } = node.props, actualType: unknown = node.type
  const kind = typeof actualType === "string" ? "literal" : actualType === Fragment ? "fragment" : "unsupported"
  return { kind, type: kind === "literal" ? actualType as string : kind === "fragment" ? "React.Fragment" : `${typeof actualType}:${String(actualType)}`,
    key: node.key, props, children: Children.toArray(children).map(snapshot) }
}
const flatten = (row: Row): Row[] => [row, ...row.children.flatMap(flatten)]
const clone = (row: Row): Row => ({ ...row, props: { ...row.props }, children: row.children.map(clone) })
function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`
  if (value && typeof value === "object") return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonical((value as Record<string, unknown>)[key])}`).join(",")}}`
  if (typeof value === "function") return `function:${value.toString()}`
  if (typeof value === "symbol") return `symbol:${String(value)}`
  return JSON.stringify(value) ?? "undefined"
}
const replacer = (_key: string, value: unknown) => typeof value === "function" ? { diagnosticFunction: value.name, sourceSha256: sha(value.toString()) }
  : typeof value === "symbol" ? { diagnosticSymbol: String(value), globalSymbolKey: Symbol.keyFor(value) ?? null } : value
const parent = buildManualPairClockV11Source(), source = buildStrict18ManualSource()
// One added wrapper normalizes Children keys once; compare its exact inverse
// against one identity pass over the already-qualified manual parent.
const before = snapshot(identity(parent.element)), after = snapshot(source.element)
const oldRows = flatten(before), newRows = flatten(after)
const counts = (rows: Row[]) => ({ reactElements: rows.filter(row => row.kind === "literal" || row.kind === "fragment").length,
  literalStrings: rows.filter(row => row.kind === "literal").length, fragments: rows.filter(row => row.kind === "fragment").length,
  primitiveChildren: rows.filter(row => row.kind === "primitive").length, unsupported: rows.filter(row => row.kind === "unsupported").length })
writeFileSync(diagnostic, JSON.stringify({ scope: "ACTUAL_STRICT18_SOURCE_TREE_BEFORE_INVERSE_ASSERTIONS", beforeCounts: counts(oldRows),
  afterCounts: counts(newRows), actualBeforeTree: before, actualProposedTree: after, inverseChecksExecuted: false,
  transitiveAncestorCoreDefinitionsImported: true, circuitConstructed: false, coreRendered: false, nativeExecuted: false, cadExecuted: false,
  referenceQualified: false, complete18Accepted: false, fabricationReady: false }, replacer, 2) + "\n", { flag: "wx", mode: 0o600 })
assert.equal(counts(oldRows).unsupported, 0); assert.equal(counts(newRows).unsupported, 0)
assert.equal(counts(oldRows).reactElements, 2232); assert.equal(counts(newRows).reactElements, 2256)
assert.equal(counts(newRows).literalStrings - counts(oldRows).literalStrings, 24)
assert.equal(counts(newRows).fragments, counts(oldRows).fragments)
assert.equal(counts(newRows).primitiveChildren, counts(oldRows).primitiveChildren)
const one = (rows: Row[], label: string) => { assert.equal(rows.length, 1, label); return rows[0] }
const byName = (rows: Row[], name: string) => one(rows.filter(row => row.kind === "literal" && row.props.name === name), name)
for (const port of proposal.addedRealInnerLayerPorts) {
  const via = byName(newRows, port.viaName)
  assert.equal(via.type, "via")
  const child = one(via.children.filter(child => child.kind === "literal" && child.type === "port"), "Exactlyone genuine inner Port child")
  assert.deepEqual(child.props, { name: port.layer, layer: port.layer }, "No invented coordinates or extra Port props")
  assert.equal(child.children.length, 0)
  assert.equal(via.children.length, 1)
}
for (const change of proposal.newOriginalSignalChanges) {
  const row = byName(newRows, change.originalLogicalTraceName), original = byName(oldRows, change.originalLogicalTraceName)
  assert.equal(row.type, "trace"); assert.equal(row.props.from, change.originalNumericFrom); assert.equal(row.props.to, change.originalNumericTo)
  assert.deepEqual(row.props.pcbPaths, change.newPcbPaths); assert.equal(row.props.pcbPathRelativeTo, change.newPcbPathRelativeTo)
  assert.deepEqual({ ...row.props, pcbPaths: undefined, pcbPathRelativeTo: undefined }, { ...original.props, pcbPaths: undefined, pcbPathRelativeTo: undefined })
  for (const owner of [change.cpu, change.ram]) {
    const local = byName(newRows, owner.traceName), oldLocal = byName(oldRows, owner.traceName)
    assert.equal(local.type, "trace"); assert.equal(local.props.pcbPath, undefined); assert.equal(local.props.pcbPaths, undefined)
    assert.deepEqual({ ...local.props, pcbPath: [] }, oldLocal.props)
  }
}
for (const clock of proposal.existingQualifiedClocksHeld) assert.equal(canonical(byName(newRows, clock.originalLogicalTraceName)), canonical(byName(oldRows, clock.originalLogicalTraceName)), "Qualified original clock props/keys/children remain exact")
for (const change of proposal.authorizedAllFourLayerFork.sourceBusAllowedLayerChanges) {
  const row = byName(newRows, change.busId), old = byName(oldRows, change.busId)
  assert.equal(row.type, "bus"); assert.deepEqual(row.props.pcbAllowedLayers, change.newAllowedLayers)
  assert.deepEqual({ ...row.props, pcbAllowedLayers: change.originalAllowedLayers }, old.props, "Only explicitly authorized allowed-layer prop changes")
}
// Compare against the ACTUAL passed prior strict18 Source tree as well as
// the original full numeric Source inverse below. Restore exactly three path
// props; keys/order/logic/ports/barrels/constraints must be the same everywhere.
const priorStrict18Capture = JSON.parse(readFileSync(proposal.inputBindings.priorStrict18Capture.path, "utf8"))
assert.equal(priorStrict18Capture.passed, true); assert.equal(priorStrict18Capture.fullInverseSourceTreePassed, true)
const priorStrict18Proposal = JSON.parse(readFileSync(proposal.inputBindings.priorStrict18Proposal.path, "utf8"))
const serializedAfter = JSON.parse(JSON.stringify(after, replacer)) as Row
const exactThreeInverse = clone(serializedAfter), previousStrict18Tree = priorStrict18Capture.actualSourceTree as Row
const changedOnly = proposal.cornerSmoothingSuccessor.changedOriginalSourceIds
assert.deepEqual(changedOnly, ["source_trace_15", "source_trace_16", "source_trace_28"])
let smoothedRestorations = 0
for (const name of changedOnly) {
  const previous = priorStrict18Proposal.newOriginalSignalChanges.find((r: { originalSourceTraceId: string }) => r.originalSourceTraceId === name)
  assert(previous)
  const restoredRow = byName(flatten(exactThreeInverse), previous.originalLogicalTraceName)
  const originalRow = byName(flatten(previousStrict18Tree), previous.originalLogicalTraceName)
  assert.deepEqual(originalRow.props.pcbPaths, previous.newPcbPaths)
  restoredRow.props.pcbPaths = previous.newPcbPaths; smoothedRestorations++
}
assert.equal(smoothedRestorations, 3)
assert.equal(canonical(exactThreeInverse), canonical(previousStrict18Tree), "Exactlythree path arrays change versus actual passed strict18; all other props/keys/order remain exact")
const restored = clone(after), untouchedActual = canonical(after)
let portsRemoved = 0, originalsRestored = 0, localsRestored = 0, busesRestored = 0
for (const row of flatten(restored)) {
  for (const port of proposal.addedRealInnerLayerPorts.filter(port => port.viaName === row.props.name)) {
    const removed = one(row.children.filter(child => child.kind === "literal" && child.type === "port" && child.props.name === port.layer && child.props.layer === port.layer), "Actual new genuine inner Port")
    row.children = row.children.filter(child => child !== removed); portsRemoved++
  }
  const signal = proposal.newOriginalSignalChanges.find(signal => signal.originalLogicalTraceName === row.props.name)
  if (signal) { delete row.props.pcbPaths; delete row.props.pcbPathRelativeTo; originalsRestored++ }
  if (proposal.newOriginalSignalChanges.some(signal => signal.newLocalRenderSuppressions.includes(String(row.props.name)))) {
    row.props.pcbPath = []; localsRestored++
  }
  const bus = proposal.authorizedAllFourLayerFork.sourceBusAllowedLayerChanges.find(bus => bus.busId === row.props.name)
  if (bus) { row.props.pcbAllowedLayers = [...bus.originalAllowedLayers]; busesRestored++ }
}
assert.equal(portsRemoved, 24); assert.equal(originalsRestored, 16); assert.equal(localsRestored, 32); assert.equal(busesRestored, 4)
assert.equal(canonical(restored), canonical(before), "Full inverse holds every original literal/Fragment/key/prop/primitive and child order")
assert.equal(canonical(after), untouchedActual, "Inverse cannot mutate actual proposed tree")
for (const key of Object.keys(parent).filter(key => key !== "element")) assert.equal(canonical((source as Record<string, unknown>)[key]), canonical((parent as Record<string, unknown>)[key]), "Every original returned Source metadata field stays exact")
const oldInput = JSON.parse(readFileSync(proposal.authorizedAllFourLayerFork.originalRoutingInputPath, "utf8"))
const forkInput = JSON.parse(readFileSync(proposal.authorizedAllFourLayerFork.routingInputPath, "utf8"))
for (const change of proposal.authorizedAllFourLayerFork.routingInputAllowedLayerChanges) {
  const bus = forkInput.buses.filter((bus: { busId: string }) => bus.busId === change.busId)
  assert.equal(bus.length, 1); assert.deepEqual(bus[0].allowedLayers, change.newAllowedLayers); bus[0].allowedLayers = change.originalAllowedLayers
}
assert.deepEqual(forkInput, oldInput, "All49 routing-input logic/width/skew/min/max/.12 pair gap and all geometry held under inverse layer fork")
const report = { scope: "ACTUAL_STRICT18_MANUAL_SOURCE_CAPTURE_AND_AUTHORIZED_LAYER_FORK", passed: true,
  originalReactElementCount: 2232, proposedReactElementCount: 2256, genuineNewInnerLayerPorts: 24,
  newOriginalThreePathDeclarations: 16, duplicateLocalPcbRenderSuppressions: 32, explicitAuthorizedBusAllowedLayerChanges: 4,
  originalQualifiedClockPropsHeld: true, originalAll49LogicBusMembershipAnd98NamedRailsHeld: true,
  originalTimingWidthSkewGapAndPreferredLayerPropsHeld: true, originalAllowedLayerPropsInverselyRestored: true,
  allOriginalSourceMetadataHeld: true, fullInverseSourceTreePassed: true, routingInputLayerForkInversePassed: true,
  actualDiagnosticPath: diagnostic, actualDiagnosticSha256: sha(readFileSync(diagnostic)), actualSourceTree: after,
  sourceOnlyProposalSha256: sha(readFileSync(new URL("./strict18-source-proposal.json", import.meta.url))),
  original144AncestorClosureUnchanged: true, exactThreeSmoothedPathSuccessorInversePassed: true,
  exactChangedOriginalSourceIds: changedOnly, updatedAuthenticPairEvidenceSha256: proposal.cornerSmoothingSuccessor.updatedAuthenticPairEvidenceSha256,
  priorActualStrict18SourceCaptureSha256: proposal.inputBindings.priorStrict18Capture.sha256, pureSourceEvaluationExecuted: true, circuitConstructed: false,
  coreRendered: false, nativeExecuted: false, cadExecuted: false, missingRoutesExpectedAfterFreshQualification: 31,
  referenceQualified: false, complete18Accepted: false, electricalTimingQualified: false, fabricationReady: false }
writeFileSync(output, JSON.stringify(report, replacer, 2) + "\n", { flag: "wx", mode: 0o600 })
console.log(JSON.stringify({ passed: true, fullInverseSourceTreePassed: true, proposedReactElementCount: 2256, coreRendered: false, complete18Accepted: false, output }))
