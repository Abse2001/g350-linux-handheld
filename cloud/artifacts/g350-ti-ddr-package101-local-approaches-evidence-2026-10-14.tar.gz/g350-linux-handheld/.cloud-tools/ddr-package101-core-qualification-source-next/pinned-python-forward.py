"""Source-only wrapper; Root runs exact existing CPython3.12 pinned target."""
from pathlib import Path
import hashlib, json, runpy, sys

ROOT=Path(__file__).resolve().parent
PYTHON=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
TARGET=Path('/workspace/g350-linux-handheld/.cloud-tools/python-routing')

def require(value,message):
    if not value:raise ValueError(message)

def main():
    require(len(sys.argv)==5,'Actual Core/hash/fresh forward/fresh Python gate required')
    actual,expected,forward,gate=sys.argv[1:]
    require(Path(sys.executable).resolve()==PYTHON.resolve() and sys.version_info[:3]==(3,12,14),'Exact existing compatible CPython3.12.14 required')
    require(hashlib.sha256(PYTHON.read_bytes()).hexdigest()=='fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7','Pinned interpreter changed')
    require(not any(name in sys.modules for name in ('numpy','shapely')),'Numerical packages must not be preloaded')
    sys.dont_write_bytecode=True;sys.path.insert(0,str(TARGET))
    import numpy,shapely
    from shapely.geometry import Point
    require(numpy.__version__=='2.3.5' and shapely.__version__=='2.1.2' and shapely.geos_version_string=='3.13.1','Exact existing pinned numerical/geometry packages required')
    require(Path(numpy.__file__).resolve()==TARGET/'numpy/__init__.py' and Path(shapely.__file__).resolve()==TARGET/'shapely/__init__.py','Exact local target imports required')
    import numpy._core._multiarray_umath as np_ext
    import shapely.lib as geo_ext
    require((TARGET/'numpy') in Path(np_ext.__file__).resolve().parents and (TARGET/'shapely') in Path(geo_ext.__file__).resolve().parents,'Exact compatible local extension trees required')
    require(Point(0,0).distance(Point(3,4))==5.0,'Tiny pinned geometry gate failed')
    report={'pythonExecutable':str(PYTHON.resolve()),'pythonVersion':'3.12.14','pythonTarget':str(TARGET),'numpyVersion':numpy.__version__,'shapelyVersion':shapely.__version__,'geosVersion':shapely.geos_version_string,'numpyExtension':str(Path(np_ext.__file__).resolve()),'shapelyExtension':str(Path(geo_ext.__file__).resolve()),'tinyGeometryPassed':True,'installedPackagesModified':False}
    with Path(gate).open('x') as file:json.dump(report,file,indent=2);file.write('\n')
    sys.argv=[str(ROOT/'verify-hs64-base-and-package-additions.py'),actual,expected,forward]
    runpy.run_path(sys.argv[0],run_name='__main__')

if __name__=='__main__':main()
