"""Actual JSON read and synthetic fullchain checks only; no native/Core/Circuit/router."""
from pathlib import Path
import copy,importlib.util,json,unittest
from validate_v7 import validate,synthetic_control
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'ti-ddr-v7-ram-right-source-next'
read=lambda n:json.loads((ROOT/n).read_bytes())
BASE=read('inputs/base-layout.circuit.json');V5=read('inputs/v5-layout.circuit.json');V6=read('inputs/v6-layout.circuit.json');ACTUAL=read('inputs/actual-v7-layout.circuit.json');POSES=read('source/lib/am3352/placement/g350-ti-top-bottom-ddr-v7-translation.json');TABLE=read('source/lib/am3352/placement/g350-ti-top-bottom-ddr-v5.json');DECL=json.loads((OLD/'packet-manifest.json').read_bytes())['planeDeclarations']
def run(c):return validate(BASE,V5,V6,c,POSES,TABLE,DECL)
class Tests(unittest.TestCase):
 def test_actual_data_fullchain_passes_only_new_inverse_view(self):
  spec=importlib.util.spec_from_file_location('old_v7_failed_validator',OLD/'validate_v7.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
  with self.assertRaisesRegex(ValueError,'Unplanned geometry movement'):old.validate(BASE,V5,V6,ACTUAL,POSES,TABLE,DECL)
  result=run(ACTUAL);self.assertTrue(result['passed']);self.assertTrue(result['only18RealPartsAnd2ReferenceAliasComponentsTranslated']);self.assertFalse(result['accepted49'])
 def test_synthetic_fullchain_positive_never_exported(self):self.assertTrue(run(synthetic_control(V6))['passed'])
 def test_fixed_cpu_geometry_real_change_rejected(self):
  x=copy.deepcopy(ACTUAL);e=next(e for e in x if e['type']=='pcb_component' and e['pcb_component_id']=='pcb_component_0');e['center']['x']+=.001
  with self.assertRaisesRegex(ValueError,'freshRigidDelta'):run(x)
 def test_moved_part_width_change_above_original_tolerance_rejected(self):
  x=copy.deepcopy(ACTUAL);e=next(e for e in x if e['type']=='pcb_component' and e['pcb_component_id']=='pcb_component_125');e['width']+=.001
  with self.assertRaisesRegex(ValueError,'freshRigidDelta'):run(x)
 def test_logical_owner_change_rejected(self):
  x=copy.deepcopy(ACTUAL);e=next(e for e in x if e['type']=='source_port');e['name']='changed-owner'
  with self.assertRaisesRegex(ValueError,'unchangedLogical'):run(x)
 def test_reference_hole_or_stub_change_rejected(self):
  for kind in ['pcb_via','pcb_trace']:
   x=copy.deepcopy(ACTUAL);e=next(e for e in x if e['type']==kind)
   if kind=='pcb_via':e['hole_diameter']+=.01
   else:e['route'][0]['x']+=.02
   with self.assertRaisesRegex(ValueError,'rigidReference'):run(x)
 def test_extra_ram_translation_one_micron_rejected(self):
  x=copy.deepcopy(ACTUAL);e=next(e for e in x if e['type']=='pcb_component' and e['pcb_component_id']=='pcb_component_1');e['center']['x']+=.001
  with self.assertRaisesRegex(ValueError,'freshRigidDelta'):run(x)
 def test_reference_span_or_owner_change_rejected(self):
  for field,value in [('layers',['top','bottom']),('source_net_id','foreign-reference-owner')]:
   x=copy.deepcopy(ACTUAL);e=next(e for e in x if e['type']=='pcb_via');e[field]=value
   with self.assertRaisesRegex(ValueError,'rigidReference'):run(x)
 def test_unknown_field_extra_record_or_moved_layer_rejected(self):
  for mutation in ['field','record','layer']:
   x=copy.deepcopy(ACTUAL);e=next(e for e in x if e['type']=='pcb_component' and e['pcb_component_id']=='pcb_component_1')
   if mutation=='field':e['unknown_physical_field']='unplanned'
   elif mutation=='record':x.append(copy.deepcopy(e))
   else:e['layer']='bottom'
   with self.assertRaises(ValueError):run(x)
if __name__=='__main__':unittest.main()
