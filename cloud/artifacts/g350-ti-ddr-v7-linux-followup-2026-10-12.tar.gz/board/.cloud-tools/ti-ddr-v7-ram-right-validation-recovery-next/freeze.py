"""Freeze validation-only recovery; no new Circuit/export/native/Core execution."""
from pathlib import Path
import json,os,stat
from inventory import sha,tree
ROOT=Path(__file__).resolve().parent;BOARD=Path('/workspace/g350-linux-handheld');OLD=BOARD/'.cloud-tools/ti-ddr-v7-ram-right-source-next';POLICY={'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
assert not(ROOT/'packet-manifest.json').exists() and not(ROOT/'run').exists()
old=json.loads((OLD/'packet-manifest.json').read_bytes())
for row in old['files']:
 if row['path'].startswith('source/'):assert sha(ROOT/row['path'])==row['sha256'] and sha(OLD/row['path'])==row['sha256']
assert sha(ROOT/'inputs/actual-v7-layout.circuit.json')=='2e81dc80bbeb7b9e687c5056a409979b0655592213fb993e9c029ae46bd847e7'
assert (ROOT/'inputs/actual-v7-layout.circuit.json').read_bytes()==(OLD/'run/fresh-layout.circuit.json').read_bytes()
for n in ['derive-input.py','capture-v7.ts','check-native-physical.mjs','process_scope.py','validate_v6.py','validate_reference_bypass.py','validate_layout.py']:assert sha(ROOT/n)==sha(OLD/n),n
assert sha(ROOT/'process_scope.py')=='7bdc74b15af3ba5b2c306d34a816b48cf8b9d68479b0c06a57f43787d4a4a993'
def item(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)}
external=old['externalFiles']+[item(OLD/n) for n in ['packet-manifest.json','run/fresh-layout.circuit.json','run/source-build-exit.json','run/postflight.json','run/execution.json','run/child.log','outer-exit.json','validate_v7.py','final-preflight-validation.json']]+[item(BOARD/'.cloud-tools/ti-ddr-v7-ram-right-independent-prelaunch-review.json')]
deps=tree(BOARD/'node_modules')
for k in ['treeSha256','regularFiles','regularBytes','symlinks','directories']:assert deps[k]==old['dependencyTree'][k]
(ROOT/'dependency-tree.json').write_text(json.dumps(deps,indent=2)+'\n');resolver=[p.replace(str(OLD),str(ROOT)) for p in old['resolverMustRemainAbsent']]
for name in resolver:assert not(Path(name).exists() or Path(name).is_symlink())
template={'authorizedByRoot':False,'scope':'one-ti-v7-exported-source-validation-only-no-new-export-no-router','packetSha256':'REVIEWED_RECOVERY_PACKET_REQUIRED','policy':POLICY,'approvalToken':'ROOT_DELEGATED_VALIDATION_NONCE_REQUIRED','accepted49':False};(ROOT/'launch-receipt.TEMPLATE.json').write_text(json.dumps(template,indent=2)+'\n')
files=[]
for current,dirs,names in os.walk(ROOT,followlinks=False):
 dirs[:]=[d for d in dirs if d!='__pycache__' and not(Path(current)/d).is_symlink()]
 for n in names:
  p=Path(current)/n
  if p.is_symlink():continue
  assert stat.S_ISREG(p.lstat().st_mode);files.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)})
files.sort(key=lambda r:r['path']);m={'schemaVersion':1,'scope':template['scope'],'policy':POLICY,'sourceFileCount':120,'freshOutput':'inputs/actual-v7-layout.circuit.json','actualV7SourceSha256':sha(OLD/'run/fresh-layout.circuit.json'),'originalActualSourcePath':str(OLD/'run/fresh-layout.circuit.json'),'originalBuildExitPath':str(OLD/'run/source-build-exit.json'),'planeDeclarations':old['planeDeclarations'],'pinnedVersions':old['pinnedVersions'],'pinnedRuntimeVersions':old['pinnedRuntimeVersions'],'nativeChecksPatchSha256':old['nativeChecksPatchSha256'],'dependencyTree':{k:v for k,v in deps.items() if k!='items'},'dependencyTreeManifestSha256':sha(ROOT/'dependency-tree.json'),'files':files,'externalFiles':external,'resolverMustRemainAbsent':resolver,'originalFailedPacketSha256':sha(OLD/'packet-manifest.json'),'originalSourceBuildExitCode':0,'originalControllerOuterExitCode':2,'originalControllerResultTrustEligible':False,'inverseViewOnlyCanonicalizationAfterUnchangedToleranceProof':True,'actualSourceBytesNeverCanonicalizedOrReserialized':True,'newSourceBuildCount':0,'nativeChecksRun':False,'actualCircuitExecuted':False,'rootDelegatedOneValidationOnly':True,'cadRequested':False,'autoroutingRequested':False,'accepted49':False,'fabricationReady':False};(ROOT/'packet-manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'packetSha256':sha(ROOT/'packet-manifest.json'),'files':len(files),'external':len(external),'newSourceBuilds':0,'actualNativeCalls':0}))
