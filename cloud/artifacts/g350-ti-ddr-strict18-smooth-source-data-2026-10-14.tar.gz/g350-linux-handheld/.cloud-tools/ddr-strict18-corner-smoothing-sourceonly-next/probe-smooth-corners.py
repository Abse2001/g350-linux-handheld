"""Bounded pure-stdlib corner smoothing, no application imports/execution."""
import json,math,hashlib,copy,ast,importlib.util,sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
DATA=ROOT/'ddr-byte1-matched-cohort-followthrough-sourceonly-next/NORMALIZED_MATCHED_DQS0_INNER1_SOURCE30_BOTTOM_SOURCE40_INNER2_SOURCE31_INNER1_JOINT_DATASET18_08.json';FULL=ROOT/'ddr-package101-plus96-signals-combined-sourceonly-next/combined-input.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(DATA)=='21316c4be094f8ec42c2d69a02b70e716ff80c5b49a3b906be78873450ad62d4'
assert sha(FULL)=='ed97be5fae82111e8e08247ba97f2a4a5977d33bd1b901a0428a1cf155af59fc'
def xy(p):return p['x'],p['y']
def P(p):return {'x':p[0],'y':p[1]}
def length(p):return sum(math.dist(a,b)for a,b in zip(p,p[1:]))
def fillet(path,indices,radius=.1016,step=15):
 p=[xy(q)if isinstance(q,dict)else tuple(q)for q in path];arcs={};details=[]
 for i in indices:
  a,b,c=p[i-1:i+2];du=math.dist(a,b);dv=math.dist(b,c);u=((b[0]-a[0])/du,(b[1]-a[1])/du);v=((c[0]-b[0])/dv,(c[1]-b[1])/dv);turn=math.atan2(u[0]*v[1]-u[1]*v[0],u[0]*v[0]+u[1]*v[1]);t=radius*math.tan(abs(turn)/2);sgn=1 if turn>0 else -1
  tin=b[0]-t*u[0],b[1]-t*u[1];tout=b[0]+t*v[0],b[1]+t*v[1];center=tin[0]-sgn*u[1]*radius,tin[1]+sgn*u[0]*radius;angle=math.atan2(tin[1]-center[1],tin[0]-center[0]);count=math.ceil(abs(math.degrees(turn))/step)
  q=[(center[0]+radius*math.cos(angle+turn*j/count),center[1]+radius*math.sin(angle+turn*j/count))for j in range(count+1)];q[0]=tin;q[-1]=tout;arcs[i]=q;details.append({'originalIndex':i,'radiusMm':radius,'turnDegrees':math.degrees(turn),'tangentTrimMm':t,'originalAdjacentSpansMm':[du,dv],'newPointCount':len(q),'center':P(center),'incomingTangent':P(tin),'outgoingTangent':P(tout)})
 # Adjacent arc tangencies must retain strictly forward straight spans.
 for i in range(len(p)-1):
  a=arcs[i][-1]if i in arcs else p[i];b=arcs[i+1][0]if i+1 in arcs else p[i+1];d=(p[i+1][0]-p[i][0],p[i+1][1]-p[i][1]);dot=(b[0]-a[0])*d[0]+(b[1]-a[1])*d[1]
  if dot<-1e-12:raise ValueError('Overlapping tangent intervals at '+str(i))
 out=[];mapping={}
 for i,q in enumerate(p):
  if i in arcs:out.extend(arcs[i]);mapping[i]={'incoming':len(out)-len(arcs[i]),'outgoing':len(out)-1}
  else:mapping[i]={'unchanged':len(out)};out.append(q)
 return [P(q)for q in out],details,mapping

def turns(path):
 p=[xy(q)for q in path];out=[]
 for i,(a,b,c)in enumerate(zip(p,p[1:],p[2:]),1):
  u=b[0]-a[0],b[1]-a[1];v=c[0]-b[0],c[1]-b[1];angle=abs(math.degrees(math.atan2(u[0]*v[1]-u[1]*v[0],u[0]*v[0]+u[1]*v[1])));out.append({'index':i,'turnDegrees':angle})
 return out
# This dependency chain was read as pure standard-library geometry; guarded mains are not run.
sp=importlib.util.spec_from_file_location('pinned_stdlib_floor',ROOT/'ddr-byte1-matched-cohort-followthrough-sourceonly-next/native-floor-policy.py');nfp=importlib.util.module_from_spec(sp);sp.loader.exec_module(nfp);m=nfp.e.m
# Exact frozen original self-clear translation, isolated function only; no module/app main.
SELF=Path('/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-clock-pair-static-followthrough-next/inspect_static_pair_v11.py');ss=SELF.read_text()
def dst(a,b):return math.dist(xy(a),xy(b))
def seg(a,b,c,d):return m.g.segdist(xy(a),xy(b),xy(c),xy(d))
ns={'math':math,'P':lambda x,y:{'x':x,'y':y},'dst':dst,'seg':seg};exec(compile(ss[ss.index('def selfcheck('):ss.index('# Reproduce scalarpackage')],'<pinned-original-self-clear-translation>','exec'),ns);selfcheck=ns['selfcheck']
full=json.loads(FULL.read_bytes());data=json.loads(DATA.read_bytes());original={r['sourceTraceId']:r for r in data['records']}

def screen(records,n):
 rs={k:{'layer':r['layer'],'path':[xy(q)for q in r['path']]}for k,r in records.items()};scene=nfp.NativeFloorScene(full,{'connections':full['connections']},rs[n]['layer'],rs,n);bad=[];minimum=None
 for k,(a,b)in enumerate(zip(rs[n]['path'],rs[n]['path'][1:])):
  for item in scene.items:
   if n in item['owners']:continue
   slack=m.g.segdist(a,b,item['a'],item['b'])-.2032 if 'ddrOwner'in item else scene.slack(item,a,b)
   row={'segment':k,'foreignId':item['id'],'foreignOwners':sorted(item['owners']),'slackMm':slack}
   if minimum is None or slack<minimum['slackMm']:minimum=row
   if slack<-1e-9:bad.append(row)
 return {'physicalViolationCount':len(bad),'violations':bad,'minimum':minimum,'self':selfcheck(records[n]['path']),'maximumTurnDegrees':max(q['turnDegrees']for q in turns(records[n]['path']))}
if __name__=='__main__':
 for n in ['source_trace_15','source_trace_16']:
  r=original[n];oldlength=length([xy(q)for q in r['path']]);ev=[]
  for tipx in [4.4,4.5,4.6,4.7,4.8,4.9,5.0]:
   p=copy.deepcopy(r['path']);p[1]['x']=tipx
   try:q,arcs,mapping=fillet(p,[1]);rs=copy.deepcopy(original);rs[n]['path']=q;s=screen(rs,n);ev.append({'tipX':tipx,'lengthDeltaMm':length([xy(q)for q in q])-oldlength,'result':s})
   except ValueError as e:ev.append({'tipX':tipx,'failure':str(e)})
  print(n,json.dumps(ev))
