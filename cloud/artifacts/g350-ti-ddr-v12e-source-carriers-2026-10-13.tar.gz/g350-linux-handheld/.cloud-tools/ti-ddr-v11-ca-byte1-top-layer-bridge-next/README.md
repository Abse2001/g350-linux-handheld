V11 source-only explicit layer-policy bridge

Only DDR_BYTE1 final allowed/preferred lists change Bottom -> Top. Allocation is COMMAND_CLOCK26+BYTE1 11 Top, BYTE0 11+RESET1 Bottom; four physical layers retain the existing reference-plane policy. Full physical input, numeric contacts, all49 owners,856obstacles,2fixed references, widths/gaps/curves, .635/.127skew, min/max windows and equal-via-count options remain exact.

The physical Core source2312 and its17zero native placement checks are inherited from root-collected V10session33215/8aad; no newCore/native/checker execution is claimed. Core source_bus JSON omits layer/preferences/absolute windows, so this is an explicit authored-props projection, not a freshly captured Core input. derived-final-authored-props.json is a pure derivation from actual V10c606 final props plus a literal final BYTE1Top React overlay. Actual pure React evaluation is pending and must pass before public routing initializes.

Root-controlled first child (60s wall,1GiB owned,24GiB shared+2GiB reserve, prefork identity/reserve recheck):
/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/.bin/bun --smol /workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v11-ca-byte1-top-layer-bridge-next/capture-v11-authored-props.ts FRESH_CHILD_OUTPUT_JSON
cwd: /workspace/g350-linux-handheld. Script writes fresh output only (wx), imports the frozen authored source tree and evaluates final React props; no Core Circuit/render, native checker or routing instance. Root must bind the clean guard receipt and call verify_actual_authored_props before routing. Deterministic new Node producer build remains required; existing exact runtime127/observer941/API/native8967/errorcapture965125 proofs are inherited. No repeated5/19 native controls are needed for unchanged runtime/observer/fixture APIs.

No worker has run in this namespace. All frozen V10/V9/evidence/canonical sources remain untouched. No route, timing, full board, plane continuity or fabrication acceptance is claimed.
