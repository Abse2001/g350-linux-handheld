"""Source-only future Root Native18/API guard; no application import in Python."""
import argparse,fcntl,hashlib,importlib.util,json,os,re,stat,sys
sys.dont_write_bytecode=True
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BOARD=Path('/workspace/g350-linux-handheld')
SOURCE=BOARD/'.cloud-tools/ddr-clock-v11-manual-pair-source-successor-next'
# Exact Python predecessor checks bind full Ce3/47633 SDKs and source closure.
# This reads stdlib source only; it does not invoke its guard or stage workers.
sys.path.insert(0,str(SOURCE))
spec=importlib.util.spec_from_file_location('manual_source_guard_readonly_library',SOURCE/'guard.py')
source_guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(source_guard)
process_scope=source_guard.process_scope
sha=source_guard.sha
read=source_guard.read
require=source_guard.require
verifyrows=source_guard.verifyrows
exact_json=source_guard.exact_json
collected=source_guard.collected
def checked():
 m=read(ROOT/'PREPARED-manifest.json');verifyrows(m['files']);verifyrows(m['externalFiles'])
 require(sha(SOURCE/'PREPARED-manifest.json')==m['sourcePreparedManifestSha256'],'Manual Source packet changed')
 sm,sp,board,solver=source_guard.checked()
 require(sp==m['sourcePreparedManifestSha256'] and sm['clockSourceManifestSha256']==m['sourceManifestSha256'],'Exact original/fresh Source packet required')
 require(not (ROOT/'node_modules').exists() and not (ROOT/'node_modules').is_symlink(),'Native worker dependency shadow forbidden')
 for name in ('.pnp.cjs','.pnp.loader.mjs','.yarn'):require(not (ROOT/name).exists() and not (ROOT/name).is_symlink(),'Native alternate resolver forbidden')
 return m,sha(ROOT/'PREPARED-manifest.json'),board,solver,sm
def successful_core(row,m):
 c,p,e=collected(row,positive=True)
 require(c.get('phase')=='core' and c.get('packetSha256')==m['sourcePreparedManifestSha256'] and p.get('phase')=='core' and p.get('packetSha256Before')==m['sourcePreparedManifestSha256'] and p.get('packetSha256After')==m['sourcePreparedManifestSha256'],'Actual successful Core must belong to the exact manual Source packet')
 require(p['clockSourceManifestSha256']==m['sourceManifestSha256'],'Actual Core Source scope differs')
 result=exact_json({'path':p['resultPath'],'sha256':p['resultSha256']})
 require(result.get('passed') is True and result.get('phase')=='core' and result.get('packetSha256')==m['sourcePreparedManifestSha256'] and result.get('clockSourceManifestSha256')==m['sourceManifestSha256'] and result.get('actualCoreCalls')==1 and result.get('freshCoreControlPassed') is True and result.get('nativeExplicitCalls')==0 and result.get('cadCalls')==0,'Actual Core result failed, reused or already qualified elsewhere')
 verifyrows(p['outputFiles'])
 artifacts={k:result[k] for k in ('actualCorePath','actualCoreSha256','coreControlsPath','coreControlsSha256')}
 require(Path(artifacts['actualCorePath'])==SOURCE/'run-core/raw-core.json' and Path(artifacts['coreControlsPath'])==SOURCE/'run-core/core-controls.json','Only actual guarded fresh source/Core outputs accepted')
 control=exact_json({'path':artifacts['coreControlsPath'],'sha256':artifacts['coreControlsSha256']})
 require(sha(artifacts['actualCorePath'])==artifacts['actualCoreSha256'] and control['rawCorePath']==artifacts['actualCorePath'] and control['rawCoreSha256']==artifacts['actualCoreSha256'] and control['freshCoreControlPassed'] is True and control['exactPersistedSerializerBytesCompared'] is True and control['actualGeneratedSourceBusIdsRetained'] is True and all(r['passed'] is True for r in control['checks']),'Actual saved raw Core/control hashes do not pass')
 require(control['manualPairSourceFork']['complete49AuthoritativeRoutingInputSha256']==m['authoritative49InputSha256'] and control['automaticCoreSrjDifferentialDiscoveryEquivalent'] is False and control['automaticCoreSrjForThisForkMustNotBeUsed'] is True,'The manual-only original coupling input contract changed')
 return e['pgid'],artifacts
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true',required=True);parser.add_argument('--root-receipt',type=Path,required=True);parser.add_argument('--root-receipt-sha256',required=True);args=parser.parse_args()
 m,packet,board_before,solver_before,sm=checked();a=exact_json({'path':str(args.root_receipt),'sha256':args.root_receipt_sha256})
 require(a.get('authorizedByRoot') is True and a.get('scope')==m['scope'] and a.get('packetSha256')==packet and a.get('sourcePreparedManifestSha256')==m['sourcePreparedManifestSha256'] and a.get('policy')==m['policy'] and a.get('allPreviousRootWorkersCollected') is True and a.get('noConcurrentRootWorker') is True and a.get('rootFullGuardReadPassed') is True and re.fullmatch('[0-9a-f]{32,128}',a.get('approvalToken','')),'Exact fresh Root Native authority/read/serial policy required')
 peer=exact_json(a['nativePacketPeerReview']);require(peer['preparedManifestSha256']==packet and peer['decision']=='GO_SOURCE_ONLY_TO_ROOT_READ_AND_SEPARATELY_GUARDED_FRESH_NATIVE_API','Finite Native source peer GO required')
 initial,post,execution=collected(a['requiredActual42982Collection'],tool=42982)
 require(initial['packetSha256']==sm['required42982PacketSha256'] and post['packetSha256']==sm['required42982PacketSha256'] and post['stage']=='candidate','Actual42982 original candidate closure binding differs')
 groups=[execution['pgid']]
 additional=a.get('additionalPreviousRootCollections',[])
 for row in sm['requiredAdditionalClosedRootCollections']:require(row in additional,'Required actual prior Root collection omitted')
 for row in additional:groups.append(collected(row)[2]['pgid'])
 prior=a.get('successfulPriorStages',{});require(set(prior)=={'capture','types'},'Real successful Source and strict type stages required')
 for phase in ('capture','types'):groups.append(source_guard.successful_stage(prior[phase],phase,m['sourcePreparedManifestSha256'],sm))
 core_group,actual=successful_core(a['successfulCoreCollection'],m);groups.append(core_group)
 require(actual==a.get('freshArtifacts'),'Root-authorized fresh artifacts differ from actual Core result')
 def closed_now():
  for pgid in groups:require(isinstance(pgid,int) and pgid>0 and pgid!=os.getpid() and process_scope.owned(pgid)==[],'Actual previous owned PGID/SID is still live')
 closed_now();run=ROOT/'run-native';require(not run.exists() and not run.is_symlink(),'One fresh exclusive Native output only')
 def before_spawn(mem):
  closed_now();require(mem['current']+m['policy']['rssBytes']+m['preforkReserveBytes']<m['policy']['sharedBytes'],'30GiB shared plus1GiB reserve failed')
 with (ROOT/'serial-root.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);execution=None;run_error=None
  try:execution=process_scope.run_guarded([sys.executable,'-B',str(ROOT/'run_stage.py')],str(BOARD),run,m['policy'],{'G350_CLOCK_FRESH_NATIVE_PACKET_SHA':packet,'G350_CLOCK_FRESH_NATIVE_ROOT_RECEIPT':str(args.root_receipt.resolve()),'G350_CLOCK_FRESH_NATIVE_ROOT_RECEIPT_SHA':args.root_receipt_sha256},before_spawn=before_spawn)
  except BaseException as error:
   run_error=type(error).__name__+': '+str(error)
   if (run/'execution.json').is_file():execution=read(run/'execution.json')
  post_error=None;board_after=None;solver_after=None;after_packet=None
  try:
   _,after_packet,board_after,solver_after,_=checked();require(sha(args.root_receipt)==args.root_receipt_sha256,'Root authority changed');_,after_actual=successful_core(a['successfulCoreCollection'],m);require(after_actual==actual,'Actual fresh Core outputs changed during Native');closed_now()
  except BaseException as error:post_error=type(error).__name__+': '+str(error)
  outputFiles=[{'path':str(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':sha(p)} for p in sorted(run.iterdir()) if p.is_file() and not p.is_symlink()] if run.is_dir() else []
  result_path=run/'result.json';result=read(result_path) if result_path.is_file() else None
  held=post_error is None and packet==after_packet and board_before==board_after and solver_before==solver_after
  clean=execution is not None and execution.get('exitCode')==0 and execution.get('diagnosticStopped') is False and execution.get('cleanupOwnedGroupEmpty') is True and not any(execution.get('oomDelta',{}).values())
  passed=run_error is None and clean and held and result is not None and result.get('passed') is True
  post={'scope':m['scope'],'packetSha256Before':packet,'packetSha256After':after_packet,'rootReceiptSha256':args.root_receipt_sha256,'sourcePreparedManifestSha256':m['sourcePreparedManifestSha256'],'sourceManifestSha256':m['sourceManifestSha256'],'actualFreshCoreArtifacts':actual,'execution':execution,'dependenciesBefore':board_before,'dependenciesAfter':board_after,'solverDependenciesBefore':solver_before,'solverDependenciesAfter':solver_after,'sourceAndDependenciesHeld':held,'runFailure':run_error,'postverificationFailure':post_error,'resultPath':str(result_path),'resultSha256':sha(result_path) if result_path.is_file() else None,'outputFiles':outputFiles,'passed':passed,'actualFreshCoreNativeExecuted':result.get('nativeCalls',0) if result else 0,'actualOriginalClockApiExecuted':result.get('clockApiCalls',0) if result else 0,'coreCalls':0,'cliCalls':0,'cadCalls':0,'full49Qualified':False,'accepted49':False,'fabricationReady':False}
  with (ROOT/'POSTAUDIT-native.json').open('x') as f:json.dump(post,f,indent=2);f.write('\n')
  print(json.dumps({'passed':passed,'rawAndFailureOutputsPreserved':True,'sourceAndDependenciesHeld':held,'full49Unfinished':True,'accepted49':False,'fabricationReady':False}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
