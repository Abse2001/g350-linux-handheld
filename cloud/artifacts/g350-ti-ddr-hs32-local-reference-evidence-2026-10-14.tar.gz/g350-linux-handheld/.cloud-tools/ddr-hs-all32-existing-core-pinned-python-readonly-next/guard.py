"""Root-only bounded readonly retry; no board imports during preparation/preflight."""
from pathlib import Path
import argparse,hashlib,json,re,stat,sys
import inventory,process_scope,python_inventory
ROOT=Path(__file__).resolve().parent
BOARD=Path('/workspace/g350-linux-handheld')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def require(value,message):
 if not value:raise ValueError(message)
def checked():
 m=read(ROOT/'PREPARED-manifest.json')
 for key,base in [('files',ROOT),('externalFiles',None)]:
  for row in m[key]:
   p=base/row['path'] if base else Path(row['path'])
   require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Frozen member changed: '+str(p))
 for row in m['resolverLinks']:
  p=Path(row['path']);require(p.is_symlink() and str(p.readlink())==row['target'] and p.resolve()==BOARD/'node_modules','Exact existing pinned resolver required')
 listed={r['path'] for r in m['files']}
 for p in (ROOT/'source').rglob('*'):
  require(not p.is_symlink(),'Unexpected source symlink')
  if p.is_file():require(p.relative_to(ROOT).as_posix() in listed,'Unexpected source mutation/artifact')
 for base in (ROOT,ROOT.parent,ROOT/'source'):
  for name in ('.pnp.cjs','.pnp.loader.mjs','.yarn'):require(not(base/name).exists() and not(base/name).is_symlink(),'Unexpected resolver shadow')
 deps=inventory.tree(BOARD/'node_modules');small={k:deps[k] for k in ('treeSha256','regularFiles','regularBytes','symlinks','directories')}
 require(small==m['boardDependencyInventory'],'Complete pinned board dependency tree changed')
 python=python_inventory.snapshot(m['pythonTarget']);require(python==read(ROOT/'PINNED-PYTHON-INVENTORY.json'),'Exact imported numerical/geometry trees changed')
 return m,sha(ROOT/'PREPARED-manifest.json'),{'board':small,'python':python}
def verify_prior(m):
 parent=Path(m['priorSourcePacketPath']).parent
 for phase in ('capture','types','core'):
  row=m['priorCollectedStages'][phase];c=read(row['collectionPath']);post=parent/('run-'+phase)/'POSTAUDIT.json';prior=read(post);e=prior['execution'];result=read(parent/('run-'+phase)/'result.json')
  require(c.get('authorizedByRoot') is True and c.get('phase')==phase and c.get('packetSha256')==m['priorSourcePacketSha256'] and c.get('toolSessionCollected') is True and c.get('postauditPath')==str(post) and c.get('postauditSha256')==sha(post),'Actual collected previous '+phase+' required')
  require(prior['sourceAndDependenciesHeld'] is True and e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()) and prior['resultSha256']==sha(parent/('run-'+phase)/'result.json'),'Previous group/source/deps/result state differs')
  if phase in ('capture','types'):require(c['toolWrapperExitCode']==0 and prior['passed'] is True and e['exitCode']==0 and e['diagnosticStopped'] is False and result['passed'] is True,'Actual capture/type pass required')
  else:
   require(c['toolWrapperExitCode']==2 and prior['passed'] is False and e['exitCode']==1 and e['diagnosticStopped'] is False and result['passed'] is False and result['coreBuildCount']==1 and result['actualCoreSha256']==m['reusedActualCoreSha256'],'Preserved exact Core failure receipt required')
   require(len(result['commands'])==2 and result['commands'][0]['name']=='direct-pinned-core' and result['commands'][0]['exitCode']==0 and result['commands'][1]['name']=='strict-original-and-additions' and result['commands'][1]['exitCode']==1,'Actual Core success/strict failure chronology differs')
   require((parent/'run-core/strict-original-and-additions.log').read_text().endswith("ModuleNotFoundError: No module named 'shapely'\n"),'Exact diagnosed missing-target failure required')
def main():
 p=argparse.ArgumentParser();p.add_argument('--preflight',action='store_true');p.add_argument('--root-receipt',type=Path);p.add_argument('--root-receipt-sha256');args=p.parse_args()
 require(args.preflight!=bool(args.root_receipt),'Select preflight or exact Root authority')
 m,packet,before=checked();verify_prior(m);policy=m['stage']['policy']
 if args.preflight:print(json.dumps({'preflightOnly':True,'phase':'readonly','packetSha256':packet,'runtimeCalls':0,'reusedActualCoreSha256':m['reusedActualCoreSha256']}));return 0
 require(re.fullmatch('[0-9a-f]{64}',args.root_receipt_sha256 or '') and sha(args.root_receipt)==args.root_receipt_sha256,'Exact Root authority hash required')
 a=read(args.root_receipt)
 require(a.get('authorizedByRoot') is True and a.get('phase')=='readonly' and a.get('scope')==m['stage']['scope'] and a.get('packetSha256')==packet and a.get('policy')==policy and a.get('allPreviousRootWorkersCollected') is True and a.get('noConcurrentRootWorker') is True and re.fullmatch('[0-9a-f]{32,128}',a.get('approvalToken','')),'Exact Root scope/policy/exclusive authority required')
 closed=a.get('previousClosedPostaudits',[]);require(closed,'Latest actual closed Root worker scope required')
 for row in closed:
  require(re.fullmatch('[0-9a-f]{64}',row.get('sha256','')) and sha(row['path'])==row['sha256'],'Previous closed postaudit hash differs')
  e=read(row['path'])['execution'];require(e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()),'Previous Root group not cleanly empty')
 run=ROOT/'run-readonly';require(not run.exists(),'One fresh readonly run only')
 def before_spawn(mem):require(mem['current']+policy['rssBytes']+m['stage']['preforkReserveBytes']<policy['sharedBytes'],'Exact byte prefork reserve fails')
 env={'G350_HS_READONLY_STAGE':'readonly','G350_HS_PACKET_SHA':packet,'G350_HS_ROOT_RECEIPT':str(args.root_receipt.resolve()),'G350_HS_ROOT_RECEIPT_SHA':args.root_receipt_sha256,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
 execution=process_scope.run_guarded([m['pythonExecutable'],'-B',str(ROOT/'run_readonly.py')],str(ROOT),run,policy,env,before_spawn=before_spawn)
 after_m,after_packet,after=checked();verify_prior(after_m);result_path=run/'result.json';r=read(result_path) if result_path.is_file() else None
 clean=execution['exitCode']==0 and execution['diagnosticStopped'] is False and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values())
 held=packet==after_packet and before==after
 passed=clean and held and r is not None and r['passed'] is True and r['phase']=='readonly' and r['packetSha256']==packet and r['reusedActualCoreSha256']==m['reusedActualCoreSha256'] and r['coreBuildCount']==r['cliCalls']==r['routingCalls']==r['cadCalls']==0
 post={'phase':'readonly','packetSha256Before':packet,'packetSha256After':after_packet,'rootReceiptSha256':args.root_receipt_sha256,'execution':execution,'dependenciesBefore':before,'dependenciesAfter':after,'sourceAndDependenciesHeld':held,'reusedActualCoreSha256':m['reusedActualCoreSha256'],'resultSha256':sha(result_path) if result_path.is_file() else None,'passed':passed,'localHsLoopOnly':True,'referenceQualified':False,'accepted49':False,'fabricationReady':False}
 with (run/'POSTAUDIT.json').open('x') as f:json.dump(post,f,indent=2);f.write('\n')
 print(json.dumps({'phase':'readonly','passed':passed,'actualCoreCalls':0,'accepted49':False}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
