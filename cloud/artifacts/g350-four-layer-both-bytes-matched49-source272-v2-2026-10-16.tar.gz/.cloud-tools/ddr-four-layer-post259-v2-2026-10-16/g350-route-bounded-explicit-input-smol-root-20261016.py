import fcntl, hashlib, importlib.util, json, os, sys
from pathlib import Path

board = Path('/workspace/g350-linux-handheld')
cache = Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
run = Path(sys.argv[1])
worker = Path(sys.argv[2])
input_dir = Path(sys.argv[3])
extra = sys.argv[4:]
manifest = Path('/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/SOURCE-manifest.json')
helper = Path('/tmp/g350-process-scope-empty-argv-bounded-startup-retry-sourceonly-next/process_scope_empty_argv_retry.proposal.py')
protected = {
 'AGENTS.md':'d3086d9ff8887bd296ed0d480fcbef732686bf45e075ae766a0a292518086723',
 'cloud/CONTINUE_BOARD.md':'bb9a879c5c68c3718d24c82a77326f5b175d47899f101407b1e1ee106c8b19ef',
 'scripts/prepare-g350-ram90-four-layer.mjs':'ec6b56c59d2c8f72f969934076dd3597014833e8b2e8e4387c1045f03eaadda0',
 'scripts/tune-g350-ram90-native-lengths.mjs':'5bfe731744159cf9f65ddde71b513cb1a0d2384574e740cd11bc087ce69b4b40',
 'node_modules/@tscircuit/checks/dist/index.js':'1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc',
}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(manifest)=='b9700a9a44c9be5f661fd38c37ca9ff6c2f012983e49a750fecea3c8d75e19e0'
assert sha(helper)=='3756c2f9bfc8284135954669c0a1cbe0e5e966796b0743c6f462af703e17a361'
pins=json.loads(manifest.read_text())['solverSourceFiles']
def verify():
 for p in pins:
  path=Path(p['path']); assert sha(path)==p['sha256'] and path.stat().st_size==p['bytes'], path
 for rel,h in protected.items(): assert sha(board/rel)==h, rel
verify()
spec=importlib.util.spec_from_file_location('owned_scope',helper)
owned=importlib.util.module_from_spec(spec); spec.loader.exec_module(owned)
policy={'wallSeconds':180,'rssBytes':2*1024**3,'sharedBytes':30*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
def admit(m):
 assert m['current']+policy['rssBytes']+1024**3 < policy['sharedBytes'], ('memory admission', m['current'])
run.mkdir(parents=True, exist_ok=False)
intent = os.environ.get('G350_WORKER_INTENT','ROOT_AUTHORIZED_BYTE0_11_SOURCE33B_INTERSECTION')
command=[str(board/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),str(worker),
 '--caller-intent',intent,
 '--input',str(input_dir/'input.json'),'--proof',str(input_dir/'proof.json'),
 '--output',str(run/'byte0-result.json'),'--budget-ms','165000',*extra]
if os.environ.get('G350_DIRECT_CLI') == '1':
 command=[str(board/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),str(worker),
  '--input',str(input_dir/'input.json'),'--output',str(run/'byte0-result.json'),*extra]
if os.environ.get('G350_POSITIONAL_CLI') == '1':
 command=[str(board/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),str(worker),
  str(input_dir),str(run/'byte0-result.json'),*extra]
if os.environ.get('G350_EXPLICIT_INPUT_CLI') == '1':
 command=[str(board/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),str(worker),
  '--output',str(run/'byte0-result.json'),*extra]
if os.environ.get('G350_BUN_SMOL') == '1':
 command.insert(1, '--smol')
before={str(p):sha(p) for p in [worker,input_dir/'input.json',input_dir/'proof.json',helper,manifest]}
journal=cache/'LATEST_CONTINUATION_2026-10-14.json'
with (cache/'strict18-root-serial.lock').open('a') as lock:
 fcntl.flock(lock, fcntl.LOCK_EX)
 state=json.loads(journal.read_text()); assert not state.get('rootSdkInvocationOpen')
 scope=int(state.get('requiresCurrentClosedScopes',88))+1
 state.update(rootSdkInvocationOpen=True,activeRootScope=scope,lastAction=owned.utc(),nextOperation='Bounded genuine four-layer Byte0 reroute with released dogbones',currentRouteRun=str(run))
 journal.write_text(json.dumps(state,indent=2)+'\n')
 execution=None
 try:
  execution=owned.run_guarded(command,str(board),run/'owned',policy,before_spawn=admit)
 finally:
  verify()
  assert all(sha(Path(p))==h for p,h in before.items()), 'Source/data mutated'
  assert execution is None or owned.owned(execution['pgid'])==[], 'Owned processes remain'
  receipt={'scope':scope,'closedAt':owned.utc(),'sourcePinsUnchanged':True,'protectedFilesUnchanged':True,'execution':execution,'all49Accepted':False,'fabricationReady':False}
  (run/'COLLECTED.json').write_text(json.dumps(receipt,indent=2)+'\n')
  state=json.loads(journal.read_text()); state.update(rootSdkInvocationOpen=False,activeRootScope=None,requiresCurrentClosedScopes=scope,lastAction=owned.utc(),lastRouteCollection=str(run/'COLLECTED.json'))
  journal.write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps({'run':str(run),'scope':scope,'exitCode':execution['exitCode'] if execution else None,'ownedGroupEmpty':execution['cleanupOwnedGroupEmpty'] if execution else None,'stopReasons':execution.get('stopReasons',[]) if execution else []}))
