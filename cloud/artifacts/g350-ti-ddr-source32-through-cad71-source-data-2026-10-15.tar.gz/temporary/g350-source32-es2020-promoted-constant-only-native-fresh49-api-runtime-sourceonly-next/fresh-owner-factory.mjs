// SOURCE-ONLY. The Root requires actual collected Source32 Core0 before invocation.
// Read-only authentication of genuine fresh rows; never creates circuit JSON rows.
import assert from 'node:assert/strict'
import {getFullConnectivityMapFromCircuitJson} from '/workspace/g350-linux-handheld/node_modules/circuit-json-to-connectivity-map/dist/index.js'
const states=new WeakMap(),LAYERS=['top','inner1','inner2','bottom'],EPS=1e-8
const one=(rows,label)=>{assert.equal(rows.length,1,label);return rows[0]}
const near=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<EPS
const at=(a,b)=>a&&b&&near(a.x,b.x)&&near(a.y,b.y)
const canonical=x=>Array.isArray(x)?'['+x.map(canonical).join(',')+']':x&&typeof x==='object'?'{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical(x[k])).join(',')+'}':JSON.stringify(x)
const same=(a,b,label)=>assert.equal(canonical(a),canonical(b),label)
const omit=(r,keys)=>Object.fromEntries(Object.entries(r).filter(([k])=>!keys.includes(k)))
const logical=r=>omit(r,['subcircuit_connectivity_map_key'])
const pointShape=p=>omit(p,['start_pcb_port_id','end_pcb_port_id'])
const routeShape=r=>r.map(pointShape)
const geometrySame=(a,b)=>typeof a==='number'&&typeof b==='number'?near(a,b):Array.isArray(a)||Array.isArray(b)?Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((v,i)=>geometrySame(v,b[i])):a&&b&&typeof a==='object'&&typeof b==='object'?canonical(Object.keys(a).sort())===canonical(Object.keys(b).sort())&&Object.keys(a).every(k=>geometrySame(a[k],b[k])):a===b
function index(circuit){
 assert(Array.isArray(circuit));const byType=new Map(),maps=new Map()
 for(const r of circuit){assert(r&&typeof r.type==='string');if(!byType.has(r.type))byType.set(r.type,[]);byType.get(r.type).push(r)}
 const rows=t=>byType.get(t)||[]
 const by=(t,id)=>{if(!maps.has(t)){const m=new Map();for(const r of rows(t)){const k=r[t+'_id'];assert.equal(typeof k,'string');assert(!m.has(k),'Duplicate actual ID '+k);m.set(k,r)}maps.set(t,m)}const r=maps.get(t).get(id);assert(r,'Missing actual '+t+' '+id);return r}
 return {rows,by}
}
function alias(actual,via,layer){
 const pcb=one(via.pcb_port_ids.map(id=>actual.by('pcb_port',id)).filter(p=>canonical(p.layers)===canonical([layer])),'One actual '+layer+' alias')
 assert(at(pcb,via));const source=actual.by('source_port',pcb.source_port_id);assert.equal(source.name,layer)
 const owner=actual.by('source_manually_placed_via',source.source_component_id),placeholder=actual.by('pcb_component',pcb.pcb_component_id)
 assert.equal(placeholder.source_component_id,owner.source_manually_placed_via_id);assert(at(placeholder.center,via));assert.equal(placeholder.width,.4572);assert.equal(placeholder.height,.4572)
 assert.equal(owner.source_net_id,via.source_net_id,'No signal rail fabrication')
 return {pcb,source,owner}
}
function endpoints(t,ids){
 const found=t.route.flatMap((p,i)=>i===0||i===t.route.length-1?[p.start_pcb_port_id,p.end_pcb_port_id].filter(Boolean):[])
 same([...found].sort(),[...ids].sort(),'Exact actual trace endpoint IDs');assert(!t.route.slice(1,-1).some(p=>p.start_pcb_port_id||p.end_pcb_port_id))
}
const freeze=v=>{if(v&&typeof v==='object'&&!Object.isFrozen(v)){Object.values(v).forEach(freeze);Object.freeze(v)}return v}
export function proveFreshIntermediate32Core({freshCore,controls,oldCore,oldNativeProof,proposal,material,nativeTargets}){
 const before=JSON.stringify(freshCore),actual=index(freshCore),old=index(oldCore)
 assert.equal(controls.scope,'ROOT_FRESH_EDITABLE_SOURCE_CORE_229_SOURCE20_SOURCE21_INTERMEDIATE_VIAS_AND_SOURCE45_32');assert.equal(controls.freshCoreControlPassed,true);assert.equal(controls.checks.length,29);assert(controls.checks.every(r=>r.passed===true))
 assert.equal(controls.sourceNumericAndPhysicalIdsDerivedWithoutAssignment,true);assert.equal(controls.circuitJsonGeometryEdited,false);assert.equal(controls.pcbRoutingDisabled,true);assert.equal(controls.expectedOriginalCarrierCount,32);assert.equal(controls.expectedMissingOriginalSignalCount,17)
 assert.equal(controls.automaticCoreSrjForThisForkMustNotBeUsed,true)
 for(const [t,n]of [['pcb_via',229],['pcb_trace',297],['pcb_port',1671],['source_port',1671],['pcb_smtpad',1161],['source_component',280],['pcb_component',509],['source_net',98],['source_bus',8],['pcb_hole',2],['pcb_plated_hole',4]])assert.equal(actual.rows(t).length,n,t)
 assert.equal(actual.rows('pcb_port').filter(p=>p.layers.length===1&&['inner1','inner2'].includes(p.layers[0])).length,52,'Exact Source32 inner aliases');
 assert.equal(proposal.all98NumericOwnedSignalBranches.length,98);assert.equal(proposal.selected32OriginalCarriers.length,32);assert.equal(material.referenceViaTargets129.length,129);assert.equal(material.referencePathTargets165.length,165)
 // The entire original logical trace/bus/rail declarations are authenticated independently.
 for(const r of old.rows('source_trace').filter(r=>/^source_trace_\d+$/.test(r.source_trace_id)&&Number(r.source_trace_id.slice(13))<49))same(logical(actual.by('source_trace',r.source_trace_id)),logical(r),'Original49 logical numeric requests')
 for(const type of ['source_net','source_bus']){
  const pending=actual.rows(type).slice();for(const r of old.rows(type)){const shape=x=>type==='source_bus'?omit(x,['source_bus_id']):logical(x);const i=pending.findIndex(x=>canonical(shape(x))===canonical(shape(r)));assert(i>=0,'Every original '+type+' held');pending.splice(i,1)}assert.equal(pending.length,0)
 }
 const partByName=name=>one(actual.rows('source_component').filter(r=>r.name===name),'One real component '+name)
 const numeric=selector=>{
  const match=/^(.*)\.pin(\d+)$/.exec(selector);assert(match);const part=partByName(match[1]),sp=one(actual.rows('source_port').filter(r=>r.source_component_id===part.source_component_id&&r.pin_number===Number(match[2])),'Actual numeric pin')
  same(logical(sp),logical(old.by('source_port',sp.source_port_id)),'Original numeric Source owner');same(logical(part),logical(old.by('source_component',part.source_component_id)),'Real part metadata')
  const pcb=one(actual.rows('pcb_port').filter(r=>r.source_port_id===sp.source_port_id),'Actual numeric PCB port'),pad=one(actual.rows('pcb_smtpad').filter(r=>r.pcb_port_id===pcb.pcb_port_id),'Actual numeric land')
  const target=one(nativeTargets.allOriginalCopperLands.filter(r=>r.pcb_port_id===one(old.rows('pcb_port').filter(p=>p.source_port_id===sp.source_port_id),'Old numeric origin').pcb_port_id),'One planning numeric copper target')
  assert(geometrySame(omit(pad,['pcb_smtpad_id','pcb_port_id','pcb_component_id']),omit(target,['pcb_smtpad_id','pcb_port_id','pcb_component_id'])),'Planned real moved pad shape')
  assert(at(pcb,pad));return {part,sp,pcb,pad}
 }
 const usedVias=new Set(),usedTraces=new Set(),viaByName=new Map(),viaByOrigin=new Map(),registry=new Map(),padRegistry=new Map(),referenceMappings=[],signalMappings=[]
 for(const target of material.referenceViaTargets129){
  const ctl=one(controls.viaProjection.filter(r=>r.sourceViaName===target.sourceViaName),'Collected actual reference via projection');assert.equal(ctl.passed,true);assert.equal(ctl.reference,true)
  const v=actual.by('pcb_via',ctl.actualViaId),expected=target.expectedPhysical
  for(const k of ['x','y','outer_diameter','hole_diameter','layers','from_layer','to_layer','tented_on_top','tented_on_bottom','source_net_id'])assert(geometrySame(v[k],expected[k]),'Reference actual '+k)
  assert(!usedVias.has(v.pcb_via_id));usedVias.add(v.pcb_via_id);assert.equal(v.pcb_port_ids.length,2)
  const a=alias(actual,v,'top'),b=alias(actual,v,'bottom');assert.equal(a.owner.source_manually_placed_via_id,b.owner.source_manually_placed_via_id);assert.equal(a.owner.source_manually_placed_via_id,ctl.actualSourceViaOwner)
  for(const own of [a,b]){const c=one(ctl.aliases.filter(r=>r.layer===own.source.name),'Exact reference projection alias');assert(c.authentic);assert.equal(c.actualPcbPortId,own.pcb.pcb_port_id);assert.equal(c.actualSourcePortId,own.source.source_port_id)}
  viaByName.set(target.sourceViaName,v);viaByOrigin.set(target.originViaIdForMappingOnly,v);registry.set(v.pcb_via_id,new Set())
 }
 for(const target of material.referencePathTargets165){
  const ctl=one(controls.referenceProjection.filter(r=>r.literalTraceName===target.literalTraceName),'Actual reference path projection');assert(ctl.passed&&ctl.semanticOwnerHeld)
  const t=actual.by('pcb_trace',ctl.actualPcbTraceId),source=actual.by('source_trace',t.source_trace_id);assert.equal(source.name,target.literalTraceName);assert.equal(source.source_trace_id,ctl.actualSourceTraceId)
  const oldSource=old.by('source_trace',target.actualBeforeSourceTraceId);same(omit(source,['source_trace_id','connected_source_port_ids','subcircuit_connectivity_map_key']),omit(oldSource,['source_trace_id','connected_source_port_ids','subcircuit_connectivity_map_key']),'Reference actual logical declaration')
  const expected=target.expectedTargetRoute;assert(geometrySame(routeShape(t.route),routeShape(expected))||geometrySame(routeShape(t.route),routeShape(expected).reverse()),'Exact moved reference copper')
  const oldMap=one(oldNativeProof.referenceMappings.filter(r=>r.actualPcbTraceId===target.actualBeforePcbTraceId),'Original Root checked reference owner mapping')
  const oldSp=old.by('source_port',oldMap.actualNumericSourcePortId),oldPart=old.by('source_component',oldSp.source_component_id),n=numeric(oldPart.name+'.pin'+oldSp.pin_number),v=viaByOrigin.get(oldMap.actualViaId);assert(v)
  const a=alias(actual,v,t.route[0].layer);endpoints(t,[n.pcb.pcb_port_id,a.pcb.pcb_port_id]);same([...source.connected_source_port_ids].sort(),[n.sp.source_port_id,a.source.source_port_id].sort(),'Reference numeric/via Source ownership');assert(source.connected_source_net_ids.includes(v.source_net_id))
  assert(!usedTraces.has(t.pcb_trace_id));usedTraces.add(t.pcb_trace_id);registry.get(v.pcb_via_id).add(t.source_trace_id)
  referenceMappings.push({originalPcbTraceId:target.actualBeforePcbTraceId,actualPcbTraceId:t.pcb_trace_id,actualSourceTraceId:t.source_trace_id,originalViaId:oldMap.actualViaId,actualViaId:v.pcb_via_id,actualNumericPcbPortId:n.pcb.pcb_port_id,actualAliasPcbPortId:a.pcb.pcb_port_id,actualNumericSourcePortId:n.sp.source_port_id})
 }
 const selected=new Map(proposal.selected32OriginalCarriers.map(c=>[c.originalSourceTraceId,c]))
 for(const owner of proposal.all98NumericOwnedSignalBranches){
  assert.equal(owner.topStub.length,owner.originalSourceTraceId==='source_trace_3'&&owner.side===0?4:owner.originalSourceTraceId==='source_trace_14'&&owner.side===1?11:owner.originalSourceTraceId==='source_trace_7'&&owner.side===1?13:2,'Only95 two-point stubs, CPU3four, RAM14eleven and RAM7thirteen');
  const n=numeric(owner.numericSelector);assert(at(n.pcb,owner.padXY));assert.equal(n.sp.pin_number,owner.numericPin)
  const ctl=one(controls.viaProjection.filter(r=>r.sourceViaName===owner.viaName),'Actual signal via projection');assert(ctl.passed&&!ctl.reference)
  const v=actual.by('pcb_via',ctl.actualViaId);assert(at(v,owner.viaXY));assert.equal(v.outer_diameter,.4572);assert.equal(v.hole_diameter,.254);same(v.layers,LAYERS);assert.equal(v.from_layer,'top');assert.equal(v.to_layer,'bottom');assert.equal(v.source_net_id,undefined);assert.equal(v.tented_on_top,true);assert.equal(v.tented_on_bottom,true)
  assert(!usedVias.has(v.pcb_via_id));usedVias.add(v.pcb_via_id)
  const definition=selected.get(owner.originalSourceTraceId),layer=['source_trace_20','source_trace_21'].includes(owner.originalSourceTraceId)?(owner.side===0?definition?.cpuCarrierLayer:definition?.ramCarrierLayer):definition?.carrierLayer,expected=['top','bottom',...(['inner1','inner2'].includes(layer)?[layer]:[])]
  same(v.pcb_port_ids.map(id=>one(actual.by('pcb_port',id).layers,'Single actual alias layer')).sort(),expected.slice().sort(),'Exact genuine via alias roster')
  const aliases=expected.map(l=>alias(actual,v,l));assert.equal(new Set(aliases.map(a=>a.owner.source_manually_placed_via_id)).size,1);assert.equal(aliases[0].owner.source_manually_placed_via_id,ctl.actualSourceViaOwner)
  const top=alias(actual,v,'top'),bottom=alias(actual,v,'bottom'),local=one(actual.rows('source_trace').filter(r=>r.name===owner.traceName),'Unique authored local branch');same(local.connected_source_port_ids,[n.sp.source_port_id,top.source.source_port_id],'True numeric-to-via Source branch');same(local.connected_source_net_ids,[]);assert.equal(local.min_trace_thickness,.1016)
  const physical=definition?owner.originalSourceTraceId:local.source_trace_id
  const t=one(actual.rows('pcb_trace').filter(r=>r.source_trace_id===physical&&(geometrySame(routeShape(r.route),owner.topStub)||geometrySame(routeShape(r.route),owner.topStub.slice().reverse()))),'One true source-owned Topstub')
  endpoints(t,[n.pcb.pcb_port_id,top.pcb.pcb_port_id]);assert.equal(actual.rows('pcb_trace').filter(r=>r.source_trace_id===local.source_trace_id).length,definition?0:1)
  const projection=one(controls.signalTopProjection.filter(r=>r.originalSourceTraceId===owner.originalSourceTraceId&&r.side===owner.side),'Actual Topstub projection');assert(projection.passed);assert.equal(projection.actualPcbTraceId,t.pcb_trace_id);assert.equal(projection.actualLocalSourceTraceId,local.source_trace_id)
  assert(!usedTraces.has(t.pcb_trace_id));usedTraces.add(t.pcb_trace_id);registry.set(v.pcb_via_id,new Set([physical]));viaByName.set(owner.viaName,v)
  if(v.pcb_trace_id!==undefined)assert.equal(v.pcb_trace_id,t.pcb_trace_id,'Signal via physical owner must be authentic Topstub')
  signalMappings.push({originalSourceTraceId:owner.originalSourceTraceId,side:owner.side,originalNumericSourcePortId:n.sp.source_port_id,sourceViaName:owner.viaName,actualViaId:v.pcb_via_id,actualLocalSourceTraceId:local.source_trace_id,actualPhysicalSourceTraceId:physical,actualPcbTraceId:t.pcb_trace_id,actualNumericPcbPortId:n.pcb.pcb_port_id,actualTopPcbPortId:top.pcb.pcb_port_id,actualBottomPcbPortId:bottom.pcb.pcb_port_id,actualTopSourcePortId:top.source.source_port_id,sourceViaOwnerId:top.owner.source_manually_placed_via_id})
 }
 const exactIntermediateIds=['source_trace_20','source_trace_21']
 same(proposal.source32Delta.exactIntermediateOriginalSourceTraceRoster,exactIntermediateIds,'Exact extra carrier roster')
 assert.equal(proposal.selected29OriginalCarriers.length,29);same(proposal.selected32OriginalCarriers.slice(0,29),proposal.selected29OriginalCarriers,'All29 strict prior carrier definitions held')
 assert.equal(proposal.intermediateCarrierVias.length,2)
 same(proposal.intermediateCarrierVias.map(v=>v.originalSourceTraceId),exactIntermediateIds,'Only20 and21 own new carrier barrels')
 const intermediateCarrierMappings=proposal.intermediateCarrierVias.map(d=>{
  assert.equal(d.role,'REMOVABLE_INTERMEDIATE_CARRIER_VIA_NOT_FIXED_FANOUT');assert.equal(d.futureFreshIds,null)
  const ctl=one(controls.viaProjection.filter(c=>c.sourceViaName===d.viaName),'One genuine new carrier-via declaration projection')
  assert(ctl.passed&&ctl.carrierOwned&&!ctl.reference);assert.equal(ctl.ownerOriginalSourceTraceId,d.originalSourceTraceId)
  const v=actual.by('pcb_via',ctl.actualViaId);assert(at(v,d.xy));same(v.layers,LAYERS);assert.equal(v.from_layer,'top');assert.equal(v.to_layer,'bottom');assert.equal(v.outer_diameter,.4572);assert.equal(v.hole_diameter,.254)
  assert.equal(v.source_net_id,undefined);assert.equal(v.source_trace_id,undefined);assert.equal(v.pcb_trace_id,undefined);assert.equal(v.tented_on_top,true);assert.equal(v.tented_on_bottom,true)
  assert(!usedVias.has(v.pcb_via_id));usedVias.add(v.pcb_via_id)
  const aliases=['top','bottom','inner2'].map(l=>alias(actual,v,l));same(v.pcb_port_ids.map(id=>one(actual.by('pcb_port',id).layers,'One actual carrier-via alias layer')).sort(),['bottom','inner2','top'])
  assert.equal(new Set(aliases.map(a=>a.owner.source_manually_placed_via_id)).size,1);assert.equal(new Set(aliases.map(a=>a.pcb.pcb_component_id)).size,1)
  assert.equal(aliases[0].owner.source_manually_placed_via_id,ctl.actualSourceViaOwner);assert.equal(aliases[0].owner.source_trace_id,undefined);assert.equal(aliases[0].owner.source_net_id,undefined)
  for(const a of aliases){const c=one(ctl.aliases.filter(c=>c.layer===a.source.name),'Actual new via alias projection');assert(c.authentic);assert.equal(c.actualPcbPortId,a.pcb.pcb_port_id);assert.equal(c.actualSourcePortId,a.source.source_port_id)}
  viaByName.set(d.viaName,v)
  return {originalSourceTraceId:d.originalSourceTraceId,sourceViaName:d.viaName,role:d.role,actualViaId:v.pcb_via_id,actualSourceViaOwner:aliases[0].owner.source_manually_placed_via_id,actualPlaceholderPcbComponentId:aliases[0].pcb.pcb_component_id,actualTopPcbPortId:aliases[0].pcb.pcb_port_id,actualBottomPcbPortId:aliases[1].pcb.pcb_port_id,actualInner2PcbPortId:aliases[2].pcb.pcb_port_id,actualSourcePortIds:aliases.map(a=>a.source.source_port_id),actualPcbPortIds:aliases.map(a=>a.pcb.pcb_port_id),physicalSpan:{from_layer:v.from_layer,to_layer:v.to_layer,layers:[...v.layers],outer_diameter:v.outer_diameter,hole_diameter:v.hole_diameter,x:v.x,y:v.y},fixedFanout:false,physicalGraphProved:false}
 })
 const carriers=proposal.selected32OriginalCarriers.map(d=>{
  if(exactIntermediateIds.includes(d.originalSourceTraceId)){
   const id=d.originalSourceTraceId;assert.equal(d.carrierArchitecture,'TWO_LAYER_ONE_OWNED_INTERMEDIATE_VIA');assert.equal(d.expectedPhysicalPathCount,4);assert.equal(d.carrierPieces.length,2);assert.equal(d.ownedIntermediateCarrierVias.length,1)
   const mapped=[d.cpu,d.ram].map(o=>one(signalMappings.filter(m=>m.originalSourceTraceId===id&&m.sourceViaName===o.viaName),'Actual extra carrier numeric endpoint'))
   const endpointVias=mapped.map(m=>actual.by('pcb_via',m.actualViaId)),middle=one(intermediateCarrierMappings.filter(m=>m.originalSourceTraceId===id),'One exact route-owned intermediate via'),v=actual.by('pcb_via',middle.actualViaId)
   const ports=[[alias(actual,endpointVias[0],'inner2'),alias(actual,v,'inner2')],[alias(actual,v,'top'),alias(actual,endpointVias[1],'top')]],paths=actual.rows('pcb_trace').filter(t=>t.source_trace_id===id);assert.equal(paths.length,4)
   const bodies=d.carrierPieces.map((piece,i)=>{
    assert.equal(piece.layer,i===0?'inner2':'top')
    const expected=piece.expectedPath.map(p=>({...p,route_type:'wire',layer:piece.layer,width:.1016}))
    const t=one(paths.filter(t=>geometrySame(routeShape(t.route),expected)),'One exact ordered actual extra carrier piece');assert(!usedTraces.has(t.pcb_trace_id));usedTraces.add(t.pcb_trace_id)
    assert.equal(t.source_trace_id,id);endpoints(t,ports[i].map(p=>p.pcb.pcb_port_id));assert.equal(t.route[0].start_pcb_port_id,ports[i][0].pcb.pcb_port_id);assert.equal(t.route.at(-1).end_pcb_port_id,ports[i][1].pcb.pcb_port_id)
    return {role:piece.role,layer:piece.layer,actualPcbTraceId:t.pcb_trace_id,actualStartPcbPortId:ports[i][0].pcb.pcb_port_id,actualEndPcbPortId:ports[i][1].pcb.pcb_port_id}
   })
   const wanted=[...mapped.map(m=>m.actualPcbTraceId),...bodies.map(b=>b.actualPcbTraceId)];same(paths.map(t=>t.pcb_trace_id).sort(),wanted.slice().sort(),'Exactly two original stubs plus two new Source-owned bodies');assert.equal(new Set(wanted).size,4)
   const planar=paths.reduce((s,t)=>s+t.route.slice(1).reduce((n,p,i)=>n+Math.hypot(p.x-t.route[i].x,p.y-t.route[i].y),0),0);assert(near(planar,d.expectedWholePlanarMm))
   const graph=new Map(),edges=[];const join=(a,b,basis)=>{for(const x of[a,b])if(!graph.has(x))graph.set(x,new Set());graph.get(a).add(b);graph.get(b).add(a);edges.push({fromActualId:a,toActualId:b,...basis})}
   for(const t of paths){assert(t.route.every(p=>p.route_type==='wire'&&p.width===.1016));const first=t.route[0],last=t.route.at(-1);for(const[p,pid]of[[first,first.start_pcb_port_id],[last,last.end_pcb_port_id]]){assert(pid);const port=actual.by('pcb_port',pid);assert(at(p,port)&&port.layers.includes(p.layer))}join(first.start_pcb_port_id,last.end_pcb_port_id,{basis:'ACTUAL_FRESH_SOURCE_OWNED_WIRE_PATH',actualPcbTraceId:t.pcb_trace_id,actualSourceTraceId:id})}
   for(const barrel of[endpointVias[0],v,endpointVias[1]])for(const pid of barrel.pcb_port_ids){const p=actual.by('pcb_port',pid);assert(at(p,barrel)&&p.layers.every(l=>barrel.layers.includes(l)));join(pid,barrel.pcb_via_id,{basis:'ACTUAL_FULLSPAN_BARREL_OWNED_ALIAS',actualSourceViaOwner:actual.by('source_port',p.source_port_id).source_component_id})}
   const begin=mapped[0].actualNumericPcbPortId,end=mapped[1].actualNumericPcbPortId,queue=[begin],prev=new Map([[begin,null]]);for(let i=0;i<queue.length;i++)for(const n of graph.get(queue[i])||[])if(!prev.has(n)){prev.set(n,queue[i]);queue.push(n)}assert(prev.has(end),'Genuine full four-path numeric CPU-to-RAM graph')
   const path=[];for(let n=end;n!==null;n=prev.get(n))path.unshift(n);assert(path.includes(v.pcb_via_id)&&path.includes(endpointVias[0].pcb_via_id),'The actual active path traverses both required layer-changing barrels')
   const ctl=one(controls.carriers.filter(c=>c.originalSourceTraceId===id),'Collected exact multi-piece Core graph');assert(ctl.passed&&ctl.actualSourceOwnedPhysicalGraph.physicallyConnected);same(ctl.actualDirectPcbTraceIds,paths.map(t=>t.pcb_trace_id),'Actual four-path roster');same(ctl.actualCarrierPcbTraceIds,bodies.map(b=>b.actualPcbTraceId),'Actual two body IDs');same(ctl.actualRemovableCarrierViaIds,[v.pcb_via_id],'Actual removable via ID');assert.equal(ctl.actualCpuCarrierLayerPcbPortId,ports[0][0].pcb.pcb_port_id);assert.equal(ctl.actualRamCarrierLayerPcbPortId,ports[1][1].pcb.pcb_port_id)
   // Register only after the exact material, owners, endpoints and complete physical graph prove this source ownership.
   assert(!registry.has(v.pcb_via_id));registry.set(v.pcb_via_id,new Set([id]));middle.physicalGraphProved=true
   return {originalSourceTraceId:id,carrierArchitecture:d.carrierArchitecture,carrierLayer:null,cpuCarrierLayer:'inner2',ramCarrierLayer:'top',actualDirectPcbTraceIds:paths.map(t=>t.pcb_trace_id),actualCarrierPcbTraceId:null,actualCarrierPcbTraceIds:bodies.map(b=>b.actualPcbTraceId),carrierPieces:bodies,actualRemovableCarrierViaIds:[v.pcb_via_id],actualCpuNumericPcbPortId:begin,actualRamNumericPcbPortId:end,actualCpuViaId:endpointVias[0].pcb_via_id,actualRamViaId:endpointVias[1].pcb_via_id,actualCpuCarrierLayerPcbPortId:ports[0][0].pcb.pcb_port_id,actualRamCarrierLayerPcbPortId:ports[1][1].pcb.pcb_port_id,wholePlanarLengthMm:planar,physicalFullThroughBarrels:3,actualActiveLayerTransitions:[{x:endpointVias[0].x,y:endpointVias[0].y,fromLayer:'top',toLayer:'inner2'},{x:v.x,y:v.y,fromLayer:'inner2',toLayer:'top'}],legacyViaMarkerLengthContributionMm:0,actualSourceOwnedPhysicalGraph:{actualEdges:edges,actualNumericCpuToRamIdPath:path,physicallyConnected:true,logicalMapAloneNotUsed:true},intermediateViaIsNotFixedFanout:true,electricalDelayQualified:false}
  }
  const id=d.originalSourceTraceId,layer=d.carrierLayer;assert(LAYERS.includes(layer));const mapped=[d.cpu,d.ram].map(o=>one(signalMappings.filter(m=>m.originalSourceTraceId===id&&m.sourceViaName===o.viaName),'Actual selected endpoint'))
  const vias=mapped.map(m=>actual.by('pcb_via',m.actualViaId)),ports=vias.map(v=>alias(actual,v,layer)),paths=actual.rows('pcb_trace').filter(t=>t.source_trace_id===id);assert.equal(paths.length,3)
  const body=one(paths.filter(t=>!mapped.some(m=>m.actualPcbTraceId===t.pcb_trace_id)),'One actual main carrier');assert(!usedTraces.has(body.pcb_trace_id));assert.equal(body.route.length,d.expectedCarrierPath.length)
  body.route.forEach((p,i)=>assert(p.route_type==='wire'&&p.layer===layer&&p.width===.1016&&at(p,d.expectedCarrierPath[i]),'Pinned Source29 carrier geometry'))
  endpoints(body,ports.map(p=>p.pcb.pcb_port_id));assert(at(body.route[0],vias[0])&&at(body.route.at(-1),vias[1]));assert(paths.every(t=>t.route.every(p=>p.route_type==='wire')));usedTraces.add(body.pcb_trace_id)
  const planar=paths.reduce((s,t)=>s+t.route.slice(1).reduce((n,p,i)=>n+Math.hypot(p.x-t.route[i].x,p.y-t.route[i].y),0),0);assert(near(planar,d.expectedWholePlanarMm))
  const graph=new Map(),edges=[];const join=(a,b,basis)=>{for(const x of[a,b])if(!graph.has(x))graph.set(x,new Set());graph.get(a).add(b);graph.get(b).add(a);edges.push({fromActualId:a,toActualId:b,...basis})}
  for(const t of paths){const first=t.route[0],last=t.route.at(-1);assert(first.start_pcb_port_id&&last.end_pcb_port_id);for(const [p,pid]of [[first,first.start_pcb_port_id],[last,last.end_pcb_port_id]]){const port=actual.by('pcb_port',pid);assert(at(p,port)&&port.layers.includes(p.layer))}join(first.start_pcb_port_id,last.end_pcb_port_id,{basis:'ACTUAL_FRESH_SOURCE_OWNED_WIRE_PATH',actualPcbTraceId:t.pcb_trace_id,actualSourceTraceId:t.source_trace_id})}
  for(const v of vias)for(const pid of v.pcb_port_ids){const p=actual.by('pcb_port',pid);assert(at(p,v)&&p.layers.every(l=>v.layers.includes(l)));join(pid,v.pcb_via_id,{basis:'ACTUAL_FULLSPAN_BARREL_OWNED_ALIAS',actualSourceViaOwner:actual.by('source_port',p.source_port_id).source_component_id})}
  const begin=mapped[0].actualNumericPcbPortId,end=mapped[1].actualNumericPcbPortId,queue=[begin],prev=new Map([[begin,null]]);for(let i=0;i<queue.length;i++)for(const next of graph.get(queue[i])||[])if(!prev.has(next)){prev.set(next,queue[i]);queue.push(next)}assert(prev.has(end),'Genuine physical numeric CPU-to-RAM graph')
  const path=[];for(let current=end;current!==null;current=prev.get(current))path.unshift(current)
  const ctl=one(controls.carriers.filter(c=>c.originalSourceTraceId===id),'Collected carrier proof');assert(ctl.passed);assert.equal(ctl.actualCarrierPcbTraceId,body.pcb_trace_id);same(ctl.actualDirectPcbTraceIds,paths.map(t=>t.pcb_trace_id),'Actual carrier roster')
  return {originalSourceTraceId:id,carrierLayer:layer,actualDirectPcbTraceIds:paths.map(t=>t.pcb_trace_id),actualCarrierPcbTraceId:body.pcb_trace_id,actualCpuNumericPcbPortId:begin,actualRamNumericPcbPortId:end,actualCpuViaId:vias[0].pcb_via_id,actualRamViaId:vias[1].pcb_via_id,actualCpuCarrierLayerPcbPortId:ports[0].pcb.pcb_port_id,actualRamCarrierLayerPcbPortId:ports[1].pcb.pcb_port_id,wholePlanarLengthMm:planar,physicalFullThroughBarrels:2,actualActiveLayerTransitions:layer==='top'?[]:[{x:vias[0].x,y:vias[0].y,fromLayer:'top',toLayer:layer},{x:vias[1].x,y:vias[1].y,fromLayer:layer,toLayer:'top'}],legacyViaMarkerLengthContributionMm:0,actualSourceOwnedPhysicalGraph:{actualEdges:edges,actualNumericCpuToRamIdPath:path,physicallyConnected:true,logicalMapAloneNotUsed:true},electricalDelayQualified:false}
 })
 for(let n=0;n<49;n++)assert.equal(actual.rows('pcb_trace').filter(t=>t.source_trace_id==='source_trace_'+n).length,exactIntermediateIds.includes('source_trace_'+n)?4:selected.has('source_trace_'+n)?3:0,'Exactly29 held plus Source45 strict three-path and two declared four-path carriers;17 unfinished')
 assert.equal(usedVias.size,229);assert.equal(usedTraces.size,297);assert.equal(registry.size,229);assert(intermediateCarrierMappings.every(m=>m.physicalGraphProved));same([...registry.keys()].sort(),actual.rows('pcb_via').map(v=>v.pcb_via_id).sort(),'Every actual barrel privately accounted exactly once')
 // Retain ONLY the authentic old RAM25/HS8 physical-contact exception; re-prove
 // its new geometry, explicit numeric owner, and real known-rail graph.
 const contact=oldNativeProof.registeredRam25Hs8Junction;assert(contact.onlyOriginalRam25Owner&&contact.stripDrillClear&&contact.padDrillClear)
 const newVia=viaByOrigin.get(contact.actualViaId),oldOwnedVia=viaByOrigin.get(contact.actualOldHsViaId),strip=one(referenceMappings.filter(m=>m.originalPcbTraceId===contact.actualOldStripPcbTraceId),'Authentic HS8 strip mapped'),t=actual.by('pcb_trace',strip.actualPcbTraceId),n=numeric('C_DDR_RAM_8.pin2'),pad=n.pad
 assert(newVia&&oldOwnedVia);assert.equal(newVia.source_net_id,'source_net_0');assert.equal(t.source_trace_id,'source_trace_987');assert.equal(n.pad.layer,'bottom');assert.equal(t.route.length,2)
 const[a,b]=t.route;assert(a.layer==='bottom'&&b.layer==='bottom'&&a.width===.2&&b.width===.2&&!a.width_interpolation_mode&&!b.width_interpolation_mode)
 const dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy),along=((newVia.x-a.x)*dx+(newVia.y-a.y)*dy)/len,distance=Math.abs(dx*(newVia.y-a.y)-dy*(newVia.x-a.x))/len,R=newVia.outer_diameter/2,h=newVia.hole_diameter/2,nearest=Math.max(0,distance-a.width/2),halfChord=Math.sqrt(R*R-nearest*nearest)
 assert(Number.isFinite(halfChord)&&2*halfChord>=.1016&&along-halfChord>1e-8&&along+halfChord<len-1e-8&&distance-a.width/2>h);assert.equal(pad.shape,'rect');assert.equal(pad.ccw_rotation??0,0)
 const closestX=Math.max(pad.x-pad.width/2,Math.min(newVia.x,pad.x+pad.width/2)),closestY=Math.max(pad.y-pad.height/2,Math.min(newVia.y,pad.y+pad.height/2)),padDistance=Math.hypot(newVia.x-closestX,newVia.y-closestY);assert(padDistance<R&&padDistance>h&&R-h>=.1016-Number.EPSILON)
 const connectivity=getFullConnectivityMapFromCircuitJson(freshCore)
 for(const pair of [[t.pcb_trace_id,newVia.pcb_via_id],[t.source_trace_id,newVia.pcb_via_id],[oldOwnedVia.pcb_via_id,newVia.pcb_via_id],[pad.pcb_smtpad_id,newVia.pcb_via_id],[n.pcb.pcb_port_id,newVia.pcb_via_id],[n.sp.source_port_id,newVia.pcb_via_id]])assert(connectivity.areIdsConnected(...pair),'Authentic known-rail RAM25/HS8 contact')
 registry.get(newVia.pcb_via_id).add(t.source_trace_id);padRegistry.set(newVia.pcb_via_id,new Set([pad.pcb_smtpad_id]))
 for(const m of referenceMappings){const t=actual.by('pcb_trace',m.actualPcbTraceId),v=actual.by('pcb_via',m.actualViaId);for(const pair of [[m.actualNumericPcbPortId,t.pcb_trace_id],[m.actualAliasPcbPortId,t.pcb_trace_id],[m.actualNumericPcbPortId,v.pcb_via_id],[t.source_trace_id,v.pcb_via_id],[v.source_net_id,v.pcb_via_id]])assert(connectivity.areIdsConnected(...pair),'Actual reference numeric graph')}
 assert.equal(JSON.stringify(freshCore),before,'No circuit JSON edit during ownership proof')
 const proof=freeze({scope:'ACTUAL_FRESH_CORE_229_297_NUMERIC32_EXPLICIT_INTERMEDIATE_CARRIER_OWNERSHIP',referenceMappings,signalMappings,intermediateCarrierMappings,carriers,clocks:carriers.filter(c=>['source_trace_33','source_trace_34'].includes(c.originalSourceTraceId)),registeredRam25Hs8Junction:{actualViaId:newVia.pcb_via_id,actualOldStripPcbTraceId:t.pcb_trace_id,actualOldStripSourceTraceId:t.source_trace_id,actualHs8PadId:pad.pcb_smtpad_id,actualHs8NumericPcbPortId:n.pcb.pcb_port_id,actualOldHsViaId:oldOwnedVia.pcb_via_id,actualContactChordMm:2*halfChord,actualPadClosestDistanceMm:padDistance,actualLandRadiusMm:R,actualDrillRadiusMm:h,onlyOriginalRam25Owner:true,stripDrillClear:true,padDrillClear:true},rawCircuitUnmodified:true,referenceQualified:false,accepted49:false,fabricationReady:false})
 states.set(proof,{circuit:freshCore,signature:before,registry,padRegistry});return proof
}
export function getFreshViaBranchRegistry(proof,circuit){const s=states.get(proof);assert(s&&s.circuit===circuit,'Only exact privately proved actual Core object');assert.equal(JSON.stringify(circuit),s.signature);return new Map([...s.registry].map(([id,owners])=>[id,new Set(owners)]))}
export function getFreshIntentionalPadContactRegistry(proof,circuit){const s=states.get(proof);assert(s&&s.circuit===circuit,'Only exact privately proved actual Core object');assert.equal(JSON.stringify(circuit),s.signature);return new Map([...s.padRegistry].map(([id,pads])=>[id,new Set(pads)]))}
