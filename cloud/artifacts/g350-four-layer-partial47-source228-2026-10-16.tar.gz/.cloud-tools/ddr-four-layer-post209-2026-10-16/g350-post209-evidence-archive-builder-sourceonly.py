#!/usr/bin/env python3
"""Stream a pinned, immutable partial-routing evidence archive; no SDK execution.

There is deliberately no default build action. The caller must pass --build and
the hashes of the final saved index, restore manifest, and progress document.
Only the separate post209 evidence directory is an eligible archive input;
the immutable Source209 archive is a required prior dependency and is excluded.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile
import tempfile

SAVED_REL = '.cloud-tools/ddr-four-layer-post209-2026-10-16'
BASE_ARCHIVE_SHA = 'c4cfe7d590a67368586ef49a6178dbc6b6519576a654a690d8f5ef91be0b9178'
CHUNK = 1024 * 1024


def drop_cache(fd, offset=0, length=0):
    os.posix_fadvise(fd, offset, length, os.POSIX_FADV_DONTNEED)


def digest_file(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        offset = 0
        while chunk := f.read(CHUNK):
            h.update(chunk)
            drop_cache(f.fileno(), offset, len(chunk))
            offset += len(chunk)
        drop_cache(f.fileno())
    return h.hexdigest()


def read_json(path):
    with path.open('rb') as f:
        value = json.load(f)
        drop_cache(f.fileno())
    return value


def safe_relative(value):
    p = PurePosixPath(value)
    assert not p.is_absolute() and p.parts and all(x not in ('', '.', '..') for x in p.parts)
    assert str(p) == value and '\\' not in value, 'Noncanonical archive path'
    return p


def collect(root, relative):
    base = root / relative
    assert base.is_dir() and not base.is_symlink()
    result = []
    for current, directories, files in os.walk(base, followlinks=False):
        for name in directories:
            p = Path(current) / name
            assert not p.is_symlink() and stat.S_ISDIR(p.lstat().st_mode), str(p)
        for name in files:
            p = Path(current) / name
            s = p.lstat()
            assert stat.S_ISREG(s.st_mode) and not p.is_symlink(), str(p)
            rel = p.relative_to(root).as_posix()
            safe_relative(rel)
            mode = stat.S_IMODE(s.st_mode)
            assert 0 <= mode <= 0o777, 'Special permission bits are unsupported'
            result.append({'path': rel, 'bytes': s.st_size, 'mode': mode,
                           '_source': p, '_identity': (s.st_dev, s.st_ino, s.st_size,
                                                      s.st_mtime_ns, s.st_ctime_ns, s.st_mode)})
    return sorted(result, key=lambda x: x['path'])


class DigestReader:
    def __init__(self, stream):
        self.stream, self.hash, self.count = stream, hashlib.sha256(), 0

    def read(self, size=-1):
        assert 0 <= size <= CHUNK, 'Archive reader requested unbounded payload'
        chunk = self.stream.read(size)
        self.hash.update(chunk)
        drop_cache(self.stream.fileno(), self.count, len(chunk))
        self.count += len(chunk)
        return chunk


class DigestWriter:
    def __init__(self, stream):
        self.stream, self.hash, self.count = stream, hashlib.sha256(), 0

    def write(self, chunk):
        written = self.stream.write(chunk)
        assert written == len(chunk)
        self.hash.update(chunk)
        self.count += written
        return written

    def flush(self):
        self.stream.flush()


def publish_new(temporary, destination):
    # link is an atomic no-replace publication, unlike os.replace.
    os.link(temporary, destination)
    temporary.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--board-root', type=Path, default=Path('/workspace/g350-linux-handheld'))
    parser.add_argument('--archive-relative', required=True)
    parser.add_argument('--manifest-relative', required=True)
    parser.add_argument('--index-sha256', required=True)
    parser.add_argument('--restore-manifest-sha256', required=True)
    parser.add_argument('--progress-sha256', required=True)
    parser.add_argument('--primary-sha256', required=True)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    assert args.build, 'No archive created: explicit --build is required'
    assert hasattr(os, 'posix_fadvise') and hasattr(os, 'POSIX_FADV_DONTNEED')
    root = args.board_root.resolve()
    for value in (args.archive_relative, args.manifest_relative):
        p = safe_relative(value)
        assert p.parts[:2] == ('cloud', 'artifacts'), 'Outputs must be in cloud/artifacts'
    archive_path, manifest_path = root / args.archive_relative, root / args.manifest_relative
    assert archive_path.suffixes[-2:] == ['.tar', '.gz']
    assert manifest_path.name.endswith('.manifest.json')
    assert not archive_path.exists() and not manifest_path.exists(), 'Immutable output already exists'
    assert archive_path.parent.resolve().is_relative_to(root)
    assert manifest_path.parent.resolve().is_relative_to(root)
    saved = root / SAVED_REL
    pins = {saved / 'WORKSPACE_HASH_INDEX.json': args.index_sha256,
            saved / 'WORKSPACE_RESTORE_MANIFEST.json': args.restore_manifest_sha256,
            saved / 'PROGRESS.json': args.progress_sha256}
    for path, expected in pins.items():
        assert len(expected) == 64 and digest_file(path) == expected, 'Final metadata pin mismatch'
    index = read_json(saved / 'WORKSPACE_HASH_INDEX.json')
    restore = read_json(saved / 'WORKSPACE_RESTORE_MANIFEST.json')
    progress = read_json(saved / 'PROGRESS.json')
    base_dependency = progress['baseArchiveDependency']
    assert base_dependency == restore['baseArchiveDependency'], 'Base dependency metadata differs'
    assert base_dependency['sha256'] == BASE_ARCHIVE_SHA and base_dependency['bytes'] == 31488547
    assert base_dependency['mustBeRestoredFirst'] is True
    base_archive_relative = str(safe_relative(base_dependency['path']))
    base_archive = root / base_archive_relative
    assert base_archive_relative == 'cloud/artifacts/g350-four-layer-partial46-source209-2026-10-16.tar.gz'
    assert base_archive.is_file() and not base_archive.is_symlink()
    assert base_archive.stat().st_size == base_dependency['bytes'] and digest_file(base_archive) == BASE_ARCHIVE_SHA
    assert digest_file(root / base_dependency['manifest']) == base_dependency['manifestSha256']
    assert progress['primaryCandidate']['sha256'] == args.primary_sha256
    primary = saved / progress['primaryCandidate']['savedPath']
    assert primary.resolve().is_relative_to(saved.resolve())
    assert digest_file(primary) == args.primary_sha256, 'Primary candidate mismatch'
    assert progress.get('all49Accepted', False) is False
    assert progress.get('fabricationReady', False) is False
    rows = collect(root, SAVED_REL)
    rows.sort(key=lambda x: x['path'])
    assert len(rows) == len({r['path'] for r in rows})
    indexed = {SAVED_REL + '/' + v['path']: v for v in index['files']}
    assert len(indexed) == len(index['files'])
    actual_saved = {r['path'] for r in rows if r['path'].startswith(SAVED_REL + '/')}
    assert actual_saved == set(indexed) | {SAVED_REL + '/WORKSPACE_HASH_INDEX.json'}, 'Saved file index is incomplete'
    restore_paths = set()
    for row in restore['files']:
        assert row['restorePath'] not in restore_paths
        restore_paths.add(row['restorePath'])
        v = indexed[SAVED_REL + '/' + row['savedPath']]
        assert v['sha256'] == row['sha256'] and v['bytes'] == row['bytes']
        if 'mode' in row:
            assert v['mode'] == row['mode']
    for r in rows:
        if r['path'] in indexed:
            v = indexed[r['path']]
            assert r['bytes'] == v['bytes'] and r['mode'] == v['mode']
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    archive_temp = manifest_temp = None
    try:
        fd, temporary = tempfile.mkstemp(prefix='.' + archive_path.name + '.', suffix='.partial', dir=archive_path.parent)
        archive_temp = Path(temporary)
        with os.fdopen(fd, 'wb') as output:
            os.fchmod(output.fileno(), 0o600)
            writer = DigestWriter(output)
            with gzip.GzipFile(filename='', mode='wb', fileobj=writer, compresslevel=6, mtime=0) as compressed:
                with tarfile.open(mode='w|', fileobj=compressed, format=tarfile.PAX_FORMAT) as archive:
                    for row in rows:
                        source = row['_source']
                        before = source.lstat()
                        identity = (before.st_dev, before.st_ino, before.st_size,
                                    before.st_mtime_ns, before.st_ctime_ns, before.st_mode)
                        assert identity == row['_identity'], 'Evidence changed before streaming'
                        info = tarfile.TarInfo(row['path'])
                        info.size, info.mode, info.mtime = row['bytes'], row['mode'], 0
                        info.uid = info.gid = 0
                        info.uname = info.gname = ''
                        with source.open('rb') as f:
                            reader = DigestReader(f)
                            archive.addfile(info, reader)
                            drop_cache(f.fileno())
                        assert reader.count == row['bytes']
                        row['sha256'] = reader.hash.hexdigest()
                        if row['path'] in indexed:
                            assert row['sha256'] == indexed[row['path']]['sha256'], 'Saved payload hash mismatch'
                        elif source in pins:
                            assert row['sha256'] == pins[source]
                        after = source.lstat()
                        assert (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns,
                                after.st_ctime_ns, after.st_mode) == identity, 'Evidence changed while streaming'
            output.flush()
            os.fsync(output.fileno())
            drop_cache(output.fileno())
        # Reject new/deleted inputs or changed final metadata before publication.
        current = collect(root, SAVED_REL)
        assert {r['path']: r['_identity'] for r in current} == {r['path']: r['_identity'] for r in rows}
        for path, expected in pins.items():
            assert digest_file(path) == expected
        files = [{k: v for k, v in row.items() if not k.startswith('_')} for row in rows]
        manifest = {'schemaVersion': 1, 'scope': 'PORTABLE_POST209_PARTIAL_FOUR_LAYER_SOURCE_AND_DATA',
                    'regularFilesOnly': True, 'historicalDataOnly': True,
                    'archive': {'path': args.archive_relative, 'bytes': writer.count,
                                'sha256': writer.hash.hexdigest()},
                    'files': files, 'inputDirectories': [SAVED_REL],
                    'baseArchiveDependency': base_dependency, 'baseArchiveIncluded': False,
                    'snapshotPins': {str(p.relative_to(root)): h for p, h in pins.items()},
                    'primaryCandidate': {'path': primary.relative_to(root).as_posix(), 'sha256': args.primary_sha256},
                    'workspaceRestoreTargetCount': len(restore_paths),
                    'latestCollectedScope': progress.get('latestClosedScopeIncluded'),
                    'partialMilestoneMetadata': progress['primaryCandidate'],
                    'tarMetadata': {'uid': 0, 'gid': 0, 'uname': '', 'gname': '', 'mtime': 0},
                    'gzipMtime': 0, 'all49Accepted': False, 'electricalTimingQualified': False,
                    'referenceQualified': False, 'cadQualified': False, 'fabricationReady': False}
        fd, temporary = tempfile.mkstemp(prefix='.' + manifest_path.name + '.', suffix='.partial', dir=manifest_path.parent)
        manifest_temp = Path(temporary)
        with os.fdopen(fd, 'w') as f:
            os.fchmod(f.fileno(), 0o600)
            json.dump(manifest, f, indent=2, allow_nan=False)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        publish_new(archive_temp, archive_path)
        archive_temp = None
        publish_new(manifest_temp, manifest_path)
        manifest_temp = None
        print(json.dumps({'archive': args.archive_relative, 'manifest': args.manifest_relative,
                          'members': len(files), 'restoreTargets': len(restore_paths),
                          'archiveBytes': writer.count, 'archiveSha256': writer.hash.hexdigest(),
                          'sdkExecuted': False, 'all49Accepted': False, 'fabricationReady': False}))
    finally:
        for temporary in (archive_temp, manifest_temp):
            if temporary is not None and temporary.exists():
                temporary.unlink()


if __name__ == '__main__':
    main()
