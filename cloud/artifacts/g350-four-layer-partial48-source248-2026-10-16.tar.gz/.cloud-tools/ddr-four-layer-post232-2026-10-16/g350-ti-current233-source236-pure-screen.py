#!/usr/bin/env python3
"""Bounded public-JSON geometry review; no PCB/solver/checker SDK imports."""
import collections, hashlib, json, math, pathlib, time
START=time.monotonic(); LIMIT=50; MAX_PAIRS=3000000
CP=pathlib.Path('/tmp/g350-ca-merge47-root-20261016-run233/byte0-result.candidate.json')
RP=pathlib.Path('/tmp/g350-ca-merged47-core236-raw.json')
OUT=pathlib.Path('/tmp/g350-ti-current233-source236-pure-screen.json')
assert not OUT.exists()
def read(p,sha):
 b=p.read_bytes(); assert hashlib.sha256(b).hexdigest()==sha; return json.loads(b)
c=read(CP,'71bbec7babdeabda657ba1b2be75d35f5d7210d5a53d55cd2fc2b279ffb0d17b')
r=read(RP,'d49c3d6f8661527cf007d3676d6cdae7f9fcec99535373997c6adda8705dc18d')
names={x['source_trace_id']:x['name'] for x in r if x['type']=='source_trace' and int(x['source_trace_id'].split('_')[-1])<49}
classes={}
for k,v in {'DQ0':[14,30,3,31,42,4,17,32,43],'DQS0':[15,16],'DQ1':[29,41,26,40,12,2,11,13,1],'DQS1':[27,28],'CK':[33,34],'RESET':[10]}.items():
 for n in v:classes[f'source_trace_{n}']=k
for n in range(49):classes.setdefault(f'source_trace_{n}','ADDR_CTRL')
pairs={frozenset((f'source_trace_{a}',f'source_trace_{b}')) for a,b in [(15,16),(27,28),(33,34)]}
z={'top':0.0,'inner1':0.1245,'inner2':1.4047,'bottom':1.5292}
segments=[]; rows=[]; layer_owners=collections.defaultdict(set)
for t in c['joinedNumericPadTraces']:
 owner=t['source_trace_id']; lengths=collections.Counter(); vertical=0.; vs=[]
 for p in t['route']:
  if p['route_type']=='via':
   d=abs(z[p['from_layer']]-z[p['to_layer']]);vertical+=d;vs.append({'from':p['from_layer'],'to':p['to_layer'],'travelMm':d})
 for a,b in zip(t['route'],t['route'][1:]):
  if a['route_type']!='wire' or b['route_type']!='wire' or a['layer']!=b['layer']:continue
  dx=b['x']-a['x'];dy=b['y']-a['y'];length=math.hypot(dx,dy)
  if length<1e-10:continue
  layer=a['layer'];lengths[layer]+=length;layer_owners[layer].add(owner)
  segments.append({'owner':owner,'layer':layer,'a':(a['x'],a['y']),'b':(b['x'],b['y']),'width':max(a['width'],b['width']),'length':length,'bbox':(min(a['x'],b['x']),min(a['y'],b['y']),max(a['x'],b['x']),max(a['y'],b['y']))})
 rows.append({'owner':owner,'name':names[owner],'spacingClass':classes[owner],'planarByLayerMm':dict(lengths),'planarMm':sum(lengths.values()),'activeVerticalMm':vertical,'planarPlusActiveVerticalMm':sum(lengths.values())+vertical,'transitions':vs})
ledger={v['owner']:v for v in rows}
for o in c['originalBusConstraintObservations']:
 for t in o['present']:assert abs(t['wholePlanarLengthMm']-ledger[t['owner']]['planarMm'])<1e-8
# Exact interval on query segment inside a finite target segment's radius capsule.
def clipped(lo,hi):
 lo=max(0.,lo);hi=min(1.,hi);return (lo,hi) if hi>lo+1e-12 else None
def quadratic(aa,bb,cc):
 if aa<1e-24:return [(0.,1.)] if cc<0 else []
 disc=bb*bb-4*aa*cc
 if disc<=0:return []
 root=math.sqrt(disc);v=clipped((-bb-root)/(2*aa),(-bb+root)/(2*aa));return [v] if v else []
def linear_bounds(p,q,lo,hi):
 if abs(q)<1e-15:return (0.,1.) if lo<=p<=hi else None
 a,b=(lo-p)/q,(hi-p)/q;return clipped(min(a,b),max(a,b))
def capsule(q,t,rad):
 a,b=q['a'],q['b'];u=(b[0]-a[0],b[1]-a[1]);v=(t['b'][0]-t['a'][0],t['b'][1]-t['a'][1]);w=(a[0]-t['a'][0],a[1]-t['a'][1]);vv=v[0]**2+v[1]**2
 intervals=[]
 for p in [t['a'],t['b']]:
  d=(a[0]-p[0],a[1]-p[1]);intervals+=quadratic(u[0]**2+u[1]**2,2*(d[0]*u[0]+d[1]*u[1]),d[0]**2+d[1]**2-rad**2)
 if vv>1e-24:
  # Line-distance strip plus perpendicular projection between target ends.
  cross=w[0]*v[1]-w[1]*v[0];crossu=u[0]*v[1]-u[1]*v[0]
  strip=linear_bounds(cross,crossu,-rad*math.sqrt(vv),rad*math.sqrt(vv))
  proj=linear_bounds(w[0]*v[0]+w[1]*v[1],u[0]*v[0]+u[1]*v[1],0.,vv)
  if strip and proj:
   iv=clipped(max(strip[0],proj[0]),min(strip[1],proj[1]));intervals += [iv] if iv else []
 return intervals
def union(vals):
 vals=sorted(vals);total=0;end=-1
 for a,b in vals:
  if a>end:total+=b-a;end=b
  elif b>end:total+=b-end;end=b
 return total
# A segment is inserted in every intersecting bbox grid cell. Queries expand by largest rule radius.
cell=.5;bins=collections.defaultdict(list)
def binrange(s,margin):
 x,y,X,Y=s['bbox'];return ((i,j) for i in range(math.floor((x-margin)/cell),math.floor((X+margin)/cell)+1) for j in range(math.floor((y-margin)/cell),math.floor((Y+margin)/cell)+1))
for i,s in enumerate(segments):
 for x,y in binrange(s,0):bins[(s['layer'],x,y)].append(i)
exposure=collections.defaultdict(list); encounters=collections.Counter(); examples=[];comparisons=0;complete=True
for i,s in enumerate(segments):
 if time.monotonic()-START>LIMIT:complete=False;break
 neighbors=set()
 for x,y in binrange(s,.4064+1e-9):neighbors.update(bins.get((s['layer'],x,y),[]))
 for j in neighbors:
  if j<=i:continue
  t=segments[j]
  if s['owner']==t['owner'] or frozenset((s['owner'],t['owner'])) in pairs:continue
  comparisons+=1
  if comparisons>MAX_PAIRS:complete=False;break
  aclass,bclass=classes[s['owner']],classes[t['owner']]
  multiple=3 if aclass==bclass and aclass in {'DQ0','DQ1','ADDR_CTRL'} else 4
  radius=multiple*max(s['width'],t['width'])
  sb,tb=s['bbox'],t['bbox']
  if sb[0]>tb[2]+radius or tb[0]>sb[2]+radius or sb[1]>tb[3]+radius or tb[1]>sb[3]+radius:continue
  si=capsule(s,t,radius)
  if not si:continue
  ti=capsule(t,s,radius)
  exposure[i]+=si;exposure[j]+=ti
  key=f'{min(aclass,bclass)}__{max(aclass,bclass)}__{multiple}W';encounters[key]+=1
  if len(examples)<30:
   iv=si[0];tt=(iv[0]+iv[1])/2;pos=[s['a'][a]+tt*(s['b'][a]-s['a'][a]) for a in (0,1)]
   examples.append({'ownerA':s['owner'],'ownerB':t['owner'],'classA':aclass,'classB':bclass,'layer':s['layer'],'normalCenterMinimumMm':radius,'pointOnAInsideReducedSpacingInterval':pos,'segmentA':i,'segmentB':j})
 if not complete:break
perowner=collections.Counter()
for i,ivs in exposure.items():perowner[segments[i]['owner']]+=union(ivs)*segments[i]['length']
# Pours are recorded by real material polygons; outer copper has no reference pours.
pours=[x for x in r if x['type']=='pcb_copper_pour']
pour_summary=collections.Counter((p['layer'],p['source_net_id']) for p in pours)
buses=[]
for b in c['originalBusConstraintObservations']:
 ids=[x['owner'] for x in b['present']];p=[ledger[i]['planarMm'] for i in ids];g=[ledger[i]['planarPlusActiveVerticalMm'] for i in ids]
 buses.append({'busId':b['originalRule']['busId'],'presentCount':len(ids),'missingOwners':b['missingOwners'],'planarSpreadMm':max(p)-min(p) if len(p)>1 else None,'candidateGeometric3DSpreadMm':max(g)-min(g) if len(g)>1 else None,'planarConstraintsPassed':b['observedPlanarConstraintsPassed'],'geometric3DIsElectricalDelay':False})
report={'scope':'BOUNDED_PURE_PUBLIC_JSON_CONNECTED47_TI_LAYER_LENGTH_AND_DDR_WIRE_SPACING_SCREEN','inputs':[{'path':str(CP),'sha256':hashlib.sha256(CP.read_bytes()).hexdigest()},{'path':str(RP),'sha256':hashlib.sha256(RP.read_bytes()).hexdigest()}],'sourceDatasheet':{'path':'reference/am3352/am3352.pdf','sha256':'ec145b6b19a7ff35118bb0ec06b5ae9c51aa97ccdf4da935f2176d9168af0205','document':'SPRS717L March2020','tables':['7-61','7-62','7-68','7-69']},'board':{'copperLayers':4,'connectedSignals':47,'pending':['source_trace_26','source_trace_30'],'fabricationReady':False},'routingLayerConnectedOwnerCount':{k:len(v) for k,v in layer_owners.items()},'routingLayerOwners':{k:sorted(v,key=lambda x:int(x.split('_')[-1])) for k,v in layer_owners.items()},'pourPolygonCount':[{'layer':k[0],'sourceNetId':k[1],'count':v} for k,v in pour_summary.items()],'referenceAssessment':{'topAndBottomReferencePours':0,'inner1SignalCarriersPresent':bool(layer_owners['inner1']),'inner2SignalCarriersPresent':bool(layer_owners['inner2']),'fullUninterruptedGroundAndVddsDdrLayersEstablished':False,'standardTiTable7_61Arrangement':False,'actualReferencesReturnsAndImpedanceQualified':False,'note':'Fifteen filled inner polygons establish material presence, not full-plane continuity/return connectivity. Adjacent outer ground for inner carriers is absent from poured geometry; cross-core or finite coplanar references are not qualified. This screen does not perform polygon connectivity or field solving.'},'lengthAccounting':{'candidateStackup':'JLC04161H-3313; documented analytical candidate, not confirmed order stackup','copperCenterDepthMm':z,'activeVerticalTravelNotViaElectricalDelay':True,'barrelsRemainFullspan':True,'unusedBarrelStubsNotCountedAsTraversedLength':True,'ledgerMatchesCandidateOriginalPlanarObservations':True,'buses':buses,'nets':rows},'spacingScreen':{'completeWithinDeclaredScope':complete,'segmentCount':len(segments),'segmentPairComparisons':comparisons,'comparisonCap':MAX_PAIRS,'wallSeconds':time.monotonic()-START,'wallLimitSeconds':LIMIT,'scopeIncludes':'Actual joined47 numeric CPU-to-RAM copper, both package stubs included; all six spacing classes kept separate; differential partners exempt from foreign-net3W/4W only. Uses max(widths) if unequal. Exact finite-segment capsule intersection intervals unioned on each physical segment.','scopeExcludes':['two pending-net fanouts','non-DDR copper','same-net meander coupling','via/pad/drill constraints','plane connectivity','differential impedance/coupling qualification'],'classEncounterCounts':dict(encounters),'encounterCountsAreSegmentPairsNotExposureLength':True,'normalSpacingExceptionsNeeded':bool(exposure),'boundedSpacingExceptionMaxMm':31.75,'reducedSpacingExposureUnionMmByNet':dict(perowner),'allConnectedNetWholePlanarLengthsBelow31p75':all(row['planarMm']<31.75 for row in rows),'allCompleteConnectedNetMeasuredExposureBelow31p75':complete and all(v<31.75 for v in perowner.values()),'examples':examples,'spacingExceptionAloneQualifiesTi':False},'authority':{'solverSdkImported':False,'boardEdits':False,'checksOrLimitsChanged':False,'electricalTimingQualified':False,'fabricationReady':False}}
with OUT.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({'report':str(OUT),'reportSha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'layerOwnerCounts':report['routingLayerConnectedOwnerCount'],'spacingComplete':complete,'comparisonCount':comparisons,'wallSeconds':time.monotonic()-START,'exposedNetCount':len(perowner),'maxExposureMm':max(perowner.values()),'maxWholePlanarMm':max(row['planarMm'] for row in rows),'buses':buses},indent=2))
