"""Source-only until Root runs under its bounded KiCad10/xvfb wrapper.

Remove only source-mapped empty via placeholders by lexical span deletion.
Prove local copper connectivity on a separate zone-free temporary copy.
Never SaveBoard, refill, route, alter the raw board, or claim fabrication ready.
"""
import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import tempfile

EXPECTED_CORE_SHA = 'ed33a0a335b1fbf0da9adcdeacaa954b655c3c4964c600efb6ef3c72aef4040e'
EXPECTED_NATIVE_SHA = '99ce86ce927006668067f1c1b84bcdf937da64cc010457026f5fda6d2003ff68'
LAYER_NAMES = {'top': 'F.Cu', 'inner1': 'In1.Cu', 'inner2': 'In2.Cu', 'bottom': 'B.Cu'}
MM_SERIALIZATION_TOLERANCE = 1e-5


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_regular(path):
    require(path.is_file() and not path.is_symlink(), 'Concrete regular input required: ' + str(path))
    data = path.read_bytes()
    require(len(data) <= 32 * 1024 * 1024, 'Finite board/source/report input required')
    return data


def near(a, b):
    return math.isfinite(a) and math.isfinite(b) and abs(a - b) <= MM_SERIALIZATION_TOLERANCE


def at(a, b):
    return near(a[0], b[0]) and near(a[1], b[1])


def transform(x, y):
    return [100 + x, 100 - y]


def one(values, message):
    require(len(values) == 1, message + ' (matches=' + str(len(values)) + ')')
    return values[0]


def signed32(value):
    value &= 0xffffffff
    return value - 0x100000000 if value & 0x80000000 else value


def converter_uuid(seed):
    # Exact pinned converter simpleHash for ASCII ID/coordinate seeds.
    require(seed.isascii(), 'Only source ID/coordinate ASCII UUID seed supported')
    h = 0
    for char in seed:
        h = signed32(h * 31 + ord(char))
    chunks = []
    for index in range(4):
        value = h
        for char in seed:
            value = signed32(value * 31 + ord(char) + index * 31)
        chunks.append(format(abs(value), '08x'))
    value = ''.join(chunks)
    return value[:8] + '-' + value[8:12] + '-' + value[12:16] + '-' + value[16:20] + '-' + value[20:32]


class Node:
    def __init__(self, start):
        self.start, self.end, self.items = start, None, []

    @property
    def head(self):
        return self.items[0] if self.items and isinstance(self.items[0], str) else None


def parse_sexpressions(data):
    """Byte spans, quoted strings and escapes; never evaluate KiCad text."""
    roots, stack, index = [], [], 0
    while index < len(data):
        char = data[index]
        if char in b' \t\r\n':
            index += 1
            continue
        if char == ord('('):
            node = Node(index)
            (stack[-1].items if stack else roots).append(node)
            stack.append(node)
            index += 1
            continue
        if char == ord(')'):
            require(stack, 'Unbalanced closing board expression')
            stack.pop().end = index + 1
            index += 1
            continue
        require(stack, 'Unexpected token outside board expression')
        if char == ord('"'):
            index += 1
            token = bytearray()
            while index < len(data) and data[index] != ord('"'):
                if data[index] == ord('\\'):
                    index += 1
                    require(index < len(data), 'Truncated quoted board escape')
                token.append(data[index])
                index += 1
            require(index < len(data), 'Unterminated quoted board string')
            index += 1
            stack[-1].items.append(bytes(token).decode('utf-8'))
        else:
            start = index
            while index < len(data) and data[index] not in b'() \t\r\n':
                index += 1
            stack[-1].items.append(data[start:index].decode('utf-8'))
    require(not stack and len(roots) == 1 and roots[0].head == 'kicad_pcb', 'Exactly one complete KiCad PCB root required')
    return roots[0]


def children(node, kind):
    return [item for item in node.items if isinstance(item, Node) and item.head == kind]


def values(node, kind):
    item = one(children(node, kind), 'Unique ' + kind + ' field required')
    require(all(isinstance(value, str) for value in item.items), 'Scalar field required: ' + kind)
    return item.items[1:]


def drop_spans(data, nodes):
    result, previous = [], 0
    for node in sorted(nodes, key=lambda item: item.start):
        require(node.start >= previous and node.end > node.start, 'Unique nonoverlapping lexical removal spans required')
        result.append(data[previous:node.start])
        previous = node.end
    result.append(data[previous:])
    return b''.join(result)


def unique_source(rows, kind):
    result = {}
    for row in rows:
        if row['type'] == kind:
            ident = row[kind + '_id']
            require(ident not in result, 'Duplicate source identity: ' + ident)
            result[ident] = row
    return result


def source_inventory(source):
    kinds = ['source_component', 'source_manually_placed_via', 'source_port', 'source_net', 'source_trace', 'pcb_component', 'pcb_port', 'pcb_smtpad', 'pcb_plated_hole', 'pcb_trace', 'pcb_via']
    lookup = {kind: unique_source(source, kind) for kind in kinds}
    require([len(lookup[kind]) for kind in ['source_component', 'pcb_smtpad', 'pcb_trace', 'pcb_via', 'source_manually_placed_via', 'pcb_component']] == [280, 1161, 165, 129, 129, 409], 'Exact actual Core local101/HS64 inventory required')
    require(len(lookup['pcb_plated_hole']) == 4, 'All four original plated connector lands required')
    placeholders = {}
    for via_id, via in lookup['pcb_via'].items():
        require(via['layers'] == ['top', 'inner1', 'inner2', 'bottom'] and via['outer_diameter'] == .4572 and via['hole_diameter'] == .254, 'Source full-through via dimensions changed')
        aliases = [lookup['pcb_port'][ident] for ident in via['pcb_port_ids']]
        require(len(aliases) == 2 and {tuple(alias['layers']) for alias in aliases} == {('top',), ('bottom',)}, 'Two actual via aliases required')
        component_ids = {alias['pcb_component_id'] for alias in aliases}
        component = lookup['pcb_component'][one(list(component_ids), 'One actual via placeholder component required')]
        owners = [lookup['source_port'][alias['source_port_id']]['source_component_id'] for alias in aliases]
        require(len(set(owners)) == 1 and component['source_component_id'] == owners[0], 'Source/PCB via placeholder ownership differs')
        manual = lookup['source_manually_placed_via'][owners[0]]
        require(manual['source_net_id'] == via['source_net_id'] and at([component['center']['x'], component['center']['y']], [via['x'], via['y']]), 'Known source-owned barrel identity differs')
        require(component['pcb_component_id'] not in placeholders, 'Duplicate via pseudo-component')
        placeholders[component['pcb_component_id']] = {'component': component, 'sourceManuallyPlacedViaId': owners[0], 'pcbViaId': via_id}
    require(len(placeholders) == 129, 'Exactly129 source-owned placeholders required')
    return lookup, placeholders


def map_raw_footprints(root, source, lookup, placeholders):
    footprints = children(root, 'footprint')
    require(len(footprints) == 409, 'Raw exporter must retain280 real and129 empty via footprints')
    mapped, removals, seen_uuids = {}, [], set()
    for footprint in footprints:
        uuid = one(values(footprint, 'uuid'), 'One raw footprint UUID required')
        require(uuid not in seen_uuids, 'Duplicate raw footprint UUID')
        seen_uuids.add(uuid)
        position = values(footprint, 'at')
        require(len(position) == 3, 'Actual footprint XY/rotation required')
        xy = [float(position[0]), float(position[1])]
        candidates = []
        for ident, component in lookup['pcb_component'].items():
            if at(xy, transform(component['center']['x'], component['center']['y'])):
                seed = 'footprint:' + ident + ':' + position[0] + ',' + position[1]
                if converter_uuid(seed) == uuid:
                    candidates.append((ident, component))
        ident, component = one(candidates, 'Explicit source component/coordinate/UUID footprint mapping required')
        require(ident not in mapped, 'Source component mapped twice')
        require(near(float(position[2]) % 360, component.get('rotation', 0) % 360), 'Original footprint rotation differs')
        require(values(footprint, 'layer') == [LAYER_NAMES[component['layer']]], 'Original footprint assembly side differs')
        mapped[ident] = {'node': footprint, 'uuid': uuid, 'component': component}
        if ident in placeholders:
            require(footprint.items[1] == 'tscircuit:Unknown', 'Only exact converter via placeholder library identity eligible')
            require(len(footprint.items) == 5 and {item.head for item in footprint.items if isinstance(item, Node)} == {'layer', 'uuid', 'at'}, 'Source-owned placeholder must have no pad/text/graphics/model/other fields')
            require(not children(footprint, 'pad') and component['source_component_id'] not in lookup['source_component'], 'Real hardware footprint cannot be removed')
            removals.append(footprint)
        else:
            real = lookup['source_component'].get(component['source_component_id'])
            require(real, 'Every retained footprint must map a real source component')
            reference = one([item.items[2] for item in children(footprint, 'property') if item.items[1] == 'Reference'], 'One actual real-component Reference required')
            require(reference == real['name'], 'Real footprint reference differs from source identity')
    require(set(mapped) == set(lookup['pcb_component']) and len(removals) == 129, 'Complete exact source footprint inventory required')
    return mapped, removals


def source_anchor(pad):
    if 'x' in pad and 'y' in pad:
        return transform(pad['x'], pad['y'])
    points = pad.get('points')
    require(pad['shape'] == 'polygon' and points, 'Unsupported actual source SMT anchor')
    # The pinned converter uses vertex mean for a custom-polygon anchor.
    return transform(sum(point['x'] for point in points) / len(points), sum(point['y'] for point in points) / len(points))


def map_raw_copper(root, lookup, native):
    net_names = {int(node.items[1]): node.items[2] for node in children(root, 'net')}
    raw_vias, raw_segments = children(root, 'via'), children(root, 'segment')
    require(len(raw_vias) == 129, 'Exactly129 raw physical via records required')
    via_uuids, segment_uuids, used = {}, {}, set()
    for ident, source_via in lookup['pcb_via'].items():
        target = transform(source_via['x'], source_via['y'])
        node = one([item for item in raw_vias if at([float(v) for v in values(item, 'at')[:2]], target)], 'Unique source/raw physical via required')
        ident_uuid = one(values(node, 'uuid'), 'Raw via UUID required')
        require(ident_uuid not in used, 'Raw physical via UUIDs must be unique')
        used.add(ident_uuid)
        require(values(node, 'layers') == ['F.Cu', 'B.Cu'], 'Raw physical through-via span differs')
        require(near(float(values(node, 'size')[0]), source_via['outer_diameter']) and near(float(values(node, 'drill')[0]), source_via['hole_diameter']), 'Raw physical via dimensions differ')
        net = int(values(node, 'net')[0])
        require(net != 0 and net_names[net] == lookup['source_net'][source_via['source_net_id']]['name'], 'Raw physical via source rail differs')
        via_uuids[ident] = ident_uuid
    branches = {item['pcb_trace_id']: item for item in native['retainedHsTerminalLoops'] + native['packageTerminalLoops']}
    matched_nodes = set()
    for ident, trace in lookup['pcb_trace'].items():
        net_name = lookup['source_net'][branches[ident]['source_net_id']]['name']
        matches = []
        for a, b in zip(trace['route'], trace['route'][1:]):
            if a['x'] == b['x'] and a['y'] == b['y']:
                continue
            start, end = transform(a['x'], a['y']), transform(b['x'], b['y'])
            def matching(node):
                if node.start in matched_nodes:
                    return False
                first = [float(value) for value in values(node, 'start')]
                second = [float(value) for value in values(node, 'end')]
                net = int(values(node, 'net')[0])
                return values(node, 'layer') == [LAYER_NAMES[a['layer']]] and near(float(values(node, 'width')[0]), a.get('width', b.get('width'))) and net != 0 and net_names[net] == net_name and ((at(first, start) and at(second, end)) or (at(first, end) and at(second, start)))
            node = one([item for item in raw_segments if matching(item)], 'Unique source/raw exact segment required: ' + ident)
            ident_uuid = one(values(node, 'uuid'), 'Raw segment UUID required')
            require(ident_uuid not in used, 'Raw via/segment UUIDs must be unique')
            used.add(ident_uuid)
            matched_nodes.add(node.start)
            matches.append(ident_uuid)
        segment_uuids[ident] = matches
    require(len(matched_nodes) == len(raw_segments), 'Extra raw segment cannot be silently retained as a qualified source centerline')
    return {'viaUuids': via_uuids, 'segmentUuids': segment_uuids, 'netNames': net_names}


def native_inspect(plane_free_path, lookup, raw_footprints, raw_copper, native):
    import wx
    wx.Log.SetLogLevel(wx.LOG_Error)
    application = wx.App(False)
    import pcbnew
    require(pcbnew.GetBuildVersion().startswith('10.'), 'KiCad10 required for this fresh export')
    board = pcbnew.LoadBoard(str(plane_free_path))
    require(board is not None and board.GetCopperLayerCount() == 4, 'Four-layer board must load')
    require(len(list(board.Zones())) == 0, 'All filled zones must be absent from local branch connectivity proof')
    board.BuildConnectivity()
    footprints = list(board.GetFootprints())
    require(len(footprints) == 280, 'Only280 original real footprints may remain')
    uid = lambda item: item.m_Uuid.AsString()
    native_footprints = {uid(item): item for item in footprints}
    require(len(native_footprints) == 280, 'Native real footprint UUIDs must be unique')
    for ident, item in raw_footprints.items():
        if item['component']['source_component_id'] in lookup['source_component']:
            footprint = native_footprints[item['uuid']]
            require(footprint.GetReference() == lookup['source_component'][item['component']['source_component_id']]['name'], 'Native real footprint source/reference map changed')
    position = lambda point: [pcbnew.ToMM(point.x), pcbnew.ToMM(point.y)]
    native_pads = [pad for footprint in footprints for pad in footprint.Pads() if pad.GetAttribute() == pcbnew.PAD_ATTRIB_SMD]
    require(len(native_pads) == 1161 and len({uid(pad) for pad in native_pads}) == 1161, 'All1161 unique original SMT copper contacts required')
    pad_by_id, pad_by_port, used_pads = {}, collections.defaultdict(list), set()
    land_by_uuid, plated_rows = {}, []
    source_nets_by_key = collections.defaultdict(list)
    for source_net in lookup['source_net'].values():
        source_nets_by_key[source_net.get('subcircuit_connectivity_map_key', source_net['source_net_id'])].append(source_net)

    def source_port_for_land(land):
        port = lookup['pcb_port'][land['pcb_port_id']]
        source_port = lookup['source_port'][port['source_port_id']]
        component = lookup['pcb_component'][land['pcb_component_id']]
        require(port['pcb_component_id'] == land['pcb_component_id'] and source_port['source_component_id'] == component['source_component_id'] and component['source_component_id'] in lookup['source_component'], 'Every copper land must retain its original real numeric source owner')
        return source_port

    def verify_raw_native_pad(candidate, land, source_port):
        raw_pad = one([item for item in children(raw_footprints[land['pcb_component_id']]['node'], 'pad') if children(item, 'uuid') and values(item, 'uuid') == [uid(candidate)]], 'Raw/native original copper-pad UUID identity required')
        require(raw_pad.items[1] == str(source_port['pin_number']), 'Original raw/native numeric pad identity differs')
        raw_net = children(raw_pad, 'net')
        require(len(raw_net) <= 1, 'At most one original pad net required')
        raw_net_code = int(raw_net[0].items[1]) if raw_net else 0
        raw_net_name = raw_net[0].items[2] if raw_net else ''
        require(candidate.GetNetCode() == raw_net_code and candidate.GetNetname() == raw_net_name, 'Raw/native original pad net differs')
        if raw_net:
            require(raw_copper['netNames'][raw_net_code] == raw_net_name, 'Original pad net table differs')
        known_nets = source_nets_by_key.get(source_port.get('subcircuit_connectivity_map_key'), [])
        require(len(known_nets) <= 1, 'Ambiguous original known numeric source net')
        if known_nets:
            require(raw_net_code != 0 and raw_net_name == known_nets[0]['name'], 'Known numeric source pad rail differs')
        return raw_pad

    for ident, pad in lookup['pcb_smtpad'].items():
        component = raw_footprints[pad['pcb_component_id']]
        source_port = source_port_for_land(pad)
        number = str(source_port['pin_number'])
        candidate = one([item for item in native_footprints[component['uuid']].Pads() if uid(item) not in used_pads and item.GetAttribute() == pcbnew.PAD_ATTRIB_SMD and item.GetNumber() == number and at(position(item.GetPosition()), source_anchor(pad))], 'Unique native SMT numeric identity/shape-anchor mapping required: ' + ident)
        require(uid(candidate) not in used_pads, 'Source SMT pads cannot collapse onto one native contact')
        used_pads.add(uid(candidate))
        copper_layers = [board.GetLayerName(layer) for layer in [pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu, pcbnew.B_Cu] if candidate.GetLayerSet().Contains(layer)]
        require(copper_layers == [LAYER_NAMES[pad['layer']]], 'Original source SMT assembly layer differs')
        if pad['shape'] == 'circle':
            require(candidate.GetShape() == pcbnew.PAD_SHAPE_CIRCLE and all(near(value, pad['radius'] * 2) for value in position(candidate.GetSize())), 'Source circle pad copper dimensions changed')
        elif pad['shape'] == 'rect' and not (pad.get('corner_radius') or pad.get('rect_border_radius')):
            require(candidate.GetShape() == pcbnew.PAD_SHAPE_RECT and at(position(candidate.GetSize()), [pad['width'], pad['height']]), 'Source rectangular pad copper dimensions changed')
        verify_raw_native_pad(candidate, pad, source_port)
        pad_by_id[ident] = candidate
        pad_by_port[pad['pcb_port_id']].append(candidate)
        land_by_uuid[uid(candidate)] = {'sourceLandId': ident, 'kind': 'pcb_smtpad', 'shape': pad['shape']}
    native_plated = [pad for footprint in footprints for pad in footprint.Pads() if pad.GetAttribute() == pcbnew.PAD_ATTRIB_PTH]
    require(len(native_plated) == 4 and len({uid(pad) for pad in native_plated}) == 4, 'All four original unique plated lands required')
    for ident, plated in lookup['pcb_plated_hole'].items():
        source_port = source_port_for_land(plated)
        component = raw_footprints[plated['pcb_component_id']]
        require(plated['shape'] == 'pill' and not plated.get('hole_offset_x') and not plated.get('hole_offset_y'), 'Only the exact original unoffset pill plated lands are supported')
        candidate = one([item for item in native_footprints[component['uuid']].Pads() if uid(item) not in used_pads and item.GetAttribute() == pcbnew.PAD_ATTRIB_PTH and item.GetNumber() == str(source_port['pin_number']) and at(position(item.GetPosition()), transform(plated['x'], plated['y']))], 'Unique native plated numeric/source anchor mapping required: ' + ident)
        used_pads.add(uid(candidate))
        raw_pad = verify_raw_native_pad(candidate, plated, source_port)
        require(raw_pad.items[2:4] == ['thru_hole', 'oval'] and candidate.GetShape() == pcbnew.PAD_SHAPE_OVAL, 'Original plated pill copper shape differs')
        require(at(position(candidate.GetSize()), [plated['outer_width'], plated['outer_height']]) and at(position(candidate.GetDrillSize()), [plated['hole_width'], plated['hole_height']]), 'Original plated pill land/drill dimensions differ')
        require(candidate.GetDrillShape() == pcbnew.PAD_DRILL_SHAPE_OBLONG, 'Original plated pill drill shape differs')
        raw_angle = values(raw_pad, 'at')
        require(len(raw_angle) == 3 and near(float(raw_angle[2]) % 360, plated.get('ccw_rotation', 0) % 360), 'Original source plated relative rotation differs')
        expected_angle = (component['component'].get('rotation', 0) + plated.get('ccw_rotation', 0)) % 180
        require(near(candidate.GetOrientation().AsDegrees() % 180, expected_angle), 'Original native plated copper orientation differs')
        copper_layers = [board.GetLayerName(layer) for layer in [pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu, pcbnew.B_Cu] if candidate.GetLayerSet().Contains(layer)]
        require(set(copper_layers) == {LAYER_NAMES[layer] for layer in plated['layers']} == set(LAYER_NAMES.values()), 'Original plated full-layer copper span differs')
        pad_by_id[ident] = candidate
        pad_by_port[plated['pcb_port_id']].append(candidate)
        land_by_uuid[uid(candidate)] = {'sourceLandId': ident, 'kind': 'pcb_plated_hole', 'shape': plated['shape']}
        plated_rows.append({'pcb_plated_hole_id': ident, 'pcb_port_id': plated['pcb_port_id'], 'source_port_id': source_port['source_port_id'], 'numericPin': source_port['pin_number'], 'nativePadUuid': uid(candidate), 'positionMm': position(candidate.GetPosition()), 'nativeNetCode': candidate.GetNetCode(), 'nativeNetName': candidate.GetNetname(), 'outerSizeMm': position(candidate.GetSize()), 'drillSizeMm': position(candidate.GetDrillSize()), 'copperLayers': copper_layers, 'sourceRelativeRotationDegrees': plated.get('ccw_rotation', 0)})
    real_ports = {ident: port for ident, port in lookup['pcb_port'].items() if lookup['pcb_component'][port['pcb_component_id']]['source_component_id'] in lookup['source_component']}
    require(len(real_ports) == 1161 and set(pad_by_port) == set(real_ports) and len(used_pads) == 1165, 'All1161 original logical ports and1165 original authored copper lands must map')
    logical_contacts = []
    for ident, port in real_ports.items():
        source_port = lookup['source_port'][port['source_port_id']]
        expected_xy = transform(port['x'], port['y'])
        hit_point = pcbnew.VECTOR2I(pcbnew.FromMM(expected_xy[0]), pcbnew.FromMM(expected_xy[1]))
        lands = pad_by_port[ident]
        hits = [item for item in lands if item.HitTest(hit_point)]
        require(hits and all(item.GetNumber() == str(source_port['pin_number']) for item in lands), 'Original logical numeric PCBport is not on its actual mapped copper-land union: ' + ident)
        require(len({item.GetNetCode() for item in lands}) == 1 and len({item.GetNetname() for item in lands}) == 1, 'Original shared numeric copper lands carry different nets')
        copper_layers = {board.GetLayerName(layer) for item in lands for layer in [pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu, pcbnew.B_Cu] if item.GetLayerSet().Contains(layer)}
        require(copper_layers == {LAYER_NAMES[layer] for layer in port['layers']}, 'Original logical numeric PCBport copper layers differ')
        logical_contacts.append({'pcb_port_id': ident, 'source_port_id': port['source_port_id'], 'numericPin': source_port['pin_number'], 'sourcePortPositionMm': expected_xy, 'nativeLandUuids': [uid(item) for item in lands], 'sourceLandIds': [land_by_uuid[uid(item)]['sourceLandId'] for item in lands], 'actualNumericPortHitLandUuids': [uid(item) for item in hits], 'netCode': lands[0].GetNetCode(), 'netName': lands[0].GetNetname()})
    tracks = list(board.GetTracks())
    vias = [item for item in tracks if isinstance(item, pcbnew.PCB_VIA)]
    segments = [item for item in tracks if not isinstance(item, pcbnew.PCB_VIA)]
    require(len(vias) == 129 and len({uid(via) for via in vias}) == 129, 'All129 source-owned real vias must remain unique')
    require(not any(hasattr(pcbnew, 'PCB_ARC') and isinstance(item, pcbnew.PCB_ARC) for item in segments), 'Only exact source straight centerlines are allowed')
    via_by_id, used_vias = {}, set()
    for ident, source_via in lookup['pcb_via'].items():
        candidate = one([via for via in vias if at(position(via.GetPosition()), transform(source_via['x'], source_via['y']))], 'Unique native physical via source mapping required')
        require(uid(candidate) == raw_copper['viaUuids'][ident], 'Raw/native via UUID identity must remain exact')
        require(uid(candidate) not in used_vias, 'Source vias cannot collapse onto one native barrel')
        used_vias.add(uid(candidate))
        net_name = lookup['source_net'][source_via['source_net_id']]['name']
        require(candidate.GetNetCode() != 0 and candidate.GetNetname() == net_name, 'Actual native via rail differs')
        require(candidate.GetViaType() == pcbnew.VIATYPE_THROUGH and board.GetLayerName(candidate.TopLayer()) == 'F.Cu' and board.GetLayerName(candidate.BottomLayer()) == 'B.Cu', 'Every129 native barrel must be full F-to-B through-via')
        require(near(pcbnew.ToMM(candidate.GetWidth(pcbnew.F_Cu)), .4572) and near(pcbnew.ToMM(candidate.GetDrillValue()), .254), 'Actual via land/drill dimensions differ')
        via_by_id[ident] = candidate
    trace_segments, used_segments, expected_segment_count = {}, set(), 0
    require(len({uid(item) for item in segments}) == len(segments), 'Native segment UUIDs must be unique')
    all_branches = native['retainedHsTerminalLoops'] + native['packageTerminalLoops']
    branch_by_trace = {branch['pcb_trace_id']: branch for branch in all_branches}
    require(len(branch_by_trace) == 165, 'Every actual local source trace must have a passed native owner row')
    for ident, trace in lookup['pcb_trace'].items():
        branch = branch_by_trace[ident]
        require(trace['source_trace_id'] == branch['source_trace_id'], 'Passed source/physical trace identity differs')
        mapped = []
        for a, b in zip(trace['route'], trace['route'][1:]):
            require(a['route_type'] == b['route_type'] == 'wire' and a['layer'] == b['layer'], 'Only actual same-layer wire centerline segments expected')
            if a['x'] == b['x'] and a['y'] == b['y']:
                continue
            expected_segment_count += 1
            start, end = transform(a['x'], a['y']), transform(b['x'], b['y'])
            width = a.get('width', b.get('width'))
            net_name = lookup['source_net'][branch['source_net_id']]['name']
            candidate = one([item for item in segments if uid(item) not in used_segments and board.GetLayerName(item.GetLayer()) == LAYER_NAMES[a['layer']] and near(pcbnew.ToMM(item.GetWidth()), width) and item.GetNetCode() != 0 and item.GetNetname() == net_name and ((at(position(item.GetStart()), start) and at(position(item.GetEnd()), end)) or (at(position(item.GetStart()), end) and at(position(item.GetEnd()), start)))], 'Unique exact source/native segment geometry/layer/width/rail required: ' + ident)
            used_segments.add(uid(candidate))
            mapped.append(candidate)
        trace_segments[ident] = mapped
        require(sorted(uid(item) for item in mapped) == sorted(raw_copper['segmentUuids'][ident]), 'Every raw/native source segment UUID must remain exact')
    require(expected_segment_count == len(segments) == len(used_segments), 'Every actual165 centerline must map all exported segments without extras')
    connectivity = board.GetConnectivity()
    linked_cache = {}
    def linked(item):
        if uid(item) not in linked_cache:
            linked_cache[uid(item)] = {uid(value) for value in connectivity.GetConnectedItems(item)} | {uid(item)}
        return linked_cache[uid(item)]
    branches = []
    for branch in all_branches:
        pad = one([item for item in pad_by_port[branch['pcb_port_id']] if land_by_uuid[uid(item)]['kind'] == 'pcb_smtpad' and land_by_uuid[uid(item)]['shape'] in ['circle', 'rect']], 'One actual circle/rect numeric local branch land required')
        via = via_by_id[branch['pcb_via_id']]
        net_name = lookup['source_net'][branch['source_net_id']]['name']
        require(pad.GetNetCode() != 0 and pad.GetNetname() == via.GetNetname() == net_name, 'Numeric pad/owned-via rail changed')
        connected = linked(pad)
        require(uid(via) in connected and all(uid(item) in connected for item in trace_segments[branch['pcb_trace_id']]), 'Zone-free physical numeric pad-to-owned-via branch is missing')
        branches.append({'scope': branch['scope'], 'pcb_port_id': branch['pcb_port_id'], 'source_port_id': branch['source_port_id'], 'pcb_trace_id': branch['pcb_trace_id'], 'source_trace_id': branch['source_trace_id'], 'pcb_via_id': branch['pcb_via_id'], 'nativePadUuid': uid(pad), 'nativeViaUuid': uid(via), 'nativeSegmentUuids': [uid(item) for item in trace_segments[branch['pcb_trace_id']]], 'netName': net_name, 'zoneFreePhysicalConnected': True})
    contact = one(native['actualKnownNumericGraphAndOwnedBranchProof']['intentionalExistingPadContacts'], 'Passed exact HS8 pad contact required')
    strip = one(native['actualKnownNumericGraphAndOwnedBranchProof']['intentionalExistingTraceContacts'], 'Passed exact HS8 strip contact required')
    require(contact['pcb_smtpad_id'] == 'pcb_smtpad_729' and contact['pcb_port_id'] == 'pcb_port_730' and contact['source_port_id'] == 'source_port_730' and strip['pcb_trace_id'] == 'pcb_trace_55' and strip['source_trace_id'] == 'source_trace_987' and strip['existingOwnedHsViaId'] == 'pcb_via_55', 'Exact declared HS8 junction identity required')
    new_via = via_by_id[contact['pcb_via_id']]
    old_via = via_by_id[strip['existingOwnedHsViaId']]
    old_pad = pad_by_id[contact['pcb_smtpad_id']]
    require(uid(new_via) in linked(old_pad) and uid(old_via) in linked(old_pad) and all(uid(item) in linked(new_via) for item in trace_segments['pcb_trace_55']), 'Actual zone-free new-GND-via to old-cap to old-owned-via/strip junction is missing')
    return {'pcbnewBuildVersion': pcbnew.GetBuildVersion(), 'realFootprints': 280, 'sourceMappedSmtPads': 1161, 'sourceMappedPlatedLands': 4, 'sourceMappedCopperLands': 1165, 'sourceMappedLogicalNumericContacts': len(logical_contacts), 'logicalNumericContacts': logical_contacts, 'sourceMappedPlatedLandRecords': plated_rows, 'sourceMappedFullThroughVias': 129, 'sourceMappedTraceRecords': 165, 'sourceMappedSegmentCount': expected_segment_count, 'packagePhysicalBranchCount': sum(branch['scope'] == 'NEW_PACKAGE_TOP' for branch in branches), 'hsPhysicalBranchCount': sum(branch['scope'] == 'RETAINED_ACTUAL_HS_BOTTOM' for branch in branches), 'zoneCountDuringConnectivityProof': 0, 'branches': branches, 'hs8ZoneFreePhysicalJunction': {'newGndViaUuid': uid(new_via), 'oldGroundPadUuid': uid(old_pad), 'oldGroundViaUuid': uid(old_via), 'oldGroundStripSegmentUuids': [uid(item) for item in trace_segments['pcb_trace_55']], 'physicallyConnected': True}, 'customPolygonCopperGeometrySeparatelyUnqualified': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ['raw-board', 'source', 'native-report', 'cleaned-board', 'report']:
        parser.add_argument('--' + flag, type=Path, required=True)
    args = parser.parse_args()
    require(not args.cleaned_board.exists() and not args.cleaned_board.is_symlink() and not args.report.exists() and not args.report.is_symlink(), 'Fresh exclusive cleaned board/report required')
    require(args.cleaned_board.parent.is_dir() and args.report.parent.is_dir(), 'Existing fresh output directories required')
    inputs = [args.raw_board, args.source, args.native_report]
    before = {str(path): digest(read_regular(path)) for path in inputs}
    report = {'scope': 'NEW_PARTIAL_PACKAGE101_HS64_SOURCE_MAPPED_LOCAL_COPPER_KICAD10_INSPECTION', 'passed': False, 'inputHashesBefore': before, 'sourceSha256': before[str(args.source)], 'rawBoardSha256': before[str(args.raw_board)], 'boardSaved': False, 'refillRun': False, 'routerRun': False, 'referenceQualified': False, 'accepted49': False, 'fabricationReady': False}
    try:
        require(before[str(args.source)] == EXPECTED_CORE_SHA and before[str(args.native_report)] == EXPECTED_NATIVE_SHA, 'Exact passed actual Core/native report required')
        source = json.loads(read_regular(args.source))
        native = json.loads(read_regular(args.native_report))
        require(native['sourceSha256'] == EXPECTED_CORE_SHA and native['physicalErrors'] == 0 and native['checkCount'] == 18 and len(native['packageTerminalLoops']) == 101 and len(native['retainedHsTerminalLoops']) == 64 and native['rawNative17InputUnmodified'] is True, 'Passed exact local165 native owner report required')
        lookup, placeholders = source_inventory(source)
        raw = read_regular(args.raw_board)
        root = parse_sexpressions(raw)
        mapped, removals = map_raw_footprints(root, source, lookup, placeholders)
        raw_copper = map_raw_copper(root, lookup, native)
        cleaned = drop_spans(raw, removals)
        clean_root = parse_sexpressions(cleaned)
        require(len(children(clean_root, 'footprint')) == 280, 'Only source-identified129 empty placeholder blocks may be removed')
        require(len(children(root, 'via')) == len(children(clean_root, 'via')) == 129, 'Raw129 actual via copper records must remain intact')
        original_copper = [raw[node.start:node.end] for node in root.items if isinstance(node, Node) and node.head in ('via', 'segment', 'zone')]
        cleaned_copper = [cleaned[node.start:node.end] for node in clean_root.items if isinstance(node, Node) and node.head in ('via', 'segment', 'zone')]
        require(original_copper == cleaned_copper, 'Every raw via/segment/zone byte must stay exact')
        with args.cleaned_board.open('xb') as output:
            output.write(cleaned)
        args.cleaned_board.chmod(0o600)
        zones = children(clean_root, 'zone')
        zone_free = drop_spans(cleaned, zones)
        require(not children(parse_sexpressions(zone_free), 'zone'), 'No zone may remain in local connection proof')
        with tempfile.TemporaryDirectory(prefix='package101-zone-free-', dir=args.report.parent) as temporary:
            no_zone_path = Path(temporary) / 'zone-free.kicad_pcb'
            no_zone_path.write_bytes(zone_free)
            no_zone_path.chmod(0o600)
            native_result = native_inspect(no_zone_path, lookup, mapped, raw_copper, native)
        require(native_result['packagePhysicalBranchCount'] == 101 and native_result['hsPhysicalBranchCount'] == 64 and native_result['sourceMappedLogicalNumericContacts'] == 1161, 'Exact actual local branch and logical contact proof counts required')
        after = {str(path): digest(read_regular(path)) for path in inputs}
        require(after == before, 'Inspector changed a raw/Core/native input')
        report.update(passed=True, status='LOCAL_PACKAGE101_HS64_KICAD10_ZONE_FREE_CONNECTIVITY_PASS', inputHashesAfter=after, rawBoardHeld=True, cleanedBoardSha256=digest(read_regular(args.cleaned_board)), onlySourceMappedEmptyPlaceholdersRemoved=True, placeholderCount=129, removedPlaceholders=[{'pcbComponentId': ident, 'sourceManuallyPlacedViaId': value['sourceManuallyPlacedViaId'], 'pcbViaId': value['pcbViaId'], 'nativeEmptyFootprintUuid': mapped[ident]['uuid']} for ident, value in placeholders.items()], allOtherRawBytesHeld=True, originalZonesRetainedInCleanedCopy=len(zones), privateZoneFreeCopyRemoved=True, packageConnectedCount=101, hsConnectedCount=64, physicalViaCount=129, sourceContactsVerified=native_result['sourceMappedLogicalNumericContacts'], planesExcludedForLocalConnectivity=True, sourceContactVerificationScope='1161 original logical numeric PCBports, all1161SMT+4plated copper lands, raw/native numeric pad UUID/net/anchor/layer mapping and actual numeric-port HitTest on mapped land union; circle/rect and plated-pill dimensions; full custom polygon copper shape needs independent qualification', **native_result)
    except Exception as error:
        report.update(status='UNRESOLVED_SOURCE_MAPPING_OR_NATIVE_LOCAL_CONNECTIVITY_FAILURE', failure=str(error), inputHashesAfter={str(path): digest(read_regular(path)) for path in inputs})
    with args.report.open('x') as output:
        json.dump(report, output, indent=2)
        output.write('\n')
    args.report.chmod(0o600)
    print(json.dumps({'passed': report['passed'], 'status': report['status'], 'referenceQualified': False, 'accepted49': False, 'fabricationReady': False}))
    return 0 if report['passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
