from pathlib import Path
import json,hashlib,stat,copy,ast,difflib
OLD=Path('/tmp/g350-source29-native54-authentic53-root-guard-sourceonly-next');NEW=Path('/tmp/g350-source29-native54-moved29-report-scope-successor-sourceonly-next');assert not NEW.exists();NEW.mkdir(mode=0o700)
def pin(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def put(p,b):
 with p.open('xb')as f:f.write(b)
 p.chmod(0o600)
a='ACTUAL_FRESH_MOVED26_CORE292_NATIVE18_PHYSICAL_AND_NUMERIC_OWNER_GRAPH_QUALIFICATION';b='ACTUAL_FRESH_MOVED29_CORE292_NATIVE18_PHYSICAL_AND_NUMERIC_OWNER_GRAPH_QUALIFICATION'
m=json.loads((OLD/'SOURCE-manifest.json').read_text());patch=[];changed=[]
for row in m['files']:
 assert pin(row['path'])==row;p=Path(row['path']);raw=p.read_bytes()
 if p.name in('run-source29-native-after53-root.proposal.py','NATIVE29_RUNTIME_TAIL_SOURCE_ONLY_TEMPLATE.py'):
  s=raw.decode();assert s.count(a)==1;t=s.replace(a,b);assert t.replace(b,a)==s;ast.parse(t if p.name.startswith('run-')else 'def main():\n'+t[:t.index("if __name__")]);raw=t.encode();changed.append(p.name);patch.extend(difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile='5826/'+p.name,tofile='scope29/'+p.name))
 put(NEW/p.name,raw)
assert len(changed)==2
put(NEW/'EXACT_MOVED29_REPORT_SCOPE_LITERAL_ONLY_DELTA.patch',''.join(patch).encode())
worker=Path('/tmp/g350-source29-promoted-pins-stable-native-fresh49-api-runtime-sourceonly-next/qualify-fresh-native.mjs').read_text();assert "scope:'"+b+"'"in worker and "'complete26Accepted'"not in worker and 'complete26Accepted:false'in worker
# Only manifest-owned pins follow these new file paths/hashes; all historical refs stay held.
def remap(v):
 if isinstance(v,dict):
  if all(k in v for k in('path','sha256','bytes','mode'))and Path(v['path']).parent==OLD:
   q=copy.deepcopy(v);q.update(pin(NEW/Path(v['path']).name));return q
  return{k:remap(x)for k,x in v.items()}
 if isinstance(v,list):return[remap(x)for x in v]
 return v
m=remap(m);m.update(historicalUnexecutedNative54WrongReportScopeManifestPin=pin(OLD/'SOURCE-manifest.json'),onlyCurrentNativeReportScopeInspectorLiteralCorrected=True,expectedCurrentNativeReportScope=b,exactMoved29ReportScopeDeltaPin=pin(NEW/'EXACT_MOVED29_REPORT_SCOPE_LITERAL_ONLY_DELTA.patch'))
m['files']=[pin(p)for p in sorted(NEW.iterdir())if p.is_file()];m['externalFiles'] +=[pin(OLD/'SOURCE-manifest.json'),pin(OLD/'run-source29-native-after53-root.proposal.py'),pin(OLD/'NATIVE29_RUNTIME_TAIL_SOURCE_ONLY_TEMPLATE.py'),pin(Path(__file__))];m['ownFileCountExcludingManifest']=len(m['files']);m['externalFileCount']=len(m['externalFiles'])
s=(NEW/'run-source29-native-after53-root.proposal.py').read_text();assert "assert proposal['status']=="+repr(m['status'])in s and "'complete26Accepted'"in s
with(NEW/'SOURCE-manifest.json').open('x')as f:json.dump(m,f,indent=2);f.write('\n')
(NEW/'SOURCE-manifest.json').chmod(0o600)
print(json.dumps(dict(manifest=pin(NEW/'SOURCE-manifest.json'),guard=pin(NEW/'run-source29-native-after53-root.proposal.py'),tail=pin(NEW/'NATIVE29_RUNTIME_TAIL_SOURCE_ONLY_TEMPLATE.py'),delta=pin(NEW/'EXACT_MOVED29_REPORT_SCOPE_LITERAL_ONLY_DELTA.patch')),indent=2))
