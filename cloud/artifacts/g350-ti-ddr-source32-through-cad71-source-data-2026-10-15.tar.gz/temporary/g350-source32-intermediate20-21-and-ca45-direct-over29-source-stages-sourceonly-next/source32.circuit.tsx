// Source-only future32 declarations. Original numeric owners remain unchanged; fresh IDs belong to Core.
import { Children,cloneElement,createElement,isValidElement,type ReactElement,type ReactNode } from "react"
import { buildOwnerMoved29Source,registerOwnerMoved29InnerPorts } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-source29-joint7-ca6-ca18-reset-editable-source-stages-sourceonly-next/source29.circuit"
import data from "./source32-proposal.json"
import type { Source32Proposal } from "./source32-types"
const proposal=data as unknown as Source32Proposal, plan=proposal.source32Delta
const fields=["pcbPath","pcbPaths","pcbPathRelativeTo"] as const
type Props=Record<string,unknown>&{name?:string;children?:ReactNode}
const canonical=(v:unknown):string=>Array.isArray(v)?`[${v.map(canonical).join(",")}]`:v&&typeof v==="object"?`{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical((v as Record<string,unknown>)[k])}`).join(",")}}`:JSON.stringify(v)??"undefined"
const mm=(v:unknown):number=>{if(typeof v==="number"&&Number.isFinite(v))return v;if(typeof v==="string"&&/^-?\d+(?:\.\d+)?mm$/.test(v))return Number(v.slice(0,-2));throw Error("Finite genuine mm required")}
function sealedShape(){
 const roster=["source_trace_20","source_trace_21","source_trace_45"],intermediateRoster=["source_trace_20","source_trace_21"],names=intermediateRoster.map(id=>`V_TI_SIGNAL_INTERMEDIATE_${id}_0`)
 if(proposal.scope!=="UNEXECUTED_SOURCE32_SOURCE20_SOURCE21_INTERMEDIATE_CARRIER_VIAS_AND_SOURCE45_OVER_PROMOTED29"||proposal.promotedParent29Source.sha256!=="00421ca4aba188174b657a0787367231e19c7a4c2b1cade7e0f548378cbf1c5a"
  ||canonical(plan.exactNewOriginalSourceTraceRoster)!==canonical(roster)||canonical(plan.exactIntermediateOriginalSourceTraceRoster)!==canonical(intermediateRoster)||canonical(plan.routeChanges.map(r=>r.originalSourceTraceId))!==canonical(roster)
  ||canonical(plan.newIntermediateCarrierVias.map(v=>v.viaName))!==canonical(names)||canonical(proposal.intermediateCarrierVias)!==canonical(plan.newIntermediateCarrierVias)
  ||plan.newIntermediateCarrierVias.some(v=>v.role!=="REMOVABLE_INTERMEDIATE_CARRIER_VIA_NOT_FIXED_FANOUT")
  ||canonical(plan.newIntermediateCarrierVias.map(v=>v.xy))!==canonical([{x:-9,y:13.6},{x:-8.5,y:14.4}])
  ||canonical(plan.newSixInnerPorts.map(p=>`${p.viaName}:${p.layer}`).sort())!==canonical([...names.map(n=>`${n}:inner2`),...intermediateRoster.map(id=>`V_TI_SIGNAL_${id}_0:inner2`),"V_TI_SIGNAL_source_trace_45_0:inner2","V_TI_SIGNAL_source_trace_45_1:inner2"].sort())
  ||proposal.selected29OriginalCarriers.length!==29||proposal.selected32OriginalCarriers.length!==32||proposal.all98NumericOwnedSignalBranches.length!==98||proposal.all49OriginalLogicalTraces.length!==49
  ||proposal.expectedCounts.physicalVias!==229||proposal.expectedCounts.physicalTraces!==297||proposal.expectedCounts.innerLiteralPorts!==52
  ||proposal.expectedCounts.expectedSourcePorts!==1671||proposal.expectedCounts.expectedReactElements!==2286||proposal.expectedCounts.carrierBodyPaths!==34)
  throw Error("Exact two named intermediate-via/four-path Source20+21 plus ordinary Source45 roster required")
}
function requireFutureQualifiedParent29(){
 if(proposal.actualParent29Qualification===null||proposal.actualParent29Capture===null||proposal.jointIntermediateViaGeometryPeer===null||proposal.source45IndependentGeometryPeer===null||Object.values(proposal.actualParent29Stages).some(p=>p===null))
  throw Error("Source32 preparation refuses until authentic complete parent29 stage data and final joint Source20+21 numerical peer are bound in a new immutable successor")
 throw Error("Future Source32 activation must explicitly authenticate the genuinely collected parent29 qualification; this sealed preparation confers no runtime authority")
}
export function buildOwnerIntermediate32Source(){
 sealedShape();requireFutureQualifiedParent29()
 const base=buildOwnerMoved29Source(),changed=new Set<string>(),locals=new Set<string>(),ports=new Set<string>(),logical=new Set<string>();let boards=0,added=0
 function fork(node:ReactNode):ReactNode{
  if(!isValidElement<Props>(node))return node
  const props:Props={...node.props},children=Children.toArray(props.children).map(fork)
  if(plan.newIntermediateCarrierVias.some(v=>v.viaName===props.name))throw Error("New carrier via name must be absent from all parent29 declarations")
  const request=plan.newSixInnerPorts.find(p=>p.viaName===props.name)
  if(request){
   if(node.type!=="via"||children.length!==0||props.fromLayer!=="top"||props.toLayer!=="bottom"||mm(props.outerDiameter)!==.4572||mm(props.holeDiameter)!==.254||mm(props.pcbX)!==request.viaXY.x||mm(props.pcbY)!==request.viaXY.y||ports.has(request.viaName))throw Error("Only a genuine held CPU20/21 or CPU/RAM45 via receives one new inner2 child")
   children.push(createElement("port",{name:request.layer,layer:request.layer}));ports.add(request.viaName)
  }
  const change=plan.routeChanges.find(c=>c.logicalName===props.name)
  if(change){
   const old=Object.fromEntries(fields.filter(k=>props[k]!==undefined).map(k=>[k,props[k]]))
   if(node.type!=="trace"||props.from!==change.fromSelector||props.to!==change.toSelector||props.path!==undefined||mm(props.thickness)!==.1016||canonical(old)!==canonical(change.beforeRouteProps)||changed.has(change.originalSourceTraceId))throw Error("Original exact20/21/45 numeric trace must be physically unseeded")
   for(const k of fields)props[k]=undefined
   props.pcbPaths=change.after.newPcbPaths;props.pcbPathRelativeTo=change.after.newPcbPathRelativeTo;changed.add(change.originalSourceTraceId)
  }
  const local=plan.localSuppressions.find(p=>p.traceName===props.name)
  if(local){
   if(node.type!=="trace"||props.from!==local.numericSelector||props.to!==`.${local.viaName} > port.top`||mm(props.thickness)!==.1016||canonical(props.pcbPath)!=="[]"||props.pcbPaths!==undefined||props.pcbPathRelativeTo!==`.${local.viaName} > port.top`||locals.has(local.traceName))throw Error("Only the six existing Source20+21+45 local physical branches are suppressed")
   props.pcbPath=undefined;locals.add(local.traceName)
  }
  const original=proposal.all49OriginalLogicalTraces.find((p:Record<string,any>)=>p.name===props.name)
  if(original){if(node.type!=="trace"||props.from!==original.from||props.to!==original.to||logical.has(original.originalSourceTraceId))throw Error("Every original49 numeric logical owner remains exact");logical.add(original.originalSourceTraceId)}
  if(node.type==="board"){
   if(++boards!==1||props.layers!==4||props.routeRemaining!==false||(props.pcbX??0)!==0||(props.pcbY??0)!==0||(props.pcbRotation??0)!==0)throw Error("One unchanged manual four-layer board required")
   for(const v of plan.newIntermediateCarrierVias){children.push(createElement("via",{name:v.viaName,pcbX:v.xy.x,pcbY:v.xy.y,fromLayer:"top",toLayer:"bottom",outerDiameter:.4572,holeDiameter:.254,tented:"top_and_bottom_tented"},createElement("port",{name:"inner2",layer:"inner2"})));added++;ports.add(v.viaName)}
  }
  return cloneElement(node as ReactElement<Props>,props,...children)
 }
 const element=fork(base.element)
 if(boards!==1||added!==2||changed.size!==3||locals.size!==6||ports.size!==6||logical.size!==49)throw Error("Exact narrow Source32 declarations required")
 return {...base,element,ownerIntermediate32Proposal:data,ownerIntermediate32Integration:{changedOriginalSourceTraceIds:[...changed],newIntermediateCarrierViaNames:plan.newIntermediateCarrierVias.map(v=>v.viaName),carrierViaRole:"REMOVABLE_CARRIER_NOT_FIXED_FANOUT",newRealPortParents:[...ports],all227ExistingBarrelsHeld:true,all29PriorCarriersHeld:true,all98NumericBranchDefinitionsHeld:true,expectedCounts:proposal.expectedCounts,freshIdsAssigned:false,source32Qualified:false,all49Accepted:false,fabricationReady:false}}
}
type Via={componentName:string;props:Props;pcb_via_id?:string|null;source_manually_placed_via_id?:string|null}
type Port={componentName:string;props:Props;parent:unknown;matchedComponents:unknown[];source_port_id?:string|null;pcb_port_id?:string|null;registerMatch(owner:unknown):void;getAvailablePcbLayers():string[]}
type Circuit={_hasRenderedAtleastOnce?:boolean;schematicDisabled?:boolean;selectOne(selector:string,options?:{type?:string}):unknown}
export function registerOwnerIntermediate32InnerPorts(circuitUnknown:unknown){
 sealedShape();requireFutureQualifiedParent29();const circuit=circuitUnknown as Circuit
 if(circuit._hasRenderedAtleastOnce||circuit.schematicDisabled!==true)throw Error("Unrendered PCB-only actual Circuit required")
 const previous=registerOwnerMoved29InnerPorts(circuitUnknown);if(previous.registrations.length!==46)throw Error("Held46 genuine registrations required")
 const registrations:Array<{viaName:string;layer:string;xy:{x:number;y:number};numericSelector:string|null;originalSourceTraceId?:string;ownershipRole?:string}>=[...previous.registrations]
 for(const request of plan.newSixInnerPorts){
  const via=circuit.selectOne(`.${request.viaName}`)as Via|null,port=circuit.selectOne(`.${request.viaName} > port.${request.layer}`,{type:"port"})as Port|null
  if(!via||via.componentName!=="Via"||via.props.name!==request.viaName||via.props.fromLayer!=="top"||via.props.toLayer!=="bottom"||mm(via.props.outerDiameter)!==.4572||mm(via.props.holeDiameter)!==.254||mm(via.props.pcbX)!==request.viaXY.x||mm(via.props.pcbY)!==request.viaXY.y||!port||port.componentName!=="Port"||port.parent!==via||port.props.name!==request.layer||port.props.layer!==request.layer||port.source_port_id||port.pcb_port_id||via.pcb_via_id||via.source_manually_placed_via_id||port.getAvailablePcbLayers().join(",")!==request.layer||port.matchedComponents.some(owner=>owner!==via))throw Error("One real requested layer Port bound only to its genuine unrendered full-span Via required")
  if(!port.matchedComponents.includes(via))port.registerMatch(via)
  if(port.matchedComponents.length!==1||port.matchedComponents[0]!==via)throw Error("Exact physical alias ownership required")
  registrations.push({viaName:request.viaName,layer:request.layer,xy:request.viaXY,numericSelector:request.numericSelector,originalSourceTraceId:request.originalSourceTraceId,ownershipRole:request.numericSelector===null?"REMOVABLE_CARRIER_VIA_ALIAS":"EXISTING_NUMERIC_ENDPOINT_ALIAS"})
 }
 if(registrations.length!==52||new Set(registrations.map(r=>`${r.viaName}:${r.layer}`)).size!==52)throw Error("Exactly52 unique real matches required")
 return {registrations,extraPhysicalViaFromPortRegistration:false,explicitSourceOwnedIntermediateViaCount:2,coreRendered:false}
}
export default()=>buildOwnerIntermediate32Source().element
