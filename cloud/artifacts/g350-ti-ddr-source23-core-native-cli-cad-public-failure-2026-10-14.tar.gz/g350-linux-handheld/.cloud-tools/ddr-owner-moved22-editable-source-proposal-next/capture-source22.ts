/** Root-only Source evaluation. Frozen ancestors import Core definitions;
 * this worker constructs no Circuit and renders no Core/router/Native/CAD. */
import { Children, Fragment, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { readFileSync, writeFileSync, existsSync } from "node:fs"
import { createHash } from "node:crypto"
import assert from "node:assert/strict"
import { buildStrict18ManualSource } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-strict18-smooth-manual-source-core-successor-next/strict18-source-overlay"
import { buildOwnerMoved22Source } from "./source22.circuit"
import proposal from "./source22-proposal.json"

const [output, diagnostic, ...extra] = process.argv.slice(2)
assert.equal(process.env.G350_MOVED22_SOURCE_ROOT_GUARDED, "1")
assert.equal(process.versions.bun, "1.3.14")
assert.ok(output && diagnostic && extra.length === 0 && output !== diagnostic && !existsSync(output) && !existsSync(diagnostic))
const sha = (value: string | Buffer) => createHash("sha256").update(value).digest("hex")
for (const binding of Object.values(proposal.inputBindings)) assert.equal(sha(readFileSync(binding.path)), binding.sha256)
type Props = Record<string, unknown> & { children?: ReactNode }
type Row = { kind: "literal" | "fragment" | "primitive" | "unsupported"; type: string; key: string | null;
  props: Record<string, unknown>; children: Row[]; value?: unknown }
function identity(node: ReactNode): ReactNode {
  if (!isValidElement<Props>(node)) return node
  return cloneElement(node as ReactElement<Props>, { ...node.props }, ...Children.toArray(node.props.children).map(identity))
}
function snapshot(node: ReactNode): Row {
  if (!isValidElement<Props>(node)) {
    const allowed = node === null || node === undefined || ["boolean", "string", "number"].includes(typeof node)
    return { kind: allowed ? "primitive" : "unsupported", type: typeof node, key: null, value: node, props: {}, children: [] }
  }
  const { children, ...props } = node.props, actualType: unknown = node.type
  const kind = typeof actualType === "string" ? "literal" : actualType === Fragment ? "fragment" : "unsupported"
  return { kind, type: kind === "literal" ? actualType as string : kind === "fragment" ? "React.Fragment" : `${typeof actualType}:${String(actualType)}`,
    key: node.key, props, children: Children.toArray(children).map(snapshot) }
}
const flatten = (row: Row): Row[] => [row, ...row.children.flatMap(flatten)]
const clone = (row: Row): Row => ({ ...row, props: { ...row.props }, children: row.children.map(clone) })
function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`
  if (value && typeof value === "object") return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonical((value as Record<string, unknown>)[key])}`).join(",")}}`
  if (typeof value === "function") return `function:${value.toString()}`
  if (typeof value === "symbol") return `symbol:${String(value)}`
  return JSON.stringify(value) ?? "undefined"
}
const replacer = (_key: string, value: unknown) => typeof value === "function" ? { diagnosticFunction: value.name, sourceSha256: sha(value.toString()) }
  : typeof value === "symbol" ? { diagnosticSymbol: String(value), globalSymbolKey: Symbol.keyFor(value) ?? null } : value
const parent = buildStrict18ManualSource(), source = buildOwnerMoved22Source()
const historicalTree = snapshot(parent.element), before = snapshot(identity(parent.element)), after = snapshot(source.element)
const oldRows = flatten(before), newRows = flatten(after)
const counts = (rows: Row[]) => ({ reactElements: rows.filter(row => row.kind === "literal" || row.kind === "fragment").length,
  literalStrings: rows.filter(row => row.kind === "literal").length, fragments: rows.filter(row => row.kind === "fragment").length,
  primitiveChildren: rows.filter(row => row.kind === "primitive").length, unsupported: rows.filter(row => row.kind === "unsupported").length })
writeFileSync(diagnostic, JSON.stringify({ scope: "ACTUAL_MOVED22_SOURCE_TREE_BEFORE_INVERSE_ASSERTIONS", beforeCounts: counts(oldRows),
  afterCounts: counts(newRows), actualBeforeTree: before, actualProposedTree: after, inverseChecksExecuted: false,
  transitiveAncestorCoreDefinitionsImported: true, circuitConstructed: false, coreRendered: false, nativeExecuted: false, cadExecuted: false,
  referenceQualified: false, all49Accepted: false, fabricationReady: false }, replacer, 2) + "\n", { flag: "wx", mode: 0o600 })
const oldCapture = JSON.parse(readFileSync(proposal.inputBindings.actualSmooth18Capture.path, "utf8"))
assert.equal(oldCapture.passed, true); assert.equal(oldCapture.fullInverseSourceTreePassed, true)
assert.equal(canonical(JSON.parse(JSON.stringify(historicalTree, replacer))), canonical(oldCapture.actualSourceTree), "Actual parent Source tree remains byte-semantic exact including keys/containers")
assert.equal(counts(oldRows).unsupported, 0); assert.equal(counts(newRows).unsupported, 0)
assert.equal(counts(oldRows).reactElements, 2256); assert.equal(counts(newRows).reactElements, proposal.expectedCounts.expectedReactElements)
assert.equal(counts(newRows).literalStrings - counts(oldRows).literalStrings, proposal.expectedCounts.innerLiteralPorts - 28 + 4)
assert.equal(counts(newRows).fragments, counts(oldRows).fragments)
assert.equal(counts(newRows).primitiveChildren, counts(oldRows).primitiveChildren)
const one = (rows: Row[], label: string) => { assert.equal(rows.length, 1, label); return rows[0] }
const byName = (rows: Row[], name: string) => one(rows.filter(row => row.kind === "literal" && row.props.name === name), name)
const selected = new Map(proposal.selected22OriginalCarriers.map(row => [row.originalSourceTraceId, row]))
const routeFields = ["pcbPath", "pcbPaths", "pcbPathRelativeTo"] as const
const omit = (props: Record<string, unknown>, fields: readonly string[]) => Object.fromEntries(Object.entries(props).filter(([key]) => !fields.includes(key)))
for (const change of proposal.coordinateChanges) {
  const row = byName(newRows, change.name), old = byName(oldRows, change.name)
  assert.equal(row.type, change.type); assert.deepEqual({ pcbX: old.props.pcbX, pcbY: old.props.pcbY }, change.before)
  assert.deepEqual({ pcbX: row.props.pcbX, pcbY: row.props.pcbY }, change.after)
  assert.deepEqual(omit(row.props, ["pcbX", "pcbY"]), omit(old.props, ["pcbX", "pcbY"]), "No metadata/footprint/dimension/rotation or other Via prop change")
}
for (const owner of proposal.all98NumericOwnedSignalBranches) {
  const via = byName(newRows, owner.viaName), local = byName(newRows, owner.traceName)
  assert.equal(via.type, "via"); assert.ok(Math.hypot(Number(via.props.pcbX) - owner.viaXY.x, Number(via.props.pcbY) - owner.viaXY.y) < 1e-9)
  assert.equal(via.props.fromLayer, "top"); assert.equal(via.props.toLayer, "bottom")
  assert.equal(via.props.outerDiameter, .4572); assert.equal(via.props.holeDiameter, .254)
  assert.equal(local.type, "trace"); assert.equal(local.props.from, owner.numericSelector)
  assert.equal(local.props.to, `.${owner.viaName} > port.top`); assert.equal(local.props.thickness, .1016)
  assert.equal(local.props.pcbPathRelativeTo, `.${owner.viaName} > port.top`)
  assert.equal(local.props.pcbPaths, undefined)
  assert.deepEqual(local.props.pcbPath, selected.has(owner.originalSourceTraceId) ? undefined : [])
  const ports = proposal.added32RealInnerLayerPorts.filter(port => port.viaName === owner.viaName)
  assert.equal(via.children.length, ports.length)
  for (const requested of ports) {
    const port = one(via.children.filter(child => child.kind === "literal" && child.type === "port"), "One genuine inner Port")
    assert.deepEqual(port.props, { name: requested.layer, layer: requested.layer }); assert.equal(port.children.length, 0)
  }
}
for (const logical of proposal.all49OriginalLogicalTraces) {
  const row = byName(newRows, logical.name), old = byName(oldRows, logical.name), carrier = selected.get(logical.originalSourceTraceId)
  assert.equal(row.type, "trace"); assert.equal(row.props.from, logical.from); assert.equal(row.props.to, logical.to)
  assert.equal(row.props.pcbPath, undefined)
  assert.deepEqual(row.props.pcbPaths, carrier?.newPcbPaths)
  assert.equal(row.props.pcbPathRelativeTo, carrier?.newPcbPathRelativeTo)
  assert.deepEqual(omit(row.props, routeFields), omit(old.props, routeFields), "Every original numeric logical/timing/width prop remains exact")
}
const restored = clone(after), restoredRows = flatten(restored), untouchedActual = canonical(after)
let coordinatesRestored = 0, originalRouteFieldsRestored = 0, localsRestored = 0, portParentsRestored = 0
for (const change of proposal.coordinateChanges) {
  const row = byName(restoredRows, change.name), old = byName(oldRows, change.name)
  row.props.pcbX = old.props.pcbX; row.props.pcbY = old.props.pcbY; coordinatesRestored++
}
for (const logical of proposal.all49OriginalLogicalTraces) {
  const row = byName(restoredRows, logical.name), old = byName(oldRows, logical.name)
  for (const field of routeFields) { delete row.props[field]; if (Object.prototype.hasOwnProperty.call(old.props, field)) row.props[field] = old.props[field] }
  originalRouteFieldsRestored++
}
for (const owner of proposal.all98NumericOwnedSignalBranches.filter(owner => owner.originalSourceTraceId !== "source_trace_10")) {
  const local = byName(restoredRows, owner.traceName), oldLocal = byName(oldRows, owner.traceName)
  assert.deepEqual(omit(local.props, ["pcbPath"]), omit(oldLocal.props, ["pcbPath"]), "No local logical owner or extra routing prop changed")
  delete local.props.pcbPath; if (Object.prototype.hasOwnProperty.call(oldLocal.props, "pcbPath")) local.props.pcbPath = oldLocal.props.pcbPath; localsRestored++
  const via = byName(restoredRows, owner.viaName), oldVia = byName(oldRows, owner.viaName)
  via.children = oldVia.children.map(clone); portParentsRestored++
}
const resetDeclarations = [...proposal.resetViaDeclarations, ...proposal.resetLocalTraceDeclarations]
assert.equal(restored.type, "board"); assert.equal(restored.children.length, before.children.length + 4)
for (let i = 0; i < 4; i++) {
  const actual = restored.children[before.children.length + i], expected = resetDeclarations[i]
  assert.equal(actual.kind, "literal"); assert.equal(actual.type, expected.type)
  assert.deepEqual(actual.props, expected.props); assert.equal(actual.children.length, 0)
  assert.equal(oldRows.filter(row => row.props.name === expected.props.name).length, 0)
}
restored.children.splice(before.children.length, 4)
assert.equal(coordinatesRestored, 129); assert.equal(originalRouteFieldsRestored, 49)
assert.equal(localsRestored, 96); assert.equal(portParentsRestored, 96)
assert.equal(canonical(restored), canonical(before), "Full inverse: every container, key, prop, literal and child order remains exact outside declared deltas")
assert.equal(canonical(after), untouchedActual, "The actual proposed tree was never edited by the inverse")
for (const name of proposal.all129ReferenceViaNames) assert.equal(byName(newRows, name).type, "via")
assert.equal(newRows.filter(row => row.kind === "literal" && row.type === "via").length, 227)
assert.equal(newRows.filter(row => row.kind === "literal" && row.type === "bus").length, 8)
writeFileSync(output, JSON.stringify({ scope: "ACTUAL_ROOT_SOURCE_ONLY_OWNER_MOVED_227_JOINT22", passed: true,
  originalReactElementCount: 2256, proposedReactElementCount: proposal.expectedCounts.expectedReactElements, original49LogicalTracesHeld: true,
  original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse: true,
  originalInnerPortCount: 28, genuineNewInnerPortCount: proposal.expectedCounts.innerLiteralPorts, genuineResetViaCountAdded: 2,
  existingCoordinateDeclarationChanges: 129, newOriginalThreePathDeclarations: proposal.expectedCounts.carrierPaths,
  expectedPhysicalVias: 227, expectedPhysicalTraces: proposal.expectedCounts.physicalTraces, missingOriginal49RequestsExpected: proposal.expectedCounts.remainingOriginal49Requests,
  fullInverseSourceTreePassed: true, sourceOnlyProposalSha256: sha(readFileSync(new URL("./source22-proposal.json", import.meta.url))),
  actualSourceTree: after, actualDiagnosticPath: diagnostic, actualDiagnosticSha256: sha(readFileSync(diagnostic)),
  transitiveAncestorCoreDefinitionsImported: true, pureSourceEvaluationExecuted: true,
  circuitConstructed: false, coreRendered: false, nativeExecuted: false, cadExecuted: false,
  manualPairSourceBusForkHeld: true, automaticCoreSrjForThisForkMustNotBeUsed: true,
  referenceQualified: false, electricalTimingPassed: false, all49Accepted: false, fabricationReady: false,
}, replacer, 2) + "\n", { flag: "wx", mode: 0o600 })
