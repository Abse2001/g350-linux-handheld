// Source-only successor to the historical single-owner helper. Do not edit it.
// Geometry and .1016mm clearance remain identical; ownership is explicit sets.
import assert from 'node:assert/strict'
import { getProvedViaBranchRegistry, getProvedIntentionalPadContactRegistry } from './prove-shared-package-loops.mjs'

function actualPadBound(pad) {
  if (pad.shape === 'circle') {
    const radius = pad.type === 'pcb_plated_hole' ? pad.outer_diameter / 2 : pad.radius
    assert(Number.isFinite(pad.x) && Number.isFinite(pad.y) && Number.isFinite(radius) && radius > 0)
    return { kind: 'circle', x: pad.x, y: pad.y, radius }
  }
  if (pad.shape === 'polygon') {
    assert(Array.isArray(pad.points) && pad.points.length >= 3 && pad.points.every(p => Number.isFinite(p.x) && Number.isFinite(p.y)))
    return { kind: 'conservativeAabb', minX: Math.min(...pad.points.map(p => p.x)), maxX: Math.max(...pad.points.map(p => p.x)), minY: Math.min(...pad.points.map(p => p.y)), maxY: Math.max(...pad.points.map(p => p.y)) }
  }
  assert(['rect', 'pill', 'rotated_pill'].includes(pad.shape), 'Unsupported actual pad shape must not be skipped')
  const width = pad.outer_width ?? pad.width, height = pad.outer_height ?? pad.height
  assert(Number.isFinite(width) && width > 0 && Number.isFinite(height) && height > 0 && Number.isFinite(pad.x) && Number.isFinite(pad.y))
  const rotation = pad.ccw_rotation ?? 0
  assert(Number.isFinite(rotation))
  const theta = rotation * Math.PI / 180
  const halfX = (Math.abs(Math.cos(theta)) * width + Math.abs(Math.sin(theta)) * height) / 2
  const halfY = (Math.abs(Math.sin(theta)) * width + Math.abs(Math.cos(theta)) * height) / 2
  return { kind: 'conservativeAabb', minX: pad.x - halfX, maxX: pad.x + halfX, minY: pad.y - halfY, maxY: pad.y + halfY }
}

function viaPadGap(via, bound) {
  if (bound.kind === 'circle') return Math.hypot(via.x - bound.x, via.y - bound.y) - bound.radius - via.outer_diameter / 2
  const dx = Math.max(bound.minX - via.x, 0, via.x - bound.maxX)
  const dy = Math.max(bound.minY - via.y, 0, via.y - bound.maxY)
  return Math.hypot(dx, dy) - via.outer_diameter / 2
}

export function checkG350ProvedViaBranchManufacturingClearance(circuit, proof) {
  const registered = getProvedViaBranchRegistry(proof, circuit)
  const padContacts = getProvedIntentionalPadContactRegistry(proof, circuit)
  const traces = circuit.filter(r => r.type === 'pcb_trace')
  const traceIds = new Set()
  for (const trace of traces) {
    assert(typeof trace.pcb_trace_id === 'string' && !traceIds.has(trace.pcb_trace_id))
    traceIds.add(trace.pcb_trace_id)
  }
  const segments = traces.flatMap(t => t.route.slice(1).flatMap((b, i) => {
    const a = t.route[i]
    return a.route_type === 'wire' && b.route_type === 'wire' && a.layer === b.layer && Math.hypot(a.x - b.x, a.y - b.y) > 1e-8
      ? [{ a, b, owner: t.source_trace_id, width: b.width ?? a.width ?? .1016 }] : []
  }))
  const errors = []
  for (const v of circuit.filter(r => r.type === 'pcb_via')) for (const s of segments) {
    // An unregistered same-rail segment still receives the original rule.
    if (registered.get(v.pcb_via_id)?.has(s.owner)) continue
    const required = v.outer_diameter / 2 + s.width / 2 + .1016
    if (v.x < Math.min(s.a.x, s.b.x) - required || v.x > Math.max(s.a.x, s.b.x) + required || v.y < Math.min(s.a.y, s.b.y) - required || v.y > Math.max(s.a.y, s.b.y) + required) continue
    const dx = s.b.x - s.a.x, dy = s.b.y - s.a.y
    const f = Math.max(0, Math.min(1, ((v.x - s.a.x) * dx + (v.y - s.a.y) * dy) / (dx * dx + dy * dy)))
    const distance = Math.hypot(v.x - s.a.x - f * dx, v.y - s.a.y - f * dy)
    if (distance < required - 1e-6) errors.push({ pcb_via_id: v.pcb_via_id, source_trace_id: s.owner, clearanceMm: distance - v.outer_diameter / 2 - s.width / 2, requiredClearanceMm: .1016 })
  }
  // All actual SMT/plated copper, all rails. No same-global-net exemption.
  // Polygon/pill AABBs are conservative: a positive bound is sufficient;
  // failure remains a failure until a separately proved exact successor.
  const pads = circuit.filter(r => r.type === 'pcb_smtpad' || r.type === 'pcb_plated_hole').map(p => ({ row: p, bound: actualPadBound(p) }))
  for (const v of circuit.filter(r => r.type === 'pcb_via')) for (const { row: pad, bound } of pads) {
    const padId = pad.pcb_smtpad_id ?? pad.pcb_plated_hole_id
    assert(typeof padId === 'string')
    const layers = pad.layer ? [pad.layer] : pad.layers
    assert(Array.isArray(layers) && layers.length > 0)
    if (!layers.some(layer => v.layers.includes(layer))) continue
    if (padContacts.get(v.pcb_via_id)?.has(padId)) continue
    const gap = viaPadGap(v, bound)
    if (gap < .1016 - 1e-6) errors.push({ pcb_via_id: v.pcb_via_id, pcb_smtpad_id: pad.pcb_smtpad_id, pcb_plated_hole_id: pad.pcb_plated_hole_id, pcb_port_id: pad.pcb_port_id, clearanceMm: gap, requiredClearanceMm: .1016, manufacturingRule: 'ALL_NET_VIA_TO_PAD', shapeBound: bound.kind })
  }
  return errors
}
