# Existing package101 Core: seven owned alias-key additions

The first package101 source capture and full type stages passed and were collected. Actual direct Core rendered successfully as `ed33a0a335b1fbf0da9adcdeacaa954b655c3c4964c600efb6ef3c72aef4040e`. The original strict forward gate then rejected an added `subcircuit_connectivity_map_key` on an original reused Top via alias; native checks did not run. That collected failed packet remains untouched. This source-only successor reuses its exact Core without repeating capture, typecheck or render.

The only eligible original SourcePort IDs are 1167,1171,1175,1215,1225,1227 and1269. Each original record lacked the optional map-key field. Every other field must remain exact. Before allowing that field, the verifier proves the original Top PCB alias, manually owned via source, exact original full-through barrel, exact original Bottom aliases and retained cap/Bottom source trace. The new key must equal the original Bottom/barrel/trace key on the same original `source_net_0` or `source_net_5`. One declared canonical reused group must own the unchanged XY/barrel/rail; every new named branch must contain exactly that Top SourcePort and its unchanged numeric package SourcePort, resolve only the original rail, and carry the same key. This is no generic metadata or same-net waiver.

All other original records remain strict, including every original package/cap numeric pad, hardware/net/bus/source trace and all64 physical HS stubs/barrels. The existing explicit65 foreign-antipad Boolean comparison and original source/physical inventories remain required. The source-side branded numeric ownership helper and native17/manufacturing checker are byte-identical to the original package101 packet. The approved new RAM25 GND junction remains limited to old HS8 pad729/port730/source_port730 and old Bottom trace55/source_trace987; native and physical connectivity still have to pass.

The Root guard retains unchanged process_scope7bd, complete inherited source/protected/dependency bounds and exact existing CPython3.12.14 NumPy2.3.5/Shapely2.1.2 trees. It binds the actual collected original capture/type successes and Core-render/forward-failure receipt before a single fresh readonly run. Policy stays120s /3GiB owned /26GiB shared, with2GiB live prefork reserve. No capture, compiler, Core build, CLI, Docker, export or routing call is allowed in this stage.

Root prepares a fresh authority using the false/null template, exact manifest hash/policy/scope, truthful serial-worker flags and the latest actual closed postaudit. Then run:

```bash
source /workspace/g350-linux-handheld/cloud/env.sh
python3 -B /workspace/g350-linux-handheld/.cloud-tools/ddr-package101-existing-core-seven-alias-readonly-next/guard.py --stage readonly --root-receipt ABS_FRESH_ROOT_AUTHORITY --root-receipt-sha256 EXACT_AUTHORITY_SHA256
```

Preparation involved plain source/data reads and edits only. The verifier/native stage is unrun by the author. A pass would qualify the local101 package/64 HS approaches and these seven derived alias fields; fresh independent CAD connectivity, filled references, full power distribution, DDR49/timing and fabrication remain separate. `referenceQualified=false`, `accepted49=false`, `fabricationReady=false`.
