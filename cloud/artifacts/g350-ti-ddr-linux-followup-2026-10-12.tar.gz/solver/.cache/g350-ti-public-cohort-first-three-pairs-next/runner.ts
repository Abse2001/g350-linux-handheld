/** Direct original first-three prefix from a trusted public checkpoint; no init rerun. */
import { strict as assert } from "node:assert"
import { createHash } from "node:crypto"
import { readFileSync, writeFileSync, mkdirSync } from "node:fs"
import { join } from "node:path"
import { pairedViewFromPublicCheckpoint } from "./checkpoint"
import { installFirstThreeGate, type Job } from "./prefix-control"
import { traceProjection } from "./released-pair-observer"
import {
  orderCapturesByOriginalJobIdentity,
  type OriginalCapture,
} from "./identity-order"
import { actualPairLengthReportsByJobIdentity } from "./pair-length-report"
import type { SimpleRouteJson, Trace } from "./source/lib/types"
import type { InitialResult } from "./derive-allocation"

assert.deepEqual(process.argv.slice(2), ["--run-one-approved"])
assert.equal(process.env.G350_PUBLIC_COHORT_PAIRS_APPROVED, "1")
const root = import.meta.dir,
  sha = (raw: string | Uint8Array) =>
    createHash("sha256").update(raw).digest("hex")
const packetBytes = readFileSync(join(root, "packet-manifest.json")),
  packet = JSON.parse(packetBytes.toString())
const bound = <T>(name: string): T => {
  const raw = readFileSync(join(root, name))
  assert.equal(sha(raw), packet.inputBindings[name].sha256)
  return JSON.parse(raw.toString())
}
const input = bound<SimpleRouteJson>("input.json"),
  unrestricted = bound<SimpleRouteJson>("original-unrestricted-input.json")
const parentResult = bound<any>("parent-result.json"),
  parentPost = bound<any>("parent-postflight.json")
const actualInput = bound<SimpleRouteJson>(
  "parent-actual-public-initial-input.json",
)
assert.deepEqual(actualInput, input)
const initial = bound<InitialResult>("parent-actual-public-initial-result.json")
const options = bound<any>("parent-actual-public-initial-options.json")
const before = JSON.stringify({ input, unrestricted, initial, options })
const fresh = pairedViewFromPublicCheckpoint(
  input,
  unrestricted,
  initial,
  options,
  parentResult,
  parentPost,
)
let capturedBytes = 0
const save = (name: string, data: unknown) => {
  const raw = JSON.stringify(data, null, 2) + "\n",
    size = Buffer.byteLength(raw)
  if (size > 16 * 1024 ** 2 || capturedBytes + size > 64 * 1024 ** 2)
    throw Error("Declared immutable capture byte limit")
  writeFileSync(join(root, "run", name), raw, { flag: "wx" })
  capturedBytes += size
}
mkdirSync(join(root, "run", "observed"))
save("fresh-planner-input.json", fresh.allocation)
save("all-owned-approaches.json", fresh.escapes)
save("terminal-layers.json", [...fresh.terminalLayers])
const captures: any[] = [],
  started = performance.now()
const pairModule = await import("./source/lib/coupled-pair-routing")
const pairs = input.differentialPairs!
const gate = installFirstThreeGate(
  pairModule,
  pairs.map((pair) => pair.connectionNames),
  (job: Job) => {
    const captured = {
      ...job,
      output: traceProjection(job.result),
      wallMs: performance.now() - started,
    }
    save(`observed/job-${job.jobId}.json`, captured)
    captures.push(captured)
  },
)
let planner: Generator<Trace[] | undefined, void, any> | undefined
let nextCalls = 0,
  closed = false,
  completed = false,
  boundaryObserved = false
let tupleOffer: Trace[] | null = null,
  unexpectedError: string | null = null
try {
  const original = await import("./source/lib/route-fresh-surface-buses")
  planner = original.priorityPairPlans(fresh.allocation, fresh.terminalLayers)
  while (true) {
    const state = planner.next()
    nextCalls++
    if (state.done) {
      completed = true
      break
    }
    if (state.value) {
      tupleOffer = state.value
      break
    }
  }
} catch (error) {
  if (error === gate.boundary) boundaryObserved = true
  else unexpectedError = String(error).slice(0, 1024)
} finally {
  try {
    closed = planner?.return(undefined).done === true
  } catch (error) {
    unexpectedError = String(error).slice(0, 1024)
  }
  gate.restore()
}
const inputUnchanged =
  JSON.stringify({ input, unrestricted, initial, options }) === before
const tiInputBoundsHeld =
  JSON.stringify(fresh.allocation.buses) === JSON.stringify(input.buses) &&
  JSON.stringify(
    input.buses!.map(
      ({ allowedLayers: _a, preferredLayers: _p, ...bus }) => bus,
    ),
  ) ===
    JSON.stringify(
      unrestricted.buses!.map(
        ({ allowedLayers: _a, preferredLayers: _p, ...bus }) => bus,
      ),
    )
const referenceHardCopperHeld =
  JSON.stringify(fresh.allocation.traces!.slice(0, 2)) ===
  JSON.stringify(unrestricted.traces)
const captureContractSatisfied =
  inputUnchanged &&
  tiInputBoundsHeld &&
  referenceHardCopperHeld &&
  closed &&
  !completed &&
  (boundaryObserved || tupleOffer !== null) &&
  gate.originalFactories === 3 &&
  gate.factoryAttempts <= 4 &&
  captures.length === 3 &&
  gate.jobs.every((job) => job.terminal) &&
  gate.errors.length === 0 &&
  unexpectedError === null
const ordered =
  captures.length === 3
    ? orderCapturesByOriginalJobIdentity(
        fresh.allocation,
        captures as OriginalCapture[],
      )
    : []
const result = {
  status: captureContractSatisfied
    ? "ORIGINAL_PUBLIC_COHORT_FIRST_THREE_CAPTURED"
    : "INCONCLUSIVE_PREFIX",
  diagnosticQualified: captureContractSatisfied,
  captureContractSatisfied,
  packetSha256: sha(packetBytes),
  sourceCommit: packet.sourceRevision,
  libTree: packet.libTree,
  parentPublicInitializationTrusted: true,
  parentInitializationResultSha256:
    packet.inputBindings["parent-result.json"].sha256,
  originalUnrestrictedInputSha256:
    packet.inputBindings["original-unrestricted-input.json"].sha256,
  producerPolicyInputSha256: packet.inputBindings["input.json"].sha256,
  newInitializerCalls: 0,
  parentOriginalPublicInitializerCalls: 1,
  parentPublicPipelineExecuted: true,
  publicPipelineExecutedInThisRun: false,
  directOriginalPrefixCaller: true,
  strongerPerBusPolicy: true,
  expectedCarrierLayers: fresh.actualLayers,
  ownedApproachCount: fresh.escapes.length,
  terminalLayerMapCount: fresh.terminalLayers.size,
  pairOwnedApproachCount: 4,
  originalFactories: gate.originalFactories,
  factoryAttempts: gate.factoryAttempts,
  closed,
  completed,
  boundaryObserved,
  nextCalls,
  tupleOffer,
  chronologicalCompletionJobIds: captures.map((capture) => capture.jobId),
  normalizedJobIds: ordered.map((capture) => capture.jobId),
  actualPairLengthReports:
    ordered.length === 3
      ? actualPairLengthReportsByJobIdentity(fresh.allocation, captures)
      : [],
  captures: captures.map(({ arguments: args, result: value, ...summary }) => ({
    ...summary,
    argumentSha256: sha(JSON.stringify(args)),
    resultSha256: sha(JSON.stringify(value) ?? "undefined"),
  })),
  inputUnchanged,
  tiInputBoundsHeld,
  referenceHardCopperHeld,
  seededPriorCopper: false,
  seededPriorClock: false,
  temporaryGuidanceCopper: false,
  captureErrors: gate.errors,
  unexpectedError,
  capturedBytesBeforeReport: capturedBytes,
  originalOrdinaryFactories: 0,
  full49FinalizerCalls: 0,
  accepted49: false,
  tiEligibleBoard: false,
  timingReady: false,
  fabricationReady: false,
  limits:
    "Direct original first3 only from actual public initialization; singletonbus policy is stronger than original unrestricted7e4. Any future complete candidate MUST validate against original unrestricted input plus all24 owned approaches and reference copper. Pair arithmetic is not native/DRC/coupling/wholebus/49 qualification.",
}
save("result.json", result)
console.log(
  JSON.stringify({
    status: result.status,
    originalFactories: gate.originalFactories,
    completionOrder: result.chronologicalCompletionJobIds,
    accepted49: false,
  }),
)
if (!captureContractSatisfied) process.exitCode = 2
