"""Root-only two serial CAD stages: one export, then independent local CAD."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
 phase=sys.argv[1] if len(sys.argv)==2 else None
 if phase not in ('export','cad') or os.environ.get('G350_PACKAGE_CAD_STAGE')!=phase:raise ValueError('Exact Root CAD stage required')
 manifest=ROOT/'PREPARED-manifest.json';m=json.loads(manifest.read_bytes())
 if os.environ.get('G350_PACKAGE_CAD_PACKET_SHA')!=sha(manifest):raise ValueError('CAD source packet changed')
 auth=Path(os.environ['G350_PACKAGE_CAD_ROOT_RECEIPT']);a=json.loads(auth.read_bytes())
 if sha(auth)!=os.environ['G350_PACKAGE_CAD_ROOT_RECEIPT_SHA'] or a.get('authorizedByRoot') is not True or a.get('phase')!=phase or a.get('packetSha256')!=sha(manifest):raise ValueError('Exact Root CAD authority required')
 core=Path(m['acceptedCorePath']);native_path=Path(m['acceptedNativePath'])
 if sha(core)!=m['acceptedCoreSha256'] or sha(native_path)!=m['acceptedNativeSha256']:raise ValueError('Accepted actual local input/receipt changed')
 native=json.loads(native_path.read_bytes())
 if native['sourceSha256']!=m['acceptedCoreSha256'] or native['physicalErrors']!=0 or native['checkCount']!=18 or len(native['packageTerminalLoops'])!=101 or len(native['retainedHsTerminalLoops'])!=64:raise ValueError('Require actual accepted101+64 native input')
 run=ROOT/('run-'+phase);report={'phase':phase,'packetSha256':sha(manifest),'commands':[],'passed':False,'coreBuildCount':0,'cliCalls':0,'routingCalls':0,'cadCalls':0,'accepted49':False,'fabricationReady':False}
 def save():(run/'result.json').write_text(json.dumps(report,indent=2)+'\n')
 def command(name,argv,cwd):
  started=time.monotonic()
  with (run/(name+'.log')).open('xb') as out:result=subprocess.run(argv,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,check=False)
  report['commands'].append({'name':name,'argv':argv,'cwd':str(cwd),'exitCode':result.returncode,'seconds':time.monotonic()-started});save()
  if result.returncode:raise ValueError('CAD stage command failed: '+name)
 try:
  if phase=='export':
   copied=Path(m['physicalCliEntry'])
   command('verify-only-tested-fa7-physical-cli',[sys.executable,'-B',m['physicalCliConstructor'],'--cli-package-directory',m['installedCliDirectory'],'--output-directory',m['physicalCliDirectory'],'--verify-only'],Path(m['boardDirectory']))
   if sha(copied)!=m['physicalCliMainSha256']:raise ValueError('Tested physical CLI source differs')
   output=run/'package101-raw.kicad_pcb';report['cliCalls']=1
   command('one-raw-physical-via-cli-export',[m['bun'],'--smol',str(copied),'export',str(core),'--format','kicad_pcb','--output',str(output)],Path(m['boardDirectory']))
   command('verify-only-physical-cli-after-export',[sys.executable,'-B',m['physicalCliConstructor'],'--cli-package-directory',m['installedCliDirectory'],'--output-directory',m['physicalCliDirectory'],'--verify-only'],Path(m['boardDirectory']))
   if not output.is_file() or output.is_symlink() or sha(core)!=m['acceptedCoreSha256']:raise ValueError('Raw export missing or actual Core changed')
   report.update(passed=True,actualCoreInputNormalized=False,rawCadPath=str(output),rawCadSha256=sha(output),rawCadBytes=output.stat().st_size,localPhysical129ViaBoundaryStillRequiresCad=True)
  else:
   export_result=json.loads((ROOT/'run-export/result.json').read_bytes());raw=Path(export_result['rawCadPath'])
   if export_result['passed'] is not True or export_result['cliCalls']!=1 or sha(raw)!=export_result['rawCadSha256']:raise ValueError('Require completed exact fresh export')
   output=run/'output';output.mkdir();cleaned=output/'package101-placeholder-cleaned.kicad_pcb';inspection=output/'native-local101-hs64.json'
   report['cadCalls']=1
   container_name='g350-package101-cad-'+sha(manifest)[:16]+'-'+sha(auth)[:16]
   command('one-offline-kicad10-local101-plus64-physical-connectivity',['bash',str(ROOT/'run-kicad-offline.sh'),str(output),container_name,m['cadInspector'],'--raw-board',str(raw),'--source',str(core),'--native-report',str(native_path),'--cleaned-board',str(cleaned),'--report',str(inspection)],Path(m['boardDirectory']))
   inspected=json.loads(inspection.read_bytes())
   if inspected.get('sourceMappedCopperLands')!=1165 or inspected.get('sourceMappedPlatedLands')!=4 or inspected.get('onlySourceMappedEmptyPlaceholdersRemoved') is not True or inspected.get('placeholderCount')!=129 or inspected.get('allOtherRawBytesHeld') is not True or inspected.get('boardSaved') is not False or inspected.get('refillRun') is not False or inspected.get('routerRun') is not False or inspected.get('pcbnewBuildVersion')!='10.0.6+dfsg-1':raise ValueError('Original copper-land inventory, exact placeholder deletion or pinned KiCad boundary failed')
   if inspected.get('passed') is not True or inspected.get('sourceSha256')!=m['acceptedCoreSha256'] or inspected.get('rawBoardSha256')!=export_result['rawCadSha256'] or inspected.get('packageConnectedCount')!=101 or inspected.get('hsConnectedCount')!=64 or inspected.get('physicalViaCount')!=129 or inspected.get('sourceContactsVerified')!=1161 or inspected.get('sourceMappedSegmentCount')!=168 or inspected.get('realFootprints')!=280 or inspected.get('planesExcludedForLocalConnectivity') is not True:raise ValueError('Independent actual local CAD/geometry/zone-free graph gate failed')
   if sha(raw)!=export_result['rawCadSha256'] or sha(core)!=m['acceptedCoreSha256'] or sha(native_path)!=m['acceptedNativeSha256']:raise ValueError('CAD inspection changed bound input/receipt/raw files')
   report.update(passed=True,nativeCadReportSha256=sha(inspection),cleanedCadSha256=sha(cleaned),numeric101PackageAnd64HsPhysicalCadConnected=True,source129ViaCopperAndOriginal1161ContactsPreserved=True,rawCadAndSourceHeld=True,planeAssistedConnectivityClaim=False,filledReferencesQualified=False)
  save();print(json.dumps({'phase':phase,'passed':True,'coreBuildCount':0,'cliCalls':report['cliCalls'],'cadCalls':report['cadCalls'],'accepted49':False}));return 0
 except BaseException as error:
  report['failure']=str(error);save();raise
if __name__=='__main__':raise SystemExit(main())
