# Conservative strict18 corner smoothing candidate

This immutable Source-only packet replaces the sharp CPU corners of source_trace_15, source_trace_16 and source_trace_28 in original dataset21316. It changes no other fifteen records, endpoint coordinates, layer choices, physical barrel, local Topstub, reference path, pad or routing constraint. It is a candidate for fresh Source capture, types, Core, Native and the unchanged original private APIs; those applications have not run on this candidate.

Each new sampled circle has radius0.102 mm and at most15-degree sample turns. The self-clear function retains its radius0.1016 mm floor and returning-arm/crossing checks. The overall route-angle limit remains45.2 degrees. DQS0's virtual tangent intersection is shifted only to restore each measured sampled polyline length; that virtual point is never emitted as copper. Source28 uses a smooth CPU fold and one0.6 mm wide,0.2241266256 mm deep RAM approach U to restore its original length.

Whole conductor lengths, including both genuine fixed Topstubs, remain15=12.605536571052456 mm,16=12.72002519969238 mm,28=13.7 mm. Loaded Byte0 skew0.5664997117 mm, Byte1 skew0.5852813742 mm and clock skew0.0867766250 mm remain under0.635 mm; all three pair skews remain under0.127 mm. All18 static physical/self/angle checks and reciprocal spacing meters pass. This does not prove full49 timing.

The actual shared sections are15[12,29],16[12,28],28[25,34],27[4,13]; clocks retain73..121 and23..71. Filleting necessarily trims0.1191304057 mm from each DQS0 horizontal shared prefix and0.002 mm from the DQS1 vertical shared prefix. All later genuine shared geometry is exact. The new section evidence binds complete actual paths. Stale annotations are explicitly rejected by controls. All three shared/exterior translations calibrate to the actual previous original TS API output and pass on the candidate; this is a stdlib calculation, not TS API execution.

The original Native/API54946 attempt is preserved: Native passed18 physical checks and graphs; the private API failed only three angle predicates. Its positive physical evidence is not copied to the candidate as acceptance. New Source/Core/Native/API ownership and outputs are required.31 DDR carriers remain missing, and references, impedance, package/via delay, electrical timing and fabrication readiness remain false.

The later empty RAM+y1.2 research context is separate. This packet binds olded97/21316 and cannot be transplanted into that moved scene.
