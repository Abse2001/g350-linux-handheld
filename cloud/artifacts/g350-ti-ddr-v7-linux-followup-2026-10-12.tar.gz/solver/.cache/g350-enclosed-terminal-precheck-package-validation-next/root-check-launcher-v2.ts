if (Bun.env.G350_FULL_SOURCE_CHECKS_APPROVED !== "1") {
  throw Error("Root full-source verification authorization is required")
}
const python = Bun.env.G350_FULLCHECK_PYTHON
if (!python?.startsWith("/")) throw Error("Exact Python executable is required")
const child = Bun.spawn([python, `${import.meta.dir}/root-run-checks.py`], {
  cwd: import.meta.dir,
  stdin: "ignore",
  stdout: "inherit",
  stderr: "inherit",
})
process.exit(await child.exited)
