"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// controls.ts
var import_strict = __toESM(require("node:assert/strict"), 1);
var import_node_fs = __toESM(require("node:fs"), 1);
var import_node_path = __toESM(require("node:path"), 1);

// private-selection-primitives.ts
function installPrivateSelectionPrimitives(prototype, clock, publish) {
  const descriptor2 = Object.getOwnPropertyDescriptor(prototype, "computeSelection");
  if (!descriptor2 || !("value" in descriptor2) || typeof descriptor2.value !== "function" || descriptor2.get !== void 0 || descriptor2.set !== void 0 || descriptor2.configurable !== true || descriptor2.writable !== true || descriptor2.enumerable !== false)
    throw Error("Expected original own configurable writable computeSelection method");
  const original = descriptor2.value;
  const rows = [];
  let calls = 0, entered = 0, returned = 0, threw = 0, observationErrors = 0;
  let overflows = 0, restored = false;
  const record = (n, p2) => {
    try {
      const t = clock();
      if (!Number.isFinite(t) || t < 0) {
        observationErrors++;
        return;
      }
      const rounded = Math.round(t * 1e3) / 1e3;
      if (!Number.isFinite(rounded) || rounded < 0) {
        observationErrors++;
        return;
      }
      const row = JSON.stringify({ n, p: p2, t: rounded }) + "\n";
      if (row.length > 128) {
        overflows++;
        return;
      }
      rows.push(row);
      if (rows.length > 16) rows.shift();
      publish(row, rows.join(""));
    } catch {
      observationErrors++;
    }
  };
  function observed(...args) {
    if (calls >= Number.MAX_SAFE_INTEGER) {
      overflows++;
      return Reflect.apply(original, this, args);
    }
    const n = ++calls;
    entered++;
    record(n, 0);
    let result2;
    try {
      result2 = Reflect.apply(original, this, args);
    } catch (error) {
      threw++;
      record(n, 2);
      throw error;
    }
    returned++;
    record(n, 1);
    return result2;
  }
  Object.defineProperty(prototype, "computeSelection", { ...descriptor2, value: observed });
  return {
    snapshot: () => ({
      calls,
      entered,
      returned,
      threw,
      observationErrors,
      overflows,
      retainedRows: rows.length,
      retainedGeometry: false,
      additionalOriginalCalls: 0
    }),
    restore: () => {
      if (restored) return true;
      const current = Object.getOwnPropertyDescriptor(prototype, "computeSelection");
      if (current?.value !== observed) {
        observationErrors++;
        return false;
      }
      Object.defineProperty(prototype, "computeSelection", descriptor2);
      restored = true;
      return true;
    }
  };
}

// ../g350-ti-v12e-actual-core-patched-fanout-public-next/source/lib/geometry.ts
function distance(a, b) {
  const dx = a.x - b.x, dy = a.y - b.y;
  return Math.sqrt(dx * dx + dy * dy);
}
function pointSegmentDistance(p2, edge) {
  return pointSegmentDistanceToPoints(p2, edge[0], edge[1]);
}
function pointSegmentDistanceToPoints(p2, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y;
  if (dx === 0 && dy === 0) return distance(p2, a);
  const t = Math.max(
    0,
    Math.min(
      1,
      ((p2.x - a.x) * dx + (p2.y - a.y) * dy) / (dx * dx + dy * dy || 1)
    )
  );
  const ex = p2.x - a.x - t * dx, ey = p2.y - a.y - t * dy;
  return Math.sqrt(ex * ex + ey * ey);
}
var cross = (a, b, c) => (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
function segmentDistance(ab, cd) {
  const [a, b] = ab, [c, d] = cd;
  if (Math.max(a.x, b.x) >= Math.min(c.x, d.x) && Math.max(c.x, d.x) >= Math.min(a.x, b.x) && Math.max(a.y, b.y) >= Math.min(c.y, d.y) && Math.max(c.y, d.y) >= Math.min(a.y, b.y) && cross(a, b, c) * cross(a, b, d) <= 0 && cross(c, d, a) * cross(c, d, b) <= 0)
    return 0;
  return Math.min(
    pointSegmentDistance(a, cd),
    pointSegmentDistance(b, cd),
    pointSegmentDistance(c, ab),
    pointSegmentDistance(d, ab)
  );
}
var length = (path2) => path2.slice(1).reduce((sum, p2, i) => sum + distance(path2[i], p2), 0);

// ../g350-ti-v12e-actual-core-patched-fanout-public-next/source/lib/route-conflict-index.ts
var RouteConflictIndex = class {
  geometry = /* @__PURE__ */ new WeakMap();
  conflicts = /* @__PURE__ */ new WeakMap();
  getGeometry(route) {
    const cached = this.geometry.get(route);
    if (cached) return cached;
    const edges = [];
    const bounds = new Float64Array(Math.max(0, route.length - 1) * 4);
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (let i = 1; i < route.length; i++) {
      const a = route[i - 1], b = route[i], offset = (i - 1) * 4;
      edges.push([a, b]);
      bounds[offset] = Math.min(a.x, b.x);
      bounds[offset + 1] = Math.max(a.x, b.x);
      bounds[offset + 2] = Math.min(a.y, b.y);
      bounds[offset + 3] = Math.max(a.y, b.y);
      minX = Math.min(minX, bounds[offset]);
      maxX = Math.max(maxX, bounds[offset + 1]);
      minY = Math.min(minY, bounds[offset + 2]);
      maxY = Math.max(maxY, bounds[offset + 3]);
    }
    const result2 = { edges, bounds, minX, maxX, minY, maxY };
    this.geometry.set(route, result2);
    return result2;
  }
  firstConflict(first, second, required) {
    let row = this.conflicts.get(first);
    const cached = row?.get(second);
    if (cached?.required === required) return cached.result;
    if (!row) {
      row = /* @__PURE__ */ new WeakMap();
      this.conflicts.set(first, row);
    }
    const a = this.getGeometry(first), b = this.getGeometry(second);
    let result2 = null;
    if (a.maxX + required >= b.minX && b.maxX + required >= a.minX && a.maxY + required >= b.minY && b.maxY + required >= a.minY) {
      conflict: for (let i = 0; i < a.edges.length; i++) {
        const ai = i * 4;
        for (let j = 0; j < b.edges.length; j++) {
          const bj = j * 4;
          if (a.bounds[ai + 1] + required < b.bounds[bj] || b.bounds[bj + 1] + required < a.bounds[ai] || a.bounds[ai + 3] + required < b.bounds[bj + 2] || b.bounds[bj + 3] + required < a.bounds[ai + 2])
            continue;
          if (segmentDistance(a.edges[i], b.edges[j]) < required) {
            result2 = [i + 1, j + 1];
            break conflict;
          }
        }
      }
    }
    row.set(second, { required, result: result2 });
    return result2;
  }
};

// ../g350-ti-v12e-actual-core-patched-fanout-public-next/source/lib/select-route-candidates.ts
var CandidateConflicts = class {
  bits = new Uint8Array(0);
  sparse = /* @__PURE__ */ new Map();
  get(id) {
    if (id >= 4096) return this.sparse.get(id);
    const value = this.bits[id];
    return value ? value === 2 : void 0;
  }
  set(id, value) {
    if (id >= 4096) {
      this.sparse.set(id, value);
      return;
    }
    if (id >= this.bits.length) {
      const next = new Uint8Array(
        Math.max(16, 2 ** Math.ceil(Math.log2(id + 1)))
      );
      next.set(this.bits);
      this.bits = next;
    }
    this.bits[id] = value ? 2 : 1;
  }
  keys() {
    return this.sparse.keys();
  }
  delete(id) {
    this.sparse.delete(id);
  }
};
var RouteCandidatePool = class {
  constructor(clearance, limit = 120) {
    this.clearance = clearance;
    this.limit = limit;
  }
  clearance;
  limit;
  pools = /* @__PURE__ */ new Map();
  nextId = 0;
  additions = 0;
  assignments = /* @__PURE__ */ new Map();
  routeConflicts = new RouteConflictIndex();
  signatures = /* @__PURE__ */ new Map();
  routeSignatures = /* @__PURE__ */ new WeakMap();
  revision = 0;
  selection;
  add(unit, traces) {
    const pool2 = this.pools.get(unit) ?? [];
    let signatures = this.signatures.get(unit);
    if (!signatures) {
      signatures = /* @__PURE__ */ new Set();
      this.signatures.set(unit, signatures);
    }
    const signature = `[${traces.map((trace) => {
      let value = this.routeSignatures.get(trace.route);
      if (value === void 0) {
        value = JSON.stringify(trace.route);
        this.routeSignatures.set(trace.route, value);
      }
      return value;
    }).join(",")}]`;
    if (signatures.has(signature)) return;
    const lengths = traces.map((trace) => length(trace.route));
    const candidate = {
      traces,
      key: signature,
      length: lengths.reduce((sum, value) => sum + value, 0),
      peak: Math.max(...lengths),
      layers: [...new Set(traces.map((t) => t.route[0].layer))],
      singleLayer: traces.every(
        (t) => t.route[0].layer === traces[0].route[0].layer
      ) ? traces[0].route[0].layer : void 0,
      conflicts: new CandidateConflicts(),
      id: this.nextId++
    };
    pool2.push(candidate);
    signatures.add(signature);
    if (pool2.length > this.limit) signatures.delete(pool2.shift().key);
    this.pools.set(unit, pool2);
    this.additions++;
    this.revision++;
  }
  transformUnit(unit, transform) {
    const alternatives = this.pools.get(unit) ?? [];
    this.pools.delete(unit);
    this.signatures.delete(unit);
    this.revision++;
    for (const candidate of alternatives) {
      const traces = transform(candidate.traces);
      if (traces) this.add(unit, traces);
    }
  }
  hasEveryUnit(units) {
    return units.every((unit) => !!this.pools.get(unit)?.length);
  }
  /** Small unresolved domain set for generating fresh conditional routes.
   * A bounded search failure is a refinement hint, not an impossibility proof. */
  unresolvedUnits(units) {
    if (this.compatible(
      units.map((n) => this.pools.get(n) ?? []),
      5e5
    ))
      return null;
    let subset = units.slice();
    for (const unit of units) {
      const remaining = subset.filter((n) => n !== unit);
      if (!this.compatible(
        remaining.map((n) => this.pools.get(n) ?? []),
        5e5
      ))
        subset = remaining;
    }
    return subset;
  }
  conditionalRoutes(units, trial, completion = []) {
    if (!units.length) return [];
    const pivot = trial % units.length, index = Math.floor(trial / units.length);
    const domains = units.map((n, i) => {
      const pool2 = this.pools.get(n) ?? [];
      return trial < 0 || i !== pivot || !pool2.length ? pool2 : [pool2[index % pool2.length]];
    });
    let selected = this.compatible(domains, 5e5);
    if (!selected) return null;
    const extended = selected.map((candidate) => [candidate]);
    for (const unit of completion) {
      if (units.includes(unit)) continue;
      const domain = this.pools.get(unit) ?? [];
      const next = this.compatible([...extended, domain]);
      if (!next) continue;
      extended.push(domain);
      selected = next;
    }
    return selected.flatMap((candidate) => candidate.traces);
  }
  get revisionNumber() {
    return this.revision;
  }
  collides(a, b) {
    if (a.singleLayer !== void 0 && b.singleLayer !== void 0 && a.singleLayer !== b.singleLayer)
      return false;
    const low = a.id < b.id ? a : b;
    const high = Math.max(a.id, b.id);
    const row = low.conflicts;
    const cached = row.get(high);
    if (cached !== void 0) return cached;
    if (!a.layers.some((layer) => b.layers.includes(layer))) {
      row.set(high, false);
      return false;
    }
    for (const first of a.traces)
      for (const second of b.traces) {
        if (first.route[0].layer !== second.route[0].layer)
          continue;
        const required = (first.route[0].width + second.route[0].width) / 2 + this.clearance - 1e-8;
        if (this.routeConflicts.firstConflict(first.route, second.route, required)) {
          row.set(high, true);
          return true;
        }
      }
    row.set(high, false);
    return false;
  }
  compatible(domains, searchBudget = 5e4) {
    const key = `${searchBudget}:` + domains.map((domain) => domain.map((c) => c.id).join(",")).join(";");
    if (this.assignments.has(key)) return this.assignments.get(key);
    const result2 = this.computeCompatible(domains, searchBudget);
    if (this.assignments.size >= 128)
      this.assignments.delete(this.assignments.keys().next().value);
    this.assignments.set(key, result2);
    return result2;
  }
  computeCompatible(domains, searchBudget) {
    if (domains.some((domain) => !domain.length)) return null;
    const layers = domains.map(
      (domain) => new Set(domain.flatMap((candidate) => candidate.layers))
    );
    const pending = new Set(domains.map((_, i) => i));
    const components = [];
    while (pending.size) {
      const component = [pending.values().next().value];
      pending.delete(component[0]);
      for (let j = 0; j < component.length; j++)
        for (const i of pending) {
          if (![...layers[i]].some((layer) => layers[component[j]].has(layer)))
            continue;
          pending.delete(i);
          component.push(i);
        }
      components.push(component);
    }
    if (components.length > 1) {
      const combined = [];
      for (const component of components) {
        const result2 = this.compatible(
          component.map((i) => domains[i]),
          searchBudget
        );
        if (!result2) return null;
        component.forEach((index, i) => {
          combined[index] = result2[i];
        });
      }
      return combined;
    }
    const selected = domains.map(() => void 0);
    const visit = (remaining) => {
      if (--searchBudget < 0) return null;
      let next = -1;
      for (let i = 0; i < remaining.length; i++) {
        if (selected[i]) continue;
        if (!remaining[i].length) return null;
        if (next < 0 || remaining[i].length < remaining[next].length) next = i;
      }
      if (next < 0) return selected;
      for (const candidate of remaining[next]) {
        selected[next] = candidate;
        const filtered = remaining.map(
          (domain, i) => selected[i] ? domain : domain.filter((other) => !this.collides(candidate, other))
        );
        const result2 = visit(filtered);
        if (result2) return result2.slice();
        selected[next] = void 0;
        if (searchBudget < 0) break;
      }
      return null;
    };
    return visit(
      domains.map((domain) => [...domain].sort((a, b) => a.length - b.length))
    );
  }
  pruneConflicts() {
    const active = new Set(
      [...this.pools.values()].flat().map((candidate) => candidate.id)
    );
    for (const pool2 of this.pools.values())
      for (const candidate of pool2)
        for (const other of candidate.conflicts.keys())
          if (!active.has(other)) candidate.conflicts.delete(other);
    this.additions = 0;
  }
  select(units, matchingGroups = []) {
    const key = JSON.stringify([units, matchingGroups]);
    if (this.selection?.revision === this.revision && this.selection.key === key)
      return this.selection.result?.slice() ?? null;
    const result2 = this.computeSelection(units, matchingGroups);
    this.selection = { revision: this.revision, key, result: result2 };
    return result2?.slice() ?? null;
  }
  computeSelection(units, matchingGroups) {
    if (this.additions >= 100) this.pruneConflicts();
    let domains = units.map((unit) => this.pools.get(unit) ?? []);
    let best = this.compatible(domains);
    if (!best) return null;
    const peak = (candidate) => candidate.peak;
    for (const group of [units, ...matchingGroups]) {
      const indices = new Set(
        group.map((name) => units.indexOf(name)).filter((i) => i >= 0)
      );
      if (!indices.size) continue;
      let ceiling = Math.max(...best.filter((_, i) => indices.has(i)).map(peak));
      const levels = [
        ...new Set(
          domains.flatMap(
            (domain, i) => indices.has(i) ? domain.map(peak) : []
          )
        )
      ].filter((n) => n < ceiling).sort((a, b) => a - b);
      let lo = 0, hi = levels.length - 1;
      while (lo <= hi) {
        const mid = lo + hi >> 1;
        const choice = this.compatible(
          domains.map(
            (domain, i) => indices.has(i) ? domain.filter((c) => peak(c) <= levels[mid]) : domain
          )
        );
        if (choice) {
          best = choice;
          ceiling = levels[mid];
          hi = mid - 1;
        } else lo = mid + 1;
      }
      domains = domains.map(
        (domain, i) => indices.has(i) ? domain.filter((c) => peak(c) <= ceiling) : domain
      );
    }
    return best.flatMap((c) => c.traces);
  }
};

// controls.ts
var ROOT = process.env.G350_PRIVATE_SELECTION_CONTROL_ROOT;
import_strict.default.equal(process.env.G350_PRIVATE_SELECTION_CONTROL_APPROVED, "1");
import_strict.default.deepEqual(process.argv.slice(2), ["--run-one-approved"]);
var assertThat = (x, message) => import_strict.default.ok(x, message);
var make = (fn, flags = {}) => {
  const p2 = {};
  Object.defineProperty(p2, "computeSelection", { value: fn, enumerable: false, writable: true, configurable: true, ...flags });
  return p2;
};
var invoke = (p2, self, args) => Reflect.apply(p2.computeSelection, self, args);
var valid = (row, rolling) => {
  assertThat(row.length <= 128);
  assertThat([...row].every((c) => c.charCodeAt(0) <= 127));
  const r = JSON.parse(row);
  import_strict.default.deepEqual(Object.keys(r), ["n", "p", "t"]);
  assertThat(Number.isSafeInteger(r.n) && r.n > 0);
  assertThat([0, 1, 2].includes(r.p));
  assertThat(Number.isFinite(r.t) && r.t >= 0);
  assertThat(Buffer.byteLength(rolling) <= 2048);
  assertThat(rolling.trimEnd().split("\n").length <= 16);
};
var controlledOriginalCalls = 0;
var controlCases = 0;
var publishedRows = 0;
for (const value of [void 0, null, 17, /* @__PURE__ */ Symbol("return"), { returnMarker: 1 }]) {
  const argsSets = [[], [void 0], [{ a: 1 }, { b: 2 }, void 0]];
  for (const args of argsSets) {
    const self = { receiver: 1 };
    let calls = 0;
    const rows = [];
    const p2 = make(function(...received) {
      calls++;
      controlledOriginalCalls++;
      import_strict.default.equal(this, self);
      import_strict.default.equal(received.length, args.length);
      received.forEach((x, i) => import_strict.default.equal(x, args[i]));
      return value;
    });
    const before = Object.getOwnPropertyDescriptor(p2, "computeSelection");
    const o = installPrivateSelectionPrimitives(p2, () => 0.123456, (r, rolling) => {
      valid(r, rolling);
      rows.push(r);
      publishedRows++;
    });
    import_strict.default.equal(invoke(p2, self, args), value);
    import_strict.default.equal(calls, 1);
    import_strict.default.deepEqual(rows.map((r) => JSON.parse(r).p), [0, 1]);
    import_strict.default.equal(JSON.parse(rows[0]).t, 0.123);
    import_strict.default.deepEqual(Object.getOwnPropertyDescriptor(p2, "computeSelection"), { ...before, value: p2.computeSelection });
    assertThat(o.restore());
    import_strict.default.deepEqual(Object.getOwnPropertyDescriptor(p2, "computeSelection"), before);
    assertThat(o.restore());
    controlCases++;
  }
}
for (const error of [void 0, null, /* @__PURE__ */ Symbol("throw"), { throwMarker: 1 }]) {
  let calls = 0, caught = false;
  const rows = [];
  const p2 = make(function() {
    calls++;
    controlledOriginalCalls++;
    throw error;
  });
  const o = installPrivateSelectionPrimitives(p2, () => 1, (r, rolling) => {
    valid(r, rolling);
    rows.push(r);
    publishedRows++;
  });
  try {
    invoke(p2, {}, []);
  } catch (e) {
    caught = true;
    import_strict.default.equal(e, error);
  }
  assertThat(caught);
  import_strict.default.equal(calls, 1);
  import_strict.default.deepEqual(rows.map((r) => JSON.parse(r).p), [0, 2]);
  assertThat(o.restore());
  controlCases++;
}
for (const bad of [-1, NaN, Infinity, Number.MAX_VALUE]) {
  let calls = 0, rows = 0;
  const marker = {};
  const p2 = make(() => {
    calls++;
    controlledOriginalCalls++;
    return marker;
  });
  const o = installPrivateSelectionPrimitives(p2, () => bad, () => {
    rows++;
  });
  import_strict.default.equal(invoke(p2, {}, []), marker);
  import_strict.default.equal(calls, 1);
  import_strict.default.equal(rows, 0);
  import_strict.default.equal(o.snapshot().observationErrors, 2);
  assertThat(o.restore());
  controlCases++;
}
for (const failingPhase of [1, 2]) for (const shouldThrow of [false, true]) for (const kind of ["clock", "publisher"]) {
  let calls = 0, observations = 0, clockCalls = 0, publishCalls = 0;
  const marker = {};
  const p2 = make(() => {
    calls++;
    controlledOriginalCalls++;
    if (shouldThrow) throw marker;
    return marker;
  });
  const o = installPrivateSelectionPrimitives(p2, () => {
    clockCalls++;
    if (kind === "clock" && clockCalls === failingPhase) throw Error("observer clock failure");
    return 1;
  }, (r, rolling) => {
    publishCalls++;
    if (kind === "publisher" && publishCalls === failingPhase) throw Error("publisher failure");
    valid(r, rolling);
    observations++;
    publishedRows++;
  });
  let caught = false;
  try {
    import_strict.default.equal(invoke(p2, {}, []), marker);
  } catch (e) {
    caught = true;
    assertThat(shouldThrow);
    import_strict.default.equal(e, marker);
  }
  import_strict.default.equal(caught, shouldThrow);
  import_strict.default.equal(calls, 1);
  import_strict.default.equal(o.snapshot().observationErrors, 1);
  assertThat(o.restore());
  controlCases++;
}
{
  let calls = 0;
  const rows = [];
  const p2 = make(() => {
    calls++;
    controlledOriginalCalls++;
    return null;
  });
  const o = installPrivateSelectionPrimitives(p2, () => 2, (r, rolling) => {
    valid(r, rolling);
    rows.push(r);
    publishedRows++;
  });
  for (let i = 0; i < 40; i++) invoke(p2, {}, []);
  import_strict.default.equal(calls, 40);
  import_strict.default.equal(rows.length, 80);
  rows.forEach((r, i) => {
    const x = JSON.parse(r);
    import_strict.default.equal(x.n, Math.floor(i / 2) + 1);
    import_strict.default.equal(x.p, i % 2);
  });
  import_strict.default.equal(o.snapshot().retainedRows, 16);
  import_strict.default.equal(o.snapshot().observationErrors, 0);
  import_strict.default.equal(o.snapshot().retainedGeometry, false);
  assertThat(o.restore());
  controlCases++;
}
{
  let calls = 0;
  const marker = {};
  let p2;
  const rows = [];
  p2 = make(function(depth) {
    calls++;
    controlledOriginalCalls++;
    if (depth === 0) import_strict.default.equal(invoke(p2, this, [1]), marker);
    return marker;
  });
  const o = installPrivateSelectionPrimitives(p2, () => 3, (r, rolling) => {
    valid(r, rolling);
    rows.push(r);
    publishedRows++;
  });
  import_strict.default.equal(invoke(p2, {}, [0]), marker);
  import_strict.default.equal(calls, 2);
  import_strict.default.deepEqual(rows.map((r) => {
    const x = JSON.parse(r);
    return [x.n, x.p];
  }), [[1, 0], [2, 0], [2, 1], [1, 1]]);
  assertThat(o.restore());
  controlCases++;
}
{
  let getterCalls = 0;
  const data = () => null;
  const candidates = [{}, Object.create(make(data)), make(12), make(data, { writable: false }), make(data, { configurable: false }), make(data, { enumerable: true })];
  const accessor = {};
  Object.defineProperty(accessor, "computeSelection", { get() {
    getterCalls++;
    return data;
  }, configurable: true });
  candidates.push(accessor);
  for (const p2 of candidates) {
    const before = Object.getOwnPropertyDescriptors(p2);
    import_strict.default.throws(() => installPrivateSelectionPrimitives(p2, () => 0, () => {
    }));
    import_strict.default.deepEqual(Object.getOwnPropertyDescriptors(p2), before);
    controlCases++;
  }
  import_strict.default.equal(getterCalls, 0);
}
{
  const p2 = make(() => null);
  const o = installPrivateSelectionPrimitives(p2, () => 0, () => {
  });
  const replacement = () => 1;
  p2.computeSelection = replacement;
  import_strict.default.equal(o.restore(), false);
  import_strict.default.equal(p2.computeSelection, replacement);
  controlCases++;
}
var descriptor = Object.getOwnPropertyDescriptor(RouteCandidatePool.prototype, "computeSelection");
import_strict.default.equal(typeof descriptor.value, "function");
import_strict.default.equal(descriptor.enumerable, false);
import_strict.default.equal(descriptor.configurable, true);
import_strict.default.equal(descriptor.writable, true);
var originRows = [];
var origin = installPrivateSelectionPrimitives(RouteCandidatePool.prototype, () => 4, (r, rolling) => {
  valid(r, rolling);
  originRows.push(r);
  publishedRows++;
});
var pool = new RouteCandidatePool(0.1524);
import_strict.default.equal(pool.select(["source-only-missing-domain"]), null);
import_strict.default.equal(origin.snapshot().calls, 1);
import_strict.default.equal(pool.select(["source-only-missing-domain"]), null);
import_strict.default.equal(origin.snapshot().calls, 1);
assertThat(origin.restore());
import_strict.default.deepEqual(Object.getOwnPropertyDescriptor(RouteCandidatePool.prototype, "computeSelection"), descriptor);
import_strict.default.deepEqual(originRows.map((r) => JSON.parse(r).p), [0, 1]);
controlCases++;
var overheadCalls = 256;
var overheadOriginalCalls = 0;
var p = make(() => {
  overheadOriginalCalls++;
  return 1;
});
var stamp = performance.now();
for (let i = 0; i < overheadCalls; i++) invoke(p, {}, []);
var plainMs = performance.now() - stamp;
var latest = "";
var overhead = installPrivateSelectionPrimitives(p, () => performance.now(), (r, rolling) => {
  valid(r, rolling);
  latest = rolling;
});
var stamp2 = performance.now();
for (let i = 0; i < overheadCalls; i++) invoke(p, {}, []);
var observedMs = performance.now() - stamp2;
import_strict.default.equal(overheadOriginalCalls, overheadCalls * 2);
import_strict.default.equal(overhead.snapshot().calls, overheadCalls);
assertThat(Buffer.byteLength(latest) <= 2048);
assertThat(overhead.restore());
assertThat(Number.isFinite(plainMs) && plainMs >= 0 && Number.isFinite(observedMs) && observedMs >= 0);
controlCases++;
var result = { passed: true, engine: process.versions.bun ? `Bun ${process.versions.bun}` : process.version, scope: "PURE_PRIVATE_SELECTION_TRANSPARENCY_AND_ORIGINAL_EMPTY_DOMAIN_CALLER_SEAM", controlCases, controlledOriginalCalls, publishedRows, actualClassDescriptorAndSelectCachedSeam: true, actualClassSourceModule: "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-actual-core-patched-fanout-public-next/source/lib/select-route-candidates.ts", futureProducerModuleOriginQualified: false, noGridOrNativeChecker: true, actualBoardRoutingPerformed: false, overhead: { callsPerLoop: overheadCalls, plainMs, observedMs, measurementScope: "Pure controlled function and bounded rolling publisher; not routing benchmark" }, accepted49: false, fabricationReady: false };
import_node_fs.default.writeFileSync(import_node_path.default.join(ROOT, process.versions.bun ? "result-bun.json" : "result-node.json"), JSON.stringify(result, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(result));
