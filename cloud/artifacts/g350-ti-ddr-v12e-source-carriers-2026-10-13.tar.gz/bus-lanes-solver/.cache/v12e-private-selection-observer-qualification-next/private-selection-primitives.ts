/** SOURCE-ONLY PROPOSAL. No imports, installation, I/O, or routing on import.
 * Future runner may install this on its exact bundled RouteCandidatePool
 * prototype before a new attempt. This cannot observe the active attempt.
 */
type Event = { n: number; p: 0 | 1 | 2; t: number }
type Descriptor = PropertyDescriptor & { value: (...args: unknown[]) => unknown }

export function installPrivateSelectionPrimitives(
  prototype: object,
  clock: () => number,
  publish: (row: string, rolling: string) => void,
) {
  const descriptor = Object.getOwnPropertyDescriptor(prototype, "computeSelection")
  if (!descriptor || !("value" in descriptor) || typeof descriptor.value !== "function" ||
      descriptor.get !== undefined || descriptor.set !== undefined ||
      descriptor.configurable !== true || descriptor.writable !== true || descriptor.enumerable !== false)
    throw Error("Expected original own configurable writable computeSelection method")
  const original = (descriptor as Descriptor).value
  const rows: string[] = []
  let calls = 0, entered = 0, returned = 0, threw = 0, observationErrors = 0
  let overflows = 0, restored = false

  // Only numeric IDs/phases/timestamps. Never inspect or retain this, args,
  // candidates, domains, geometry, return objects, or exception objects.
  const record = (n: number, p: Event["p"]) => {
    try {
      const t = clock()
      if (!Number.isFinite(t) || t < 0) { observationErrors++; return }
      const rounded = Math.round(t * 1000) / 1000
      if (!Number.isFinite(rounded) || rounded < 0) { observationErrors++; return }
      const row = JSON.stringify({ n, p, t: rounded }) + "\n"
      // Numeric-only ASCII JSON: character count equals UTF-8 byte count.
      if (row.length > 128) { overflows++; return }
      rows.push(row)
      if (rows.length > 16) rows.shift()
      publish(row, rows.join(""))
    } catch { observationErrors++ }
  }
  function observed(this: unknown, ...args: unknown[]) {
    if (calls >= Number.MAX_SAFE_INTEGER) {
      overflows++
      return Reflect.apply(original, this, args)
    }
    const n = ++calls
    entered++
    record(n, 0)
    let result: unknown
    try {
      result = Reflect.apply(original, this, args)
    } catch (error) {
      threw++
      record(n, 2)
      throw error
    }
    returned++
    record(n, 1)
    return result
  }
  Object.defineProperty(prototype, "computeSelection", { ...descriptor, value: observed })
  return {
    snapshot: () => ({ calls, entered, returned, threw, observationErrors, overflows,
      retainedRows: rows.length, retainedGeometry: false, additionalOriginalCalls: 0 }),
    restore: () => {
      if (restored) return true
      const current = Object.getOwnPropertyDescriptor(prototype, "computeSelection")
      if (current?.value !== observed) { observationErrors++; return false }
      Object.defineProperty(prototype, "computeSelection", descriptor)
      restored = true
      return true
    },
  }
}
