from pathlib import Path
import json,hashlib,stat,copy,ast,sys,difflib,re
TEMPLATE=Path('/tmp/g350-source29-three-stage-batch-future52-promotion-parsed-template-sourceonly-next')
ACTIVATION=Path('/tmp/g350-source29-authentic52-parent-qualified-activation-sourceonly-next')
TARGET=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-source29-joint7-ca6-ca18-reset-editable-source-stages-sourceonly-next')
OUT=Path('/tmp/g350-source29-three-stage-batch-authentic52-promoted-root-guard-sourceonly-next')
assert len(sys.argv)==2 and re.fullmatch('[0-9a-f]{64}',sys.argv[1])
def pin(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def put(p,b):
 with p.open('xb')as f:f.write(b)
 p.chmod(0o600)
def js(p,v):put(p,(json.dumps(v,indent=2)+'\n').encode())
assert pin(TARGET/'SOURCE-manifest.json')['sha256']==sys.argv[1]
promoted=json.loads((TARGET/'SOURCE-manifest.json').read_text());activation=json.loads((ACTIVATION/'SOURCE-manifest.json').read_text());m=json.loads((TEMPLATE/'SOURCE-manifest.json').read_text());params=json.loads(Path('/tmp/source29-batch53-authentic52-consumer-SOURCE-proof.json').read_text())['actual52Parameters']
assert len(activation['files'])==17 and len(promoted['files'])==17
for row in activation['files']:
 q=TARGET/Path(row['path']).name;assert {k:pin(q)[k]for k in('sha256','bytes','mode')}=={k:row[k]for k in('sha256','bytes','mode')}
assert promoted['parent181HeldSourceBindings']==activation['parent181HeldSourceBindings']and promoted['expandedHeldSourceAndControllerClosure'][:181]==activation['expandedHeldSourceAndControllerClosure'][:181]
assert len(promoted['expandedHeldSourceAndControllerClosure'])==promoted['expandedHeldSourceAndControllerClosureCount']==186
for row in promoted['files']:assert pin(row['path'])==row
assert not OUT.exists();OUT.mkdir(mode=0o700)
old_guard=(TEMPLATE/'run-source29-capture-types-core-batch-root.proposal.py').read_text();old_consumer=(TEMPLATE/'CLOSED52_PARENT26_CAD_SOURCE_ONLY_TEMPLATE.py').read_text();new_consumer=Path('/tmp/source29-batch53-closed52-consumer.AUTHENTIC52.py').read_text()
assert old_guard.count(old_consumer)==1;guard=old_guard.replace(old_consumer,new_consumer)
ast.parse(guard)
for name in ('SOURCE29_CAPTURE_CORE_RESULT_INSPECTORS.py','SOURCE29_SERIAL_MAIN_TAIL.py'):put(OUT/name,(TEMPLATE/name).read_bytes())
put(OUT/'CLOSED52_PARENT26_CAD_SOURCE_ONLY.py',new_consumer.encode());put(OUT/'run-source29-capture-types-core-batch-root.proposal.py',guard.encode())
contract=json.loads((TEMPLATE/'SERIAL_BATCH29_CONTRACT.json').read_text());contract.update(scope='SOURCE_ONLY_SOURCE29_CAPTURE_TYPES_CORE_SERIAL_BATCH_AUTHENTIC52_PROMOTED186_ROOT_REVIEW_REQUIRED',actualParent26CadCollectionPin=params['actual52CollectionPin'],promotedSource29ManifestPin=pin(TARGET/'SOURCE-manifest.json'))
js(OUT/'SERIAL_BATCH29_CONTRACT.json',contract)
m.update(params)
m.update(scope='SOURCE_ONLY_SOURCE29_SERIAL_CAPTURE_TYPES_CORE_BATCH53_AFTER_AUTHENTIC52_AND_ROOT_PROMOTION',actual52AndSource29PromotionSealed=True,prepared29ActivationManifestPin=pin(ACTIVATION/'SOURCE-manifest.json'),prepared29ActivationPeerPin=pin('/tmp/g350-source29-authentic52-activation-independent-peer.json'),promoted29ManifestPin=pin(TARGET/'SOURCE-manifest.json'),promoted29ModulePin=pin(TARGET/'source29.circuit.tsx'),promoted29ProposalPin=pin(TARGET/'source29-proposal.json'),promoted29CapturePin=pin(TARGET/'capture-source29.ts'),promoted29TypesPin=pin(TARGET/'typecheck-source29.sh'),promoted29CorePin=pin(TARGET/'render-source29-core.ts'),source29BatchContractPin=pin(OUT/'SERIAL_BATCH29_CONTRACT.json'),source29Closed52ConsumerTemplatePin=pin(OUT/'CLOSED52_PARENT26_CAD_SOURCE_ONLY.py'),source29InspectorsPin=pin(OUT/'SOURCE29_CAPTURE_CORE_RESULT_INSPECTORS.py'),source29SerialMainTailPin=pin(OUT/'SOURCE29_SERIAL_MAIN_TAIL.py'),guardPin=pin(OUT/'run-source29-capture-types-core-batch-root.proposal.py'),historicalFuture52Batch53TemplateManifestPin=pin(TEMPLATE/'SOURCE-manifest.json'),historicalFuture52Batch53TemplateGuardPin=pin(TEMPLATE/'run-source29-capture-types-core-batch-root.proposal.py'),actualClosedSdkScopeCountRemains=52,plannedFirstActualSdkScopeRemains=53,actualSource29BatchCollectionPin=None,Source29Accepted=False,source29Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingPassed=False,fabricationReady=False,RootAuthorityCreated=False,guardHelperSdkProcessOrWorkerExecutedByAuthor=False)
# Keep the frozen future template as historical source, never asserting it was an execution.
for key in('actualCad52RootReceipt','actualCad52Report'):m[key]=None
put(OUT/'EXACT_FUTURE_TEMPLATE_TO_AUTHENTIC52_CONSUMER_DELTA.patch',''.join(difflib.unified_diff(old_guard.splitlines(True),guard.splitlines(True),fromfile='597d-future-template',tofile='source-only-authentic52-promoted29-guard')).encode())
metadata={k:dict(before=json.loads((TEMPLATE/'SOURCE-manifest.json').read_text()).get(k),after=m.get(k))for k in sorted(m)if k not in('files','externalFiles')and m.get(k)!=json.loads((TEMPLATE/'SOURCE-manifest.json').read_text()).get(k)}
js(OUT/'EXACT_AUTHENTIC52_AND_ROOT_PROMOTION_BINDINGS.json',metadata)
put(OUT/'README.md',b'Source-only, unexecuted Source29 serial capture/types/Core guard after authentic Root CAD52 and byte-identical Root promotion. Parent Source26 partial geometry is qualified by actual48/49/50/51/52. Source29 remains unaccepted and all actual Source29 artifacts remain NULL until Root runs and collects all three owned children. Capture60s1GiB, types120s2GiB, Core180s2GiB run serially with separate POSTs, common guard identity, whole Source186/SDK/native/Git/disk holds and immediate stop after first failed phase. All29 original Core predicates and1053 independently derived nonzero wire segments are required. No native/API/CLI/CAD or fabrication acceptance is granted by this batch. A fresh independent combined Source peer and Root authority are required before runtime.\n')
pt=ast.parse(old_guard);gt=ast.parse(guard);pm=next(n for n in pt.body if isinstance(n,ast.FunctionDef)and n.name=='main');gm=next(n for n in gt.body if isinstance(n,ast.FunctionDef)and n.name=='main');gd={n.name:n for n in gm.body if isinstance(n,ast.FunctionDef)};held=[]
for n in pm.body:
 if isinstance(n,ast.FunctionDef)and n.name!='closed52':assert ast.get_source_segment(old_guard,n)==ast.get_source_segment(guard,gd[n.name]);held.append(n.name)
proof=dict(scope='SOURCE_ONLY_AUTHENTIC52_ROOT_PROMOTED29_BATCH53_GUARD_PROOF',historicalTemplateManifestPin=pin(TEMPLATE/'SOURCE-manifest.json'),actual52Parameters=params,activated29ManifestPin=pin(ACTIVATION/'SOURCE-manifest.json'),promoted29ManifestPin=pin(TARGET/'SOURCE-manifest.json'),activated29PeerPin=pin('/tmp/g350-source29-authentic52-activation-independent-peer.json'),all17PromotedBodyBytesExact=True,parent181BindingsByteExact=True,heldSourceClosureCount=186,allPriorHistoryAndInspectorsAndSerialControllerByteExactExceptExplicit52Consumer=True,unchangedNestedFunctionNames=held,guardAstParsed=True,guardStatusLiteralMatchesManifest=True,actual52AuthenticAndRootPartial26Only=True,expectedActualNonzeroWireSegmentCount=1053,allSource29ActualsNull=True,guardHelperOrSdkOrAppImportedOrExecuted=False,workspaceWrites=False,RootAuthorityCreated=False,Source29Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingPassed=False,fabricationReady=False)
assert "assert proposal['status']=="+repr(m['status'])in guard
assert m['actual52AndSource29PromotionSealed']is True
js(OUT/'SOURCE_ONLY_AUTHENTIC52_PROMOTED29_BATCH53_PROOF.json',proof)
by={}
extras=[*m['files'],*m['externalFiles'],*activation['files'],pin(TEMPLATE/'SOURCE-manifest.json'),pin(ACTIVATION/'SOURCE-manifest.json'),pin(TARGET/'SOURCE-manifest.json'),pin('/tmp/g350-source29-authentic52-activation-independent-peer.json'),pin('/tmp/source29-batch53-closed52-consumer.AUTHENTIC52.py'),pin('/tmp/source29-batch53-authentic52-consumer-SOURCE-proof.json'),pin('/tmp/source29-batch53-authentic52-consumer-EXACT_DELTA.patch'),pin('/tmp/source29-batch53-EXACT_SERIAL48_TAIL_DELTA.patch'),pin(Path(__file__))]
for row in extras:assert row['path']not in by or by[row['path']]==row;by[row['path']]=row
m['files']=[pin(p)for p in sorted(OUT.iterdir())if p.is_file()];m['externalFiles']=list(by.values());m['ownFileCountExcludingManifest']=len(m['files']);m['externalFileCount']=len(m['externalFiles'])
# Source/data walk only: prohibit accidental illustrative null pin rows in the executable proposal.
def rows(v):
 if isinstance(v,dict):
  if all(k in v for k in('path','sha256','bytes','mode')):yield v
  else:
   for x in v.values():yield from rows(x)
 elif isinstance(v,list):
  for x in v:yield from rows(x)
allrows=list(rows(m));assert not any(any(r[k]is None for k in('path','sha256','bytes','mode'))for r in allrows)
for row in allrows:assert pin(row['path'])=={k:row[k]for k in('path','sha256','bytes','mode')}
js(OUT/'SOURCE-manifest.json',m)
print(json.dumps(dict(manifest=pin(OUT/'SOURCE-manifest.json'),guard=pin(OUT/'run-source29-capture-types-core-batch-root.proposal.py'),consumer=pin(OUT/'CLOSED52_PARENT26_CAD_SOURCE_ONLY.py'),contract=pin(OUT/'SERIAL_BATCH29_CONTRACT.json'),exactGuardDelta=pin(OUT/'EXACT_FUTURE_TEMPLATE_TO_AUTHENTIC52_CONSUMER_DELTA.patch'),metadataDelta=pin(OUT/'EXACT_AUTHENTIC52_AND_ROOT_PROMOTION_BINDINGS.json'),concreteProposalRowOccurrences=len(allrows),own=len(m['files']),external=len(m['externalFiles'])),indent=2))
