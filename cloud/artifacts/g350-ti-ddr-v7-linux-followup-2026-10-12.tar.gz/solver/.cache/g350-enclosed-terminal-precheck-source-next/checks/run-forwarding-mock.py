from pathlib import Path
import hashlib,importlib.util,json,os
ROOT=Path(__file__).resolve().parent.parent
SOURCE=ROOT/'source'
SCOPE=Path('/workspace/bus-lanes-solver/.cache/g350-ti-v5-combined-public-pipeline-v3-memory-next/process_scope.py')
assert hashlib.sha256(SCOPE.read_bytes()).hexdigest()=='7bdc74b15af3ba5b2c306d34a816b48cf8b9d68479b0c06a57f43787d4a4a993'
spec=importlib.util.spec_from_file_location('owned_mock_scope',SCOPE);scope=importlib.util.module_from_spec(spec);spec.loader.exec_module(scope)
POLICY={'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
M=ROOT/'library-v1/manifest.json';manifest=json.loads(M.read_bytes())
def verify():
 for f in manifest['files']:
  if hashlib.sha256((SOURCE/f['path']).read_bytes()).hexdigest()!=f['sha256']:raise ValueError('Frozen library changed: '+f['path'])
 return hashlib.sha256(M.read_bytes()).hexdigest()
before=verify();baseline=scope.memory()
def gate(current):
 if current['current']+POLICY['rssBytes']+2*1024**3>=POLICY['sharedBytes']:raise ValueError('Mock needs strict headroom')
 if any(current['events'][k]!=baseline['events'][k] for k in scope.OOM_KEYS):raise ValueError('New OOM before mock')
BUN='/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
command=[BUN,'test','tests/enclosed-terminal-precheck-forwarding.test.ts']
execution=scope.run_guarded(command,SOURCE,ROOT/'checks/forwarding-mock-v1',POLICY,{'TMPDIR':str(ROOT/'checks/tmp')},before_spawn=gate)
receipt={'scope':'Process-isolated MOCK forwarding only; both original Grid constructors prohibited; no physical proof','sourceManifestBefore':before,'sourceManifestAfter':verify(),'testSha256':hashlib.sha256((SOURCE/'tests/enclosed-terminal-precheck-forwarding.test.ts').read_bytes()).hexdigest(),'execution':execution,'accepted49':False}
(ROOT/'checks/forwarding-mock-v1-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'actualExit':execution['exitCode'],'stopReasons':execution['stopReasons'],'sourceBeforeAfterEqual':receipt['sourceManifestBefore']==receipt['sourceManifestAfter']}))
