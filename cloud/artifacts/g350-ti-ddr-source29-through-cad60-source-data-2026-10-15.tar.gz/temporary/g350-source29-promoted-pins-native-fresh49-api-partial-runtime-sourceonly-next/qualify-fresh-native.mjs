// Root only after source/peer/receipt/SDK checks. Never edits circuit JSON.
import assert from 'node:assert/strict'
import fs from 'node:fs'
import {createHash} from 'node:crypto'
const BOARD='/workspace/g350-linux-handheld',ROOT=import.meta.dir
const digest=b=>createHash('sha256').update(b).digest('hex')
const [manifestPath,manifestSha,authorityPath,authoritySha,output,...extra]=process.argv.slice(2)
assert.equal(process.env.G350_SOURCE7_SOURCE6_SOURCE18_RESET_REPAIR_29_FRESH_NATIVE_APPROVED,'1');assert.equal(process.versions.bun,'1.3.14')
assert(manifestPath&&manifestSha&&authorityPath&&authoritySha&&output&&!extra.length&&!fs.existsSync(output))
const validSha=h=>typeof h==='string'&&/^[0-9a-f]{64}$/.test(h)
// Null until Root seals the promoted Source29 declaration/proposal; no current23/24 material is admissible.
const FUTURE_SOURCE29_CORE_SOURCE_SHA="00421ca4aba188174b657a0787367231e19c7a4c2b1cade7e0f548378cbf1c5a",FUTURE_SOURCE29_PROPOSAL_SHA="34a35a2ef12829ac11303dfb98ce8c955efcf0c897fa133c79ddcd63d99cf86a"
assert(validSha(FUTURE_SOURCE29_CORE_SOURCE_SHA),'Root must bind the genuine promoted Source29 source manifest')
assert(validSha(FUTURE_SOURCE29_PROPOSAL_SHA),'Root must bind the genuine promoted Source29 proposal')
const load=(path,sha)=>{assert.equal(typeof path,'string');assert(path.startsWith('/'));assert(validSha(sha),'Mandatory bound SHA; future null pins refuse execution');const raw=fs.readFileSync(path);assert.equal(digest(raw),sha);return JSON.parse(raw)}
try {
const manifest=load(manifestPath,manifestSha),authority=load(authorityPath,authoritySha)
assert.equal(authority.authorizedByRoot,true);assert.equal(authority.scope,manifest.scope);assert.equal(authority.packetSha256,manifestSha)
assert.equal(authority.rootFullGuardReadPassed,true);assert.equal(authority.noConcurrentRootWorker,true)
assert.equal(authority.sourceManifestSha256,manifest.sourceManifestSha256)
assert.equal(authority.coreSourceManifestSha256,manifest.coreSourceManifestSha256)
assert(validSha(manifest.sourceManifestSha256));assert.equal(manifest.coreSourceManifestSha256,FUTURE_SOURCE29_CORE_SOURCE_SHA)
assert.equal(manifest.source29ProposalSha256,FUTURE_SOURCE29_PROPOSAL_SHA)
assert.equal(manifest.nativeWorkerPath,new URL(import.meta.url).pathname)
assert.equal(digest(fs.readFileSync(manifest.nativeWorkerPath)),manifest.nativeWorkerSha256)
for(const name of ['fresh-owner-factory.mjs','fresh-via-branch-manufacturing-clearance.mjs']){const p=new URL(name,import.meta.url).pathname;assert.equal(manifest.files.filter(r=>r.path===p).length,1,'Actual local private helper source must be bound')}
for(const row of [...manifest.files,...manifest.externalFiles]){const p=fs.lstatSync(row.path);assert(p.isFile()&&!p.isSymbolicLink());const b=fs.readFileSync(row.path);assert.equal(b.length,row.bytes);assert.equal(p.mode&0o777,row.mode);assert.equal(digest(b),row.sha256)}
assert.equal(digest(fs.readFileSync(BOARD+'/node_modules/@tscircuit/checks/dist/index.js')),'1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc')
const artifacts=manifest.actualFreshArtifacts
assert.deepEqual(authority.freshArtifacts,artifacts)
for(const key of ['actualCorePath','coreControlsPath']){assert.equal(typeof artifacts[key],'string');assert(artifacts[key].startsWith('/'))}
for(const key of ['actualCoreSha256','coreControlsSha256'])assert(validSha(artifacts[key]),'Actual Core25 pins must be supplied by Root')
const fresh=load(artifacts.actualCorePath,artifacts.actualCoreSha256),controls=load(artifacts.coreControlsPath,artifacts.coreControlsSha256)
assert.equal(controls.rawCorePath,artifacts.actualCorePath);assert.equal(controls.rawCoreSha256,artifacts.actualCoreSha256);assert.equal(controls.freshCoreControlPassed,true);assert.equal(controls.checks.length,29);assert(controls.checks.every(c=>c.passed===true))
const proposal=load(manifest.source29ProposalPath,manifest.source29ProposalSha256),material=load(manifest.source29MaterialPath,manifest.source29MaterialSha256)
const old=load(proposal.inputBindings.actualSmooth18CoreRaw.path,proposal.inputBindings.actualSmooth18CoreRaw.sha256)
const oldNativeReport=load(manifest.oldSmooth18NativeReportPath,manifest.oldSmooth18NativeReportSha256)
assert.equal(oldNativeReport.physicalErrors,0);assert.equal(oldNativeReport.physicalCpuRamConnectedCarrierCount,18)
const nativeTargets=load(proposal.inputBindings.ownerMoved22NativeHypothesis.path,proposal.inputBindings.ownerMoved22NativeHypothesis.sha256)
const checks=await import('/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js')
const {g350DdrPhysicalChecks}=await import('/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v10-ca-top-bytes-bottom-prefork-successor-next/source/scripts/lib/g350-ddr-physical-checks.mjs')
const {proveFreshMoved29Core}=await import('./fresh-owner-factory.mjs')
const {checkG350ProvedViaBranchManufacturingClearance}=await import('./fresh-via-branch-manufacturing-clearance.mjs')
const signature=JSON.stringify(fresh),proof=proveFreshMoved29Core({freshCore:fresh,controls,oldCore:old,oldNativeProof:oldNativeReport.actualOwnershipProof,proposal,material,nativeTargets})
const names=[...g350DdrPhysicalChecks,'checkPadPadClearance','checkTracesAreContiguous','checkDanglingTraces','checkPcbTracesOutOfBoard','checkPcbCopperOverKeepout','checkPcbComponentOverlap','checkPcbComponentsOutOfBoard'];assert.equal(names.length,17)
const results={},timing={}
for(const name of names){assert.equal(typeof checks[name],'function');results[name]=checks[name](fresh)}
results.checkG350ProvedViaBranchManufacturingClearance=checkG350ProvedViaBranchManufacturingClearance(fresh,proof)
// Full fresh circuit, unchanged native APIs; preserve every incomplete global finding.
timing.checkPcbBusLengthSkew=checks.checkPcbBusLengthSkew(fresh)
timing.checkPcbRoutingConstraints=checks.checkPcbRoutingConstraints(fresh)
const expectedPairs=[['DDR_DQS0_PAIR',['source_trace_15','source_trace_16']],['DDR_DQS1_PAIR',['source_trace_28','source_trace_27']],['DDR_CK_PAIR',['source_trace_33','source_trace_34']]]
const actualPairBuses=expectedPairs.map(([name,ids])=>{const rows=fresh.filter(r=>r.type==='source_bus'&&r.name===name);assert.equal(rows.length,1);assert.deepEqual(rows[0].source_trace_ids,ids);assert.equal(rows[0].max_length_skew,.127);return rows[0]})
const pairIds=new Set(actualPairBuses.map(b=>b.source_bus_id)),actualNativePairFindings=Object.values(timing).flat().filter(r=>pairIds.has(r.source_bus_id))
assert.equal(JSON.stringify(fresh),signature,'Native functions must not mutate actual raw Core')
const physicalErrors=Object.values(results).flat().length
const report={scope:'ACTUAL_FRESH_MOVED29_CORE292_NATIVE18_PHYSICAL_AND_NUMERIC_OWNER_GRAPH_QUALIFICATION',packetSha256:manifestSha,sourceManifestSha256:manifest.sourceManifestSha256,actualCorePath:artifacts.actualCorePath,actualCoreSha256:artifacts.actualCoreSha256,actualCoreControlsSha256:artifacts.coreControlsSha256,coreSourceManifestSha256:manifest.coreSourceManifestSha256,originalSource29ProposalSha256:manifest.source29ProposalSha256,checkCount:18,counts:Object.fromEntries(Object.entries(results).map(([name,issues])=>[name,issues.length])),results,physicalErrors,unchangedNativeTimingFunctions:timing,actualPairBuses,actualNativePairFindings,actualOwnershipProof:proof,physicalCpuRamConnectedCarrierCount:proof.carriers.filter(c=>c.actualSourceOwnedPhysicalGraph.physicallyConnected).length,expectedMissingOriginalSignalCount:20,all165ReferencePathsPreserved:true,all129ReferenceBarrelsPreserved:true,all98SignalBarrelsAndSource29TopStubsProved:true,source14RamBarrelAndTopStubChangedOnlyAsExplicitlyProposed:true,source3CpuBarrelAndFourPointTopStubChangedOnlyAsExplicitlyProposed:true,source27And28CarriersChangedOnlyAsExplicitlyProposed:true,source7RamBarrelAndThirteenPointTopStubChangedOnlyAsExplicitlyProposed:true,resetEightVertexCarrierRepairExplicit:true,all25OtherParent26CarriersExact:true,all49OriginalLogicalNumericRequestsPreserved:true,rawCircuitUnmodified:true,sourceNetFabricationPerformed:false,circuitJsonGeometryOrIdentitiesEdited:false,globalSameNetManufacturingExemption:false,onlyAuthenticRam25Hs8PadAndStripContactRegistered:true,originalAll3CouplingApisAgainstActualGeometryRequiredSeparately:true,noCoreRenderPerformed:true,noRoutingPerformed:true,noCliOrCadPerformed:true,full49RoutesUnfinished:true,fullCohortTimingPassed:false,electricalTimingQualified:false,referenceQualified:false,complete26Accepted:false,accepted49:false,fabricationReady:false}
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600})
assert.equal(physicalErrors,0,'Actual full Native18 physical/manufacturing findings retained before assertion')
assert.equal(actualNativePairFindings.length,0,'Actual native findings from all3 original differential buses retained')
assert.equal(report.physicalCpuRamConnectedCarrierCount,29)
console.log(JSON.stringify({actualNative18PhysicalErrors:physicalErrors,actualAll3PairNativeFindings:actualNativePairFindings.length,physicalCpuRamConnectedCarrierCount:29,expectedMissingOriginalSignalCount:20,accepted49:false,fabricationReady:false}))

} catch(error) {
 if(!fs.existsSync(output))fs.writeFileSync(output,JSON.stringify({scope:'UNRESOLVED_MOVED29_NATIVE_PRECONDITION_OR_OWNERSHIP',passed:false,failure:String(error),rawCircuitUnmodified:true,accepted49:false,referenceQualified:false,electricalTimingQualified:false,fabricationReady:false},null,2)+'\n',{flag:'wx',mode:0o600})
 throw error
}
