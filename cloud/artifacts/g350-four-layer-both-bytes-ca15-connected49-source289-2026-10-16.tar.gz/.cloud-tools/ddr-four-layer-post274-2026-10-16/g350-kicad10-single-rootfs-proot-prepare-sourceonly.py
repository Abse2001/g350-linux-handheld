#!/usr/bin/env python3
"""SOURCE ONLY. Root-run PRoot prerequisite probe and single-copy image extraction.

This never imports/runs KiCad, Docker, Bun, or routing code. It downloads only two
small exact official Debian packages into a fresh owned directory. No package is
installed. The prepare action reads the existing pinned image archive and makes
one disposable rootfs copy; it does not modify an image, archive, frozen evidence,
board, or system configuration. Root guards each action and any later CAD run.
"""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import tarfile
import time
import urllib.request

BOARD = Path('/workspace/g350-linux-handheld')
IMAGE = BOARD / '.cloud-tools/kicad10-debian.tar'
IMAGE_SHA = '70a47643a9a6d89cca64579b5ef6bab5a290803ccc94ed9b9e170fb14c70b6bb'
CONFIG = 'blobs/sha256/11b9360b20752e87f20942639e229b0d111e96f6e30b1bd1cb2eaafce9f26cfc'
LAYER = 'blobs/sha256/dc6bd6081d010129ac314430968e4a36f2c066bcda19468fc1c1fbc9fc80f938'
LAYER_BYTES = 1536673280
PACKAGES = [
 {'name': 'proot', 'url': 'https://deb.debian.org/debian/pool/main/p/proot/proot_5.1.0-1.3+b1_amd64.deb',
  'bytes': 75876, 'sha256': '7ca9260edf1ca6666f9b33e1da551638055934d673117acd135ff5367f420744'},
 {'name': 'libtalloc2', 'url': 'https://deb.debian.org/debian/pool/main/s/samba/libtalloc2_2.4.3+samba4.22.11+dfsg-0+deb13u1_amd64.deb',
  'bytes': 63644, 'sha256': 'b4cc8aa74c8b7c05a64efb6577acc955f522a8e39d8f37fe60b1b3fe6634ce96'},
]
SHARED_LIMIT = 30 * 1024**3
OWNED_RSS_LIMIT = 2 * 1024**3
RESERVE = 1024**3

def need(ok, message):
    if not ok: raise ValueError(message)

def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1048576): h.update(chunk)
    return h.hexdigest()

def sha(blob): return hashlib.sha256(blob).hexdigest()

def fresh_json(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2); f.write('\n'); os.fchmod(f.fileno(), 0o600)

def admission():
    current = int(Path('/sys/fs/cgroup/memory.current').read_text())
    need(current + OWNED_RSS_LIMIT + RESERVE < SHARED_LIMIT, 'Original shared30GiB/+1GiB reserve admission refused')
    return current

def regular(path): return path.is_file() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)

def relative(name):
    p = PurePosixPath(name)
    need(not p.is_absolute() and '..' not in p.parts, 'Archive path must stay inside owned tree')
    return Path(*p.parts)

def ar_data(blob):
    need(blob.startswith(b'!<arch>\n'), 'Official .deb ar container')
    at, result = 8, []
    while at < len(blob):
        header = blob[at:at+60]; need(len(header) == 60 and header[58:60] == b'`\n', 'Valid .deb member header')
        name = header[:16].decode('ascii').strip().rstrip('/')
        length = int(header[48:58].decode('ascii').strip()); at += 60
        member = blob[at:at+length]; need(len(member) == length, 'Complete .deb member')
        if name.startswith('data.tar'): result.append(member)
        at += length + length % 2
    need(len(result) == 1, 'Exactly one official data archive')
    return result[0]

def probe(out):
    need(out.is_absolute() and out.parent.resolve() == Path('/tmp') and out.name.startswith('g350-kicad10-proot-prereq-')
         and not out.exists(), 'Fresh /tmp/g350-kicad10-proot-prereq-* only')
    initial_memory = admission(); out.mkdir(mode=0o700)
    tools = out / 'tools'; tools.mkdir(mode=0o700)
    records = []
    report = {'scope': 'OFFICIAL_DEBIAN_PROOT_OWNED_TRUE_PREREQUISITE_PROBE_NOT_CAD', 'passed': False,
              'packages': records, 'memoryCurrentBefore': initial_memory, 'kicadExecuted': False,
              'packageInstalled': False, 'namespaceIsolationClaimed': False, 'networkIsolationClaimed': False,
              'all49Accepted': False, 'fabricationReady': False}
    try:
        for package in PACKAGES:
            request = urllib.request.Request(package['url'], headers={'User-Agent': 'g350-source-only-root-prerequisite/1'})
            with urllib.request.urlopen(request, timeout=20) as response:
                need(response.status == 200 and response.url == package['url'], 'Exact official Debian HTTPS package URL')
                blob = response.read(package['bytes'] + 1)
            need(len(blob) == package['bytes'] and sha(blob) == package['sha256'], 'Exact official Debian package size/SHA')
            path = out / Path(package['url']).name
            with path.open('xb') as f: f.write(blob); os.fchmod(f.fileno(), 0o600)
            with tarfile.open(fileobj=io.BytesIO(ar_data(blob)), mode='r:*') as archive:
                members = archive.getmembers()
                need(sum(m.size for m in members) < 2*1024**2 and all(m.isdir() or m.isfile() or m.issym() for m in members), 'Small data-only prerequisite archive')
                archive.extractall(tools, members=members, filter='data')
            records.append({**package, 'path': str(path)})
        executable = tools / 'usr/bin/proot'
        library = tools / 'usr/lib/x86_64-linux-gnu'
        need(regular(executable) and any(library.glob('libtalloc.so.2*')), 'Local executable and dependency extracted without install')
        scratch = out / 'scratch'; scratch.mkdir(mode=0o700)
        env = {'PATH': '/usr/bin:/bin', 'LD_LIBRARY_PATH': str(library), 'PROOT_NO_SECCOMP': '1',
               'TMPDIR': str(scratch), 'LC_ALL': 'C'}
        command = [str(executable), '-r', '/', '-w', '/', '/bin/true']
        # Inherit Root's owned process group: no detached tracer or child.
        process = subprocess.Popen(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            stdout, stderr = process.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill(); stdout, stderr = process.communicate()
            raise ValueError('Owned PRoot true probe exceeded10 seconds')
        report.update(command=command, exitCode=process.returncode, stdout=stdout.decode(errors='replace'), stderr=stderr.decode(errors='replace'),
                      toolsDirectory=str(tools), prootExecutable={'path': str(executable), 'sha256': file_sha(executable)},
                      prootLibraryDirectory=str(library), runtimeLibraries=[{'path': str(p),'bytes': p.stat().st_size,'sha256': file_sha(p)}
                          for p in sorted(library.rglob('*')) if regular(p)],
                      subprocessInheritsRootOwnedPgid=True, passed=process.returncode == 0)
        need(process.returncode == 0, 'PRoot must prove child tracing/path virtualization before any rootfs extraction')
    except Exception as exc:
        report['error'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        report['memoryCurrentAfter'] = int(Path('/sys/fs/cgroup/memory.current').read_text())
        fresh_json(out / 'PROBE.json', report)
    print(json.dumps({'report': str(out/'PROBE.json'), 'sha256': file_sha(out/'PROBE.json'), 'passed': report['passed'], 'kicadExecuted': False}))
    need(report['passed'], 'Prerequisite probe failed; preserved small owned diagnostics, no image extraction')

def prepare(out, probe_path, probe_sha):
    need(out.is_absolute() and out.parent.resolve() == BOARD/'.cloud-tools' and out.name.startswith('kicad10-single-rootfs-')
         and not out.exists(), 'Fresh owned .cloud-tools/kicad10-single-rootfs-* only')
    need(regular(probe_path) and file_sha(probe_path) == probe_sha, 'Explicit successful probe SHA')
    proof = json.loads(probe_path.read_text())
    need(proof['scope'] == 'OFFICIAL_DEBIAN_PROOT_OWNED_TRUE_PREREQUISITE_PROBE_NOT_CAD' and proof['passed'] is True
         and proof['exitCode'] == 0 and proof['kicadExecuted'] is False, 'Successful actual plain-utility prerequisite')
    for package, pin in zip(proof['packages'], PACKAGES):
        need(all(package[k] == pin[k] for k in ('name','url','bytes','sha256')) and file_sha(Path(package['path'])) == pin['sha256'], 'Exact retained official tools')
    need(len(proof['packages']) == 2 and file_sha(Path(proof['prootExecutable']['path'])) == proof['prootExecutable']['sha256'], 'Exact prerequisite tools remain')
    need(len(proof['runtimeLibraries']) >= 1 and all(regular(Path(r['path'])) and Path(r['path']).stat().st_size == r['bytes']
         and file_sha(Path(r['path'])) == r['sha256'] for r in proof['runtimeLibraries']), 'Every extracted runtime library remains exact')
    memory_before = admission()
    need(regular(IMAGE) and IMAGE.stat().st_size == 1536684032 and file_sha(IMAGE) == IMAGE_SHA, 'Existing frozen official KiCad10 image archive')
    free = shutil.disk_usage(out.parent).free
    need(free >= LAYER_BYTES + 256*1024**2, 'Single rootfs disk space plus unchanged256MiB reserve')
    out.mkdir(mode=0o700); rootfs = out/'rootfs'; rootfs.mkdir(mode=0o700)
    started = time.monotonic(); pending_links, entries, total, skipped = [], [], 0, []
    report = {'scope': 'EXACT_KICAD10_IMAGE_SINGLE_COPY_PROOT_ROOTFS_PREPARATION_NOT_CAD', 'complete': False,
              'rootfs': str(rootfs), 'imageArchive': {'path': str(IMAGE),'sha256': IMAGE_SHA}, 'layer': LAYER,
              'probe': {'path': str(probe_path),'sha256': probe_sha}, 'memoryCurrentBefore': memory_before,
              'workspaceFreeBefore': free, 'rootfsOnTmpfs': False, 'kicadExecuted': False, 'dockerExecuted': False,
              'imageArchiveModified': False, 'frozenEvidenceModified': False, 'all49Accepted': False,'fabricationReady': False}
    try:
        with tarfile.open(IMAGE, mode='r:') as outer:
            manifest = json.load(outer.extractfile('manifest.json'))
            need(len(manifest) == 1 and manifest[0]['Config'] == CONFIG and manifest[0]['Layers'] == [LAYER]
                 and manifest[0]['RepoTags'] == ['g350-kicad-debian:10.0.6'] and outer.getmember(LAYER).size == LAYER_BYTES, 'Exact single imported image layer')
            layer_file = outer.extractfile(LAYER)
            class HashReader:
                def __init__(self, file): self.file, self.h, self.count = file, hashlib.sha256(), 0
                def read(self, length=-1):
                    blob = self.file.read(length); self.h.update(blob); self.count += len(blob); return blob
            stream = HashReader(layer_file)
            with tarfile.open(fileobj=stream, mode='r|') as layer:
                for item in layer:
                    need(time.monotonic()-started < 160, 'Single rootfs preparation160-second budget')
                    relative_path = relative(item.name)
                    if not relative_path.parts: continue
                    need(not any(p.startswith('.wh.') for p in relative_path.parts), 'Single imported rootfs must not need whiteout semantics')
                    path = rootfs / relative_path
                    need(path.parent.resolve().is_relative_to(rootfs), 'No link traversal during extraction')
                    if item.isdir():
                        path.mkdir(parents=True, exist_ok=True)
                    elif item.isfile():
                        path.parent.mkdir(parents=True, exist_ok=True)
                        data = layer.extractfile(item); h = hashlib.sha256(); count = 0
                        with path.open('xb') as target:
                            while blob := data.read(1048576): target.write(blob); h.update(blob); count += len(blob)
                            os.fchmod(target.fileno(), item.mode & 0o777)
                        need(count == item.size, 'Complete rootfs file')
                        total += count
                        need(total <= LAYER_BYTES and shutil.disk_usage(out.parent).free >= 256*1024**2, 'Single-copy byte bound and disk reserve')
                        entries.append({'path': relative_path.as_posix(),'bytes': count,'sha256': h.hexdigest(),'mode': item.mode & 0o777})
                    elif item.issym() or item.islnk(): pending_links.append((relative_path, item.linkname, item.issym()))
                    elif item.ischr() or item.isblk() or item.isfifo(): skipped.append({'path': relative_path.as_posix(),'type': repr(item.type)})
                    else: raise ValueError('Unsupported rootfs member '+item.name)
            # Consume padding too: the pinned OCI diff_id hashes the whole tar layer.
            while stream.read(1048576): pass
            need(stream.count == LAYER_BYTES and stream.h.hexdigest() == LAYER.rsplit('/',1)[1], 'Exact streamed image diff_id')
        for path, target, symbolic in pending_links:
            if symbolic: continue
            source = rootfs/relative(target); destination = rootfs/path
            need(regular(source) and destination.parent.resolve().is_relative_to(rootfs), 'Contained regular hardlink target')
            destination.parent.mkdir(parents=True, exist_ok=True); os.link(source, destination)
        # Install symbolic links only after files/hardlinks: absolute guest links
        # can never redirect an extraction write into the host filesystem.
        for path, target, symbolic in sorted(pending_links, key=lambda e: len(e[0].parts), reverse=True):
            if not symbolic: continue
            destination = rootfs/path
            need(destination.parent.resolve().is_relative_to(rootfs), 'Contained symlink parent')
            destination.parent.mkdir(parents=True, exist_ok=True); os.symlink(target, destination)
        need(shutil.disk_usage(out.parent).free >= 256*1024**2, 'Disk reserve still held after directories and links')
        need(file_sha(IMAGE) == IMAGE_SHA and file_sha(probe_path) == probe_sha, 'Frozen archive and probe unchanged')
        report.update(complete=True, extractedRegularBytes=total, regularFiles=len(entries), linkCount=len(pending_links),
                      specialDeviceMembersNotCreated=skipped, entries=entries, links=[{'path':p.as_posix(),'target':t,'symbolic':s} for p,t,s in pending_links],
                      prootExecutable=proof['prootExecutable'], prootLibraryDirectory=proof['prootLibraryDirectory'],
                      runtimeLibraries=proof['runtimeLibraries'],
                      rootfsPrivilegesNormalizedToCurrentUid=True, setIdModeBitsNotEnabled=True)
    except Exception as exc:
        report['error'] = {'type': type(exc).__name__,'message': str(exc)}
    finally:
        report['elapsedSeconds'] = time.monotonic()-started
        report['workspaceFreeAfter'] = shutil.disk_usage(out.parent).free
        fresh_json(out/'ROOTFS.json', report)
    print(json.dumps({'report':str(out/'ROOTFS.json'),'sha256':file_sha(out/'ROOTFS.json'),'complete':report['complete'],'kicadExecuted':False}))
    need(report['complete'], 'Single-copy extraction failed; only its new owned directory retained')

def main():
    ap = argparse.ArgumentParser(description=__doc__); sub = ap.add_subparsers(dest='action',required=True)
    p = sub.add_parser('probe'); p.add_argument('--output-dir',type=Path,required=True)
    p = sub.add_parser('prepare'); p.add_argument('--rootfs-dir',type=Path,required=True); p.add_argument('--probe-report',type=Path,required=True); p.add_argument('--probe-report-sha',required=True)
    args = ap.parse_args()
    if args.action == 'probe': probe(args.output_dir)
    else: prepare(args.rootfs_dir,args.probe_report,args.probe_report_sha)

if __name__ == '__main__': main()
