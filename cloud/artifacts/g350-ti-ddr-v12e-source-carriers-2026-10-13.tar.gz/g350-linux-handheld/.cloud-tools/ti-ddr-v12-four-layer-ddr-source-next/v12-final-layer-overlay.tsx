import {Children, cloneElement, isValidElement, type ReactElement, type ReactNode} from "react"
import {buildV11Source} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v11-ca-byte1-top-layer-bridge-next/v11-final-layer-overlay"
import policy from "./v12-layer-policy.json"

type Props = Record<string, unknown> & {name?: string; children?: ReactNode}
const equal = (a: unknown, b: unknown, label: string) => {
  if (JSON.stringify(a) !== JSON.stringify(b)) throw Error("V12 final authored props mismatch: " + label)
}
/** V12 source-only four-signal-layer policy. No Circuit/Core/render/router call.
 * Geometry, original 2 real reference stubs/vias and existing copper candidates
 * stay intact. Those candidates are NOT qualified continuous references for
 * all-four-layer DDR; regional return/PDN/impedance redesign remains required. */
export function buildV12Source() {
  const base = buildV11Source()
  const groups = new Map<string, Record<string, unknown>>()
  const pairs = new Map<string, Record<string, unknown>>()
  let boardCount = 0
  const referenceCopperCandidates: Array<Record<string, unknown>> = []
  function apply(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const p = {...node.props}
    const group = policy.groups.find(g => g.nativeBus.busId === p.name)
    const pair = policy.pairs.find(g => g.name === p.name)
    if (group) {
      const spec = group.nativeBus
      if (node.type !== "bus" || groups.has(spec.busId)) throw Error("Exactly four literal original class buses required")
      const before = base.authoredPolicyProof.groups.find(g => g.busId === spec.busId)
      if (!before) throw Error("Missing original V11 final group proof")
      const original: Record<string, unknown> = {busId: spec.busId, connections: p.connections,
        pcbTraceWidth: p.pcbTraceWidth, pcbAllowedLayers: p.pcbAllowedLayers, preferredLayers: p.preferredLayers}
      for (const key of ["maxLengthSkew", "minLength", "maxLength"] as const)
        if (p[key] !== undefined) original[key] = p[key]
      equal(original, before, spec.busId + " original V11 final props")
      p.pcbAllowedLayers = [...spec.allowedLayers]
      p.preferredLayers = [...spec.preferredLayers]
      equal(p.connections, group.logicalConnections, spec.busId + " roster")
      equal(p.pcbAllowedLayers, spec.allowedLayers, spec.busId + " allowed")
      equal(p.preferredLayers, spec.preferredLayers, spec.busId + " preferred")
      equal(p.pcbTraceWidth, spec.traceWidth, spec.busId + " width")
      for (const key of ["maxLengthSkew", "minLength", "maxLength"] as const)
        equal(p[key], (spec as Record<string, unknown>)[key], spec.busId + " " + key)
      groups.set(spec.busId, {...original, pcbAllowedLayers: p.pcbAllowedLayers, preferredLayers: p.preferredLayers})
    }
    if (pair) {
      if (node.type !== "differentialpair" || pairs.has(pair.name)) throw Error("Exactly three original literal pairs required")
      equal([p.positiveConnection, p.negativeConnection], pair.logicalConnections, pair.name + " partners")
      equal(p.maxLengthSkew, pair.nativePair.lengthTolerance, pair.name + " skew")
      equal(p.pcbTraceGap, pair.nativePair.traceGap, pair.name + " gap")
      const snapshot = {name: pair.name, ownerBusId: pair.ownerBusId,
        positiveConnection: p.positiveConnection, negativeConnection: p.negativeConnection,
        maxLengthSkew: p.maxLengthSkew, pcbTraceGap: p.pcbTraceGap}
      equal(snapshot, base.authoredPolicyProof.pairs.find(g => g.name === pair.name), pair.name + " V11 proof")
      pairs.set(pair.name, snapshot)
    }
    if (node.type === "copperpour") {
      if (!["G350_TI_V2_INNER1_GND", "G350_TI_V2_INNER2_DDR_1V5"].includes(p.name ?? ""))
        throw Error("Unexpected reference copper source")
      const snapshot: Record<string, unknown> = {}
      for (const key of ["name", "layer", "connectsTo", "clearance", "boardEdgeMargin", "cutoutMargin", "useThermalReliefs", "outline"])
        if (p[key] !== undefined) snapshot[key] = p[key]
      referenceCopperCandidates.push(snapshot)
    }
    if (node.type === "board") {
      boardCount++
      equal(p.layers, 4, "physical layers")
      equal(p.routeRemaining, false, "routing-disabled source")
    }
    return cloneElement(node as ReactElement<Props>, p, ...Children.toArray(node.props.children).map(apply))
  }
  const element = apply(base.element)
  if (groups.size !== 4 || pairs.size !== 3 || boardCount !== 1 || referenceCopperCandidates.length !== 2) throw Error("Original four classes, three pairs and one board required")
  return {element, authoredPolicyProof: {...base.authoredPolicyProof,
    groups: policy.groups.map(g => groups.get(g.nativeBus.busId)!), pairs: policy.pairs.map(g => pairs.get(g.name)!)},
    referenceCopperCandidates, referenceQualified: false, TIplaneArrangement: false,
    globalSignalLayerProjection: [...policy.globalSignalLayers], naturallyDerivedGenericDefaultCap: 800000}
}
export default () => buildV12Source().element
