import fs from "node:fs"
import crypto from "node:crypto"
import assert from "node:assert/strict"
import type { SimpleRouteJson, Trace } from "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/types"
const [manifestPath,manifestSha,authorityPath,authoritySha,nativePath,outputPath,...extra]=process.argv.slice(2)
assert.ok(manifestPath&&manifestSha&&authorityPath&&authoritySha&&nativePath&&outputPath&&!extra.length&&!fs.existsSync(outputPath))
assert.equal(process.env.G350_RESET_SOURCE3_26_FRESH_NATIVE_APPROVED,"1");assert.equal(process.versions.bun,"1.3.14")
const digest=(b:Buffer)=>crypto.createHash("sha256").update(b).digest("hex")
const load=(p:string,h?:string)=>{const b=fs.readFileSync(p);if(h)assert.equal(digest(b),h);return JSON.parse(b.toString())}
try {
const manifest=load(manifestPath,manifestSha),authority=load(authorityPath,authoritySha)
const FUTURE_SOURCE26_CORE_SOURCE_SHA:string|null=null,FUTURE_SOURCE26_PROPOSAL_SHA:string|null=null
const validSha=(v:unknown):v is string=>typeof v==="string"&&/^[0-9a-f]{64}$/.test(v)
assert(validSha(FUTURE_SOURCE26_CORE_SOURCE_SHA),"Root must bind the genuine promoted Source26 source manifest")
assert(validSha(FUTURE_SOURCE26_PROPOSAL_SHA),"Root must bind the genuine promoted Source26 proposal")
assert.equal(manifest.genuineSource26ManifestSha256,FUTURE_SOURCE26_CORE_SOURCE_SHA)
assert.equal(manifest.source26ProposalSha256,FUTURE_SOURCE26_PROPOSAL_SHA)
assert.equal(authority.authorizedByRoot,true);assert.equal(authority.packetSha256,manifestSha);assert.equal(authority.scope,manifest.scope)
for(const row of [...manifest.files,...manifest.externalFiles]){const st=fs.lstatSync(row.path);assert(st.isFile()&&!st.isSymbolicLink());const b=fs.readFileSync(row.path);assert.equal(b.length,row.bytes);assert.equal(st.mode&0o777,row.mode);assert.equal(digest(b),row.sha256)}
const artifacts=manifest.actualFreshArtifacts;assert.deepEqual(authority.freshArtifacts,artifacts)
assert.equal(typeof artifacts.actualCorePath,"string");assert.equal(typeof artifacts.actualCoreSha256,"string");
const raw=fs.readFileSync(artifacts.actualCorePath);assert.equal(digest(raw),artifacts.actualCoreSha256)
const core=JSON.parse(raw.toString()) as Array<Record<string,any>>,native=load(nativePath)
// Native was collected in a prior Root scope; its packet is bound separately.
assert.equal(nativePath,manifest.actualNativeReportPath)
assert.equal(digest(fs.readFileSync(nativePath)),manifest.actualNativeReportSha256)
assert.equal(native.packetSha256,manifest.nativeQualificationPacketSha256)
assert.equal(native.actualCoreSha256,artifacts.actualCoreSha256)
assert.equal(native.checkCount,18);assert.equal(native.physicalErrors,0);assert.equal(native.physicalCpuRamConnectedCarrierCount,26);assert.equal(native.actualNativePairFindings.length,0)
// Source26 physical material and all endpoint IDs must be freshly projected AFTER
// its Native ownership proof. An old631/B262 file is never an accepted binding.
for(const key of ["authorized49InputPath","authorized49InputSha256","fresh49ProjectionProofPath","fresh49ProjectionProofSha256","source26ProposalPath","source26ProposalSha256"])assert.equal(typeof manifest[key],"string",`Future binding absent: ${key}`)
const input=load(manifest.authorized49InputPath,manifest.authorized49InputSha256) as SimpleRouteJson
const projectionProof=load(manifest.fresh49ProjectionProofPath,manifest.fresh49ProjectionProofSha256)
assert.equal(projectionProof.actualCoreSha256,artifacts.actualCoreSha256)
assert.equal(projectionProof.actualNativeReportSha256,digest(fs.readFileSync(nativePath)))
assert.equal(projectionProof.constructorInputSha256,manifest.authorized49InputSha256)
assert.equal(projectionProof.sourceManifestSha256,manifest.genuineSource26ManifestSha256)
assert.equal(projectionProof.originalSource26ProposalSha256,manifest.source26ProposalSha256)
const proposal=load(manifest.source26ProposalPath,manifest.source26ProposalSha256)
const static26={records:proposal.selected26NormalizedRecords}
assert.equal(static26.records.length,26)
const updatedPairs={candidates:Object.fromEntries(proposal.selected26OriginalCarriers.filter((c:Record<string,any>)=>["source_trace_15","source_trace_16","source_trace_27","source_trace_28","source_trace_33","source_trace_34"].includes(c.originalSourceTraceId)).map((c:Record<string,any>)=>[c.originalSourceTraceId,{layer:c.carrierLayer,path:c.expectedCarrierPath,coupledSection:c.coupledSection}]))}
assert.deepEqual(Object.keys(updatedPairs.candidates).sort(),["source_trace_15","source_trace_16","source_trace_27","source_trace_28","source_trace_33","source_trace_34"].sort())
assert.equal(input.connections.length,49);assert.equal(input.traces!.length,263);assert.equal(input.obstacles.length,1298);assert.equal(input.layerCount,4)
assert.equal(input.differentialPairs!.length,3);assert(input.differentialPairs!.every(p=>p.lengthTolerance===.127&&p.traceGap===.12))
assert.equal(core.filter(r=>r.type==="pcb_via").length,227);assert.equal(core.filter(r=>r.type==="pcb_trace").length,289)
assert.equal(core.filter(r=>r.type==="pcb_port").length,1655)
assert.equal(input.traces!.flatMap(t=>t.route).filter(p=>p.route_type==="via").length,98)
const ram14map=native.actualOwnershipProof.signalMappings.find((m:Record<string,any>)=>m.originalSourceTraceId==="source_trace_14"&&m.side===1)
assert(ram14map)
const ram14via=core.find(r=>r.type==="pcb_via"&&r.pcb_via_id===ram14map.actualViaId)!
assert(ram14via&&Math.hypot(ram14via.x-2.4,ram14via.y-12)<1e-9)
const ram14request=input.connections.find(c=>c.name==="source_trace_14")!.pointsToConnect[1]
assert(Math.hypot(ram14request.x-ram14via.x,ram14request.y-ram14via.y)<1e-9,"Fresh49 must include actual relocated barrel")
// Fresh moved CPU3 barrel and its complete four-wire stub must be present in
// this fresh49 material; the later selected-layer view must not hide stale input.
const cpu3map=native.actualOwnershipProof.signalMappings.find((m:Record<string,any>)=>m.originalSourceTraceId==="source_trace_3"&&m.side===0)
assert(cpu3map)
const cpu3via=core.find(r=>r.type==="pcb_via"&&r.pcb_via_id===cpu3map.actualViaId)!
assert(cpu3via&&Math.hypot(cpu3via.x-6.2,cpu3via.y-12.4)<1e-9)
const cpu3request=input.connections.find(c=>c.name==="source_trace_3")!.pointsToConnect[0]
assert(Math.hypot(cpu3request.x-cpu3via.x,cpu3request.y-cpu3via.y)<1e-9)
const cpu3raw=core.find(r=>r.type==="pcb_trace"&&r.pcb_trace_id===cpu3map.actualPcbTraceId)!
const cpu3fixed=input.traces!.find(t=>t.pcb_trace_id===cpu3map.actualPcbTraceId)!
assert(cpu3raw&&cpu3raw.route.length===4&&cpu3fixed&&cpu3fixed.route.length===6)
const cpu3canonical=cpu3raw.route[0].start_pcb_port_id===cpu3map.actualNumericPcbPortId?cpu3raw.route:[...cpu3raw.route].reverse()
assert(cpu3fixed.route.slice(0,4).every((p,i)=>p.route_type==="wire"&&p.layer==="top"&&p.width===.1016&&Math.hypot(p.x-cpu3canonical[i].x,p.y-cpu3canonical[i].y)<1e-9))
const cpu3event=cpu3fixed.route[4] as Trace["route"][number]&{pcb_via_id?:string}
const cpu3tail=cpu3fixed.route[5] as Trace["route"][number]&{pcb_port_id?:string}
assert(cpu3event.route_type==="via"&&cpu3event.pcb_via_id===cpu3via.pcb_via_id&&cpu3tail.route_type==="wire"&&cpu3tail.layer==="bottom"&&cpu3tail.pcb_port_id===cpu3map.actualBottomPcbPortId)
const signature=JSON.stringify(core),bindings=native.actualOwnershipProof.carriers
assert.equal(bindings.length,26)
const projections:Array<Record<string,any>>=[]
const traces:Trace[]=bindings.map((binding:Record<string,any>)=>{
 const direct=core.filter(r=>r.type==="pcb_trace"&&r.source_trace_id===binding.originalSourceTraceId)
 assert.equal(direct.length,3);assert.deepEqual(direct.map(t=>t.pcb_trace_id),binding.actualDirectPcbTraceIds)
 const body=direct.find(t=>t.pcb_trace_id===binding.actualCarrierPcbTraceId)!
 assert(body&&body.route.every((p:Record<string,any>)=>p.route_type==="wire"&&p.layer===binding.carrierLayer&&p.width===.1016))
 const record=static26.records.find((r:Record<string,any>)=>r.sourceTraceId===binding.originalSourceTraceId)!
 assert(record&&record.layer===binding.carrierLayer&&record.path.length===body.route.length)
 const delta=Math.max(...record.path.map((p:Record<string,any>,i:number)=>Math.hypot(p.x-body.route[i].x,p.y-body.route[i].y)))
 assert(delta<1e-9)
 let coupledSection=record.coupledSection
 const pair=updatedPairs.candidates[binding.originalSourceTraceId]
 if(pair){
  assert.equal(pair.layer,binding.carrierLayer);assert.equal(pair.path.length,body.route.length)
  assert(pair.path.every((p:Record<string,any>,i:number)=>Math.hypot(p.x-body.route[i].x,p.y-body.route[i].y)<1e-9),"Coupled-section evidence must cover the complete authentic NEW physical carrier")
  coupledSection=pair.coupledSection
  assert(Array.isArray(coupledSection)&&coupledSection.length===2&&coupledSection.every(Number.isInteger)&&coupledSection[0]>=0&&coupledSection[0]<coupledSection[1]&&coupledSection[1]<body.route.length)
 }
 projections.push({originalSourceTraceId:binding.originalSourceTraceId,actualCarrierPcbTraceId:body.pcb_trace_id,actualDirectPcbTraceIds:binding.actualDirectPcbTraceIds,maximumCoordinateDeltaMm:delta,carrierLayer:binding.carrierLayer,coupledSection:coupledSection??null})
 return {...body,connection_name:binding.originalSourceTraceId,coupledSection} as Trace
})
// Geometry view names remain original49. Only endpoint layer/ID anchors for the
// actually completed26 are derived from their genuine fresh physical aliases.
const byName=new Map(bindings.map((b:Record<string,any>)=>[b.originalSourceTraceId,b]))
const apiInput:SimpleRouteJson={...input,connections:input.connections.map(c=>{
 const b=byName.get(c.name) as Record<string,any>|undefined;if(!b)return c
 const ids=[b.actualCpuCarrierLayerPcbPortId,b.actualRamCarrierLayerPcbPortId]
 return {...c,pointsToConnect:c.pointsToConnect.map((p,i)=>{
  const actualPort=core.find(r=>r.type==="pcb_port"&&r.pcb_port_id===ids[i])!
  assert(actualPort&&actualPort.layers.includes(b.carrierLayer),"Authentic physical carrier alias required")
  return {...p,x:actualPort.x,y:actualPort.y,layer:b.carrierLayer,pointId:actualPort.pcb_port_id,pcb_port_id:actualPort.pcb_port_id}
 })}
})}
const dataSignature=JSON.stringify({input,apiInput,static26,updatedPairs,traces})
// Load unchanged private implementations only after all actual Root/data bindings pass.
const {VectorScene, routeCopper, fixedCopper}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/vector-scene")
const {tuningPathIsSelfClear}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/length-tuning")
const {sharedPairSpacingReports}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/shared-pair-spacing")
const {exteriorPairSpacingReports}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/exterior-pair-spacing")
const {pairCouplingReports}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/pair-coupling")
const {pairLengthReports, busLengthReports, fixedRouteLength}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/route-lengths")
const {routeAnglesAreConventional}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/route-angle-validation")
const fixed=fixedCopper(apiInput)
const continuity=traces.map(t=>{
 const c=apiInput.connections.find(c=>c.name===t.connection_name)!,b=byName.get(t.connection_name!) as Record<string,any>
 assert(c&&b.actualSourceOwnedPhysicalGraph.physicallyConnected)
 assert(Math.hypot(t.route[0].x-c.pointsToConnect[0].x,t.route[0].y-c.pointsToConnect[0].y)<1e-9)
 assert(Math.hypot(t.route.at(-1)!.x-c.pointsToConnect[1].x,t.route.at(-1)!.y-c.pointsToConnect[1].y)<1e-9)
 const others=traces.filter(other=>other!==t).flatMap(routeCopper)
 const scene=new VectorScene(apiInput,c,.1016,[...fixed,...others])
 return {connectionName:t.connection_name,actualCarrierPcbTraceId:t.pcb_trace_id,pathVisible:scene.pathVisible(t.route),segmentsVisible:t.route.slice(1).map((p,i)=>scene.visible(t.route[i],p)),selfClear:tuningPathIsSelfClear(t.route,.2032),conventionalAngles:routeAnglesAreConventional([t]),fixedPlanarLength:fixedRouteLength(apiInput,t.connection_name!),foreignActual26AndOriginalFixedCopperIncluded:true}
})
const shared=sharedPairSpacingReports(apiInput,traces),exterior=exteriorPairSpacingReports(apiInput,traces),coupling=pairCouplingReports(apiInput,traces),pairLengths=pairLengthReports(apiInput,traces)
assert.equal(shared.length,3);assert.equal(exterior.length,3);assert.equal(coupling.length,3);assert.equal(pairLengths.length,3)
// The pinned Trace type supports one contiguous coupledSection. Both real
// shared meanders are evaluated; geometry stays identical between metadata views.
const primaryName=proposal.primaryCoupledSectionView,secondaryName=proposal.secondaryCoupledSectionView
assert.equal(primaryName,"lower_coupled_U");assert.equal(secondaryName,"early_reflected_meander")
assert.equal(proposal.singleCoupledSectionCoversBoth,false)
assert.equal(proposal.bothActualSharedMeandersMustBeChecked,true)
const views=proposal.dqs1CouplingViews
assert.equal(views.length,2)
const secondaryView=views.find((v:Record<string,any>)=>v.name===secondaryName)!
assert(secondaryView)
const secondaryTraces:Trace[]=traces.map(t=>{
 const range=secondaryView.ranges[t.connection_name!]
 if(!range)return t
 assert(["source_trace_27","source_trace_28"].includes(t.connection_name!))
 assert(Array.isArray(range)&&range.length===2&&range.every(Number.isInteger)&&range[0]>=0&&range[0]<range[1]&&range[1]<t.route.length)
 return {...t,coupledSection:[...range] as [number,number]}
})
const strip=(t:Trace)=>{const {coupledSection,...rest}=t;return rest}
assert.deepEqual(secondaryTraces.map(strip),traces.map(strip),"Metadata view cannot alter copper or endpoints")
const dqs1Pairs=apiInput.differentialPairs!.filter(p=>p.connectionNames.includes("source_trace_27")&&p.connectionNames.includes("source_trace_28"))
assert.equal(dqs1Pairs.length,1)
const secondaryInput={...apiInput,differentialPairs:dqs1Pairs}
const secondarySignature=JSON.stringify({secondaryInput,secondaryTraces})
const secondaryShared=sharedPairSpacingReports(secondaryInput,secondaryTraces),secondaryExterior=exteriorPairSpacingReports(secondaryInput,secondaryTraces),secondaryCoupling=pairCouplingReports(secondaryInput,secondaryTraces)
assert.equal(secondaryShared.length,1);assert.equal(secondaryExterior.length,1);assert.equal(secondaryCoupling.length,1)
const secondViewPassed=secondaryShared.every(r=>r.matched)&&secondaryExterior.every(r=>r.matched)&&secondaryCoupling.every(r=>r.matched)
const originalAll49BusReports=busLengthReports(apiInput,traces)
const completedNames=new Set(traces.map(t=>t.connection_name))
const cohortViews=apiInput.buses!.filter(b=>b.busId!=="DDR_RESET").map(b=>({...b,connectionNames:b.connectionNames.filter(n=>completedNames.has(n))}))
const loadedCohortBusReports=busLengthReports({...apiInput,buses:cohortViews},traces)
const byte0=loadedCohortBusReports.find(b=>b.busId==="DDR_BYTE0")!
assert.equal(byte0.lengths.length,6)
const byte1=loadedCohortBusReports.find(b=>b.busId==="DDR_BYTE1")!
assert.equal(byte1.lengths.length,11)
const held=signature===JSON.stringify(core)&&dataSignature===JSON.stringify({input,apiInput,static26,updatedPairs,traces})&&secondarySignature===JSON.stringify({secondaryInput,secondaryTraces})
const report={scope:"ACTUAL_MOVED26_FRESH_CORE_ALL3_UNCHANGED_ORIGINAL_PRIVATE_API_DIAGNOSTIC",packetSha256:manifestSha,actualCorePath:artifacts.actualCorePath,actualCoreSha256:artifacts.actualCoreSha256,actualNativeReportPath:nativePath,actualNativeReportSha256:digest(fs.readFileSync(nativePath)),actualCarrierProjections:projections,updatedAuthenticPairEvidence:{path:manifest.source26ProposalPath,sha256:manifest.source26ProposalSha256,field:"selected26OriginalCarriers[].coupledSection",bothRealDqs1CoupledViews:views},stale21316IndicesOr068fSource28GeometryUsed:false,actualNumericPhysicalGraphsRequired:true,actualClockGeometryUsed:true,originalPrivateContinuousApiImplementationsUnchanged:true,automaticCoreSrjUsed:false,original49Input:{path:manifest.authorized49InputPath,sha256:manifest.authorized49InputSha256},completeHardwareSignalsRequested:49,actualCompleteOriginalSignalCount:26,expectedMissingOriginalSignalCount:23,fresh49ProjectionProof:{path:manifest.fresh49ProjectionProofPath,sha256:manifest.fresh49ProjectionProofSha256,actualCoreSha256:projectionProof.actualCoreSha256},fullOriginalBusRostersAndConstraintsHeld:true,originalFullDifferentialPairArrayUnchanged:true,all3DifferentialPairsInvokedAgainstFreshCopper:true,actualLayerAndEndpointIdViewDerivedFromFreshPhysicalOwnedAliases:true,rawCoreOrAuthoritativeInputRetagged:false,exactMaterialHeld:held,continuity,shared,exterior,coupling,pairLengths,secondaryDqs1View:{name:secondaryName,geometryAndEndpointsUnchanged:true,shared:secondaryShared,exterior:secondaryExterior,coupling:secondaryCoupling,passed:secondViewPassed},checkInventory:{continuityRows:26,primaryBooleanPredicates:26*4+3*4,secondaryDqs1BooleanPredicates:3,primaryPlusSecondaryBooleanPredicates:26*4+3*4+3,loadedCohortBusGatesAdditional:3,immutableDataGateAdditional:1},originalAll49BusReports,loadedCohortBusReports,loadedCohortViews:cohortViews,loadedCohortsExplicitlyPartial:{DDR_BYTE0:6,DDR_BYTE1:11,DDR_COMMAND_CLOCK:8},onlyByte1FullElevenPresent:true,originalFullByte0AndCaStillIncomplete:true,nativeManufacturingCheckerExecuted:false,coreRenderedByThisWorker:false,freshCadExecuted:false,originalGridOrPublicSolverExecuted:false,fullCohortTimingPassed:false,electricalDelayModelQualified:false,referenceQualified:false,complete26Accepted:false,accepted49:false,fabricationReady:false,allOriginalApiLoaded26ChecksPassed:held&&secondViewPassed&&continuity.every(r=>r.pathVisible&&r.segmentsVisible.every(Boolean)&&r.selfClear&&r.conventionalAngles)&&shared.every(r=>r.matched)&&exterior.every(r=>r.matched)&&coupling.every(r=>r.matched)&&pairLengths.every(r=>r.matched)&&loadedCohortBusReports.every(r=>r.aboveMinimumLength&&r.withinLengthLimit&&r.matched)}
fs.writeFileSync(outputPath,`${JSON.stringify(report,null,2)}\n`,{flag:"wx",mode:0o600})
assert.equal(report.allOriginalApiLoaded26ChecksPassed,true,"Complete actual diagnostics retained before assertion; never relax a failed original API")
console.log(JSON.stringify({scope:report.scope,allOriginalApiLoaded26ChecksPassed:true,expectedMissingOriginalSignalCount:23,accepted49:false,outputPath}))

} catch(error) {
 if(!fs.existsSync(outputPath))fs.writeFileSync(outputPath,JSON.stringify({scope:"UNRESOLVED_MOVED26_ORIGINAL_API_PRECONDITION_OR_PROJECTION",passed:false,failure:String(error),actualRawCoreOrInputEdited:false,rawAndFailureDiagnosticPreserved:true,accepted49:false,referenceQualified:false,electricalTimingQualified:false,fabricationReady:false},null,2)+"\n",{flag:"wx",mode:0o600})
 throw error
}
