"""Prepare immutable Source/Core source delta, never import applications."""
import json,copy,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent;BASE=HERE.parent/'ddr-strict18-manual-source-integration-sourceonly-next';CORE=HERE.parent/'ddr-strict18-manual-core-owned-alias-successor-next';GEOMETRY=HERE.parent/'ddr-strict18-corner-smoothing-sourceonly-next'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def binding(p):return {'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777}
assert digest(BASE/'SOURCE-manifest.json')=='be1969ab1a99af7e823213c44166505eaf765048e6809fcd5f2fbd6aea5bd15e'
assert digest(CORE/'SOURCE-manifest.json')=='6c4bf7ee94347c8cb21307b22d6ef231e136589a77752f0702f34fa8d3ab2c4d'
assert digest(GEOMETRY/'SOURCE-manifest.json')=='bf3fb7e0920981893f3cdb1ec063869f0da79314c32a2a98c7ed6c081a0b7519'
proposal=json.loads((BASE/'strict18-source-proposal.json').read_bytes());old=copy.deepcopy(proposal);data=json.loads((GEOMETRY/'NORMALIZED_STRICT18_THREE_CORNER_SMOOTHING_LENGTH_RESTORED.json').read_bytes());records={r['sourceTraceId']:r for r in data['records']};changed={'source_trace_15','source_trace_16','source_trace_28'}
for row in proposal['newOriginalSignalChanges']:
 n=row['originalSourceTraceId']
 if n not in changed:continue
 path=records[n]['path'];origin=row['cpu']['viaXY'];assert records[n]['layer']==row['carrierLayer']
 row['newPcbPaths'][1]=[row['newPcbPaths'][1][0]]+[{'x':p['x']-origin['x'],'y':p['y']-origin['y'],'layer':row['carrierLayer']}for p in path[1:-1]]+[row['newPcbPaths'][1][-1]]
 row['originalStaticCarrierPath']=copy.deepcopy(path)
 row['expectedCarrierPhysicalRoute']=[{'route_type':'wire',**p,'layer':row['carrierLayer'],'width':.1016}for p in path]
 row['physicalCarrierCoupledSection']=records[n]['coupledSection']
for n in changed:
 before=next(r for r in old['newOriginalSignalChanges']if r['originalSourceTraceId']==n);after=next(r for r in proposal['newOriginalSignalChanges']if r['originalSourceTraceId']==n)
 restored=copy.deepcopy(after)
 for key in ['newPcbPaths','originalStaticCarrierPath','expectedCarrierPhysicalRoute']:restored[key]=before[key]
 del restored['physicalCarrierCoupledSection'];assert restored==before
assert all(a==b for a,b in zip(old['newOriginalSignalChanges'],proposal['newOriginalSignalChanges'])if a['originalSourceTraceId']not in changed)
proposal['inputBindings']['static18']=binding(GEOMETRY/'NORMALIZED_STRICT18_THREE_CORNER_SMOOTHING_LENGTH_RESTORED.json');proposal['inputBindings']['static18Report']=binding(GEOMETRY/'THREE_CORNER_SMOOTHING_STATIC_REPORT.json')
for key,path in {'smoothingGeometryManifest':GEOMETRY/'SOURCE-manifest.json','updatedPairSections':GEOMETRY/'UPDATED_AUTHENTIC_PAIR_SECTIONS.json','smoothingPairControls':GEOMETRY/'PAIR_SECTION_CONTROLS.json','priorStrict18Proposal':BASE/'strict18-source-proposal.json','priorStrict18SourceManifest':BASE/'SOURCE-manifest.json','priorStrict18Capture':BASE/'run-capture/source-capture.json','priorStrict18CaptureCollection':Path('/workspace/bus-lanes-solver/.cache/root-routing-progress/strict18-source-capture-86442-COLLECTED-root.json'),'priorStrict18CoreManifest':CORE/'SOURCE-manifest.json'}.items():proposal['inputBindings'][key]=binding(path)
proposal['cornerSmoothingSuccessor']={'scope':'EXACT_THREE_PHYSICAL_CARRIER_PATH_DECLARATION_REPLACEMENTS_ONLY','changedOriginalSourceIds':sorted(changed),'all13OtherNewThreePathDeclarationsExact':True,'all2OriginalClockThreePathDeclarationsExact':True,'all32Suppressions24PortsAnd4LayerForksExact':True,'all225Barrels96Topstubs165ReferencesOriginalLogicAndConstraintsExact':True,'updatedAuthenticPairEvidencePath':str(GEOMETRY/'UPDATED_AUTHENTIC_PAIR_SECTIONS.json'),'updatedAuthenticPairEvidenceSha256':digest(GEOMETRY/'UPDATED_AUTHENTIC_PAIR_SECTIONS.json'),'old54946PrivateApiAnglesFailedOnlyThreeSignals':True,'freshSourceCoreNativeOriginalApisRequired':True,'oldProofsNotAcceptanceForNewGeometry':True,'complete18Accepted':False,'accepted49':False,'fabricationReady':False}
# Exact same source-level owner, suppression, Port and layer code. The three
# different path arrays enter through the new local proposal import only.
for name in ['strict18-source-overlay.tsx','validate-source-proposal.py','authorized-all4-routing-input.json']:(HERE/name).write_bytes((BASE/name).read_bytes())
(HERE/'strict18-source-proposal.json').write_text(json.dumps(proposal,indent=2)+'\n')
s=(BASE/'capture-strict18-source.ts').read_text();needle='const restored = clone(after), untouchedActual = canonical(after)'
assert s.count(needle)==1
addition='''// Compare against the ACTUAL passed prior strict18 Source tree as well as
// the original full numeric Source inverse below. Restore exactly three path
// props; keys/order/logic/ports/barrels/constraints must be the same everywhere.
const priorStrict18Capture = JSON.parse(readFileSync(proposal.inputBindings.priorStrict18Capture.path, "utf8"))
assert.equal(priorStrict18Capture.passed, true); assert.equal(priorStrict18Capture.fullInverseSourceTreePassed, true)
const priorStrict18Proposal = JSON.parse(readFileSync(proposal.inputBindings.priorStrict18Proposal.path, "utf8"))
const serializedAfter = JSON.parse(JSON.stringify(after, replacer)) as Row
const exactThreeInverse = clone(serializedAfter), previousStrict18Tree = priorStrict18Capture.actualSourceTree as Row
const changedOnly = proposal.cornerSmoothingSuccessor.changedOriginalSourceIds
assert.deepEqual(changedOnly, ["source_trace_15", "source_trace_16", "source_trace_28"])
let smoothedRestorations = 0
for (const name of changedOnly) {
  const previous = priorStrict18Proposal.newOriginalSignalChanges.find((r: { originalSourceTraceId: string }) => r.originalSourceTraceId === name)
  assert(previous)
  const restoredRow = byName(flatten(exactThreeInverse), previous.originalLogicalTraceName)
  const originalRow = byName(flatten(previousStrict18Tree), previous.originalLogicalTraceName)
  assert.deepEqual(originalRow.props.pcbPaths, previous.newPcbPaths)
  restoredRow.props.pcbPaths = previous.newPcbPaths; smoothedRestorations++
}
assert.equal(smoothedRestorations, 3)
assert.equal(canonical(exactThreeInverse), canonical(previousStrict18Tree), "Exactlythree path arrays change versus actual passed strict18; all other props/keys/order remain exact")
'''
s=s.replace(needle,addition+needle).replace('original144AncestorClosureUnchanged: true, pureSourceEvaluationExecuted: true,','original144AncestorClosureUnchanged: true, exactThreeSmoothedPathSuccessorInversePassed: true,\n  exactChangedOriginalSourceIds: changedOnly, updatedAuthenticPairEvidenceSha256: proposal.cornerSmoothingSuccessor.updatedAuthenticPairEvidenceSha256,\n  priorActualStrict18SourceCaptureSha256: proposal.inputBindings.priorStrict18Capture.sha256, pureSourceEvaluationExecuted: true,')
(HERE/'capture-strict18-source.ts').write_text(s)
core=(CORE/'render-strict18-core.ts').read_text();oldpath=str(BASE);assert core.count(oldpath)==2
core=core.replace(oldpath,str(HERE))
# All120 authentic controls and the exact pinned imports remain; only two
# Source imports now resolve to the new immutable source/proposal.
(HERE/'render-strict18-core.ts').write_text(core)
for p in HERE.iterdir():p.chmod(0o600)
print(json.dumps({'proposalSha256':digest(HERE/'strict18-source-proposal.json'),'overlayByteIdentical':(HERE/'strict18-source-overlay.tsx').read_bytes()==(BASE/'strict18-source-overlay.tsx').read_bytes(),'coreOnlyTwoSourceImportsRepointed':core.replace(str(HERE),str(BASE))==(CORE/'render-strict18-core.ts').read_text(),'all32LocalTopSuppressions24InnerPortsHeld':True,'applicationsExecuted':False}))
