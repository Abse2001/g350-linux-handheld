This is an independent local electrostatic cross-section model. It is not the
JLCPCB calculator, a manufacturer guarantee, an actual-board field solution or
a timing qualification. It never imports, routes or exports board copper.

The retained official JLC04161H-3313 and JLC04161H-1080 templates supply the
0.0994 mm/Er=4.1 and 0.0764 mm/Er=3.91 outer dielectric heights. All cases keep
the saved 0.1016 mm lower/0.0889 mm upper trace widths, 0.04064 mm copper,
0.12 mm lower-edge differential gap and Er=3.8 solder-mask parameters. The
physical millimetre inputs are used directly; the saved web requests round
their mil conversions. The templates are symmetric, so the two outer-layer
estimates are identical under the ideal continuous-reference assumptions.

Python 3.12.14, NumPy 2.3.5 and SciPy 1.17.0 are asserted. The existing installed
package RECORD hashes were verified for 903 NumPy and 1,426 SciPy files without
installing anything. Each job runs sequentially with one BLAS thread, a 60 s
wall limit, sampled 1 GiB RSS limit and protective 28 GiB shared-memory stop.
All 24 final nominal/sensitivity jobs exited zero; maximum sampled RSS was
253,673,472 bytes and maximum wall time 2.023 s. Full raw receipts remain in
`raw/`. Initial controls under `history-v0/` predate a corrected metal-boundary
coefficient and are superseded; other historical controls also remain.

The finite-volume solver sums each face once, uses dielectric face weights,
and applies the exterior dielectric at perfect-conductor boundaries. Identical
all-air geometry supplies C0. For a symmetric pair at ±0.5 V, differential
capacitance is 2U=Qpositive and differential impedance is
1/(c*sqrt(Cdiff*C0diff)); odd impedance is half that value. Independent matrix
excitation checks this factor of two. Controls also cover a parallel plate,
homogeneous permittivity scaling, a two-dielectric series capacitor with an
irrelevant metal interior permittivity of 123, and an uncoated zero-thickness
microstrip against the approximate Hammerstad/Jensen formula.

Each nominal case uses 4, 2 and 1 µm near-conductor refinements. Boundary
doubling and two explicit mask profiles measure separate sensitivities. The
parameter descriptions do not determine a real mask meniscus or sidewall
shape: offset and stepped profiles are assumptions. Sloping copper boundaries
and dielectric interfaces remain approximated by the grid; nonmonotonic mesh
changes do not provide a rigorous continuum error bound.

| Template | Isolated single | Differential | Differential / twice single |
| --- | ---: | ---: | ---: |
| 3313 | 60.39 Ω | 97.52 Ω | 0.807 |
| 1080 | 53.68 Ω | 90.97 Ω | 0.847 |

These values use the doubled boundary box and offset mask at 1 µm. The final
mesh changes are at most 0.122 Ω; box doubling changes isolated singles by up
to 0.429 Ω and pairs by 0.033 Ω. Alternate masks change singles by up to
0.223 Ω and pairs by 0.631 Ω. Those are observed differences, not uncertainty
or manufacturing guarantees. The paired/isolated difference is substantial
enough to justify a trusted field-model cross-check before considering any
future width or gap change. No geometry change or TI differential pass/fail
tolerance is inferred or applied by this work.

Quasi-static phase estimates around 5.7–5.94 ps/mm omit material dispersion,
group delay, package/via effects, return discontinuities, adjacent traces,
loss, crosstalk, slew and clock jitter. A 400 MHz setup/hold budget, the TI
single-ended per-segment ±5 Ω requirement, a production guarantee and the
complete routing checks all remain open. fabricationReady remains false.

`report.json` binds all final inputs, model, guard, control results and raw
executions. `summarize.py` only reads completed results. For a new control run,
use fresh output and receipt filenames with `run-job.py`; existing raw job
files intentionally refuse overwrite. No network requests are needed.
