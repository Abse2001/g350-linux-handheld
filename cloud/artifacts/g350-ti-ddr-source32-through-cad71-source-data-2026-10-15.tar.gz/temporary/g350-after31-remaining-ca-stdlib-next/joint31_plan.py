"""Own pure-stdlib prospective joint31 geometry; no application imports."""
import json,pathlib,sys
sys.path.insert(0,'/tmp/g350-after27-remaining-ddr-scalar-planner-next')
import joint27_plan as parent
q=parent.q;g=parent.g
PINS={
 '/tmp/g350-source29-joint7-ca6-ca18-reset-spacing-and-self-repair-sourceonly-next/JOINT_SOURCE29_GEOMETRY_PROPOSAL.json':'2bd2ae7e5e92375dfeb3734165e63cc655e6487a62881d2dfda10c17a6ea427e',
 '/tmp/g350-source20-one-standard-through-via-compatible-with29-and21-geometry-sourceonly-next/SOURCE20_ONE_STANDARD_VIA_GEOMETRY_PROPOSAL.json':'a20ec2fa3f753ebeda2899b2d993fd502d2fb38e1a373c55c6ce1af31c143b64',
 '/tmp/g350-source21-one-standard-through-via-joint29-geometry-sourceonly-next/SOURCE21_ONE_STANDARD_VIA_GEOMETRY_PROPOSAL.json':'7ac7e56343d8dce6bc4133e4b012b87f64bead24b778b88d9408e638dee051f2'}
DATA=[]
for path,sha in PINS.items():
 assert g.sha(path)==sha
 DATA.append(json.loads(pathlib.Path(path).read_text()))
j=DATA[0]
q.PRIMS=[o for o in q.PRIMS if not o['id'].startswith('planned26_reset_bottom:')]
q.segment(j['explicitExistingResetSource26To29Repair']['afterBottomCarrierPoints'],'bottom','source_trace_10','planned29_reset')
for n in j['newTwoCarrierRoutes']:
 q.segment(n['newInner2CarrierPoints'],'inner2',n['originalSourceTraceId'],'planned29_'+n['originalSourceTraceId'])
for candidate in DATA[1:]:
 name=candidate['originalSourceTraceId']
 for piece in candidate['pieces']:
  if piece['role'].startswith('new_'):
   q.segment(piece['points'],piece['layer'],name,'planned31_'+name+'_'+piece['role'])
 x,y=g.xy(candidate['newStandardThroughVia']['xy']);r=.2286
 q.PRIMS.append(dict(kind='circle',geom=(x,y),rad=r,layers=g.LAYERS,owners={name},id='planned31_'+name+'_standard_intermediate_via',bbox=(x-r,y-r,x+r,y+r)))
def required(primitive,name,ti=True):
 hard=primitive['rad']+g.MARGIN
 classes=[q.CLASSES[x] for x in primitive['owners'] if x in q.CLASSES]
 if ti and primitive['kind']=='segment' and classes:
  return max(hard,g.WIDTH*(3 if q.CLASSES[name] in classes else 4))
 return hard
q.required=required
PRIMS=q.PRIMS
BRANCHES=parent.BRANCHES
SELECTED={c['originalSourceTraceId']for c in json.loads(pathlib.Path('/tmp/g350-source31-explicit-nested-roster-type-successor-sourceonly-next/source31-proposal.json').read_text())['selected31OriginalCarriers']}
REMAINING_CA=[n for b in g.MODEL['buses']if b['busId']=='DDR_COMMAND_CLOCK'for n in b['connectionNames']if n not in SELECTED]
