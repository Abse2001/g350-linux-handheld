from pathlib import Path
import argparse, hashlib, importlib.util, json, os, re, stat, sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'g350-count-conditioned-site-recovery-next'
REPOSITORY = Path('/workspace/bus-lanes-solver')
POLICY = {'wallSeconds': 60, 'rssBytes': 2*1024**3, 'sharedBytes': 26*1024**3,
          'sampleSeconds': .05, 'termGraceSeconds': 5}
RESERVE = 2*1024**3

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''): h.update(block)
    return h.hexdigest()

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec); spec.loader.exec_module(loaded)
    return loaded

def verify():
    raw = (ROOT / 'PREPARED.json').read_bytes(); packet = json.loads(raw)
    for row in packet['files'] + packet['externalFiles']:
        path = Path(row['path'])
        assert path.is_file() and not path.is_symlink() and sha(path) == row['sha256']
        assert path.stat().st_size == row['bytes'] and stat.S_IMODE(path.stat().st_mode) == row['mode']
    parent = module('cartesian_oracle_original_focused_guard', ROOT.parent / 'g350-canonical-prune-cartesian-oracle-focused-sourceonly-next/guard.py')
    old_packet, old_digest = parent.verify()
    assert old_digest == packet['parentPacketSha256'] == '4c5a65fca23568b027d48ade49f81ed52f1516509a43af8945f4aa2c83bffb38'
    assert packet['sourceDirectory'] == old_packet['sourceDirectory']
    previous = json.loads((ROOT.parent / 'g350-canonical-prune-cartesian-oracle-focused-sourceonly-next/EXECUTION-postaudit.json').read_bytes())
    assert previous['focusedOracleQualificationPassed'] is False
    assert previous['actualCounters'] == {'pass': 6, 'fail': 1}
    assert previous['sourceAndArtifactsHeld'] is True and previous['dependenciesBefore'] == previous['dependenciesAfter']
    assert previous['execution']['exitCode'] == 1 and previous['execution']['diagnosticStopped'] is False
    assert previous['execution']['cleanupOwnedGroupEmpty'] is True and not any(previous['execution']['oomDelta'].values())
    steps = json.loads((ROOT.parent / 'g350-canonical-prune-cartesian-oracle-focused-sourceonly-next/run/steps.json').read_bytes())
    assert steps[0]['name'] == 'typecheck' and steps[0]['exitCode'] == 0
    assert steps[0]['command'] == ['/workspace/g350-linux-handheld/.cloud-tools/node/bin/node', 'node_modules/typescript/bin/tsc', '--noEmit']
    original_collection = json.loads(Path(packet['originalRootCollectionPath']).read_bytes())
    assert original_collection['sessionId'] == 21588 and original_collection['toolExitCode'] == 2
    return packet, hashlib.sha256(raw).hexdigest()

def dependencies():
    verifier = module('canonical_handoff_trusted_dependency_verifier', BASE / 'verify-installed-dependencies.py')
    result = verifier.verify(BASE / 'dependencies/archive-receipt.json',
        '1a49a60909258b542c7f4899e6378fa9f10c1cea08ef1aaf4b5366480dbf71b7',
        BASE / 'audit-installed-dependencies.py')
    assert result['treeSha256'] == '47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--root-receipt'); parser.add_argument('--root-receipt-sha256')
    args = parser.parse_args(); packet, digest = verify()
    if args.preflight_only:
        print(json.dumps({'preflightPassed': True, 'packetSha256': digest, 'sourceOnly': True})); return 0
    assert args.run and args.root_receipt and args.root_receipt_sha256
    authority = json.loads(Path(args.root_receipt).read_bytes())
    assert sha(args.root_receipt) == args.root_receipt_sha256
    assert authority['authorizedByRoot'] is True and authority['scope'] == packet['scope']
    assert authority['packetSha256'] == digest and authority['policy'] == POLICY
    assert re.fullmatch('[0-9a-f]{32,128}', authority['approvalToken'])
    previous_path = Path(authority['previousClosedPostauditPath'])
    assert sha(previous_path) == authority['previousClosedPostauditSha256']
    previous = json.loads(previous_path.read_bytes()); execution = previous['execution']
    assert execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values())
    assert execution['pgid'] == authority['previousOwnedPgid']
    assert previous.get('sourceAndArtifactHeld', previous.get('sourceAndArtifactsHeld')) is True
    assert previous['dependenciesBefore'] == previous['dependenciesAfter']
    scope = module('canonical_handoff_original_owned_scope', BASE / 'process_scope.py')
    assert not scope.owned(execution['pgid']) and not (ROOT / 'run').exists()
    before = dependencies(); baseline = scope.memory()
    def gate(now):
        assert now['current'] + POLICY['rssBytes'] + RESERVE < POLICY['sharedBytes'], 'Strict prefork reserve required'
        assert all(now['events'][k] == baseline['events'][k] for k in scope.OOM_KEYS)
    actual = scope.run_guarded(packet['command'], Path(packet['sourceDirectory']), ROOT / 'run', POLICY, before_spawn=gate)
    verify(); after = dependencies(); assert before == after
    result_path = ROOT / 'run/result.json'
    result = json.loads(result_path.read_bytes()) if result_path.is_file() else None
    log_path = ROOT / 'run/child.log'
    log = log_path.read_text(errors='replace') if log_path.is_file() else ''
    pass_rows = re.findall(r'^\s*(\d+) pass\s*$', log, re.M)
    fail_rows = re.findall(r'^\s*(\d+) fail\s*$', log, re.M)
    counts = {'pass': int(pass_rows[-1]) if pass_rows else None,
              'fail': int(fail_rows[-1]) if fail_rows else None}
    passed = (actual['exitCode'] == 0 and not actual['diagnosticStopped']
        and actual['cleanupOwnedGroupEmpty'] and not any(actual['oomDelta'].values())
        and counts['pass'] == 7 and counts['fail'] == 0)
    receipt = {'execution': actual, 'dependenciesBefore': before, 'dependenciesAfter': after,
        'sourceAndArtifactsHeld': True, 'packetSha256': digest, 'focusedOracleQualificationPassed': passed,
        'actualCounters': counts, 'resultSha256': sha(result_path) if result is not None else None,
        'accepted49': False, 'wholeSuiteExecuted': False, 'typecheckReusedFromSuccessfulOriginalStep': True, 'originalTypeStepsSha256': packet['originalTypeStepsSha256'], 'original961QueryFailurePreserved': True, 'allElevenBenchmarksExecuted': False}
    (ROOT / 'EXECUTION-postaudit.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'focusedOracleQualificationPassed': passed, 'actualCounters': counts,
                     'resultSha256': receipt['resultSha256']}))
    return 0 if passed else 2

if __name__ == '__main__': raise SystemExit(main())
