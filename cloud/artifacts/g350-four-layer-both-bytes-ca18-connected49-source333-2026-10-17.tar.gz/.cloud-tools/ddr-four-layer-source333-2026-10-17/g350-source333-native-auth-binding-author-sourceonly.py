#!/usr/bin/env python3
"""Own stdlib text/JSON author: no SDK, TS parser, helper import or geometry."""
import ast
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/tmp')
PINS = {
    'plan': ('/tmp/g350-both-bytes-ca18-model328-projector-root-20261017-run331/byte0-result.json', '7a10f9b14d9e6656ad7033279fdfdf2ca60047e855fdc9c36466cc9223250103'),
    'candidate': ('/tmp/g350-four-body-ca18-strong-self-root-20261017-run328/byte0-result.candidate.json', '056cac41c6a654b417f6c088d871b8aab41bdaf1bfd42f570acd9dd42d7a09c8'),
    'capture': ('/tmp/g350-both-bytes-ca18-model328-capture-root-20261017-run332/byte0-result.json', 'a164a7b04c44096c8d0f9cdcc33fd09d0d4a2e37047f699aebd38aa527cc4237'),
    'raw': ('/tmp/g350-both-bytes-ca18-model328-core333-raw.json', 'fcb39e6bb43d972f8d511671ffe30b40819d53aeaeb48fd05d8017f30667990d'),
    'controls': ('/tmp/g350-both-bytes-ca18-model328-core-smol-root-20261017-run333/byte0-result.json', '435bf9061803ed2c903eeba7085e1f2b4bc77f6cdd7fd8137f024df9b49f1f38'),
}
PARENTS = [
    ('focused16', '/tmp/g350-all49-plan311-ca16-focused-native-checks-sourceonly.ts', 'a41e6cc509b452d67c7074575b70cb39d5dc402209c226e0b99dbaba2fb28578', '/tmp/g350-all49-plan331-ca18-focused-native-checks-sourceonly.ts'),
    ('complement16', '/tmp/g350-all49-plan311-source313-remaining-original16-native-checks-sourceonly.ts', '2f8a36abf1e5b54c944cb6166feff15f775b3d70041517e0f656b688dfb1d253', '/tmp/g350-all49-plan331-source333-remaining-original16-native-checks-sourceonly.ts'),
    ('via236', '/tmp/g350-manual49-plan311-model299-ca16-ti3w-via-track-manufacturing-sourceonly.ts', '3a76d4559cefc594f935b6d4180964466fbbf84c6cc3661393016c11d453ff4e', '/tmp/g350-manual49-plan331-model328-ca18-via-track-manufacturing-sourceonly.ts'),
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    with Path(path).open('x') as f:
        f.write(value)

data = {}
for name, (path, h) in PINS.items():
    raw = Path(path).read_bytes()
    assert digest(raw) == h, name
    data[name] = json.loads(raw)
plan, control, capture = [data[k] for k in ('plan', 'controls', 'capture')]
pdn = plan['cap8HardwareDelta']
N, I, R, A, P, J = (len(plan['newVias']), len(plan['innerPortRegistrations']),
    sum(len(g['wireRuns']) for g in plan['projectedGeometry']), len(plan['auxiliaryLocalTraces']),
    len(pdn['pdnVias']), len(pdn['innerPortRegistrations']))
assert (N, I, R, A, P, J) == (105, 82, 154, 0, 2, 4)
expected = dict(physicalVias=129+N+P, pcbComponents=409+N+P,
    sourceAndPcbPorts=1419+2*N+I+2*P+J, sourceTraces=1097+A, physicalTraces=165+R+A,
    reactElements=2036+N+I+A+P+J, registeredInnerPorts=I+J, newVias=N+P,
    newSignalVias=N, newPdnVias=P, newInnerPorts=I+J, newSignalInnerPorts=I,
    newPdnInnerPorts=J, newWireRuns=R+A, routedWireRuns=R, auxiliaryWireRuns=A,
    auxiliaryLocalTraces=A, routedOwners=49, pendingOwners=0)
assert control['expectedCounts'] == capture['expectedCounts'] == expected
assert len(control['checks']) == 35 and all(c['passed'] is True for c in control['checks'])
assert len(control['physicalGraphs']) == 49 and all(g['physicallyConnectedByActualOwnedNumericIdGraph'] for g in control['physicalGraphs'])
counts = Counter(row['type'] for row in data['raw'])
assert all(counts[t] == n for t, n in [('source_component',280), ('source_manually_placed_via',236),
    ('pcb_via',236), ('pcb_component',516), ('source_port',1719), ('pcb_port',1719),
    ('source_trace',1097), ('pcb_trace',319), ('pcb_copper_pour',19)])
assert capture['passed'] and capture['fullInverseSourceTreePassed'] and capture['parentNormalizationInversePassed']
assert control['planSha256'] == capture['planSha256'] == PINS['plan'][1]
assert control['candidateSha256'] == capture['candidateSha256'] == PINS['candidate'][1]
assert control['actualCaptureSha256'] == PINS['capture'][1] and control['rawCoreSha256'] == PINS['raw'][1]

shared = {
    '/tmp/g350-both-bytes-ca16-ti3w-model299-projector-root-20261016-run311/byte0-result.json': PINS['plan'][0],
    '35f5fb65d14e5386797eaf24475813f6205a65466ac2df600e12f38f31b0ce74': PINS['plan'][1],
    '/tmp/g350-source24-TI3W-foreign34W-matched49-finite1g-root-20261016-run299/byte0-result.candidate.json': PINS['candidate'][0],
    '8abef05761375014f8a310f9cfcab92d7a5b7da978598fe4a49b1c118658d34d': PINS['candidate'][1],
    '/tmp/g350-both-bytes-ca16-ti3w-model299-capture-root-20261016-run312/byte0-result.json': PINS['capture'][0],
    '8da7d8270e6994c5afa255cc90953e7f3393e84f32cba674c0b838457a5c05b0': PINS['capture'][1],
    '299 Source24-bank model': '328 four-body CA18 model',
    '299 CA16 model': '328 CA18 model',
    'candidate299 CA16 TI3W-bank replay': 'candidate328 CA18 wide-route replay',
    'CA16 TI3W-bank': 'CA18 wide-route',
    'PLAN311_MODEL299_CA16_TI3W': 'PLAN331_MODEL328_CA18_WIDE',
    'PLAN311_SOURCE313_CA16_MODEL299': 'PLAN331_SOURCE333_CA18_MODEL328',
    'PLAN311_CA16_MODEL299': 'PLAN331_CA18_MODEL328',
    'Plan311Ca16': 'Plan331Ca18',
    'Plan311Source313': 'Plan331Source333',
    'Plan311Model299Ca16': 'Plan331Model328Ca18',
    'actual311': 'actual331',
    'combined311': 'combined331',
    'Model299 CA16': 'Model328 CA18',
    '/312 capture /fresh Core313': '/332 capture /fresh Core333',
    'actual312capture/311plan/299candidate': 'actual332capture/331plan/328candidate',
    'passed312': 'passed332',
    'Actual299': 'Actual328',
    'candidate299': 'candidate328',
    'actualCapture312': 'actualCapture332',
    'model299PhysicalAndTiSpacingEvidenceIsNotFreshNativeQualification': 'model328PhysicalAndTiSpacingEvidenceIsNotFreshNativeQualification',
    'PLAN311': 'PLAN331',
    'Source312': 'Source332',
    'plan311': 'plan331',
    'capture312': 'capture332',
    'source289QualificationInherited:false,': 'source289QualificationInherited:false,source313QualificationInherited:false,',
    'source289Original32QualificationInherited:false,': 'source289Original32QualificationInherited:false,source313Original32QualificationInherited:false,',
    'source299ModelPhysicalQualificationInherited:false,': 'source299ModelPhysicalQualificationInherited:false,source313GeometryOrPourQualificationInherited:false,',
}
complement = {
    'ACTUAL313': 'ACTUAL333', 'actual313 raw/control': 'actual333 raw/control',
    '2899641a823e870db43b4dde16cec50bcebec8434ef09ebf5d980300d087c59e': PINS['raw'][1],
    '3bda070f41549fef4c33f455132b2e3a5d34100a7c3abbf01cc1b8014373a33a': PINS['controls'][1],
}
auth = {
    'and234 actual fullspan vias': 'and236 actual fullspan vias',
    'N===103&&I===80&&A===0&&R===152&&P===2&&J===4&&PHYSICAL_VIAS===234&&PHYSICAL_TRACES===317':
        'N===105&&I===82&&A===0&&R===154&&P===2&&J===4&&PHYSICAL_VIAS===236&&PHYSICAL_TRACES===319',
    'N103/I80/routed152/aux0': 'N105/I82/routed154/aux0',
    'Exact234 actual physical vias': 'Exact236 actual physical vias',
    'Exact physical234 partition:129 unchanged reference barrels,103 generated signal barrels':
        'Exact physical236 partition:129 unchanged reference barrels,105 generated signal barrels',
    'AUTHENTICATED_234': 'AUTHENTICATED_236',
    'ALL234_VIAS': 'ALL236_VIAS',
}
records = []
for kind, old, old_sha, new in PARENTS:
    source = Path(old).read_text()
    assert digest(source.encode()) == old_sha, old
    changes = {**shared, **(complement if kind == 'complement16' else auth if kind == 'via236' else {})}
    pattern = re.compile('|'.join(re.escape(s) for s in sorted(changes, key=len, reverse=True)))
    pieces = []; edits = []; last = 0; out_count = 0
    for match in pattern.finditer(source):
        before = source[last:match.start()]; pieces.append(before); out_count += len(before)
        replacement = changes[match.group()]
        edits.append(dict(beforeStart=match.start(), beforeEnd=match.end(), afterStart=out_count,
            afterEnd=out_count+len(replacement), before=match.group(), after=replacement))
        pieces.append(replacement); out_count += len(replacement); last = match.end()
    pieces.append(source[last:]); output = ''.join(pieces)
    reverse = []; last = 0
    for edit in edits:
        assert output[edit['afterStart']:edit['afterEnd']] == edit['after']
        reverse += [output[last:edit['afterStart']], edit['before']]; last = edit['afterEnd']
    reverse.append(output[last:]); assert ''.join(reverse) == source
    assert 'Plan311' not in output and 'PLAN311' not in output and 'candidate299:' not in output
    write(new, output)
    delta = ''.join(difflib.unified_diff(source.splitlines(True), output.splitlines(True), fromfile=old, tofile=new))
    diff_path = new.replace('.ts', '.full-functional.diff'); write(diff_path, delta)
    records.append(dict(kind=kind, parent=dict(path=old,sha256=old_sha),
        successor=dict(path=new,sha256=digest(output.encode()),bytes=len(output.encode()),lines=len(output.splitlines())),
        fullFunctionalDiff=dict(path=diff_path,sha256=digest(delta.encode())),
        exactPositionalBindingInverseRecoversParent=True, bindingEdits=edits))

manifest = dict(scope='SOURCE_ONLY_SOURCE333_PLAN331_MODEL328_CA18_NATIVE16_COMPLEMENT16_AUTH236_BINDING_SUCCESSORS',
    inputPins={k:dict(path=v[0],sha256=v[1]) for k,v in PINS.items()},
    derivedInventory=dict(N=N,I=I,R=R,A=A,P=P,J=J), expectedCounts=expected,
    actualRawCatalogueCounts=dict(counts), all35ControlsAnd49OwnedNumericGraphsPassed=True,
    successors=records, sourceAlgorithmChanges=False, allMathematicsAndOwnershipKernelsUnchanged=True,
    fullFindingsAndExceptionsRemainUnfiltered=True, original32RosterAndSplit16Plus16Unchanged=True,
    originalBusSkewMm=.635,originalPairToleranceMm=.127,
    moduleImportOrExecutionByAuthor=False, tsParserOrSdkExecutedByAuthor=False,
    source313QualificationInherited=False, currentNativeResultsKnown=False,
    currentPourQualified=False,currentPdnContinuityQualified=False,cadQualified=False,fabricationReady=False,
    authorPythonAstAndCompileOnlyPassed=True)
own = Path(__file__).read_bytes(); ast.parse(own,str(__file__)); compile(own,str(__file__),'exec')
write('/tmp/g350-source333-native-auth-binding-static-manifest.json', json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k not in ('successors','actualRawCatalogueCounts')},indent=2))
for r in records:
    print(json.dumps({k:r[k] for k in ('kind','successor','fullFunctionalDiff','exactPositionalBindingInverseRecoversParent')}))
