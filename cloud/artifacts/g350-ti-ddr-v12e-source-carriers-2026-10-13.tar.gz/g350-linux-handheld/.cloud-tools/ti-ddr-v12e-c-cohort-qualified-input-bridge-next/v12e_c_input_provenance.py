"""Pure actual-final-props C layer sidecar over measured unchanged E geometry."""
from pathlib import Path
import copy,hashlib,importlib.util,json,stat,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PARENT=Path('/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-qualified-input-bridge-next')
LAYERS=['top','inner1','inner2','bottom'];CARRIERS={'DDR_RESET':'top','DDR_BYTE0':'bottom','DDR_BYTE1':'inner2','DDR_COMMAND_CLOCK':'inner1'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def require(v,s):
 if not v:raise ValueError(s)
def verify_rows(base,rows):
 for row in rows:
  p=base/row['path'] if base else Path(row['path'])
  require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Binding changed: '+str(p))
def verify(expected_manifest_sha256):
 require(sha(ROOT/'SOURCE-INPUT-manifest.json')==expected_manifest_sha256,'Exact sealed C source/input sidecar required')
 m=load(ROOT/'SOURCE-INPUT-manifest.json');verify_rows(ROOT,m['files']);verify_rows(None,m['externalFiles'])
 spec=importlib.util.spec_from_file_location('g350_c_reused_actual_e_geometry',PARENT/'v12e_input_provenance.py');parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent);inherited=parent.verify(m['parentBridgeManifestSha256'])
 old_d=load(m['closedDOriginalNaturalFailureRoot']);old_e=load(m['closedERecoveredWallStopRoot'])
 require(old_d['naturalFailure'] is True and old_d['actualSolverState']['failed'] is True and old_d['actualSolverState']['actualTraceCount']==0 and old_d['sourceAndDependenciesHeld'] is True and old_d['execution']['cleanupOwnedGroupEmpty'] is True and not any(old_d['execution']['oomDelta'].values()) and old_d['accepted49'] is False and old_d['fabricationReady'] is False,'Original D natural failure must remain preserved, not retagged successful')
 require(old_e['status']=='RECOVERED_WALL_STOP1200_NO_NATURAL_OUTPUT' and old_e['naturalOutputPresent'] is False and old_e['sourceAndDependenciesHeld'] is True and old_e['execution']['cleanupOwnedGroupEmpty'] is True and not any(old_e['execution']['oomDelta'].values()) and old_e['accepted49'] is False and old_e['fabricationReady'] is False,'Original E recovered wall stop/unknown wrapper session must remain preserved')
 source=Path(m['sourceDirectory']);packet=load(source/'CAPTURE-manifest.json');require(sha(source/'CAPTURE-manifest.json')==m['capturePacketSha256'],'Actual C capture packet changed');verify_rows(source,packet['files']);verify_rows(None,packet['externalFiles'])
 actual=load(source/'run/actual-final-props.json');receipt=load(source/'run/RECEIPT.json');e=receipt['execution'];derived=load(source/'derived-final-authored-props.json')
 require(receipt['passed'] is True and receipt['sourceHeld'] is True and receipt['sourceManifestSha256']==m['capturePacketSha256'] and receipt['captureSha256']==sha(source/'run/actual-final-props.json') and e['exitCode']==0 and e['diagnosticStopped'] is False and e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()) and receipt['boardDependenciesBefore']==receipt['boardDependenciesAfter'],'Actual clean source/dependency-held C final React capture required')
 require(actual['scope']=='PURE_ACTUAL_V12E_C_FINAL_REACT_TWO_BUS_FOUR_LAYER_LIST_PROPS_ONLY' and actual['actualFinalReactTreeEvaluated'] is True and actual['allOtherTreePropsTypesKeysChildrenExactlyHeld'] is True and len(actual['changedLayerProps'])==4 and sorted(actual['changedLayerProps'],key=lambda x:(x['busId'],x['field']))==sorted(packet['fourLayerPropChanges'],key=lambda x:(x['busId'],x['field'])),'Exactly four actual layer-list props across two original buses required')
 for key in ['placementProposal','authoredPolicyProof','referenceCopperCandidates','globalSignalLayerProjection','naturallyDerivedGenericDefaultCap']:require(actual[key]==derived[key],'Final C authored metadata differs: '+key)
 for key in ['newCoreBuildPerformed','newNativePlacementCheckPerformed','referenceQualified','TIplaneArrangement','coreRenderCalled','nativePlacementChecksInvoked','routingSolverInstantiated','accepted49','fabricationReady']:require(actual[key] is False,'Metadata-only capture must not claim a new geometry/physics/routing pass: '+key)
 require(inherited['freshCircuitSha256']==m['reusedActualCoreGeometrySha256']=='0e2ce064e896db1d087474716d2e82b86155dbe28eecf28ce1727e73a466fee1' and inherited['nativePlacementChecks']==17 and inherited['nativePlacementErrors']==0,'Original actual E geometry/native17 measurement required')
 before=load(PARENT/'input.json');expected=copy.deepcopy(before)
 for bus in expected['buses']:
  if bus['busId'] in ['DDR_RESET','DDR_BYTE0']:bus['allowedLayers']=[CARRIERS[bus['busId']]];bus['preferredLayers']=[CARRIERS[bus['busId']]]
 current=load(ROOT/'input.json');require(current==expected and (ROOT/'input.json').read_bytes()==(source/'input.json').read_bytes(),'Native input changes only declared final C layer lists; physical graph exact')
 require((ROOT/'original-unrestricted-input.json').read_bytes()==(PARENT/'original-unrestricted-input.json').read_bytes(),'Original all4 broad physical input bytes remain exact')
 require(sha(ROOT/'input.json')==m['inputSha256'] and sha(ROOT/'original-unrestricted-input.json')==m['unrestrictedInputSha256'],'Exact derived input sidecar hashes required')
 for bus in current['buses']:
  group=next(g for g in actual['authoredPolicyProof']['groups'] if g['busId']==bus['busId']);require(group['pcbAllowedLayers']==bus['allowedLayers'] and group['preferredLayers']==bus['preferredLayers'] and group['pcbTraceWidth']==bus['traceWidth'],'Native layer sidecar must derive from actual final authored props')
 require(current['allowedLayers']==LAYERS and current['layerCount']==4 and len(current['connections'])==49 and len(current['obstacles'])==856 and len(current['traces'])==2 and actual['globalSignalLayerProjection']==LAYERS and actual['naturallyDerivedGenericDefaultCap']==800000,'Original four physical layers/49/856/2/default800k required')
 return {'scope':'ACTUAL_FINAL_C_LAYER_METADATA_SIDECAR_OVER_UNCHANGED_MEASURED_V12E_GEOMETRY','inputSha256':m['inputSha256'],'unrestrictedInputSha256':m['unrestrictedInputSha256'],'freshCircuitSha256':m['reusedActualCoreGeometrySha256'],'actualCoreGeometryReusedNotFreshlyRendered':True,'originalDNaturalFailurePreserved':True,'originalERecoveredWallStopAndUnknownWrapperExitPreserved':True,'nativePlacementChecks':17,'nativePlacementErrors':0,'nativePlacementChecksInheritedNotRerun':True,'actualCoreInputQualified':True,'actualFinalReactTreeEvaluated':True,'sourceInputParityQualified':True,'finalLayerMetadataDerivedFromActualAuthoredProps':True,'pinnedCoreSourceBusMetadataOmissionExplicit':True,'newRawCoreLayerMetadataEmissionClaimed':False,'exactAll49SourceConnectionsQualified':True,'proposedThreeRigidXMotionsExactlyHeld':True,'routingRequests':49,'obstacles':856,'fixedReferences':2,'signalLayersAllowed':LAYERS,'cohortCarrierConstraints':CARRIERS,'naturallyDerivedGenericDefaultCap':800000,'explicitSearchCapSupplied':False,'referenceQualified':False,'TIplaneArrangement':False,'referenceRedesignStillRequired':True,'newCoreBuildPerformed':False,'newNativePlacementCheckPerformed':False,'nativeCoreOrRouterApiInvoked':False,'accepted49':False,'fabricationReady':False}
def verify_producer_inputs(producer_directory,expected_manifest_sha256):
 result=verify(expected_manifest_sha256);p=Path(producer_directory);require(sha(p/'input.json')==result['inputSha256'] and sha(p/'original-unrestricted-input.json')==result['unrestrictedInputSha256'],'Producer must use exact C sidecar and unchanged physical broad input');return result
def verify_actual_authored_props(path):
 m=load(ROOT/'SOURCE-INPUT-manifest.json');canonical=Path(m['sourceDirectory'])/'run/actual-final-props.json';require(sha(path)==sha(canonical) and load(path)==load(canonical),'Exact actual final C React props required')
 return {'actualFinalReactTreeEvaluated':True,'captureSha256':sha(path),'signalLayersAllowed':LAYERS,'cohortCarrierConstraints':CARRIERS,'naturallyDerivedGenericDefaultCap':800000,'referenceQualified':False,'TIplaneArrangement':False,'newCoreBuildPerformed':False,'newNativePlacementCheckPerformed':False,'nativePlacementChecksInheritedNotRerun':True,'accepted49':False,'fabricationReady':False}
