#!/usr/bin/env python3
"""SOURCE ONLY. Root-run stock CLI export in the reviewed owned resource scope.

No author execution. This launches Bun directly in the existing guarded PGID,
keeps every source/protected/input pin, and never imports routing/CAD packages
in the guard. Export success does not qualify CAD connectivity or fabrication.
"""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat

board = Path('/workspace/g350-linux-handheld')
cache = Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
stage = board / 'dist/g350-source272-kicad49-root-20261016'
manifest = Path('/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/SOURCE-manifest.json')
helper = Path('/tmp/g350-process-scope-empty-argv-bounded-startup-retry-sourceonly-next/process_scope_empty_argv_retry.proposal.py')
cli = board / 'node_modules/@tscircuit/cli/dist/cli/main.js'
bun = board / '.cloud-tools/bun/node_modules/bun/bin/bun.exe'
output = stage / 'source272-bridged-fresh.kicad_pcb'
protected = {
 'AGENTS.md':'d3086d9ff8887bd296ed0d480fcbef732686bf45e075ae766a0a292518086723',
 'cloud/CONTINUE_BOARD.md':'bb9a879c5c68c3718d24c82a77326f5b175d47899f101407b1e1ee106c8b19ef',
 'scripts/prepare-g350-ram90-four-layer.mjs':'ec6b56c59d2c8f72f969934076dd3597014833e8b2e8e4387c1045f03eaadda0',
 'scripts/tune-g350-ram90-native-lengths.mjs':'5bfe731744159cf9f65ddde71b513cb1a0d2384574e740cd11bc087ce69b4b40',
 'node_modules/@tscircuit/checks/dist/index.js':'1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc',
 'node_modules/@tscircuit/core/dist/index.js':'97b8a4eb484630c3ce2bfc2d68588801484d85adf94785d8849a1d91c4404905',
 'node_modules/@tscircuit/cli/dist/cli/main.js':'2135bc7f5e27b72ddfaa9b65586c905897e4222f989328ebc0434b1d1961c19c',
}
inputs = {
 stage/'source272-via-key-bridge.circuit.json':'53a6975d24aed09d7669d0eef2a54b12d6a715772e4467c4d6ac7a1dba63a4d1',
 stage/'source272-kicad49-expected.json':'4e04245bee872685747fd1ed5deb8dfa4dbedbc31e93d195679b071d70506a3f',
 stage/'SERIALIZER_BRIDGE.json':'0a9321f765cd36af2eb06d8cad22f6319b06693b38253457c264fa3cacf0288a',
 stage/'original-source272.circuit.json':'33584d197a1bb45a0dc76ac0a69e7016866a2369f1750c72d5eedc41ef444594',
 Path('/tmp/g350-both-bytes-ca9-matched49-core272-raw.json'):'33584d197a1bb45a0dc76ac0a69e7016866a2369f1750c72d5eedc41ef444594',
}

def sha(p):
 h = hashlib.sha256()
 with p.open('rb') as f:
  while chunk := f.read(1048576): h.update(chunk)
 return h.hexdigest()

def regular(p):
 return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)

ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument('run', type=Path)
ap.add_argument('--expected-scope', type=int, default=285)
args = ap.parse_args()
run = args.run
assert run.is_absolute() and str(run).startswith('/tmp/g350-') and run.resolve().is_relative_to('/tmp') and not run.exists(), 'Fresh public owned run directory required'
assert stage.is_dir() and stage.resolve() == stage and not output.exists() and not output.is_symlink(), 'Fresh absent export output required'
assert regular(manifest) and sha(manifest) == 'b9700a9a44c9be5f661fd38c37ca9ff6c2f012983e49a750fecea3c8d75e19e0'
assert regular(helper) and sha(helper) == '3756c2f9bfc8284135954669c0a1cbe0e5e966796b0743c6f462af703e17a361'
pins = json.loads(manifest.read_text())['solverSourceFiles']
assert len(pins) == 120

def verify():
 for pin in pins:
  p = Path(pin['path'])
  assert regular(p) and sha(p) == pin['sha256'] and p.stat().st_size == pin['bytes'], p
 for rel, h in protected.items():
  p = board / rel
  assert regular(p) and sha(p) == h, rel
 for p, h in inputs.items():
  assert regular(p) and sha(p) == h, str(p)

verify()
spec = importlib.util.spec_from_file_location('owned_scope', helper)
owned = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)
policy = {'wallSeconds':180,'rssBytes':2*1024**3,'sharedBytes':30*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
def admit(memory):
 assert memory['current'] + policy['rssBytes'] + 1024**3 < policy['sharedBytes'], ('memory admission', memory['current'])

command = [str(bun), '--smol', str(cli), 'export', str(stage/'source272-via-key-bridge.circuit.json'),
 '--format', 'kicad_pcb', '--output', str(output), '--disable-parts-engine']
assert regular(bun)
before = {str(p):sha(p) for p in [Path(__file__).resolve(), bun, helper, manifest, *inputs, *(board/p for p in protected)]}
journal = cache / 'LATEST_CONTINUATION_2026-10-14.json'
with (cache/'strict18-root-serial.lock').open('a') as lock:
 fcntl.flock(lock, fcntl.LOCK_EX)
 state = json.loads(journal.read_text())
 assert not state.get('rootSdkInvocationOpen')
 scope = int(state.get('requiresCurrentClosedScopes', 88)) + 1
 assert scope == args.expected_scope, ('Explicit current scope required', scope)
 assert not output.exists() and not output.is_symlink(), 'Export output became occupied before launch'
 verify()
 run.mkdir(parents=True, exist_ok=False)
 state.update(rootSdkInvocationOpen=True, activeRootScope=scope, lastAction=owned.utc(),
  nextOperation='Bounded stock CLI Source272 metadata-bridged fresh KiCad export; no CAD qualification', currentRouteRun=str(run))
 journal.write_text(json.dumps(state, indent=2)+'\n')
 execution = None
 try:
  execution = owned.run_guarded(command, str(board), run/'owned', policy, before_spawn=admit)
 finally:
  verify()
  assert all(regular(Path(p)) and sha(Path(p)) == h for p,h in before.items()), 'Source/tool/export input mutated'
  assert execution is None or owned.owned(execution['pgid']) == [], 'Owned processes remain'
  exported = None
  if output.exists() or output.is_symlink():
   assert regular(output), 'Export output must be a regular file'
   exported = {'path':str(output),'bytes':output.stat().st_size,'mode':stat.S_IMODE(output.stat().st_mode),'sha256':sha(output)}
  child_log = run/'owned/child.log'
  log_row = {'path':str(child_log),'bytes':child_log.stat().st_size,'sha256':sha(child_log)} if regular(child_log) else None
  receipt = {'scope':scope,'closedAt':owned.utc(),'sourcePinsUnchanged':True,'protectedFilesUnchanged':True,
   'inputFilesUnchanged':True,'inputBindings':[{'path':p,'sha256':h} for p,h in before.items()],
   'execution':execution,'command':command,'childLog':log_row,'exportOutput':exported,
   'exportProcessExitedZero':bool(execution is not None and execution['exitCode'] == 0),
   'exportProducedNonemptyBoard':bool(exported is not None and exported['bytes'] > 0),
   'serializerBridgeExplicit':True,'originalRawEdited':False,'stockCliEdited':False,
   'cadConnectivityQualified':False,'cadManufacturingQualified':False,'all49Accepted':False,'fabricationReady':False}
  (run/'COLLECTED.json').write_text(json.dumps(receipt, indent=2)+'\n')
  state = json.loads(journal.read_text())
  state.update(rootSdkInvocationOpen=False,activeRootScope=None,requiresCurrentClosedScopes=scope,
   lastAction=owned.utc(),lastRouteCollection=str(run/'COLLECTED.json'))
  journal.write_text(json.dumps(state, indent=2)+'\n')
print(json.dumps({'run':str(run),'scope':scope,'exitCode':execution['exitCode'] if execution else None,
 'ownedGroupEmpty':execution['cleanupOwnedGroupEmpty'] if execution else None,
 'stopReasons':execution.get('stopReasons',[]) if execution else [],'exportOutput':exported,
 'cadConnectivityQualified':False,'all49Accepted':False,'fabricationReady':False}))
