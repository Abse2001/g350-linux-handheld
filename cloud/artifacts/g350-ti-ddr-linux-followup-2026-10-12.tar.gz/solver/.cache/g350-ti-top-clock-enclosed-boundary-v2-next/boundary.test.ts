import { expect, test } from "bun:test"
import { captureUntilEnclosedBoundary } from "./boundary-control"
import {
  makeBoundaryCapture,
  wrapBoundaryConstructor,
} from "./boundary-capture"

test("boundary proxy preserves actual instances/private brand/direct and subclass newTarget despite observer exception", () => {
  class Original {
    #value: unknown
    target: unknown
    constructor(value: unknown) {
      this.#value = value
      this.target = new.target
    }
    value() {
      return this.#value
    }
  }
  const error = Error("observer only")
  const wrapped = wrapBoundaryConstructor(Original, () => {
    throw error
  })
  const token = Symbol("identity")
  const direct = new wrapped.Constructor(token)
  class Derived extends wrapped.Constructor {}
  const derived = new Derived(token)
  expect(direct instanceof Original).toBe(true)
  expect(direct.target).toBe(Original)
  expect(derived.target).toBe(Derived)
  expect(direct.value()).toBe(token)
  expect(derived.value()).toBe(token)
  expect(wrapped.Constructor.prototype).toBe(Original.prototype)
  expect(wrapped.observationErrors()).toBe(2)
})

test("declared boundary forwards real yield then exact original RETURN/finally once", () => {
  const argument = {},
    returned = Symbol("yielded")
  let attempted = false,
    closed = 0,
    receiver: unknown,
    received: unknown[] = []
  const producer = {
    routeCoupledPair: function* (this: unknown, ...args: any[]) {
      receiver = this
      received = args
      try {
        yield returned
        attempted = true
        yield returned
        throw Error("must never advance after boundary")
      } finally {
        closed++
      }
    },
  }
  const result = captureUntilEnclosedBoundary(
    producer,
    [argument],
    () => attempted,
  )
  expect(receiver).toBe(undefined)
  expect(received[0]).toBe(argument)
  expect(result.originalNextCalls).toBe(2)
  expect(result.originalReturnCalls).toBe(1)
  expect(result.chargedYields).toBe(2)
  expect(result.originalTerminalMethod).toBe("return")
  expect(result.naturalCompletion).toBe(false)
  expect(result.diagnosticBoundaryStopped).toBe(true)
  expect(result.boundedDone).toBe(true)
  expect(closed).toBe(1)
})
test("natural terminal and original exception remain distinct from diagnostic boundary", () => {
  const value = Symbol("natural")
  const complete = captureUntilEnclosedBoundary(
    {
      routeCoupledPair: function* () {
        return value
      },
    },
    [],
    () => false,
  )
  expect(complete.rawResult).toBe(value)
  expect(complete.naturalCompletion).toBe(true)
  expect(complete.diagnosticBoundaryStopped).toBe(false)
  const error = Error("original")
  expect(() =>
    captureUntilEnclosedBoundary(
      {
        routeCoupledPair: function* () {
          throw error
        },
      },
      [],
      () => false,
    ),
  ).toThrow(error)
})
test("raw prefix/suffix capture never guesses or drops physical blockers", () => {
  const physical = [{ layer: "top", owners: ["physical"], radius: 0.2 }]
  const input = {
    connections: Array.from({ length: 49 }, (_, i) => ({ name: `n${i}` })),
    obstacles: Array.from({ length: 856 }, () => ({})),
  }
  const scene = {
    input,
    connection: { name: "n1", pointsToConnect: [{ layer: "top" }] },
    width: 0.1016,
    margin: 0.1524,
    owners: new Set(["n1"]),
    copper: [...physical, { layer: "top", owners: ["clock"], radius: 0.05 }],
  }
  let raw: any
  const capture = makeBoundaryCapture(input, ["clock"], physical, (value) => {
    raw = value
  })
  capture.observeConstructor([scene, { x: 0, y: 0 }, { x: 1, y: 1 }])
  expect(capture.status().succeeded).toBe(true)
  expect(raw.originalPhysicalCopper).toBe(physical)
  expect(raw.clockCandidateCopper.length).toBe(1)
  const bad = makeBoundaryCapture(input, ["clock"], physical, () => {
    throw Error("must not save altered prefix")
  })
  bad.observeConstructor([{ ...scene, copper: scene.copper.slice(1) }, {}, {}])
  expect(bad.status().succeeded).toBe(false)
  expect(bad.status().error).not.toBe(null)
  expect(bad.status().error!.length).toBeLessThan(256)
})
