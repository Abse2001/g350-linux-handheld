#!/usr/bin/env python3
"""Freeze a NEW post252 Source257 evidence checkpoint using own stdlib only.

Source-only handoff: author has not run this collector. Root must review it and
authorize its execution. Saves CLOSED253..259 plus exact all14 foreign-pour
audit/aggregate, separate annular PDN-contact proof and Root-reviewed plot.
Neither the earlier negative disk proof nor later timing
searches are treated as accepted Source257 geometry.
Frozen post232 and every prior saved directory/archive are read-only inputs.
"""
import argparse
import copy
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import stat

ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post252-2026-10-16'
BASE = ROOT / '.cloud-tools/ddr-four-layer-post232-2026-10-16'
BASE_PINS = {
    'PROGRESS.json': '72f8c492337c2c4097aff00a1db03738c385a765b908b69c523111ef87ec0a5e',
    'WORKSPACE_HASH_INDEX.json': '7ef3325aa7cfa1a82c4e80f760c0a06b6d5790d5f7fcf232f7831b198e75c601',
    'WORKSPACE_RESTORE_MANIFEST.json': '54513dea6b5fea2d4cada7187f115ba10ce8ff43f3afd7f20b506fb9cb5614ef',
    'README.md': 'a7e9ed921e0d682d2aa7ffea82902788922f9b1597173a9548959be69fcbef5e',
}
BASE_MANIFEST = ROOT / 'cloud/artifacts/g350-four-layer-partial48-source248-2026-10-16.manifest.json'
BASE_MANIFEST_SHA = 'a30bfbd25e88a0aa19269c6946a2f33b7683ab4421d99046a85bb8e7cb49e600'
BASE_ARCHIVE_SHA = 'e5d10d729ee0fc7fed74fdafbcb169a4f78083645d81064130dc30c2809d9e24'
RUN = Path('/tmp/g350-cpu-cycle-manual49-root-20261016-run253')
CURRENT = RUN / 'byte0-result.candidate.json'
CURRENT_SHA = 'f76709a0c4cf1a19920b1e9361e7d5f994ee1671f975836f88d775e17651df87'
REPORT = RUN / 'byte0-result.json'
REPORT_SHA = 'ec0018e7b103a91639e67fa6938c875b58942845b41f93c35a35cc1384736348'
WORKER = Path('/tmp/g350-current243-cpu-cycle-manual49-cap8-two-planned-PDN-v4-sourceonly.ts')
WORKER_SHA = 'fd5f61a5593e77a3e669248c1266063c3113f3c427694023a953995ab6e05290'
DESCRIPTOR = Path('/tmp/g350-current243-cap8-two-declared-pdn-nodes-Vdd72-descriptor-v2-sourceonly.json')
DESCRIPTOR_SHA = '20e698e6225f7aa0759aa4acf70103c5f90f3894ae94726336e098598b3f3976'
ANCHOR = Path('/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json')
ANCHOR_SHA = 'cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
PINS = {
    str(CURRENT): CURRENT_SHA, str(REPORT): REPORT_SHA,
    str(WORKER): WORKER_SHA, str(DESCRIPTOR): DESCRIPTOR_SHA,
    str(ANCHOR): ANCHOR_SHA,
    str(RUN / 'COLLECTED.json'): 'd6c97ed14f32d0acc5167339aad3b0efd90afabfbb1f705394805de1b500eaa4',
    str(RUN / 'owned/execution.json'): '24f87512c4d912b1022346de9a78dc22c010b89e967985e7b78531b4db5f9974',
    str(RUN / 'owned/child.log'): '6f89d1f4155b7777ddc1550b154a801c223b0d2400723482dfc24effc5cbefa3',
    str(RUN / 'owned/memory.jsonl'): '4ff46023d2d8e67eb5f82eda8cff629dc826a6a786bf2a2bcbb0d562ad501e78',
}
DENIED = ('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT', 'AUTHORITY_PACKET')
FALSE_FLAGS = ('matched', 'timingPassed', 'electricalTimingQualified', 'freshSource',
               'freshSourceCoreDerived', 'nativeExecuted', 'cadExecuted', 'all49Accepted', 'fabricationReady')
EXPECTED_OWNERS = {'source_trace_' + str(i) for i in range(49)}
RUNS = {
    253: RUN,
    254: Path('/tmp/g350-cap8-pdn49-projector-root-20261016-run254'),
    255: Path('/tmp/g350-cap8-pdn49-capture-root-20261016-run255'),
    256: Path('/tmp/g350-cap8-pdn49-core-root-20261016-run256'),
    257: Path('/tmp/g350-cap8-pdn49-core-objloader-root-20261016-run257'),
    258: Path('/tmp/g350-cap8-pdn49-native-root-20261016-run258'),
    259: Path('/tmp/g350-cap8-pdn49-via-track-root-20261016-run259'),
}
PLAN = RUNS[254] / 'byte0-result.json'
PLAN_SHA = '30ade5ec6bcaebef1f06247d1f74183b7730b71910a750dc02ab934e4ba63343'
CAPTURE = RUNS[255] / 'byte0-result.json'
CAPTURE_SHA = '547bf292261c2e8840406d5a85ebfe1e6942c3ffcc274a1195a0e3cad66f3e2f'
RAW = Path('/tmp/g350-cap8-pdn49-core257-raw.json')
RAW_SHA = 'db3cc308c41304d57c37ca027de5bfa45379e149c1eb313940eed65050807d6d'
CONTROLS = RUNS[257] / 'byte0-result.json'
CONTROLS_SHA = 'cdfdef69b8e2893167d7a826dbc6dc9e2cdbd0491b17d0653dac1f2b0dfa36c6'
NATIVE = RUNS[258] / 'byte0-result.json'
NATIVE_SHA = '459a2091a5a6d42668cea3aca08959b50086810a4d28055fb5c67d11784face5'
AUTH = RUNS[259] / 'byte0-result.json'
AUTH_SHA = 'bd06f6163f4ae2258e375f67b0b55ee562bbb2071d58dd6952176ee03704166a'
AUDIT = Path('/tmp/g350-source257-all14-literal-pour-margin-root-20261016.json')
AUDIT_SHA = 'f9ed9e3a96a37f55066e29ae8201593660cd9c5e490b9fa71be2cef1616715d4'
AGGREGATE = Path('/tmp/g350-source257-all14-literal-pour-margin-root-aggregate-20261016.json')
AGGREGATE_SHA = 'd4057031810c822309cd0a0e45f329e3f70ae6ade8c47381946ce892dcdb3352'
PDN_NEGATIVE = Path('/tmp/g350-source257-new-pdn-same-polygon-root-20261016.json')
PDN_NEGATIVE_SHA = 'a7e83cfb76a258eb211b00e962c74ce7ba46f60a1aa864bb53f61eea43deece8'
PDN_NEGATIVE_SOURCE = Path('/tmp/g350-plan254-fresh-two-pdn-same-polygon-contact-sourceonly.py')
PDN_NEGATIVE_SOURCE_SHA = 'c437815a3ac2f486d7c0540835517a6ebfd0147a096db927643d986267d52081'
OBJ_WRAPPER = Path('/tmp/g350-cap12-cap8-two-pdn-partial-capture-core-v2-exact-obj-loader-root-sourceonly.ts')
OBJ_WRAPPER_SHA = '1174b5e84e23c1e47c56d0535657638e10260b76189e36a098056db7027c949f'
PINS.update({str(p): pin for p, pin in ((PLAN, PLAN_SHA), (CAPTURE, CAPTURE_SHA),
    (RAW, RAW_SHA), (CONTROLS, CONTROLS_SHA), (NATIVE, NATIVE_SHA), (AUTH, AUTH_SHA),
    (AUDIT, AUDIT_SHA), (AGGREGATE, AGGREGATE_SHA), (PDN_NEGATIVE, PDN_NEGATIVE_SHA),
    (PDN_NEGATIVE_SOURCE, PDN_NEGATIVE_SOURCE_SHA), (OBJ_WRAPPER, OBJ_WRAPPER_SHA))})
PDN_CONTACT = Path('/tmp/g350-source257-new-pdn-annular-same-polygon-root-20261016.json')
PDN_CONTACT_SHA = '4a423b52960f51280b7923a39519ddd634f11b84b32c37ee47309354847931ea'
PDN_CONTACT_SOURCE = Path('/tmp/g350-plan254-source257-fresh-two-pdn-same-polygon-annular-contact-v2-sourceonly.py')
PDN_CONTACT_SOURCE_SHA = '5fb559c76e9bd410f392eae5a30e5e209c4bdd278bb0e5310b287a5779a98a3e'
PINS.update({str(PDN_CONTACT): PDN_CONTACT_SHA, str(PDN_CONTACT_SOURCE): PDN_CONTACT_SOURCE_SHA})
OBJ_ASSET = ROOT / '.cloud-tools/ti-ddr-v10-ca-top-bytes-bottom-prefork-successor-next/source/imports/USBLC6_2SC6/USBLC6_2SC6.obj'
OBJ_ASSET_SHA = 'b4a68fd1399fd2ab9e7baf51fd4bb6dd8b2a8be45c2b632e1f2c84723c5d7e45'
PINS[str(OBJ_ASSET)] = OBJ_ASSET_SHA
STEP_ASSET = OBJ_ASSET.with_suffix('.step')
STEP_ASSET_SHA = '53901e8dbe77366e4c00f90fd3613933fd2db1f1453ddc9eee51d8a18d44dbff'
ASSETS = {OBJ_ASSET: {'sha256': OBJ_ASSET_SHA, 'bytes': 565628},
          STEP_ASSET: {'sha256': STEP_ASSET_SHA, 'bytes': 3277419}}
PREPARED_V3 = Path('/tmp/g350-cap12-cap8-two-pdn-partial-capture-core-v3-exact-obj-step-loaders-root-sourceonly.ts')
PREPARED_V3_SHA = 'df7e38369721152c4d8bb1930a4f55aba4ebf03904f93962e0b53d4935ae661f'
PLOT_SOURCE = Path('/tmp/g350-plot-source257-cap12-cap8-pdn-manual49-v2-root-sourceonly.py')
PLOT_SOURCE_SHA = '6685d27107bf15b3d6a69fe3147e0ca2ecfca9f2789f141500d9819f1cfb0928'
PLOT_DIR = Path('/tmp/g350-source257-manual49-root-20261016-plot')
PLOT_PINS = {
    'SOURCE257_CAP12_CAP8_PDN_CONNECTED49_FOUR_LAYER_MILESTONE.png': '3f8a1cf187722aa699bea445c0262ce23977b86d9b8f10d6fc4d1216ca7dd99a',
    'SOURCE257_CAP12_CAP8_PDN_CONNECTED49_FOUR_LAYER_MILESTONE.svg': '80a767e98b70bfc7bbfe5346b1ff0b9779c9de2fe4ee73ccf3cad22c90cf60e0',
}
PINS.update({str(STEP_ASSET): STEP_ASSET_SHA, str(PREPARED_V3): PREPARED_V3_SHA,
             str(PLOT_SOURCE): PLOT_SOURCE_SHA, **{str(PLOT_DIR / name): pin for name, pin in PLOT_PINS.items()}})
ALIAS_SOURCES = [
    ('byte0-result.candidate.json', CURRENT), ('byte0-result.json', REPORT),
    ('route-plan.json', PLAN), ('source-capture.json', CAPTURE), ('raw-core.json', RAW),
    ('core-controls.json', CONTROLS), ('native-focused16.json', NATIVE), ('via-owner234.json', AUTH),
    ('literal-pour-audit-all14.json', AUDIT), ('literal-pour-aggregate-all14.json', AGGREGATE),
    ('new-pdn-annular-contact.json', PDN_CONTACT), ('new-pdn-original-full-held-disk-negative.json', PDN_NEGATIVE),
]
RESERVED_ALIASES = {name for name, _ in ALIAS_SOURCES}
METADATA_NAMES = {'README.md', 'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
RESERVED_NAMES = RESERVED_ALIASES | METADATA_NAMES
FAILED_COLLECTOR = Path('/tmp/g350-persist-post252-final259-source257-sourceonly.py')
FAILED_COLLECTOR_SHA = 'c607f326bd95284b225323a5d666a5a6724cd5d148efe23a52064c25296975f6'
FAILED_PROFILE = Path('/tmp/g350-post252-source257-checkpoint-profile-v3-final-sourceonly.json')
FAILED_PROFILE_SHA = 'ce67dc672a620ea2af3552473844c729acb060552e3b75195fa9d966e0f0149c'
PRESERVED_FAILED_DIRECTORY = ROOT / '.cloud-tools/ddr-four-layer-post252-failed-alias-save-2026-10-16'
FAILED_RECEIPT = Path('/tmp/g350-source257-collector-c607-failed-alias-root-20261016.json')
FAILED_RECEIPT_SHA = 'cbe22c66a1e8aa642c3b01bd621ae6d2b088efd5b8d942ccf6807d99724319e5'
PINS.update({str(FAILED_COLLECTOR): FAILED_COLLECTOR_SHA, str(FAILED_PROFILE): FAILED_PROFILE_SHA,
             str(FAILED_RECEIPT): FAILED_RECEIPT_SHA})


def require(value, message):
    if not value:
        raise ValueError(message)


def drop(fd):
    if hasattr(os, 'posix_fadvise'):
        os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
        drop(stream.fileno())
    return h.hexdigest()


def read(p):
    with p.open('rb') as stream:
        value = json.load(stream)
        drop(stream.fileno())
    return value


def regular(p):
    return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)


def safe_public(p):
    return (p.is_absolute() and str(p).startswith('/tmp/g350-')
            and p.resolve().is_relative_to('/tmp')
            and not any(term in str(p).upper() for term in DENIED))


def safe_evidence(p):
    # Two immutable non-code model assets are saved separately from /tmp restore
    # targets. The compatible legacy helper does not restore workspace assets.
    return safe_public(p) or (p in ASSETS and p.resolve() == p.absolute()
                              and regular(p) and p.stat().st_size == ASSETS[p]['bytes']
                              and digest(p) == ASSETS[p]['sha256'])


def metadata(p):
    s = p.stat()
    return {'bytes': s.st_size, 'sha256': digest(p), 'mode': stat.S_IMODE(s.st_mode)}


def verify_rows(folder, rows):
    seen = set()
    for row in rows:
        relative = Path(row['path'])
        p = folder / relative
        require(row['path'] not in seen and not relative.is_absolute() and '..' not in relative.parts
                and p.resolve().is_relative_to(folder.resolve()) and regular(p)
                and metadata(p) == {k: row[k] for k in ('bytes', 'sha256', 'mode')},
                'Frozen payload bytes/mode changed: ' + str(p))
        seen.add(row['path'])


def verify_base():
    require(BASE.is_dir() and not BASE.is_symlink(), 'Read-only frozen Source248 dependency')
    for name, pin in BASE_PINS.items():
        require(regular(BASE / name) and digest(BASE / name) == pin, 'Frozen post232 metadata changed')
    index = read(BASE / 'WORKSPACE_HASH_INDEX.json')
    require(index['frozenCheckpoint'] is True and len(index['files']) == 193,
            'Exact frozen closed252+all14+plot Source248 inventory')
    verify_rows(BASE, index['files'])
    require(regular(BASE_MANIFEST) and digest(BASE_MANIFEST) == BASE_MANIFEST_SHA,
            'Exact frozen Source248 archive manifest')
    archive = read(BASE_MANIFEST)['archive']
    ap = ROOT / archive['path']
    require(not Path(archive['path']).is_absolute() and '..' not in Path(archive['path']).parts
            and ap.resolve().is_relative_to(ROOT.resolve()) and regular(ap)
            and archive['sha256'] == BASE_ARCHIVE_SHA and archive['bytes'] == 11222356
            and ap.stat().st_size == archive['bytes'] and digest(ap) == BASE_ARCHIVE_SHA,
            'Frozen Source248 archive bytes unchanged; never copied by collector')


def owner(t):
    # Physical qualification rows use owner; actual trace rows use the two
    # canonical fields above it. This fixes the unexecuted draft's roster guard.
    return t.get('connection_name') or t.get('source_trace_id') or t.get('owner')


def exact_roster(rows, expected, message):
    actual = [owner(t) for t in rows]
    require(len(actual) == len(expected) and len(set(actual)) == len(actual) and set(actual) == expected, message)


def verify_model():
    c, r, d, anchor = read(CURRENT), read(REPORT), read(DESCRIPTOR), read(ANCHOR)
    closed, execution = read(RUN / 'COLLECTED.json'), read(RUN / 'owned/execution.json')
    require(closed['scope'] == 253 and closed.get('closedAt') and closed['execution'] == execution
            and closed['sourcePinsUnchanged'] is True and closed['protectedFilesUnchanged'] is True
            and execution['exitCode'] == 0 and execution['cleanupOwnedGroupEmpty'] is True
            and execution['diagnosticStopped'] is False and not execution['stopReasons']
            and execution['command'][1] == str(WORKER) and closed['all49Accepted'] is False,
            'Exact CLOSED253 physical-only receipt')
    for packet in (r, c):
        require(packet['all49Connected'] is True and packet['allSavedCarriersCurrentSceneQualified'] is True
                and packet['beforeCurrent48Qualified'] is True
                and all(packet[k] is False for k in FALSE_FLAGS), '49 connected model, all qualification boundaries retained')
        exact_roster(packet['finalScenePhysicalReports'], EXPECTED_OWNERS, 'All49 unique current-scene physical reports')
        require(all(q['passed'] is True for q in packet['finalScenePhysicalReports'])
                and len(packet['changedJoinedSignalPhysicalReports']) == 4
                and all(q['passed'] is True for q in packet['changedJoinedSignalPhysicalReports'])
                and len(packet['criticalValidationViews']) == 2
                and all(q['passed'] is True and q['c31']['solved'] is True
                        and set(q['reports']) == {'bus', 'pair', 'shared', 'coupling', 'exterior'}
                        and all(len(rows) == 3 and all(v['matched'] is True for v in rows)
                                for rows in q['reports'].values()) for q in packet['criticalValidationViews'])
                and all(len(packet[key]) == 2 and all(v['passed'] is True for v in packet[key])
                        for key in ('powerReferencePhysicalReports', 'movedCap8PadFixedCopperPreflight',
                                    'plannedPdnViaPhysicalReports')),
                'Fresh49/4joins/2criticalviews/2references/2pads/2plannedPDN gates')
    require(r['connectedCount'] == 49 and r['remaining'] == [] and c['missingOwnerIds'] == []
            and c['planningOnly'] is False and c['sourceCapPlacementStillPending'] is True
            and c['actualPdnPlaneGraphQualificationPending'] is True and c['futureNewPdnFreshIds'] is None
            and c['dormantWorkingBarrels'] == [] and c['workingBarrelPhysicalJoinAudit']['passed'] is True,
            'Complete model only; fresh Source placement/PDN graph explicitly pending')
    exact_roster(c['carrierTraces'], EXPECTED_OWNERS, 'Literal49 carrier roster')
    exact_roster(c['joinedNumericPadTraces'], EXPECTED_OWNERS, 'Literal49 numeric joined roster')
    require(len(c['heldCarrierTraces']) == 6 and len(c['ordinaryCarrierTraces']) == 43
            and c['heldCarrierTraces'] == anchor['heldCarrierTraces']
            and len(c['full49FanoutInput']['connections']) == 49
            and len(c['full49FanoutInput']['traces']) == 263
            and len(c['full49FanoutInput']['obstacles']) == 1300
            and all(c['full49FanoutInput'][k] == anchor['full49FanoutInput'][k]
                    for k in ('buses', 'differentialPairs')), 'Exact original49 rules, six held bodies and declared263/1300 foundation')
    require(c['inputBindings'] == r['inputBindings'] and c['cap8PlacementInverse'] == r['cap8PlacementInverse'] == d
            and c['requiredSourceHardwarePlacementDeltas'] == [anchor['cap12PlacementInverse'], d]
            and c['cap8PdnInsertions'] == d['cap8PdnInsertions'] and len(d['cap8PdnInsertions']) == 2
            and c['sourceReferenceTargetInverses'] == d['sourceReferenceTargetInverses']
            and len(c['sourceReferenceTargetInverses']) == 2, 'Complete cap12+cap8/PDN plural descriptor and reference targets')
    delta = r['constructorFoundationDelta']
    require(delta['sourcePacketSha256'] == ANCHOR_SHA and delta['exactExpectedEqualityPassed'] is True
            and delta['finalPhysicalObstacles'] == 1300 and delta['plannedNewFullspanPdnNodes'] == 2
            and delta['futureNewPdnFreshIds'] is None and delta['cpuBranchesChanged'] == ['source_trace_2', 'source_trace_11']
            and delta['bodyOwnersChanged'] == ['source_trace_2', 'source_trace_11', 'source_trace_35', 'source_trace_42']
            and delta['referenceTracesChanged'] == ['pcb_trace_156', 'pcb_trace_157']
            and delta['other163ReferencesLiteral'] is True and delta['critical169SixLiteral'] is True,
            'Latest253 delta comes from exact report, not candidate inherited stale constructorFoundationDelta')
    require(c['workingChanges'][-1]['cpuFanoutInverses'] == r['cpuFanoutInverses']
            and c['workingChanges'][-1]['d12EndpointInverses'] == r['d12EndpointInverses']
            and c['workingChanges'][-1]['bodyInverses'] == r['bodyInverses'], 'Latest CPU/D12/body inverse ledger exact')
    observations = r['originalBusConstraintObservations']
    require([o['originalRule'] for o in observations] == c['full49FanoutInput']['buses']
            and all(o['allMembersPresent'] is True and o['missingOwners'] == [] for o in observations)
            and sum(any(v['kind'] == 'ORIGINAL_MAX_LENGTH_SKEW' for v in o['violations']) for o in observations) == 3,
            'All49 literal constraints measured; exactly three failing bus skews retained')
    wanted = {'DDR_BYTE0': 6.655202281574553, 'DDR_BYTE1': 2.4000719198310776,
              'DDR_COMMAND_CLOCK': 17.43870093419864}
    for o in observations:
        bus = o['originalRule']['busId']
        if bus in wanted:
            require(math.isfinite(o['observedSkewMm']) and abs(o['observedSkewMm'] - wanted[bus]) <= 1e-10,
                    'Exact253 original bus skew observation')
    require(len(r['originalPairConstraintObservations']) == 3
            and all(o['lengthToleranceSatisfied'] is True and o['missingOwners'] == []
                    for o in r['originalPairConstraintObservations']), 'Original three pair length observations pass independently')
    return c, r, d, closed, execution


def write_json(p, value):
    with p.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        os.fchmod(stream.fileno(), 0o600)


def verify_source257():
    plan, capture, controls = read(PLAN), read(CAPTURE), read(CONTROLS)
    native, auth, raw = read(NATIVE), read(AUTH), read(RAW)
    audit, aggregate, negative, pdn = read(AUDIT), read(AGGREGATE), read(PDN_NEGATIVE), read(PDN_CONTACT)
    receipts = []
    for scope, folder in RUNS.items():
        closed, execution = read(folder / 'COLLECTED.json'), read(folder / 'owned/execution.json')
        require(closed['scope'] == scope and closed.get('closedAt') and closed['execution'] == execution
                and closed['sourcePinsUnchanged'] is True and closed['protectedFilesUnchanged'] is True
                and execution['cleanupOwnedGroupEmpty'] is True and execution['diagnosticStopped'] is False,
                'Closed public scope receipt and exact execution: ' + str(scope))
        if scope == 256:
            require(execution['exitCode'] == 1 and not (folder / 'byte0-result.json').exists()
                    and not Path('/tmp/g350-cap8-pdn49-core256-raw.json').exists(),
                    'Failed256 OBJ loader attempt has no raw/control geometry evidence')
        else:
            require(execution['exitCode'] == 0 and regular(folder / 'byte0-result.json'), 'Passed closed scope: ' + str(scope))
        receipts.append({'scope': scope, 'closedAt': closed['closedAt'], 'exitCode': execution['exitCode'],
                         'qualificationState': 'FAILED_BEFORE_FRESH_CORE_GEOMETRY_OBJ_LOADER' if scope == 256 else 'CLOSED_SCOPED_PASS',
                         'folder': folder})
    require(plan['inputBindings']['candidate']['sha256'] == CURRENT_SHA
            and plan['hardwareDeltaProfile'] == 'CAP12_X0P79_CAP8_TWO_NEW_PDN_VIAS'
            and len(plan['newVias']) == 103 and len(plan['innerPortRegistrations']) == 80
            and len(plan['projectedGeometry']) == 49 and plan['pendingOwnerIds'] == []
            and plan['auxiliaryLocalTraces'] == [] and len(plan['cap8HardwareDelta']['pdnVias']) == 2
            and len(plan['cap8HardwareDelta']['innerPortRegistrations']) == 4,
            'Exact plan254 full49 with103 signal barrels and2 new PDN barrels')
    require(capture['passed'] is True and capture['fullInverseSourceTreePassed'] is True
            and capture['parentNormalizationInversePassed'] is True and capture['planSha256'] == PLAN_SHA
            and capture['candidateSha256'] == CURRENT_SHA, 'Exact capture255 and full literal/key inverse')
    expected = {'physicalVias': 234, 'pcbComponents': 514, 'sourceAndPcbPorts': 1713,
        'sourceTraces': 1097, 'physicalTraces': 317, 'reactElements': 2225, 'registeredInnerPorts': 84,
        'newVias': 105, 'newSignalVias': 103, 'newPdnVias': 2, 'newInnerPorts': 84,
        'newSignalInnerPorts': 80, 'newPdnInnerPorts': 4, 'newWireRuns': 152, 'routedWireRuns': 152,
        'auxiliaryWireRuns': 0, 'auxiliaryLocalTraces': 0, 'routedOwners': 49, 'pendingOwners': 0}
    require(controls['rawCoreSha256'] == RAW_SHA and controls['planSha256'] == PLAN_SHA
            and controls['candidateSha256'] == CURRENT_SHA and controls['actualCaptureSha256'] == CAPTURE_SHA
            and controls['freshCoreDerived'] is True and controls['freshCoreControlPassed'] is True
            and controls['partialDiagnosticReplayControlsPassed'] is True and controls['all49Connected'] is True
            and len(controls['checks']) == 35 and all(q['passed'] is True for q in controls['checks'])
            and controls['expectedCounts'] == expected and controls['expectedConnectedOwners'] == 49
            and controls['expectedPendingOwners'] == 0 and controls['pendingOwnerIds'] == [],
            'Actual fresh Core257 all35 and exact234/514/1713/1097/317/2225 inventory')
    require(len(controls['physicalGraphs']) == 49
            and {r['originalSourceTraceId'] for r in controls['physicalGraphs']} == EXPECTED_OWNERS
            and all(r['physicallyConnectedByActualOwnedNumericIdGraph'] is True for r in controls['physicalGraphs']),
            'All49 authentic owned numeric graphs connected')
    require(controls['cap12HardwareDelta'] == plan['cap12HardwareDelta']
            and controls['cap8HardwareDelta'] == plan['cap8HardwareDelta']
            and controls['cap8HardwareDelta']['originalDeclaration'] == read(DESCRIPTOR), 'Exact hardware ledgers carry into fresh Core controls')
    results = {r['name']: r for r in native['results']}
    require(native['completed'] is True and native['finished'] is True and native['completedCheckCount'] == 16
            and native['exceptionCount'] == 0 and native['allPinnedInputsUnchanged'] is True
            and native['all32FreshNativeChecksExecuted'] is False and len(results) == 16
            and len(native['physical10']) == 10
            and all(results[n]['state'] == 'completed' and results[n]['findingCount'] == 0 for n in native['physical10'])
            and results['checkPcbBusLengthSkew']['findingCount'] == 3
            and all(r['state'] == 'completed' and r['findingCount'] == 0
                    for n, r in results.items() if n != 'checkPcbBusLengthSkew')
            and native['inputBindings']['raw']['sha256'] == RAW_SHA
            and native['inputBindings']['controls']['sha256'] == CONTROLS_SHA
            and native['inputBindings']['reviewedSourcePlan']['sha256'] == PLAN_SHA,
            'Native258 focused16/physical10 clear; allthree original skew findings retained')
    require(auth['scope'] == 'EXPLICITLY_PINNED_M49_PLAN254_CAP12_CAP8_TWO_PDN_AUTHENTICATED_234_MANUAL_VIA_TRACK_MANUFACTURING_DIAGNOSTIC'
            and auth['complete'] is True and auth['executed'] is True and auth['actualViaCount'] == 234
            and auth['completedViaCount'] == 234 and auth['foreignViaTrackCopperClearancePassed'] is True
            and auth['exactInputFilesUnchanged'] is True
            and all(auth[k] == [] for k in ('violations', 'ambiguousVias', 'identityFailures', 'invalidSegments', 'unresolvedSegmentOwners'))
            and len(auth['pdnIdentityProofs']) == 2 and all(q['passed'] is True for q in auth['pdnIdentityProofs'])
            and auth['inputBindings']['raw']['sha256'] == RAW_SHA
            and auth['inputBindings']['controls']['sha256'] == CONTROLS_SHA
            and auth['inputBindings']['plan']['sha256'] == PLAN_SHA
            and auth['inputBindings']['candidate']['sha256'] == CURRENT_SHA,
            'Auth259 strict genuine234 ownership and unfiltered foreign via-track results passed')
    pour_ids = [p['pcb_copper_pour_id'] for p in raw if p.get('type') == 'pcb_copper_pour']
    require(len(pour_ids) == 14 and len(set(pour_ids)) == 14
            and sum(v.get('type') == 'pcb_via' for v in raw) == 234,
            'Actual Source25714-pour/234-via inventory')
    for d in (audit, aggregate):
        b = d['inputBindings']
        require(d['completed'] is True and d['literalForeignPourMarginClear'] is True
                and d['actualRawPourCount'] == 14 and d['actualRawPourIds'] == pour_ids
                and d['actualViaCount'] == 234 and d['wireSegmentCount'] == 979 and d['inputFilesUnchanged'] is True
                and d['requiredForeignViaPourEdgeMm'] == d['requiredForeignWirePourEdgeMm'] == .1016
                and d['coordinateToleranceMm'] == 1e-8 and d['violations'] == [] and d['unsupportedGeometry'] == []
                and b['raw']['sha256'] == RAW_SHA and b['controls']['sha256'] == CONTROLS_SHA
                and b['current234Ownership']['sha256'] == AUTH_SHA and b['reviewedSourcePlan254']['sha256'] == PLAN_SHA
                and d['source248GeometryOrPourQualificationInherited'] is False
                and all(d[k] is False for k in ('all49Accepted', 'fullBoardPassed', 'electricalTimingQualified',
                    'ownNetReentryQualified', 'referenceWireGeometryIncluded', 'nativeExecuted', 'cadExecuted', 'fabricationReady')),
                'Exact Source257 all14/234/979 literal foreign edge-margin pass; no prior inheritance')
    require(audit['allActualPoursCompleted'] is True and audit['selectedPourIds'] == pour_ids
            and audit['omittedPourIds'] == [] and len(audit['pourReports']) == 14
            and aggregate['completedPourCount'] == 14 and aggregate['completedPourIds'] == pour_ids
            and aggregate['wireOwnerCount'] == 49 and aggregate['candidate253Sha256'] == CURRENT_SHA
            and aggregate['inputBindings']['report_0']['sha256'] == AUDIT_SHA
            and aggregate['allCompletedComparisonRostersReconstructedFromExactRaw'] is True
            and aggregate['sameExactRawControlsAuthAcrossAllContributions'] is True
            and aggregate['identityFailures'] == [] and aggregate['excludedBoundedPartialReports'] == [],
            'All14 complete comparison/exemption rosters independently aggregated')
    require(negative['scope'] == 'PLAN254_FRESH234_TWO_NEW_PDN_FULL_LAND_SAME_FILLED_POLYGON_CONTACT_PROOF'
            and negative['passed'] is False and negative['newPdnLocalPlaneContactsQualified'] is False
            and negative['exactInputFilesUnchanged'] is True and len(negative['errors']) == 1
            and negative['errors'][0]['kind'] == 'NO_SINGLE_FRESH_FILLED_POLYGON_CONTAINS_BOTH_FULL_NEW_PDN_LAND_AND_FULL_AUTHENTIC_HELD_SAME_NET_REFERENCE_LAND'
            and negative['inputBindings']['raw']['sha256'] == RAW_SHA
            and negative['inputBindings']['auth']['sha256'] == AUTH_SHA,
            'Keep original overstrong full-held-disk negative proof unchanged; no annular-proof waiver')
    require(pdn['scope'] == 'PLAN254_SOURCE257_TWO_NEW_PDN_FULL_LAND_PLUS_HELD_ANNULAR_BAND_SAME_FILLED_POLYGON_CONTACT_PROOF'
            and pdn['passed'] is True and pdn['newPdnLocalPlaneContactsQualified'] is True
            and pdn['errors'] == [] and pdn['exactInputFilesUnchanged'] is True
            and pdn['actualViaCount'] == 234 and pdn['heldOriginalReferenceViaCount'] == 129
            and pdn['candidateBinding']['sha256'] == CURRENT_SHA
            and len(pdn['newPdnPlaneContactResults']) == 2
            and {r['sourceViaName'] for r in pdn['newPdnPlaneContactResults']} == {'V_CAP8_REPLAY_DDR_1V5', 'V_CAP8_REPLAY_GND'}
            and all(r['passed'] is True and any(t['passed'] is True for t in r['polygonTrials'])
                    for r in pdn['newPdnPlaneContactResults'])
            and pdn['geometryOrManufacturingRulesChanged'] is False
            and all(pdn[k] is False for k in ('regeneratedPlaneContinuityQualified', 'ddrReferencePlaneContinuityQualified',
                        'wholeBoardPassed', 'electricalTimingQualified', 'cadQualified', 'all49Accepted', 'fabricationReady')),
            'Separate exact two-PDN local annular/full-land polygon contact pass, not complete DDR reference continuity')
    for key, pin in (('raw', RAW_SHA), ('controls', CONTROLS_SHA), ('auth', AUTH_SHA), ('plan', PLAN_SHA), ('descriptor', DESCRIPTOR_SHA)):
        require(pdn['inputBindings'][key]['sha256'] == pin, 'Positive PDN contact proof binds current actual Source257')
    require(regular(OBJ_ASSET) and OBJ_ASSET.stat().st_size == 565628 and digest(OBJ_ASSET) == OBJ_ASSET_SHA
            and digest(OBJ_WRAPPER) == OBJ_WRAPPER_SHA, 'Exact actual257 loader and immutable original OBJ asset')
    return {'plan': plan, 'capture': capture, 'controls': controls, 'native': native, 'auth': auth,
            'audit': audit, 'aggregate': aggregate, 'negative': negative, 'pdn': pdn, 'pourIds': pour_ids, 'receipts': receipts}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile', default='/tmp/g350-post252-source257-checkpoint-profile-v4-final-sourceonly.json')
    parser.add_argument('--profile-sha', required=True)
    args = parser.parse_args()
    profile_path = Path(args.profile)
    require(safe_public(profile_path) and regular(profile_path)
            and re.fullmatch('[0-9a-f]{64}', args.profile_sha) and digest(profile_path) == args.profile_sha,
            'Explicit reviewed profile path and exact byte SHA required')
    profile = read(profile_path)
    require(profile['scope'] == 'POST252_SOURCE257_ALL49_SCOPED_CORE_NATIVE_AUTH_LITERAL_POURS_PROFILE'
            and profile['candidateSha256'] == CURRENT_SHA and profile['reportSha256'] == REPORT_SHA
            and profile['freshSourceCorePending'] is False and profile['nativePending'] is False
            and profile['authenticatedViaTrackPending'] is False and profile['literalPoursPending'] is False
            and profile['pdnLocalContactPending'] is False and profile['reviewedPlotPending'] is False
            and profile['frozenCheckpoint'] is True,
            'Source257 final scoped checkpoint and Root-rendered/reviewed plot; full timing and board qualification remain false')
    require(not SAVED.exists(), 'New post252 folder must be absent; later append needs separate reviewed Source')
    verify_base()
    all_pins = dict(PINS)
    for row in profile['artifacts']:
        p, pin = Path(row['path']), row['sha256']
        require(safe_evidence(p) and regular(p) and re.fullmatch('[0-9a-f]{64}', pin)
                and (str(p) not in all_pins or all_pins[str(p)] == pin)
                and metadata(p) == {k: row[k] for k in ('bytes', 'sha256', 'mode')},
                'Explicit public profile artifact byte/hash/mode pin')
        all_pins[str(p)] = pin
    for name, pin in all_pins.items():
        require(safe_evidence(Path(name)) and regular(Path(name)) and digest(Path(name)) == pin,
                'Exact public model253 artifact: ' + name)
    candidate, report, descriptor, closure, execution = verify_model()
    current = verify_source257()
    failure = read(FAILED_RECEIPT)
    require(failure['source'] == str(FAILED_COLLECTOR) and failure['sha256'] == FAILED_COLLECTOR_SHA
            and failure['profileSha256'] == FAILED_PROFILE_SHA and failure['exitCode'] == 1
            and failure['failedPartialPreserved'] == str(PRESERVED_FAILED_DIRECTORY)
            and failure['oldFrozenFoldersUnchanged'] is True and failure['fabricationReady'] is False,
            'Exact Root receipt for failed pre-metadata alias publication')
    require(PRESERVED_FAILED_DIRECTORY.is_dir() and not PRESERVED_FAILED_DIRECTORY.is_symlink()
            and not any((PRESERVED_FAILED_DIRECTORY / name).exists() for name in METADATA_NAMES),
            'Preserved failed partial has no successful saved-workspace metadata')
    failed_rows = [{'path': p.name, **metadata(p)} for p in sorted(PRESERVED_FAILED_DIRECTORY.iterdir()) if regular(p)]
    require(len(failed_rows) == 89 and len(list(PRESERVED_FAILED_DIRECTORY.iterdir())) == 89,
            'Exact89 public failed-attempt payloads preserved read-only')
    verify_rows(PRESERVED_FAILED_DIRECTORY, failed_rows)
    base_progress, base_restore = read(BASE / 'PROGRESS.json'), read(BASE / 'WORKSPACE_RESTORE_MANIFEST.json')
    require(base_progress['frozenCheckpoint'] is True and base_progress['latestClosedScopeIncluded'] == 252
            and base_progress['latestSourceVerifiedCheckpoint']['routedOwners'] == 48,
            'Frozen Source24848 fallback preserved, including failed247 closure')
    catalog = {r['restorePath']: copy.deepcopy(r) for r in base_restore['baseDependencyRestoreFiles']}
    for r in base_restore['files']:
        catalog[r['restorePath']] = {'baseSavedDirectory': BASE.relative_to(ROOT).as_posix(), **copy.deepcopy(r)}
    targets, bases, inputs, sources, workspace_assets = {}, {}, {}, set(), {}
    SAVED.mkdir(parents=True, exist_ok=False)

    def save(p, name=None, force=False):
        p = Path(p)
        require(safe_evidence(p) and regular(p), 'Only regular public /tmp inputs and two exact immutable OBJ/STEP assets')
        before, data = p.stat(), metadata(p)
        inputs[str(p)] = data
        if str(p) in workspace_assets:
            require(data == {k: workspace_assets[str(p)][k] for k in data}, 'Immutable asset source unchanged')
            return workspace_assets[str(p)]
        if str(p) in targets:
            require(data == {k: targets[str(p)][k] for k in data}, 'Collected restore target changed')
            return targets[str(p)]
        base_row = catalog.get(str(p))
        if not force and base_row and data == {k: base_row[k] for k in data}:
            bases[str(p)] = copy.deepcopy(base_row)
            return {'baseDependencyOnly': True, **copy.deepcopy(base_row)}
        dest = SAVED / (name or p.name)
        require(dest.parent == SAVED, 'Safe flat saved filename')
        # Dependency filenames are not current-checkpoint aliases. Reserve the
        # complete alias set before copying anything, including the old243
        # candidate and raw-core/controls/capture dependencies. Never overwrite.
        if dest.name in RESERVED_NAMES:
            dest = dest.with_name('DEPENDENCY_' + data['sha256'][:16] + '_' + dest.name)
        if dest.exists() and metadata(dest) != data:
            dest = dest.with_name(dest.stem + '__' + data['sha256'][:16] + dest.suffix)
        if not dest.exists():
            with p.open('rb') as reader, dest.open('xb') as writer:
                shutil.copyfileobj(reader, writer, 1024 * 1024)
                os.fchmod(writer.fileno(), data['mode'])
                drop(reader.fileno())
        after = p.stat()
        require((before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
                (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
                and metadata(dest) == data, 'Stable source copy with exact mode/hash')
        row = {'savedPath': dest.name, 'restorePath': str(p), **data}
        if p in ASSETS:
            workspace_assets[str(p)] = {**row, 'boardRelativePath': p.relative_to(ROOT).as_posix(),
                'restoreMethod': 'EXACT_ARCHIVE_MEMBER_OR_EXPLICIT_BYTE_MODE_COPY_AFTER_HASH_VERIFICATION',
                'legacySavedWorkspaceHelperRestoresThisAsset': False, 'existingAssetNeverOverwrittenByCollector': True}
            return workspace_assets[str(p)]
        targets[str(p)] = row
        bases.pop(str(p), None)
        return row

    for name in all_pins:
        p = Path(name)
        run_scope = next((scope for scope, folder in RUNS.items() if p.is_relative_to(folder)), None)
        label = None if run_scope is None else ('MODEL253_' if run_scope == 253 else 'SOURCE257_SCOPE' + str(run_scope) + '_') + ('owned_' if p.parent.name == 'owned' else '') + p.name
        force = run_scope is not None or p in (WORKER, DESCRIPTOR, OBJ_ASSET, STEP_ASSET, PREPARED_V3, PLOT_SOURCE) or p.parent == PLOT_DIR
        save(p, label, force)
        if p.suffix in ('.py', '.ts', '.tsx', '.mjs') and p != Path(__file__):
            sources.add(p)
    save(profile_path, force=True)
    save(Path(__file__), force=True)
    excluded = set()
    visited = set()
    for _ in range(3):
        following = set()
        for p in sorted(sources - visited):
            visited.add(p)
            for literal in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]", p.read_text()):
                q = Path(literal)
                if not safe_public(q):
                    excluded.add(str(q))
                    continue
                if regular(q):
                    save(q)
                    if q.suffix in ('.py', '.ts', '.tsx', '.mjs'):
                        following.add(q)
        sources |= following
    # Model/current-Source aliases all refer to exact253/Source257, not old248/233.
    aliases = {}
    require(all(not (SAVED / name).exists() for name in RESERVED_NAMES), 'Every canonical alias and metadata name reserved before dependency copying')
    for alias, source in ALIAS_SOURCES:
        row = targets[str(source)]
        dest = SAVED / alias
        with (SAVED / row['savedPath']).open('rb') as reader, dest.open('xb') as writer:
            shutil.copyfileobj(reader, writer, 1024 * 1024)
            os.fchmod(writer.fileno(), row['mode'])
        require(metadata(dest) == {k: row[k] for k in ('bytes', 'sha256', 'mode')}, 'Exact candidate/report alias')
        aliases[alias] = {'canonicalSavedPath': row['savedPath'], 'restorePath': str(source),
                          **{k: row[k] for k in ('bytes', 'sha256', 'mode')}}
    archive = read(BASE_MANIFEST)['archive']
    dependency = {**copy.deepcopy(archive), 'manifest': BASE_MANIFEST.relative_to(ROOT).as_posix(),
                  'manifestSha256': BASE_MANIFEST_SHA, 'mustBeRestoredFirst': True,
                  'payloadCopiedByThisCollector': False, 'priorDependencies': copy.deepcopy(base_progress['baseArchiveDependenciesInRestoreOrder'])}
    archives = copy.deepcopy(base_progress['baseArchiveDependenciesInRestoreOrder']) + [dependency]
    primary = {'scope': 'SOURCE257_CONNECTED49_SCOPED_CORE_NATIVE_AUTH_POUR_LOCAL_PDN_NOT_FULL_BOARD_QUALIFICATION',
               'modelReportScope': report['scope'], 'candidateSha256': CURRENT_SHA,
               'savedCandidate': 'byte0-result.candidate.json', 'routedOwners': 49, 'pendingOwnerIds': [],
               'modelAll49PhysicalPassed': True, 'bothCriticalViewsPassed': True,
               'changedJoinedChecksPassed': 4, 'powerReferencesPassed': 2, 'cap8PadsPassed': 2,
               'plannedPdnPhysicalNodesPassed': 2, 'freshSourceCorePending': False,
               'freshSource257All35Passed': True, 'freshSource257NumericConnectedCount': 49,
               'nativePending': False, 'focusedNative258Physical10Passed': True,
               'focusedNativeCheckCount': 16, 'other16NativeChecksNotRetested': True,
               'authenticatedViaTrackPending': False, 'authenticated234ViaTrack259Passed': True,
               'literalPoursPending': False, 'literalAll14PourForeignMarginsPassed': True,
               'newPdnLocalAnnularContactsPassed': True,
               'actualPdnPlaneGraphQualificationPending': True,
               'wholeDdrReferencePlaneContinuityQualified': False, 'reviewedPlotPending': False, 'busSkewFailureCount': 3,
               'fullTimingPassed': False, 'electricalTimingQualified': False, 'tiQualified': False,
               'referenceContinuityQualified': False, 'cadQualified': False,
               'defaultBoardPromoted': False, 'all49Accepted': False, 'fabricationReady': False}
    latest = {**copy.deepcopy(primary), 'candidate': copy.deepcopy(targets[str(CURRENT)]),
              'report': copy.deepcopy(targets[str(REPORT)]), 'resumeRoutingFromThisCheckpoint': True,
              'freshSourceDerived': True, 'coreScope': 257,
              'plan': copy.deepcopy(targets[str(PLAN)]), 'capture': copy.deepcopy(targets[str(CAPTURE)]),
              'raw': copy.deepcopy(targets[str(RAW)]), 'controls': copy.deepcopy(targets[str(CONTROLS)]),
              'native': copy.deepcopy(targets[str(NATIVE)]), 'authenticatedViaTrack': copy.deepcopy(targets[str(AUTH)]),
              'freshCoreExpectedCounts': copy.deepcopy(current['controls']['expectedCounts']),
              'source257TimingObservations': copy.deepcopy(current['controls']['timingObservations']),
              'originalBusConstraintObservations': copy.deepcopy(report['originalBusConstraintObservations']),
              'originalPairConstraintObservations': copy.deepcopy(report['originalPairConstraintObservations']),
              'latestConstructorFoundationDeltaFromReport': copy.deepcopy(report['constructorFoundationDelta']),
              'inheritedCandidateConstructorFoundationDeltaIsNotCurrent253Authority': True,
              'cap8PlacementInverse': copy.deepcopy(descriptor),
              'requiredSourceHardwarePlacementDeltas': copy.deepcopy(candidate['requiredSourceHardwarePlacementDeltas'])}
    scoped_pours = {'scope': current['aggregate']['scope'], 'report': copy.deepcopy(targets[str(AUDIT)]),
        'aggregate': copy.deepcopy(targets[str(AGGREGATE)]), 'literalForeignPourMarginClear': True,
        'actualPourCount': 14, 'actualPourIds': current['pourIds'], 'actualViaCount': 234,
        'routedWireSegmentCount': 979, 'routedWireOwnerCount': 49, 'requiredForeignEdgeClearanceMm': .1016,
        'minimumForeignEdgeGapMm': current['aggregate']['minimumForeignEdgeGapMm'],
        'source248GeometryOrPourQualificationInherited': False, 'referenceWireGeometryIncluded': False,
        'ownNetReentryQualified': False, 'referenceContinuityQualified': False,
        'all49Accepted': False, 'fabricationReady': False}
    pdn_contact = {'scope': current['pdn']['scope'], 'report': copy.deepcopy(targets[str(PDN_CONTACT)]),
        'source': copy.deepcopy(targets[str(PDN_CONTACT_SOURCE)]), 'newPdnLocalPlaneContactsQualified': True,
        'exactInputFilesUnchanged': True, 'newPdnNames': ['V_CAP8_REPLAY_DDR_1V5', 'V_CAP8_REPLAY_GND'],
        'actualPcbViaIds': [r['newPdnIdentity']['actualPcbViaId'] for r in current['pdn']['newPdnPlaneContactResults']],
        'priorStricterFullHeldDiskNegativeReport': copy.deepcopy(targets[str(PDN_NEGATIVE)]),
        'priorNegativeSource': copy.deepcopy(targets[str(PDN_NEGATIVE_SOURCE)]),
        'priorNegativeRetainedUnmodified': True, 'geometryOrManufacturingRulesChanged': False,
        'fullDdrReferencePlaneContinuityQualified': False, 'all49Accepted': False, 'fabricationReady': False}
    latest['literalPourCoverageAggregate'] = copy.deepcopy(scoped_pours)
    latest['newPdnLocalContactProof'] = copy.deepcopy(pdn_contact)
    plot = {'source': copy.deepcopy(targets[str(PLOT_SOURCE)]), 'rootRenderedAndViewed': True,
            'views': ['top', 'inner1', 'inner2', 'bottom'], 'routedOwners': 49, 'pendingOwnerIds': [],
            'candidateSha256': CURRENT_SHA, 'rawCoreSha256': RAW_SHA,
            'files': [copy.deepcopy(targets[str(PLOT_DIR / name)]) for name in PLOT_PINS],
            'all3BusSkewFailuresExplicit': True, 'all49Accepted': False, 'fabricationReady': False}
    latest['reviewedFourLayerPlot'] = copy.deepcopy(plot)
    latest['caMinimumPassingCount'] = sum(g['cohort'] == 'DDR_COMMAND_CLOCK'
            and g['timingObservationOnly']['aboveMinimum'] is True for g in current['controls']['generatedWireChecks'])
    closed_experiments = []
    for entry in current['receipts']:
        folder, scope = entry['folder'], entry['scope']
        record = {k: v for k, v in entry.items() if k != 'folder'}
        record['closure'] = copy.deepcopy(targets[str(folder / 'COLLECTED.json')])
        record['execution'] = copy.deepcopy(targets[str(folder / 'owned/execution.json')])
        if scope != 256:
            record['report'] = copy.deepcopy(targets[str(folder / 'byte0-result.json')])
        record.update({'source257GeometryUnchangedByCollection': True, 'all49Accepted': False, 'fabricationReady': False})
        closed_experiments.append(record)
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    freeze = {'scope': 'CLOSED259_SOURCE257_ALL14_LITERAL_POURS_TWO_LOCAL_PDN_CONTACTS_AND_REVIEWED_FOUR_LAYER_PLOT',
              'latestClosedScope': 259, 'lastClosedRoutingScope': 253, 'sourceCoreScope': 257,
              'candidateSha256': CURRENT_SHA, 'rawCoreSha256': RAW_SHA, 'literalPourAggregateSha256': AGGREGATE_SHA,
              'pdnLocalContactReportSha256': PDN_CONTACT_SHA, 'laterWorkRequiresNewSavedDirectory': True,
              'all49Accepted': False, 'fabricationReady': False}
    boundaries = {'frozenCheckpoint': True, 'freezeBoundary': freeze, 'laterRoutingWorkRequiresNewSavedDirectory': True,
                  'all49Accepted': False, 'fabricationReady': False}
    restore = {'scope': 'FROZEN_POST252_SOURCE257_CONNECTED49_SCOPED_PASSES_NOT_TIMING_OR_FULL_BOARD_QUALIFICATION',
               'updatedAt': now, 'solverSourceRoot': '/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib',
               'files': sorted(targets.values(), key=lambda r: r['restorePath']),
               'baseDependencyRestoreFiles': sorted(bases.values(), key=lambda r: r['restorePath']),
               'baseArchiveDependency': dependency, 'baseArchiveDependenciesInRestoreOrder': archives,
               'immutableWorkspaceAssets': sorted(workspace_assets.values(), key=lambda r: r['restorePath']),
               'aliases': aliases, 'primaryCandidate': primary, 'latestSourceVerifiedCheckpoint': latest,
               'literalPourCoverageAggregate': scoped_pours, 'newPdnLocalContactProof': pdn_contact,
               'reviewedFourLayerPlot': plot,
               'preparedLaterReplaySource': {'source': copy.deepcopy(targets[str(PREPARED_V3)]),
                    'usedForSource257': False, 'laterRuntimeEvidenceExcluded': True,
                    'qualificationInheritedFromSource257': False},
               'priorFailedCollectorAttempt': {'source': copy.deepcopy(targets[str(FAILED_COLLECTOR)]),
                    'profile': copy.deepcopy(targets[str(FAILED_PROFILE)]),
                    'rootFailureReceipt': copy.deepcopy(targets[str(FAILED_RECEIPT)]),
                    'preservedPartialDirectory': PRESERVED_FAILED_DIRECTORY.relative_to(ROOT).as_posix(),
                    'preservedPartialFileInventory': failed_rows,
                    'failureKind': 'DEPENDENCY_FILENAME_COLLIDED_WITH_RESERVED_CURRENT_CANDIDATE_ALIAS',
                    'metadataWrittenByFailedAttempt': False, 'priorPartialFilesModifiedByThisCollector': False,
                    'sdkExecuted': False},
               'independentFallbacks': {'source24848': copy.deepcopy(base_progress['latestSourceVerifiedCheckpoint']),
                                        'source23347TimingFallback': copy.deepcopy(base_progress['primaryCandidate']),
                                        'savedDirectory': BASE.relative_to(ROOT).as_posix(), 'independentNotInherited': True},
               **boundaries}
    progress = {'scope': restore['scope'], 'updatedAt': now, 'latestClosedScopeIncluded': 259,
                'primaryCandidate': primary, 'latestSourceVerifiedCheckpoint': latest,
                'literalPourCoverageAggregate': scoped_pours, 'newPdnLocalContactProof': pdn_contact,
                'reviewedFourLayerPlot': plot,
                'preparedLaterReplaySource': copy.deepcopy(restore['preparedLaterReplaySource']),
                'priorFailedCollectorAttempt': copy.deepcopy(restore['priorFailedCollectorAttempt']),
                'independentFallbacks': copy.deepcopy(restore['independentFallbacks']),
                'closedExperiments': closed_experiments,
                'aliases': aliases, 'baseArchiveDependenciesInRestoreOrder': archives,
                'publicBaseRestoreDependencies': restore['baseDependencyRestoreFiles'],
                'immutableWorkspaceAssets': copy.deepcopy(restore['immutableWorkspaceAssets']),
                'frozenPost232MetadataPins': BASE_PINS, 'profileSha256': args.profile_sha,
                'collectorSource': str(Path(__file__)), 'collectorUsesOnlyOwnPythonStdlib': True,
                'privateAuthorityAndContextBodiesExcluded': True, 'excludedPrivateNamedLiterals': sorted(excluded),
                'baseDependenciesCopied': False, 'failed247RetainedInFrozenBase': True,
                'sdkExecutedByCollector': False, 'existingRestoreHelperExecutedByCollector': False,
                'archiveCreated': False, 'commitCreated': False, 'cloudDocumentEdited': False, **boundaries}
    for name, data in inputs.items():
        require(metadata(Path(name)) == data, 'Public source changed before metadata publication')
    for name, pin in all_pins.items():
        require(digest(Path(name)) == pin, 'Explicit253 source pin changed')
    require(digest(profile_path) == args.profile_sha, 'Profile unchanged')
    verify_base()
    verify_rows(PRESERVED_FAILED_DIRECTORY, failed_rows)
    write_json(SAVED / 'WORKSPACE_RESTORE_MANIFEST.json', restore)
    readme = f"""Resume from latestSourceVerifiedCheckpoint: actual SOURCE257 has all49/49
numeric-connected DDR routes, with no pending owner. Its exact candidate253
passed all49 routing-model physical gates and both critical DQS1 views/all five
APIs. Source254 projection,255 capture/full literal+key inverse, fresh Core257
all35 controls, focused native258 physical10 and other requested geometry checks,
authenticated234-via check259, and all14 literal-pour foreign-margin checks PASS
their stated scopes. Two new net-declared PDN barrels have separate actual filled-
polygon local contact proofs. Root rendered and reviewed the four-layer PNG/SVG:
all49 routes are shown across Top/Inner1/Inner2/Bottom with no pending owner.
This checkpoint is FROZEN at closed259 plus the all14-pour and local PDN proofs
and reviewed plot. All later routing or Source experiments need a NEW folder.

Candidate after dependency restore: {CURRENT}
SHA256 {CURRENT_SHA}
Saved current candidate: byte0-result.candidate.json
Report: {REPORT}
Actual raw Source257: {RAW}
SHA256 {RAW_SHA}
Controls: {CONTROLS}
Plan254: {PLAN}
Capture255: {CAPTURE}
Native258: {NATIVE}
Authenticated234-via result259: {AUTH}
All14-pour aggregate: {AGGREGATE}
Local PDN contact proof: {PDN_CONTACT}
No Source248 or Source236 qualification is inherited.
All3 original cohort skew checks still FAIL: 6.655202281574553,
2.4000719198310776 and17.43870093419864mm. Full timing, electrical readiness,
TI/reference continuity, CAD, default promotion, all49 acceptance and fabrication
readiness remain FALSE.

The CPU2NE/CPU11SW branches, four body replacements, manual26 endpoint changes,
cap8 move and two planned PDN declarations each have exact inverse/proof records.
The two new PDN Source declarations now have actual Core257 via232/233,
manual Source232/233 and PCBcomponent512/513 identities, authenticated on all4
layers and real Source nets5/0. Latest253 foundation authority is the REPORT's
constructorFoundationDelta; the candidate's same-named inherited cap12 field is
preserved only as provenance. The plural requiredSourceHardwarePlacementDeltas
contains both actual cap12 and cap8 descriptors.

The fresh foreign-pour aggregate covers all14 actual BREP pours,234 vias and979
routed signal-wire segments at0.1016mm. Reference-wire geometry and own-net
reentry are excluded. The PDN proof retains fullNEW.2286mm-OD land disks inside
the respective filled islands. VDD has held full-land witnesses; GND has the
specifically authenticated site010 positive plated annular contact band outside
its drill, joined by the genuine Top reference to numericU_RAM.pin14. The older
c437/a7e83 overstrong fullHELDdisk negative is preserved, not edited or relabeled.
This proves two local contacts, not complete DDR reference-plane continuity,
electrical timing, TI stack compliance, or whole-board fabrication readiness.

Failed Core256 is preserved: it exited1 on OBJ asset loading and emitted no
raw/control geometry evidence. Core257 used exact1174 pinned OBJ loading with
the ORIGINAL b4a68fd/565628byte USBLC6 asset. That unchanged asset is saved as a
regular indexed payload with a separate immutableWorkspaceAssets row. The exact
original53901e8/3277419byte STEP asset is also saved, together with the prepared
df7e383 OBJ+STEP loader successor. That successor and STEP loading were NOT used
for Source257, and no later263/264 runtime or geometry qualification is included.
The legacy
saved-workspace helper restores only /tmp targets; it does NOT restore workspace
assets. A future portable archive must include this asset at its exact recorded
boardRelativePath, or an explicit byte/hash/mode checked copy must place it there
without overwriting differing local work. No loader or application file is edited.

The frozen post232 Source24848 checkpoint (all scoped checks+all14 pours) and its
INDEPENDENT Source233/23647-route CA13 timing fallback remain base dependencies.
No fallback geometry or qualification is combined with this Source257. Failed
Core247's loader exception remains preserved in that frozen dependency. Restore
Source209 -> Source228 -> Source248 before this new saved workspace; hashes and
exact byte/mode restore rows are recorded in WORKSPACE_RESTORE_MANIFEST.json.
The compatible helper is scripts/restore-g350-four-layer-routing-workspace.py
--saved-directory .cloud-tools/ddr-four-layer-post252-2026-10-16; --restore refuses
different existing bytes/modes. This collector does not run the supplied helper.

No older saved folder, archive, tracked application Source, cloud document or
commit is modified. Only this NEW post252 directory is written, using own stdlib.
SOURCE257_CAP12_CAP8_PDN_CONNECTED49_FOUR_LAYER_MILESTONE.png and.svg are the
exact Root-rendered/reviewed files; plot Source and all hashes are indexed.
Later Byte1 model/source experiments are independent. Closed260+ results and
their geometry are outside this frozen checkpoint and cannot inherit Source257
native/pour/contact qualification. Frozen post232, its failed247 receipt and all
prior payload archives remain unchanged.

The earlier c607 collector failed before metadata when an old dependency used
the current candidate alias filename. Root preserved its partial files in
{PRESERVED_FAILED_DIRECTORY.relative_to(ROOT).as_posix()}; its exact Source and
profile are saved as failed provenance, not qualification. This v4 collector
reserves EVERY canonical alias before copying dependencies and writes each alias
fresh afterward. It never overwrites prior partial files or existing payloads.
"""
    with (SAVED / 'README.md').open('x') as stream:
        stream.write(readme)
        os.fchmod(stream.fileno(), 0o600)
    excluded_metadata = {'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
    progress['artifacts'] = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir())
                             if regular(p) and p.name not in excluded_metadata]
    write_json(SAVED / 'PROGRESS.json', progress)
    rows = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir())
            if regular(p) and p.name != 'WORKSPACE_HASH_INDEX.json']
    write_json(SAVED / 'WORKSPACE_HASH_INDEX.json', {'scope': restore['scope'], 'updatedAt': now,
               'files': rows, 'selfExcluded': True, **boundaries})
    verify_rows(SAVED, rows)
    for row in restore['files']:
        expected = {k: row[k] for k in ('bytes', 'sha256', 'mode')}
        require(metadata(SAVED / row['savedPath']) == expected
                and metadata(Path(row['restorePath'])) == expected, 'Saved and current restore targets exact')
    for row in restore['immutableWorkspaceAssets']:
        expected = {k: row[k] for k in ('bytes', 'sha256', 'mode')}
        require(metadata(SAVED / row['savedPath']) == expected
                and metadata(Path(row['restorePath'])) == expected, 'Saved original immutable OBJ bytes/mode exact')
    verify_base()
    verify_rows(PRESERVED_FAILED_DIRECTORY, failed_rows)
    print(json.dumps({'savedDirectory': str(SAVED), 'fileCount': len(rows) + 1,
        'indexRows': len(rows), 'restoreTargets': len(targets), 'baseRestoreDependencies': len(bases),
        'immutableWorkspaceAssetCount': len(workspace_assets),
        'metadataSha256': {name: digest(SAVED / name) for name in
            ('PROGRESS.json', 'WORKSPACE_HASH_INDEX.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'README.md')},
        'frozenCheckpoint': True, 'freshSourceCorePending': False, 'reviewedPlotPending': False,
        'sdkExecuted': False, 'all49Accepted': False, 'fabricationReady': False}, indent=2))


if __name__ == '__main__':
    main()
