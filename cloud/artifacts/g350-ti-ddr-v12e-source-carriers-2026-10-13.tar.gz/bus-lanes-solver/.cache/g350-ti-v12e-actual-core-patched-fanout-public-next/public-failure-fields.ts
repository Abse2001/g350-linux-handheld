/** Read-only own-data public fields; never invoke getters or coerce objects. */
export type FailureFieldKind = "string" | "null" | "absent" | "accessor" | "unsupported"
function field(value: unknown, key: "error" | "failureCode") {
  if ((typeof value !== "object" && typeof value !== "function") || value === null)
    return { value: null, kind: "absent" as FailureFieldKind, truncated: false }
  const descriptor = Object.getOwnPropertyDescriptor(value, key)
  if (!descriptor) return { value: null, kind: "absent" as FailureFieldKind, truncated: false }
  if (!("value" in descriptor)) return { value: null, kind: "accessor" as FailureFieldKind, truncated: false }
  if (descriptor.value === null) return { value: null, kind: "null" as FailureFieldKind, truncated: false }
  if (typeof descriptor.value !== "string") return { value: null, kind: "unsupported" as FailureFieldKind, truncated: false }
  return { value: descriptor.value.slice(0, 1024), kind: "string" as FailureFieldKind, truncated: descriptor.value.length > 1024 }
}
export function ownPublicFailureFields(value: unknown) {
  const error = field(value, "error"), code = field(value, "failureCode")
  return { error: error.value, failureCode: code.value, errorFieldKind: error.kind,
    failureCodeFieldKind: code.kind, errorTruncated: error.truncated, failureCodeTruncated: code.truncated }
}
