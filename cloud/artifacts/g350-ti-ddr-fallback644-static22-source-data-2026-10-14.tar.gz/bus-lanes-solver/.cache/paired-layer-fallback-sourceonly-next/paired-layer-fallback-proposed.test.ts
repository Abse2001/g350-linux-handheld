import { expect, test } from "bun:test"
import { BusLanesSolver } from "./lib/bus-lanes-solver"
import { pairCouplingReports } from "./lib/pair-coupling"
import { pairLengthReports } from "./lib/route-lengths"
import { makeFixture, terminalLayers } from "./fixture"
import type { SimpleRouteJson } from "./lib/types"

const run = (input: SimpleRouteJson, layers = terminalLayers()) => {
  const before = structuredClone(input)
  const solver = new BusLanesSolver(
    input,
    { denseSearch: true, maxSearchIterations: 20000 },
    layers,
  )
  solver.solve()
  expect(input).toEqual(before)
  return solver
}

const assertClearPair = (solver: BusLanesSolver) => {
  expect(solver.error).toBeNull()
  expect(solver.solved).toBe(true)
  expect(solver.traces).toHaveLength(2)
  expect(pairCouplingReports(solver.input, solver.traces)[0].matched).toBe(true)
  expect(pairLengthReports(solver.input, solver.traces)[0].matched).toBe(true)
  for (const trace of solver.traces) {
    const connection = solver.input.connections.find(
      (c) => c.name === trace.connection_name,
    )!
    expect(trace.route.every((p) => p.route_type === "wire" && p.layer === "inner1" && p.width === 0.1)).toBe(true)
    expect(trace.route[0].x).toBe(connection.pointsToConnect[0].x)
    expect(trace.route[0].y).toBe(connection.pointsToConnect[0].y)
    expect(trace.route.at(-1)!.x).toBe(connection.pointsToConnect[1].x)
    expect(trace.route.at(-1)!.y).toBe(connection.pointsToConnect[1].y)
  }
  expect(solver.input.differentialPairs).toEqual(makeFixture().differentialPairs)
}

test("a coupled pair falls back from a blocked layer to a clear available layer", () => {
  assertClearPair(run(makeFixture()))
})

test("an available clear layer works without a blocked first choice", () => {
  const input = makeFixture()
  for (const c of input.connections)
    for (const p of c.pointsToConnect) p.layer = "inner1"
  assertClearPair(run(input, new Map([["P", ["inner1"]], ["N", ["inner1"]]])))
})

test("no pair is invented when every available layer is blocked", () => {
  const solver = run(makeFixture(["top", "inner1"]))
  expect(solver.solved).toBe(false)
  expect(solver.failed).toBe(true)
  expect(solver.failureCode).toBe("no_planar_route")
  expect(solver.traces).toHaveLength(0)
})
