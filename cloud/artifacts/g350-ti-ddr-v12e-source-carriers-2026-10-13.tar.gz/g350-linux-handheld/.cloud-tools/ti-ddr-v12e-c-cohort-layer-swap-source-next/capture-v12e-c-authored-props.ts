import {Children,cloneElement,isValidElement,type ReactElement,type ReactNode} from "react"
import {readFileSync,writeFileSync} from "node:fs"
import {buildV12eSource} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-ram7-reference-right-source-proposal-next/v12e-ram7-reference-right-overlay"
import {buildV12eCSource} from "./v12e-c-final-layer-overlay"
if(import.meta.main){
 const [output,...extra]=process.argv.slice(2);if(!output||extra.length)throw Error("Usage: bun --smol capture-v12e-c-authored-props.ts FRESH_OUTPUT_JSON")
 const rawBefore=buildV12eSource(),after=buildV12eCSource()
 function identityClone(node:ReactNode):ReactNode{if(!isValidElement<Record<string,unknown>>(node))return node;return cloneElement(node as ReactElement<Record<string,unknown>>,{...node.props},...Children.toArray(node.props.children as ReactNode).map(identityClone))}
 const before={...rawBefore,element:identityClone(rawBefore.element)}
 let comparedElements=0;const changes:Array<Record<string,unknown>>=[]
 function compare(a:ReactNode,b:ReactNode,path:string){
  if(!isValidElement<Record<string,unknown>>(a)||!isValidElement<Record<string,unknown>>(b)){if(JSON.stringify(a)!==JSON.stringify(b))throw Error("Non-element value changed: "+path);return}
  comparedElements++;if(a.type!==b.type||a.key!==b.key)throw Error("Source type or key changed: "+path)
  const pa={...a.props},pb={...b.props};delete pa.children;delete pb.children
  const spec=({DDR_RESET:{before:"bottom",after:"top"},DDR_BYTE0:{before:"top",after:"bottom"}} as Record<string,{before:string;after:string}>)[String(pa.name)]
  if(spec){
   if(a.type!=="bus")throw Error("Original bus required")
   for(const field of ["pcbAllowedLayers","preferredLayers"] as const){
    if(JSON.stringify(pa[field])!==JSON.stringify([spec.before])||JSON.stringify(pb[field])!==JSON.stringify([spec.after]))throw Error("Exact two-bus layer metadata swap required")
    changes.push({busId:pa.name,field,before:pa[field],after:pb[field]});pb[field]=pa[field]
   }
  }
  if(JSON.stringify(pa)!==JSON.stringify(pb))throw Error("Unexpected source props changed: "+path)
  const ca=Children.toArray(a.props.children as ReactNode),cb=Children.toArray(b.props.children as ReactNode);if(ca.length!==cb.length)throw Error("Source children count changed")
  ca.forEach((child,i)=>compare(child,cb[i],path+"/"+i))
 }
 compare(before.element,after.element,"board");if(changes.length!==4||new Set(changes.map(c=>c.busId)).size!==2)throw Error("Exactly four layer-list props across two buses required")
 const expected=JSON.parse(readFileSync(new URL('./derived-final-authored-props.json',import.meta.url),'utf8'))
 for(const key of ["placementProposal","authoredPolicyProof","referenceCopperCandidates","globalSignalLayerProjection","naturallyDerivedGenericDefaultCap"] as const)if(JSON.stringify(after[key])!==JSON.stringify(expected[key]))throw Error("Final C source metadata mismatch: "+key)
 for(const key of ["placementProposal","referenceCopperCandidates","globalSignalLayerProjection","naturallyDerivedGenericDefaultCap","referenceQualified","TIplaneArrangement"] as const)if(JSON.stringify(after[key])!==JSON.stringify(before[key]))throw Error("Non-layer V12e source field changed: "+key)
 writeFileSync(output,JSON.stringify({scope:"PURE_ACTUAL_V12E_C_FINAL_REACT_TWO_BUS_FOUR_LAYER_LIST_PROPS_ONLY",actualFinalReactTreeEvaluated:true,comparedElements,allOtherTreePropsTypesKeysChildrenExactlyHeld:true,changedLayerProps:changes,placementProposal:after.placementProposal,authoredPolicyProof:after.authoredPolicyProof,referenceCopperCandidates:after.referenceCopperCandidates,globalSignalLayerProjection:after.globalSignalLayerProjection,naturallyDerivedGenericDefaultCap:after.naturallyDerivedGenericDefaultCap,referenceQualified:false,TIplaneArrangement:false,newCoreBuildPerformed:false,newNativePlacementCheckPerformed:false,coreRenderCalled:false,nativePlacementChecksInvoked:false,routingSolverInstantiated:false,accepted49:false,fabricationReady:false},null,2)+"\n",{flag:"wx",mode:0o600})
}
