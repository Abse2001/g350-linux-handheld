#!/usr/bin/env bash
set -euo pipefail
source /workspace/g350-linux-handheld/cloud/env.sh
exec python3 -B "$(dirname "$0")/guard.py" "$@"
