"""Bounded read-only active CPU geometry stop probe; no solver imports."""
from pathlib import Path
import json,math,os,re,stat

LIMIT=2*1024*1024
THRESHOLD=100000
REASON='OWNED_ACTIVE_CPU_GEOMETRY_CAPTURE'
REQUIRED=['callerSha256','gridSha256','publicInputSha256','stageObserverSha256']
CAPTURE_AT='after-original-step-return-at-active-cpu-threshold'

def make_capture_probe(path,expected_bindings,expected_scene_input):
    bindings=dict(expected_bindings)
    assert set(bindings)==set(REQUIRED+['precheckEnclosedTerminals'])
    assert bindings['precheckEnclosedTerminals'] is True
    assert all(isinstance(bindings[key],str) and re.fullmatch('[0-9a-f]{64}',bindings[key]) for key in REQUIRED)
    expected=json.loads(json.dumps(expected_scene_input,allow_nan=False))
    assert isinstance(expected,dict) and expected.get('layerCount')==4
    assert len(expected.get('connections',[]))==26 and len(expected.get('traces',[]))==98
    assert len(expected.get('obstacles',[]))==856
    assert len(expected.get('buses',[]))==1 and expected['buses'][0]['busId']=='DDR_COMMAND_CLOCK'
    assert len(expected.get('differentialPairs',[]))==1
    assert expected['differentialPairs'][0]['connectionNames']==['source_trace_33','source_trace_34']
    expected_serialized=json.dumps(expected,separators=(',',':'),ensure_ascii=False,allow_nan=False)
    expected_clock=next(connection for connection in expected['connections'] if connection['name']=='source_trace_34')
    expected_clock_serialized=json.dumps(expected_clock,separators=(',',':'),ensure_ascii=False,allow_nan=False)
    path=Path(path);fingerprint=None;cached_reason=None
    def finite(value):
        return type(value) in (int,float) and math.isfinite(value)
    def point(value):
        return isinstance(value,dict) and finite(value.get('x')) and finite(value.get('y'))
    def eligible(value):
        if not isinstance(value,dict) or value.get('bindings')!=bindings:return False
        if value.get('diagnosticOnly') is not True or value.get('accepted49') is not False or value.get('fabricationReady') is not False:return False
        if value.get('captureAt')!=CAPTURE_AT or value.get('threshold')!=THRESHOLD:return False
        if value.get('complete') is not True:return False
        if any(type(value.get(key)) is not int or value[key]!=1 for key in ['persistedActiveScenes','observedAttempts','persistedAttempts']):return False
        if type(value.get('persistedFailingScenes')) is not int or value['persistedFailingScenes']!=0:return False
        records=value.get('records')
        if not isinstance(records,list) or len(records)!=1:return False
        record=records[0]
        if not isinstance(record,dict) or type(record.get('id')) is not int or record['id']!=1:return False
        if record.get('kind') not in ['original-coarse','original-fine'] or type(record.get('startTerminalIndex')) is not int or record['startTerminalIndex']!=0:return False
        if record.get('captureAt')!=CAPTURE_AT:return False
        if record.get('frontierCaptured') is not False or record.get('fullFrontierReplayClaimed') is not False:return False
        data=record.get('data');paths=record.get('undefinedPaths')
        if not isinstance(data,dict) or not isinstance(paths,list):return False
        required=['input','connection','width','hardCopper','margin','start','end','grid','stateAfterOriginalStep']
        if any(key not in data for key in required):return False
        if data['input']!=expected or json.dumps(data['input'],separators=(',',':'),ensure_ascii=False,allow_nan=False)!=expected_serialized:return False
        if data['connection']!=expected_clock or json.dumps(data['connection'],separators=(',',':'),ensure_ascii=False,allow_nan=False)!=expected_clock_serialized:return False
        terminals=data['connection']['pointsToConnect']
        if len(terminals)!=2 or any(not point(p) or p.get('layer')!='inner1' for p in terminals):return False
        if not point(data['start']) or not point(data['end']):return False
        if any(data['start'][axis]!=terminals[0][axis] for axis in ['x','y']):return False
        width=data['width'];margin=data['margin']
        if not finite(width) or width<=0 or width!=expected_clock.get('nominalTraceWidth',expected_clock.get('width',expected['minTraceWidth'])):return False
        clearance=expected.get('minTraceToPadEdgeClearance',expected.get('defaultObstacleMargin',.075))
        if not finite(margin) or abs(margin-(width/2+clearance))>1e-12:return False
        copper=data['hardCopper']
        if not isinstance(copper,list) or not any(isinstance(row,dict) and isinstance(row.get('owners'),list) and 'reserved_pair_tail' in row['owners'] for row in copper):return False
        grid=data['grid']
        if not isinstance(grid,dict) or grid.get('checkReachability') is not True or not finite(grid.get('step')) or grid['step']<=0:return False
        step=grid['step'];want=width/2 if record['kind']=='original-coarse' else max(.01,width/10)
        if abs(step-want)>1e-12:return False
        bounds=grid.get('bounds')
        if not isinstance(bounds,dict) or any(not finite(bounds.get(key)) for key in ['minX','maxX','minY','maxY']):return False
        if not bounds['minX']<=bounds['maxX'] or not bounds['minY']<=bounds['maxY']:return False
        state=data['stateAfterOriginalStep']
        if not isinstance(state,dict):return False
        if type(state.get('expanded')) is not int or state['expanded']<THRESHOLD:return False
        if state.get('solved') is not False or state.get('failed') is not False:return False
        if type(state.get('alternateAttachments')) is not bool or not point(state.get('origin')):return False
        if any(type(state.get(key)) is not int or state[key]<=0 for key in ['nx','ny']):return False
        if state['origin']['x']!=bounds['minX'] or state['origin']['y']!=bounds['minY']:return False
        if state['nx']!=math.ceil((bounds['maxX']-bounds['minX'])/step)+1 or state['ny']!=math.ceil((bounds['maxY']-bounds['minY'])/step)+1:return False
        outcome=record.get('outcome')
        if not isinstance(outcome,dict) or outcome.get('kind')!='ACTIVE_DIAGNOSTIC':return False
        if outcome.get('observedAt')!='after-original-step-return' or outcome.get('originalStepReturned') is not True:return False
        if outcome.get('solved') is not False or outcome.get('failed') is not False:return False
        if type(outcome.get('expanded')) is not int or outcome['expanded']!=state['expanded']:return False
        for entry in paths:
            if not isinstance(entry,list) or not entry or any(not isinstance(key,str) for key in entry):return False
            current=data
            for key in entry:
                if isinstance(current,dict) and key in current:current=current[key]
                elif isinstance(current,list) and key.isascii() and key.isdecimal() and int(key)<len(current):current=current[int(key)]
                else:return False
            if current is not None:return False
        return True
    def probe():
        nonlocal fingerprint,cached_reason
        try:
            fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
            with os.fdopen(fd,'rb') as stream:
                status=os.fstat(stream.fileno())
                if not stat.S_ISREG(status.st_mode):return None
                current=(status.st_dev,status.st_ino,status.st_size,status.st_mtime_ns,status.st_ctime_ns)
                if current==fingerprint:return cached_reason
                fingerprint=current;cached_reason=None
                if not 0<status.st_size<=LIMIT:return None
                raw=stream.read(LIMIT+1)
                if len(raw)!=status.st_size or len(raw)>LIMIT:return None
                if eligible(json.loads(raw)):cached_reason=REASON
                return cached_reason
        except (OSError,ValueError,UnicodeDecodeError,RecursionError,OverflowError,TypeError):return None
    return probe
