"""ONE validation-only recovery of original actual V7 bytes; no source rebuild/router."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
from validate_v7 import validate
ROOT=Path(__file__).resolve().parent;BOARD=Path('/workspace/g350-linux-handheld');BUN=str(BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 if sys.argv[1:]!=['--one-approved-validation-recovery'] or os.environ.get('G350_TI_V7_VALIDATION_APPROVED')!='1':raise ValueError('Explicit validation-only authority required')
 raw=(ROOT/'packet-manifest.json').read_bytes();pkt=hashlib.sha256(raw).hexdigest();m=json.loads(raw)
 if os.environ.get('G350_TI_V7_VALIDATION_PACKET_SHA')!=pkt:raise ValueError('Exact reviewed packet required')
 original=Path(m['originalActualSourcePath']);source=ROOT/m['freshOutput']
 if sha(source)!=m['actualV7SourceSha256'] or source.read_bytes()!=original.read_bytes() or not(ROOT/'run').is_dir() or(ROOT/'output').exists():raise ValueError('Original actual source bytes and exclusive outputs required')
 original_exit=json.loads(Path(m['originalBuildExitPath']).read_bytes());assert original_exit['actualExitCode']==0 and original_exit['sourceBuildCount']==1 and original_exit['routingDisabled'] is True
 (ROOT/'run/fresh-layout.circuit.json').write_bytes(source.read_bytes());compiled=json.loads(source.read_bytes());output=ROOT/'run/fresh-layout.circuit.json'
 names=['inputs/base-layout.circuit.json','inputs/v5-layout.circuit.json','inputs/v6-layout.circuit.json','source/lib/am3352/placement/g350-ti-top-bottom-ddr-v7-translation.json','source/lib/am3352/placement/g350-ti-top-bottom-ddr-v5.json'];base,v5,v6,poses,table=[json.loads((ROOT/n).read_bytes()) for n in names]
 report=validate(base,v5,v6,compiled,poses,table,m['planeDeclarations']);(ROOT/'run/source-validation.json').write_text(json.dumps(report,indent=2)+'\n');exits=[]
 commands=[('all17-native-physical',[BUN,str(ROOT/'check-native-physical.mjs'),str(output),m['actualV7SourceSha256'],str(ROOT/'run/native-physical.json')]),('pinned-core-projection',[BUN,str(ROOT/'capture-v7.ts'),str(BOARD/'node_modules/@tscircuit/core/dist/index.js'),str(output),m['actualV7SourceSha256']]),('fresh-endpoint-ti-input',[sys.executable,'-B',str(ROOT/'derive-input.py')])]
 for name,argv in commands:
  print(json.dumps({'phase':name,'command':argv,'sourceRebuilds':0,'signalRoutingPerformed':False}),flush=True);p=subprocess.run(argv,cwd=ROOT,check=False);exits.append({'name':name,'command':argv,'actualExitCode':p.returncode});(ROOT/'run/projection-check-exits.json').write_text(json.dumps(exits,indent=2)+'\n')
  if p.returncode!=0:raise ValueError('Recovered source qualification failed: '+name)
 native=json.loads((ROOT/'run/native-physical.json').read_bytes());derive=json.loads((ROOT/'run/input-derivation.json').read_bytes());assert native['physicalErrors']==0 and native['checkCount']==17
 result={'packetSha256':pkt,'validationOnlyRecovery':True,'newSourceBuildCount':0,'originalSourceBuildCount':1,'originalSourceBuildExitCode':0,'originalSourceControllerOuterExitCode':2,'originalSourceControllerChildExitCode':1,'originalSourceControllerResultTrustEligible':False,'originalFailurePreserved':True,'sourceOutput':{'originalPath':str(original),'copiedPath':str(output),'bytes':source.stat().st_size,'sha256':sha(source)},'sourceBytesNeverReserialized':True,'validation':report,'nativePhysicalCounts':native['counts'],'nativePhysicalErrors':0,'inputSha256':derive['hashes']['input.json'],'unrestrictedInputSha256':derive['hashes']['original-unrestricted-input.json'],'sourceOnlyQualified':True,'freshTiEndpointAuditVerified':True,'byte0MaximumTotalPlanarMm':13.2,'byte1MaximumTotalPlanarMm':14.4,'commandTotalPlanarRangeMm':derive['commandTotalPlanarRangeMm'],'toolExits':exits,'sourceInitializerCalled':False,'autoroutingPerformed':False,'cadPerformed':False,'actualBoardDdr49Accepted':False,'electricalTimingQualified':False,'fabricationReady':False}
 (ROOT/'run/result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'sourceOnlyQualified':True,'actualSourceSha256':sha(source),'newSourceBuilds':0,'nativePhysicalErrors':0,'accepted49':False}),flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
