from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,stat
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/bus-lanes-solver')
BASE=REPO/'.cache/g350-ti-top-clock-enclosed-boundary-v2-next'
PREPARED=REPO/'.cache/topology-default-c115121-smol-14400/prepared-manifest.json'
PHASE=REPO/'.cache/root-routing-progress'
def item(p,relative=False):
 raw=p.read_bytes();return{'path':str(p.relative_to(ROOT))if relative else str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode)}
assert not(ROOT/'packet-manifest.json').exists()
for n in ['run','root-launch-receipt.json']:assert not(ROOT/n).exists()and not(ROOT/n).is_symlink()
p=json.loads(PREPARED.read_bytes());assert len(p['sourceHashes'])==177
for n,h in p['sourceHashes'].items():assert item(ROOT/'source'/n)['sha256']==h and item(PREPARED.parent/'frozen'/n)['sha256']==h
base=json.loads((BASE/'packet-manifest.json').read_bytes());assert item(BASE/'packet-manifest.json')['sha256']=='aa4870741c189c7a14a1eed29fa0f90f4f393f519f213660f01df3a157094759'
origins={'capture.json':BASE/'run/first-enclosed-grid-constructor.json','parent-result.json':BASE/'run/result.json','parent-postflight.json':BASE/'run/postflight.json','parent-connectors-result.json':PHASE/'captured-rasn-connectors.json','parent-connectors-postflight.json':PHASE/'captured-rasn-connectors-postflight.json'}
for n,p in origins.items():assert item(ROOT/n)['sha256']==item(p)['sha256']
assert item(ROOT/'capture.json')['sha256']=='798e435705fb5d47bb47b08043a78a90c8837436d2bada425be0f9c058857418'
assert item(ROOT/'parent-connectors-result.json')['sha256']=='f4280c5f4b8adebafea688f22bb5de023f9485134dea2dbd05a32bc47766e944'
assert item(ROOT/'parent-connectors-postflight.json')['sha256']=='1c575ff8d6363fa66cebc1dbf905d18c39c26d7091d99a935e8969c11f5b3633'
absent=[name.replace(str(BASE),str(ROOT))for name in base['requiredAbsentRuntimeFiles']]
for n in absent:assert not Path(n).exists()and not Path(n).is_symlink(),n
files=[item(f,True)for f in sorted(ROOT.rglob('*'))if f.is_file()and not f.is_symlink()and not any(v in ['run','__pycache__','prep-validation']for v in f.relative_to(ROOT).parts)and f.name!='packet-manifest.json']
external=[PREPARED,BASE/'packet-manifest.json',*origins.values(),PHASE/'captured-rasn-connectors.ts',REPO/'package.json',REPO/'tsconfig.json',REPO/'bunfig.toml',Path('/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe')]
m={'schemaVersion':1,'preparedUtc':datetime.now(timezone.utc).isoformat(),'sourceRevision':'c1151212be7b9de4b34b07436d135d874e6c0466','libTree':'6c2f08dac7b248f94c2fd1125545031eeaa01e13','originalPreparedPath':str(PREPARED),'originalSourceMemberCount':177,'files':files,'externalFiles':[item(f)for f in external],'requiredAbsentRuntimeFiles':absent,'policy':{'wallSeconds':30,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5},'scope':'exact-captured-enclosed-grid-checkReachability','gridCapExpanded':500000,'gridOptionalChanges':['checkReachability:true'],'defaultOtherOptionsPreserved':['softCu[]','penalty4','historyundefined','step/originunmodified','maxLengthundefined','attachmentflagsundefined'],'originalRoutingFactories':0,'originalSceneCallsPerActual':1,'originalGridCallsPerActual':1,'connectorCallsPerActual':0,'baselineDuplicateGridWorker':False,'parentBoundaryPacketSha256':item(BASE/'packet-manifest.json')['sha256'],'parentCaptureSha256':item(ROOT/'capture.json')['sha256'],'parentConnectorsResultSha256':item(ROOT/'parent-connectors-result.json')['sha256'],'inputBindings':{n:item(ROOT/n,True)for n in origins},'dependencyReceiptSha256':base['dependencyReceiptSha256'],'dependencyTreeSha256':base['dependencyTreeSha256'],'dependencyArchiveSha256':base['dependencyArchiveSha256'],'captureLimitBytes':4*1024**2,'beforeCancelClassificationRequired':True,'unknownIsNeverReachableOrPhysicalFailure':True,'finiteGridFailureIsNotGlobalPhysicalInfeasibility':True,'preparationActualSceneGridCheckerRoutingCalls':0,'rootActualGoRequired':True,'acceptedClock':False,'accepted49':False,'fabricationReady':False}
(ROOT/'packet-manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'packetSha256':item(ROOT/'packet-manifest.json')['sha256'],'localFiles':len(files),'externalFiles':len(external),'sourceMembers':177}))
