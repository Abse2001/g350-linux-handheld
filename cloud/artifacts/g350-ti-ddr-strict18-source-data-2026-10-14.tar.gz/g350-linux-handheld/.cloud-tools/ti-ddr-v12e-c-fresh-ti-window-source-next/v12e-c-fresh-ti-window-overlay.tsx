import {Children,cloneElement,isValidElement,type ReactElement,type ReactNode} from "react"
import {buildV12eCSource} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-c-cohort-layer-swap-source-next/v12e-c-final-layer-overlay"
type Props=Record<string,unknown>&{name?:string;children?:ReactNode}
export function buildV12eCTiWindowSource(){
 const base=buildV12eCSource();let changed=0
 function apply(node:ReactNode):ReactNode{
  if(!isValidElement<Props>(node))return node
  const p={...node.props}
  if(p.name==="DDR_COMMAND_CLOCK"){
   if(node.type!=="bus"||changed||p.minLength!==21.15||p.maxLength!==23.69)throw Error("Exactly one original CA bus/window required")
   p.minLength=20.95;p.maxLength=23.49;changed++
  }
  return cloneElement(node as ReactElement<Props>,p,...Children.toArray(node.props.children).map(apply))
 }
 const element=apply(base.element);if(changed!==1)throw Error("Exactly one CA bus required")
 const proof={...base.authoredPolicyProof,groups:base.authoredPolicyProof.groups.map(g=>g.busId==="DDR_COMMAND_CLOCK"?{...g,minLength:20.95,maxLength:23.49}:g)}
 return {...base,element,authoredPolicyProof:proof,tiWindowProposal:{freshMaximumManhattanMm:14.6,caclmMm:22.22,toleranceMm:1.27,changedProps:[{busId:"DDR_COMMAND_CLOCK",field:"minLength",before:21.15,after:20.95},{busId:"DDR_COMMAND_CLOCK",field:"maxLength",before:23.69,after:23.49}],allPhysicalPlacementsAndOriginalThreeRigidXMotionsHeld:true,newCoreBuildPerformed:false,newNativePlacementCheckPerformed:false}}
}
export default()=>buildV12eCTiWindowSource().element
