import {Children,cloneElement,isValidElement,type ReactElement,type ReactNode} from "react"
import {readFileSync,writeFileSync} from "node:fs"
import {buildV12eCSource} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-c-cohort-layer-swap-source-next/v12e-c-final-layer-overlay"
import {buildV12eCTiWindowSource} from "./v12e-c-fresh-ti-window-overlay"
if(import.meta.main){
 const [output,...extra]=process.argv.slice(2);if(!output||extra.length)throw Error("Usage: bun --smol capture-v12e-c-ti-window.ts FRESH_OUTPUT_JSON")
 const rawBefore=buildV12eCSource(),after=buildV12eCTiWindowSource()
 function identityClone(node:ReactNode):ReactNode{if(!isValidElement<Record<string,unknown>>(node))return node;return cloneElement(node as ReactElement<Record<string,unknown>>,{...node.props},...Children.toArray(node.props.children as ReactNode).map(identityClone))}
 const before={...rawBefore,element:identityClone(rawBefore.element)}
 let comparedElements=0;const changes:Array<Record<string,unknown>>=[]
 function compare(a:ReactNode,b:ReactNode,path:string){
  if(!isValidElement<Record<string,unknown>>(a)||!isValidElement<Record<string,unknown>>(b)){if(JSON.stringify(a)!==JSON.stringify(b))throw Error("Non-element changed: "+path);return}
  comparedElements++;if(a.type!==b.type||a.key!==b.key)throw Error("Source type or key changed: "+path)
  const pa={...a.props},pb={...b.props};delete pa.children;delete pb.children
  if(pa.name==="DDR_COMMAND_CLOCK"){
   if(a.type!=="bus")throw Error("Original CA bus required")
   for(const [field,oldValue,newValue] of [["minLength",21.15,20.95],["maxLength",23.69,23.49]] as const){
    if(pa[field]!==oldValue||pb[field]!==newValue)throw Error("Exact fresh TI CA window required")
    changes.push({busId:pa.name,field,before:pa[field],after:pb[field]});pb[field]=pa[field]
   }
  }
  if(JSON.stringify(pa)!==JSON.stringify(pb))throw Error("Unexpected source props changed: "+path)
  const ca=Children.toArray(a.props.children as ReactNode),cb=Children.toArray(b.props.children as ReactNode);if(ca.length!==cb.length)throw Error("Source children count changed")
  ca.forEach((child,i)=>compare(child,cb[i],path+"/"+i))
 }
 compare(before.element,after.element,"board");if(changes.length!==2||changes.some(c=>c.busId!=="DDR_COMMAND_CLOCK"))throw Error("Exactly two CA length props required")
 const expected=JSON.parse(readFileSync(new URL('./derived-final-authored-props.json',import.meta.url),'utf8'))
 for(const key of ["placementProposal","authoredPolicyProof","referenceCopperCandidates","globalSignalLayerProjection","naturallyDerivedGenericDefaultCap"] as const)if(JSON.stringify(after[key])!==JSON.stringify(expected[key]))throw Error("Fresh TI source metadata mismatch: "+key)
 for(const key of ["placementProposal","referenceCopperCandidates","globalSignalLayerProjection","naturallyDerivedGenericDefaultCap","referenceQualified","TIplaneArrangement"] as const)if(JSON.stringify(after[key])!==JSON.stringify(before[key]))throw Error("Non-window C source field changed: "+key)
 const oldProof={...after.authoredPolicyProof,groups:after.authoredPolicyProof.groups.map(g=>g.busId==="DDR_COMMAND_CLOCK"?{...g,minLength:21.15,maxLength:23.69}:g)}
 if(JSON.stringify(oldProof)!==JSON.stringify(before.authoredPolicyProof))throw Error("Only CA min/max proof fields may change")
 writeFileSync(output,JSON.stringify({scope:"PURE_ACTUAL_V12E_C_FRESH_TI_CA_TWO_LENGTH_PROPS_ONLY",actualFinalReactTreeEvaluated:true,comparedElements,allOtherTreePropsTypesKeysChildrenExactlyHeld:true,changedLengthProps:changes,placementProposal:after.placementProposal,authoredPolicyProof:after.authoredPolicyProof,referenceCopperCandidates:after.referenceCopperCandidates,globalSignalLayerProjection:after.globalSignalLayerProjection,naturallyDerivedGenericDefaultCap:after.naturallyDerivedGenericDefaultCap,tiWindowProposal:after.tiWindowProposal,referenceQualified:false,TIplaneArrangement:false,newCoreBuildPerformed:false,newNativePlacementCheckPerformed:false,coreRenderCalled:false,nativePlacementChecksInvoked:false,routingSolverInstantiated:false,accepted49:false,fabricationReady:false},null,2)+"\n",{flag:"wx",mode:0o600})
}
