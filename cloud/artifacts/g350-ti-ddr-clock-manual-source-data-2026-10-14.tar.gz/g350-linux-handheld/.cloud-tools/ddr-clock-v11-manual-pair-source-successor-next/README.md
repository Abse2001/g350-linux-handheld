This is an unexecuted, explicit manual-routing Source successor. Root must
independently read it, bind a finite peer GO and authorize three separate serial
stages. It preserves d011, ed2, both actual failed captures/Core outputs, all
hardware sources and both SDK trees. It neither edits circuit-JSON nor writes
old generated PCB/Source bus IDs onto new copper.

Actual Root82627 retained both complete clocks with their exact original
numeric owners, three direct paths each, real Inner1 ports and V11 planar
lengths. Four duplicate Top stubs and three expanded pair buses caused a real
failure. Source capture had missed that deleting pcbPath before cloneElement
retains the original pcbPath=[]; the successor explicitly overrides undefined
and checks forward suppression before inverse restoration. Native/Core routing
remains disabled; the public manual renderer returns without a path prop.

The successor replaces exactly three DifferentialPair literals with public
Bus literals using their original ordered two trace names and .127 mm skew.
The full inverse restores every original type, key, prop (including .12 mm
pcbTraceGap), container and child order. Four real layer ports and the existing
six PCB-only changes remain. All 96 local Source branches remain declared.
The expected totals remain 2228→2232 React elements, 225 physical barrels and
263 PCB paths. Root must prove those totals and each physical ownership;
267 paths cannot be accepted as the expected result.

This representation preserves the original eight serialized bus names, ordered
membership and every emitted constraint. Bus and DifferentialPair emit during
different official phases, so fresh generated Source bus IDs may change. The
worker derives a complete bijection by exact names/member order/constraint
fields and reports both old and actual new IDs. It preserves actual identities;
it does not retag them or accept extra members. The original 49 numeric trace
rows, 98 named net rows, package sources and physical hole shapes remain exact.

Bus is not equivalent to automatic Core SRJ DifferentialPair discovery. For
this manual fork, do not route with Core-generated SRJ. The immutable complete
49-signal input ed97be5fae82111e8e08247ba97f2a4a5977d33bd1b901a0428a1cf155af59fc
retains all three original differential declarations (.127 mm skew/.12 mm gap),
all buses and other TI assertions. Original coupling/shared/exterior/physical
checks against actual geometry remain mandatory. Existing Root50372 qualifies
only frozen V11 clock geometry under its explicit scope; Source/Core alone does
not qualify newly rendered copper or unfinished DQS/global49 routes.

The Core worker preserves raw serializer bytes before assertions and compares
those parsed bytes with the parsed baseline. Runtime Core objects contain
undefined-valued optional schema properties absent from JSON; comparing them
as literal enumerable keys created false net/hole/logical failures in82627.
Parsing the exact preserved bytes performs no geometry or ownership edit.

The original 7bd process helper, complete board Ce3 inventory, solver47633 tree
and archive checks remain exact. Source inputs are immutable/private frozen
files; the full solver Git checkout is not assumed to remain at historical
C115. New D7 HEAD source is for separate reviewed solver tests. Shared budget
30 GiB plus 1 GiB reserve; capture60s/1GiB, types120s/2GiB, Core90s/2GiB. Those
budgets are unchanged from ed2, whose actual Source/types and failed Core
measurements are retained. New application stages remain unrun.

Root authority must bind actual42982 closure, all required prior collected
scopes (50372,91494,52953,74203,82627), and every later Root owned scope, including
current25380 only after its actual collection. No concurrent app worker.
Successful capture is mandatory before types; both actual capture0/types0 are
mandatory before Core. Negative raw/diagnostic/output bytes remain retained.
No explicit Native, CLI, CAD, routing, 49 acceptance or fabrication publication
occurs in this packet. fabricationReady=false.

Run each phase separately only after Root's fresh finite authority:

    source cloud/env.sh
    python -B .cloud-tools/ddr-clock-v11-manual-pair-source-successor-next/guard.py \
      --run --phase capture --root-receipt /ABS/ACTUAL_ROOT_CAPTURE_AUTHORITY.json \
      --root-receipt-sha256 ACTUAL_SHA256

Repeat with a different actual Root authority for phase types, then phase core.
The template is explicitly not an authorization. Guard/preflight, Source,
types and Core have not executed for this packet during authoring.
