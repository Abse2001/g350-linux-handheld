"""Pure stdlib geometry of explicit public-JSON joint ordinary fanout plan; no runtime/acceptance."""
exec(open('/tmp/g350-generic-focus-static-helper.py').read())
P='/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json';PIN='cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
R='/tmp/g350-current243-cpu-cycle42A16-11SW-2NE-joint-planning-screen-report.json';RPIN='4737965e5e21b45f642bde94a47c3dfc81150d649dbfd45b1f3a7c06267326ec';assert hashlib.sha256(Path(R).read_bytes()).hexdigest()==RPIN
r=json.load(open(R));g=focus(26,P,PIN);xy=lambda p:dict(zip(('x','y'),p))
bodyinvs=[r['body'+str(n)+'Inverse'] for n in (2,11,35,42)];removed={b['before']['pcb_trace_id'] for b in bodyinvs}|{b['before']['pcb_trace_id'] for b in r['cpuFanoutInverses']};g['objects'][:]=[o for o in g['objects'] if o['id'] not in removed]
def addtrace(t):
 own=t.get('connection_name') or t.get('source_trace_id')
 for i,p in enumerate(t['route']):
  if p['route_type']=='via':o={'kind':'via','p':p,'radius':p['via_diameter']/2,'holeRadius':p['via_hole_diameter']/2,'layers':p['layers'],'index':i,'owner':own,'id':t['pcb_trace_id']};o['bbox']=g['bbox'](o);g['objects'].append(o)
  elif i and t['route'][i-1]['route_type']=='wire' and t['route'][i-1]['layer']==p['layer']:
   a=t['route'][i-1];o={'kind':'wire','a':a,'b':p,'radius':max(a.get('width',.1016),p.get('width',.1016))/2,'layers':[p['layer']],'index':i,'owner':own,'id':t['pcb_trace_id']};o['bbox']=g['bbox'](o);g['objects'].append(o)
for inv in bodyinvs+r['cpuFanoutInverses']:addtrace(inv['after'])
def hits(a,b,l):return [{'owner':o['owner'],'id':o['id'],'index':o['index']} for o in g['wireContacts'](xy(a),xy(b),l)]
rows=[]
for a,b,l,name in [((.8,12.8),(.8,7.9196),'inner2','EXACT_RELEASED_OLD2_TRUNK'),((0,12.25),(.25,12.25),'inner2','HEAD_EAST'),((.25,12.25),(.8,11.7),'inner2','SMOOTH_DIRECT_TRUNK_ENTRY'),((.8,12.8),(1,13),'inner2','Q_NE_CONTINUATION'),((1,13),(1.2,13),'inner2','Q_EAST_TURN'),((1.2,13),(1.4,12.8),'inner2','Q_SE_TURN'),((.8,9.4),(1.2,9),'inner2','RAM_DIAGONAL_ENTRY'),((.8,7.9196),(.9524,7.7672),'inner2','OLD2_FIRST_DIAGONAL')]:rows.append({'name':name,'layer':l,'a':a,'b':b,'foreignContacts':hits(a,b,l)})
for row in rows: print(json.dumps(row))
out={'scope':'PURE_CONDITIONAL_CPU_CYCLE_D12_I2_TRUNK_FRONTIER_NO_SDK_NO_ACCEPTANCE','inputSha256':PIN,'jointProofSha256':RPIN,'tests':rows,'cap8StillUnmoved':True,'all49Accepted':False};O='/tmp/g350-current243-cpu-cycle-D12-I2-trunk-frontier-static.json';Path(O).write_text(json.dumps(out,indent=2)+'\n');print(O)
