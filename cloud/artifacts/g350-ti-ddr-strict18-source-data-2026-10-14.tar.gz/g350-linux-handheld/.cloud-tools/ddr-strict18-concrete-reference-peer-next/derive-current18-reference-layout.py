"""Finite analytic adjacent-reference layout screen. Stdlib only; no apps/route/fill/physics."""
import ast,collections,hashlib,json,math
from pathlib import Path
ROOT=Path('/workspace/g350-linux-handheld'); HERE=Path(__file__).parent
ROUTES=ROOT/'.cloud-tools/ddr-byte1-matched-cohort-followthrough-sourceonly-next/NORMALIZED_MATCHED_DQS0_INNER1_SOURCE30_BOTTOM_SOURCE40_INNER2_SOURCE31_INNER1_JOINT_DATASET18_08.json'
REPORT=ROOT/'.cloud-tools/ddr-byte1-matched-cohort-followthrough-sourceonly-next/STRICT_MATCHED_DQS0_INNER1_SOURCE30_BOTTOM_SOURCE40_INNER2_SOURCE31_INNER1_RECIPROCAL18_REPORT08.json'
FULL=ROOT/'.cloud-tools/ddr-package101-plus96-signals-combined-sourceonly-next/combined-input.json'
CONTEXT=ROOT/'.cloud-tools/ddr-package101-plus96-signals-combined-sourceonly-next/native-context.json'
CORE=ROOT/'.cloud-tools/ddr-package101-core-qualification-source-next/run-core/fresh-core.circuit.json'
MATH_SOURCE=ROOT/'.cloud-tools/ddr-strict13-reference-layout-sourceonly-next/derive-concrete-layout.py'
PINS={str(ROUTES):'21316c4be094f8ec42c2d69a02b70e716ff80c5b49a3b906be78873450ad62d4',str(REPORT):'d8d52732bb2fc7d0b671fd2b27054dc42cfbc427ac88a96fe5caf7172384126c',str(FULL):'ed97be5fae82111e8e08247ba97f2a4a5977d33bd1b901a0428a1cf155af59fc',str(CONTEXT):'e9edfcd1b47c6d04ffa2a817a6957ed5b395a8f8f2d4554a03cf28eda589e44e',str(CORE):'ed33a0a335b1fbf0da9adcdeacaa954b655c3c4964c600efb6ef3c72aef4040e',str(MATH_SOURCE):'88ea3d3f9ce0d1e1ff3f3cccfa837aaca27cc8bdce9243846758a7a174e60a1d'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(v,m):
 if not v:raise ValueError(m)
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
 p.chmod(0o600)
for p,h in PINS.items():require(Path(p).is_file() and not Path(p).is_symlink() and sha(Path(p))==h,'Exact regular input '+p)
r=json.loads(ROUTES.read_bytes());report=json.loads(REPORT.read_bytes());full=json.loads(FULL.read_bytes());context=json.loads(CONTEXT.read_bytes());core=json.loads(CORE.read_bytes())
require(len(r['records'])==len({v['sourceTraceId'] for v in r['records']})==18 and r['sourceReportSha256']==PINS[str(REPORT)] and report['fullInputSha256']==PINS[str(FULL)],'Exact current18 authority')
require(report['inputPhysicalViolationCount']==report['selfFailedConductorCount']==0 and report['allPhysicalSelfAndMeterChecksPassedForLoadedSubset'],'Retained physical0 proof')
require(len(context['referenceVias'])==129 and len(context['signalDogbones'])==96 and len(context['allOriginalCopperLands'])==1165,'Fixed original225/1165')
bytype={}
for row in core:
 if row['type'] in ['pcb_via','source_net','pcb_port','source_port','source_component','pcb_smtpad','pcb_plated_hole']:
  bytype.setdefault(row['type'],{})[row[row['type']+'_id']]=row
require(bytype['source_net']['source_net_0']['name']=='GND' and bytype['source_net']['source_net_5']['name']=='DDR_1V5','Authentic reference owner names')
for v in context['referenceVias']:require(bytype['pcb_via'][v['pcb_via_id']]==v,'129 exact actual Source reference barrels')
# Retain only finite pure analytic interval definitions; never import or run old author module.
a=ast.parse(MATH_SOURCE.read_text());names={'xy','merge','linear_band','circle_interval','capsule_intervals','box_intervals','rounded_rect_intervals','blocked','item_bbox','overlap'}
g={'math':math};exec(compile(ast.Module(body=[n for n in a.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'pinned-pure-analytic-intervals','exec'),g)
xy,merge,blocked,item_bbox,overlap=[g[n] for n in ['xy','merge','blocked','item_bbox','overlap']]
WIDTH=.1016;CLEAR=.12;HALF=.4;ADJ={'top':'inner1','inner1':'top','inner2':'bottom','bottom':'inner2'}
items=[]
for i,o in enumerate(full['obstacles']):
 md=o.get('circuitJsonMetadata',{});ident=md.get('pcb_via_id') or md.get('pcb_smtpad_id') or md.get('pcb_plated_hole_id') or md.get('pcb_hole_id') or md.get('pcb_keepout_id') or 'obstacle_'+str(i)
 net='GND' if 'source_net_0' in o.get('connectedTo',[]) else 'DDR_1V5' if 'source_net_5' in o.get('connectedTo',[]) else 'FOREIGN_OR_UNNAMED'
 c=xy(o['center']);w,h=o['width'],o['height']
 if o.get('shape')=='circle':shape={'kind':'capsule','a':c,'b':c,'radius':max(w,h)/2}
 else:shape={'kind':'rect_conservative_bound','box':(c[0]-w/2,c[0]+w/2,c[1]-h/2,c[1]+h/2)}
 items.append({'id':ident,'net':net,'layers':o['layers'],'basis':'AUTHENTIC_FIXED_OBSTACLE','metadata':md,**shape})
for t in full['traces']:
 netid=t.get('physicalContextMetadata',{}).get('source_net_id');net='GND' if netid=='source_net_0' else 'DDR_1V5' if netid=='source_net_5' else 'FOREIGN_OR_UNNAMED'
 for i,(a,b) in enumerate(zip(t['route'],t['route'][1:])):
  if a['route_type']==b['route_type']=='wire' and a['layer']==b['layer'] and xy(a)!=xy(b):
   require(a['width']==b['width'],'Fixed exact width');items.append({'id':t['pcb_trace_id']+':segment:'+str(i),'net':net,'layers':[a['layer']],'basis':'AUTHENTIC_FIXED_LOCAL_COPPER','kind':'capsule','a':xy(a),'b':xy(b),'radius':a['width']/2})
 for i,p in enumerate(t['route']):
  if p['route_type']=='via':items.append({'id':t['pcb_trace_id']+':barrel:'+str(i),'net':net,'layers':p['layers'],'basis':'AUTHENTIC_FIXED96_SIGNAL_BARREL','kind':'capsule','a':xy(p),'b':xy(p),'radius':p['via_diameter']/2})
for rec in r['records']:
 for i,(a,b) in enumerate(zip(rec['path'],rec['path'][1:])):
  if xy(a)!=xy(b):items.append({'id':rec['sourceTraceId']+':carrier:'+str(i),'sourceTraceId':rec['sourceTraceId'],'net':'FOREIGN_SIGNAL','layers':[rec['layer']],'basis':'CURRENT18_MAIN_SIGNAL','kind':'capsule','a':xy(a),'b':xy(b),'radius':WIDTH/2})

def spans_for(rec,selected,half,clearance):
 prefix=0;intervals=[];matches=[]
 for i,(aa,bb) in enumerate(zip(rec['path'],rec['path'][1:])):
  a,b=xy(aa),xy(bb);length=math.dist(a,b)
  if not length:continue
  bounds=(min(a[0],b[0]),max(a[0],b[0]),min(a[1],b[1]),max(a[1],b[1]))
  for item in selected:
   if not overlap(bounds,item_bbox(item,half+clearance)):continue
   ii=blocked(a,b,item,half,clearance)
   if ii:
    positions=[[prefix+lo*length,prefix+hi*length] for lo,hi in ii];intervals+=positions
    matches.append({'segmentIndex':i,'foreignOwnerId':item['id'],'foreignSourceTraceId':item.get('sourceTraceId'),'foreignBasis':item['basis'],'segmentFractions':ii,'distanceAlongCarrierMm':positions,'projectedEndpointPairs':[[{'x':a[0]+lo*(b[0]-a[0]),'y':a[1]+lo*(b[1]-a[1])},{'x':a[0]+hi*(b[0]-a[0]),'y':a[1]+hi*(b[1]-a[1])}] for lo,hi in ii]})
  prefix+=length
 union=merge(intervals)
 return {'blockedDistanceIntervalsMm':union,'blockedLengthMm':sum(hi-lo for lo,hi in union),'carrierLengthMm':prefix,'foreignOwnerMatches':matches}
results=[];pairs=[]
for rec in r['records']:
 adj=ADJ[rec['layer']];main=[i for i in items if adj in i['layers'] and i['basis']=='CURRENT18_MAIN_SIGNAL'];ground=[i for i in items if adj in i['layers'] and i['net']!='GND'];preserved_net='DDR_1V5' if rec['layer']=='bottom' else 'GND';preserved=[i for i in items if adj in i['layers'] and i['net']!=preserved_net]
 out={'sourceTraceId':rec['sourceTraceId'],'signalLayer':rec['layer'],'adjacentNearFaceReferenceLayer':adj,'class':rec['class'],'mainSignalsZeroPourClearancePhysicalFootprint':spans_for(rec,main,WIDTH/2,0),'mainSignalsP12PourClearancePhysicalFootprint':spans_for(rec,main,WIDTH/2,CLEAR),'allFixedAndCurrent18GroundP12Footprint':spans_for(rec,ground,WIDTH/2,CLEAR),'allFixedAndCurrent18GroundP4HalfReservation':spans_for(rec,ground,HALF,CLEAR),'preservedPlaneOwner':preserved_net,'preservedPlaneOwnerP12Footprint':spans_for(rec,preserved,WIDTH/2,CLEAR)}
 results.append(out)
 for foreign_id in sorted({i['sourceTraceId'] for i in main}):
  pp=spans_for(rec,[i for i in main if i['sourceTraceId']==foreign_id],WIDTH/2,CLEAR)
  if pp['blockedLengthMm']>0:pairs.append({'signal':rec['sourceTraceId'],'signalLayer':rec['layer'],'adjacentSignal':foreign_id,'adjacentLayer':adj,**pp})
# Concrete planar reservations: all explicitly candidates, foreign cutouts remain required.
compartments=[
 {'name':'TOP_WEST_CLOCK_GND_CANDIDATE','layer':'top','targets':['source_trace_33','source_trace_34'],'bounds':[-8.238186070478214,1.6,3.8,14.0]},
 {'name':'TOP_EAST_DATA_DQS_GND_CANDIDATE','layer':'top','targets':['source_trace_29','source_trace_15','source_trace_16','source_trace_31'],'bounds':[1.1835,6.4,3.0,16.0]},
 {'name':'BOTTOM_RIGHT_BYTE1_GND_CANDIDATE','layer':'bottom','targets':[rec['sourceTraceId'] for rec in r['records'] if rec['layer']=='inner2'],'bounds':[-.4,8.0,3.4,16.0]},
 {'name':'INNER1_TOP3_GND_COMPARTMENT_CANDIDATE','layer':'inner1','targets':['source_trace_3'],'bounds':[2.8,7.677207793864214,7.0,13.2]},
 {'name':'INNER2_BOTTOM_DATA_GND_COMPARTMENT_SOURCE_FORK_ONLY','layer':'inner2','targets':[rec['sourceTraceId'] for rec in r['records'] if rec['layer']=='bottom'],'bounds':[0.0,8.0,3.8,14.4],'replacesExistingPowerInArea':True}
]
gndvias=[v for v in context['referenceVias'] if v['source_net_id']=='source_net_0']; ground_lands=[]
for land in context['allOriginalCopperLands']:
 port=bytype['pcb_port'][land['pcb_port_id']];sp=bytype['source_port'][port['source_port_id']];sck=sp.get('subcircuit_connectivity_map_key')
 if sck==bytype['source_net']['source_net_0'].get('subcircuit_connectivity_map_key'):
  owner=bytype['source_component'][sp['source_component_id']]['name'];point=xy(land) if 'x'in land else (sum(p['x'] for p in land['points'])/len(land['points']),sum(p['y'] for p in land['points'])/len(land['points']))
  ground_lands.append({'sourceLandId':land.get('pcb_smtpad_id') or land.get('pcb_plated_hole_id'),'pcbPortId':land['pcb_port_id'],'sourcePortId':sp['source_port_id'],'numericPin':sp['pin_number'],'ownerName':owner,'x':point[0],'y':point[1],'layer':land.get('layer'),'layers':land.get('layers')})

def point_foreign_collisions(p,layer,radius):
 out=[]
 for item in items:
  if layer not in item['layers'] or item['net']=='GND':continue
  if item['kind']=='capsule':
   a,b=item['a'],item['b'];dx,dy=b[0]-a[0],b[1]-a[1];den=dx*dx+dy*dy;t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den)) if den else 0;edge=math.dist(p,(a[0]+t*dx,a[1]+t*dy))-item['radius']
  else:
   x0,x1,y0,y1=item['box'];edge=math.hypot(max(x0-p[0],0,p[0]-x1),max(y0-p[1],0,p[1]-y1))
  if edge<radius+full['minViaEdgeToPadEdgeClearance']-1e-12:out.append(item['id'])
 return out
for comp in compartments:
 x0,x1,y0,y1=comp['bounds'];comp['referenceNet']='GND';comp['outline']=[{'x':x0,'y':y0},{'x':x1,'y':y0},{'x':x1,'y':y1},{'x':x0,'y':y1}];comp['pourClearanceMm']=CLEAR;comp['candidateOnly']=True;comp['continuousCoverageClaimed']=False;comp['filledConnectivityQualified']=False;comp['reuseActualGroundBarrels']=[]
 for v in gndvias:
  rad=v['outer_diameter']/2
  if not(x0+rad+CLEAR<=v['x']<=x1-rad-CLEAR and y0+rad+CLEAR<=v['y']<=y1-rad-CLEAR):continue
  comp['reuseActualGroundBarrels'].append({'pcbViaId':v['pcb_via_id'],'sourceNetId':'source_net_0','sourceNetName':'GND','x':v['x'],'y':v['y'],'outerDiameterMm':v['outer_diameter'],'holeDiameterMm':v['hole_diameter'],'layers':v['layers'],'newHole':False,'sameLayerForeignScreenConflicts':point_foreign_collisions((v['x'],v['y']),comp['layer'],rad)})
 comp['actualGroundNumericLands']=[v for v in ground_lands if (v['layer']==comp['layer'] or comp['layer']in(v.get('layers') or [])) and x0<=v['x']<=x1 and y0<=v['y']<=y1]
 comp['mainSignalBlockedLengthByTarget']={x['sourceTraceId']:x['mainSignalsP12PourClearancePhysicalFootprint']['blockedLengthMm'] for x in results if x['sourceTraceId']in comp['targets']}
 comp['allFixedGroundFootprintBlockedLengthByTarget']={x['sourceTraceId']:x['allFixedAndCurrent18GroundP12Footprint']['blockedLengthMm'] for x in results if x['sourceTraceId']in comp['targets']}
 # Demand rectangles containing shadow collisions cannot claim filled corridor.
 comp['directGroundAreaFeasiblePiecesOnly']=not any(comp['mainSignalBlockedLengthByTarget'].values())
transition_candidates=[]
for rec in r['records']:
 for end,label in [(xy(rec['path'][0]),'CPU'),(xy(rec['path'][-1]),'RAM')]:
  candidates=sorted(gndvias,key=lambda v:math.dist(end,(v['x'],v['y'])))[:3]
  transition_candidates.append({'sourceTraceId':rec['sourceTraceId'],'endLabel':label,'signalBarrelCoordinate':{'x':end[0],'y':end[1]},'nearestAuthenticGroundBarrelCandidates':[{'pcbViaId':v['pcb_via_id'],'sourceNetId':'source_net_0','x':v['x'],'y':v['y'],'centerDistanceMm':math.dist(end,(v['x'],v['y'])),'sameAdjacentReferenceLayerForeignScreenConflicts':point_foreign_collisions((v['x'],v['y']),ADJ[rec['layer']],v['outer_diameter']/2),'newHole':False} for v in candidates],'returnImpedanceQualified':False})
out={'scope':'CURRENT_STRICT18_CONCRETE_ADJACENT_GROUND_RESERVATIONS_AND_ANALYTIC_SHADOW_INTERVALS_SOURCE_ONLY','pins':PINS,'currentCarrierCount':18,'requiredFullSignals':49,'remaining49Signals':31,'retainedCurrentPhysical0Report':True,'fixedReferenceBarrelInventory':{'allReference':129,'actualGnd':len(gndvias),'actualDdrPower':len(context['referenceVias'])-len(gndvias),'signalBarrels':96,'allFixed':225},'signalLayerCounts':dict(collections.Counter(v['layer']for v in r['records'])),'nearFaceReferenceLayerMapping':ADJ,'nominalCandidateNearFaceDielectricMm':.0764,'manufacturer1080SelectionConfirmed':False,'groundPourClearanceMm':CLEAR,'signalWidthMm':WIDTH,'provisionalReservationHalfWidthMm':HALF,'analyticMainOnlyAndFixedDeficits':results,'directedCrossLayerSignalPairIntervals':pairs,'groundCompartmentCandidates':compartments,'returnTransitionGroundSiteCandidates':transition_candidates,'original225Barrels96Stubs1165Lands261FixedTracesHeld':True,'proposed227OrCa48Adopted':False,'sourceOnly':True,'actualAppImports':0,'nativeCalls':0,'cadCalls':0,'actualEmSiRuns':0,'filledCoverageQualified':False,'referenceQualified':False,'electricalTimingQualified':False,'accepted49':False,'fabricationReady':False,'limitations':['Analytic floating-point capsules/circles exact for modeled line geometry, not field solver; noncircular land/keepout rectangles are conservative bounding geometry.','Main-carrier shadows persist even at zero ground clearance and the minimum .1016mm signal footprint; no ground patch can occupy the same projected actual adjacent-layer signal copper.','Fixed signal-via lands/antipads including own transitions are screened without exemptions; an actual active-via/return model must resolve those launch-region gaps.','Candidate rectangle outlines reserve concrete geometry only. They are not filled patches and cannot bridge every reported foreign-copper hole or prove all islands connected.','Original Inner1 GND and Inner2 DDR_1V5 plane owners remain frozen unqualified evidence. Local Inner2 GND replacement requires a separate exact Source fork, power cutout/continuity/PDN validation and every native/CAD gate.','Conditional1080 near-face dielectric is not manufacturer-selected or qualified. A far central dielectric cannot be substituted as a passing adjacent reference by a label.','Do not adopt route layer swaps, endpoint moves, new stitches, CA48/cap9/227 proposed scene or stale strict13 patches from this report.']}
write(HERE/'REFERENCE_LAYOUT_AND_SHADOW_REPORT.json',out)
summary={'sourceTraceId':{},'directedPairCount':len(pairs),'compartments':[]}
for q in results:summary['sourceTraceId'][q['sourceTraceId']]={'layer':q['signalLayer'],'referenceLayer':q['adjacentNearFaceReferenceLayer'],'mainZeroClearanceMm':q['mainSignalsZeroPourClearancePhysicalFootprint']['blockedLengthMm'],'mainP12Mm':q['mainSignalsP12PourClearancePhysicalFootprint']['blockedLengthMm'],'fullGndP12Mm':q['allFixedAndCurrent18GroundP12Footprint']['blockedLengthMm'],'preservedOwnerP12Mm':q['preservedPlaneOwnerP12Footprint']['blockedLengthMm']}
for c in compartments:summary['compartments'].append({'name':c['name'],'layer':c['layer'],'bounds':c['bounds'],'groundBarrelIds':[v['pcbViaId'] for v in c['reuseActualGroundBarrels']],'conflictedStitchIds':[v['pcbViaId'] for v in c['reuseActualGroundBarrels'] if v['sameLayerForeignScreenConflicts']],'groundLandCount':len(c['actualGroundNumericLands']),'directGroundAreaFeasiblePiecesOnly':c['directGroundAreaFeasiblePiecesOnly']})
summary['largestDirectedPairs']=[{'signal':x['signal'],'adjacentSignal':x['adjacentSignal'],'signalLayer':x['signalLayer'],'adjacentLayer':x['adjacentLayer'],'blockedLengthMm':x['blockedLengthMm'],'intervals':x['blockedDistanceIntervalsMm']}for x in sorted(pairs,key=lambda x:x['blockedLengthMm'],reverse=True)[:18]]
write(HERE/'SUMMARY.json',summary)
require(all(sha(Path(p))==h for p,h in PINS.items()),'All frozen input bytes held after')
print(json.dumps({'reportSha256':sha(HERE/'REFERENCE_LAYOUT_AND_SHADOW_REPORT.json'),'summarySha256':sha(HERE/'SUMMARY.json'),**summary}))
