import { strict as assert } from "node:assert"
import { readFileSync } from "node:fs"
import { isDeepStrictEqual } from "node:util"
import { test } from "bun:test"
import { validateParentCaptureSummaries } from "./parent-summary"
const load = (name: string) =>
  JSON.parse(readFileSync(`${import.meta.dir}/${name}`, "utf8"))
test("actual saved jobs reproduce original parent hash summaries; prior raw assertion fails", () => {
  const parent = load("parent-result.json"),
    captures = [2, 1, 3].map((id) => load(`job-${id}.json`))
  const before = JSON.stringify({ parent, captures })
  assert.equal(isDeepStrictEqual(parent.captures, captures), false)
  assert.equal(validateParentCaptureSummaries(parent.captures, captures), true)
  assert.equal(JSON.stringify({ parent, captures }), before)
  for (const mutate of [
    (c: any[]) => c[0].arguments.push("foreign"),
    (c: any[]) => (c[0].result[0].route[0].x += 0.1),
    (c: any[]) => c[0].nextCalls++,
    (c: any[]) => c.reverse(),
  ]) {
    const changed = structuredClone(captures)
    mutate(changed)
    assert.throws(
      () => validateParentCaptureSummaries(parent.captures, changed),
      /relationship/,
    )
  }
})
