"""Root-owned CAD child resource observations, no Docker imports or subprocesses."""
import json,re,shutil,stat,sys
from pathlib import Path

def main():
 assert len(sys.argv)==11
 path,phase,name,expected,image,driver,docker_root,image_bytes,empty,outcome=sys.argv[1:]
 path=Path(path);assert path.is_absolute()and path.resolve()==path and path.parent.parent==Path('/tmp')and re.fullmatch('g350-source26-cad-root-[A-Za-z0-9_-]+',path.parent.name)and path.name=='cad-resource-observations.json'
 assert phase in ('BEFORE_CONTAINER','AFTER_CLEANUP')and re.fullmatch('g350-source26-fresh-cad-[0-9a-f]{16}-[0-9a-f]{16}',name)
 assert expected=='sha256:11b9360b20752e87f20942639e229b0d111e96f6e30b1bd1cb2eaafce9f26cfc'and image==expected
 assert re.fullmatch('[A-Za-z0-9_-]+',driver)and Path(docker_root).is_absolute()and int(image_bytes)>0 and empty in ('unknown','true','false')
 assert docker_root=='/var/lib/docker','Actual Docker storage root must match the sampled process disk guard'
 free=shutil.disk_usage(docker_root).free;required=2*int(image_bytes)+192*1024*1024 if driver=='vfs'else 0
 row={'phase':phase,'imageId':image,'imageSizeBytes':int(image_bytes),'storageDriver':driver,'dockerRootDir':docker_root,'freeBytesActuallyObserved':free,'requiredVfsBytes':required,'actualVfsReserveSatisfiedAtObservation':free>=required,'imageAlreadyPresent':True,'noImageLoadBuildPull':True,'vfsOverheadBufferBytes':201326592,'continuousDiskMinimumFreeBytesExpected':134217728}
 if phase=='BEFORE_CONTAINER':
  assert empty=='unknown'and not path.exists()and not path.is_symlink();value={'scope':'ROOT_OWNED_CAD_CHILD_ACTUAL_DOCKER_RESOURCES','containerName':name,'imageId':image,'previousScope45ContainerName':'g350-source24-fresh-cad-2daf946d02c2622f-ba1ae2eb02401321','previousScope45ContainerAbsenceCheckPassed':True,'previousScope46ContainerName':'g350-source24-fresh-cad-5d76e3e1fa307eab-795b80f87262657d','previousScope46ContainerAbsenceCheckPassed':True,'observations':[row],'ownedContainerActuallyEmpty':None,'cleanupStatusRecorded':False,'containerWorkerStatus':None,'authorizedByThisReporter':False,'accepted49':False,'fabricationReady':False}
  mode='x'
 else:
  s=path.lstat();assert stat.S_ISREG(s.st_mode)and not path.is_symlink()and s.st_size<=65536 and stat.S_IMODE(s.st_mode)==0o600
  value=json.loads(path.read_text());assert value['containerName']==name and value['imageId']==image and len(value['observations'])==1 and value['observations'][0]['phase']=='BEFORE_CONTAINER'
  value['observations'].append(row);value['ownedContainerActuallyEmpty']={'true':True,'false':False,'unknown':None}[empty];value['cleanupStatusRecorded']=True;value['containerWorkerStatus']=int(outcome);mode='w'
 with path.open(mode)as f:json.dump(value,f,indent=2);f.write('\n')
 path.chmod(0o600)
 return 0
if __name__=='__main__':raise SystemExit(main())
