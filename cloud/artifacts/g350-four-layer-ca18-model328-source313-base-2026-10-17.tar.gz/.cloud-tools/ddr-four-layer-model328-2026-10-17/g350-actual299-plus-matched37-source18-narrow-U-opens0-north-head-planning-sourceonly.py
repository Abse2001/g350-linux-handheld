"""Own stdlib exact partial topology proposal; no SDK, source, or board acceptance."""
exec(open('/tmp/g350-actual299-plus-matched37-ground79-retire-I1-transfer-component-sourceonly.py').read().split('oldids=')[0])
old18=by['source_trace_18'];new18=copy.deepcopy(old18)
new18['route']=copy.deepcopy(old18['route'][:1])+[{'route_type':'wire','layer':'inner1','width':.1016,'x':x,'y':y}for x,y in[(-1.6,18.4),(-1.2,18.8),(-1.2,19.6),(-1.6,20),(-1.6,20.95),(-1.8,21.15),(-1.8176,21.15),(-2.0176,20.95)]]+copy.deepcopy(old18['route'][6:])
new18['pcb_trace_id']='planned18_narrow_north_U_via7_right_chicane_opens0_header'
assert new18['route'][0]==old18['route'][0] and new18['route'][-1]==old18['route'][-1]
oldids={t['pcb_trace_id']for t in p['carrierTraces']};objects=[o for o in BASE if o['id']not in oldids];after=dict(by);after['source_trace_18']=new18
for t in after.values():objects.extend(bodyobjects(t))
scene=Scene(objects)
rows=[{'owner':n,'contacts':scene.contacts(t)}for n,t in after.items()];assert all(not r['contacts']for r in rows)
header={'connection_name':'source_trace_0','pcb_trace_id':'ANALYSIS_ONLY0_NORTH_HEADER_NOT_COMPLETE_SIGNAL','route':[{'route_type':'wire','width':.1016,'layer':'inner1','x':x,'y':y}for x,y in[(-1.6,12.8),(-1.2,13.2),(-1.2,16.2),(-1,16.4),(-.6,16.4),(-.4,16.6),(-.4,20.2),(-.2,20.4),(1,20.4),(1.2,20.2),(1.2,16.4)]]}
headerContacts=scene.contacts(header);assert not headerContacts
native=selfreports(new18);assert all(r['passedPureMath']for r in native)
three=self_math(new18['route'],.3048)
fixed=sum(length(t)for t in f['traces']if owner(t)=='source_trace_18');whole=length(new18)+fixed;assert 20.950002<=whole<=21.585658
report={'scope':'UNACCEPTED_MATCHED_SOURCE18_NARROW_NORTH_U_AND_CLEAR_PARTIAL_SOURCE0_HEADER_NO_COMPLETE0_RETURN','inputBindings':{'actual299':{'path':P299,'sha256':S299},'matched37':{'path':P37,'sha256':S37}},'bodyInverse':{'owner':'source_trace_18','before':old18,'after':new18},'wholeBeforeMm':length(old18)+fixed,'wholeAfterMm':whole,'all49ReciprocalForeignReports':rows,'all49ForeignContactsZero':True,'entireFoundationLiteral299':True,'allNumericEndpointsWorkingBranchesViasAndReferenceMaterialHeld':True,'nativeStyleSelfMath':native,'threeWidthSelfObservation':three,'partial0Header':header,'partial0HeaderLengthMm':length(header),'partial0HeaderForeignContacts':headerContacts,'partial0HeaderSelfMath':selfreports(header),'incomplete0ReturnWitnesses':{'singleNativeTraceCpuColumn':{'xMm':-1.2,'foreignBarrelsOnEitherSide':[[-1.6,13.6],[-.8,13.6],[-1.6,14.4],[-.8,14.4]],'singleWireCenterWindowWidthMm':.8-2*.381},'eastI1ReturnWalls':['source_trace_29','source_trace_12','source_trace_26','source_trace_16']},'completeSource0RoutePresent':False,'mustNotPromoteWithoutComplete0Return':True,'SDKExecuted':False,'sourceCoreDerived':False,'nativeExecuted':False,'all49Accepted':False,'wholeTiRoutingQualified':False,'timingPassed':False,'fabricationReady':False}
out=Path('/tmp/g350-actual299-plus-matched37-source18-narrow-U-opens0-north-head-planning-report.json');out.open('x').write(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'whole18':whole,'all49ForeignZero':True,'source0Complete':False,'threeWidthSelf':three['passedPureMath']}))
