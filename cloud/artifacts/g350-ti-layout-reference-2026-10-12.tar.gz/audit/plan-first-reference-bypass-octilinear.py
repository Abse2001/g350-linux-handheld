"""Plan two real bypass vias and stubs against fresh physical pad geometry.
This creates a proposal only, never modifies a board or claims connectivity.
"""
import json, math, hashlib, sys
from pathlib import Path
sys.path.insert(0, '/workspace/g350-linux-handheld/.cloud-tools/python-routing')
from shapely.geometry import Point, Polygon, box, LineString
from shapely.affinity import rotate

ROOT = Path('/workspace/g350-linux-handheld')
SOURCE = ROOT / '.cloud-tools/ti-ddr-v2-source-export-bun-next/source/dist/experiments/am3352-g350-ti-top-bottom-ddr-v2-layout/circuit.json'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'f437b0ad4b5229cd065596e3a848feb714df519f83fd9a88593bf3ea0cae197a'
data = json.loads(raw)
names = {e['source_component_id']: e['name'] for e in data if e['type'] == 'source_component'}
components = {e['pcb_component_id']: names.get(e.get('source_component_id')) for e in data if e['type'] == 'pcb_component'}

def shape(e):
    if e['shape'] == 'polygon':
        return Polygon([(p['x'], p['y']) for p in e['points']])
    x, y = e['x'], e['y']
    if e['shape'] == 'circle':
        return Point(x, y).buffer(e['radius'], quad_segs=64)
    if e['shape'] == 'rect':
        return box(x-e['width']/2, y-e['height']/2, x+e['width']/2, y+e['height']/2)
    if e['shape'] == 'rotated_rect':
        return rotate(box(x-e['width']/2, y-e['height']/2, x+e['width']/2, y+e['height']/2), e['ccw_rotation'], origin=(x,y))
    raise ValueError('Unsupported exact pad shape: '+e['shape'])

pads = [(e, shape(e)) for e in data if e['type'] == 'pcb_smtpad']
assert len(pads) == 1161
keepouts = []
for e in data:
    if e['type'] != 'pcb_keepout': continue
    assert e['shape'] == 'rect'
    x,y=e['center']['x'],e['center']['y']
    keepouts.append((e, box(x-e['width']/2,y-e['height']/2,x+e['width']/2,y+e['height']/2)))

LAND, DRILL, WIDTH, GAP, DRILL_GAP = .4572, .254, .2, .1016, .2
selected = [e for e,_ in pads if components[e['pcb_component_id']] == 'C_DDR_RAM_7']
assert len(selected) == 2 and all(e['layer']=='bottom' for e in selected)
proposal=[]
for pad in sorted(selected, key=lambda e:e['port_hints']):
    own=next(g for e,g in pads if e is pad)
    candidates=[]
    for ix in range(85,146):
        for iy in range(141,185):
            x,y=ix*.05,iy*.05
            if math.hypot(x-pad['x'],y-pad['y']) > 1.8: continue
            if -9-LAND/2 < x < 9+LAND/2 and y+LAND/2 > 9.41: continue
            point=Point(x,y)
            # Drill clearance includes the owning capacitor pad: no via-in-pad.
            if min(point.distance(g) for _,g in pads) < DRILL/2+DRILL_GAP+1e-6: continue
            if min(point.distance(g) for _,g in pads) < LAND/2+GAP+1e-6: continue
            if any(point.distance(g)<LAND/2+GAP for _,g in keepouts): continue
            dx,dy=x-pad['x'],y-pad['y']; diagonal=min(abs(dx),abs(dy))
            elbow=(pad['x']+math.copysign(diagonal,dx),pad['y']+math.copysign(diagonal,dy))
            line=LineString([(pad['x'],pad['y']),elbow,(x,y)])
            other=[g for e,g in pads if e['layer']=='bottom' and e is not pad]
            clearance=min(line.distance(g)-WIDTH/2 for g in other)
            if clearance < GAP+1e-6: continue
            if any('bottom' in e['layers'] and line.distance(g)<WIDTH/2+GAP for e,g in keepouts): continue
            if proposal:
                prev=proposal[0]
                if point.distance(Point(prev['via']['x'],prev['via']['y'])) < max(LAND+GAP,DRILL+.254): continue
                previous_line=LineString(prev['stub']['points'])
                if line.distance(previous_line)<WIDTH+GAP: continue
                if previous_line.distance(point)<LAND/2+WIDTH/2+GAP: continue
                if line.distance(Point(prev['via']['x'],prev['via']['y']))<LAND/2+WIDTH/2+GAP: continue
            candidates.append((line.length,x,y,clearance,min(point.distance(g) for _,g in pads),list(line.coords)))
    assert candidates, 'No physically clear direct bypass found: '+str(pad['port_hints'])
    length,x,y,clearance,drill_distance,path_points=min(candidates)
    proposal.append(dict(capacitor='C_DDR_RAM_7',terminal=pad['port_hints'][0],net='DDR_1V5' if pad['port_hints']==['pin1'] else 'GND',pad=dict(x=pad['x'],y=pad['y'],pcb_smtpad_id=pad['pcb_smtpad_id'],pcb_port_id=pad['pcb_port_id']),via=dict(x=x,y=y,outerDiameter=LAND,holeDiameter=DRILL,layers=['top','inner1','inner2','bottom']),stub=dict(layer='bottom',width=WIDTH,lengthMm=length,points=path_points),minimumStubCopperGapMm=clearance,minimumDrillToPadCopperGapMm=drill_distance-DRILL/2,minimumViaToPadCopperGapMm=drill_distance-LAND/2))
report=dict(sourceSha256=hashlib.sha256(raw).hexdigest(),proposedRealBypass=proposal,all1161PhysicalPadsChecked=True,sourceHardwareModified=False,sourceReplayVerified=False,nativeDrcVerified=False,cadVerified=False,planeConnectivityQualified=False,fabricationReady=False)
output=ROOT/'.cloud-tools/ti-ddr-rule-audit/first-reference-bypass-octilinear-proposal.json'
assert not output.exists()
output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
