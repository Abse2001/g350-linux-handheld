import { spyOn } from "bun:test"
import { createHash } from "node:crypto"

type WriteEvent = (event: Record<string, unknown>) => void
type AdvanceMethod = "next" | "return" | "throw"
type ActivationMethod = AdvanceMethod | "dispose"
type IteratorLike = Generator<unknown, unknown, unknown>

export interface EventLimits {
  maxEvents?: number
  maxTotalBytes?: number
  maxEventBytes?: number
}

/** The writer sees new JSON-only data, never an input, Scene or route reference. */
export function boundedEventSink(write: WriteEvent, limits: EventLimits = {}) {
  const bound = (value: number | undefined, maximum: number) =>
    Number.isInteger(value) && value! >= 0 ? Math.min(value!, maximum) : maximum
  const maxEvents = bound(limits.maxEvents, 20_000)
  const maxTotalBytes = bound(limits.maxTotalBytes, 32 * 1024 * 1024)
  const maxEventBytes = bound(limits.maxEventBytes, 64 * 1024)
  const errors: string[] = []
  const counts = {
    attempted: 0,
    written: 0,
    dropped: 0,
    bytes: 0,
    writeErrors: 0,
    projectionErrors: 0,
  }
  const error = (value: unknown) => {
    counts.writeErrors++
    if (errors.length < 16) errors.push(errorText(value))
  }
  return {
    counts,
    errors,
    record(event: Record<string, unknown>) {
      counts.attempted++
      try {
        const json = JSON.stringify(event)
        const bytes = Buffer.byteLength(json) + 1
        if (
          counts.written >= maxEvents ||
          bytes > maxEventBytes ||
          counts.bytes + bytes > maxTotalBytes
        ) {
          counts.dropped++
          return
        }
        counts.written++
        counts.bytes += bytes
        try {
          write(JSON.parse(json))
        } catch (value) {
          error(value)
        }
      } catch {
        counts.projectionErrors++
        counts.dropped++
      }
    },
  }
}

function own(value: unknown, key: string | number): any {
  if (!value || (typeof value !== "object" && typeof value !== "function"))
    return undefined
  const descriptor = Object.getOwnPropertyDescriptor(value, key)
  return descriptor && "value" in descriptor ? descriptor.value : undefined
}

function errorText(value: unknown): string {
  try {
    if (typeof value === "string") return value.slice(0, 256)
    const message = own(value, "message")
    return typeof message === "string"
      ? message.slice(0, 256)
      : "Opaque observation error"
  } catch {
    return "Opaque observation error"
  }
}

function scalar(value: unknown): string | number | boolean | null {
  return typeof value === "string"
    ? value.slice(0, 256)
    : typeof value === "number" && Number.isFinite(value)
      ? value
      : typeof value === "boolean"
        ? value
        : null
}

function scalarArray(
  value: unknown,
  limit = 16,
): Array<string | number | boolean | null> | null {
  if (!Array.isArray(value) || value.length > limit) return null
  return Array.from({ length: value.length }, (_, index) =>
    scalar(own(value, index)),
  )
}

/** Bounded physical projection only: no Scene, options, callback or toJSON read. */
export function traceProjection(value: unknown) {
  if (!Array.isArray(value) || value.length > 4096)
    return {
      count: null,
      geometrySha256: null,
      projectionComplete: false,
      members: null,
    }
  const hash = createHash("sha256")
  const members: Array<{ name: unknown; layer: unknown; vertices: number }> = []
  let points = 0
  for (let index = 0; index < value.length; index++) {
    const trace = own(value, index),
      route = own(trace, "route")
    if (
      !Array.isArray(route) ||
      route.length > 4096 ||
      (points += route.length) > 131_072
    )
      return {
        count: value.length,
        geometrySha256: null,
        projectionComplete: false,
        members: null,
      }
    const name = scalar(own(trace, "connection_name"))
    hash.update(
      JSON.stringify([scalar(own(trace, "pcb_trace_id")), name, route.length]),
    )
    for (let pointIndex = 0; pointIndex < route.length; pointIndex++) {
      const point = own(route, pointIndex)
      hash.update(
        JSON.stringify([
          scalar(own(point, "route_type")),
          scalar(own(point, "x")),
          scalar(own(point, "y")),
          scalar(own(point, "layer")),
          scalar(own(point, "width")),
          scalar(own(point, "from_layer")),
          scalar(own(point, "to_layer")),
          scalar(own(point, "via_diameter")),
          scalar(own(point, "via_hole_diameter")),
          scalar(own(point, "hole_diameter")),
          scalarArray(own(point, "layers")),
        ]),
      )
    }
    if (members.length < 16)
      members.push({
        name,
        layer: scalar(own(own(route, 0), "layer")),
        vertices: route.length,
      })
  }
  return {
    count: value.length,
    geometrySha256: hash.digest("hex"),
    projectionComplete: true,
    members,
    memberProjectionTruncated: value.length > 16,
  }
}

/** routeCoupledPair's third argument is Copper[], not output Trace[]. */
export function copperProjection(value: unknown) {
  if (!Array.isArray(value) || value.length > 131_072)
    return { count: null, geometrySha256: null, projectionComplete: false }
  const hash = createHash("sha256")
  for (let index = 0; index < value.length; index++) {
    const copper = own(value, index),
      a = own(copper, "a"),
      b = own(copper, "b"),
      rect = own(copper, "rect")
    if (!a || !b)
      return {
        count: value.length,
        geometrySha256: null,
        projectionComplete: false,
      }
    hash.update(
      JSON.stringify([
        scalar(own(a, "x")),
        scalar(own(a, "y")),
        scalar(own(b, "x")),
        scalar(own(b, "y")),
        scalar(own(copper, "radius")),
        scalar(own(copper, "layer")),
        scalarArray(own(copper, "owners"), 256),
        rect
          ? [
              scalar(own(rect, "minX")),
              scalar(own(rect, "maxX")),
              scalar(own(rect, "minY")),
              scalar(own(rect, "maxY")),
            ]
          : null,
      ]),
    )
  }
  return {
    count: value.length,
    geometrySha256: hash.digest("hex"),
    projectionComplete: true,
  }
}

interface Life {
  id: number
  started: boolean
  yields: number
  advances: number
  lastDone: boolean | null
  ended: boolean
  canceled: boolean
  throwCalls: number
}
interface PairLife extends Life {
  planId: number | null
  tags: Record<string, unknown>
}
interface BoundLife extends Life {
  job: PairLife
  limit: unknown
  childReturnedNonterminalDuringNext: boolean
}
interface PlanLife extends Life {
  tags: Record<string, unknown>
  offers: number
}

const life = (id: number): Life => ({
  id,
  started: false,
  yields: 0,
  advances: 0,
  lastDone: null,
  ended: false,
  canceled: false,
  throwCalls: 0,
})

export interface PairObserverModules {
  pairRouter: { routeCoupledPair: (...args: any[]) => IteratorLike }
  boundedRouting: { runBoundedRouting: (...args: any[]) => IteratorLike }
  pairPlanner: { planSharedPairCorridors: (...args: any[]) => IteratorLike }
}

/** Optional export observation; caller must install before importing its driver.
 * No callback, predicate, generator advance, cap or routing input is added.
 * Wrapped iterators forward exact protocol calls and original result objects.
 */
export function installPairObserver(
  modules: PairObserverModules,
  write: WriteEvent,
  limits: EventLimits = {},
) {
  const sink = boundedEventSink(write, limits)
  const counts = {
    jobs: 0,
    bounds: 0,
    plans: 0,
    offers: 0,
    caps: 0,
    observationErrors: 0,
  }
  const spies: any[] = []
  const jobs = new WeakMap<object, PairLife>()
  let activePlan: PlanLife | undefined
  let activeBound: { life: BoundLife; method: AdvanceMethod } | undefined
  let enabled = true
  const clearRecordedCalls = () => {
    for (const spy of spies) spy.mockClear()
  }
  const safe = (action: () => void) => {
    try {
      action()
    } catch {
      counts.observationErrors++
    }
  }
  const record = (event: Record<string, unknown>) => {
    if (enabled) sink.record(event)
  }
  const histories = () =>
    spies.map((spy) => ({
      calls: spy.mock.calls.length,
      results: spy.mock.results.length,
      contexts: spy.mock.contexts.length,
      instances: spy.mock.instances.length,
    }))

  function wrap(
    work: IteratorLike,
    state: Life,
    before: (method: ActivationMethod) => void,
    after: (method: AdvanceMethod, result: IteratorResult<unknown>) => void,
    onError: (method: AdvanceMethod, error: unknown) => void,
    context: <T>(method: AdvanceMethod, action: () => T) => T,
    iteratorKind: "job" | "bound" | "plan",
  ) {
    const advance = (method: AdvanceMethod, args: any[]) => {
      clearRecordedCalls()
      state.advances++
      if (method === "return") state.canceled = true
      if (method === "throw") state.throwCalls++
      safe(() => before(method))
      try {
        const result = context(method, () =>
          Reflect.apply(work[method], work, args),
        )
        state.lastDone = result.done === true
        if (!result.done) state.yields++
        safe(() => after(method, result))
        return result
      } catch (error) {
        safe(() => onError(method, error))
        throw error
      } finally {
        clearRecordedCalls()
      }
    }
    const iterator: IteratorLike = {
      next(...args: any[]) {
        return advance("next", args)
      },
      return(...args: any[]) {
        return advance("return", args)
      },
      throw(...args: any[]) {
        return advance("throw", args)
      },
      [Symbol.iterator]() {
        return this
      },
      [Symbol.toStringTag]: "Generator",
    } as unknown as IteratorLike
    // Bun generators also expose synchronous disposal. Its void result
    // cannot prove cleanup completion; forward the original method exactly.
    let disposePresent = false
    safe(() => {
      let prototype: object | null = work
      for (let depth = 0; prototype && depth < 8; depth++) {
        const descriptor = Object.getOwnPropertyDescriptor(
          prototype,
          Symbol.dispose,
        )
        if (descriptor) {
          disposePresent =
            "value" in descriptor && typeof descriptor.value === "function"
          break
        }
        prototype = Object.getPrototypeOf(prototype)
      }
    })
    if (disposePresent)
      Object.defineProperty(iterator, Symbol.dispose, {
        value: function (...args: any[]) {
          clearRecordedCalls()
          state.canceled = true
          safe(() => before("dispose"))
          try {
            const result = context("return", () =>
              Reflect.apply(work[Symbol.dispose], work, args),
            )
            record({
              kind: "paired-iterator-dispose",
              iteratorKind,
              id: state.id,
              completionObserved: false,
            })
            return result
          } catch (error) {
            record({
              kind: "paired-iterator-dispose-error",
              iteratorKind,
              id: state.id,
              error: errorText(error),
              completionObserved: false,
            })
            throw error
          } finally {
            clearRecordedCalls()
          }
        },
      })
    return iterator
  }

  function install(
    target: any,
    key: string,
    intercept: (original: any, receiver: any, args: any[]) => any,
  ) {
    const original = target[key]
    const spy = spyOn(target, key).mockImplementation(function (
      this: any,
      ...args: any[]
    ) {
      clearRecordedCalls()
      try {
        return intercept(original, this, args)
      } finally {
        clearRecordedCalls()
      }
    })
    spies.push(spy)
  }
  try {
    install(
      modules.pairRouter,
      "routeCoupledPair",
      (original, receiver, args) => {
        // Preserve factory-time exceptions/laziness before observing arguments.
        const work = Reflect.apply(original, receiver, args) as IteratorLike
        const job: PairLife = {
          ...life(++counts.jobs),
          planId: activePlan?.id ?? null,
          tags: {},
        }
        let projectArgs: any[] | undefined = args
        const project = () => {
          if (!projectArgs) return
          const args = projectArgs
          projectArgs = undefined
          safe(() => {
            const pair = args[1],
              options = args[3],
              names = scalarArray(own(pair, "connectionNames"))
            const connections = own(args[0], "connections")
            const requestedLayers = new Set<string | number | boolean | null>()
            let layerProjectionTruncated = false
            if (
              Array.isArray(connections) &&
              connections.length <= 4096 &&
              names
            )
              for (const name of names) {
                // Match the router's first connection by name; duplicate
                // malformed records cannot grow retained metadata.
                for (let i = 0; i < connections.length; i++) {
                  const connection = own(connections, i)
                  if (name !== own(connection, "name")) continue
                  const points = own(connection, "pointsToConnect")
                  if (Array.isArray(points) && points.length <= 16)
                    for (let j = 0; j < points.length; j++) {
                      const layer = scalar(own(own(points, j), "layer"))
                      if (
                        requestedLayers.size < 16 ||
                        requestedLayers.has(layer)
                      )
                        requestedLayers.add(layer)
                      else layerProjectionTruncated = true
                    }
                  break
                }
              }
            job.tags = {
              pairNames: names,
              requestedLayers: [...requestedLayers],
              layerProjectionTruncated,
              variant: scalar(own(options, "variant")),
              handoffOffsets: scalarArray(own(options, "handoffOffsets")),
              allowProvisionalPairTuning: scalar(
                own(options, "allowProvisionalPairTuning"),
              ),
              preferPackageOnlyTuning: scalar(
                own(options, "preferPackageOnlyTuning"),
              ),
              fixedCopper: copperProjection(args[2]),
              softCopperCount: Array.isArray(own(options, "copper"))
                ? own(options, "copper").length
                : null,
              penalty: scalar(own(options, "penalty")),
              historyPresent: own(options, "history") !== undefined,
            }
          })
        }
        const wrapped = wrap(
          work,
          job,
          (method) => {
            if (!job.started) {
              job.started = true
              if (method === "next") project()
              else projectArgs = undefined
              record({
                kind: "paired-job-start",
                jobId: job.id,
                planId: job.planId,
                activationMethod: method,
                bodyStartedByNext: method === "next",
                ...job.tags,
              })
            }
            if (
              method === "return" &&
              activeBound?.life.job === job &&
              activeBound.method === "next" &&
              job.lastDone === false
            )
              activeBound.life.childReturnedNonterminalDuringNext = true
          },
          (method, result) => {
            if (result.done && !job.ended) {
              job.ended = true
              record({
                kind: "paired-job-end",
                jobId: job.id,
                planId: job.planId,
                method,
                yields: job.yields,
                advances: job.advances,
                canceled: job.canceled,
                throwCalls: job.throwCalls,
                returnedNull: result.value === null,
                output: traceProjection(result.value),
                boundedFinalizerDuringNext:
                  activeBound?.life.job === job &&
                  activeBound.method === "next" &&
                  method === "return",
              })
            }
          },
          (method, error) => {
            if (!job.ended) {
              job.ended = true
              record({
                kind: "paired-job-error",
                jobId: job.id,
                planId: job.planId,
                method,
                yields: job.yields,
                advances: job.advances,
                canceled: job.canceled,
                error: errorText(error),
              })
            }
          },
          (_method, action) => action(),
          "job",
        )
        jobs.set(wrapped, job)
        return wrapped
      },
    )
    install(
      modules.boundedRouting,
      "runBoundedRouting",
      (original, receiver, args) => {
        const work = Reflect.apply(original, receiver, args) as IteratorLike
        const job = jobs.get(args[0])
        if (!job) return work // Keep every unrelated bounded search untouched.
        const bound: BoundLife = {
          ...life(++counts.bounds),
          job,
          limit: scalar(args[1]),
          childReturnedNonterminalDuringNext: false,
        }
        return wrap(
          work,
          bound,
          (method) => {
            if (!bound.started) {
              bound.started = true
              record({
                kind: "paired-bound-start",
                boundId: bound.id,
                jobId: job.id,
                planId: job.planId,
                limit: bound.limit,
                activationMethod: method,
              })
            }
          },
          (method, result) => {
            if (result.done && !bound.ended) {
              bound.ended = true
              const capped =
                method === "next" &&
                !bound.canceled &&
                bound.throwCalls === 0 &&
                result.value === null &&
                bound.childReturnedNonterminalDuringNext &&
                typeof bound.limit === "number" &&
                bound.yields >= Math.max(0, bound.limit)
              if (capped) counts.caps++
              record({
                kind: "paired-bound-end",
                boundId: bound.id,
                jobId: job.id,
                planId: job.planId,
                limit: bound.limit,
                method,
                yields: bound.yields,
                advances: bound.advances,
                childYields: job.yields,
                childAdvances: job.advances,
                childEnded: job.ended,
                canceled: bound.canceled,
                throwCalls: bound.throwCalls,
                returnedNull: result.value === null,
                capObserved: capped,
                externalCancellation: bound.canceled || bound.throwCalls > 0,
                childReturnedNonterminalDuringNext:
                  bound.childReturnedNonterminalDuringNext,
              })
            }
          },
          (method, error) => {
            if (!bound.ended) {
              bound.ended = true
              record({
                kind: "paired-bound-error",
                boundId: bound.id,
                jobId: job.id,
                planId: job.planId,
                limit: bound.limit,
                method,
                yields: bound.yields,
                canceled: bound.canceled,
                error: errorText(error),
              })
            }
          },
          (method, action) => {
            const previous = activeBound
            activeBound = { life: bound, method }
            try {
              return action()
            } finally {
              activeBound = previous
            }
          },
          "bound",
        )
      },
    )
    install(
      modules.pairPlanner,
      "planSharedPairCorridors",
      (original, receiver, args) => {
        const work = Reflect.apply(original, receiver, args) as IteratorLike
        const plan: PlanLife = { ...life(++counts.plans), tags: {}, offers: 0 }
        let projectArgs: any[] | undefined = args
        return wrap(
          work,
          plan,
          (method) => {
            if (!plan.started) {
              plan.started = true
              if (method === "next" && projectArgs) {
                const args = projectArgs
                safe(() => {
                  plan.tags = {
                    freshDogbones: scalar(args[2]),
                    maxTopologyVariants: scalar(
                      own(args[3], "maxTopologyVariants"),
                    ),
                    preferPackageOnlyTuning: scalar(
                      own(args[3], "preferPackageOnlyTuning"),
                    ),
                  }
                })
              }
              projectArgs = undefined
              record({
                kind: "paired-plan-start",
                planId: plan.id,
                activationMethod: method,
                bodyStartedByNext: method === "next",
                ...plan.tags,
              })
            }
          },
          (method, result) => {
            if (!result.done && Array.isArray(result.value)) {
              plan.offers++
              counts.offers++
              record({
                kind: "paired-plan-offer",
                planId: plan.id,
                offerOrdinal: plan.offers,
                output: traceProjection(result.value),
                acceptance: false,
                domainChoiceAcceptanceObserved: false,
                provisionalStatusObserved: false,
              })
            }
            if (result.done && !plan.ended) {
              plan.ended = true
              record({
                kind: "paired-plan-end",
                planId: plan.id,
                method,
                yields: plan.yields,
                advances: plan.advances,
                offers: plan.offers,
                canceled: plan.canceled,
                throwCalls: plan.throwCalls,
              })
            }
          },
          (method, error) => {
            if (!plan.ended) {
              plan.ended = true
              record({
                kind: "paired-plan-error",
                planId: plan.id,
                method,
                yields: plan.yields,
                offers: plan.offers,
                canceled: plan.canceled,
                error: errorText(error),
              })
            }
          },
          (_method, action) => {
            const previous = activePlan
            activePlan = plan
            try {
              return action()
            } finally {
              activePlan = previous
            }
          },
          "plan",
        )
      },
    )
  } catch (error) {
    for (const spy of spies.reverse()) spy.mockRestore()
    throw error
  }
  return {
    counts,
    sink,
    clearRecordedCalls,
    getRecordedHistorySizes: histories,
    getActiveContexts: () => ({
      planId: activePlan?.id ?? null,
      boundId: activeBound?.life.id ?? null,
    }),
    restore() {
      enabled = false
      clearRecordedCalls()
      for (const spy of [...spies].reverse()) spy.mockRestore()
    },
  }
}
