 def closed63():
  prior=closed62();assert prior['actualClosedScopeCount']==62
  assert proposal['actual63Sealed']is True
  for key in('actual63CollectionPin','actual63PostauditPin','actual63ChildLogPin','actual63GuardManifestPin'):binding(proposal[key])
  r=read(proposal['actual63CollectionPin']['path']);p=read(proposal['actual63PostauditPin']['path']);e=p['execution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is r['passed']is p['passed']is True and r['toolExitCode']==r['toolWrapperExitCode']==0 and r['toolSessionId']==proposal['actual63ToolSessionId']
  assert r['postauditPath']==proposal['actual63PostauditPin']['path']and r['postauditSha256']==proposal['actual63PostauditPin']['sha256']and r['execution']==e
  assert r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior
  for d in(r,p):
   assert d['scope']=='ROOT_C31_FULL647_WITH62_AUTHENTIC_PRIOR_CLOSURES'and d['phase']=='full647'and d['sourceManifestSha256']==d['candidateSourceManifestSha256']==proposal['candidateSourcePin']['sha256']and d['rootGuardProposalManifestSha256']==proposal['actual63GuardManifestPin']['sha256']
   assert d['full647ProjectManifestSha256']==proposal['full647PreparedProjectManifestPin']['sha256']and d['observedCounts']=={'pass':647,'fail':0}
   for k in('sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','stageNaturallyCompleted','full647Requalified','ownedGroupEmptyActuallyObserved','passedMeansFull647RegressionOnly'):assert d[k]is True
   assert all(d[k]is None for k in('runFailure','postverificationFailure','resultInspectionFailure'))
   assert all(d[k]is False for k in('originalAll11AcceptanceClaimed','fixReleaseQualificationPassed','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'))and all(d[k]==0 for k in('CoreCalls','nativeCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'))
  assert r['testSuiteCompleted']is True and r['observedCounts']=={'pass':647,'fail':0}and r['observedTestFileCount']==190 and p['observedTestFileCount']==190
  h.finite(e,0);h.held_inventory_post(p);assert e['policy']==full_contract['policy']and e['command']==full_contract['command']and e['pid']==e['pgid']==proposal['actual63Pgid']and e['currentGuardPid']==proposal['actual63GuardPid']
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]and c.guard.process_scope.owned(e['pgid'])==[]and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['childLogPath']==p['childLogPath']==proposal['actual63ChildLogPin']['path']and r['childLogSha256']==p['childLogSha256']==proposal['actual63ChildLogPin']['sha256']
  log=Path(p['childLogPath']).read_text();assert counts(log)=={'pass':647,'fail':0}and re.findall(r'^Ran (\d+) tests across (\d+) files\. \[[^\n]+\]$',log,re.M)==[('647','190')]
  prior['actual63Full647RegressionCollectionPin']={k:proposal['actual63CollectionPin'][k]for k in('path','sha256')};prior['actual63Full647Natural647Pass190FilesOnly']=True;prior['actualClosedScopeCount']=63
  return prior
