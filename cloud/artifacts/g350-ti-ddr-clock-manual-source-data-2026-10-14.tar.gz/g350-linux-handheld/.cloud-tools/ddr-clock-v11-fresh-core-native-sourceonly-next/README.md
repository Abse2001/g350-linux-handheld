This packet is source-only preparation for a future actual fresh Core result.
It has not imported Native checks, Original continuous APIs, Core or CLI.
Root may invoke it only after the exact manual Source predecessor has separately
passed capture, strict types and Core, each with actual collected Root exit0.
The failed82627 output is preserved; it cannot substitute for a successful
fresh225-barrel/263-trace Core output.

The guard binds actual saved raw/control hashes from that Core result, all
source files, the unchanged full Ce3 board SDK and47633 solver tree/archive.
It uses the original7bd process helper through the exact Source guard. Prior
42982 candidate plus all required and later Root owned scopes must actually be
collected, empty and OOM-free. Root binds a finite peer GO and full read with a
fresh nonce. One exclusive90s/1GiB worker, shared30GiB plus1GiB reserve. That
Native budget is a policy proposal, not a claimed new measurement.

The first stage uses only stdlib to derive physical/Source mappings from the
actual new raw Core, independently cross-check the real controls, and construct
unbranched numeric CPU-to-RAM graphs from all3 actual wire paths plus2 real
existing barrels per clock. Fourteen finite adversarial modifications of that
actual future output must reject. It creates no fake fresh fixture or copy of
failed old output. The unchanged bytes remain hash-bound before and after.

The Native owner factory invokes the untouched original authentic package
proof on olded33 plus goldenHS64 first. It then recomputes old→actual new
reference barrel/path/port ownership using actual geometry, original numeric
Source ports, aliases and named rail identities. All129 reference barrels,
165 reference paths,96 signal barrels/Top stubs and2 actual clock carriers must
account for exactly225 barrels and263 paths. Source bus numbering can differ
because the public manual Bus representation emits in another phase; every
original name, ordered member ID and other constraint field remains exact.
No generated identity is rewritten.

The one registered RAM25/HS8 exception authenticates the original numeric RAM25
GND branch, C_DDR_RAM_8 pin2, old stripSource987 and old pad geometry. It finds
the actual new IDs and repeats the finite annulus/strip chord, interior-chord,
pad overlap and drill clearance mathematics against real new rows, accompanied
by actual known-rail graph checks. Other same-net copper/pads are not exempt.
Registry access requires the private proof for the same unmodified object.
The manufacturing helper is the exact original strict body, with only its
registry import redirected to this proved actual factory.

The Native runner calls unchanged17 physical checks plus registered strict
manufacturing18 on actual raw Core, then the unchanged full-circuit Native bus
length/routing functions. Each original clockSource33/34 must directly own all3
paths including both Top stubs. Report actual planar lengths, native findings,
physical2 full-span barrels and2 active Top↔Inner1 transitions separately.
There are no fake route-via markers; the legacy Native marker-height addition
is zero. That is not an electrical delay calculation.

A subsequent helper feeds actual fresh clock carrier coordinates, with real
new PCB IDs, into the original immutable13 VectorScene/self/corner/shared/
exterior/coupling/pair/window APIs. The complete26-CA physical input remains
unchanged; only the explicit clock-only pair/window view is used, while DQS
and global matching remain unqualified. The complete49 authoritative input
ed97 retains all3 original differential declarations (.127mm/.12mm), all
other buses and TI assertions. Private source bindings do not assume full
solver checkout C115 still exists; the reviewed D7 branch is independent.

No circuit-JSON geometry edits, old-ID copying, source-net fabrication, CAD,
CLI, Core rendering or hardware routing occurs in this qualification packet.
Raw negative reports remain saved before assertions and in the failed output
receipt. Qualifying two clocks/local fanouts does not qualify all49 DDR paths,
full-board references/electrical timing/impedance/PDN or fabrication.
fabricationReady=false.

Root command, only after actual required success/closure and fresh authority:

    source cloud/env.sh
    python -B .cloud-tools/ddr-clock-v11-fresh-core-native-sourceonly-next/guard.py \
      --run --root-receipt /ABS/ACTUAL_FUTURE_ROOT_NATIVE_AUTHORITY.json \
      --root-receipt-sha256 ACTUAL_SHA256

The template is not an authorization. AST parsing/file hashing during authoring
is not guard/preflight, Native, Original API or board qualification execution.
