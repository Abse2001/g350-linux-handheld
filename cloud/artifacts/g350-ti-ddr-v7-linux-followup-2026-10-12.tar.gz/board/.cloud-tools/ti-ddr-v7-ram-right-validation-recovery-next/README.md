Validation-only recovery; no repeated source export or routing.

The original frozen48579 source-only controller built V7 with actual CLIexit0, then failed its inverse-validation view before native/Core checks (worker1, outer2). Its raw failure and actual exported source2e81 remain unchanged. Direct actualV7 geometry/ID/field delta checks passed. Inverse translated numeric values and renderer-recomputed widths differed from the originalV6 by floating roundoff, e.g8.88e-16mm. LegacyV6 classified changes using raw dictionary inequality and rejected these already numerically equivalent non-CPU13 rows.

This separate recovery changes only the non-emitted inverse validation view. For each declared moved geometry row it first proves the actual fresh forward delta and every field/ID against originalV6 using the established unchanged1e-7mm numeric tolerance. It independently proves inverse equivalence, then copies that proven originalV6 row into the legacy validation view. It never canonicalizes the actual exported circuit, unknown fields, fixed-part geometry, actual Core input, native checker input or solver input. Existing standalone reference inverses and all actual physical checks retain their original rules. The normalized view is not written or used by native/Core/router.

Meaningful fullchain controls preserve the original validator failure on actual exportedJSON, accept the corrected non-emitted view, and reject fixed-part1µm movement, extraRAM1µm translation, changed width above tolerance, source-port owner changes, changed reference drill/span/net, unexpected fields/duplicate records and moved layers. These controls are pure JSON validation, not a Circuit or physical-native run.

After independent peer/root authorization, one60s/1GiB owned/24GiB shared/.05s/5s guarded validation invokes all17 original native checks and the same pinned Core converter on byte-identical source2e81. It performs zero CLIbuilds. Only after exact49 CPU/RAM pin/endpoint and132 movedobstacle/724 unchangedobstacle checks derive BYTE013.2/BYTE115.6/CMD14.8 may it write source-derived BYTE0max13.2, BYTE1stricter14.4 and CMD21.15–23.69 inputs, preserving .635/.127 and every geometry/via/clearance rule. Both explicit and unrestricted outer-layer policies remain derived data without routing.

Source120/runtime pins/fullboardce3d/nativepatch1a8af remain checked before/after. The original failed controller remains resultTrustEligiblefalse. This new validation result has separate producer exits/provenance and cannot erase that historical failure. No V6 routing success, source adoption, new initialization, Grid/carrier search, CAD, full49 acceptance or fabrication readiness is claimed.

```bash
source /workspace/g350-linux-handheld/cloud/env.sh
bash /workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v7-ram-right-validation-recovery-next/launch-bootstrap.sh --preflight
```

A separate hash-pinned receipt authorizes only one validation-only invocation of that bootstrap. No receipt or run directory exists in PREP.
