import {Children, cloneElement, isValidElement, type ReactElement, type ReactNode} from "react"
import OriginalV9 from "./am3352-g350-ti-top-bottom-ddr-v9-ram-y0_2-layout.circuit"
import {v10Groups, v10Pairs, groupPolicyByName, pairPolicyByName} from "../lib/am3352/placement/G350V10DdrLayerPolicy"

type Props = Record<string, unknown> & {name?: string; children?: ReactNode}
export type AuthoredPolicyProof = {groups: Array<Record<string, unknown>>; pairs: Array<Record<string, unknown>>;
  policyAppliedAfterAllV9Wrappers: true; coreCircuitJsonOmitsLayerAndAbsoluteLengthFields: true}
const equal = (a: unknown, b: unknown, label: string) => {
  if (JSON.stringify(a) !== JSON.stringify(b)) throw Error("V10 authored constraint mismatch: " + label)
}

/** Only final DDR class layer lists change. Existing V9 placement/reference
 * planes and every source identity stay untouched. The old clearCorridor
 * broad-layer override has already executed before this final overlay. */
export function buildV10Source(): {element: ReactNode; authoredPolicyProof: AuthoredPolicyProof} {
  const groups = new Map<string, Record<string, unknown>>()
  const pairs = new Map<string, Record<string, unknown>>()
  function apply(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const p = {...node.props}
    const group = groupPolicyByName.get(p.name ?? "")
    const pair = pairPolicyByName.get(p.name ?? "")
    if (group) {
      if (node.type !== "bus" || groups.has(group.nativeBus.busId)) throw Error("Exactly one literal DDR class bus required")
      const spec = group.nativeBus
      equal(p.connections, group.logicalConnections, spec.busId + " original logical members")
      equal(p.pcbTraceWidth, spec.traceWidth, spec.busId + " original width")
      equal(p.maxLengthSkew, spec.maxLengthSkew, spec.busId + " original within-class skew")
      // These unchanged b04 absolute windows were already explicit in the
      // reviewed input; declare them here and bridge Core's omitted fields.
      for (const key of ["minLength", "maxLength"] as const) {
        if (p[key] !== undefined) equal(p[key], spec[key], spec.busId + " original " + key)
        if (spec[key] !== undefined) p[key] = spec[key]
      }
      p.pcbAllowedLayers = [...spec.allowedLayers]
      p.preferredLayers = [...spec.preferredLayers]
      const snapshot: Record<string, unknown> = {busId: spec.busId, connections: p.connections,
        pcbTraceWidth: p.pcbTraceWidth, pcbAllowedLayers: p.pcbAllowedLayers, preferredLayers: p.preferredLayers}
      for (const key of ["maxLengthSkew", "minLength", "maxLength"] as const)
        if (p[key] !== undefined) snapshot[key] = p[key]
      groups.set(spec.busId, snapshot)
    }
    if (pair) {
      if (node.type !== "differentialpair" || pairs.has(pair.name)) throw Error("Exactly one original differentialpair required")
      equal([p.positiveConnection, p.negativeConnection], pair.logicalConnections, pair.name + " original partners")
      equal(p.maxLengthSkew, pair.nativePair.lengthTolerance, pair.name + " original skew")
      equal(p.pcbTraceGap, pair.nativePair.traceGap, pair.name + " original gap")
      pairs.set(pair.name, {name: pair.name, ownerBusId: pair.ownerBusId,
        positiveConnection: p.positiveConnection, negativeConnection: p.negativeConnection,
        maxLengthSkew: p.maxLengthSkew, pcbTraceGap: p.pcbTraceGap})
    }
    if (node.type === "board") {
      equal(p.layers, 4, "physical layer count")
      equal(p.routeRemaining, false, "routing-disabled source")
    }
    return cloneElement(node as ReactElement<Props>, p, ...Children.toArray(node.props.children).map(apply))
  }
  const element = apply(OriginalV9())
  if (groups.size !== 4 || pairs.size !== 3) throw Error("V10 must observe all4 final class buses and all3 original pairs")
  return {element, authoredPolicyProof: {groups: v10Groups.map(g => groups.get(g.nativeBus.busId)!),
    pairs: v10Pairs.map(p => pairs.get(p.name)!), policyAppliedAfterAllV9Wrappers: true,
    coreCircuitJsonOmitsLayerAndAbsoluteLengthFields: true}}
}
export default () => buildV10Source().element
