"""Import-safe stdlib material for complete genuine cap19/owned32 corner hypothesis."""
import pathlib,json,importlib.util,hashlib,sys
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();EMPTY=ROOT/'EMPTY49_CAP19_OWNED32_OWNED4_COORDINATED_CORNERS_CONTEXT12.json';assert sha(EMPTY)=='dcf6e041f60a4f9d0731587145165d0b5f66f84485dec49e0fa3537464a7e656';empty=json.loads(EMPTY.read_text());assert empty['carrierCount']==0 and empty['records']==[]
for key in('full49NumericInputPin','full49CarrierInputPin','fullNativeContextPin','fullCoreGeometryHypothesisPin','changedCoreRowsPin','changedInputRowsPin','actualOwnerClosurePin','exactPhysicalProbePin','packageBoxesPin'):
 p=empty[key];assert sha(p['path'])==p['sha256']
INPUT=pathlib.Path(empty['full49NumericInputPin']['path']);CARRIER=pathlib.Path(empty['full49CarrierInputPin']['path']);CONTEXT=pathlib.Path(empty['fullNativeContextPin']['path']);full=json.loads(INPUT.read_text());carrier=json.loads(CARRIER.read_text());ctx=json.loads(CONTEXT.read_text());assert len(full['connections'])==len(carrier['connections'])==49 and len(ctx['referenceVias'])==129 and len(ctx['signalDogbones'])==96 and len(ctx['allOriginalCopperLands'])==1165
SP=ROOT.parent/'ddr-byte0-ram-yplus1_2-reference-aware-sourceonly-next/material-context-sealed-empty49.py';spec=importlib.util.spec_from_file_location('safe_defs',SP);defs=importlib.util.module_from_spec(spec);spec.loader.exec_module(defs)
h,m,ns,P,dst,seg,angles,strictxy,packageBoxes=defs.h,defs.m,defs.ns,defs.P,defs.dst,defs.seg,defs.angles,defs.strictxy,defs.packageBoxes

def endpoints(name):
 dogs=[t for t in full['traces']if t.get('source_trace_id')==name];assert len(dogs)==2
 vs=[next(p for p in t['route']if p['route_type']=='via')for t in dogs];fixed=sum(m.g.length([(p['x'],p['y'])for p in t['route']if p.get('layer')=='top'])for t in dogs)
 return [(v['x'],v['y'])for v in vs],fixed,dogs
assert endpoints('source_trace_32')[0]==[(3.2,16),(2.0000000000000004,5.3999999999999995)]
