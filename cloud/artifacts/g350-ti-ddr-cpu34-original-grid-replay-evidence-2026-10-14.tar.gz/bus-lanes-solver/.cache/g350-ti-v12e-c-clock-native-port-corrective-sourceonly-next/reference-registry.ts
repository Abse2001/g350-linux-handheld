import assert from "node:assert/strict"
import type { Connection, SimpleRouteJson, Trace } from "../g350-ti-v12e-c-pitch-phase-retry-runtime-proposal-next/source/lib/types"

export type CoreRecord = Record<string, any>
export interface NativeReferenceEntry {
  connectionName: string; sourceTraceId: string; sourceNetId: string
  pcbTraceId: string; viaId: string; viaPortId: string; capPortId: string
  sourceTrace: CoreRecord; via: CoreRecord; viaPort: CoreRecord; capPort: CoreRecord
  viaSourcePort: CoreRecord; viaComponent: CoreRecord; sourceVia: CoreRecord
  capSourcePort: CoreRecord; capComponent: CoreRecord; capPad: CoreRecord; fixedTrace: Trace
}

/** Data-only source ownership proof. It neither routes nor changes pad/via policy. */
export function buildNativeReferenceRegistry(core: CoreRecord[], input: SimpleRouteJson) {
  const one = (type: string, key: string, id: string) => {
    const rows = core.filter(row => row.type === type && row[key] === id)
    assert.equal(rows.length, 1, `Expected unique ${type} ${id}`)
    return rows[0]!
  }
  const pcbPort = (sourceId: string) => {
    const rows = core.filter(row => row.type === "pcb_port" && row.source_port_id === sourceId)
    assert.equal(rows.length, 1, `Expected unique native pcb_port for ${sourceId}`)
    const port = rows[0]!
    assert.equal(one("pcb_port", "pcb_port_id", port.pcb_port_id), port)
    assert.ok(Number.isFinite(port.x) && Number.isFinite(port.y))
    assert.ok(Array.isArray(port.layers) && port.layers.length === 1 && typeof port.layers[0] === "string")
    return port
  }
  assert.equal(input.connections.length, 49)
  assert.equal(input.traces?.length, 2)
  assert.equal(input.layerCount, 4)
  const boards = core.filter(row => row.type === "pcb_board")
  assert.equal(boards.length, 1)
  assert.equal(boards[0].is_via_in_pad_allowed, false)
  assert.notEqual((input as SimpleRouteJson & { allowViaInPad?: boolean }).allowViaInPad, true)
  const nativeDdrPortAudit = input.connections.map(connection => {
    const source = one("source_trace", "source_trace_id", connection.source_trace_id ?? connection.name)
    assert.equal(source.connected_source_port_ids.length, connection.pointsToConnect.length)
    const ports = source.connected_source_port_ids.map((id: string) => pcbPort(id))
    const points = connection.pointsToConnect.map(point => {
      const matches = ports.filter((port: CoreRecord) => port.pcb_port_id === point.pcb_port_id)
      assert.equal(matches.length, 1, `DDR terminal must name its original native port: ${connection.name}`)
      const port = matches[0]!
      assert.equal(point.x, port.x); assert.equal(point.y, port.y)
      assert.equal(point.layer, port.layers[0]); assert.equal(point.pointId, port.pcb_port_id)
      const pads = core.filter(row => row.type === "pcb_smtpad" && row.pcb_port_id === port.pcb_port_id)
      assert.equal(pads.length, 1, `DDR terminal must own one native SMT pad: ${port.pcb_port_id}`)
      return { point: structuredClone(point), port: structuredClone(port), pad: structuredClone(pads[0]) }
    })
    return { connectionName: connection.name, sourceTrace: structuredClone(source), points }
  })
  const specs = [
    { trace: "source_trace_932", via: "pcb_via_0", port: "pcb_port_1162", cap: "pcb_port_727", net: "source_net_5" },
    { trace: "source_trace_933", via: "pcb_via_1", port: "pcb_port_1164", cap: "pcb_port_728", net: "source_net_0" },
  ]
  const connections: Connection[] = [], entries: NativeReferenceEntry[] = []
  for (const spec of specs) {
    assert.ok(!input.connections.some(connection => connection.name === spec.trace))
    const sourceTrace = one("source_trace", "source_trace_id", spec.trace)
    assert.deepEqual(sourceTrace.connected_source_net_ids, [spec.net])
    assert.equal(sourceTrace.connected_source_port_ids.length, 2)
    const ports = sourceTrace.connected_source_port_ids.map((id: string) => pcbPort(id))
    assert.deepEqual(ports.map((port: CoreRecord) => port.pcb_port_id), [spec.port, spec.cap])
    const [viaPort, capPort] = ports as [CoreRecord, CoreRecord]
    const owners = core.filter(row => row.type === "pcb_via" && row.pcb_port_ids?.includes(viaPort.pcb_port_id))
    assert.equal(owners.length, 1, `Via port ${spec.port} requires one physical owner`)
    const via = owners[0]!
    assert.equal(via.pcb_via_id, spec.via); assert.equal(via.source_net_id, spec.net)
    assert.equal(via.x, viaPort.x); assert.equal(via.y, viaPort.y)
    assert.deepEqual(via.layers, ["top", "inner1", "inner2", "bottom"])
    assert.equal(via.outer_diameter, .4572); assert.equal(via.hole_diameter, .254)
    const viaSourcePort = one("source_port", "source_port_id", viaPort.source_port_id)
    const viaComponent = one("pcb_component", "pcb_component_id", viaPort.pcb_component_id)
    assert.equal(viaComponent.source_component_id, viaSourcePort.source_component_id)
    const sourceVia = one("source_manually_placed_via", "source_manually_placed_via_id", viaSourcePort.source_component_id)
    assert.equal(sourceVia.source_net_id, spec.net)
    const capSourcePort = one("source_port", "source_port_id", capPort.source_port_id)
    const capComponent = one("pcb_component", "pcb_component_id", capPort.pcb_component_id)
    assert.equal(capComponent.source_component_id, capSourcePort.source_component_id)
    const capPads = core.filter(row => row.type === "pcb_smtpad" && row.pcb_port_id === capPort.pcb_port_id)
    assert.equal(capPads.length, 1, `Reference capacitor port ${spec.cap} must own one native SMT pad`)
    const capPad = capPads[0]!
    assert.equal(capPad.pcb_component_id, capPort.pcb_component_id)
    assert.equal(capPad.x, capPort.x); assert.equal(capPad.y, capPort.y); assert.equal(capPad.layer, capPort.layers[0])
    assert.equal(core.filter(row => row.type === "pcb_smtpad" && row.pcb_port_id === viaPort.pcb_port_id).length, 0)
    const fixed = input.traces!.filter(trace => trace.source_trace_id === spec.trace)
    assert.equal(fixed.length, 1)
    const fixedTrace = fixed[0]!
    assert.equal(fixedTrace.connection_name, spec.trace)
    const physical = (fixedTrace as Trace & { physicalContextMetadata?: CoreRecord }).physicalContextMetadata
    assert.equal(physical?.pcb_via_id, spec.via); assert.equal(physical?.source_net_id, spec.net)
    const viaPoints = fixedTrace.route.filter(point => point.route_type === "via")
    assert.equal(viaPoints.length, 1)
    const viaPoint = viaPoints[0]!
    assert.equal(viaPoint.x, via.x); assert.equal(viaPoint.y, via.y)
    assert.equal(viaPoint.via_diameter, via.outer_diameter); assert.equal(viaPoint.via_hole_diameter, via.hole_diameter)
    assert.deepEqual(viaPoint.layers, via.layers)
    connections.push({ name: spec.trace, source_trace_id: spec.trace,
      nominalTraceWidth: sourceTrace.min_trace_thickness, width: sourceTrace.min_trace_thickness,
      pointsToConnect: ports.map((port: CoreRecord) => ({ x: port.x, y: port.y,
        layer: port.layers[0], layers: [...port.layers], pointId: port.pcb_port_id, pcb_port_id: port.pcb_port_id })) })
    entries.push({ connectionName: spec.trace, sourceTraceId: spec.trace, sourceNetId: spec.net,
      pcbTraceId: fixedTrace.pcb_trace_id, viaId: spec.via, viaPortId: spec.port, capPortId: spec.cap,
      sourceTrace: structuredClone(sourceTrace), via: structuredClone(via), viaPort: structuredClone(viaPort),
      capPort: structuredClone(capPort), viaSourcePort: structuredClone(viaSourcePort),
      viaComponent: structuredClone(viaComponent), sourceVia: structuredClone(sourceVia),
      capSourcePort: structuredClone(capSourcePort), capComponent: structuredClone(capComponent), capPad: structuredClone(capPad),
      fixedTrace: structuredClone(fixedTrace) })
  }
  return { connections, entries, audit: { nativeDdrConnections: 49, nativeDdrPortAudit,
    referenceCount: 2, referenceEntries: entries, viaInPadAllowed: false, inputConnectionsUnmodified: true } }
}
