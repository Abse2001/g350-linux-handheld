"""Source-only metadata hashing; never import numerical/geometry packages."""
from pathlib import Path
import stat
import inventory

PARTS=('numpy','numpy.libs','numpy-2.3.5.dist-info','shapely','shapely.libs','shapely-2.1.2.dist-info')
KEYS=('treeSha256','regularFiles','regularBytes','symlinks','directories')

def snapshot(target):
    target=Path(target)
    if not target.is_dir() or target.is_symlink():raise ValueError('Concrete installed target required')
    entries=[]
    for p in sorted(target.iterdir()):
        s=p.lstat()
        if p.is_symlink():raise ValueError('Unexpected target-root symlink')
        kind='directory' if stat.S_ISDIR(s.st_mode) else 'file' if stat.S_ISREG(s.st_mode) else None
        if kind is None:raise ValueError('Special target-root entry')
        entries.append({'name':p.name,'type':kind,'mode':stat.S_IMODE(s.st_mode)})
    trees={}
    for name in PARTS:
        if not(target/name).is_dir() or (target/name).is_symlink():raise ValueError('Pinned package tree missing')
        full=inventory.tree(target/name)
        trees[name]={k:full[k] for k in KEYS}
    return {'target':str(target),'topLevelEntries':entries,'importedPackageTrees':trees}
