#!/usr/bin/env python3
"""ROOT ONLY; source-author has not executed this exact38 public-data copy."""
import hashlib,json,os,stat
from pathlib import Path
assert os.environ.get('G350_SOURCE29_CAD58_PRECOPY_ROOT_APPROVED')=='1','Root full read required'
PLAN=Path('/tmp/g350-source29-cad58-after-truthful-prefork57-sourceonly-next/SNAPSHOT_COPY_INPUTS.json');EXPECTED='82b2d22dad138666b4aef82d6cd2eb4d60b1ca1570d41549f6cb3602a1d77521'
RUN=Path('/tmp/g350-source29-cad-root-20261015-after57');REPORT=Path('/tmp/g350-source29-cad58-root-precopy-report.json')
sha=lambda data:hashlib.sha256(data).hexdigest()
assert PLAN.resolve()==PLAN and sha(PLAN.read_bytes())==EXPECTED
plan=json.loads(PLAN.read_text());assert plan['runRoot']==str(RUN)and plan['requiredSparseFileCount']==len(plan['snapshots'])==38 and plan['requiredSparseBytes']==24380686
assert not RUN.exists()and not RUN.is_symlink()and not REPORT.exists()and not REPORT.is_symlink()
root=Path(plan['snapshotRoot']);assert root.parent==RUN/'snapshots'and root.name=='86585a66f64af30b17f9150777491caf'
prepared=[]
for item in plan['snapshots']:
 row=item['original'];source=Path(row['path']);target=Path(item['snapshotPath'])
 assert source.is_absolute()and source.resolve()==source and len(source.parts)>3 and source.parts[1]=='tmp'
 assert target==root/item['snapshotRelativePath']and target.is_relative_to(root)and item['containerTargetPath']==str(source)
 descriptor=os.open(source,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
 with os.fdopen(descriptor,'rb')as stream:
  info=os.fstat(stream.fileno());assert stat.S_ISREG(info.st_mode)and info.st_size==row['bytes']and stat.S_IMODE(info.st_mode)==row['mode'];data=stream.read(row['bytes']+1)
 assert len(data)==row['bytes']and sha(data)==row['sha256'];prepared.append((row,target,data))
assert len({str(target)for _,target,_ in prepared})==38 and sum(len(data)for _,_,data in prepared)==24380686
RUN.mkdir(mode=0o700)
for row,target,data in prepared:
 target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
 assert target.parent.resolve()==target.parent
 with target.open('xb')as stream:stream.write(data)
 target.chmod(row['mode']);assert sha(target.read_bytes())==row['sha256']and target.stat().st_size==row['bytes']and stat.S_IMODE(target.stat().st_mode)==row['mode']
for row,_,_ in prepared:
 source=Path(row['path']);assert source.resolve()==source and sha(source.read_bytes())==row['sha256']and stat.S_IMODE(source.stat().st_mode)==row['mode']
value={'scope':'ROOT_ACTUAL_SOURCE29_CAD58_EXACT38_PRECOPY','copyInputsPath':str(PLAN),'copyInputsSha256':EXPECTED,'copiedFiles':38,'copiedBytes':24380686,'allOriginalsHeld':True,'allSnapshotBytesModesExact':True,'runRoot':str(RUN),'snapshotRoot':str(root),'RootAuthorityBodiesCopied':0,'SDKOrAppsImported':False,'workspaceWrites':False,'all49Accepted':False,'fabricationReady':False}
with REPORT.open('x')as stream:json.dump(value,stream,indent=2);stream.write('\n')
REPORT.chmod(0o600);print(json.dumps({'passed':True,'reportPath':str(REPORT),'reportSha256':sha(REPORT.read_bytes()),'copiedFiles':38,'copiedBytes':24380686}))
