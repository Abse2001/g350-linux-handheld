/** SOURCE ONLY. Import-free bounded storage, with no routing/geometry policy.
 * Graph keys are nonnegative signed-Int32 integers. Heap IDs are dense labels,
 * never graph keys. A reached capacity blocks only NEW labels; existing labels
 * may still improve. All allocated buffers have the caller's finite label cap.
 */
export class BoundedSparseStateStore {
 readonly states:Int32Array
 readonly parents:Int32Array
 readonly costs:Float64Array
 private readonly labels=new Map<number,number>()
 private used=0
 private capped=false
 readonly maxLabels:number
 constructor(maxLabels=4_000_000){
  if(!Number.isInteger(maxLabels)||maxLabels<1||maxLabels>8_000_000)throw new RangeError('maxLabels must be an integer in 1..8000000')
  this.maxLabels=maxLabels
  this.states=new Int32Array(maxLabels)
  this.parents=new Int32Array(maxLabels)
  this.costs=new Float64Array(maxLabels)
 }
 get count(){return this.used}
 get limitReached(){return this.capped}
 private key(key:number){
  if(!Number.isInteger(key)||key<0||key>2_147_483_647)throw new RangeError('Graph state key must be a nonnegative signed-Int32 integer')
 }
 private label(label:number){
  if(!Number.isInteger(label)||label<0||label>=this.used)throw new RangeError('Label is outside the allocated state count')
 }
 get(key:number):number {this.key(key);return this.labels.get(key)??-1}
 /** Return the existing/new dense label iff its cost strictly improves.
  * -1 also means unchanged, or a new key rejected at the label cap. Inspect
  * limitReached to distinguish capacity pressure. parentLabel=-1 is a root.
  */
 relax(key:number,g:number,parentLabel:number):number {
  this.key(key)
  if(!Number.isFinite(g)||g<0)throw new RangeError('State cost must be finite and nonnegative')
  if(parentLabel!==-1)this.label(parentLabel)
  const previous=this.labels.get(key)
  if(previous!==undefined){
   if(g>=this.costs[previous])return -1
   if(parentLabel===previous)throw new RangeError('An improved state cannot be its own parent')
   this.costs[previous]=g;this.parents[previous]=parentLabel;return previous
  }
  if(this.used===this.maxLabels){this.capped=true;return -1}
  const next=this.used++
  this.labels.set(key,next);this.states[next]=key;this.costs[next]=g;this.parents[next]=parentLabel
  return next
 }
 state(label:number):number {this.label(label);return this.states[label]}
 parent(label:number):number {this.label(label);return this.parents[label]}
 cost(label:number):number {this.label(label);return this.costs[label]}
}
