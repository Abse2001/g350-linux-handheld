import { strict as assert } from "node:assert"
import type { SimpleRouteJson, Trace } from "./source/lib/types"
import type { PartialNativeApis } from "./partial-native"
/** Planned actual negative fixture only; never changes or replaces observed Cu. */
export function checkRealComponentEndpointNegative(
  native: SimpleRouteJson,
  positive: any,
  api: PartialNativeApis,
) {
  const before = JSON.stringify({ native, positive }),
    owners = positive.additionalPhysicalReferenceOwners
  assert.ok(
    owners.every(
      (owner: any) =>
        owner.providedCopperOwnerOnly &&
        owner.pointsToConnect.length === 1 &&
        owner.viaAliasContacts.length === 1,
    ),
    "Single real terminal owner view required",
  )
  const output: Trace[] = structuredClone([
    ...native.traces!,
    ...positive.joinedNativePaths,
    ...positive.retainedUnfinishedApproaches,
  ])
  const owner = owners.find((owner: any) => owner.name === "source_trace_932"),
    point = owner.pointsToConnect[0],
    trace = output.find((trace) => trace.connection_name === owner.name)!
  // Coincident original real cap pin and whole barrel are deliberate invalid Cu.
  for (let index = 0; index < 3; index++) {
    trace.route[index].x = point.x
    trace.route[index].y = point.y
  }
  const input = { ...native, connections: [...native.connections, ...owners] }
  const report = api.validateRoutedCopperDrc({
    inputSrj: input,
    routedSrj: { ...input, traces: output },
    clearance: native.minTraceToPadEdgeClearance ?? 0.1016,
    allowBlindAndBuriedVias: false,
  })
  const rejected =
    report.valid === false &&
    report.issues.some(
      (issue: any) =>
        issue.code === "via-at-endpoint" &&
        issue.traceId === trace.pcb_trace_id &&
        issue.connectionName === owner.name,
    )
  assert.ok(
    rejected,
    "Native DRC must reject a via on an actual component terminal",
  )
  assert.ok(
    JSON.stringify({ native, positive }) === before,
    "Negative fixture altered real input/copper",
  )
  return {
    diagnosticFixtureOnly: true,
    originalNativeInputHeld: true,
    observedCopperHeld: true,
    realComponentEndpointRulePreserved: rejected,
    traceId: trace.pcb_trace_id,
    componentPortId: point.pcb_port_id,
    deliberateViaPosition: { x: point.x, y: point.y },
    report,
    accepted49: false,
  }
}
