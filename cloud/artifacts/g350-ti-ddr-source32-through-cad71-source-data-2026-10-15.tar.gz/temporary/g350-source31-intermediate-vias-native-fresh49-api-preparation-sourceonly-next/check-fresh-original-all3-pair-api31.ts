import fs from "node:fs"
import crypto from "node:crypto"
import assert from "node:assert/strict"
import type { SimpleRouteJson, Trace } from "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/types"
const [manifestPath,manifestSha,authorityPath,authoritySha,nativePath,outputPath,...extra]=process.argv.slice(2)
assert.ok(manifestPath&&manifestSha&&authorityPath&&authoritySha&&nativePath&&outputPath&&!extra.length&&!fs.existsSync(outputPath))
assert.equal(process.env.G350_SOURCE20_SOURCE21_INTERMEDIATE_31_FRESH_NATIVE_APPROVED,"1");assert.equal(process.versions.bun,"1.3.14")
const digest=(b:Buffer)=>crypto.createHash("sha256").update(b).digest("hex")
const load=(p:string,h?:string)=>{const b=fs.readFileSync(p);if(h)assert.equal(digest(b),h);return JSON.parse(b.toString())}
try {
const manifest=load(manifestPath,manifestSha),authority=load(authorityPath,authoritySha)
const FUTURE_SOURCE31_CORE_SOURCE_SHA:string|null=null,FUTURE_SOURCE31_PROPOSAL_SHA:string|null=null
const validSha=(v:unknown):v is string=>typeof v==="string"&&/^[0-9a-f]{64}$/.test(v)
assert(validSha(FUTURE_SOURCE31_CORE_SOURCE_SHA),"Root must bind the genuine promoted Source31 source manifest")
assert(validSha(FUTURE_SOURCE31_PROPOSAL_SHA),"Root must bind the genuine promoted Source31 proposal")
assert.equal(manifest.genuineSource31ManifestSha256,FUTURE_SOURCE31_CORE_SOURCE_SHA)
assert.equal(manifest.source31ProposalSha256,FUTURE_SOURCE31_PROPOSAL_SHA)
assert.equal(authority.authorizedByRoot,true);assert.equal(authority.packetSha256,manifestSha);assert.equal(authority.scope,manifest.scope)
for(const row of [...manifest.files,...manifest.externalFiles]){const st=fs.lstatSync(row.path);assert(st.isFile()&&!st.isSymbolicLink());const b=fs.readFileSync(row.path);assert.equal(b.length,row.bytes);assert.equal(st.mode&0o777,row.mode);assert.equal(digest(b),row.sha256)}
const artifacts=manifest.actualFreshArtifacts;assert.deepEqual(authority.freshArtifacts,artifacts)
assert.equal(typeof artifacts.actualCorePath,"string");assert.equal(typeof artifacts.actualCoreSha256,"string");
const raw=fs.readFileSync(artifacts.actualCorePath);assert.equal(digest(raw),artifacts.actualCoreSha256)
const core=JSON.parse(raw.toString()) as Array<Record<string,any>>,native=load(nativePath)
// Native was collected in a prior Root scope; its packet is bound separately.
assert.equal(nativePath,manifest.actualNativeReportPath)
assert.equal(digest(fs.readFileSync(nativePath)),manifest.actualNativeReportSha256)
assert.equal(native.packetSha256,manifest.nativeQualificationPacketSha256)
assert.equal(native.actualCoreSha256,artifacts.actualCoreSha256)
assert.equal(native.checkCount,18);assert.equal(native.physicalErrors,0);assert.equal(native.physicalCpuRamConnectedCarrierCount,31);assert.equal(native.actualNativePairFindings.length,0)
// Source31 physical material and all endpoint IDs must be freshly projected AFTER
// its Native ownership proof. An old631/B262 file is never an accepted binding.
for(const key of ["authorized49InputPath","authorized49InputSha256","fresh49ProjectionProofPath","fresh49ProjectionProofSha256","source31ProposalPath","source31ProposalSha256"])assert.equal(typeof manifest[key],"string",`Future binding absent: ${key}`)
const input=load(manifest.authorized49InputPath,manifest.authorized49InputSha256) as SimpleRouteJson
const projectionProof=load(manifest.fresh49ProjectionProofPath,manifest.fresh49ProjectionProofSha256)
assert.equal(projectionProof.actualCoreSha256,artifacts.actualCoreSha256)
assert.equal(projectionProof.actualNativeReportSha256,digest(fs.readFileSync(nativePath)))
assert.equal(projectionProof.constructorInputSha256,manifest.authorized49InputSha256)
assert.equal(projectionProof.sourceManifestSha256,manifest.genuineSource31ManifestSha256)
assert.equal(projectionProof.originalSource31ProposalSha256,manifest.source31ProposalSha256)
const proposal=load(manifest.source31ProposalPath,manifest.source31ProposalSha256)
const static31={records:proposal.selected31NormalizedRecords}
assert.equal(static31.records.length,31)
const updatedPairs={candidates:Object.fromEntries(proposal.selected29OriginalCarriers.filter((c:Record<string,any>)=>["source_trace_15","source_trace_16","source_trace_27","source_trace_28","source_trace_33","source_trace_34"].includes(c.originalSourceTraceId)).map((c:Record<string,any>)=>[c.originalSourceTraceId,{layer:c.carrierLayer,path:c.expectedCarrierPath,coupledSection:c.coupledSection}]))}
assert.deepEqual(Object.keys(updatedPairs.candidates).sort(),["source_trace_15","source_trace_16","source_trace_27","source_trace_28","source_trace_33","source_trace_34"].sort())
assert.equal(input.connections.length,49);assert.equal(input.traces!.length,263);assert.equal(input.obstacles.length,1298);assert.equal(input.layerCount,4)
assert.equal(input.differentialPairs!.length,3);assert(input.differentialPairs!.every(p=>p.lengthTolerance===.127&&p.traceGap===.12))
assert.equal(core.filter(r=>r.type==="pcb_via").length,229);assert.equal(core.filter(r=>r.type==="pcb_trace").length,296)
assert.equal(core.filter(r=>r.type==="pcb_port").length,1669)
assert.equal(input.traces!.flatMap(t=>t.route).filter(p=>p.route_type==="via").length,98)
const ram14map=native.actualOwnershipProof.signalMappings.find((m:Record<string,any>)=>m.originalSourceTraceId==="source_trace_14"&&m.side===1)
assert(ram14map)
const ram14via=core.find(r=>r.type==="pcb_via"&&r.pcb_via_id===ram14map.actualViaId)!
assert(ram14via&&Math.hypot(ram14via.x-2.4,ram14via.y-12)<1e-9)
const ram14request=input.connections.find(c=>c.name==="source_trace_14")!.pointsToConnect[1]
assert(Math.hypot(ram14request.x-ram14via.x,ram14request.y-ram14via.y)<1e-9,"Fresh49 must include actual relocated barrel")
// Fresh moved CPU3 barrel and its complete four-wire stub must be present in
// this fresh49 material; the later selected-layer view must not hide stale input.
const cpu3map=native.actualOwnershipProof.signalMappings.find((m:Record<string,any>)=>m.originalSourceTraceId==="source_trace_3"&&m.side===0)
assert(cpu3map)
const cpu3via=core.find(r=>r.type==="pcb_via"&&r.pcb_via_id===cpu3map.actualViaId)!
assert(cpu3via&&Math.hypot(cpu3via.x-6.2,cpu3via.y-12.4)<1e-9)
const cpu3request=input.connections.find(c=>c.name==="source_trace_3")!.pointsToConnect[0]
assert(Math.hypot(cpu3request.x-cpu3via.x,cpu3request.y-cpu3via.y)<1e-9)
const cpu3raw=core.find(r=>r.type==="pcb_trace"&&r.pcb_trace_id===cpu3map.actualPcbTraceId)!
const cpu3fixed=input.traces!.find(t=>t.pcb_trace_id===cpu3map.actualPcbTraceId)!
assert(cpu3raw&&cpu3raw.route.length===4&&cpu3fixed&&cpu3fixed.route.length===6)
const cpu3canonical=cpu3raw.route[0].start_pcb_port_id===cpu3map.actualNumericPcbPortId?cpu3raw.route:[...cpu3raw.route].reverse()
assert(cpu3fixed.route.slice(0,4).every((p,i)=>p.route_type==="wire"&&p.layer==="top"&&p.width===.1016&&Math.hypot(p.x-cpu3canonical[i].x,p.y-cpu3canonical[i].y)<1e-9))
const cpu3event=cpu3fixed.route[4] as Trace["route"][number]&{pcb_via_id?:string}
const cpu3tail=cpu3fixed.route[5] as Trace["route"][number]&{pcb_port_id?:string}
assert(cpu3event.route_type==="via"&&cpu3event.pcb_via_id===cpu3via.pcb_via_id&&cpu3tail.route_type==="wire"&&cpu3tail.layer==="bottom"&&cpu3tail.pcb_port_id===cpu3map.actualBottomPcbPortId)
 // The Source7 RAM barrel and all thirteen real Top wirepoints must come from this fresh29 Core.
 const ram7map=native.actualOwnershipProof.signalMappings.find((m:Record<string,any>)=>m.originalSourceTraceId==="source_trace_7"&&m.side===1)
 assert(ram7map)
 const ram7via=core.find(r=>r.type==="pcb_via"&&r.pcb_via_id===ram7map.actualViaId)!
 assert(ram7via&&Math.hypot(ram7via.x+7.4,ram7via.y-7.8)<1e-9)
 const ram7request=input.connections.find(c=>c.name==="source_trace_7")!.pointsToConnect[1]
 assert(Math.hypot(ram7request.x-ram7via.x,ram7request.y-ram7via.y)<1e-9)
 const ram7raw=core.find(r=>r.type==="pcb_trace"&&r.pcb_trace_id===ram7map.actualPcbTraceId)!
 const ram7fixed=input.traces!.find(t=>t.pcb_trace_id===ram7map.actualPcbTraceId)!
 assert(ram7raw&&ram7raw.route.length===13&&ram7fixed&&ram7fixed.route.length===15)
 const ram7canonical=ram7raw.route[0].start_pcb_port_id===ram7map.actualNumericPcbPortId?ram7raw.route:[...ram7raw.route].reverse()
 assert(ram7fixed.route.slice(0,13).every((p,i)=>p.route_type==="wire"&&p.layer==="top"&&p.width===.1016&&Math.hypot(p.x-ram7canonical[i].x,p.y-ram7canonical[i].y)<1e-9))
 const ram7event=ram7fixed.route[13] as Trace["route"][number]&{pcb_via_id?:string}
 const ram7tail=ram7fixed.route[14] as Trace["route"][number]&{pcb_port_id?:string}
 assert(ram7event.route_type==="via"&&ram7event.pcb_via_id===ram7via.pcb_via_id&&ram7tail.route_type==="wire"&&ram7tail.layer==="bottom"&&ram7tail.pcb_port_id===ram7map.actualBottomPcbPortId)
const signature=JSON.stringify(core),bindings=native.actualOwnershipProof.carriers
assert.equal(bindings.length,31)
const projections:Array<Record<string,any>>=[]
type RunView={connectionName:string;actualCarrierPcbTraceId:string;layer:string;startPcbPortId:string;endPcbPortId:string;trace:Trace}
const wireRuns:RunView[]=[],intermediateMappings=native.actualOwnershipProof.intermediateCarrierMappings as Array<Record<string,any>>
assert.equal(intermediateMappings.length,2);assert.deepEqual(intermediateMappings.map(m=>m.originalSourceTraceId),["source_trace_20","source_trace_21"])
assert.equal(projectionProof.raw229BarrelsExplicitlyPartitioned,true);assert.equal(projectionProof.unseededFixed227BarrelsRepresentedExactlyOnce,true)
assert.deepEqual([...projectionProof.removedIntermediateCarrierViaIds2].sort(),intermediateMappings.map(m=>m.actualViaId).sort())
assert(!input.obstacles.some(o=>intermediateMappings.some(m=>o.obstacleId===m.actualViaId)))
const actualPort=(id:string)=>{const found=core.filter(r=>r.type==="pcb_port"&&r.pcb_port_id===id);assert.equal(found.length,1);return found[0]}
const traces:Trace[]=bindings.map((binding:Record<string,any>)=>{
 const direct=core.filter(r=>r.type==="pcb_trace"&&r.source_trace_id===binding.originalSourceTraceId)
 const id=binding.originalSourceTraceId
 if(["source_trace_20","source_trace_21"].includes(id)){
  assert.equal(binding.carrierArchitecture,"TWO_LAYER_ONE_OWNED_INTERMEDIATE_VIA");assert.equal(binding.carrierLayer,null);assert.equal(direct.length,4);assert.deepEqual(direct.map(t=>t.pcb_trace_id),binding.actualDirectPcbTraceIds)
  assert.equal(binding.actualCarrierPcbTraceIds.length,2);assert.equal(binding.carrierPieces.length,2)
  const record=static31.records.find((r:Record<string,any>)=>r.sourceTraceId===id)!
  assert(record&&record.architecture==="TWO_LAYER_ONE_OWNED_INTERMEDIATE_VIA"&&record.layerRuns.length===2&&record.coupledSection===undefined&&record.curvedSegments===undefined)
  const actualRuns:Trace[]=binding.carrierPieces.map((piece:Record<string,any>,i:number)=>{
   assert.equal(piece.layer,i===0?"inner2":"top");assert.equal(piece.actualPcbTraceId,binding.actualCarrierPcbTraceIds[i])
   const body=direct.find(t=>t.pcb_trace_id===piece.actualPcbTraceId)!,expected=record.layerRuns[i]
   assert(body&&expected.layer===piece.layer&&body.route.length===expected.path.length)
   const delta=Math.max(...expected.path.map((p:Record<string,any>,j:number)=>Math.hypot(p.x-body.route[j].x,p.y-body.route[j].y)))
   assert(delta<1e-9&&body.route.every((p:Record<string,any>)=>p.route_type==="wire"&&p.layer===piece.layer&&p.width===.1016))
   const start=actualPort(piece.actualStartPcbPortId),end=actualPort(piece.actualEndPcbPortId)
   assert(start.layers.includes(piece.layer)&&end.layers.includes(piece.layer));assert.equal(body.route[0].start_pcb_port_id,start.pcb_port_id);assert.equal(body.route.at(-1).end_pcb_port_id,end.pcb_port_id)
   const trace={...body,connection_name:id}as Trace;assert(trace.coupledSection===undefined&&trace.curvedSegments===undefined)
   wireRuns.push({connectionName:id,actualCarrierPcbTraceId:body.pcb_trace_id,layer:piece.layer,startPcbPortId:start.pcb_port_id,endPcbPortId:end.pcb_port_id,trace})
   return trace
  })
  const m=intermediateMappings.find(m=>m.originalSourceTraceId===id)!,v=core.find(r=>r.type==="pcb_via"&&r.pcb_via_id===m.actualViaId)!
  assert(m&&m.physicalGraphProved&&m.fixedFanout===false&&v);assert.deepEqual(v.layers,["top","inner1","inner2","bottom"]);assert.equal(v.from_layer,"top");assert.equal(v.to_layer,"bottom");assert.equal(v.outer_diameter,.4572);assert.equal(v.hole_diameter,.254)
  assert.deepEqual(binding.actualRemovableCarrierViaIds,[v.pcb_via_id]);assert.equal(actualRuns[0].route.at(-1)!.x,v.x);assert.equal(actualRuns[0].route.at(-1)!.y,v.y);assert.equal(actualRuns[1].route[0].x,v.x);assert.equal(actualRuns[1].route[0].y,v.y)
  // Exact actual physical span, with active I2->Top transition recorded separately.
  // This is a body-only analysis view, prohibited as a generic router input or authoritative raw trace.
  const marker={route_type:"via",x:v.x,y:v.y,from_layer:v.from_layer,to_layer:v.to_layer,layers:[...v.layers],via_diameter:v.outer_diameter,via_hole_diameter:v.hole_diameter,pcb_via_id:v.pcb_via_id}
  const route=[...actualRuns[0].route,marker,...actualRuns[1].route] as Trace["route"]
  projections.push({originalSourceTraceId:id,actualCarrierPcbTraceId:null,actualCarrierPcbTraceIds:binding.actualCarrierPcbTraceIds,actualDirectPcbTraceIds:binding.actualDirectPcbTraceIds,actualIntermediateViaId:v.pcb_via_id,maximumCoordinateDeltaMm:Math.max(...record.layerRuns.flatMap((run:Record<string,any>,i:number)=>run.path.map((p:Record<string,any>,j:number)=>Math.hypot(p.x-actualRuns[i].route[j].x,p.y-actualRuns[i].route[j].y)))),carrierLayer:null,physicalViaSpanCopiedExactly:true,activeLayerTransition:{x:v.x,y:v.y,fromLayer:"inner2",toLayer:"top"},analysisProjectionOnly:true,pcbTraceIdIsFirstBodyAnalysisKeyOnly:true,authoritativeAggregatePcbTraceObjectExists:false,coupledSection:null})
  return {type:"pcb_trace",pcb_trace_id:binding.actualCarrierPcbTraceIds[0],source_trace_id:id,connection_name:id,route} as Trace
 }
 assert.equal(direct.length,3);assert.deepEqual(direct.map(t=>t.pcb_trace_id),binding.actualDirectPcbTraceIds)
 const body=direct.find(t=>t.pcb_trace_id===binding.actualCarrierPcbTraceId)!
 assert(body&&body.route.every((p:Record<string,any>)=>p.route_type==="wire"&&p.layer===binding.carrierLayer&&p.width===.1016))
 const record=static31.records.find((r:Record<string,any>)=>r.sourceTraceId===binding.originalSourceTraceId)!
 assert(record&&record.layer===binding.carrierLayer&&record.path.length===body.route.length)
 const delta=Math.max(...record.path.map((p:Record<string,any>,i:number)=>Math.hypot(p.x-body.route[i].x,p.y-body.route[i].y)))
 assert(delta<1e-9)
 let coupledSection=record.coupledSection
 const pair=updatedPairs.candidates[binding.originalSourceTraceId]
 if(pair){
  assert.equal(pair.layer,binding.carrierLayer);assert.equal(pair.path.length,body.route.length)
  assert(pair.path.every((p:Record<string,any>,i:number)=>Math.hypot(p.x-body.route[i].x,p.y-body.route[i].y)<1e-9),"Coupled-section evidence must cover the complete authentic NEW physical carrier")
  coupledSection=pair.coupledSection
  assert(Array.isArray(coupledSection)&&coupledSection.length===2&&coupledSection.every(Number.isInteger)&&coupledSection[0]>=0&&coupledSection[0]<coupledSection[1]&&coupledSection[1]<body.route.length)
 }
 wireRuns.push({connectionName:binding.originalSourceTraceId,actualCarrierPcbTraceId:body.pcb_trace_id,layer:binding.carrierLayer,startPcbPortId:binding.actualCpuCarrierLayerPcbPortId,endPcbPortId:binding.actualRamCarrierLayerPcbPortId,trace:{...body,connection_name:binding.originalSourceTraceId,coupledSection}as Trace})
 projections.push({originalSourceTraceId:binding.originalSourceTraceId,actualCarrierPcbTraceId:body.pcb_trace_id,actualDirectPcbTraceIds:binding.actualDirectPcbTraceIds,maximumCoordinateDeltaMm:delta,carrierLayer:binding.carrierLayer,coupledSection:coupledSection??null})
 return {...body,connection_name:binding.originalSourceTraceId,coupledSection} as Trace
})
// Geometry view names remain original49. Only endpoint layer/ID anchors for the
// actually completed31 are derived from their genuine fresh physical aliases.
const byName=new Map(bindings.map((b:Record<string,any>)=>[b.originalSourceTraceId,b]))
const apiInput:SimpleRouteJson={...input,connections:input.connections.map(c=>{
 const b=byName.get(c.name) as Record<string,any>|undefined;if(!b)return c
 const ids=[b.actualCpuCarrierLayerPcbPortId,b.actualRamCarrierLayerPcbPortId]
 return {...c,pointsToConnect:c.pointsToConnect.map((p,i)=>{
  const actualPort=core.find(r=>r.type==="pcb_port"&&r.pcb_port_id===ids[i])!
  const layer=b.carrierArchitecture==="TWO_LAYER_ONE_OWNED_INTERMEDIATE_VIA"?(i===0?b.cpuCarrierLayer:b.ramCarrierLayer):b.carrierLayer
  assert(actualPort&&actualPort.layers.includes(layer),"Authentic physical per-end carrier alias required")
  return {...p,x:actualPort.x,y:actualPort.y,layer,pointId:actualPort.pcb_port_id,pcb_port_id:actualPort.pcb_port_id}
 })}
})}
const dataSignature=JSON.stringify({input,apiInput,static31,updatedPairs,traces})
// Load unchanged private implementations only after all actual Root/data bindings pass.
const {VectorScene, fixedCopper}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/vector-scene")
const {tuningPathIsSelfClear}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/length-tuning")
const {sharedPairSpacingReports}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/shared-pair-spacing")
const {exteriorPairSpacingReports}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/exterior-pair-spacing")
const {pairCouplingReports}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/pair-coupling")
const {pairLengthReports, busLengthReports, fixedRouteLength}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/route-lengths")
const {routeAnglesAreConventional}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/route-angle-validation")
const {segmentDistance,pointSegmentDistanceToPoints}=await import("/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/geometry")
const fixed=fixedCopper(apiInput)
assert.equal(wireRuns.length,33);assert.equal(traces.length,31);assert.equal(new Set(traces.map(t=>t.connection_name)).size,31)
// fixedCopper understands physical via layers/diameters; routeCopper is intentionally never called on these mixed views.
const candidateCopperByName=new Map(traces.map(t=>[t.connection_name!,fixedCopper({...apiInput,obstacles:[],traces:[t]})]))
const fullSpanViaCoverage=intermediateMappings.map(m=>{
 const v=core.find(r=>r.type==="pcb_via"&&r.pcb_via_id===m.actualViaId)!,capsules=candidateCopperByName.get(m.originalSourceTraceId)!.filter(c=>Math.hypot(c.a.x-v.x,c.a.y-v.y)<1e-9&&Math.hypot(c.b.x-v.x,c.b.y-v.y)<1e-9&&Math.abs(c.radius-v.outer_diameter/2)<1e-9)
 assert.equal(capsules.length,4);assert.deepEqual(capsules.map(c=>c.layer).sort(),["top","inner1","inner2","bottom"].sort());assert(capsules.every(c=>c.owners.includes(m.originalSourceTraceId)&&c.owners.every(owner=>owner===m.originalSourceTraceId)))
 return {originalSourceTraceId:m.originalSourceTraceId,actualViaId:v.pcb_via_id,physicalFromLayer:v.from_layer,physicalToLayer:v.to_layer,physicalLayers:[...v.layers],radiusMm:v.outer_diameter/2,capsuleCount:4,allFourLayersIncluded:true,foreignScenesDoNotIgnoreThisOwner:true}
})
const runContinuity=wireRuns.map(run=>{
 const c=apiInput.connections.find(c=>c.name===run.connectionName)!,binding=byName.get(run.connectionName)as Record<string,any>
 assert(c&&binding.actualSourceOwnedPhysicalGraph.physicallyConnected)
 const endpoints=[actualPort(run.startPcbPortId),actualPort(run.endPcbPortId)]
 assert(endpoints.every(p=>p.layers.includes(run.layer)))
 const connection={...c,pointsToConnect:endpoints.map(p=>({x:p.x,y:p.y,layer:run.layer,pointId:p.pcb_port_id,pcb_port_id:p.pcb_port_id}))}
 assert(Math.hypot(run.trace.route[0].x-endpoints[0].x,run.trace.route[0].y-endpoints[0].y)<1e-9);assert(Math.hypot(run.trace.route.at(-1)!.x-endpoints[1].x,run.trace.route.at(-1)!.y-endpoints[1].y)<1e-9)
 assert(run.trace.route.every(p=>p.route_type==="wire"&&p.layer===run.layer&&p.width===.1016))
 const others=[...candidateCopperByName].filter(([name])=>name!==run.connectionName).flatMap(([,copper])=>copper),scene=new VectorScene(apiInput,connection,.1016,[...fixed,...others])
 return {connectionName:run.connectionName,actualCarrierPcbTraceId:run.actualCarrierPcbTraceId,layer:run.layer,actualStartPcbPortId:run.startPcbPortId,actualEndPcbPortId:run.endPcbPortId,pathVisible:scene.pathVisible(run.trace.route),segmentsVisible:run.trace.route.slice(1).map((p,i)=>scene.visible(run.trace.route[i],p)),selfClear:tuningPathIsSelfClear(run.trace.route,.2032),conventionalAngles:routeAnglesAreConventional([run.trace]),foreignAll33WireRunsAndBothFullspanViasIncluded:true}
})
// This extra guard implements the geometry peer's strict 3W nonlocal criterion.
// Original self-clear calls above remain .2032 and byte-exact private implementations.
const xy=(p:Trace["route"][number])=>({x:p.x,y:p.y})
function strictNonlocal3W(path:Array<{x:number;y:number}>){
 const cumulative=[0],turns=[0],failures:Array<Record<string,any>>=[];let minimum=Infinity,localPairs=0,nonlocalPairs=0
 for(let i=1;i<path.length;i++)cumulative.push(cumulative[i-1]+Math.hypot(path[i].x-path[i-1].x,path[i].y-path[i-1].y))
 for(let i=1;i<path.length-1;i++){const a={x:path[i].x-path[i-1].x,y:path[i].y-path[i-1].y},b={x:path[i+1].x-path[i].x,y:path[i+1].y-path[i].y};turns.push(turns[i-1]+Math.abs(Math.atan2(a.x*b.y-a.y*b.x,a.x*b.x+a.y*b.y)))}
 for(let i=0;i<path.length-1;i++)for(let j=i+2;j<path.length-1;j++){
  const separation=segmentDistance([path[i],path[i+1]],[path[j],path[j+1]]),contour=cumulative[j]-cumulative[i+1]
  if(separation<1e-9&&contour>1e-8){failures.push({firstSegment:i,secondSegment:j,reason:"NONADJACENT_INTERSECTION",separationMm:separation});continue}
  if(contour<=Math.PI*.2032+1e-8&&turns[j]-turns[i]<=Math.PI/2+1e-8){localPairs++;continue}
  nonlocalPairs++;minimum=Math.min(minimum,separation);if(separation<.3048-1e-8)failures.push({firstSegment:i,secondSegment:j,reason:"STRICT_3W_NONLOCAL_SPACING",separationMm:separation})
 }
 return {requiredCenterSpacingMm:.3048,localContourLimitMm:Math.PI*.2032,localTurnMaximumDegrees:90,localPairs,nonlocalPairs,minimumNonlocalCenterMm:Number.isFinite(minimum)?minimum:null,failures,passed:failures.length===0}
}
function ownBarrelContacts(path:Trace["route"],via:Record<string,any>){
 assert(path.length>=2&&path.every(p=>p.route_type==="wire"))
 const same=(p:{x:number;y:number})=>Math.hypot(p.x-via.x,p.y-via.y)<1e-8,atStart=same(path[0]),atEnd=same(path.at(-1)!),reach=via.outer_diameter/2+.1016/2+.1016
 assert(!(atStart&&atEnd),"A local carrier run cannot be a via-to-itself loop")
 const ordered=atEnd?[...path].reverse():path;let leftInitialEnvelope=false,passed=true
 for(let i=1;i<ordered.length;i++){
  const a=ordered[i-1],b=ordered[i],separation=pointSegmentDistanceToPoints(via,a,b)
  if((!atStart&&!atEnd||leftInitialEnvelope)&&separation<reach-1e-8)passed=false
  if(Math.hypot(b.x-via.x,b.y-via.y)>reach+1e-8)leftInitialEnvelope=true
 }
 return {actualViaId:via.pcb_via_id,pathLayer:(path[0]as any).layer,ownedEndpointContact:atStart||atEnd,onlyInitialConnectedContactEnvelopeAllowed:true,clearanceEnvelopeCenterMm:reach,passed}
}
const jointNetChecks=["source_trace_20","source_trace_21"].map(name=>{
 const binding=byName.get(name)as Record<string,any>,runs=wireRuns.filter(r=>r.connectionName===name);assert.equal(runs.length,2)
 const mappings=native.actualOwnershipProof.signalMappings.filter((m:Record<string,any>)=>m.originalSourceTraceId===name),cpu=mappings.find((m:Record<string,any>)=>m.side===0),ram=mappings.find((m:Record<string,any>)=>m.side===1)
 assert(cpu&&ram)
 const cpuRaw=core.find(r=>r.type==="pcb_trace"&&r.pcb_trace_id===cpu.actualPcbTraceId)!,ramRaw=core.find(r=>r.type==="pcb_trace"&&r.pcb_trace_id===ram.actualPcbTraceId)!
 const orient=(route:Trace["route"],startId:string)=>(route[0]as any).start_pcb_port_id===startId?[...route]:[...route].reverse()
 const cpuStub=orient(cpuRaw.route,cpu.actualNumericPcbPortId),ramStub=orient(ramRaw.route,ram.actualTopPcbPortId)
 const top=runs.find(r=>r.layer==="top")!,inner=runs.find(r=>r.layer==="inner2")!
 assert(Math.hypot(top.trace.route.at(-1)!.x-ramStub[0].x,top.trace.route.at(-1)!.y-ramStub[0].y)<1e-9)
 const merged=[...top.trace.route,...ramStub.slice(1)],mergedView={...top.trace,route:merged}
 const originalMergedSelf=tuningPathIsSelfClear(merged,.2032),strict3W=strictNonlocal3W(merged.map(xy)),mergedAngles=routeAnglesAreConventional([mergedView])
 let disconnectedMinimum=Infinity;for(let i=1;i<cpuStub.length;i++)for(let j=1;j<merged.length;j++)disconnectedMinimum=Math.min(disconnectedMinimum,segmentDistance([cpuStub[i-1],cpuStub[i]],[merged[j-1],merged[j]]))
 const disconnectedCpuStubClear=disconnectedMinimum>=.3048-1e-8
 const ownVias=[binding.actualCpuViaId,...binding.actualRemovableCarrierViaIds,binding.actualRamViaId].map(id=>core.find(r=>r.type==="pcb_via"&&r.pcb_via_id===id)!)
 assert.equal(ownVias.length,3);assert(ownVias.every(v=>v&&v.layers.length===4))
 const contactRows=[cpuStub,inner.trace.route,top.trace.route,ramStub].flatMap(path=>ownVias.filter(v=>v.layers.includes((path[0]as any).layer)).map(v=>ownBarrelContacts(path,v)))
 const ownedBarrelContactsBounded=contactRows.every(r=>r.passed)
 return {connectionName:name,actualDirectPcbTraceIds:binding.actualDirectPcbTraceIds,originalMergedSelfClear2032:originalMergedSelf,strict3WNonlocalTopSelf:strict3W,mergedRamJunctionConventionalAngles:mergedAngles,disconnectedCpuTopStubMinimumCenterMm:disconnectedMinimum,disconnectedCpuTopStubRequiredCenterMm:.3048,disconnectedCpuTopStubClear,ownBarrelContactRows:contactRows,ownedBarrelContactsBounded,passed:originalMergedSelf&&strict3W.passed&&mergedAngles&&disconnectedCpuStubClear&&ownedBarrelContactsBounded}
})
const continuity=traces.map(t=>{
 const rows=runContinuity.filter(r=>r.connectionName===t.connection_name),b=byName.get(t.connection_name!)as Record<string,any>
 assert.equal(rows.length,["source_trace_20","source_trace_21"].includes(t.connection_name!)?2:1)
 return {connectionName:t.connection_name,actualCarrierPcbTraceIds:rows.map(r=>r.actualCarrierPcbTraceId),actualSourceOwnedPhysicalGraphProved:b.actualSourceOwnedPhysicalGraph.physicallyConnected,pathVisible:rows.every(r=>r.pathVisible),segmentsVisible:rows.flatMap(r=>r.segmentsVisible),selfClear:rows.every(r=>r.selfClear),conventionalAngles:rows.every(r=>r.conventionalAngles),fixedPlanarLength:fixedRouteLength(apiInput,t.connection_name!),bodyOnlyLengthViewIncludesAllRunsOnce:true}
})
const shared=sharedPairSpacingReports(apiInput,traces),exterior=exteriorPairSpacingReports(apiInput,traces),coupling=pairCouplingReports(apiInput,traces),pairLengths=pairLengthReports(apiInput,traces)
assert.equal(shared.length,3);assert.equal(exterior.length,3);assert.equal(coupling.length,3);assert.equal(pairLengths.length,3)
// The pinned Trace type supports one contiguous coupledSection. Both real
// shared meanders are evaluated; geometry stays identical between metadata views.
const primaryName=proposal.primaryCoupledSectionView,secondaryName=proposal.secondaryCoupledSectionView
assert.equal(primaryName,"lower_coupled_U");assert.equal(secondaryName,"early_reflected_meander")
assert.equal(proposal.singleCoupledSectionCoversBoth,false)
assert.equal(proposal.bothActualSharedMeandersMustBeChecked,true)
const views=proposal.dqs1CouplingViews
assert.equal(views.length,2)
const secondaryView=views.find((v:Record<string,any>)=>v.name===secondaryName)!
assert(secondaryView)
const secondaryTraces:Trace[]=traces.map(t=>{
 const range=secondaryView.ranges[t.connection_name!]
 if(!range)return t
 assert(["source_trace_27","source_trace_28"].includes(t.connection_name!))
 assert(Array.isArray(range)&&range.length===2&&range.every(Number.isInteger)&&range[0]>=0&&range[0]<range[1]&&range[1]<t.route.length)
 return {...t,coupledSection:[...range] as [number,number]}
})
const strip=(t:Trace)=>{const {coupledSection,...rest}=t;return rest}
assert.deepEqual(secondaryTraces.map(strip),traces.map(strip),"Metadata view cannot alter copper or endpoints")
const dqs1Pairs=apiInput.differentialPairs!.filter(p=>p.connectionNames.includes("source_trace_27")&&p.connectionNames.includes("source_trace_28"))
assert.equal(dqs1Pairs.length,1)
const secondaryInput={...apiInput,differentialPairs:dqs1Pairs}
const secondarySignature=JSON.stringify({secondaryInput,secondaryTraces})
const secondaryShared=sharedPairSpacingReports(secondaryInput,secondaryTraces),secondaryExterior=exteriorPairSpacingReports(secondaryInput,secondaryTraces),secondaryCoupling=pairCouplingReports(secondaryInput,secondaryTraces)
assert.equal(secondaryShared.length,1);assert.equal(secondaryExterior.length,1);assert.equal(secondaryCoupling.length,1)
const secondViewPassed=secondaryShared.every(r=>r.matched)&&secondaryExterior.every(r=>r.matched)&&secondaryCoupling.every(r=>r.matched)
const originalAll49BusReports=busLengthReports(apiInput,traces)
const completedNames=new Set(traces.map(t=>t.connection_name))
const cohortViews=apiInput.buses!.filter(b=>b.busId!=="DDR_RESET").map(b=>({...b,connectionNames:b.connectionNames.filter(n=>completedNames.has(n))}))
const loadedCohortBusReports=busLengthReports({...apiInput,buses:cohortViews},traces)
const byte0=loadedCohortBusReports.find(b=>b.busId==="DDR_BYTE0")!
assert.equal(byte0.lengths.length,6)
const byte1=loadedCohortBusReports.find(b=>b.busId==="DDR_BYTE1")!
assert.equal(byte1.lengths.length,11)
 const ca=loadedCohortBusReports.find(b=>b.busId==="DDR_COMMAND_CLOCK")!
 assert.equal(ca.lengths.length,13)
 const held=signature===JSON.stringify(core)&&dataSignature===JSON.stringify({input,apiInput,static31,updatedPairs,traces})&&secondarySignature===JSON.stringify({secondaryInput,secondaryTraces})
const report={scope:"ACTUAL_SOURCE31_TWO_INTERMEDIATE_VIAS_ALL3_UNCHANGED_PRIVATE_APIS_PER_RUN_DIAGNOSTIC",packetSha256:manifestSha,actualCorePath:artifacts.actualCorePath,actualCoreSha256:artifacts.actualCoreSha256,actualNativeReportPath:nativePath,actualNativeReportSha256:digest(fs.readFileSync(nativePath)),actualCarrierProjections:projections,updatedAuthenticPairEvidence:{path:manifest.source31ProposalPath,sha256:manifest.source31ProposalSha256,field:"selected29OriginalCarriers[].coupledSection",bothRealDqs1CoupledViews:views},stale21316IndicesOr068fSource28GeometryUsed:false,actualNumericPhysicalGraphsRequired:true,actualClockGeometryUsed:true,originalPrivateContinuousApiImplementationsUnchanged:true,automaticCoreSrjUsed:false,original49Input:{path:manifest.authorized49InputPath,sha256:manifest.authorized49InputSha256},completeHardwareSignalsRequested:49,actualCompleteOriginalSignalCount:31,expectedMissingOriginalSignalCount:18,fresh49ProjectionProof:{path:manifest.fresh49ProjectionProofPath,sha256:manifest.fresh49ProjectionProofSha256,actualCoreSha256:projectionProof.actualCoreSha256},fullOriginalBusRostersAndConstraintsHeld:true,originalFullDifferentialPairArrayUnchanged:true,all3DifferentialPairsInvokedAgainstFreshCopper:true,actualLayerAndEndpointIdViewDerivedFromFreshPhysicalOwnedAliases:true,rawCoreOrAuthoritativeInputRetagged:false,exactMaterialHeld:held,bodyOnlyTraceViewCount:31,actualPhysicalWireRunCount:33,runContinuity,jointNetChecks,fullSpanViaCoverage,analysisMixedRoutesNotGenericRouterInputs:true,fullTiClassOrElectricalQualificationClaimed:false,continuity,shared,exterior,coupling,pairLengths,secondaryDqs1View:{name:secondaryName,geometryAndEndpointsUnchanged:true,shared:secondaryShared,exterior:secondaryExterior,coupling:secondaryCoupling,passed:secondViewPassed},checkInventory:{perNetSummaries:31,actualWireRunRows:33,runPredicates:["pathVisible","allSegmentsVisible","selfClear2032","conventionalAngles"],runBooleanPredicates:33*4,originalPairBooleanPredicates:3*4,secondaryDqs1BooleanPredicates:3,allOriginalApiBooleanPredicates:33*4+3*4+3,additionalJointNetAggregates:2,originalApiPlusJointAggregateGates:33*4+3*4+3+2,jointAggregateSubchecks:["originalMergedSelf2032","strictNonlocal3W3048","mergedRamJunctionAngles","disconnectedCpuStub3W3048","boundedOwnedBarrelContacts"],loadedCohortBusGatesAdditional:3,immutableDataGateAdditional:1},originalAll49BusReports,loadedCohortBusReports,loadedCohortViews:cohortViews,loadedCohortsExplicitlyPartial:{DDR_BYTE0:6,DDR_BYTE1:11,DDR_COMMAND_CLOCK:13},onlyByte1FullElevenPresent:true,originalFullByte0AndCaStillIncomplete:true,nativeManufacturingCheckerExecuted:false,coreRenderedByThisWorker:false,freshCadExecuted:false,originalGridOrPublicSolverExecuted:false,fullCohortTimingPassed:false,electricalDelayModelQualified:false,referenceQualified:false,complete31Accepted:false,accepted49:false,fabricationReady:false,allOriginalApiLoaded31ChecksPassed:held&&secondViewPassed&&jointNetChecks.every(r=>r.passed)&&continuity.every(r=>r.pathVisible&&r.segmentsVisible.every(Boolean)&&r.selfClear&&r.conventionalAngles)&&shared.every(r=>r.matched)&&exterior.every(r=>r.matched)&&coupling.every(r=>r.matched)&&pairLengths.every(r=>r.matched)&&loadedCohortBusReports.every(r=>r.aboveMinimumLength&&r.withinLengthLimit&&r.matched)}
fs.writeFileSync(outputPath,`${JSON.stringify(report,null,2)}\n`,{flag:"wx",mode:0o600})
assert.equal(report.allOriginalApiLoaded31ChecksPassed,true,"Complete actual diagnostics retained before assertion; never relax a failed original API")
console.log(JSON.stringify({scope:report.scope,allOriginalApiLoaded31ChecksPassed:true,expectedMissingOriginalSignalCount:18,accepted49:false,outputPath}))

} catch(error) {
 if(!fs.existsSync(outputPath))fs.writeFileSync(outputPath,JSON.stringify({scope:"UNRESOLVED_SOURCE31_INTERMEDIATE_VIA_ORIGINAL_API_PRECONDITION_OR_PROJECTION",passed:false,failure:String(error),actualRawCoreOrInputEdited:false,rawAndFailureDiagnosticPreserved:true,accepted49:false,referenceQualified:false,electricalTimingQualified:false,fabricationReady:false},null,2)+"\n",{flag:"wx",mode:0o600})
 throw error
}
