#!/usr/bin/env python3
"""SOURCE ONLY: append closed Root244 critical companion to saved MODEL24348.

Pure standard library. No application imports or routing execution. Root runs
this source separately after review. Only the post232 saved folder is writable;
Source23347 and its Source236 scoped-pour fallback remain exactly as recorded.
"""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat

ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post232-2026-10-16'
OLD = ROOT / '.cloud-tools/ddr-four-layer-post209-2026-10-16'
RUN = Path('/tmp/g350-joint48-critical-root-20261016-run244')
REPORT = RUN / 'byte0-result.json'
CANDIDATE = Path('/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json')
MODEL_REPORT = Path('/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.json')
WORKER = Path('/tmp/g350-actual243-joint48-critical6-two-dqs1-views-sourceonly.ts')
INITIAL = {
    'PROGRESS.json': '3e3b48feac546e899d1d993a32aaa31c3a1d8b22a3abd1721cc4247937a101bc',
    'WORKSPACE_HASH_INDEX.json': 'e21c9b7295f75f6f05c5fe954a912c938bb170b2addb2909a7fdc9dfae2c91f1',
    'WORKSPACE_RESTORE_MANIFEST.json': '9ba5c5bc1cc7a6c970c2d524fa9da70404ca08ce5dec12bbab46b196def66455',
    'README.md': 'c9b21bdb939e63bbdd957ecae20841ff3505bc3fd8caa7ffb67cdfdb077c4e89',
}
OLD_PINS = {
    'WORKSPACE_HASH_INDEX.json': '809a4437af0306c37aa759044131fbaa9939032244284705c31a3910d339a83d',
    'WORKSPACE_RESTORE_MANIFEST.json': 'd8a8ebdc11a3900affe120fdd70c946403c4e26bf9b7b02bd9a1088a98369cef',
    'PROGRESS.json': 'fac4424b0ca0fe1b74fc640687a0567b7b3264267a65da5acfff5eb9091b5ef0',
}
PINS = {
    str(RUN / 'COLLECTED.json'): '48305c50722cdef52df0d3c73451ae0c5dc6442e1a494b207ece2d7224035d7c',
    str(RUN / 'owned/execution.json'): '49dbdb568bf4df7b480375e848e1ef511b20a6401b0fec48082c2932c96d76f6',
    str(REPORT): '0867dce555fe0aea211bf269100b22cb21717ce2298551de7f071c967da05d99',
    str(CANDIDATE): 'cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720',
    str(MODEL_REPORT): '3745a26adbe3b1123cdcff161a39cd4a589c2baba0f55b74515a1925afaad237',
    str(WORKER): '471d2d0ea5b89bb4c10dd88d68f0fa3510c99531b98dc8cfb993ebaf38768dde',
}
CRITICAL = {'source_trace_' + str(i) for i in (15, 16, 27, 28, 33, 34)}


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
        if hasattr(os, 'posix_fadvise'):
            os.posix_fadvise(stream.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return h.hexdigest()


def read(p):
    with p.open('rb') as stream:
        return json.load(stream)


def regular(p):
    return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)


def safe(p):
    denied = ('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT', 'AUTHORITY_PACKET')
    return (p.is_absolute() and str(p).startswith('/tmp/g350-') and p.resolve().is_relative_to('/tmp')
            and not any(part in str(p).upper() for part in denied))


def metadata(p):
    s = p.stat()
    return {'bytes': s.st_size, 'sha256': digest(p), 'mode': stat.S_IMODE(s.st_mode)}


def verify_rows(folder, rows):
    for row in rows:
        relative = Path(row['path'])
        p = folder / relative
        require(not relative.is_absolute() and '..' not in relative.parts
                and p.resolve().is_relative_to(folder.resolve()) and regular(p)
                and metadata(p) == {k: row[k] for k in ('bytes', 'sha256', 'mode')},
                'Saved bytes/mode changed: ' + str(p))


def verify_old():
    for name, pin in OLD_PINS.items():
        require(digest(OLD / name) == pin, 'Frozen post209 metadata changed')
    rows = read(OLD / 'WORKSPACE_HASH_INDEX.json')['files']
    require(len(rows) == 195, 'Exact frozen post209195-row index required')
    verify_rows(OLD, rows)


def atomic_json(name, value):
    temp = SAVED / ('.append244-' + name + '.tmp')
    with temp.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        os.fchmod(stream.fileno(), 0o600)
    os.replace(temp, SAVED / name)


def main():
    require(SAVED.is_dir() and not SAVED.is_symlink(), 'Existing post232 saved directory required')
    for name, pin in INITIAL.items():
        require(digest(SAVED / name) == pin, 'Exact through243 metadata required')
    index_before = read(SAVED / 'WORKSPACE_HASH_INDEX.json')
    verify_rows(SAVED, index_before['files'])
    verify_old()
    for name, pin in PINS.items():
        p = Path(name)
        require(safe(p) and regular(p) and digest(p) == pin, 'Exact public input required: ' + name)
    progress = read(SAVED / 'PROGRESS.json')
    manifest = read(SAVED / 'WORKSPACE_RESTORE_MANIFEST.json')
    require(progress['latestClosedScopeIncluded'] == 243 and len(progress['separateModelMilestones']) == 1,
            'Exact separate MODEL243 milestone required')
    primary = copy.deepcopy(progress['primaryCandidate'])
    pour = copy.deepcopy(progress['literalPourCoverageAggregate'])
    require(primary == manifest['primaryCandidate'] and primary['routedOwners'] == 47
            and primary['candidateSha256'] == '71bbec7babdeabda657ba1b2be75d35f5d7210d5a53d55cd2fc2b279ffb0d17b'
            and primary['caMinimumPassingCount'] == 13 and primary['literalPourClearanceQualified'] is True
            and primary['literalPourAggregateSha256'] == 'de4e08e71a5de9503b1050b4e920086e9c2c1ed0211a57d2fed826a1decc6f1f',
            'Preserve exact Source23347 fallback and Source236 scoped-pour pass')
    model = copy.deepcopy(progress['separateModelMilestones'][0])
    require(progress['separateModelMilestones'] == manifest['separateModelMilestones']
            and model['candidate']['sha256'] == PINS[str(CANDIDATE)]
            and model['routedOwners'] == 48 and model['pendingOwnerIds'] == ['source_trace_26']
            and model['criticalCompanionPending'] is True and model['allCriticalApisFreshForModel'] is False,
            'Exact pending model-critical status required')
    closed, execution, report = read(RUN / 'COLLECTED.json'), read(RUN / 'owned/execution.json'), read(REPORT)
    require(closed['scope'] == 244 and closed.get('closedAt') and closed['sourcePinsUnchanged'] is True
            and closed['protectedFilesUnchanged'] is True and closed['all49Accepted'] is False
            and closed['execution'] == execution and execution['exitCode'] == 0
            and execution['diagnosticStopped'] is False and execution['cleanupOwnedGroupEmpty'] is True
            and execution['accepted'] is False and execution['stopReasons'] == [], 'Exact closed clean Root244 runtime')
    command = execution['command']
    require(command[1] == str(WORKER) and command.count('--input') == 1
            and command[command.index('--input') + 1] == str(CANDIDATE)
            and command.count('--input-sha') == 1
            and command[command.index('--input-sha') + 1] == PINS[str(CANDIDATE)], 'Exact public worker/input CLI')
    require(report['scope'] == 'ACTUAL_ROOT_JOINT48_FRESH_CRITICAL6_ALL_FIVE_APIS_BOTH_ACTUAL_DQS1_VIEWS'
            and report['terminalOutcome'] == 'FRESH_CURRENT_CRITICAL6_AND_BOTH_ACTUAL_DQS1_FIVE_API_VIEWS_PASS_NO_BOARD_ACCEPTANCE'
            and report['inputPath'] == str(CANDIDATE) and report['inputSha256'] == PINS[str(CANDIDATE)]
            and report['currentConnectedOwnerCount'] == 48 and report['currentMissingOwners'] == ['source_trace_26']
            and report['criticalProfileQualified'] is True
            and report['currentSceneCriticalAssertionsFreshlyQualified'] is True, 'Exact fresh critical-only pass')
    for key in ('criticalPhysicalReports', 'criticalJoinedNativeGeometryReports'):
        rows = report[key]
        require(len(rows) == 6 and {r['owner'] for r in rows} == CRITICAL
                and all(r['passed'] is True for r in rows), 'All six current critical bodies and joined paths passed')
    views = report['criticalValidationViews']
    require(len(views) == 2 and {v['scope'] for v in views} == {
        'DQS1_LOWER_U_SHARED_VIEW', 'DQS1_EARLY_MEANDER_SHARED_VIEW'}, 'Both actual DQS1 views required')
    for view in views:
        require(view['passed'] is True and view['samePhysicalCriticalCopper'] is True
                and view['c31']['solved'] is True and set(view['reports']) == {'bus', 'pair', 'shared', 'coupling', 'exterior'},
                'Fresh C31 and all five critical report families')
        for rows in view['reports'].values():
            require(len(rows) == 3 and all(r['matched'] is True and r.get('aboveMinimumLength') is not False
                    and r.get('withinLengthLimit') is not False for r in rows), 'All three pairs matched in every critical API')
    require(all(report[k] is False for k in ('all49Accepted', 'fullBoardPassed', 'electricalTimingQualified',
            'timingPassed', 'matched', 'sourcePlacementExecuted', 'nativeExecuted', 'cadExecuted', 'fabricationReady'))
            and report['sourceNativeCadPending'] is True, 'No model Source/native-board/CAD/timing acceptance')
    inverse = report['declaredAtomicSceneInversesVerified']
    require(inverse['entireFoundationEqualityPassed'] is True and inverse['all49RulesLiteral'] is True
            and inverse['literal169CriticalSix'] is True and inverse['all129ActualFixedReferenceViasLiteral'] is True
            and inverse['sourcePlacementExecuted'] is False, 'Critical pass binds exact unchanged declared foundation')
    # The following are recorded whole-planar measurements from the pinned243
    # report. They are not new timing execution or inherited233 CA meanders.
    ca = next(r for r in read(MODEL_REPORT)['originalBusConstraintObservations']
              if r['originalRule']['busId'] == 'DDR_COMMAND_CLOCK')
    rule = ca['originalRule']
    require(rule['minLength'] == 20.95 and rule['maxLength'] == 22.29 and rule['maxLengthSkew'] == .635
            and ca['allMembersPresent'] is True and len(ca['present']) == 26, 'Literal original complete CA observations')
    passing = sorted(r['owner'] for r in ca['present'] if r['wholePlanarLengthMm'] >= rule['minLength'] - 1e-9)
    lengths = [r['wholePlanarLengthMm'] for r in ca['present']]
    require(passing == ['source_trace_33', 'source_trace_34', 'source_trace_46']
            and abs(ca['observedSkewMm'] - 17.43870093419864) < 1e-9
            and abs(max(lengths) - min(lengths) - ca['observedSkewMm']) < 1e-9, 'Actual243 CA minimum3/skew; never233 minimum13')
    # Preserve exact existing metadata before adding any new payload.
    for name, pin in INITIAL.items():
        dest = SAVED / ('HISTORY_THROUGH243_' + name)
        require(not dest.exists(), 'Fresh exact through243 history required')
        with (SAVED / name).open('rb') as reader, dest.open('xb') as writer:
            shutil.copyfileobj(reader, writer, 1024 * 1024)
            os.fchmod(writer.fileno(), stat.S_IMODE((SAVED / name).stat().st_mode))
        require(digest(dest) == pin, 'Exact preserved through243 metadata')
    targets = {r['restorePath']: copy.deepcopy(r) for r in manifest['files']}
    bases = {r['restorePath']: copy.deepcopy(r) for r in manifest['baseDependencyRestoreFiles']}
    catalog = {}
    for folder in (ROOT / '.cloud-tools/ddr-four-layer-manual-2026-10-16', OLD):
        for row in read(folder / 'WORKSPACE_RESTORE_MANIFEST.json')['files']:
            catalog[row['restorePath']] = {'baseSavedDirectory': folder.relative_to(ROOT).as_posix(), **row}
    inputs = {}

    def save(p, name=None, force=False):
        p = Path(p)
        require(safe(p) and regular(p), 'Only public regular source input: ' + str(p))
        before = p.stat()
        data = metadata(p)
        inputs[str(p)] = data
        if str(p) in targets:
            require(data == {k: targets[str(p)][k] for k in data}, 'Existing restore target changed')
            return targets[str(p)]
        old = bases.get(str(p)) or catalog.get(str(p))
        if not force and old and data == {k: old[k] for k in data}:
            bases[str(p)] = copy.deepcopy(old)
            return old
        dest = SAVED / (name or p.name)
        require(dest.parent == SAVED, 'Flat saved filename required')
        if dest.exists() and metadata(dest) != data:
            dest = dest.with_name(dest.stem + '__' + data['sha256'][:16] + dest.suffix)
        if not dest.exists():
            with p.open('rb') as reader, dest.open('xb') as writer:
                shutil.copyfileobj(reader, writer, 1024 * 1024)
                os.fchmod(writer.fileno(), data['mode'])
        require(metadata(dest) == data, 'Saved bytes/mode mismatch')
        after = p.stat()
        require((before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
                (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'Public input changed during copy')
        row = {'savedPath': dest.name, 'restorePath': str(p), **data}
        targets[str(p)] = row
        bases.pop(str(p), None)
        return row

    saved_report = save(REPORT, 'CRITICAL244_MODEL48_byte0-result.json', True)
    saved_closed = save(RUN / 'COLLECTED.json', 'CRITICAL244_MODEL48_COLLECTED.json', True)
    saved_worker = save(WORKER, force=True)
    for filename in ('execution.json', 'child.log', 'memory.jsonl'):
        p = RUN / 'owned' / filename
        require(regular(p), 'Closed runtime evidence required: ' + filename)
        save(p, 'CRITICAL244_MODEL48_owned_' + filename, True)
    # Collect every explicit public CLI file and only public literal source
    # dependencies. Existing targets and known base payloads are deduplicated.
    sources = {WORKER}
    for arg in command[2:]:
        p = Path(arg)
        if safe(p) and regular(p):
            save(p)
            if p.suffix in ('.py', '.ts', '.tsx', '.mjs'):
                sources.add(p)
    for name in PINS:
        save(Path(name))
    save(Path(__file__), force=True)
    visited = set()
    for _ in range(3):
        following = set()
        for p in sorted(sources - visited):
            visited.add(p)
            for literal in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]", p.read_text()):
                q = Path(literal)
                if safe(q) and regular(q):
                    save(q)
                    if q.suffix in ('.py', '.ts', '.tsx', '.mjs'):
                        following.add(q)
        sources |= following
    binding = {'scope': report['scope'], 'closedScope': 244, 'closedAt': closed['closedAt'],
               'candidateSha256': PINS[str(CANDIDATE)], 'report': copy.deepcopy(saved_report),
               'workerSource': copy.deepcopy(saved_worker), 'closure': copy.deepcopy(saved_closed),
               'criticalPhysicalOwners': sorted(CRITICAL), 'criticalPhysicalCount': 6,
               'joinedNativeGeometryCount': 6, 'actualDqs1Views': [v['scope'] for v in views],
               'allFiveCriticalApisInBothViewsPassed': True, 'fullBoardPassed': False,
               'all49Accepted': False, 'fabricationReady': False}
    model.update({'criticalCompanionPending': False, 'allCriticalApisFreshForModel': True,
                  'criticalCompanionQualification': binding,
                  'caPlanarTimingObservations': {
                      'scope': 'PINNED_ROOT243_WHOLE_PLANAR_OBSERVATIONS_NOT_BOARD_TIMING_QUALIFICATION',
                      'report': copy.deepcopy(targets[str(MODEL_REPORT)]),
                      'candidateSha256': PINS[str(CANDIDATE)], 'originalRule': copy.deepcopy(rule),
                      'memberCount': 26, 'minimumPassingCount': 3, 'minimumPassingOwners': passing,
                      'observedSkewMm': ca['observedSkewMm'], 'wholePlanarLengths': copy.deepcopy(ca['present']),
                      'observationsInheritedFrom233': False, 'allTimingPassed': False,
                      'electricalTimingQualified': False}})
    require(model['freshSourceCaptureCorePending'] is True and model['allBoardNativeChecksPending'] is True
            and model['merged233CAGeometryOrTimingPassInherited'] is False and model['source236PourPassInherited'] is False
            and all(model[k] is False for k in ('fullTimingPassed', 'tiQualified', 'cadQualified',
                    'defaultBoardPromoted', 'all49Accepted', 'fabricationReady')), 'All noncritical model boundaries retained')
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    addition = {'scope': 244, 'closedAt': closed['closedAt'], 'terminalOutcome': report['terminalOutcome'],
                'exitCode': 0, 'childRuntimeExecuted': True, 'geometryRoutingExecuted': False,
                'criticalApisExecutedFreshly': True, 'newConnectedOwnerCount': 0,
                'currentConnectedOwnerCount': 48, 'candidateSha256': PINS[str(CANDIDATE)],
                'sourceCoreNativeCadFreshForThisModel': False, 'report': copy.deepcopy(saved_report),
                'all49Accepted': False, 'fabricationReady': False}
    progress['updatedAt'] = manifest['updatedAt'] = now
    progress['scope'] = 'Separate post232 through244; Source23347 fallback with scoped15-pour pass; MODEL24348 fresh critical244 pass'
    progress['latestClosedScopeIncluded'] = 244
    require(not any(r['scope'] == 244 for r in progress['closedExperiments']), '244 must be a new closed append')
    progress['closedExperiments'].append(addition)
    progress['separateModelMilestones'] = [model]
    manifest['separateModelMilestones'] = copy.deepcopy(progress['separateModelMilestones'])
    manifest['files'] = sorted(targets.values(), key=lambda r: r['restorePath'])
    manifest['baseDependencyRestoreFiles'] = sorted(bases.values(), key=lambda r: r['restorePath'])
    progress['publicBaseRestoreDependencies'] = copy.deepcopy(manifest['baseDependencyRestoreFiles'])
    progress['appendCollector'] = str(Path(__file__))
    progress['through243MetadataPins'] = copy.deepcopy(INITIAL)
    require(progress['primaryCandidate'] == manifest['primaryCandidate'] == primary
            and progress['literalPourCoverageAggregate'] == manifest['literalPourCoverageAggregate'] == pour,
            'Source23347 fallback and Source236 scoped pour evidence remain literal')
    for name, data in inputs.items():
        require(metadata(Path(name)) == data, 'Collected public input changed')
    for name, pin in PINS.items():
        require(digest(Path(name)) == pin, 'Pinned public input changed at closure')
    verify_rows(SAVED, [r for r in index_before['files'] if r['path'] not in INITIAL])
    verify_old()
    atomic_json('WORKSPACE_RESTORE_MANIFEST.json', manifest)
    previous_readme = (SAVED / 'README.md').read_text()
    readme = """CURRENT THROUGH244: Source23347 remains the Source-verified fallback with its
Source236 scoped15-pour pass and separate13 CA minimum observations. MODEL243 has48
physical/numeric-joined routes, only26 pending. Its fresh Root244 critical companion
passed all6 physical/joined paths and all5 critical APIs in both actual DQS1 views.
The48 model's own measured CA minimum-pass count is3 (33,34,46), skew17.4387009342mm;
it does not inherit merged233 CA13 geometry/timing or Source236 pour qualification.
Cap12 editable Source/Core, full native-board, model pours, CAD, complete timing,
TI/reference-plane, electrical/default/fabrication qualification remain pending.
Older status paragraphs below are historical; only the critical-companion pending
status is superseded by closed244. Exact four through243 metadata files are saved
as HISTORY_THROUGH243_*. No candidate geometry changed in this append.

""" + previous_readme
    temp = SAVED / '.append244-README.tmp'
    with temp.open('x') as stream:
        stream.write(readme)
        os.fchmod(stream.fileno(), 0o600)
    os.replace(temp, SAVED / 'README.md')
    excluded = {'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
    progress['artifacts'] = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir())
                             if regular(p) and p.name not in excluded]
    atomic_json('PROGRESS.json', progress)
    rows = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir())
            if regular(p) and p.name != 'WORKSPACE_HASH_INDEX.json']
    atomic_json('WORKSPACE_HASH_INDEX.json', {'scope': 'Post232 through244; Source23347 scoped-pour fallback; separate MODEL24348 critical244 pass',
                'updatedAt': now, 'files': rows, 'selfExcluded': True, 'all49Accepted': False, 'fabricationReady': False})
    verify_rows(SAVED, rows)
    for row in manifest['files']:
        require(metadata(SAVED / row['savedPath']) == {k: row[k] for k in ('bytes', 'sha256', 'mode')}
                and metadata(Path(row['restorePath'])) == {k: row[k] for k in ('bytes', 'sha256', 'mode')}, 'Exact restore payload/target required')
    for name, pin in INITIAL.items():
        require(digest(SAVED / ('HISTORY_THROUGH243_' + name)) == pin, 'Through243 history unchanged')
    verify_old()
    print(json.dumps({'savedDirectory': str(SAVED), 'latestClosedScope': 244, 'indexedFiles': len(rows),
          'restoreTargets': len(manifest['files']), 'baseDependencies': len(manifest['baseDependencyRestoreFiles']),
          'sourceVerifiedFallbackOwners': 47, 'modelRoutedOwners': 48, 'modelCritical244Passed': True,
          'modelCaMinimumPassingCount': 3, 'all49Accepted': False, 'fabricationReady': False,
          'metadataHashes': {n: digest(SAVED / n) for n in INITIAL}}, indent=2))


if __name__ == '__main__':
    main()
