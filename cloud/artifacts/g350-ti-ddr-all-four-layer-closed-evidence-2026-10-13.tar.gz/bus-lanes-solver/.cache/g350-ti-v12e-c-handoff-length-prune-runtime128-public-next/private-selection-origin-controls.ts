import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { RouteCandidatePool as A } from "./source/lib/select-route-candidates"
import { RouteCandidatePool as B } from "./source/lib/select-route-candidates.ts"
import { installPrivateSelectionPrimitives } from "./private-selection-primitives"
assert.equal(process.env.G350_PRIVATE_CLASS_ORIGIN_APPROVED,"1")
assert.deepEqual(process.argv.slice(2),["--run-one-approved"])
assert.equal(process.version,"v25.6.1");assert.deepEqual(process.execArgv,[])
assert.equal(A,B);assert.equal(A.prototype,B.prototype)
const before=Object.getOwnPropertyDescriptor(A.prototype,"computeSelection")!
assert.equal(before.enumerable,false);assert.equal(before.writable,true);assert.equal(before.configurable,true)
const rows:string[]=[];const observer=installPrivateSelectionPrimitives(A.prototype,()=>1,(row,rolling)=>{assert.ok(Buffer.byteLength(row)<=128&&Buffer.byteLength(rolling)<=2048);rows.push(row)})
const pool=new B(.1524);assert.equal(pool.select(["origin-only-missing-domain"]),null);assert.equal(observer.snapshot().calls,1);assert.equal(pool.select(["origin-only-missing-domain"]),null);assert.equal(observer.snapshot().calls,1);assert.equal(observer.snapshot().observationErrors,0);assert.equal(observer.restore(),true);assert.deepEqual(Object.getOwnPropertyDescriptor(A.prototype,"computeSelection"),before)
assert.deepEqual(rows.map(row=>JSON.parse(row).p),[0,1])
const result={passed:true,engine:process.version,classConstructorAndPrototypeIdentity:true,actualCopiedPrivateClassReachedByOriginalSelectExactlyOnce:true,cachedSelectAddsNoComputeCall:true,exactDescriptorRestored:true,publicBundleSourceOriginParityStillCheckedByController:true,noGridNoNativeChecker:true,actualBoardRoutingPerformed:false,accepted49:false,fabricationReady:false}
fs.writeFileSync(path.join(process.env.G350_PRIVATE_CLASS_ORIGIN_DIRECTORY!,"class-origin-result.json"),JSON.stringify(result,null,2)+"\n",{flag:"wx"});console.log(JSON.stringify(result))
