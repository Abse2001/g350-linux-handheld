"""ONE delegated routing-disabled fresh source build, physical checks and projection.
No Bus Lanes/Fanout/Grid constructor or signal-routing worker is invoked here.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from validate_v6 import validate

ROOT = Path(__file__).resolve().parent
BOARD = Path('/workspace/g350-linux-handheld')
BUN = str(BOARD / '.cloud-tools/bun/node_modules/bun/bin/bun.exe')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if sys.argv[1:] != ['--one-approved-source-export'] or os.environ.get('G350_TI_V6_EXPORT_APPROVED') != '1':
        raise ValueError('Explicit delegated source-only authorization required')
    raw = (ROOT / 'packet-manifest.json').read_bytes()
    packet = hashlib.sha256(raw).hexdigest()
    manifest = json.loads(raw)
    if os.environ.get('G350_TI_V6_PACKET_SHA') != packet:
        raise ValueError('Exact packet binding required')
    output = ROOT / manifest['freshOutput']
    if not (ROOT / 'run').is_dir() or output.exists() or output.parent.exists() or (ROOT / 'output').exists():
        raise ValueError('Fresh exclusive source/converter output required')
    started = time.time()
    command = manifest['originalCommand']
    print(json.dumps({'phase': 'ONE_PINNED_ROUTING_DISABLED_SOURCE_BUILD', 'command': command,
                      'routingDisabled': True, 'autoroutingPerformed': False}), flush=True)
    completed = subprocess.run(command, cwd=ROOT / 'source',
                               env={**os.environ, 'G350_REPO_ROOT': str(BOARD)}, check=False)
    (ROOT / 'run/source-build-exit.json').write_text(json.dumps({'command': command, 'actualExitCode': completed.returncode,
                                                                'sourceBuildCount': 1, 'routingDisabled': True}, indent=2) + '\n')
    if completed.returncode != 0 or not output.is_file() or output.stat().st_mtime < started:
        raise ValueError('Fresh source build did not successfully complete')
    (ROOT / 'run/fresh-layout.circuit.json').write_bytes(output.read_bytes())
    compiled = json.loads(output.read_bytes())
    base = json.loads((ROOT / 'inputs/base-layout.circuit.json').read_bytes())
    v5 = json.loads((ROOT / 'inputs/v5-layout.circuit.json').read_bytes())
    table = json.loads((ROOT / 'source/lib/am3352/placement/g350-ti-top-bottom-ddr-v5.json').read_bytes())
    report = validate(base, v5, compiled, table, manifest['planeDeclarations'])
    (ROOT / 'run/source-validation.json').write_text(json.dumps(report, indent=2) + '\n')
    source_hash = sha(output)
    tool_exits = []
    commands = [
        ('all17-native-physical', [BUN, str(ROOT / 'check-native-physical.mjs'), str(output), source_hash,
                                   str(ROOT / 'run/native-physical.json')]),
        ('pinned-core-projection', [BUN, str(ROOT / 'capture-v6.ts'), str(BOARD / 'node_modules/@tscircuit/core/dist/index.js'),
                                    str(output), source_hash]),
        ('pure-alternate-input', [sys.executable, '-B', str(ROOT / 'derive-input.py')]),
    ]
    for name, command in commands:
        print(json.dumps({'phase': name, 'command': command, 'signalRoutingPerformed': False}), flush=True)
        completed = subprocess.run(command, cwd=ROOT, check=False)
        tool_exits.append({'name': name, 'command': command, 'actualExitCode': completed.returncode})
        (ROOT / 'run/projection-check-exits.json').write_text(json.dumps(tool_exits, indent=2) + '\n')
        if completed.returncode != 0:
            raise ValueError('Source-only qualification failed: ' + name)
    native = json.loads((ROOT / 'run/native-physical.json').read_bytes())
    derivation = json.loads((ROOT / 'run/input-derivation.json').read_bytes())
    if native['physicalErrors'] != 0 or native['checkCount'] != 17:
        raise ValueError('All17 native physical checks must pass')
    result = {'packetSha256': packet, 'sourceBuildExitCode': 0, 'originalCommand': manifest['originalCommand'],
              'sourceOutput': {'path': str(output), 'bytes': output.stat().st_size, 'sha256': source_hash},
              'copiedFreshOutput': {'path': str(ROOT / 'run/fresh-layout.circuit.json'), 'sha256': sha(ROOT / 'run/fresh-layout.circuit.json')},
              'validation': report, 'nativePhysicalCounts': native['counts'], 'nativePhysicalErrors': 0,
              'inputSha256': derivation['hashes']['input.json'], 'input': str(ROOT / 'run/input.json'),
              'alternateTopMembers': 22, 'alternateBottomMembers': 27,
              'sourceOnlyQualified': True, 'exactOne20umCpu13MoveVerified': True,
              'sourceBuildCount': 1, 'toolExits': tool_exits,
              'autoroutingPerformed': False, 'cadPerformed': False, 'actualBoardDdr49Accepted': False,
              'electricalTimingQualified': False, 'fabricationReady': False}
    (ROOT / 'run/result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'sourceOnlyQualified': True, 'sourceSha256': source_hash,
                      'inputSha256': result['inputSha256'], 'topMembers': 22, 'bottomMembers': 27,
                      'nativePhysicalErrors': 0, 'actualBoardDdr49Accepted': False}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
