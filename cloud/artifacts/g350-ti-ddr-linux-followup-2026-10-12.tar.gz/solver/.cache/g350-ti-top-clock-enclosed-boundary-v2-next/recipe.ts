import { strict as assert } from "node:assert"
import { createHash } from "node:crypto"
import { fixedCopper } from "./source/lib/vector-scene"
import { reserveBusPackageExits } from "./source/lib/reserve-bus-package-exits"
import type { SimpleRouteJson } from "./source/lib/types"

export const fingerprint = (value: unknown) =>
  createHash("sha256").update(JSON.stringify(value)).digest("hex")
const serialized = (value: unknown) => JSON.parse(JSON.stringify(value))

export function validateOriginalReservedRecipe(
  capturedFixed: unknown,
  physical: unknown[],
  reservations: unknown[],
) {
  assert.deepEqual(
    serialized([...physical, ...reservations]),
    capturedFixed,
    "Original fixedCopper plus ORIGINAL reserveBusPackageExits must exactly reproduce captured hard argument",
  )
}

/** Derive the existing original unreserved producer, never filter captured
 * physical objects or guess which blocker is disposable. */
export function buildOriginalUnreservedJob(
  captured: any,
  parent: any,
  post: any,
) {
  assert.equal(post.resultTrustEligible, true)
  assert.equal(parent.captureContractSatisfied, true)
  assert.equal(captured.jobId, 3)
  assert.equal(captured.terminalMethod, "return")
  assert.equal(captured.nextCalls, 6001)
  assert.equal(captured.returnCalls, 1)
  assert.equal(captured.result, null)
  assert.equal(captured.arguments.length, 4)
  const [input, pair, capturedFixed, options] = captured.arguments as [
    SimpleRouteJson,
    any,
    unknown[],
    any,
  ]
  const declaration = parent.captures.find((job: any) => job.jobId === 3)
  assert.equal(fingerprint(captured.arguments), declaration.argumentSha256)
  assert.deepEqual(pair.connectionNames, ["source_trace_33", "source_trace_34"])
  assert.deepEqual(options, {
    copper: [],
    penalty: 0,
    preferPackageOnlyTuning: true,
    allowProvisionalPairTuning: false,
    variant: 0,
  })
  assert.equal(input.connections.length, 49)
  assert.equal(input.obstacles.length, 856)
  assert.deepEqual(input.allowedLayers, ["top", "bottom"])
  assert.equal(input.traces!.length, 6)
  assert.deepEqual(
    input.traces!.slice(0, 2).map((t) => t.source_trace_id),
    ["source_trace_932", "source_trace_933"],
  )
  assert.deepEqual(
    input.traces!.slice(2).map((t) => t.source_trace_id),
    [
      "source_trace_15",
      "source_trace_15",
      "source_trace_16",
      "source_trace_16",
    ],
  )
  const originalPair = input.differentialPairs!.find(
    (p) => p.connectionNames[0] === pair.connectionNames[0],
  )
  assert.ok(originalPair)
  assert.deepEqual(pair, originalPair)
  const physical = fixedCopper(input)
  const reservations = reserveBusPackageExits(input, pair)
  validateOriginalReservedRecipe(capturedFixed, physical, reservations)
  assert.equal(physical.length, 893)
  assert.equal(reservations.length, 13)
  assert.equal(capturedFixed.length, 906)
  assert.ok(reservations.every((c) => c.layer === "top"))
  return {
    input,
    pair,
    physical,
    reservations,
    options,
    originalArguments: captured.arguments,
    unreservedArguments: [input, pair, physical, options] as const,
    originalPhysicalFingerprint: fingerprint(physical),
    reservationFingerprint: fingerprint(reservations),
    capturedArgumentFingerprint: fingerprint(captured.arguments),
  }
}
