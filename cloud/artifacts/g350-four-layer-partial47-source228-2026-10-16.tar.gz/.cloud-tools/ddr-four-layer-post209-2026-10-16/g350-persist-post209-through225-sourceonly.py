#!/usr/bin/env python3
"""Copy closed public post209 evidence, preserving the immutable base archive."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat

ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post209-2026-10-16'
BASE = ROOT / '.cloud-tools/ddr-four-layer-manual-2026-10-16'
BASE_PINS = {
    'WORKSPACE_HASH_INDEX.json': '7d471d7f282e2b50e8a10991a50946b6068d114e4f79d7c0b85ee2d26701e6eb',
    'WORKSPACE_RESTORE_MANIFEST.json': '6937e1bd2512ec77d3c9adc97c45c9d5f8e09d420b613b2ca9151ee683102e3d',
    'PROGRESS.json': '2d255e885f078cef97fc7b698b7a9f71025418fabcd07eca4c64f10d18d6f437',
}
PROTECTED = {
    'AGENTS.md': 'd3086d9ff8887bd296ed0d480fcbef732686bf45e075ae766a0a292518086723',
    'cloud/CONTINUE_BOARD.md': 'bb9a879c5c68c3718d24c82a77326f5b175d47899f101407b1e1ee106c8b19ef',
    'scripts/prepare-g350-ram90-four-layer.mjs': 'ec6b56c59d2c8f72f969934076dd3597014833e8b2e8e4387c1045f03eaadda0',
    'scripts/tune-g350-ram90-native-lengths.mjs': '5bfe731744159cf9f65ddde71b513cb1a0d2384574e740cd11bc087ce69b4b40',
}
PRIMARY_SHA = 'ddaa4efd8d20f16cefca89b9166e834a956113194beed6f0f13903e346e36ea0'

def drop(fd):
    os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)

def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
        drop(f.fileno())
    return h.hexdigest()

def read(p):
    with p.open('rb') as f:
        value = json.load(f); drop(f.fileno())
    return value

def write(p, value):
    temporary = p.with_name(p.name + '.next225')
    with temporary.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n')
    os.replace(temporary, p)

def safe_public(path):
    return str(path).startswith('/tmp/g350-') and not any(
        part.upper().startswith(('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT'))
        for part in path.parts)

def main():
    for name, digest in BASE_PINS.items():
        assert sha(BASE / name) == digest
    for name, digest in PROTECTED.items():
        assert sha(ROOT / name) == digest
    SAVED.mkdir(parents=True, exist_ok=True)
    assert not (SAVED / 'WORKSPACE_RESTORE_MANIFEST.json').exists(), 'Use a separate successor collector for later additions'
    targets, payloads = {}, {}
    observations, static_dependencies, omitted_private_names = [], set(), []
    def save(source, name=None):
        source = Path(source)
        assert safe_public(source), str(source)
        assert source.is_file() and not source.is_symlink(), str(source)
        digest, mode = sha(source), stat.S_IMODE(source.stat().st_mode)
        if str(source) in targets:
            old = targets[str(source)]
            assert old['sha256'] == digest and old['bytes'] == source.stat().st_size and old['mode'] == mode
            return old
        dest = SAVED / (name or source.name)
        if dest.exists() and sha(dest) != digest:
            dest = dest.with_name(dest.stem + '__' + digest[:16] + dest.suffix)
        if not dest.exists():
            with source.open('rb') as a, dest.open('xb') as b:
                shutil.copyfileobj(a, b, 1024 * 1024); os.fchmod(b.fileno(), mode); drop(a.fileno())
        assert sha(dest) == digest and stat.S_IMODE(dest.stat().st_mode) == mode
        row = {'savedPath': dest.relative_to(SAVED).as_posix(), 'restorePath': str(source),
               'bytes': source.stat().st_size, 'sha256': digest, 'mode': mode}
        targets[str(source)] = row
        payloads[row['savedPath']] = row
        return row

    labels = {
        215: 'MANUAL_D5_215_ALTERNATE46', 216: 'CA_POCKET216_PARSE_FAILURE',
        217: 'POWER_SLOT217_PREFLIGHT_FAILURE', 218: 'CA_POCKET218_NO_IMPROVEMENT',
        219: 'POWER_SLOT219_QUALIFIED_BRANCH46', 220: 'POWER_SLOT_D7_220',
        221: 'MANUAL_D15_221', 222: 'COMBINED_POWER_RAM_CPU222',
        223: 'MANUAL223_PARTIAL47', 224: 'PROJECTOR224_PARTIAL47', 225: 'CRITICAL225_PARTIAL47',
    }
    worker_paths = set()
    for scope, label in labels.items():
        folder = next(Path('/tmp').glob('g350-*-root-20261016-run' + str(scope)))
        collection = read(folder / 'COLLECTED.json')
        assert collection.get('closedAt') and collection['scope'] == scope
        save(folder / 'COLLECTED.json', label + '_COLLECTED.json')
        execution = collection.get('execution')
        command = execution.get('command', []) if execution else []
        for p in sorted(folder.glob('byte0-result*.json')):
            save(p, label + '_' + p.name)
        for name in ('child.log', 'execution.json', 'memory.jsonl'):
            p = folder / 'owned' / name
            if p.is_file():
                save(p, label + '_owned_' + name)
        if command:
            worker = Path(command[1]); save(worker); worker_paths.add(worker)
            for i, value in enumerate(command[2:], 2):
                if value.startswith('/tmp/g350-'):
                    p = Path(value)
                    if p.is_file():
                        save(p, 'INPUT_' + label + '_' + p.parent.name + '_' + p.name)
                        if i > 0 and command[i - 1] in ('--input', '--constructor'):
                            for sibling in ('proof.json', 'contacts.json'):
                                q = p.parent / sibling
                                if q.is_file():
                                    save(q, 'INPUT_' + label + '_' + q.parent.name + '_' + q.name)
        report_path = folder / 'byte0-result.json'
        report = read(report_path) if report_path.exists() else {}
        observations.append({'scope': scope, 'label': label, 'closedAt': collection['closedAt'],
            'executionOccurred': execution is not None, 'exitCode': execution.get('exitCode') if execution else None,
            'reportProduced': report_path.exists(), 'candidateProduced': (folder / 'byte0-result.candidate.json').exists(),
            'reportedConnectedCount': report.get('connectedAll49Count', report.get('currentConnectedOwnerCount')),
            'reportedRemaining': report.get('remaining', report.get('currentMissingOwners')),
            'reportedTerminalOutcome': report.get('terminalOutcome'),
            'primaryPost209Milestone': scope == 223, 'defaultBoardPromoted': False, 'all49Accepted': False})

    # Public source-only plans/profiles needed by the new explicit reference branch.
    for name in (
        'g350-route-bounded-explicit-input-root-20261016.py', 'g350-route-bounded-root-20261016.py',
        'g350-common210-reference-overlay-dynamic-constructor-sourceonly.py',
        'g350-current210-power120-ddr32-reference-overlay-planning-builder-sourceonly.py',
        'g350-current210-power-slot-root-planning216.json',
        'g350-current210-power120-ddr32-slot-exchange-screen-report.json',
        'g350-persist-post209-through225-sourceonly.py',
    ):
        p = Path('/tmp') / name
        save(p)
        if p.suffix in ('.py', '.ts', '.mjs'):
            worker_paths.add(p)
    assert sha(Path('/tmp/g350-route-bounded-explicit-input-root-20261016.py')) == '983731eb66bbb42e3c1b8ba3cd24766df1a50aee2b4dc5a4ac2f99f8d54c4f6b'
    assert sha(Path('/tmp/g350-route-bounded-root-20261016.py')) == 'c1bde8bf9dd1dd81b1651183c07c2e088263aa75c6acfaf06cd9f377f8d2e144'
    visited = set()
    for depth in range(3):
        next_sources = set()
        for source in sorted(worker_paths - visited):
            visited.add(source)
            with source.open('r') as f:
                text = f.read(); drop(f.fileno())
            for literal in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]", text):
                p = Path(literal)
                if not safe_public(p):
                    omitted_private_names.append(str(p)); continue
                if p.is_file() and not p.is_symlink():
                    save(p); static_dependencies.add(str(p))
                    if p.suffix in ('.py', '.ts', '.mjs', '.tsx', '.sh'):
                        next_sources.add(p)
        worker_paths |= next_sources
    assert sha(Path('/tmp/g350-deterministic-manual47-root-20261016-run223/byte0-result.candidate.json')) == PRIMARY_SHA
    report223 = read(Path('/tmp/g350-deterministic-manual47-root-20261016-run223/byte0-result.json'))
    critical225 = read(Path('/tmp/g350-manual47-critical-root-20261016-run225/byte0-result.json'))
    assert report223['connectedAll49Count'] == 47 and report223['allSavedCarriersCurrentSceneQualified']
    assert critical225['inputSha256'] == PRIMARY_SHA and critical225['currentConnectedOwnerCount'] == 47
    assert critical225['criticalProfileQualified'] and critical225['currentSceneCriticalAssertionsFreshlyQualified']
    assert set(critical225['currentMissingOwners']) == {'source_trace_26', 'source_trace_30'}
    base_dependency = {'path': 'cloud/artifacts/g350-four-layer-partial46-source209-2026-10-16.tar.gz',
        'sha256': 'c4cfe7d590a67368586ef49a6178dbc6b6519576a654a690d8f5ef91be0b9178', 'bytes': 31488547,
        'manifest': 'cloud/artifacts/g350-four-layer-partial46-source209-2026-10-16.manifest.json',
        'manifestSha256': sha(ROOT / 'cloud/artifacts/g350-four-layer-partial46-source209-2026-10-16.manifest.json'),
        'mustBeRestoredFirst': True, 'includesPriorSource32RestorePrerequisite': False,
        'originalBaseSavedMetadataPins': BASE_PINS}
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    primary = {'savedPath': targets[str(Path('/tmp/g350-deterministic-manual47-root-20261016-run223/byte0-result.candidate.json'))]['savedPath'],
        'sha256': PRIMARY_SHA, 'connected': 47, 'pendingOwners': [26, 30],
        'all47CurrentScenePhysicalQualified': True, 'freshCritical225BothDqs1ViewsPassed': True,
        'projector224Passed': True, 'freshSourceCorePending': True, 'freshBoardNativePending': True,
        'ordinaryMatchingPassed': False, 'defaultBoardPromoted': False, 'all49Accepted': False, 'fabricationReady': False}
    manifest = {'scope': 'Post209 experimental partial routing workspace; no default-board promotion',
        'updatedAt': now, 'solverSourceRoot': '/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib',
        'baseArchiveDependency': base_dependency, 'primaryCandidate': primary,
        'files': sorted(targets.values(), key=lambda row: row['restorePath']),
        'all49Accepted': False, 'fabricationReady': False}
    progress = {'scope': 'Separate post209 experiments; immutable Source209 archive is unchanged',
        'updatedAt': now, 'latestClosedScopeIncluded': 225, 'live226Excluded': True,
        'baseArchiveDependency': base_dependency, 'primaryCandidate': primary,
        'acceptedDefaultBoardConnected': 32, 'latestVerifiedSourceBoardConnected': 46,
        'currentPhysicalMilestoneConnected': 47, 'pendingOwners': {'source_trace_26': 'DDR_D12', 'source_trace_30': 'DDR_DQM0'},
        'closedExperiments': observations, 'staticPublicDependenciesSaved': sorted(static_dependencies),
        'privateAuthorityAndContextBodiesExcluded': True, 'privateNamedLiteralsNotCopied': omitted_private_names,
        'currentRunner': {'explicitSource': 'g350-route-bounded-explicit-input-root-20261016.py',
            'explicitSha256': '983731eb66bbb42e3c1b8ba3cd24766df1a50aee2b4dc5a4ac2f99f8d54c4f6b',
            'normalSource': 'g350-route-bounded-root-20261016.py',
            'normalSha256': 'c1bde8bf9dd1dd81b1651183c07c2e088263aa75c6acfaf06cd9f377f8d2e144',
            'explicitModeRequiredForExactCallerInput': True, 'sourceExecutedByCollector': False},
        'freshSourceCorePending': True, 'freshBoardNativePending': True,
        'ordinaryTimingPassed': False, 'electricalTimingQualified': False, 'referenceQualified': False,
        'cadQualified': False, 'all49Accepted': False, 'fabricationReady': False, 'archiveCreated': False}
    write(SAVED / 'WORKSPACE_RESTORE_MANIFEST.json', manifest)
    write(SAVED / 'PROGRESS.json', progress)
    readme = ('Separate post209 routing evidence, through closed225.\n\n'
        'Primary223 has47/49 current-scene physical paths; fresh225 critical6 and allfive\n'
        'report APIs pass in both actual DQS1 views. Projector224 passes. D12/source26 and\n'
        'DQM0/source30 remain pending. Fresh Source/Core and board-native checks are pending.\n'
        'Original matching/electrical/reference/CAD/fabrication qualification remains false.\n'
        'The accepted default board remains32; the last fully checked partial Source is20946.\n\n'
        'Restore prior Source32 prerequisites and immutable Source209 archive first, as\n'
        'documented in cloud/DDR_FOUR_LAYER_MANUAL_ROUTING_2026-10-16.md. Then run:\n\n'
        'python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post209-2026-10-16 --restore\n'
        'python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post209-2026-10-16\n\n'
        'The existing helper verifies local saved hashes/modes and refuses differing targets;\n'
        'it does not interpret the extra baseArchiveDependency metadata, so restore order\n'
        'is a caller precondition. No SDK is executed by this collector or restoration.\n'
        'Closed failures216/217 are retained with their logs and no invented qualification.\n'
        'The qualified reference-overlay219 is a separate branch; it does not alter223.\n'
        'Live226 is excluded. No archive, commit or push is performed.\n')
    with (SAVED / 'README.md').open('x') as f:
        f.write(readme)
    artifacts = []
    excluded = {'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
    for p in sorted(SAVED.rglob('*')):
        if p.is_file() and not p.is_symlink() and p.relative_to(SAVED).as_posix() not in excluded:
            artifacts.append({'path': p.relative_to(SAVED).as_posix(), 'bytes': p.stat().st_size,
                              'sha256': sha(p), 'mode': stat.S_IMODE(p.stat().st_mode)})
    progress['artifacts'] = artifacts; write(SAVED / 'PROGRESS.json', progress)
    rows = artifacts + [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p),
                         'mode': stat.S_IMODE(p.stat().st_mode)} for p in (SAVED / 'PROGRESS.json', SAVED / 'WORKSPACE_RESTORE_MANIFEST.json')]
    write(SAVED / 'WORKSPACE_HASH_INDEX.json', {'scope': 'Separate post209 saved evidence; no board acceptance',
        'updatedAt': now, 'files': sorted(rows, key=lambda row: row['path']), 'selfExcluded': True,
        'all49Accepted': False, 'fabricationReady': False})
    for name, digest in BASE_PINS.items():
        assert sha(BASE / name) == digest
    for name, digest in PROTECTED.items():
        assert sha(ROOT / name) == digest
    print(json.dumps({'restoreTargets': len(targets), 'indexedFiles': len(rows), 'latestClosedIncluded': 225,
        'primaryConnected': 47, 'missing': [26, 30], 'live226Excluded': True,
        'oldFrozenBaseUnchanged': True, 'protectedFourUnchanged': True,
        'sdkExecuted': False, 'archiveCreated': False, 'all49Accepted': False, 'fabricationReady': False}))

if __name__ == '__main__':
    main()
