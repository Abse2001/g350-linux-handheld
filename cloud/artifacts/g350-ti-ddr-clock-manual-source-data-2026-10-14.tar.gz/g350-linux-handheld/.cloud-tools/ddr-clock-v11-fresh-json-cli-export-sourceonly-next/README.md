The pinned CLI0.1.2258 supports exporting an already-rendered fresh Circuit JSON
array directly. Its isCircuitJsonFile function recognizes .circuit.json or
/circuit.json; exportSnippet parses that file directly and sends the array to
CircuitJsonToKicadPcbConverter. It bypasses the Source generation/Core path.
The actual41840 file is named raw-core.json, so the worker makes an exclusive
byte-identical copy named fresh-core.circuit.json. It does not edit geometry,
IDs, net labels, layer ports or the original raw/control files.

The proposed command is the actual installed pinned main module:

    PINNED_BUN --smol PINNED_CLI_MAIN export fresh-core.circuit.json \
      --format kicad_pcb --output clock-v11.kicad_pcb --disable-parts-engine

The worker accepts only the actual successfully collected Native/API result
for the prepared fresh225/263 Core, with its real raw/control hashes. A future
Root authority and owned serial process guard are mandatory. No app/Core/CLI
or KiCad invocation occurred during this authoring. Root still must bind full
Ce3/47633 inventories before and after the stage, check all previous owned
process groups are empty, and collect its actual tool outcome. A policy proposal
is90s/2GiB, shared30GiB plus1GiB reserve; no new measured CLI result is claimed.

Plain tsci export of the Source module is not claimed. Its default export
returns a tree, while the fresh direct Core renderer registered four actual
Inner1 ports through the public hook before rendering. The standard CLI Source
loader is not known to call that hook. The JSON path needs no hook: the freshly
rendered raw array already contains the actual layer ports and complete paths.
The manual Source fork also cannot be routed with automatic Core SRJ; original
all49 differential/coupling declarations remain in the immutable input.

CLI export is not KiCad connectivity or serializer/checker qualification.
Future KiCad10 checks must operate on this newly exported file, prove the actual
numeric CPU/RAM clocks and all original local contacts/barrels, and retain
negative/all-rule findings without editing frozen KiCad10 evidence. All49 DDR,
full-board timing/reference/electrical release remain unfinished.
fabricationReady=false.
