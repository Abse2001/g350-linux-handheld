"""Finite Source-only overlap graph binding candidate rectangles to real GND annuli/circle pads."""
import json,math,hashlib
from pathlib import Path
HERE=Path(__file__).parent
report=json.loads((HERE/'REFERENCE_LAYOUT_AND_SHADOW_REPORT.json').read_bytes());supp=json.loads((HERE/'CLEAR_GND_RIBBON_PIECES_AND_FIXED_OWNER_SUPPLEMENT.json').read_bytes());context=json.loads(Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-plus96-signals-combined-sourceonly-next/native-context.json').read_bytes());raw=json.loads(Path(context['corePath']).read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(HERE/'REFERENCE_LAYOUT_AND_SHADOW_REPORT.json')=='0620c69b581cf55889f7e52a13b83c10d239d4e97e849e1676096d9f46710731'
assert sha(HERE/'CLEAR_GND_RIBBON_PIECES_AND_FIXED_OWNER_SUPPLEMENT.json')=='e0bde2d83468268eb717ed4a6986c80d9350aa860b3cd6e5db092f015695c13d'
assert sha(Path(context['corePath']))==context['coreSha256']
lookup={}
for r in raw:
 if r['type']in ['source_net','source_port','pcb_port','source_component']:lookup.setdefault(r['type'],{})[r[r['type']+'_id']]=r
net=lookup['source_net']['source_net_0'];assert net['name']=='GND'
def xy(p):return(p['x'],p['y'])
def dot(p,q):return p[0]*q[0]+p[1]*q[1]
def vec(a,b):return(b[0]-a[0],b[1]-a[1])
def segmentdist(p,a,b):
 d=vec(a,b);den=dot(d,d);t=max(0,min(1,dot(vec(a,p),d)/den)) if den else 0
 return math.dist(p,(a[0]+t*d[0],a[1]+t*d[1]))
def distance_range(p,poly):
 cross=[vec(a,b)[0]*vec(a,p)[1]-vec(a,b)[1]*vec(a,p)[0] for a,b in zip(poly,poly[1:]+poly[:1])]
 inside=all(x>=0 for x in cross) or all(x<=0 for x in cross)
 return (0 if inside else min(segmentdist(p,a,b) for a,b in zip(poly,poly[1:]+poly[:1])),max(math.dist(p,x) for x in poly))
def overlap(a,b):
 for poly in [a,b]:
  for p,q in zip(poly,poly[1:]+poly[:1]):
   edge=vec(p,q);axis=(-edge[1],edge[0]);aa=[dot(x,axis) for x in a];bb=[dot(x,axis) for x in b]
   if min(max(aa),max(bb))-max(min(aa),min(bb))<=1e-12:return False
 return True
pieces=supp['candidateRectangles'];polys=[[xy(p) for p in row['outline']]for row in pieces];vias=[v for v in context['referenceVias'] if v['source_net_id']=='source_net_0'];circles=[]
for land in context['allOriginalCopperLands']:
 if land['shape']!='circle':continue
 port=lookup['pcb_port'][land['pcb_port_id']];sp=lookup['source_port'][port['source_port_id']]
 if sp.get('subcircuit_connectivity_map_key')==net['subcircuit_connectivity_map_key']:
  circles.append({'sourceLandId':land['pcb_smtpad_id'],'pcbPortId':port['pcb_port_id'],'sourcePortId':sp['source_port_id'],'ownerName':lookup['source_component'][sp['source_component_id']]['name'],'numericPin':sp['pin_number'],'x':land['x'],'y':land['y'],'radius':land['radius'],'layer':land['layer']})
parent=list(range(len(pieces)))
def find(i):
 while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
 return i
def union(a,b):parent[find(a)]=find(b)
for i in range(len(pieces)):
 for j in range(i):
  if pieces[i]['patchLayer']==pieces[j]['patchLayer'] and overlap(polys[i],polys[j]):union(i,j)
viaedges={};bindings=[]
for i,(row,poly) in enumerate(zip(pieces,polys)):
 va=[];pa=[]
 for v in vias:
  lo,hi=distance_range((v['x'],v['y']),poly)
  if lo<v['outer_diameter']/2-1e-12 and hi>v['hole_diameter']/2+1e-12:
   va.append(v['pcb_via_id']);viaedges.setdefault(v['pcb_via_id'],[]).append(i)
 for c in circles:
  if c['layer']==row['patchLayer'] and distance_range((c['x'],c['y']),poly)[0]<c['radius']-1e-12:pa.append(c)
 bindings.append({'pieceIndex':i,'targetSourceTraceId':row['targetSourceTraceId'],'patchLayer':row['patchLayer'],'intersectingAuthenticGroundAnnulusIds':va,'intersectingAuthenticNumericGroundCircleLands':pa})
for ids in viaedges.values():
 for i in ids[1:]:union(ids[0],i)
groups={}
for i in range(len(pieces)):groups.setdefault(find(i),[]).append(i)
components=[]
for idx,ids in enumerate(groups.values()):
 components.append({'candidateComponentIndex':idx,'pieceIndices':ids,'layers':sorted({pieces[i]['patchLayer'] for i in ids}),'targetSourceTraceIds':sorted({pieces[i]['targetSourceTraceId']for i in ids}),'actualGroundAnnulusIds':sorted({x for i in ids for x in bindings[i]['intersectingAuthenticGroundAnnulusIds']}),'numericGroundCircleLands':[x for i in ids for x in bindings[i]['intersectingAuthenticNumericGroundCircleLands']],'hasGeometricAuthenticGroundContact':any(bindings[i]['intersectingAuthenticGroundAnnulusIds']or bindings[i]['intersectingAuthenticNumericGroundCircleLands']for i in ids),'actualFillConnectivityQualified':False})
result={'scope':'FINITE_SOURCEONLY_CLEAR_RIBBON_OVERLAP_AND_AUTHENTIC_GROUND_ANNULUS_BINDING','reportSha256':sha(HERE/'REFERENCE_LAYOUT_AND_SHADOW_REPORT.json'),'supplementSha256':sha(HERE/'CLEAR_GND_RIBBON_PIECES_AND_FIXED_OWNER_SUPPLEMENT.json'),'candidatePieceBindings':bindings,'candidateConnectedComponents':components,'candidateComponentCount':len(components),'candidateGroundContactComponentCount':sum(c['hasGeometricAuthenticGroundContact']for c in components),'authenticGroundViaIdsUsed':sorted(viaedges),'annulusCheckIncludesActualDrillVoid':True,'sourceOwnerNetId':'source_net_0','sourceOwnerName':'GND','notes':['Positive-area convex rectangle overlap is derived only for separately foreign-copper-clear candidate pieces. Existing Groundfullspan annular metal intersects pieces outside actual drillvoids.','Groundnumericcircle pads are bound to the exact Core original numeric pin/sourceport/GNDconnectivity key. Noncircle Groundlands are omitted rather than approximated as binding evidence.','This geometry is not actualfilled/native/CAD connectivity, nor an RF returnproof. Groundcontact pieces do not close missing carrier intervals or validate transitions.','Pieces onInner2 require a separate Sourcepowerplane cutout/continuity fork; no currentpowerowner changes here.'],'nativeCalls':0,'cadCalls':0,'actualAppImports':0,'referenceQualified':False,'electricalTimingQualified':False,'accepted49':False,'fabricationReady':False}
f=HERE/'CANDIDATE_GROUND_ANNULUS_BINDINGS.json'
with f.open('x')as out:json.dump(result,out,indent=2);out.write('\n')
f.chmod(0o600)
print(json.dumps({'sha256':sha(f),'candidateComponents':len(components),'groundContactComponents':result['candidateGroundContactComponentCount'],'groundViaIds':result['authenticGroundViaIdsUsed']}))
