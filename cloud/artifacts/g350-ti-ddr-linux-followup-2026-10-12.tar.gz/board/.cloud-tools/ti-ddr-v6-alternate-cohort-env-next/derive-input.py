"""Pure source-derived V6 native input and alternate bus cohort; no router."""
from pathlib import Path
import copy
import hashlib
import json

ROOT = Path(__file__).resolve().parent
new_raw = (ROOT / 'output/ddr-input.json').read_bytes()
data = json.loads(new_raw)
old = json.loads((ROOT / 'inputs/v5-core-ddr-input.json').read_bytes())
assert set(data) == set(old)
assert len(data['connections']) == 49 and len(data['obstacles']) == 856 and len(data['traces']) == 2
for key in data:
    if key != 'obstacles':
        assert data[key] == old[key], 'Changed original Core/native field: ' + key
changes = []
for before, after in zip(old['obstacles'], data['obstacles']):
    if before == after:
        continue
    assert before.get('circuitJsonMetadata', {}).get('source_component_name') == 'C_DDR_CPU_13'
    assert after.get('circuitJsonMetadata', {}).get('source_component_name') == 'C_DDR_CPU_13'
    normalized = copy.deepcopy(after)
    normalized['center'] = before['center']
    assert normalized == before
    assert abs(after['center']['x'] - before['center']['x'] - .02) < 1e-9
    assert after['center']['y'] == before['center']['y'] == 16.8
    changes.append({'pad': before['circuitJsonMetadata']['pcb_smtpad_id'],
                    'before': before['center'], 'after': after['center']})
assert len(changes) == 2
for bus in data['buses']:
    if bus['busId'] in ['DDR_BYTE0', 'DDR_BYTE1']:
        bus['maxLength'] = 14.4
    elif bus['busId'] == 'DDR_COMMAND_CLOCK':
        bus.update(minLength=22.35, maxLength=24.89)
unrestricted = copy.deepcopy(data)
old_bounded = json.loads((ROOT / 'inputs/v5-bounded-unrestricted-input.json').read_bytes())
normalized = copy.deepcopy(data)
for a, b in zip(normalized['obstacles'], old_bounded['obstacles']):
    if a != b:
        a['center'] = b['center']
assert normalized == old_bounded, 'V6 unconstrained data changed beyond exact CPU13 pad move'
classes = {'DDR_RESET': 'bottom', 'DDR_BYTE0': 'top', 'DDR_BYTE1': 'top', 'DDR_COMMAND_CLOCK': 'bottom'}
policy = []
for bus in data['buses']:
    layer = classes[bus['busId']]
    bus['allowedLayers'] = [layer]
    bus['preferredLayers'] = [layer]
    policy.append({'busId': bus['busId'], 'members': len(bus['connectionNames']), 'layer': layer})
assert sum(p['members'] for p in policy if p['layer'] == 'top') == 22
assert sum(p['members'] for p in policy if p['layer'] == 'bottom') == 27
assert len(set(c['name'] for c in data['connections'])) == 49
hashes = {}
for name, value in [('original-unrestricted-input.json', unrestricted), ('input.json', data)]:
    raw = (json.dumps(value, indent=2) + '\n').encode()
    (ROOT / 'run' / name).write_bytes(raw)
    hashes[name] = hashlib.sha256(raw).hexdigest()
report = {'scope': 'Pure fresh pinned Core projection plus alternate per-bus layer policy',
          'coreInputSha256': hashlib.sha256(new_raw).hexdigest(), 'hashes': hashes,
          'connections': 49, 'obstacles': 856, 'originalPads': 854, 'referenceViaObstacles': 2,
          'fixedReferences': 2, 'cpu13PadChangesOnly': changes,
          'connectionsAndCpuRamEndpointsExact': True, 'allOtherPadGeometryAndOwnersExact': True,
          'fixedReferenceGeometryAndOwnersExact': True,
          'classPolicy': policy, 'topMembers': 22, 'bottomMembers': 27,
          'byteMaximumTotalPlanarMm': 14.4, 'commandTotalPlanarRangeMm': [22.35, 24.89],
          'busSkewMm': .635, 'pairSkewMm': .127,
          'nominalViaCountTargets': {'bytes': 0, 'command': 2, 'status': 'Design intent; actual output qualification pending'},
          'sourceInitializerCalled': False, 'signalRoutingPerformed': False, 'accepted49': False,
          'referenceContinuityQualified': False, 'fabricationReady': False}
(ROOT / 'run/input-derivation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'derivedInputSha256': hashes['input.json'], 'topMembers': 22, 'bottomMembers': 27,
                  'cpu13PadChanges': len(changes), 'initializerCalls': 0, 'accepted49': False}))
