/** SOURCE ONLY v3: partial compact mixed-carrier literal route replay.
 * No Core construction, files, SDK execution, raw IDs, routing or adoption.
 * Root binds parent/candidate/plan/audit bytes and owns capture/Core execution.
 * Routed owners get real paths. Pending owners keep empty logical pcbPaths
 * and their exact owned approaches as separate real local traces/barrels.
 */
// Runtime and declaration paths are explicit: this file lives outside a project.
// @ts-ignore Exact managed runtime; matching declarations are imported separately.
import ReactRuntime from "/workspace/g350-linux-handheld/node_modules/react/index.js"
import type * as ReactTypes from "/workspace/g350-linux-handheld/node_modules/@types/react/index"
const { Children, Fragment, cloneElement, createElement, isValidElement }: typeof ReactTypes = ReactRuntime
type ReactNode = ReactTypes.ReactNode
type ReactElement<P> = ReactTypes.ReactElement<P>

type Row = Record<string, any>
type Props = Record<string, any> & { children?: ReactNode }
export interface LiteralSnapshot {
  kind: "literal" | "fragment" | "primitive" | "unsupported"
  type: string
  key: string | null
  props: Props
  children: LiteralSnapshot[]
  value?: unknown
}
export interface All49ReplayPlan extends Row {
  replacedOriginals: Array<{ originalSourceTraceId: string; logicalName: string;
    fromSelector: string; toSelector: string; afterRouteProps: {
      pcbPaths: Array<Array<string | { x: number; y: number }>>; pcbPathRelativeTo: string } }>
  removeLocalTraceNames: string[]
  removeViaNames: string[]
  newVias: Array<Row & { name: string; x: number; y: number; innerLayers: string[] }>
  innerPortRegistrations: Array<Row & { viaName: string; layer: string; xy: { x: number; y: number } }>
  /** Root augments the pure joined-route projector plan with these parent data. */
  retainedInnerPortRegistrations: Array<Row & { viaName: string; layer: string; xy?: Row; viaXY?: Row }>
  all49OriginalLogicalTraces: Array<{ originalSourceTraceId: string; name: string; from: string; to: string }>
  sourceRuleIntersections: Array<{ busName: string; after: Row }>
  parentCapturePin: unknown
  manufacturerAuditPin: unknown
  partialLayerProfile: "compact-four-layer-partial"
  routedOwnerIds: string[]
  pendingOwnerIds: string[]
  routedOriginals: All49ReplayPlan["replacedOriginals"]
  pendingOriginals: All49ReplayPlan["replacedOriginals"]
  auxiliaryLocalTraces: Array<Row & { name: string; owner: string; originalSourceTraceId: string;
    branchId: string; side: number; fromSelector: string; toSelector: string;
    thicknessMm: .1016; layer: "top"; absolutePoints: Array<{ x: number; y: number }>;
    relativeAnchorSelector: string; relativeAnchorXY: { x: number; y: number };
    afterRouteProps: { pcbPaths: Array<Array<string | { x: number; y: number }>>; pcbPathRelativeTo: string } }>
  pendingApproachSources: All49ReplayPlan["auxiliaryLocalTraces"]
  pendingOwnerApproaches: Array<Row & { owner: string; originalSourceTraceId: string; branchId: string;
    side: number; originalBranch: Row; auxiliaryTraceNames: string[]; viaNames: string[] }>
  inputBindings: Row & { candidate: { path: string; sha256: string } }
}
interface PropertyEdit { name: string; type: string; beforeProps: Props; afterProps: Props }
interface RemovedNode { parentPath: number[]; childIndex: number; row: LiteralSnapshot }
export interface ReplayAuditPlan {
  scope: string
  propertyEdits: PropertyEdit[]
  removedNodes: RemovedNode[]
  addedViaNames: string[]
  addedAuxiliaryTraceNames: string[]
  effectiveConstraintBridge: Row
  expectedCounts: Row
  parentCapturePin: unknown
  parentKeyNormalizations: Array<{ path: number[]; before: string | null; after: string | null }>
  rawCircuitIdsAssigned: false
  full49Accepted: false
  fabricationReady: false
}
const IDS = Array.from({ length: 49 }, (_, i) => i)
const OWNERS = IDS.map(n => `source_trace_${n}`)
const LAYERS = ["top", "inner1", "inner2", "bottom"]
const ROUTE_KEYS = ["pcbPath", "pcbPaths", "pcbPathRelativeTo"]
const check = (value: unknown, message: string): void => { if (!value) throw new Error(message) }
const mm = (v: unknown): number => typeof v === "number" && Number.isFinite(v) ? v
  : typeof v === "string" && /^-?\d+(?:\.\d+)?mm$/.test(v) ? Number(v.slice(0, -2)) : NaN
const canonical = (v: unknown): string => Array.isArray(v) ? `[${v.map(canonical).join(",")}]`
  : v && typeof v === "object" ? `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical((v as Row)[k])}`).join(",")}}`
  : typeof v === "function" ? `function:${v.toString()}` : typeof v === "symbol" ? `symbol:${String(v)}` : JSON.stringify(v) ?? "undefined"
const same = (a: unknown, b: unknown): boolean => canonical(a) === canonical(b)
const sameSet = (a: string[], b: string[]): boolean => a.length === b.length
  && new Set(a).size === a.length && a.every(n => b.includes(n))
const flatten = (r: LiteralSnapshot): LiteralSnapshot[] => [r, ...r.children.flatMap(flatten)]
const cloneSnapshot = (r: LiteralSnapshot): LiteralSnapshot => ({ ...r, props: { ...r.props }, children: r.children.map(cloneSnapshot) })

/** Same literal/Fragment snapshot conventions as the genuine Source33B capture. */
export function snapshotAll49ReplaySource(node: ReactNode): LiteralSnapshot {
  if (!isValidElement<Props>(node)) return { kind: node === null || node === undefined
    || ["boolean", "string", "number"].includes(typeof node) ? "primitive" : "unsupported",
    type: typeof node, key: null, value: node, props: {}, children: [] }
  const { children, ...props } = node.props
  const actualType: unknown = node.type
  const kind = typeof actualType === "string" ? "literal" : actualType === Fragment ? "fragment" : "unsupported"
  return { kind, type: kind === "literal" ? actualType as string : kind === "fragment" ? "React.Fragment" : String(actualType),
    key: node.key, props, children: Children.toArray(children).map(snapshotAll49ReplaySource) }
}
function identity(node: ReactNode): ReactNode {
  if (!isValidElement<Props>(node)) return node
  return cloneElement(node as ReactElement<Props>, { ...node.props }, ...Children.toArray(node.props.children).map(identity))
}
function validatePlan(plan: All49ReplayPlan): void {
  check(!!plan.parentCapturePin && !!plan.manufacturerAuditPin, "Root must bind genuine parent capture and manufacturer audit")
  check(plan.partialLayerProfile === "compact-four-layer-partial"
    && plan.scope === "SOURCE33B_PARTIAL_MIXED_JOINED_EDITABLE_PLAN_SOURCE_PROJECTION_ONLY", "Separate partial compact replay profile required")
  check(plan.inputBindings?.candidate && typeof plan.inputBindings.candidate.path === "string"
    && /^[a-f0-9]{64}$/.test(plan.inputBindings.candidate.sha256), "Exact current partial candidate bytes must be bound")
  const frame = plan.pcbPathCoordinateFrame
  check(frame?.kind === "CAPTURED_CPU_COMPONENT_ORIGIN" && frame.componentName === "U_SOC"
    && frame.rotationDegrees === 0 && frame.originXY?.x === 0 && frame.originXY?.y === 20
    && frame.rawCoreBinding?.sha256 === "d2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607"
    && typeof frame.rawCoreBinding?.path === "string"
    && typeof frame.capturedOriginalSourceComponentId === "string"
    && typeof frame.capturedOriginalPcbComponentId === "string" && frame.freshCoreDerived === false,
    "Exact captured compact CPU component coordinate frame required; numeric pad position is not the pcbPath XY origin")
  check(plan.replacedOriginals.length === 49 && sameSet(plan.replacedOriginals.map(r => r.originalSourceTraceId), OWNERS), "Exact original all49 replacement roster")
  check(Number.isInteger(plan.routedOwnerIds.length) && plan.routedOwnerIds.length >= 45 && plan.routedOwnerIds.length <= 49
    && plan.pendingOwnerIds.length === 49 - plan.routedOwnerIds.length
    && sameSet([...plan.routedOwnerIds, ...plan.pendingOwnerIds], OWNERS), "Exact routedM/pending49-minus-M original-owner partition")
  check(sameSet(plan.routedOriginals.map(r => r.originalSourceTraceId), plan.routedOwnerIds)
    && sameSet(plan.pendingOriginals.map(r => r.originalSourceTraceId), plan.pendingOwnerIds)
    && [...plan.routedOriginals, ...plan.pendingOriginals].every(r => same(r,
      plan.replacedOriginals.find(p => p.originalSourceTraceId === r.originalSourceTraceId))), "Routed/pending rows match exact49 replacements")
  check(Array.isArray(plan.projectedGeometry) && sameSet(plan.projectedGeometry.map((r: Row) => r.originalSourceTraceId),
    plan.routedOwnerIds), "Only routedM graphs are projected as connected copper")
  check(plan.pendingOwnerApproaches.length === 2 * plan.pendingOwnerIds.length
    && sameSet(plan.pendingOwnerApproaches.map(r => `${r.owner}:${r.side}`), plan.pendingOwnerIds.flatMap(n => [0, 1].map(s => `${n}:${s}`))),
    "Exactly two current owned approaches per pending owner")
  check(same(plan.pendingApproachSources, plan.auxiliaryLocalTraces)
    && new Set(plan.auxiliaryLocalTraces.map(r => r.name)).size === plan.auxiliaryLocalTraces.length, "Unique exact auxiliary local trace inventory")
  check(sameSet(plan.removeLocalTraceNames, IDS.flatMap(n => [0, 1].map(s => `TI_SIGNAL_LOCAL_source_trace_${n}_${s}`))), "Exact98 local trace removals")
  check(sameSet(plan.removeViaNames, [...IDS.flatMap(n => [0, 1].map(s => `V_TI_SIGNAL_source_trace_${n}_${s}`)),
    "V_TI_SIGNAL_INTERMEDIATE_source_trace_20_0", "V_TI_SIGNAL_INTERMEDIATE_source_trace_21_0", "V_TI_SIGNAL_INTERMEDIATE_source_trace_17_0"]), "Exact101 old fullspan source via removals")
  check(plan.all49OriginalLogicalTraces.length === 49 && new Set(plan.all49OriginalLogicalTraces.map(r => r.name)).size === 49,
    "Exact all49 original logical trace metadata required")
  check(plan.retainedInnerPortRegistrations.length === 0
    && plan.retainedInnerPortRegistrations.every(r => !plan.removeViaNames.includes(r.viaName)), "No old signal inner port registrations survive")
  check(Number.isInteger(plan.newVias.length) && plan.newVias.length >= 0
    && plan.newVias.length === new Set(plan.newVias.map(v => v.name)).size, "Unique replacement source via names; N may exceed98")
  for (const v of plan.newVias) {
    check(/^[A-Za-z][A-Za-z0-9_]*$/.test(v.name) && !plan.removeViaNames.includes(v.name)
      && Number.isFinite(v.x) && Number.isFinite(v.y) && v.fromLayer === "top" && v.toLayer === "bottom"
      && same(v.layers, LAYERS) && v.outerDiameter === .4572 && v.holeDiameter === .254
      && v.tented === "top_and_bottom_tented" && new Set(v.innerLayers).size === v.innerLayers.length
      && v.innerLayers.every((l: string) => l === "inner1" || l === "inner2"), "Real fullspan new via declaration")
    check(OWNERS.includes(v.originalSourceTraceId), "New physical via has one explicit original49 owner")
  }
  const newByName = new Map(plan.newVias.map(v => [v.name, v])), used = new Set<string>()
  function validatePath(path: Array<string | { x: number; y: number }>, sid: string, numericSelectors: string[]): void {
    check(path.length >= 2 && typeof path[0] === "string" && typeof path[path.length - 1] === "string",
      "Each wire path starts and ends on real source selectors")
    for (const p of path.slice(1, -1)) check(p && typeof p === "object" && Number.isFinite(p.x) && Number.isFinite(p.y)
      && sameSet(Object.keys(p), ["x", "y"]), "Only explicit XY wire vertices; no implicit inline via/toLayer")
    for (const selector of [path[0], path[path.length - 1]] as string[]) {
      if (numericSelectors.includes(selector)) continue
      const match = /^\.([A-Za-z][A-Za-z0-9_]*) > port\.(top|bottom|inner1|inner2)$/.exec(selector)
      const via = match ? newByName.get(match[1]) : undefined
      check(via && via.originalSourceTraceId === sid
        && (["top", "bottom"].includes(match![2]) || via.innerLayers.includes(match![2])),
        "Every path via selector names this owner's real declared via/Port")
      used.add(match![1])
    }
  }
  for (const r of plan.replacedOriginals) {
    const routed = plan.routedOwnerIds.includes(r.originalSourceTraceId)
    check((routed ? r.afterRouteProps.pcbPaths.length > 0 : r.afterRouteProps.pcbPaths.length === 0)
      && r.afterRouteProps.pcbPathRelativeTo === r.fromSelector,
      "Routed owners have explicit paths; pending logical rows have empty paths and no old carrier")
    for (const path of r.afterRouteProps.pcbPaths) validatePath(path, r.originalSourceTraceId, [r.fromSelector, r.toSelector])
  }
  for (const a of plan.pendingOwnerApproaches) {
    check(a.originalSourceTraceId === a.owner && plan.pendingOwnerIds.includes(a.owner)
      && a.originalBranch?.pcb_trace_id === a.branchId
      && (a.originalBranch.connection_name ?? a.originalBranch.source_trace_id) === a.owner,
      "Pending approach retains actual same-owner branch identity")
    check(sameSet(a.auxiliaryTraceNames, plan.auxiliaryLocalTraces.filter(t => t.owner === a.owner && t.branchId === a.branchId).map(t => t.name)),
      "Every pending branch's auxiliary Top trace is inventoried exactly")
    const topRuns: Row[][] = []; let current: Row[] = []
    function flush(): void {
      if (current.some((p, i) => i > 0 && Math.hypot(p.x - current[i - 1].x, p.y - current[i - 1].y) > 1e-8)) topRuns.push(current)
      current = []
    }
    for (const p of a.originalBranch.route) {
      check(p.route_type === "wire" || p.route_type === "via", "Pending branch has only explicit wire/via primitives")
      if (p.route_type === "wire" && p.layer === "top") { check(p.width === .1016, "Exact pending Top approach width"); current.push(p) }
      else flush()
    }
    flush()
    const actualAux = a.auxiliaryTraceNames.map(name => plan.auxiliaryLocalTraces.find(t => t.name === name)!)
    check(actualAux.length === topRuns.length && actualAux.every((t, i) => same(t.absoluteTopWireRoute, topRuns[i])
      && same(t.absolutePoints, topRuns[i].map(p => ({ x: p.x, y: p.y })))), "Every nonzero original pending Top run is retained without simplification")
    const events = a.originalBranch.route.filter((p: Row) => p.route_type === "via")
    check(a.viaNames.length === events.length && new Set(a.viaNames).size === a.viaNames.length,
      "Every pending real terminal barrel is retained exactly once")
    for (const [index, name] of a.viaNames.entries()) {
      const via = newByName.get(name), event = events[index]
      check(via && via.originalSourceTraceId === a.owner && via.role === "PENDING_ENDPOINT"
        && via.activeTransition === null && Math.hypot(via.x - event.x, via.y - event.y) <= 1e-8
        && same(event.layers, LAYERS) && event.via_diameter === .4572 && event.via_hole_diameter === .254
        && same(via.originalEvent, event), "Pending source via preserves physical fullspan branch event, without invented active carrier")
      used.add(name)
    }
  }
  for (const a of plan.auxiliaryLocalTraces) {
    const original = plan.replacedOriginals.find(r => r.originalSourceTraceId === a.owner)
    check(a.originalSourceTraceId === a.owner && plan.pendingOwnerIds.includes(a.owner)
      && /^[A-Za-z][A-Za-z0-9_]*$/.test(a.name) && !plan.removeLocalTraceNames.includes(a.name)
      && a.thicknessMm === .1016 && a.layer === "top" && a.absolutePoints.length >= 2
      && a.absolutePoints.every(p => Number.isFinite(p.x) && Number.isFinite(p.y))
      && a.absolutePoints.some((p, i) => i > 0 && Math.hypot(p.x - a.absolutePoints[i - 1].x, p.y - a.absolutePoints[i - 1].y) > 1e-8)
      && a.afterRouteProps.pcbPaths.length === 1,
      "Each auxiliary declaration is one genuine nonzero Top approach run")
    check(original && (a.side === 0 || a.side === 1)
      && a.fromSelector === (a.side === 0 ? original.fromSelector : original.toSelector),
      "Auxiliary approach begins at the owner's actual numeric source selector")
    const cpuApproach = plan.pendingOwnerApproaches.find(p => p.owner === a.owner && p.side === 0)
    const anchor = a.relativeAnchorXY, actualCpu = cpuApproach?.originalBranch?.route?.[0]
    check(actualCpu?.route_type === "wire" && actualCpu.layer === "top" && anchor
      && Number.isFinite(anchor.x) && Number.isFinite(anchor.y)
      && Math.hypot(anchor.x - frame.originXY.x, anchor.y - frame.originXY.y) <= 1e-8
      && a.relativeAnchorSelector === original!.fromSelector
      && a.afterRouteProps.pcbPathRelativeTo === a.relativeAnchorSelector,
      "Every auxiliary XY uses the CPU numeric selector and captured CPU component origin; RAM rotation is not applied")
    const path = a.afterRouteProps.pcbPaths[0]
    check(path.length === a.absolutePoints.length && path[0] === a.fromSelector && path.at(-1) === a.toSelector
      && path.slice(1, -1).every((point, index) => typeof point === "object"
        && Math.hypot(point.x - (a.absolutePoints[index + 1].x - anchor.x),
          point.y - (a.absolutePoints[index + 1].y - anchor.y)) <= 1e-8), "Auxiliary source XY exactly replays its complete numeric-relative Top run")
    const approach = plan.pendingOwnerApproaches.find(p => p.owner === a.owner && p.branchId === a.branchId && p.side === a.side)
    const terminal = /^\.([A-Za-z][A-Za-z0-9_]*) > port\.top$/.exec(a.toSelector)
    const terminalVia = terminal ? newByName.get(terminal[1]) : undefined, end = a.absolutePoints.at(-1)!
    check(approach && terminal && approach.viaNames.includes(terminal[1]) && terminalVia
      && Math.hypot(terminalVia.x - end.x, terminalVia.y - end.y) <= 1e-8,
      "Pending Top approach terminates on this exact branch's real barrel Top selector")
    validatePath(path, a.owner, [original!.fromSelector, original!.toSelector])
  }
  check(used.size === plan.newVias.length, "No unused replacement via declaration")
  const requested = plan.newVias.flatMap(v => v.innerLayers.map(layer => `${v.name}:${layer}`))
  check(sameSet(plan.innerPortRegistrations.map(r => `${r.viaName}:${r.layer}`), requested), "Every new real inner child has one registration")
  const expected = { DDR_BYTE0: { maxLength: 11.8, maxLengthSkew: .635 }, DDR_BYTE1: { maxLength: 14.2, maxLengthSkew: .635 },
    DDR_COMMAND_CLOCK: { minLength: 20.95, maxLength: 22.29, maxLengthSkew: .635 } }
  check(plan.sourceRuleIntersections.length === 3 && plan.sourceRuleIntersections.every(r => same(r.after, (expected as Row)[r.busName]))
    && new Set(plan.sourceRuleIntersections.map(r => r.busName)).size === 3, "Explicit approved original/manufacturer intersection only")
}

export function deriveAll49ReplayExpectedCounts(plan: All49ReplayPlan): Row {
  const N = plan.newVias.length, I = plan.innerPortRegistrations.length, A = plan.auxiliaryLocalTraces.length
  const R = plan.replacedOriginals.reduce((sum, r) => sum + r.afterRouteProps.pcbPaths.length, 0)
  return { realComponents: 280, originalCopperLands: 1165, referenceVias: 129, fixedReferencePaths: 165,
    heldOtherPhysicalPaths: 165, generatedWirePaths: R + A, routedWirePaths: R, auxiliaryWirePaths: A,
    auxiliarySourceTraces: A, generatedFullspanVias: N, generatedInnerPorts: I,
    physicalVias: 129 + N, pcbComponentsIncludingViaAliases: 409 + N, physicalTraces: 165 + R + A,
    sourceTraces: 1097 + A, innerLiteralPorts: I, expectedSourcePorts: 1419 + 2 * N + I,
    expectedReactElements: 2036 + N + I + A, sourceBuses: 8, namedSourceNets: 98,
    expectedPhysicallyConnectedOriginalOwnersIfAllHeldGraphsReproved: plan.routedOwnerIds.length,
    expectedRemainingOriginalOwners: plan.pendingOwnerIds.length, fullBoardPassed: false }
}

export function buildAll49SourceReplay(parentElementInput: ReactNode, plan: All49ReplayPlan): {
  parentElement: ReactNode; element: ReactNode; auditPlan: ReplayAuditPlan; expectedCounts: Row;
} {
  validatePlan(plan)
  const originalParentSnapshot = snapshotAll49ReplaySource(parentElementInput)
  const parentElement = identity(parentElementInput), before = snapshotAll49ReplaySource(parentElement)
  const parentKeyNormalizations: ReplayAuditPlan["parentKeyNormalizations"] = []
  function inventoryNormalization(a: LiteralSnapshot, b: LiteralSnapshot, path: number[]): void {
    check(a.kind === b.kind && a.type === b.type && same(a.props, b.props) && same(a.value, b.value)
      && a.children.length === b.children.length, "Parent identity pass changes only React normalization keys")
    if (a.key !== b.key) parentKeyNormalizations.push({ path: [...path], before: a.key, after: b.key })
    a.children.forEach((child, index) => inventoryNormalization(child, b.children[index], [...path, index]))
  }
  inventoryNormalization(originalParentSnapshot, before, [])
  const beforeRows = flatten(before)
  check(beforeRows.every(r => r.kind !== "unsupported"), "Literal/Fragment parent only")
  const named = (name: string): LiteralSnapshot => {
    const rows = beforeRows.filter(r => r.kind === "literal" && r.props.name === name)
    check(rows.length === 1, `Exactly one parent literal ${name}`); return rows[0]
  }
  for (const name of plan.removeViaNames) {
    const r = named(name)
    check(r.type === "via" && r.props.fromLayer === "top" && r.props.toLayer === "bottom"
      && mm(r.props.outerDiameter) === .4572 && mm(r.props.holeDiameter) === .254, "Only explicit old signal fullspan vias removed")
  }
  for (const name of plan.removeLocalTraceNames) check(named(name).type === "trace", "Only explicit old local traces removed")
  for (const v of plan.newVias) check(!beforeRows.some(r => r.props.name === v.name), "New via name absent from entire parent")
  for (const a of plan.auxiliaryLocalTraces) check(!beforeRows.some(r => r.props.name === a.name)
    && !plan.newVias.some(v => v.name === a.name), "New auxiliary local trace name absent from entire parent/via inventory")
  const actualRetainedInner = beforeRows.filter(r => r.type === "via" && !plan.removeViaNames.includes(String(r.props.name)))
    .flatMap(v => v.children.filter(p => p.type === "port" && ["inner1", "inner2"].includes(String(p.props.name)))
      .map(p => ({ viaName: String(v.props.name), layer: String(p.props.name), x: mm(v.props.pcbX), y: mm(v.props.pcbY) })))
  check(actualRetainedInner.length === 0 && sameSet(actualRetainedInner.map(r => `${r.viaName}:${r.layer}`),
    plan.retainedInnerPortRegistrations.map(r => `${r.viaName}:${r.layer}`)), "All52 old signal/carrier inner ports are removed with their old vias")
  for (const r of plan.retainedInnerPortRegistrations) {
    const actual = actualRetainedInner.find(p => p.viaName === r.viaName && p.layer === r.layer), xy = r.xy ?? r.viaXY
    check(actual && xy && actual.x === xy!.x && actual.y === xy!.y, "Retained registration uses actual parent Via coordinates")
  }
  const propertyEdits: PropertyEdit[] = [], removedNodes: RemovedNode[] = []
  const removal = new Set([...plan.removeViaNames, ...plan.removeLocalTraceNames])
  function inventoryRemoved(r: LiteralSnapshot, parentPath: number[] = []): void {
    for (const [i, child] of r.children.entries()) {
      if (removal.has(String(child.props.name))) removedNodes.push({ parentPath: [...parentPath], childIndex: i, row: cloneSnapshot(child) })
      else inventoryRemoved(child, [...parentPath, i])
    }
  }
  inventoryRemoved(before)
  check(removedNodes.length === 199, "Every98 local trace and101 via subtree removed once")
  const changed = new Set<string>(), removed = new Set<string>(), buses = new Set<string>(); let boards = 0
  function fork(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const originalProps: Props = { ...node.props }; delete originalProps.children
    const props: Props = { ...node.props }, name = String(props.name ?? "")
    if (removal.has(name)) { check(!removed.has(name), "Unique removal"); removed.add(name); return null }
    const children = Children.toArray(node.props.children).map(fork)
    const change = plan.replacedOriginals.find(r => r.logicalName === name)
    if (change) {
      check(node.type === "trace" && props.from === change.fromSelector && props.to === change.toSelector
        && mm(props.thickness) === .1016 && props.path === undefined && !changed.has(name), "Original numeric logical trace metadata unchanged")
      for (const key of ROUTE_KEYS) delete props[key]
      props.pcbPaths = change.afterRouteProps.pcbPaths; props.pcbPathRelativeTo = change.afterRouteProps.pcbPathRelativeTo
      check(props.pcbPathRelativeTo === change.fromSelector, "All new path coordinates relative to real CPU numeric selector")
      changed.add(name)
    }
    const intersection = plan.sourceRuleIntersections.find(r => r.busName === name)
    if (intersection) {
      check(node.type === "bus" && props.maxLengthSkew === .635 && same(props.pcbAllowedLayers, LAYERS), "Original cohort semantics retained")
      const expected = name === "DDR_BYTE0" ? 13.2 : name === "DDR_BYTE1" ? 14.4 : 23.49
      check(props.maxLength === expected && (name !== "DDR_COMMAND_CLOCK" || props.minLength === 20.95), "Exact captured historical absolute rules")
      Object.assign(props, intersection.after); buses.add(name)
    }
    if (change || intersection) {
      const afterProps = { ...props }; delete afterProps.children
      propertyEdits.push({ name, type: String(node.type), beforeProps: originalProps, afterProps })
    }
    if (node.type === "board") {
      check(++boards === 1 && props.layers === 4 && props.routeRemaining === false && props.autorouter === "bus_lanes", "Four-layer non-routing original board")
      for (const v of plan.newVias) children.push(createElement("via", { key: `RUN90-${v.name}`, name: v.name,
        pcbX: v.x, pcbY: v.y, fromLayer: "top", toLayer: "bottom", outerDiameter: .4572, holeDiameter: .254,
        tented: "top_and_bottom_tented" }, ...v.innerLayers.map(layer => createElement("port", { key: layer, name: layer, layer }))))
      for (const a of plan.auxiliaryLocalTraces) children.push(createElement("trace", { key: `PARTIAL-${a.name}`,
        name: a.name, from: a.fromSelector, to: a.toSelector, thickness: .1016,
        pcbPaths: a.afterRouteProps.pcbPaths, pcbPathRelativeTo: a.afterRouteProps.pcbPathRelativeTo }))
    }
    // React.cloneElement starts from all original props, so a deleted route key
    // (including an own undefined pcbPath) would silently survive. Recreate
    // changed literal traces from the audited exact props instead. Preserve
    // key absence when null, and preserve ref only through its existing prop.
    if (change) {
      const exactProps: Props & { key?: string } = { ...props }; delete exactProps.children
      if (node.key !== null) exactProps.key = String(node.key)
      return createElement(node.type, exactProps, ...children)
    }
    return cloneElement(node as ReactElement<Props>, props, ...children)
  }
  // Fork the same unnormalized input as identity(): held React key normalization agrees.
  const element = fork(parentElementInput), after = snapshotAll49ReplaySource(element), afterRows = flatten(after)
  check(boards === 1 && changed.size === 49 && removed.size === 199 && buses.size === 3, "Exact complete overlay scope")
  for (const original of plan.all49OriginalLogicalTraces) {
    const rows = afterRows.filter(r => r.type === "trace" && r.props.name === original.name)
    check(rows.length === 1 && rows[0].props.from === original.from && rows[0].props.to === original.to, "Every original numeric logical trace held")
  }
  const strings = (v: unknown): string[] => typeof v === "string" ? [v] : Array.isArray(v) ? v.flatMap(strings)
    : v && typeof v === "object" ? Object.values(v).flatMap(strings) : []
  check(afterRows.every(r => strings(r.props).every(s => !plan.removeViaNames.some(n => s.includes(`.${n} > port.`)))),
    "No source selector references any removed old signal/carrier via")
  const expectedCounts = deriveAll49ReplayExpectedCounts(plan)
  const auditPlan: ReplayAuditPlan = { scope: "PARTIAL_MIXED_SOURCE33B_LITERAL_OVERLAY_FULL_INVERSE_REQUIRED", propertyEdits, removedNodes,
    addedViaNames: plan.newVias.map(v => v.name), addedAuxiliaryTraceNames: plan.auxiliaryLocalTraces.map(a => a.name),
    expectedCounts, parentCapturePin: plan.parentCapturePin, parentKeyNormalizations,
    effectiveConstraintBridge: { profile: "compact-four-layer-partial", manufacturerAuditPin: plan.manufacturerAuditPin,
      candidatePin: plan.inputBindings.candidate, routedOwnerIds: plan.routedOwnerIds, pendingOwnerIds: plan.pendingOwnerIds,
      pendingOwnerLogicalRoutesAreEmpty: true, pendingPhysicalApproachesPreserved: true,
      fullBoardPassed: false, all49Accepted: false, partialDiagnosticReplayControlsPassed: false,
      mixedRoutePhysicalQualificationRequiresPerRunAndFullspanViaChecks: true,
      wholeMixedC31ValidateOutputQualified: false, capturedIdsUsedAsFreshIds: false,
      originalCapturedCohorts: propertyEdits.filter(e => e.type === "bus").map(e => ({ name: e.name, props: e.beforeProps })),
      effectiveCohorts: propertyEdits.filter(e => e.type === "bus").map(e => ({ name: e.name, props: e.afterProps })),
      automaticCoreSrjForThisForkMustNotBeUsed: true, sourceBusAbsoluteBoundsMayBeAbsentFromCoreJson: true,
      futureConstructorMustUseThisExplicitBridgeAndOriginalExactOwnerMapping: true },
    rawCircuitIdsAssigned: false, full49Accepted: false, fabricationReady: false }
  check(same(inverseAll49ReplaySnapshot(after, auditPlan), before), "Complete presence-aware/child-order/key inverse to parent literals")
  check(same(inverseAll49ReplayParentNormalization(before, auditPlan), originalParentSnapshot), "Exact inverse of parent-only key normalization")
  check(afterRows.filter(r => r.kind === "literal" || r.kind === "fragment").length === expectedCounts.expectedReactElements,
    "Dynamic React literal count")
  check(afterRows.filter(r => r.type === "via").length === expectedCounts.physicalVias
    && afterRows.filter(r => r.type === "port").length === expectedCounts.innerLiteralPorts
    && afterRows.filter(r => r.type === "trace").length === expectedCounts.sourceTraces
    && afterRows.filter(r => r.type === "bus").length === 8, "Dynamic declaration counts")
  return { parentElement, element, auditPlan, expectedCounts }
}

/** Invoke after route inverse to recover the exact captured compact parent. */
export function inverseAll49ReplayParentNormalization(normalizedParent: LiteralSnapshot, audit: ReplayAuditPlan): LiteralSnapshot {
  const result = cloneSnapshot(normalizedParent), restored = new Set<string>()
  function walk(row: LiteralSnapshot, path: number[]): void {
    const edit = audit.parentKeyNormalizations.find(e => same(e.path, path)), id = JSON.stringify(path)
    if (edit) { check(!restored.has(id) && row.key === edit.after, "Exact normalized parent key before inverse"); row.key = edit.before; restored.add(id) }
    row.children.forEach((child, index) => walk(child, [...path, index]))
  }
  walk(result, [])
  check(restored.size === audit.parentKeyNormalizations.length, "Every parent normalization key restored")
  return result
}

export function inverseAll49ReplaySnapshot(after: LiteralSnapshot, audit: ReplayAuditPlan): LiteralSnapshot {
  const result = cloneSnapshot(after), added = new Set([...audit.addedViaNames, ...audit.addedAuxiliaryTraceNames])
  function restore(r: LiteralSnapshot, path: number[]): void {
    r.children = r.children.filter(child => !added.has(String(child.props.name)))
    const removed = audit.removedNodes.filter(m => same(m.parentPath, path)).sort((a, b) => a.childIndex - b.childIndex)
    for (const item of removed) r.children.splice(item.childIndex, 0, cloneSnapshot(item.row))
    const edit = audit.propertyEdits.find(e => e.name === r.props.name && e.type === r.type)
    if (edit) {
      if (!same(r.props, edit.afterProps)) {
        const expected = edit.afterProps, actual = r.props
        const keys = [...new Set([...Object.keys(expected), ...Object.keys(actual)])].sort()
        const has = (v: Props, key: string) => Object.prototype.hasOwnProperty.call(v, key)
        const key = keys.find(k => has(expected, k) !== has(actual, k) || !same(expected[k], actual[k]))
        const describe = (props: Props, field: string): Row => {
          const value = props[field], serialized = canonical(value)
          return { present: has(props, field), type: value === null ? "null" : Array.isArray(value) ? "array" : typeof value,
            canonicalPreview: serialized.slice(0, 360), canonicalLength: serialized.length }
        }
        throw new Error("Exact declared after props before inverse: " + JSON.stringify({
          node: { name: r.props.name ?? null, type: r.type, path },
          expectedOwnKeys: Object.keys(expected).sort(), actualOwnKeys: Object.keys(actual).sort(),
          firstDifference: key === undefined ? null : { key, expected: describe(expected, key), actual: describe(actual, key) },
        }))
      }
      r.props = { ...edit.beforeProps }
    }
    r.children.forEach((child, i) => restore(child, [...path, i]))
  }
  restore(result, [])
  return result
}

type ViaInstance = { componentName: string; props: Props; pcb_via_id?: string | null; source_manually_placed_via_id?: string | null }
type PortInstance = { componentName: string; props: Props; parent: unknown; matchedComponents: unknown[];
  source_port_id?: string | null; pcb_port_id?: string | null; registerMatch(owner: unknown): void; getAvailablePcbLayers(): string[] }
type CircuitView = { _hasRenderedAtleastOnce?: boolean; schematicDisabled?: boolean;
  selectOne(selector: string, options?: { type?: string }): unknown }
/** Register only new genuine inner children; no old signal/carrier registrar runs. */
export function registerAll49SourceReplayInnerPorts(circuitUnknown: unknown, plan: All49ReplayPlan): Row {
  validatePlan(plan)
  const circuit = circuitUnknown as CircuitView
  check(!circuit._hasRenderedAtleastOnce && circuit.schematicDisabled === true, "Unrendered PCB-only real Circuit")
  const requests = [...plan.retainedInnerPortRegistrations, ...plan.innerPortRegistrations]
  check(new Set(requests.map(r => `${r.viaName}:${r.layer}`)).size === requests.length, "Unique retained/generated inner matches")
  const registrations: Row[] = []
  for (const r of requests) {
    const xy = r.xy ?? r.viaXY
    const via = circuit.selectOne(`.${r.viaName}`) as ViaInstance | null
    const port = circuit.selectOne(`.${r.viaName} > port.${r.layer}`, { type: "port" }) as PortInstance | null
    check(xy && (r.layer === "inner1" || r.layer === "inner2") && via?.componentName === "Via"
      && via.props.name === r.viaName && via.props.fromLayer === "top" && via.props.toLayer === "bottom"
      && mm(via.props.outerDiameter) === .4572 && mm(via.props.holeDiameter) === .254
      && mm(via.props.pcbX) === xy!.x && mm(via.props.pcbY) === xy!.y
      && port?.componentName === "Port" && port.parent === via && port.props.name === r.layer && port.props.layer === r.layer
      && !port.source_port_id && !port.pcb_port_id && !via.pcb_via_id && !via.source_manually_placed_via_id
      && port.getAvailablePcbLayers().join(",") === r.layer && port.matchedComponents.every(owner => owner === via),
      "One genuine unrendered explicit inner Port and its exact fullspan Via")
    if (!port!.matchedComponents.includes(via)) port!.registerMatch(via)
    check(port!.matchedComponents.length === 1 && port!.matchedComponents[0] === via, "Exact public real owner match")
    registrations.push({ ...r, xy, futureFreshIds: null })
  }
  return { registrations, retainedCount: 0, generatedCount: plan.innerPortRegistrations.length,
    extraPhysicalViaFromPortRegistration: false, rawCircuitIdsAssigned: false, coreRendered: false, fabricationReady: false }
}
