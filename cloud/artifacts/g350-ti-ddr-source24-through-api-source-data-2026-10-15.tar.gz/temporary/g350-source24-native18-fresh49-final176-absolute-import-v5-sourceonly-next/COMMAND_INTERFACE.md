Source-only preparation; no authority, no application execution, no acceptance.

Root stage order: actual Source24 Core and its 29 controls → Native18 → pure-stdlib fresh49 projection → independently bound API111 (108 primary predicates plus3 secondary DQS1 predicates) → CLI/CAD.

Native command interface (Root must first create and authenticate a NEW bound manifest/authority with the complete SDK/source closure and actual non-null Core24/control pins):
  G350_MOVED24_FRESH_NATIVE_APPROVED=1 bun qualify-fresh-native.mjs ABS_MANIFEST MANIFEST_SHA ABS_AUTHORITY AUTHORITY_SHA ABS_FRESH_NATIVE_REPORT

Projection command interface (Root must first bind the actual native report and the same Core24/control/proposal/source pins into a NEW successor manifest, and create a fresh empty owned output directory):
  G350_FRESH24_FULL49_PROJECTION_APPROVED=1 python3 -B derive-fresh24-core49-input.py ABS_PROJECTION_MANIFEST MANIFEST_SHA ABS_FRESH_EMPTY_OUTPUT_DIRECTORY

Future Core24/control/native report and API full49 input/projection proof pins remain NULL in FUTURE_BINDINGS_TEMPLATE_NO_AUTHORIZATION.json. That template is intentionally not runnable. The native worker loads only standard-library modules before validating mandatory actual pins; its 18 physical/manufacturing calls and two timing calls are unchanged. The original manufacturing helper is byte-identical. Native ownership uses a private WeakMap tied to the actual fresh Core object; no JSON registry substitutes, retagging, old IDs, or old constructor material are accepted.

Fresh49 outputs: GENUINE_CORE24_FULL49_UNSEEDED_PUBLIC_INPUT.json; GENUINE_CURRENT_CORE49_NUMERIC_REQUESTS_AND_CONTACTS.json; CURRENT_MATERIAL_PROJECTION_PROOF.json; GENUINE_CURRENT_CORE49_CONSTRUCTOR_INPUT.json; CURRENT_VIA_EVENT_AND_NPTH_INVERSE_PROOF.json. The final proof exposes actualCoreSha256, actualNativeReportSha256, constructorInputSha256, originalSource24ProposalSha256, and sourceManifestSha256 (the exact Source24 source closure). API must bind the final input/proof only after Root has actually produced and collected them.

The full49 output is freshly projected from actual Core24 and its actual native ownership: 263 local/reference traces, 49 original requests, 98 existing fullspan signal via events, 1298 hard obstacles. All 24 carrier bodies are excluded from the unseeded input. The only old template data reused are pinned original rule/request metadata and original numeric selector metadata; old 631/b262 material is not output. The one eleven-wire Source14 RAM stub is retained completely, with raw direction and endpoint IDs restored by an exact inverse; the other 97 stubs remain exactly two wires. Reference geometry, holes, copper and original rules are preserved, with the already documented NPTH generic-clearance envelope and no new physical vias.

No SDK/native/solver/API/Core/CLI/CAD application imports or evaluations were performed by the author. Only stdlib source reads, string comparisons, Python AST parsing and finite hashes were used. No workspace files were written. Root owns all authority, bounded execution, process/resource/closure verification and any qualification. accepted49=false; referenceQualified=false; electricalTimingQualified=false; fabricationReady=false.

Functional import successor: Root-authorized private factory imports the pinned absolute board connectivity-map entry, so the /tmp helpers do not depend on absent local node_modules. The Native worker and both sibling helpers are co-located in this successor. The installed board package and Ce3 tree remain unchanged. Root still binds all actual future artifacts before invocation.
