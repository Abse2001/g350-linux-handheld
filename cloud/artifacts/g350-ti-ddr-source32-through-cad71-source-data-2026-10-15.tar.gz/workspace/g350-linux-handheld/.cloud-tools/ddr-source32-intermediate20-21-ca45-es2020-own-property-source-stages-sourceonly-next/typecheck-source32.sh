#!/usr/bin/env bash
set -euo pipefail
source /workspace/g350-linux-handheld/cloud/env.sh
[[ "${G350_SOURCE32_TYPES_ROOT_GUARDED:-}" == 1 ]]
cd /workspace/g350-linux-handheld
packet=/workspace/g350-linux-handheld/.cloud-tools/ddr-source32-intermediate20-21-ca45-es2020-own-property-source-stages-sourceonly-next
exec "$G350_REPO_ROOT/.cloud-tools/node/bin/node" --max-old-space-size=4096 "$G350_REPO_ROOT/node_modules/typescript/bin/tsc" --noEmit --strict --target ES2020 --module ESNext --moduleResolution node --jsx react-jsx --resolveJsonModule --esModuleInterop --skipLibCheck --rootDir /workspace --types tscircuit,bun-types,node "$packet/source32.circuit.tsx" "$packet/capture-source32.ts" "$packet/render-source32-core.ts"
