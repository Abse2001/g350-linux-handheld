"""Root exact attempt cleanup. No SDK, source, image or original-cache edits."""
from pathlib import Path
import datetime, hashlib, json, os, shutil, stat, subprocess

RUN=Path('/tmp/g350-source24-cad-root-20261015-after45-diskguard')
POST_SHA='c71792755945e1b2f58ffd7db00d6a752e347a41784bccb31adc4639e3c2c9e8'
CONTAINER='g350-source24-fresh-cad-5d76e3e1fa307eab-795b80f87262657d'
IMAGE='sha256:11b9360b20752e87f20942639e229b0d111e96f6e30b1bd1cb2eaafce9f26cfc'
SCRATCH=Path('/tmp/g350-source24-fresh-cad.Nl6W3d')
BOARD=Path('/workspace/g350-linux-handheld')
assert hashlib.sha256((RUN/'POSTAUDIT.json').read_bytes()).hexdigest()==POST_SHA
post=json.loads((RUN/'POSTAUDIT.json').read_bytes())
assert post['ownedContainerName']==CONTAINER and post['cadExecution']['pgid']==488592
assert post['cadExecution']['diagnosticStopped'] and post['cadExecution']['stopReasons']==['OWNED_DISK_FREE_STOP']
assert post['dependenciesBefore']==post['dependenciesAfter'] and post['solverDependenciesBefore']==post['solverDependenciesAfter']
docker=['bash',str(BOARD/'scripts/cloud-docker.sh')]
def command(args):
    result=subprocess.run(docker+args,check=True,capture_output=True,text=True,timeout=30)
    return result.stdout.strip()
def named():return command(['ps','--all','--quiet','--filter','name=^/'+CONTAINER+'$'])
assert command(['image','inspect',IMAGE,'--format','{{.Id}}'])==IMAGE
before=shutil.disk_usage('/workspace').free
ids=named()
if ids:
    assert all(len(v)==12 and all(c in '0123456789abcdef'for c in v)for v in ids.splitlines())
    command(['rm','--force',CONTAINER])
assert not named()
assert SCRATCH.is_dir() and SCRATCH.resolve()==SCRATCH and not SCRATCH.is_symlink()
created=datetime.datetime.fromtimestamp(SCRATCH.stat().st_ctime,datetime.timezone.utc)
assert datetime.datetime.fromisoformat(post['cadExecution']['startedAt'])<=created<=datetime.datetime.fromisoformat(post['cadExecution']['endedAt'])
source_rows=[];copied=0;logical=0
for base,dirs,files in os.walk(SCRATCH,followlinks=False):
    for name in dirs:
        p=Path(base)/name;assert p.is_dir() and not p.is_symlink()
    for name in files:
        p=Path(base)/name;rel=p.relative_to(SCRATCH);s=p.lstat()
        assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
        if rel.as_posix()=='snapshot-mounts.nul':
            assert s.st_size<65536
            continue
        assert rel.parts[0]in('xdg-config','xdg-cache','xdg-data')
        original=BOARD/'.cloud-tools'/rel
        a=original.lstat();assert stat.S_ISREG(a.st_mode) and not original.is_symlink()
        data=p.read_bytes();original_data=original.read_bytes()
        assert data==original_data and stat.S_IMODE(s.st_mode)==stat.S_IMODE(a.st_mode)
        source_rows.append((str(original),hashlib.sha256(original_data).hexdigest(),a.st_size,stat.S_IMODE(a.st_mode)))
        copied+=1;logical+=s.st_size
assert copied==12057 and logical==1158893348
shutil.rmtree(SCRATCH)
assert not SCRATCH.exists()
assert not named()
assert command(['image','inspect',IMAGE,'--format','{{.Id}}'])==IMAGE
for p,digest,size,mode in source_rows:
    p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink()and s.st_size==size and stat.S_IMODE(s.st_mode)==mode
    assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
after=shutil.disk_usage('/workspace').free
result=dict(scope='ROOT_EXACT_SCOPE46_OWNED_CONTAINER_AND_SCRATCH_CLEANUP',containerName=CONTAINER,ownedContainerSeenBeforeCleanup=bool(ids),ownedContainerActuallyAbsentAfterCleanup=True,ownedScratchPath=str(SCRATCH),ownedScratchRemoved=True,originalCacheFilesVerifiedUnchanged=copied,originalCacheBytesVerifiedUnchanged=logical,imageIdHeld=IMAGE,workspaceFreeBytesBefore=before,workspaceFreeBytesAfter=after,originalWorkspaceFloor=post['workspaceFreeBytesBefore'],originalWorkspaceFloorRecovered=after>=post['workspaceFreeBytesBefore'],originalPostauditHeld=True,hardwareOrSourceOrSdkOrOriginalCacheEdited=False,accepted49=False,fabricationReady=False)
out=RUN/'ROOT_EXACT_CLEANUP_REPORT.json'
with out.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
out.chmod(0o600)
print(json.dumps(result))
