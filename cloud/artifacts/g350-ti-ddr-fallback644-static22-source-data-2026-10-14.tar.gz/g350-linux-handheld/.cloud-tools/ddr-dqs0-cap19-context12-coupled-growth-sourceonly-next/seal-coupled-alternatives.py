"""Finite original-derived geometry qualification; no solver/Core/native/CAD imports."""
from pathlib import Path
import json,math,hashlib,importlib.util,stat,time,copy,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;MATERIAL=ROOT.parent/'ddr-full49-cap19-owned32-owned4-jointpool-sourceonly-next/material-one-context.py'
assert hashlib.sha256(MATERIAL.read_bytes()).hexdigest()=='1ad802cd7454b27343cbd8f429177f0a9cf80d4c9d606ed7c84ac9f91856883f'
sp=importlib.util.spec_from_file_location('context12_seal_material',MATERIAL);q=importlib.util.module_from_spec(sp);sp.loader.exec_module(q)
BASE=ROOT.parent/'ddr-cpu19-cap-and-owned32-corner-sourceonly-next/NORMALIZED_TRUE_SEVEN_FRESH_RIGHT_DQS1_CONTEXT12_17.json'
REFERENCE=ROOT.parent/'ddr-ram-yplus1_2-four-strobe-reference-peer-next/CONNECTED_GROUND_POLYGON_AND_REAL_RETURN_PROPOSAL.json'
ATTEMPT=ROOT/'FINITE_COUPLED_TRUNK_GROWTH_ATTEMPT02_SAFE_RADIUS_PARTIAL_ARCS.json'
assert q.g.sha(BASE)=='e0842814eea31f966e235c2c131d7bb7f9761e8a7e73faca437fe82b6abfe1e1'
assert q.g.sha(REFERENCE)=='cd731719b31a1b35e70ad6f06831660774f1abafefc73cbfb547fb3ac6efd548'
assert q.g.sha(ATTEMPT)=='b35aa11ed2f5f643b000024baf383ab7b3eb5cc12213c48637aa6ace4edb110d'
base,baseRaw=q.normalize(json.loads(BASE.read_text()));reference=json.loads(REFERENCE.read_text());region=next(r for r in reference['polygons'] if r['name']=='TOP_B0_GND_BODY');reserved=[region]
boxes=[[-7.2632,7.2632,12.3082,27.2632],[-5.2732,8.0918,3.3082,11.4918]]
names=['source_trace_15','source_trace_16'];pair=next(r for r in q.full['differentialPairs'] if set(r['connectionNames'])==set(names));bus=next(b for b in q.full['buses']if b['busId']=='DDR_BYTE0')
assert pair['traceGap']==.12 and pair['lengthTolerance']==.127 and bus['maxLength']==13.2 and bus['maxLengthSkew']==.635 and bus['traceWidth']==.1016
allowed=(.1016+pair['traceGap'])/math.cos(math.pi/8)-.1016+.002
poly=[(p['x'],p['y'])for p in region['outline']]
def pin(p):return {'path':str(p.resolve()),'sha256':q.g.sha(p)}
def write(name,d):
 p=ROOT/name
 with p.open('x')as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n')
 p.chmod(0o600);return p

def outside(a,b):
 intervals=[]
 for box in boxes:
  lo,hi=0.,1.
  for k,low,high in[(0,box[0],box[1]),(1,box[2],box[3])]:
   v=b[k]-a[k]
   if abs(v)<1e-15:
    if a[k]<low or a[k]>high:lo,hi=1.,0.;break
   else:t0=(low-a[k])/v;t1=(high-a[k])/v;lo=max(lo,min(t0,t1));hi=min(hi,max(t0,t1))
  if lo<hi:intervals.append((lo,hi))
 intervals.sort();out=[];end=0.
 for lo,hi in intervals:
  if lo>end:out.append((end,lo))
  end=max(end,hi)
 if end<1.:out.append((end,1.))
 return out

def coupling(path,mate,section):
 result={}
 for label,ranges in{'shared':[(j,0.,1.)for j in range(*section)],'exterior':[(j,lo,hi)for j,(a,b)in enumerate(zip(path,path[1:]))for lo,hi in outside(a,b)]}.items():
  maxgap=-1.;mingap=math.inf;sampleCount=0;length=0.;separated=0.;error=0.
  for j,lo,hi in ranges:
   a,b=path[j:j+2];span=math.dist(a,b);steps=max(1,math.ceil((hi-lo)*span/.002));step=(hi-lo)*span/steps;error=max(error,step/2);length+=(hi-lo)*span
   for k in range(steps):
    t=lo+(hi-lo)*(k+.5)/steps;p=(a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1]));gap=min(q.g.pointseg(p,x,y)for x,y in zip(mate,mate[1:]))-.1016;sampleCount+=1;maxgap=max(maxgap,gap);mingap=min(mingap,gap)
    if gap+step/2>allowed:separated+=step
  result[label]={'maximumSampleEdgeGapMm':maxgap,'minimumSampleEdgeGapMm':mingap,'maximumSamplingErrorMm':error,'sampleCount':sampleCount,'evaluatedLengthMm':length,'separatedLengthUpperBoundMm':separated,'originalDerivedMaximumAllowedEdgeGapMm':allowed,'entireIntervalBoundedPass':separated==0.}
 return result

def inside(p):
 x,y=p;hit=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if(a[1]>y)!=(b[1]>y)and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:hit=not hit
 return hit

def reference_footprint(path,section):
 minimum=math.inf;samples=0;bad=[]
 for j in range(*section):
  a,b=path[j:j+2];length=math.dist(a,b);steps=max(1,math.ceil(length/.002));error=length/steps/2
  for k in range(steps):
   t=(k+.5)/steps;p=(a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1]));boundary=min(q.g.pointseg(p,x,y)for x,y in zip(poly,poly[1:]+poly[:1]));slack=boundary-.0508-error;samples+=1;minimum=min(minimum,slack)
   if not inside(p) or slack<-1e-9:bad.append({'segment':j,'point':p,'footprintSlackMm':slack,'inside':inside(p)})
 return {'sharedOnlyFootprintInsidePinnedConnectedGroundPolygon':not bad,'conservativeMinimumSharedFootprintBoundarySlackMm':minimum,'samples':samples,'traceHalfWidthMm':.0508,'samplingErrorAtMostMm':.001,'violations':bad,'fullApproachesOrRFFootprintCoverageClaimed':False,'actualFilledGroundPlaneQualified':False}

def allchecks(joined):
 out={}
 for n,r in joined.items():
  scene=q.Scene(r['layer'],joined,n,reserved);certificate=scene.certificate(r['path'],n);angles=q.z.turns(r['path']);selftest=q.z.selfcheck([q.z.P(*v)for v in r['path']]);exposure=scene.exposure(r['path'],n)
  out[n]={'physical':certificate,'angles':angles,'self':selftest,'reciprocalWholeWireNormalSpacingExposure':exposure,'pass':certificate['violationCount']==0 and angles['pass']and selftest['clear']and exposure['absoluteTICapPass']}
 return out

def ownerproof(n,path):
 dogs=[t for t in q.full['traces']if t.get('source_trace_id')==n];assert len(dogs)==2
 dogvias=[next(p for p in t['route']if p['route_type']=='via')for t in dogs];assert len(dogvias)==2
 for actual,owned in zip([path[0],path[-1]],dogvias):assert math.dist(actual,(owned['x'],owned['y']))<1e-8 and owned['via_diameter']==.4572 and set(owned['layers'])=={'top','inner1','inner2','bottom'}
 numeric=next(c for c in q.full['connections']if c['name']==n)['pointsToConnect']
 for contact,dog in zip(numeric,dogs):
  wires=[p for p in dog['route']if p['route_type']=='wire'and p['layer']=='top'];assert len(wires)>=2 and math.dist((wires[0]['x'],wires[0]['y']),(contact['x'],contact['y']))<1e-8
 return {'genuineOriginalSourceTraceId':n,'authenticNumericCpuRamTopContacts':numeric,'actualOwnedBarrelEndpoints':[{'x':v['x'],'y':v['y'],'outerDiameterMm':v['via_diameter'],'layers':v['layers']}for v in dogvias],'exactUnchangedTopStubRows':dogs,'fixedTopStubPlanarMm':q.fixed[n],'physicalExistingFullThroughBarrels':2,'ownedEndpointBijectionPassed':True,'noExtraViaOrInventedNumericSourceContact':True,'activeVerticalDelayMmNotAddedToPlanarConstraint':True,'electricalTimingUnqualified':True}

# Recheck every changed real Top item against the pinned Ground proposal.
material_reference=[]
for row in q.changedObstacles:
 o=row['after']
 if'top'not in o['layers']:continue
 center=(o['center']['x'],o['center']['y']);angle=math.radians(o.get('ccwRotationDegrees',0));co,si=math.cos(angle),math.sin(angle);w,h=o['width']/2,o['height']/2;vertices=[(center[0]+x*co-y*si,center[1]+x*si+y*co)for x,y in[(-w,-h),(w,-h),(w,h),(-w,h)]]
 gap=min(q.m.polydist(a,b,poly)for a,b in zip(vertices,vertices[1:]+vertices[:1]));assert gap>=.12-1e-8;material_reference.append({'changedObstacleIndex':row['index'],'minimumForeignEdgeGapMm':gap})
for row in q.changedTraces:
 trace=row['after']
 for p in trace['route']:
  if p['route_type']=='via':
   gap=q.m.polydist((p['x'],p['y']),(p['x'],p['y']),poly)-p['via_diameter']/2;assert gap>=.12-1e-8;material_reference.append({'changedBranchId':trace['pcb_trace_id'],'minimumOwnedBarrelEdgeGapMm':gap})
 for j,(a,b)in enumerate(zip(trace['route'],trace['route'][1:])):
  if a['route_type']==b['route_type']=='wire'and a['layer']==b['layer']=='top':
   gap=q.m.polydist((a['x'],a['y']),(b['x'],b['y']),poly)-a['width']/2;assert gap>=.12-1e-8;material_reference.append({'changedBranchId':trace['pcb_trace_id'],'segment':j,'minimumForeignEdgeGapMm':gap})

started=time.monotonic();outcomes=[];attempt=json.loads(ATTEMPT.read_text())
for choice in attempt['goodCandidates']:
 angle=choice['parameters']['lobeAngleDegrees']
 if angle not in [80,82,84]:continue
 pairRecords,rawPair=q.normalize(choice);joined={**base,**pairRecords};checks=allchecks(joined);special={}
 for n in names:
  path=pairRecords[n]['path'];mate=pairRecords[next(m for m in names if m!=n)]['path'];section=rawPair[n]['coupledSection'];special[n]={'ownerProof':ownerproof(n,path),'wholePlanarLengthMm':q.g.length(path)+q.fixed[n],'coupledSection':section,'originalDerivedSharedExteriorCoupling':coupling(path,mate,section),'referenceAwareSharedBody':reference_footprint(path,section)}
 pairSkew=abs(special[names[0]]['wholePlanarLengthMm']-special[names[1]]['wholePlanarLengthMm']);passed=all(r['pass']for r in checks.values())and pairSkew<=pair['lengthTolerance']and all(r['wholePlanarLengthMm']<=bus['maxLength']and all(v['entireIntervalBoundedPass']for v in r['originalDerivedSharedExteriorCoupling'].values())and r['referenceAwareSharedBody']['sharedOnlyFootprintInsidePinnedConnectedGroundPolygon']for r in special.values())
 tag=f'ANGLE{angle:02d}';report=write(f'COUPLED_DQS0_CONTEXT12_{tag}_FULL_STATIC_REPORT.json',{'scope':'SOURCE_ONLY_CONTEXT12_ATOMIC_DQS0_COMPLETE_SHARED_EXTERIOR_SELF_ANGLE_OWNER_REFERENCE_BODY_AND_BASE7_RECIPROCAL','materialContextPin':pin(q.CONTEXT),'full49NumericInputPin':pin(Path(q.pins[0]['path'])),'full49CarrierInputPin':pin(Path(q.pins[1]['path'])),'nativeContextHypothesisPin':pin(Path(q.pins[2]['path'])),'base7Pin':pin(BASE),'groundReservationPin':pin(REFERENCE),'finiteAttemptPin':pin(ATTEMPT),'parameters':choice['parameters'],'records':special,'allSevenActualGeometryChecks':checks,'pairSkewMm':pairSkew,'allStaticPairAndBase7PhysicalSelfAngleReciprocalAndSharedExteriorPass':passed,'existingB0SubsetPlanarCohort':q.cohort(joined,'DDR_BYTE0'),'source4ComparisonOnlyMm':13.0669,'source4VsPairWorstSkewComparisonOnlyMm':13.0669-min(r['wholePlanarLengthMm']for r in special.values()),'genuineContext12ChangedPhysicalItemsVsPinnedGroundProposal':material_reference,'oldOther5RecordsByteIdentical':all(joined[n]==base[n]for n in set(base)-set(names)),'cpuAndRamApproachesAndTerminalsUnchanged':True,'exact225ExistingHoles96Topstubs129ReferenceVias1165LandsPreserved':True,'originalPairLengthToleranceMm':pair['lengthTolerance'],'originalNominalTraceGapMm':pair['traceGap'],'originalB0MaxMm':bus['maxLength'],'originalB0SkewMm':bus['maxLengthSkew'],'source31AndOtherByte0StillNeedGlobalMatching':True,'currentCpuLaunchReferenceHoldNotRepaired':True,'allReferencePlanesReturnsImpedanceAndElectricalTimingQualified':False,'stdLibOriginalDerivedChecksOnlyNotActualOriginalAPIExecution':True,'sourceNativeApiCoreCadExecuted':False,'all11Byte0Or49Accepted':False,'fabricationReady':False})
 for r in rawPair.values():
  for stale in ['wholeLength','wholePlanarLengthMm','actualContext12Recheck','sourceReport','sourceReportSha256','authoredRoleClassProvenance']:r.pop(stale,None)
  r['wholePlanarLengthMm']=special[r['sourceTraceId']]['wholePlanarLengthMm'];r['actualStaticFullPairReportPin']=pin(report)
 norm=write(f'NORMALIZED_ATOMIC_DQS0_CONTEXT12_MATCHED_{tag}.json',{'scope':'SOURCE_ONLY_REAL_ATOMIC_COUPLED_DQS0_CONTEXT12_MATCHED_ALTERNATIVE','strictUniqueCarrierCount':2,'records':[rawPair[n]for n in names],'actualStaticFullPairReportPin':pin(report),'materialContextPin':pin(q.CONTEXT),'full49NumericInputPin':pin(Path(q.pins[0]['path'])),'full49CarrierInputPin':pin(Path(q.pins[1]['path'])),'allStaticPairAndBase7ChecksPass':passed,'pairSkewMm':pairSkew,'currentCpuLaunchReferenceHoldNotRepaired':True,'sourceNativeApiCoreCadExecuted':False,'referenceQualified':False,'electricalTimingQualified':False,'accepted49':False,'fabricationReady':False})
 assert passed
 outcomes.append({'variant':tag,'normalizedPair':pin(norm),'report':pin(report),'wholeLengthsMm':{n:special[n]['wholePlanarLengthMm']for n in names},'skewMm':pairSkew,'sharedSections':{n:special[n]['coupledSection']for n in names},'allStaticPass':passed})
print(json.dumps({'variants':outcomes,'wallSeconds':time.monotonic()-started,'referenceLaunchHoldExplicit':True,'actualAppsRun':False}))
