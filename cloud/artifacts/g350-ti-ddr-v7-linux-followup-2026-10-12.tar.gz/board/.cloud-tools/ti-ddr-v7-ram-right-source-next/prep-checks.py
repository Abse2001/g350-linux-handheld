"""Small guarded source-only validator and policy mocks; no Circuit/import/export."""
from pathlib import Path
import ast,hashlib,importlib.util,json,sys
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('v7_prep_scope',ROOT/'process_scope.py');scope=importlib.util.module_from_spec(spec);spec.loader.exec_module(scope)
policy={'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5};baseline=scope.memory()
def gate(current):
 if current['current']+policy['rssBytes']+2*1024**3>=policy['sharedBytes']:raise ValueError('Smallcheck headroom required')
 if any(current['events'][k]!=baseline['events'][k] for k in scope.OOM_KEYS):raise ValueError('New OOM before checks')
executions=[]
for name in ['validator','guard']:
 argv=[sys.executable,'-B',str(ROOT/(name+'.test.py'))];e=scope.run_guarded(argv,ROOT,ROOT/'checks'/name,policy,{'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(ROOT/'checks/tmp')},before_spawn=gate);executions.append({'name':name,'execution':e})
 if e['exitCode']!=0 or e['diagnosticStopped'] or not e['cleanupOwnedGroupEmpty']:raise ValueError('Meaningful source-only mock failed '+name)
for p in ROOT.glob('*.py'):ast.parse(p.read_text())
r={'allPassed':True,'executions':executions,'pythonSyntaxPassed':True,'actualCircuitCalls':0,'actualSourceExports':0,'actualSceneOrGridCalls':0,'actualRoutingPerformed':False,'accepted49':False};(ROOT/'checks/prep-checks.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'allPassed':True,'actualCircuitCalls':0}))
