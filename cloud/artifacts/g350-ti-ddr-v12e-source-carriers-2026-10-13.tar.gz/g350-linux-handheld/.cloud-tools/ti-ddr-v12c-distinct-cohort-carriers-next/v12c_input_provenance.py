"""Pure V12c singleton-cohort layer bridge. Existing geometry and actual V12b
final props are reused. No Core/native/router/CAD call or reference qualification.
"""
from pathlib import Path
import hashlib, json, stat, copy, importlib.util, sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PARENT=Path('/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12b-four-carrier-ddr-source-next')
PARENT_MANIFEST='14e6cdee6ac1d6dd3ee60179eec9eead19c49f3fb5670672cce438c7f6902103'
PARENT_MODULE='100b480c3c27adebb704c3aca67a59588fba89d9bff34c194df93c848217b459'
CAPTURE=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress/v12b-actual-react-next2/actual-final-props.json')
CAPTURE_SHA='c01e2b3f7444205fc602dbe7264384e9b1817aee22a519be54a57c09eec555f3'
RECEIPT=CAPTURE.parent/'RECEIPT.json'
RECEIPT_SHA='375dc16b34629941238373a77c774ce9a9c1015de37f26a09aced2be8f621ee8'
INPUT_SHA='8ec0070e5b11712cd75a00d1c3cb5b332b3da9587429385d0bb468e9c2715010'
BROAD_SHA='06a81bc88e38c7967545a77317c9f3b480b64865a2323fd1a305a2e481f3cb31'
LAYERS=['top','inner1','inner2','bottom']
CARRIERS={'DDR_RESET':'top','DDR_BYTE0':'bottom','DDR_BYTE1':'inner2','DDR_COMMAND_CLOCK':'inner1'}
def require(v,s):
    if not v: raise ValueError(s)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def verify_rows(base,rows):
    for row in rows:
        p=Path(row['path']) if base is None else base/row['path']
        require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Binding changed: '+str(p))
def verify(expected_manifest_sha256):
    require(sha(ROOT/'SOURCE-INPUT-manifest.json')==expected_manifest_sha256,'Exact frozen V12c source/input manifest required')
    m=load(ROOT/'SOURCE-INPUT-manifest.json');verify_rows(ROOT,m['files']);verify_rows(None,m['externalFiles'])
    require(sha(PARENT/'v12b_input_provenance.py')==PARENT_MODULE,'Frozen independent parent binder changed')
    spec=importlib.util.spec_from_file_location('g350_frozen_v12b_source_bridge',PARENT/'v12b_input_provenance.py');parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent)
    inherited=parent.verify(PARENT_MANIFEST)
    require(sha(CAPTURE)==CAPTURE_SHA and sha(RECEIPT)==RECEIPT_SHA,'Actual V12b final props/root receipt changed')
    actual_parent=parent.verify_actual_authored_props(CAPTURE);receipt=load(RECEIPT);execution=receipt['execution']
    require(receipt['passed'] is True and receipt['sourceHeld'] is True and receipt['sourceManifestSha256']==PARENT_MANIFEST and receipt['proof']==actual_parent and execution['exitCode']==0 and execution['diagnosticStopped'] is False and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values()),'Actual clean source-held V12b React evaluation required')
    require(sha(ROOT/'input.json')==INPUT_SHA and sha(ROOT/'original-unrestricted-input.json')==BROAD_SHA and sha(PARENT/'input.json')==BROAD_SHA,'Exact new singleton input and frozen all4 broad counterpart required')
    broad=load(ROOT/'original-unrestricted-input.json');expected=copy.deepcopy(broad)
    for b in expected['buses']:b['allowedLayers']=[CARRIERS[b['busId']]];b['preferredLayers']=[CARRIERS[b['busId']]]
    actual=load(ROOT/'input.json');require(actual==expected,'Only perbus allowed/preferred layer lists may change')
    require(actual['allowedLayers']==LAYERS and actual['layerCount']==4 and len(actual['connections'])==49 and len(actual['obstacles'])==856 and len(actual['traces'])==2,'Original fourlayer49/856/2 physical inventory/global allowance required')
    policy=load(ROOT/'v12c-layer-policy.json');require(actual['buses']==[g['nativeBus'] for g in policy['groups']] and policy['globalSignalLayers']==LAYERS,'Source policy must exactly match native singleton cohorts/global4')
    require(policy['referenceQualified'] is False and policy['TIplaneArrangement'] is False and policy['naturalGenericDefaultCap']==800000,'Reference compatibility/defaultcap must not be promoted')
    before=load(CAPTURE);expected_props=copy.deepcopy(before['authoredPolicyProof'])
    for g in expected_props['groups']:g['pcbAllowedLayers']=[CARRIERS[g['busId']]];g['preferredLayers']=[CARRIERS[g['busId']]]
    derived=load(ROOT/'derived-final-authored-props.json');require(derived['authoredPolicyProof']==expected_props and derived['actualV12bFinalPropsCaptureSha256']==CAPTURE_SHA and derived['referenceCopperCandidates']==before['referenceCopperCandidates'],'Only final cohort layer props change from actual V12b tree; reference candidates remain exact')
    require(derived['physicalGeometrySourceSha256']==inherited['freshCircuitSha256'] and derived['globalSignalLayerProjection']==LAYERS and derived['naturallyDerivedGenericDefaultCap']==800000,'Existing physical2312 geometry/global4/default800k held')
    for field in ['referenceQualified','TIplaneArrangement','actualV12ReactEvaluationPerformed','newCoreBuildPerformed','newNativePlacementCheckPerformed','accepted49','fabricationReady']:require(derived[field] is False,'Pure derivation/readiness flag must remain false: '+field)
    return {'scope':'PURE_V12C_DISTINCT_SINGLETON_COHORT_LAYER_SOURCE_BRIDGE_REFERENCE_PENDING','inputSha256':INPUT_SHA,'unrestrictedInputSha256':BROAD_SHA,'freshCircuitSha256':inherited['freshCircuitSha256'],'physicalInputExactlyHeld':True,'onlyLayerListsChanged':True,'nativePlacementChecks':17,'nativePlacementErrors':0,'nativePlacementChecksInheritedNotRerun':True,'routingRequests':49,'obstacles':856,'fixedReferences':2,'signalLayersAllowed':LAYERS,'cohortCarrierConstraints':CARRIERS,'naturallyDerivedGenericDefaultCap':800000,'explicitSearchCapSupplied':False,'referenceQualified':False,'TIplaneArrangement':False,'referenceRedesignStillRequired':True,'actualFinalReactEvaluationRequiredBeforeMain':True,'captureScript':str(ROOT/'capture-v12c-authored-props.ts'),'newCoreBuildPerformed':False,'nativeCoreOrRouterApiInvoked':False,'accepted49':False,'fabricationReady':False}
def verify_producer_inputs(producer_directory,expected_manifest_sha256):
    result=verify(expected_manifest_sha256);p=Path(producer_directory)
    require(sha(p/'input.json')==INPUT_SHA and sha(p/'original-unrestricted-input.json')==BROAD_SHA,'Producer inputs must match exact singleton cohort/broad source bridge')
    return result
def verify_actual_authored_props(path):
    d=load(ROOT/'derived-final-authored-props.json')
    expected={'scope':'PURE_ACTUAL_V12C_FINAL_REACT_PROPS_REFERENCE_UNQUALIFIED','actualFinalReactTreeEvaluated':True,'derivedProofSha256':sha(ROOT/'derived-final-authored-props.json'),'authoredPolicyProof':d['authoredPolicyProof'],'referenceCopperCandidates':d['referenceCopperCandidates'],'globalSignalLayerProjection':LAYERS,'naturallyDerivedGenericDefaultCap':800000,'referenceQualified':False,'TIplaneArrangement':False,'coreRenderCalled':False,'nativePlacementChecksInvoked':False,'routingSolverInstantiated':False,'accepted49':False,'fabricationReady':False}
    require(load(path)==expected,'Actual final V12c props differ from exact singleton cohort/reference-pending source bridge')
    return {'actualFinalReactTreeEvaluated':True,'captureSha256':sha(path),'derivedProofSha256':expected['derivedProofSha256'],'signalLayersAllowed':LAYERS,'cohortCarrierConstraints':CARRIERS,'naturallyDerivedGenericDefaultCap':800000,'referenceQualified':False,'TIplaneArrangement':False,'newCoreBuildPerformed':False,'newNativePlacementCheckPerformed':False,'accepted49':False,'fabricationReady':False}
