"""Own stdlib exact49/ownland/fullclass exposure audit of the frozenmanual37proposal, notSDK."""
s=open('/tmp/g350-actual299-source37-same-two-vias-I1-finite-trombones-v2-three-width-sourceonly.py').read();exec(s.split('for it in range(12):')[0])
PROPOSAL='/tmp/g350-actual299-source37-same-two-vias-I1-finite-trombones-v3-three-width-bank-report.json';bb=Path(PROPOSAL).read_bytes();assert hashlib.sha256(bb).hexdigest()=='c70a69a2c9e1eb13bf470fed9e0cde30574fc4c82ce8faf50890458e37cd531c';j=json.loads(bb);new=copy.deepcopy(j['bodyInverse']['after']);assert j['bodyInverse']['before']==bt['source_trace_37'];AF={**bt,'source_trace_37':new};OS=[o for o in oo if o['id']!=bt['source_trace_37']['pcb_trace_id']]+bodyobjects(new);sc=Scene(OS);reciprocal=[]
for n,t in AF.items():
 cs=sc.contacts(t);reciprocal.append({'owner':n,'foreignContacts':cs,'passed':not cs})
assert len(reciprocal)==49 and all(z['passed']for z in reciprocal)
reverse=[]
for t in f['traces']:
 if owner(t)=='source_trace_37':continue
 cs=[c for c in sc.contacts(t)if c['otherOwner']=='source_trace_37'];reverse.append({'owner':owner(t),'pcb_trace_id':t['pcb_trace_id'],'foreignContactsWith37':cs,'passed':not cs})
assert all(z['passed']for z in reverse)
viaReports=ownViaRows(new);assert len(viaReports)==2 and all(z['passed']for z in viaReports)
sm=selfreports(new);assert all(z['passedPureMath']for z in sm)
self3=[];cur=[]
for v in new['route']:
 if v.get('route_type')=='wire':cur.append(v)
 else:
  if len(cur)>1:self3.append({'layer':cur[0]['layer'],**self_math(cur,.3048)})
  cur=[]
if len(cur)>1:self3.append({'layer':cur[0]['layer'],**self_math(cur,.3048)})
foreign=[]
for i,(a,b)in enumerate(zip(new['route'],new['route'][1:])):
 if a.get('route_type')!=b.get('route_type')or a.get('route_type')!='wire'or a.get('layer')!=b.get('layer'):continue
 for n,pid,c,d,need in foreignWires:
  if a['layer']!=c['layer']:continue
  dist=sd(a,b,c,d)
  if dist<need-1e-8:foreign.append({'candidateSegment':i,'layer':a['layer'],'otherOwner':n,'otherId':pid,'actualCenterlineMm':dist,'requiredClassCenterlineMm':need,'source37GeometryChangedFrom299':not any(u.get('route_type')==v.get('route_type')=='wire'and u.get('layer')==v.get('layer')==a['layer']and sd(a,b,u,v)<1e-9 for u,v in zip(bt['source_trace_37']['route'],bt['source_trace_37']['route'][1:]))})
viaBefore=[v for v in bt['source_trace_37']['route']if v['route_type']=='via'];viaAfter=[v for v in new['route']if v['route_type']=='via'];assert len(viaBefore)==len(viaAfter)==2 and viaAfter[1]==viaBefore[1]
for key in viaBefore[0]:
 if key not in['x','y']:assert viaAfter[0][key]==viaBefore[0][key]
assert math.isclose(viaAfter[0]['x']-viaBefore[0]['x'],-.1,abs_tol=1e-10)and math.isclose(viaAfter[0]['y']-viaBefore[0]['y'],-.1,abs_tol=1e-10)
coh=[]
for b in f['buses']:
 rows=[{'owner':n,'wholeLengthMm':length(AF[n])+sum(length(t)for t in f['traces']if owner(t)==n)}for n in b['connectionNames']];vals=[z['wholeLengthMm']for z in rows];coh.append({'originalRule':b,'members':rows,'skewMm':max(vals)-min(vals),'minimumPassingOwners':[z['owner']for z in rows if b.get('minLength')is None or z['wholeLengthMm']>=b['minLength']-1e-8]})
ca=next(z for z in coh if z['originalRule']['busId']=='DDR_COMMAND_CLOCK');mv=[z['wholeLengthMm']for z in ca['members']if z['owner']in ca['minimumPassingOwners']];assert len(mv)==17 and max(mv)-min(mv)<=.635+1e-8
R={'scope':'OWN_STDLIB_LITERAL_ACTUAL299_ONLY37_MATCHED_FULL49_PHYSICAL_OWN_INLINE_LAND_AND_TI_EXPOSURE_NOT_NATIVE','inputPath':P299,'inputSha256':hashlib.sha256(B299).hexdigest(),'proposalPath':PROPOSAL,'proposalSha256':hashlib.sha256(bb).hexdigest(),'bodyInverse':j['bodyInverse'],'allOther48BodiesLiteral299':True,'fullFoundationLiteral299':True,'all263Traces1300Obstacles129ReferenceVias165References280HardwareBothPdnAndCapsHeld':True,'orderedBothNumericTopEndpointObjectsLiteral':new['route'][0]==bt['source_trace_37']['route'][0]and new['route'][-1]==bt['source_trace_37']['route'][-1],'carrierViaPhysicalEventInverses':[{'eventIndex':i,'before':a,'after':b}for i,(a,b)in enumerate(zip(viaBefore,viaAfter))],'exactTwoFullspanViaEvents':True,'secondCarrierViaObjectLiteral':True,'workingBranchInverses':[],'noWorkingBranchOrRequestOrPinDelta':True,'wholeBeforeMm':length(bt['source_trace_37'])+sum(length(t)for t in f['traces']if owner(t)=='source_trace_37'),'wholeAfterMm':j['wholeAfterMm'],'targetWindowMm':[20.950002,21.585658],'all49ReciprocalForeignReports':reciprocal,'all49ForeignContactsZero':True,'all263ForeignWorkingAndReferenceReverseReports':reverse,'ownInlineViaFirstExitReports':viaReports,'nativeStyleSelfMath':sm,'allThreeCompleteCohorts':coh,'caMinimumPassingCount':17,'caMatchedSubcohortSkewMm':max(mv)-min(mv),'fullCaSkewStillFailed':True,'typicalTiSpacingExposure':{'sameClass3WCenterlineMm':.3048,'otherDdrClass4WCenterlineMm':.4064,'proposedTromboneWidthsMm':[h['width']for h in j['history']],'selfThreeWidthReports':self3,'foreignSubGuidancePairs':foreign,'noExceptionWaiversApplied':True,'typicalGuidancePassed':not foreign and all(x['passedPureMath']for x in self3)},'nativeExecuted':False,'sourceCoreDerived':False,'cadExecuted':False,'all49Accepted':False,'wholeTiRoutingQualified':False,'timingPassed':False,'electricalTimingQualified':False,'fabricationReady':False}
out=Path('/tmp/g350-actual299-source37-matched21p2-three-width-full49-own-audit-report.json');out.open('x').write(json.dumps(R,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'whole':R['wholeAfterMm'],'all49':True,'inline':True,'caMinimumPassingCount':17,'self3Wfailures':[(x['layer'],len(x['failures']))for x in self3],'foreign3W4Wcount':len(foreign),'foreignOwners':sorted(set(x['otherOwner']for x in foreign))}))
