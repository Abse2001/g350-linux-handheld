"""Read-only V7 placement view; straight airwires are never routing evidence."""
import collections, hashlib, json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle, Polygon
from matplotlib.lines import Line2D

ROOT=Path('/workspace/g350-linux-handheld')
SRC=ROOT/'.cloud-tools/ti-ddr-v7-ram-right-source-next/run/fresh-layout.circuit.json'
OUT=ROOT/'.cloud-tools/ti-ddr-v7-ratsnest-preview-next'
raw=SRC.read_bytes(); sha=hashlib.sha256(raw).hexdigest()
assert sha=='2e81dc80bbeb7b9e687c5056a409979b0655592213fb993e9c029ae46bd847e7'
c=json.loads(raw)
by_type=collections.defaultdict(list)
for r in c: by_type[r['type']].append(r)
sources={r['source_component_id']:r for r in by_type['source_component']}
parts={r['pcb_component_id']:r for r in by_type['pcb_component']}
ports={r['source_port_id']:r for r in by_type['pcb_port']}
traces={r['source_trace_id']:r for r in by_type['source_trace']}
styles={'DDR_BYTE0':('#22b8b0','BYTE0 · 11 airwires'), 'DDR_BYTE1':('#b991ff','BYTE1 · 11 airwires'), 'DDR_COMMAND_CLOCK':('#f7b44b','Command / clock · 26 airwires'), 'DDR_RESET':('#fc6884','RESETn · 1 airwire')}
selected=[]
for bus in by_type['source_bus']:
 if bus['name'] not in styles: continue
 for tid in bus['source_trace_ids']:
  t=traces[tid]; endpoints=t['connected_source_port_ids']; assert len(endpoints)==2
  a,b=map(ports.__getitem__,endpoints)
  ownernames={sources[parts[p['pcb_component_id']]['source_component_id']]['name'] for p in [a,b]}
  assert ownernames=={'U_SOC','U_RAM'}
  selected.append({'name':t['name'],'id':tid,'group':bus['name'],'a':{'x':a['x'],'y':a['y']},'b':{'x':b['x'],'y':b['y']},'sourcePortIds':endpoints})
assert len(selected)==len({t['id'] for t in selected})==49
assert {t['id'] for t in selected}=={t['source_trace_id'] for t in by_type['source_trace'] if t.get('name','').startswith('DDR_')}
assert not any(t.get('source_trace_id') in {r['id'] for r in selected} for t in by_type['pcb_trace'])
assert len(sources)==280
cpu=next(p for p in parts.values() if sources.get(p.get('source_component_id'),{}).get('name')=='U_SOC')
ram=next(p for p in parts.values() if sources.get(p.get('source_component_id'),{}).get('name')=='U_RAM')
assert cpu['center']=={'x':0,'y':20} and cpu['rotation']==0
assert abs(ram['center']['x']-1.2)<1e-7 and ram['center']['y']==6 and ram['rotation']==270
board=by_type['pcb_board'][0]; assert board['num_layers']==4
bg='#101b2b'; padcolors={'top':'#c58a57','bottom':'#6291b6'}
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none'})

def plot(ax,zoom):
 ax.set_facecolor(bg)
 pts=board['outline']+[board['outline'][0]]
 ax.plot([v['x'] for v in pts],[v['y'] for v in pts],color='#d6e0ed',lw=1.1,zorder=2)
 # All actual top and bottom pads are overlaid, viewed from the top.
 for p in by_type['pcb_smtpad']:
  color=padcolors.get(p.get('layer'),'#8996a8'); kwargs={'facecolor':color,'edgecolor':'none','alpha':.58,'zorder':3}
  if p['shape']=='circle': q=Circle((p['x'],p['y']),p['radius'],**kwargs)
  elif p['shape'] in ['rect','rotated_rect']: q=Rectangle((p['x']-p['width']/2,p['y']-p['height']/2),p['width'],p['height'],angle=p.get('ccw_rotation',0),rotation_point='center',**kwargs)
  elif p['shape']=='polygon': q=Polygon([(v['x'],v['y']) for v in p['points']],**kwargs)
  else: raise RuntimeError('Unhandled pad shape '+p['shape'])
  ax.add_patch(q)
 for p in parts.values():
  name=sources.get(p.get('source_component_id'),{}).get('name','')
  if not name: continue
  ismajor=name in ['U_SOC','U_RAM']; center=p['center']
  color='#d6e0ed' if ismajor else padcolors.get(p['layer'],'#738297')
  ax.add_patch(Rectangle((center['x']-p['width']/2,center['y']-p['height']/2),p['width'],p['height'],fill=False,edgecolor=color,lw=1.1 if ismajor else .35,alpha=.9 if ismajor else .45,zorder=2))
 for t in selected:
  a,b=t['a'],t['b']; color=styles[t['group']][0]
  ax.plot([a['x'],b['x']],[a['y'],b['y']],color=color,lw=.75 if zoom else .48,alpha=.9,zorder=4)
  if zoom: ax.plot([a['x'],b['x']],[a['y'],b['y']],'.',color=color,ms=2.2,zorder=5)
 for v in by_type['pcb_via']:
  ax.add_patch(Circle((v['x'],v['y']),v['outer_diameter']/2,fill=False,edgecolor='#e2e8f0',lw=.7,zorder=6))
 for hole in by_type['pcb_hole']:
  ax.add_patch(Circle((hole['x'],hole['y']),hole['hole_diameter']/2,fill=False,edgecolor='#e2e8f0',lw=.5,zorder=3))
 if zoom:
  ax.set(xlim=(-11.5,13),ylim=(-.5,30.5))
  ax.text(-8.4,28.6,'U_SOC · AM3352 fixed at (0, 20)',color='#eaf0f8',fontsize=10,ha='left',va='center')
  ax.text(-8.4,-.0,'U_RAM: (1.2, 6), 270° · shifted right 1.2 mm',color='#eaf0f8',fontsize=9,ha='left',va='center')
  ax.annotate('RAM bypass caps remain close',xy=(7.7,8.6),xytext=(4.2,10.5),color='#b4c4d7',fontsize=8,ha='left',arrowprops={'arrowstyle':'->','color':'#b4c4d7','lw':.6},zorder=7)
  ax.annotate('Clear component corridor',xy=(0,10.1),xytext=(-10.8,10.3),color='#b4c4d7',fontsize=8,ha='left',arrowprops={'arrowstyle':'->','color':'#b4c4d7','lw':.6},zorder=7)
 else:
  ax.set(xlim=(-41,41),ylim=(-62,62))
  ax.add_patch(Rectangle((-11.5,-.5),24.5,31,fill=False,edgecolor='#e9edf5',lw=.8,linestyle='--',zorder=7))
  ax.text(15,20,'CPU / RAM\nzoom area',color='#d6e0ed',fontsize=8)
 ax.set_aspect('equal'); ax.set_xlabel('mm',color='#a7b7cd'); ax.set_ylabel('mm',color='#a7b7cd')
 ax.tick_params(colors='#a7b7cd',labelsize=8); ax.grid(color='#687991',alpha=.16,lw=.4)
 for spine in ax.spines.values(): spine.set_color('#445570')
 ax.set_title('CPU / RAM detail' if zoom else 'Whole PCB · 280 parts · provisional 76 × 118 mm',color='#d6e0ed',fontsize=10,pad=12)

handles=[Line2D([0],[0],color=v[0],lw=2,label=v[1]) for v in styles.values()]
handles.extend([Line2D([0],[0],marker='s',color='none',markerfacecolor=padcolors['top'],label='Top pads'),Line2D([0],[0],marker='s',color='none',markerfacecolor=padcolors['bottom'],label='Bottom pads')])
outputs=[]
for kind in ['overview','whole-board','cpu-ram-zoom']:
 if kind=='overview': fig,axes=plt.subplots(1,2,figsize=(13,10),gridspec_kw={'width_ratios':[.95,1.05]}); plot(axes[0],False); plot(axes[1],True)
 else:
  fig,ax=plt.subplots(figsize=(8,10)); plot(ax,kind=='cpu-ram-zoom')
 fig.patch.set_facecolor(bg)
 fig.suptitle('V7 placement — ratsnest, 49 DDR routes not completed',color='#f4f7fb',fontsize=14 if kind=='overview' else 10,y=.98)
 fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,.074),ncol=3,facecolor=bg,edgecolor='#425572',labelcolor='#d6e0ed',fontsize=8)
 fig.text(.5,.041,'Straight lines = airwires. Planned: Top / Bottom DDR; Inner1 GND / Inner2 DDR power reference planes.',ha='center',color='#c5d2e2',fontsize=8)
 fig.text(.5,.022,'Placement snapshot only · timing / full board checks unfinished · fabricationReady = false',ha='center',color='#fc9c9c',fontsize=8)
 fig.tight_layout(rect=(0,.13,1,.95))
 for ext in ['png','svg']:
  p=OUT/f'{kind}.{ext}'; assert not p.exists(); fig.savefig(p,dpi=180,facecolor=bg); outputs.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
 plt.close(fig)
assert SRC.read_bytes()==raw
info={'source':str(SRC),'sourceSha256':sha,'sourceRecords':len(c),'realParts':len(sources),'physicalLayers':board['num_layers'],'ddrAirwireCount':len(selected),'ddrSourceCopperCount':0,'classCounts':dict(collections.Counter(t['group'] for t in selected)),'cpu':cpu,'ram':ram,'coordinates':'millimeters; both outer-layer pads overlaid in top-view coordinates','status':'Placement ratsnest only; 49 DDR routes not completed','fabricationReady':False,'airwires':selected,'outputs':outputs}
(OUT/'info.json').write_text(json.dumps(info,indent=2)+'\n')
print(json.dumps({k:info[k] for k in ['sourceSha256','realParts','physicalLayers','ddrAirwireCount','ddrSourceCopperCount','classCounts','outputs']},indent=2))
