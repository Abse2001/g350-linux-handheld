"""Pure stdlib isolated owner-closed227 geometry hypothesis; no Source overlay."""
from pathlib import Path
import importlib.util,copy,json,math,hashlib,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def mod(name,p):
 sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
EP=BASE/'ddr-source31-canonical227-one-epoch-sourceonly-next/exact-canonical227-scene.py'
assert sha(EP)=='1fe0beefde7c332a4b0ef5f4d88131960ed9663af2cbf8be691e0dbd6a7b879c'
ec=mod('owned_move227_base',EP);q=ec.z
CLEAN=BASE/'ddr-reset10-context12-two-owned-breakout-227-sourceonly-next/FULL49_SOLVER_VIEW_RESET_BARREL_IDENTITY_CLEAN_PROJECTION03.json'
assert sha(CLEAN)=='9c239feb9937dff0e31ff46812278bcbf8c727b15572b539ad84ce9df835e39f'
full=copy.deepcopy(q.full);carrier=json.loads(CLEAN.read_text())
assert all(full[k]==carrier[k]for k in full if k!='connections')
moves={'source_trace_15':(4.,13.6),'source_trace_16':(4.,14.4)}
changes=[];oldIds={};newBranches={}
for n,new in moves.items():
 branches=[t for t in full['traces']if t.get('source_trace_id')==n];assert len(branches)==2
 branch=branches[0];oldIds[n]=branch['pcb_trace_id'];before=copy.deepcopy(branch)
 contact=next(c for c in full['connections']if c['name']==n)['pointsToConnect'][0]
 assert branch['route'][0]['x']==contact['x']and branch['route'][0]['y']==contact['y']
 via=next(p for p in branch['route']if p['route_type']=='via');old=(via['x'],via['y'])
 for point in branch['route'][1:]:point['x'],point['y']=new
 for point in branch['route'][2:]:
  if point['route_type']=='via':point['to_layer']='inner1'
  else:point['layer']='inner1'
 branch['source_only_proposed_cpu_relocation']=True;branch['original_cpu_branch_origin_id']=oldIds[n]
 c=next(c for c in carrier['connections']if c['name']==n);c['pointsToConnect'][0]['x'],c['pointsToConnect'][0]['y']=new
 # Real aliases must be derived from future Source/Core. Coordinate aliases
 # from an old physical barrel must not be presented as fresh IDs.
 for key in list(c['pointsToConnect'][0]):
  if key not in ['x','y','layer']:c['pointsToConnect'][0].pop(key)
 c['pointsToConnect'][0]['layer']='inner1'
 newBranches[n]=branch
 changes.append({'actualOriginalLogicalSourceTraceId':n,'actualNumericTopContact':contact,'oldSourceOnlyCpuBranchOriginId':oldIds[n],'oldCpuSite':old,'proposedOwnedCpuSite':new,'unchangedRamBranch':branches[1],'hypothesisCpuTopLead':branch,'existingOwnedCpuBarrelRelocatedNotAdded':True,'futureSourceViaPcbViaPcbPortIds':None,'beforePlanningBranch':before})
carrier['traces']=copy.deepcopy(full['traces'])
assert len(full['traces'])==263 and len(carrier['connections'])==49
assert sum(p['route_type']=='via'for t in full['traces']for p in t['route'])+len(q.native['referenceVias'])==227
assert full['connections']==q.full['connections']and full['buses']==q.full['buses']and full['differentialPairs']==q.full['differentialPairs']and full['obstacles']==q.full['obstacles']
fixed={}
for t in full['traces']:
 n=t.get('source_trace_id');fixed[n]=fixed.get(n,0.)+sum(math.dist((a['x'],a['y']),(b['x'],b['y']))for a,b in zip(t['route'],t['route'][1:])if a['route_type']==b['route_type']=='wire'and a['layer']==b['layer'])
def normalize(doc):
 rows=doc['records'];rows=list(rows.values())if isinstance(rows,dict)else rows;out={};raw={}
 for row in rows:
  n=row['sourceTraceId'];assert n not in out
  if n not in moves:
   x,y=q.normalize({'records':[row]});out.update(x);raw.update(y);continue
  assert row['layer']in['top','inner1','inner2','bottom']and row['role']in['DDR_BYTE0','BYTE0_DQS']
  path=[(p['x'],p['y'])if isinstance(p,dict)else tuple(p)for p in row['path']];assert len(path)>=2
  assert all(len(p)==2 and all(type(v)in[int,float]and math.isfinite(v)for v in p)for p in path)
  endpoints=next(c for c in carrier['connections']if c['name']==n)['pointsToConnect']
  assert math.dist(path[0],(endpoints[0]['x'],endpoints[0]['y']))<1e-8 and math.dist(path[-1],(endpoints[1]['x'],endpoints[1]['y']))<1e-8
  out[n]={'layer':row['layer'],'path':path};raw[n]=copy.deepcopy(row)
 return out,raw
class Scene(ec.Scene):
 def __init__(self,layer,records,target):
  super().__init__(layer,records,target);self.full,self.carrier=full,carrier
  for n,new in moves.items():self.terminals[n][0]=new
  removed={v for id in oldIds.values()for v in [id,id+':via']};items=self.items;self.items=[];self.buckets={}
  for item in items:
   if item['id']not in removed:self.add(dict(item))
  for n,xy in moves.items():
   x,y=xy;r=.4572/2+.1016/2+full['minTraceToPadEdgeClearance'];id='SOURCEONLY_OWNED_CPU_RELOCATION_'+n
   self.add({'kind':'circle','p':xy,'r':r,'owners':{n},'id':id+':via','bbox':(x-r,x+r,y-r,y+r)})
   if layer=='top':
    t=newBranches[n];a,b=[(p['x'],p['y'])for p in t['route'][:2]];required=q.p.normal_spacing(target,n,self.byclass,self.mates);self.segment(a,b,required,{n},id);self.items[-1].update(ddrOwner=n,localPieces=q.p.circlesplit(a,b,self.terminals[n]))
  assert self.counts['signalFullSpanBarrels']==98
 def exposure(self,path,name):
  pieces=[('new-main',i,a,b,self.layer)for i,(a,b)in enumerate(q.g.pairs(path))]
  for t in full['traces']:
   if t.get('source_trace_id')!=name:continue
   for i,(a,b)in enumerate(zip(t['route'],t['route'][1:])):
    if a['route_type']==b['route_type']=='wire'and(a['x'],a['y'])!=(b['x'],b['y']):pieces.append((t['pcb_trace_id'],i,(a['x'],a['y']),(b['x'],b['y']),a['layer']))
  scenes={self.layer:self};reports=[];total=0.;noneligible=0.
  for branch,i,a,b,layer in pieces:
   if layer not in scenes:scenes[layer]=Scene(layer,self.records,name)
   scene=scenes[layer];eligible=[];ineligible=[]
   for item in scene.items:
    if name in item['owners']or'ddrOwner'not in item or scene.pair_is_intrinsic(item['ddrOwner']):continue
    intervals=q.p.capsule_intervals(a,b,item['a'],item['b'],item['r']-1e-10);(eligible if scene.eligible(item['ddrOwner'])else ineligible).extend(intervals)
   union=q.p.merge(eligible);mm=sum((hi-lo)*math.dist(a,b)for lo,hi in union);total+=mm
   nou=q.p.merge(ineligible);nm=sum((hi-lo)*math.dist(a,b)for lo,hi in nou);noneligible+=nm
   reports.append({'branch':branch,'segment':i,'layer':layer,'normalDeficitParameterUnion':union,'normalDeficitLengthMm':mm,'nonEligibleNormalDeficitLengthMm':nm})
  return {'exactNormalDeficitUnionLengthMm':total,'includesActualMovedCpuTopLeadsAndOtherUnchangedStubs':True,'absoluteTICapMm':31.75,'absoluteTICapPass':total<=31.75+1e-8,'nonEligibleNormalDeficitLengthMm':noneligible,'noResetOrIntrinsicPairSpacingException':noneligible<=1e-8,'segments':reports,'reciprocalOtherConductorAuditRequired':True}
