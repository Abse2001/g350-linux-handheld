"""Own stdlib full independent peer; dynamic proof pin with literal318 anchor."""
from pathlib import Path
import argparse,hashlib,json
ap=argparse.ArgumentParser();ap.add_argument('--proof',required=True);ap.add_argument('--proof-sha',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
assert len(args.proof_sha)==64 and all(x in '0123456789abcdef'for x in args.proof_sha)
out=Path(args.output);assert not out.exists()
ownpeer=Path('/tmp/g350-actual318-four-body20-23-25-36-independent-pure-peer-sourceonly.py').read_text().rsplit('\nreport=',1)[0]
ownpeer=ownpeer.replace("PR='/tmp/g350-actual318-four-body20-23-25-36-exhaustive-new-wire-TI3W4W-proof-report.json';PS='56e8a547dcf6a643e5e666e3c647c71c8d4f37811e24320773cc1127614ea32f'",'PR='+repr(args.proof)+';PS='+repr(args.proof_sha))
exec(ownpeer)
strong=[]
for n in ids:
 legacy=[];new=[]
 for run in split(after[n]):
  s=self_math([q for i,q in run],.3048)
  for z in s['failures']:
   a,b=z['segments'];ii=[run[k][0]for k in[a,a+1,b,b+1]];held=all(k<len(before[n]['route'])and strict(after[n]['route'][k],before[n]['route'][k])for k in ii);row={'localSegments':z['segments'],'wholeRouteIndices':ii,'allFourEndpointObjectsHeldLiteral':held,'geometry':z}
   (legacy if held else new).append(row)
 assert not new,(n,new[:2]);strong.append({'owner':n,'retainedLegacyFailureCount':len(legacy),'introducedFailureCount':len(new),'allRetainedFailureRows':legacy,'introducedFailureRows':new})
wholeForeign=[]
for n in ids:
 newidx=newedges(n);legacy=[];introduced=[]
 for a in mats(after[n]):
  if a['kind']!='wire':continue
  for o in foreignwire:
   if o['owner']==n or not(set(a['layers'])&set(o['layers'])):continue
   need=.3048 if classes[n]==classes[o['owner']]else .4064;d=sd(a['a'],a['b'],o['a'],o['b'])
   if d<need-1e-8:
    row={'candidateSegment':a['index'],'foreignOwner':o['owner'],'foreignSegment':o.get('index'),'centerDistanceMm':d,'requiredMm':need,'candidateEdgeNew':a['index']in newidx}
    (introduced if row['candidateEdgeNew']else legacy).append(row)
 assert not introduced,(n,introduced[:2]);wholeForeign.append({'owner':n,'retainedLegacyCount':len(legacy),'introducedNewEdgeCount':len(introduced),'retainedRows':legacy,'introducedRows':introduced})
R={'scope':'INDEPENDENT_OWN_STDLIB_CURRENT318_ALL49_FOUR_BODY_NATIVE_PHYSICAL_ALL25_AND_EVERY_NEW_EDGE_3W4W_ALL_CHANGED_OWNER_STRONG_SELF_CLASSIFICATION','proofPath':PR,'proofSha256':PS,'inputPath':pr['inputPath'],'inputSha256':pr['inputSha256'],'bodyOwnersChanged':ids,'other45BodiesLiteral':True,'wholeFoundationLiteral':True,'all49ReciprocalRows':rows,'all263ReverseRows':rev,'nativeSelfMath':selfrows,'ownBarrelFirstExitNoReentryAudit':own,'headings':headings,'all25AndAllOtherNewEdgeExhaustive3W4WAudit':guidance,'everyChangedOwnerStrongSelfLegacyClassification':strong,'everyChangedOwnerWholeForeignLegacyClassification':wholeForeign,'wholeChangedMm':{n:whole(after[n])for n in ids},'completeCohorts':cohorts,'actualCarrier25ViasPhysicalOnly':via25,'SDKExecuted':False,'nativeExecuted':False,'sourceCoreDerived':False,'all49Accepted':False,'fullBoardTIQualification':False,'timingPassed':False,'fabricationReady':False,'independentPureFullPeerPassed':True}
out.open('x').write(json.dumps(R,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'all49ForeignZero':True,'all263ReverseZero':True,'allNewForeignGuidanceZero':True,'allNewStrongSelfFailuresZero':True,'selfLegacyCounts':{x['owner']:x['retainedLegacyFailureCount']for x in strong},'foreignLegacyCounts':{x['owner']:x['retainedLegacyCount']for x in wholeForeign},'whole':R['wholeChangedMm'],'CAcount':ca['minimumPassingCount']}))
