"""Exact V3 two-via/two-stub delta, then unchanged V2 inventory validator."""
import copy,math
from validate_layout import validate as validate_v2

def require(value,message):
    if not value: raise ValueError(message)

def validate(base,compiled,table,declarations):
    added_components=[e for e in compiled if e['type']=='pcb_component' and e.get('source_component_id','').startswith('source_manually_placed_via_')]
    added_source_ports=[e for e in compiled if e['type']=='source_port' and e.get('source_component_id','').startswith('source_manually_placed_via_')]
    via_component_ids={e['pcb_component_id'] for e in added_components}
    via_source_port_ids={e['source_port_id'] for e in added_source_ports}
    added_pcb_ports=[e for e in compiled if e['type']=='pcb_port' and e['source_port_id'] in via_source_port_ids]
    declared_traces=[e for e in compiled if e['type']=='source_trace' and e.get('name') in ['TI_RAM7_POWER_BYPASS','TI_RAM7_GROUND_BYPASS']]
    require(len(added_components)==2 and len(added_source_ports)==4 and len(added_pcb_ports)==4,'Exact two via components/four alias ports required')
    require(len(declared_traces)==2,'Exact two new bypass source traces required')
    trace_ids={e['source_trace_id'] for e in declared_traces}
    vias=[e for e in compiled if e['type']=='pcb_via']
    traces=[e for e in compiled if e['type']=='pcb_trace']
    require(len(vias)==len(traces)==2,'Only two manual bypass traces and two physical vias permitted')
    require({e['source_trace_id'] for e in traces}==trace_ids,'Unexpected imported signal copper')
    nets={e['source_net_id']:e['name'] for e in compiled if e['type']=='source_net'}
    expected={'DDR_1V5':(6.65,8.55),'GND':(6.45,7.95)}
    for e in vias:
        name=nets.get(e.get('source_net_id'))
        require(name in expected,'Unexpected via net')
        x,y=expected[name]
        require(abs(e['x']-x)<1e-7 and abs(e['y']-y)<1e-7,'Changed bypass via location')
        require(e['layers']==['top','inner1','inner2','bottom'],'Full-depth four-layer via required')
        require(abs(e['outer_diameter']-.4572)<1e-7 and abs(e['hole_diameter']-.254)<1e-7,'Changed full-depth via process')
    expected_routes={
        'TI_RAM7_POWER_BYPASS':[(6.65,8.55),(6.020116,8.55)],
        'TI_RAM7_GROUND_BYPASS':[(6.45,7.95),(5.779884,7.95),(5.179884,8.55)],
    }
    source_trace_names={e['source_trace_id']:e['name'] for e in declared_traces}
    for e in traces:
        route=e['route'];wanted=expected_routes[source_trace_names[e['source_trace_id']]]
        require(len(route)==len(wanted),'Bypass route vertices changed')
        for p,(x,y) in zip(route,wanted):
            require(p['route_type']=='wire' and p['layer']=='bottom' and abs(p['width']-.2)<1e-7,'Unexpected bypass route primitive')
            require(abs(p['x']-x)<1e-7 and abs(p['y']-y)<1e-7,'Compiled manual bypass differs from reviewed geometry')
        for a,b in zip(route,route[1:]):
            dx,dy=abs(a['x']-b['x']),abs(a['y']-b['y'])
            require(max(dx,dy)>1e-7 and (min(dx,dy)<1e-7 or abs(dx-dy)<1e-7),'Require nonzero orthogonal/45-degree stub')
    stripped=[e for e in compiled if not (
        e['type'] in ['pcb_trace','pcb_via','source_manually_placed_via'] or
        (e['type']=='source_trace' and e['source_trace_id'] in trace_ids) or
        (e['type']=='source_port' and e['source_port_id'] in via_source_port_ids) or
        (e['type']=='pcb_port' and e['source_port_id'] in via_source_port_ids) or
        (e['type']=='pcb_component' and e['pcb_component_id'] in via_component_ids)
    )]
    report=validate_v2(base,stripped,table,declarations)
    report.update(firstPhysicalReferenceBypassSourceQualified=True,physicalThroughVias=2,manualBypassTraces=2,additionalViaEndpointAliasPorts=4,originalComponents=280,originalPhysicalContacts=1161,originalDdrSignals=49,originalLogicalInventoryPreserved=True,compiledPlaneStackPresent=True,signalRoutingPerformed=False,actualBypassLoopsQualified=False,referenceContinuityQualified=False,electricalTimingQualified=False,fabricationReady=False)
    return report
