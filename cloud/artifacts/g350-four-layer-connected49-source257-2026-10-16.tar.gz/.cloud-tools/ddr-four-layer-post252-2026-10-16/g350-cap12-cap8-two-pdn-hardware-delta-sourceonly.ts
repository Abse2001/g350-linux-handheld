/** Pure Source-only hardware bridge. No I/O, Core/SDK imports or execution. */
import { deriveCap12HardwareDelta } from '/tmp/g350-cap12point79-hardware-delta-v2-sourceonly.ts'
type Row = Record<string, any>
export const COMBINED_PROFILE = 'CAP12_X0P79_CAP8_TWO_NEW_PDN_VIAS'
export const CAP8_PROFILE = 'CAP8_AT_0_7P9_TWO_NEW_PLANE_VIAS_VDD7P2'
export const CAP8_DESCRIPTOR_SHA = '20e698e6225f7aa0759aa4acf70103c5f90f3894ae94726336e098598b3f3976'
export const CAP8_PROOF_SHA = 'ec002642c791f3fdcd041e647202712020f9acccf20ced6e22302db20c5601c3'
const need = (v: unknown, label: string): void => { if (!v) throw Error(label) }
const clone = <T>(v: T): T => structuredClone(v)
const canonical = (v: any): string => Array.isArray(v) ? `[${v.map(canonical).join(',')}]`
  : v && typeof v === 'object' ? `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}` : JSON.stringify(v) ?? 'undefined'
const same = (a: unknown, b: unknown) => canonical(a) === canonical(b)
const one = (rs: Row[], label: string): Row => { need(rs.length === 1, label); return rs[0] }
const LAYERS = ['top', 'inner1', 'inner2', 'bottom']
const SPECS = [
  { sid: 'source_trace_986', id: 'pcb_trace_156', name: 'TI_HS_C_DDR_RAM_8_POWER', pin: 1,
    pad: 'pcb_smtpad_730', port: 'pcb_port_729', sourcePort: 'source_port_729', x: .420116,
    oldVia: 'pcb_via_54', oldViaSource: 'source_manually_placed_via_54', oldPort: 'pcb_port_1270',
    oldSelector: '.V_TI_HS_C_DDR_RAM_8_POWER > port.bottom', viaName: 'V_CAP8_REPLAY_DDR_1V5',
    netId: 'source_net_5', netName: 'DDR_1V5', xy: { x: .4, y: 7.2 },
    points: [{ x: .420116, y: 7.9 }, { x: .420116, y: 7.220116 }, { x: .4, y: 7.2 }] },
  { sid: 'source_trace_987', id: 'pcb_trace_157', name: 'TI_HS_C_DDR_RAM_8_GROUND', pin: 2,
    pad: 'pcb_smtpad_729', port: 'pcb_port_730', sourcePort: 'source_port_730', x: -.420116,
    oldVia: 'pcb_via_55', oldViaSource: 'source_manually_placed_via_55', oldPort: 'pcb_port_1272',
    oldSelector: '.V_TI_HS_C_DDR_RAM_8_GROUND > port.bottom', viaName: 'V_CAP8_REPLAY_GND',
    netId: 'source_net_0', netName: 'GND', xy: { x: -1.6, y: 7.4 },
    points: [{ x: -.420116, y: 7.9 }, { x: -1.4, y: 7.9 }, { x: -1.6, y: 7.7 }, { x: -1.6, y: 7.4 }] },
]
const find = (raw: Row[], type: string, key: string, id: string): Row =>
  one(raw.filter(r => r.type === type && r[key] === id), `One captured ${type} ${id}`)

/** The descriptor's SHA is supplied and checked by the CLI. This pure routine
 * also reconstructs every allowed effective scene delta from captured rows.
 * Reversing cap8 in an isolated model allows the frozen cap12 audit to remain
 * unchanged; neither a captured raw array nor any original input is edited. */
export function deriveCombinedHardwareDelta(raw: Row[], originalInput: Row, candidate: Row,
  candidateBinding: Row, descriptor: Row, descriptorBinding: Row): Row {
  need(candidateBinding && /^[a-f0-9]{64}$/.test(candidateBinding.sha256) && typeof candidateBinding.path === 'string', 'Mandatory new actual candidate binding')
  need(descriptorBinding?.sha256 === CAP8_DESCRIPTOR_SHA && typeof descriptorBinding.path === 'string'
    && descriptor.geometryProof?.sha256 === CAP8_PROOF_SHA, 'Exact reviewed cap8 descriptor/proof pins')
  const cap = candidate.cap8PlacementInverse
  need(same(cap, descriptor) && same(candidate.requiredSourceHardwarePlacementDeltas,
    [candidate.cap12PlacementInverse, descriptor]), 'Both exact complete hardware inverses required, in cap12/cap8 order')
  need(cap.name === 'C_DDR_RAM_8' && cap.source_component_id === 'source_component_132'
    && cap.pcb_component_id === 'pcb_component_132' && cap.inputSha256 === 'cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
    && cap.all280ComponentsPreserved === true && cap.all129OriginalFixedViasPreserved === true
    && cap.sourcePlacementAppliedByThisWorker === false && cap.freshSource === false
    && cap.futureFreshIds === null && cap.plannedNewPhysicalFullspanPdnViaCount === 2,
    'Exact original cap8 identity and explicit unrendered two-PDN plan')
  need(originalInput.obstacles?.length === 1298 && originalInput.traces?.length === 165
    && candidate.full49FanoutInput?.obstacles?.length === 1300, 'Original1298 plus exactly2 explicit new PDN obstacles')
  const scene = candidate.full49FanoutInput, reversed = clone(scene)
  need(cap.padObstacleInverses?.length === 2 && cap.fixedViaAliasInverses?.length === 2
    && cap.powerReferenceInverses?.length === 2 && cap.cap8PdnInsertions?.length === 2
    && cap.typedSmtPadInverses?.length === 2 && cap.typedPcbPortInverses?.length === 2
    && cap.sourceReferenceTargetInverses?.length === 2, 'Exact cap8 delta rosters')
  for (const r of [...cap.padObstacleInverses, ...cap.fixedViaAliasInverses]) {
    need(Number.isInteger(r.index) && same(reversed.obstacles[r.index], r.after), 'Exact cap8 after obstacle before inverse')
    reversed.obstacles[r.index] = clone(r.before)
  }
  for (const r of cap.powerReferenceInverses) {
    need(Number.isInteger(r.index) && same(reversed.traces[r.index], r.after), 'Exact cap8 after reference before inverse')
    reversed.traces[r.index] = clone(r.before)
  }
  for (const v of [...cap.cap8PdnInsertions].sort((a, b) => b.plannedObstacle.index - a.plannedObstacle.index)) {
    const n = v.plannedObstacle.index
    need(n === reversed.obstacles.length - 1 && same(reversed.obstacles[n], v.plannedObstacle.after), 'Only two exact appended PDN obstacles may be removed in isolated inverse view')
    reversed.obstacles.pop()
  }
  const cap12Stage = deriveCap12HardwareDelta(raw, originalInput, { ...candidate,
    full49FanoutInput: reversed }, candidateBinding)
  const effective = clone(cap12Stage.effectiveProjectionInput)
  const part = find(raw, 'pcb_component', 'pcb_component_id', 'pcb_component_132')
  const source = find(raw, 'source_component', 'source_component_id', 'source_component_132')
  const expectedPart = { ...clone(part), center: { x: 0, y: 7.9 }, display_offset_x: 0, display_offset_y: 7.9 }
  need(source.name === 'C_DDR_RAM_8' && part.source_component_id === source.source_component_id
    && same(part.center, { x: 1.2, y: 9.799999999999999 }) && part.rotation === 0 && part.layer === 'bottom'
    && same(cap.componentInverse, { before: part, after: expectedPart }), 'Only exact cap8 XY/display translation; all other captured component properties held')
  const typedSmtPads: Row[] = [], typedPcbPorts: Row[] = [], references: Row[] = [], pdnVias: Row[] = []
  for (const s of SPECS) {
    const pad = find(raw, 'pcb_smtpad', 'pcb_smtpad_id', s.pad), port = find(raw, 'pcb_port', 'pcb_port_id', s.port)
    need(pad.pcb_component_id === part.pcb_component_id && pad.pcb_port_id === s.port
      && port.pcb_component_id === part.pcb_component_id && port.source_port_id === s.sourcePort
      && pad.shape === 'rect' && pad.layer === 'bottom' && same(port.layers, ['bottom'])
      && pad.width === .499999 && pad.height === .540004, 'Actual two semantic cap8 pad/port owners')
    for (const [list, key, before, output] of [
      [cap.typedSmtPadInverses, 'pcb_smtpad_id', pad, typedSmtPads],
      [cap.typedPcbPortInverses, 'pcb_port_id', port, typedPcbPorts],
    ] as any[]) {
      const r = one(list.filter((q: Row) => q.before[key] === before[key]), 'One exact typed cap8 inverse')
      need(same(r, { before, after: { ...clone(before), x: s.x, y: 7.9 } }), 'Only exact translated cap8 typed XY')
      output.push(clone(r))
    }
    const obstacle = one(cap.padObstacleInverses.filter((q: Row) => q.before.obstacleId === s.pad), 'One cap8 pad obstacle')
    const expectedObstacle = { ...clone(obstacle.before), center: { x: s.x, y: 7.9 } }
    need(same(effective.obstacles[obstacle.index], obstacle.before) && same(obstacle.after, expectedObstacle)
      && obstacle.before.circuitJsonMetadata?.pcb_smtpad_id === s.pad
      && obstacle.before.circuitJsonMetadata?.pcb_port_id === s.port && obstacle.before.componentId === part.pcb_component_id,
      'Cap8 obstacle is genuine captured numeric pad with exact translation')
    effective.obstacles[obstacle.index] = clone(obstacle.after)
    const target = one(cap.sourceReferenceTargetInverses.filter((q: Row) => q.originalSourceTraceId === s.sid), 'One explicit original-to-planned Source endpoint inverse')
    const sourceTrace = find(raw, 'source_trace', 'source_trace_id', s.sid), oldVia = find(raw, 'pcb_via', 'pcb_via_id', s.oldVia)
    const oldViaSource = find(raw, 'source_manually_placed_via', 'source_manually_placed_via_id', s.oldViaSource)
    const oldPort = find(raw, 'pcb_port', 'pcb_port_id', s.oldPort)
    const oldSourcePort = find(raw, 'source_port', 'source_port_id', oldPort.source_port_id)
    const net = find(raw, 'source_net', 'source_net_id', s.netId)
    need(net.name === s.netName && same(sourceTrace.connected_source_net_ids, [s.netId])
      && same(sourceTrace.connected_source_port_ids, [s.sourcePort, oldPort.source_port_id])
      && oldVia.source_net_id === s.netId && oldViaSource.source_net_id === s.netId
      && oldSourcePort.source_component_id === oldViaSource.source_manually_placed_via_id
      && oldSourcePort.name === 'bottom' && oldVia.pcb_port_ids.includes(s.oldPort)
      && same(oldVia.layers, LAYERS) && oldVia.outer_diameter === .4572 && oldVia.hole_diameter === .254,
      'Genuine original same-rail Source/net/terminal authority; no geometry union')
    need(target.beforeSelector === s.oldSelector && target.afterSelector === `.${s.viaName} > port.bottom`
      && same(target.sourceTraceBefore, sourceTrace) && same(target.unchangedSourceNetIds, [s.netId])
      && same(target.beforeTarget, { pcbVia: oldVia, viaSource: oldViaSource, pcbPort: oldPort, sourcePort: oldSourcePort })
      && target.afterTarget.kind === 'PLANNED_SOURCE_VIA_BOTTOM' && target.afterTarget.viaName === s.viaName
      && same(target.afterTarget.xy, s.xy) && target.afterTarget.connectsTo === `net.${s.netName}`
      && target.afterTarget.futureFreshIds === null && target.noNewNumericPcbPortId === true,
      'Captured logical target removed explicitly; new IDs remain future')
    const v = one(cap.cap8PdnInsertions.filter((q: Row) => q.name === s.viaName), 'One planned PDN declaration')
    need(v.x === s.xy.x && v.y === s.xy.y && v.fromLayer === 'top' && v.toLayer === 'bottom'
      && same(v.layers, LAYERS) && v.outerDiameter === .4572 && v.holeDiameter === .254
      && v.connectsTo === `net.${s.netName}` && v.sourceNet.source_net_id === s.netId
      && v.sourceNet.provenanceOnlyCapturedNetIds === true && v.plannedIdsAreSourceIdentitiesOnly === true
      && v.futureFreshIds === null && v.plannedBottomPointId === target.afterTarget.pointId
      && v.plannedObstacle.index === effective.obstacles.length
      && v.plannedObstacle.after.circuitJsonMetadata?.plannedSourceIdentityOnly === true
      && v.plannedObstacle.after.circuitJsonMetadata?.pcb_port_id === null
      && v.plannedObstacle.after.circuitJsonMetadata?.source_port_id === null
      && !v.plannedObstacle.after.circuitJsonMetadata?.pcb_via_id,
      'New physical material is explicitly planned, never a captured via or numeric alias')
    effective.obstacles.push(clone(v.plannedObstacle.after)); pdnVias.push({ ...clone(v), innerLayers: ['inner1', 'inner2'] })
    const alias = one(cap.fixedViaAliasInverses.filter((q: Row) => q.before.circuitJsonMetadata?.pcb_via_id === s.oldVia), 'One old-reference alias inverse')
    const expectedAlias = clone(alias.before); expectedAlias.connectedTo = expectedAlias.connectedTo.filter((id: string) => id !== s.sid)
    need(same(effective.obstacles[alias.index], alias.before) && same(alias.after, expectedAlias), 'Original fixed barrel geometry and all other rail aliases held')
    effective.obstacles[alias.index] = clone(alias.after)
    const r = one(cap.powerReferenceInverses.filter((q: Row) => q.before.pcb_trace_id === s.id), 'One captured cap8 reference replacement')
    const captured = find(raw, 'pcb_trace', 'pcb_trace_id', s.id)
    need(same(r.before, { ...captured, connection_name: s.sid }) && same(effective.traces[r.index], r.before)
      && r.after.source_trace_id === s.sid && r.after.pcb_trace_id === s.id
      && same(r.after.route.map((p: Row) => ({ x: p.x, y: p.y })), s.points)
      && r.after.route.every((p: Row) => p.route_type === 'wire' && p.layer === 'bottom' && p.width === .2)
      && r.after.route[0].start_pcb_port_id === s.port
      && r.after.route.at(-1).pointId === v.plannedBottomPointId
      && !('pcb_port_id' in r.after.route.at(-1)) && !('end_pcb_port_id' in r.after.route.at(-1))
      && !('source_port_id' in r.after.route.at(-1)), 'Exact width.2 Bottom route ends on declared planned target without fake authentic IDs')
    effective.traces[r.index] = clone(r.after)
    const from = `C_DDR_RAM_8.pin${s.pin}`, to = `.${s.viaName} > port.bottom`
    references.push({ name: s.name, literalTraceName: s.name, originalSourceTraceId: s.sid,
      capturedPcbTraceId: s.id, fromSelector: from, beforeToSelector: s.oldSelector, toSelector: to,
      width: .2, before: clone(r.before), after: clone(r.after), absolutePoints: clone(s.points),
      relativeAnchorSelector: 'U_SOC.pin7', relativeAnchorXY: { x: 0, y: 20 }, beforeRouteProps: { pcbPath: [] },
      afterRouteProps: { pcbPaths: [[from, ...s.points.slice(1, -1).map(p => ({ x: p.x, y: p.y - 20 })), to]], pcbPathRelativeTo: 'U_SOC.pin7' } })
  }
  const ids = new Set(originalInput.traces.map((r: Row) => r.pcb_trace_id))
  need(same(scene.obstacles, effective.obstacles) && same(scene.traces.filter((r: Row) => ids.has(r.pcb_trace_id)), effective.traces),
    'Complete effective input equals only four pad translations, four reference replacements, two old alias removals and two planned PDN insertions')
  need(effective.obstacles.filter((o: Row) => o.circuitJsonMetadata?.pcb_via_id).length === 129
    && effective.obstacles.filter((o: Row) => o.circuitJsonMetadata?.planned_pdn_via_id).length === 2,
    'All129 captured physical reference barrels plus two separately declared new barrels')
  const cap8HardwareDelta = { profile: CAP8_PROFILE, candidateBinding: clone(candidateBinding),
    descriptorBinding: clone(descriptorBinding), proofBinding: clone(cap.geometryProof),
    component: { name: source.name, before: clone(part), after: clone(expectedPart), sourceComponent: clone(source),
      sourcePlacement: { before: { pcbX: 1.2, pcbY: 9.799999999999999, layer: 'bottom', pcbRotation: 0 },
        after: { pcbX: 0, pcbY: 7.9, layer: 'bottom', pcbRotation: 0 } } },
    typedSmtPads, typedPcbPorts, references, pdnVias,
    innerPortRegistrations: pdnVias.flatMap(v => ['inner1', 'inner2'].map(layer => ({ viaName: v.name, layer,
      xy: { x: v.x, y: v.y }, role: v.role, futureFreshIds: null }))),
    sourceEndpointInverses: clone(cap.sourceReferenceTargetInverses), padObstacleInverses: clone(cap.padObstacleInverses),
    fixedViaAliasInverses: clone(cap.fixedViaAliasInverses), originalDeclaration: clone(cap),
    sourceApplied: false, freshCoreDerived: false, capturedIdsAreMappingProvenanceOnly: true,
    regeneratedPlaneContinuityQualified: false, nativeQualified: false, cadQualified: false,
    all49Accepted: false, electricalTimingPassed: false, fabricationReady: false }
  return { hardwareDeltaProfile: COMBINED_PROFILE, cap12HardwareDelta: cap12Stage.cap12HardwareDelta,
    cap8HardwareDelta, effectiveProjectionInput: effective }
}
