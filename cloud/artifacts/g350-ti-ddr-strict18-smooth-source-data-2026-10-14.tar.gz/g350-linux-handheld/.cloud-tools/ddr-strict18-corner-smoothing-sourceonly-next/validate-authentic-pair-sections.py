"""Finite translations of pinned original shared/exterior API, with controls."""
import json,math,copy,importlib.util,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('stable_geometry',HERE/'smooth-corners-stable.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
DATA=HERE/'NORMALIZED_STRICT18_THREE_CORNER_SMOOTHING_LENGTH_RESTORED.json';d=json.loads(DATA.read_bytes());new={r['sourceTraceId']:r for r in d['records']};full=m.full
DQS1=m.ROOT/'ddr-byte1-pair-ripup-sourceonly-next/DQS1_LEFT_SHARED_U_13_7_WITH_DQ26_LEFT_TRUNK_TRIAL02.json';clock=Path('/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-clock-pair-static-followthrough-next/finite-fully-paired-result-v11.json');ds=json.loads(DQS1.read_bytes());ck=json.loads(clock.read_bytes())
sections={n:r['coupledSection']for n,r in new.items()if 'coupledSection'in r}
sections['source_trace_27']=ds['candidates']['source_trace_27']['coupledSection']
sections.update(ck['coupledSections'])
oldsections={n:r['coupledSection']for n,r in m.original.items()if 'coupledSection'in r};oldsections.update({n:c['coupledSection']for n,c in ds['candidates'].items()});oldsections.update(ck['coupledSections'])
WIDTH=.1016;allowed=(WIDTH+.12)/math.cos(math.pi/8)-WIDTH+.002

def pair_shared(records,names,sectionmap):
 out=[]
 for n,mate in zip(names,names[::-1]):
  sec=sectionmap.get(n);p=records[n]['path'];other=records[mate]['path']
  if not sec or not 0<=sec[0]<sec[1]<len(p):return {'matched':False,'reason':'Invalid shared section'}
  lengths=0.;mn=math.inf;mx=-math.inf;err=0.;samples=0
  for a,b in zip(p[sec[0]:sec[1]],p[sec[0]+1:sec[1]+1]):
   a,b=m.xy(a),m.xy(b);span=math.dist(a,b);count=max(1,math.ceil(span/.002));lengths+=span;err=max(err,span/(2*count));samples+=count
   for j in range(count):
    f=(j+.5)/count;point=(a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f);gap=min(m.m.g.pointseg(point,m.xy(c),m.xy(e))for c,e in zip(other,other[1:]))-WIDTH;mn=min(mn,gap);mx=max(mx,gap)
  out.append({'sourceTraceId':n,'section':sec,'sharedCopperMm':lengths,'minEdgeGapMm':mn,'maxEdgeGapMm':mx,'samplingErrorMm':err,'samples':samples,'matched':lengths>0 and mx+err<=allowed})
 return {'connectionNames':names,'maxAllowedEdgeGapMm':allowed,'conductors':out,'matched':all(q['matched']for q in out)}
# Exact native package field construction, without enlarging from routed trunks.
pads=[o for o in full['obstacles']if o.get('componentId')];regions={}
def include(box,p,rx,ry=None):
 ry=rx if ry is None else ry;box[0]=min(box[0],p['x']-rx);box[1]=max(box[1],p['x']+rx);box[2]=min(box[2],p['y']-ry);box[3]=max(box[3],p['y']+ry)
for p in pads:
 box=regions.setdefault(p['componentId'],[math.inf,-math.inf,math.inf,-math.inf]);angle=math.radians(p.get('ccwRotationDegrees',0));include(box,p['center'],(abs(math.cos(angle))*p['width']+abs(math.sin(angle))*p['height'])/2,(abs(math.sin(angle))*p['width']+abs(math.cos(angle))*p['height'])/2)
for t in full['traces']:
 vs=[p for p in t['route']if p['route_type']=='via']
 if len(vs)!=1 or not t['route']:continue
 first=t['route'][0];owners=[o for o in pads if math.dist(m.xy(o['center']),m.xy(first))<1e-4]
 if not owners:continue
 owner=owners[0];v=vs[0];rad=v.get('via_diameter',full.get('minViaPadDiameter',.6))/2;angle=math.radians(owner.get('ccwRotationDegrees',0));clear=full['minTraceToPadEdgeClearance'];rx=(abs(math.cos(angle))*owner['width']+abs(math.sin(angle))*owner['height'])/2+rad+clear;ry=(abs(math.sin(angle))*owner['width']+abs(math.cos(angle))*owner['height'])/2+rad+clear
 if abs(v['x']-first['x'])>rx+.001+1e-4 or abs(v['y']-first['y'])>ry+.001+1e-4:continue
 include(regions[owner['componentId']],v,rad)
margin=WIDTH+.12/2+full['minTraceToPadEdgeClearance'];regions={n:[b[0]-margin,b[1]+margin,b[2]-margin,b[3]+margin]for n,b in regions.items()}
def within(p,b):return b[0]<=p['x']<=b[1]and b[2]<=p['y']<=b[3]
def exterior_intervals(a,b,boxes):
 inside=[]
 for box in boxes:
  lo,hi=0.,1.
  for axis,x,y in [('x',box[0],box[1]),('y',box[2],box[3])]:
   delta=b[axis]-a[axis]
   if abs(delta)<1e-15:
    if a[axis]<x or a[axis]>y:lo,hi=1,0;break
   else:p,q=(x-a[axis])/delta,(y-a[axis])/delta;lo=max(lo,min(p,q));hi=min(hi,max(p,q))
  if lo<hi:inside.append([lo,hi])
 out=[];end=0.
 for lo,hi in sorted(inside):
  if lo>end:out.append([end,lo])
  end=max(end,hi)
 if end<1:out.append([end,1.])
 return out

def pair_exterior(records,names):
 fields=[]
 for end in [0,-1]:
  boxes=[b for b in regions.values()if all(within(records[n]['path'][end],b)for n in names)]
  if boxes:fields.append(boxes[0])
 if len(fields)!=2:return {'connectionNames':names,'applicable':False,'matched':True,'fields':fields}
 mx=-math.inf;err=0;sep=0;lengths=0;samples=0
 for n,mate in zip(names,names[::-1]):
  p=records[n]['path'];other=records[mate]['path']
  for a,b in zip(p,p[1:]):
   span=math.dist(m.xy(a),m.xy(b))
   for lo,hi in exterior_intervals(a,b,fields):
    count=max(1,math.ceil((hi-lo)*span/.002));step=(hi-lo)*span/count;err=max(err,step/2);lengths+=(hi-lo)*span;samples+=count
    for j in range(count):
     f=lo+(hi-lo)*(j+.5)/count;point=(a['x']+(b['x']-a['x'])*f,a['y']+(b['y']-a['y'])*f);gap=min(m.m.g.pointseg(point,m.xy(c),m.xy(e))for c,e in zip(other,other[1:]))-WIDTH;mx=max(mx,gap)
     if gap+step/2>allowed:sep+=step
 return {'connectionNames':names,'applicable':True,'nativePackageFields':fields,'matched':sep==0,'maxExteriorEdgeGapMm':mx,'samplingErrorMm':err,'separatedExteriorLengthMm':sep,'exteriorLengthMm':lengths,'samples':samples}

if __name__=='__main__':
 actual=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-strict18-fresh-core-native-api-sourceonly-next/run-native/actual-original-all3-pair-api.json');previous=json.loads(actual.read_bytes());checks=[];oldshared=[];oldexterior=[];newshared=[];newexterior=[]
 for pair in full['differentialPairs']:
  names=pair['connectionNames'];old=pair_shared(m.original,names,oldsections);oldext=pair_exterior(m.original,names);oldshared.append(old);oldexterior.append(oldext);expected=next(v for v in previous['shared']if v['connectionNames']==names);expectedext=next(v for v in previous['exterior']if v['connectionNames']==names)
  # Independent exact-source translation calibrated to actual original TS APIs,
  # before applying changed Source geometry. Never label this TS execution.
  assert old['matched']==expected['matched']and oldext['matched']==expectedext['matched']
  assert abs(max(v['maxEdgeGapMm']for v in old['conductors'])-expected['maxEdgeGapMm'])<1e-10
  assert abs(oldext['maxExteriorEdgeGapMm']-expectedext['maxExteriorEdgeGapMm'])<1e-10
  assert abs(oldext['separatedExteriorLengthMm']-expectedext['separatedExteriorLengthMm'])<1e-10
  checks.append({'names':names,'actualOriginalTsSharedExteriorCalibrationPass':True})
  newshared.append(pair_shared(new,names,sections));newexterior.append(pair_exterior(new,names))
 assert all(q['matched']for q in newshared+newexterior)
 controls=[]
 def record(name,predicate):
  assert predicate,name;controls.append({'name':name,'refused':True})
 for n in ['source_trace_15','source_trace_16','source_trace_28']:
  record('Frozen sharp '+n,any(t['turnDegrees']>45.2 for t in m.turns(m.original[n]['path'])))
 for names in [['source_trace_15','source_trace_16'],['source_trace_28','source_trace_27']]:
  record('Stale original shared annotations '+','.join(names),not pair_shared(new,names,oldsections)['matched'])
 record('Missing shared annotation',not pair_shared(new,['source_trace_15','source_trace_16'],{})['matched'])
 record('Crossing cannot use smooth-bend exemption',not m.selfcheck([{'x':0,'y':0},{'x':1,'y':1},{'x':0,'y':1},{'x':1,'y':0}])['clear'])
 tiny,_,_=m.fillet(m.original['source_trace_15']['path'],[1],.01)
 record('Microfillet cannot waive returning arm',not m.selfcheck(tiny)['clear'])
 other=copy.deepcopy(new);other['source_trace_28']['path'][-1]['x']+=.4
 record('Changed genuine endpoint',other['source_trace_28']['path'][-1]!=m.original['source_trace_28']['path'][-1])
 ns=copy.deepcopy(sections);ns['source_trace_28']=[25,10000]
 record('Out of range shared annotation',not pair_shared(new,['source_trace_28','source_trace_27'],ns)['matched'])
 # Exterior geometry ignores annotation, so a one-point metadata-only corridor
 # cannot conceal a genuine separated trunk.
 foreign=copy.deepcopy(new);foreign['source_trace_15']['path'][19]['y']+=.5
 record('Real separated shared copper',not pair_shared(foreign,['source_trace_15','source_trace_16'],sections)['matched'])
 report={'scope':'SOURCE_ONLY_PINNED_API_TRANSLATION_SHARED_EXTERIOR_AND_NEGATIVE_CONTROLS','normalizedSha256':m.sha(DATA),'actualOriginalApiReportPath':str(actual),'actualOriginalApiReportSha256':m.sha(actual),'all3OriginalApiCalibration':checks,'frozenOriginalShared':oldshared,'frozenOriginalExterior':oldexterior,'newShared':newshared,'newExterior':newexterior,'preciseSectionBindings':sections,'negativeControls':controls,'all3SharedAndExteriorStaticTranslationsPass':True,'originalTsExecuted':False,'actualNativeExecuted':False,'actualCoreExecuted':False,'accepted49':False,'fabricationReady':False}
 out=HERE/'PAIR_SECTION_CONTROLS.json';out.write_text(json.dumps(report,indent=2)+'\n');evidence=HERE/'UPDATED_AUTHENTIC_PAIR_SECTIONS.json';evidence.write_text(json.dumps({'scope':'EXACT_CURRENT18_SMOOTHED_SOURCE_PAIR_GEOMETRY_SECTIONS','normalizedPath':str(DATA),'normalizedSha256':m.sha(DATA),'original49InputSha256':m.sha(m.FULL),'candidates':{n:{'layer':new[n]['layer'],'path':new[n]['path'],'coupledSection':s}for n,s in sections.items()},'oldDqs1EvidencePath':str(DQS1),'oldDqs1EvidenceSha256':m.sha(DQS1),'frozenClockPath':str(clock),'frozenClockSha256':m.sha(clock),'sectionsAreGenuinePhysicalGeometryNotRetaggedOldIndices':True,'freshCoreAndOriginalApisStillRequired':True,'accepted49':False,'fabricationReady':False},indent=2)+'\n')
 print(json.dumps({'reportSha256':m.sha(out),'evidenceSha256':m.sha(evidence),'negativeControls':len(controls),'shared':newshared,'exterior':newexterior}))
