"""Finite stdlib future23 actual-artifact contract. No SDK/CAD imports.
The Root fills actual prerequisite hashes only after authentic collected0.
"""
import hashlib,json,math,re,stat
from pathlib import Path
BOARD=Path('/workspace/g350-linux-handheld');HERE=Path(__file__).parent
SOURCE_SHA='68798e7d9132d01d15cd2b67db31fdfe5d18bc745c86defd39de9e598129d565'
NATIVE_SOURCE_SHA='9dbdfc5e2eba4176fe695a68423059b15656cc746789f8c9239da968a9b735f1'
SIGNAL_PROPOSAL=BOARD/'.cloud-tools/ddr-owner23-display-offset-compact-source-successor-next/source23-proposal.json'
SIGNAL_SHA='ce3dd042546465740ca0f9d720a37a96406de7efe2afb8ac4aa40dff047b3a5a'
RAW=CONTROLS=RAW_SHA=CONTROLS_SHA=ACTUAL_NATIVE_COLLECTION=ACTUAL_NATIVE_REPORT=ACTUAL_API=ACTUAL_RESULT=None
STATE=None
def require(v,label):
 if not v:raise ValueError(label)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def regular(p):
 p=Path(p);require(p.is_absolute()and p.is_file()and not p.is_symlink(),'Absolute regular artifact');return p
def load(row):
 require(isinstance(row,dict)and isinstance(row.get('path'),str)and isinstance(row.get('sha256'),str)and re.fullmatch('[0-9a-f]{64}',row['sha256']),'Concrete actual binding, no placeholder')
 p=regular(row['path']);require(p.stat().st_size<=32*1024*1024 and sha(p)==row['sha256'],'Exact finite actual artifact');return json.loads(p.read_bytes())
def binding(row):
 p=regular(row['path']);require(p.stat().st_size==row['bytes']and stat.S_IMODE(p.stat().st_mode)==row['mode']and sha(p)==row['sha256'],'Exact Source binding')
def one(rows,label):
 require(len(rows)==1,label+'; matches='+str(len(rows)));return rows[0]
def near(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])<1e-8
def index(raw,kind):
 rows=[r for r in raw if r['type']==kind];out={r[kind+'_id']:r for r in rows};require(len(rows)==len(out),'Unique actual '+kind);return out
def collected(row):
 c=load(row);require(c.get('authorizedByRoot')is True and c.get('toolSessionCollected')is True and c.get('passed')is True and c.get('toolExitCode')==c.get('toolWrapperExitCode')==0 and isinstance(c.get('toolSessionId'),int),'Actual successful collected Root natural0')
 post=load({'path':c['postauditPath'],'sha256':c['postauditSha256']});e=post['execution'];require(c['execution']==e and e['exitCode']==0 and e['diagnosticStopped']is False and e['cleanupOwnedGroupEmpty']is True and not any(e['oomDelta'].values()),'Actual natural child0/closed/OOM0')
 require(c['sourceAndDependenciesHeld']is True and post['sourceAndDependenciesHeld']is True and post['passed']is True,'Source/SDK held0')
 for prefix,digest in [('dependencies','ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'),('solverDependencies','47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6')]:require(post[prefix+'Before']==post[prefix+'After']and post[prefix+'After']['treeSha256']==digest,'Complete ce3/476 held')
 require(post['accepted49']is False and post['fabricationReady']is False,'Partial acceptance remains explicit');return c,post
def produced(post,row):
 key='resultFileBindings'if post.get('scope')=='ACTUAL_ROOT_GENUINE_SOURCE_OWNER_MOVED_227_JOINT23'else'outputFiles'
 require(any(r['path']==row['path']and r['sha256']==row['sha256']for r in post[key]),'Actual collected output required');return load(row)
def authority(row,manifest_sha,scope):
 global STATE,RAW,CONTROLS,RAW_SHA,CONTROLS_SHA,ACTUAL_NATIVE_COLLECTION,ACTUAL_NATIVE_REPORT,ACTUAL_API,ACTUAL_RESULT
 a=load(row);require(a.get('authorizedByRoot')is True and a.get('scope')==scope and a.get('sourceManifestSha256')==manifest_sha and a.get('actualPreviousScopesCollectedAndEmpty')is True and a.get('noConcurrentRootWorker')is True and a.get('rootFullWorkerReadPassed')is True,'Fresh Root serial/full-read authority')
 require(a['genuineSourceManifestSha256']==SOURCE_SHA and a['actualNativeSourceManifestSha256']==NATIVE_SOURCE_SHA,'Exact corrected23 Source and reviewed Native source')
 for key in ['actualCoreCollection','actualCoreRaw','actualCoreControls','actualNativeCollection','actualNativeReport','actualOriginalApiReport','actualNativeStageResult']:load(a[key])
 STATE=a;RAW=Path(a['actualCoreRaw']['path']);RAW_SHA=a['actualCoreRaw']['sha256'];CONTROLS=Path(a['actualCoreControls']['path']);CONTROLS_SHA=a['actualCoreControls']['sha256'];ACTUAL_NATIVE_COLLECTION=a['actualNativeCollection'];ACTUAL_NATIVE_REPORT=a['actualNativeReport'];ACTUAL_API=a['actualOriginalApiReport'];ACTUAL_RESULT=a['actualNativeStageResult'];return a
def actual_core():
 require(STATE is not None,'Actual Root bindings required first');c,post=collected(STATE['actualCoreCollection']);require(c['sourceManifestSha256']==post['sourceManifestSha256']==SOURCE_SHA and c['phase']==post['phase']=='core'and c['coreCalls']==1,'Actual corrected Source23 Core0, never timed-out raw alone')
 raw=produced(post,STATE['actualCoreRaw']);controls=produced(post,STATE['actualCoreControls']);require(controls['rawCorePath']==str(RAW)and controls['rawCoreSha256']==RAW_SHA and controls['freshCoreControlPassed']is True and len(controls['checks'])==29 and all(c['passed']is True for c in controls['checks']),'Actual all29 fresh Core controls')
 require(controls['sourceNumericAndPhysicalIdsDerivedWithoutAssignment']is True and controls['circuitJsonGeometryEdited']is False and controls['automaticCoreSrjForThisForkMustNotBeUsed']is True and controls['expectedOriginalCarrierCount']==23 and controls['expectedMissingOriginalSignalCount']==26,'Genuine23/manual fork/26 missing')
 return raw,controls
def native_outputs():
 c,post=collected(ACTUAL_NATIVE_COLLECTION);report=produced(post,ACTUAL_NATIVE_REPORT);api=produced(post,ACTUAL_API);result=produced(post,ACTUAL_RESULT)
 require(c['sourceManifestSha256']==post['sourceManifestSha256']==report['sourceManifestSha256']==result['sourceManifestSha256']==NATIVE_SOURCE_SHA,'Actual reviewed Native source1a190')
 require(result['passed']is True and [(r['phase'],r['exitCode'])for r in result['commands']]==[('native',0),('original3pairAPI',0)],'Both actual Native and original API children0')
 require(c['packetSha256']==post['packetSha256']==result['packetSha256']==report['packetSha256']==api['packetSha256'],'Same authentic Native/API bound packet')
 require(result['actualCoreSha256']==report['actualCoreSha256']==api['actualCoreSha256']==RAW_SHA and result['actualCoreControlsSha256']==report['actualCoreControlsSha256']==CONTROLS_SHA,'Same actual fresh23 raw/control hashes')
 require(result['actualNativeReportPath']==ACTUAL_NATIVE_REPORT['path']and result['actualNativeReportSha256']==ACTUAL_NATIVE_REPORT['sha256']and result['actualOriginal3PairApiReportPath']==ACTUAL_API['path']and result['actualOriginal3PairApiReportSha256']==ACTUAL_API['sha256'],'Actual child report hashes')
 require(report['checkCount']==len(report['counts'])==18 and not any(report['counts'].values())and report['physicalErrors']==0 and report['actualNativePairFindings']==[]and report['physicalCpuRamConnectedCarrierCount']==23,'Native18/all3pair findings0/23 graphs')
 require(api['allOriginalApiLoaded23ChecksPassed']is True and api['exactMaterialHeld']is True and api['actualCompleteOriginalSignalCount']==23 and api['expectedMissingOriginalSignalCount']==26,'All actual original API predicates passed on23')
 require(api['fullOriginalBusRostersAndConstraintsHeld']is True and api['originalFullDifferentialPairArrayUnchanged']is True and api['originalPrivateContinuousApiImplementationsUnchanged']is True,'All original49 rules held')
 for key in ['shared','exterior','coupling','pairLengths']:require(len(api[key])==3 and all(r['matched']is True for r in api[key]),'All3 original '+key+' predicates')
 require(len(api['continuity'])==23 and all(r['pathVisible']and r['selfClear']and r['conventionalAngles']and r['segmentsVisible']and all(r['segmentsVisible'])for r in api['continuity']),'All23 continuous/self/angle predicates')
 require(len(api['loadedCohortBusReports'])==3 and all(r['aboveMinimumLength']and r['withinLengthLimit']and r['matched']for r in api['loadedCohortBusReports']),'All original loaded-cohort bounds')
 for obj in [report,api,result]:require(obj['accepted49']is False and obj['fabricationReady']is False and obj['referenceQualified']is False,'No broader qualification')
 return report,post
def derive_owned(raw,controls,proposal):
 report,_=native_outputs();proof=report['actualOwnershipProof'];kinds=['pcb_via','pcb_trace','pcb_port','source_port','pcb_component','source_component','source_trace','source_manually_placed_via'];ix={k:index(raw,k)for k in kinds}
 require([len(ix[k])for k in ['pcb_via','pcb_trace','pcb_component','source_component','pcb_port']]==[227,286,507,280,1651],'Exact fresh227/286/507/280/1651')
 signals=proof['signalMappings'];carriers=proof['carriers'];require(len(signals)==98 and len(carriers)==23 and len(proof['referenceMappings'])==165,'Native authentic98/23/165 proofs')
 require(len({s['actualViaId']for s in signals})==98 and len({s['actualPcbTraceId']for s in signals})==98,'Unique actual signal barrels/stubs')
 for s in signals:
  owner=one([o for o in proposal['all98NumericOwnedSignalBranches']if o['viaName']==s['sourceViaName']],'Actual Source named via branch')
  numeric=ix['pcb_port'][s['actualNumericPcbPortId']];sp=ix['source_port'][numeric['source_port_id']];part=ix['source_component'][sp['source_component_id']]
  require(part['name']+'.pin'+str(sp['pin_number'])==owner['numericSelector']and near(numeric,owner['padXY']),'Real numeric package/pad')
  via=ix['pcb_via'][s['actualViaId']];top=ix['pcb_port'][s['actualTopPcbPortId']];trace=ix['pcb_trace'][s['actualPcbTraceId']]
  require(near(via,owner['viaXY'])and via['layers']==['top','inner1','inner2','bottom']and via['outer_diameter']==.4572 and via['hole_diameter']==.254 and via['from_layer']=='top'and via['to_layer']=='bottom','Real fullspan barrel')
  require(top['pcb_port_id']in via['pcb_port_ids']and top['layers']==['top']and near(top,via)and ix['source_port'][top['source_port_id']]['source_component_id']==s['sourceViaOwnerId'],'Actual same-owner alias')
  require(trace['source_trace_id']==s['actualPhysicalSourceTraceId']and len(trace['route'])==2 and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in trace['route'])and {trace['route'][0].get('start_pcb_port_id'),trace['route'][-1].get('end_pcb_port_id')}=={numeric['pcb_port_id'],top['pcb_port_id']},'Actual true Top dogbone ownership/geometry')
 for c in carriers:
  paths=[t for t in ix['pcb_trace'].values()if t['source_trace_id']==c['originalSourceTraceId']];require(len(paths)==3 and set(c['actualDirectPcbTraceIds'])=={t['pcb_trace_id']for t in paths},'Exactly3 actual Source-owned paths')
  d=one([d for d in proposal['selected23OriginalCarriers']if d['originalSourceTraceId']==c['originalSourceTraceId']],'Original selected Source carrier')
  body=ix['pcb_trace'][c['actualCarrierPcbTraceId']];require(c['carrierLayer']==d['carrierLayer']and len(body['route'])==len(d['expectedCarrierPath'])and all(p['route_type']=='wire'and p['layer']==c['carrierLayer']and p['width']==.1016 and near(p,q)for p,q in zip(body['route'],d['expectedCarrierPath'])),'Authentic complete carrier')
  require(body['route'][0].get('start_pcb_port_id')==c['actualCpuCarrierLayerPcbPortId']and body['route'][-1].get('end_pcb_port_id')==c['actualRamCarrierLayerPcbPortId'],'Genuine actual carrier endpoints')
  require(c['actualSourceOwnedPhysicalGraph']['physicallyConnected']is True and c['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is True,'Native proved real numeric physical graph')
  whole=sum(math.hypot(b['x']-a['x'],b['y']-a['y'])for t in paths for a,b in zip(t['route'],t['route'][1:]));require(abs(whole-c['wholePlanarLengthMm'])<1e-8 and abs(whole-d['expectedWholePlanarMm'])<1e-8,'Actual all3-path planar length')
 require(len({c['originalSourceTraceId']for c in carriers})==23,'23 distinct original signals')
 segments=sum(a['x']!=b['x']or a['y']!=b['y']for t in ix['pcb_trace'].values()for a,b in zip(t['route'],t['route'][1:]));return ix,signals,carriers,segments
def native_prerequisite(authority,carriers):
 require(authority['actualNativeCollection']==ACTUAL_NATIVE_COLLECTION and authority['actualNativeReport']==ACTUAL_NATIVE_REPORT,'Same Root-bound Native prerequisite')
 report,post=native_outputs();require({c['originalSourceTraceId']for c in carriers}=={c['originalSourceTraceId']for c in report['actualOwnershipProof']['carriers']},'Same authentic23 proof');return report,post
