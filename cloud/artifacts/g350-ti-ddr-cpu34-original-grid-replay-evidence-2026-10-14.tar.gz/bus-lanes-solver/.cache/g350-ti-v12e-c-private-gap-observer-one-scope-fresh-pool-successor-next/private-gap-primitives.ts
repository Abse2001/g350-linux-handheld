/** SOURCE ONLY. No imports, I/O, installation, or routing on import.
 * Observe only the two synchronous RouteCandidatePool method boundaries.
 * The exact copied class origin still requires independent qualification.
 */
const names = ["unresolvedUnits", "conditionalRoutes"] as const
type Name = (typeof names)[number]
type Phase = 0 | 1 | 2
type Method = (this: unknown, ...args: unknown[]) => unknown

export function installPrivateGapPrimitives(
  prototype: object,
  clock: () => number,
  publish: (row: string, rolling: string) => void,
) {
  // Validate both own data descriptors before installing either wrapper.
  // No property read, accessor invocation, or inspection of solver state.
  const entries = names.map((name) => {
    const descriptor = Object.getOwnPropertyDescriptor(prototype, name)
    if (!descriptor || !("value" in descriptor) || typeof descriptor.value !== "function" ||
        descriptor.get !== undefined || descriptor.set !== undefined ||
        descriptor.configurable !== true || descriptor.writable !== true || descriptor.enumerable !== false)
      throw Error(`Expected original own configurable writable ${name} method`)
    return { name, descriptor, original: descriptor.value as Method,
      observed: undefined as Method | undefined, restored: false }
  })
  const rows: string[] = []
  const counts = { unresolvedUnits: { entered: 0, returned: 0, threw: 0 },
    conditionalRoutes: { entered: 0, returned: 0, threw: 0 } }
  let calls = 0, observationErrors = 0, overflows = 0
  function record(n: number, m: Name, p: Phase) {
    try {
      const time = clock()
      if (!Number.isFinite(time) || time < 0) { observationErrors++; return }
      const t = Math.round(time * 1000) / 1000
      if (!Number.isFinite(t) || t < 0) { observationErrors++; return }
      const row = JSON.stringify({ n, m, p, t }) + "\n"
      // Fixed ASCII method name and numeric scalars only. No arguments,
      // receivers, domains, geometry, return objects, or errors are retained.
      if (row.length > 128) { overflows++; return }
      rows.push(row)
      if (rows.length > 16) rows.shift()
      publish(row, rows.join(""))
    } catch { observationErrors++ }
  }
  for (const entry of entries) {
    entry.observed = function (this: unknown, ...args: unknown[]) {
      if (calls >= Number.MAX_SAFE_INTEGER) {
        overflows++
        return Reflect.apply(entry.original, this, args)
      }
      const n = ++calls
      counts[entry.name].entered++
      record(n, entry.name, 0)
      let result: unknown
      try {
        result = Reflect.apply(entry.original, this, args)
      } catch (error) {
        counts[entry.name].threw++
        record(n, entry.name, 2)
        throw error
      }
      counts[entry.name].returned++
      record(n, entry.name, 1)
      return result
    }
  }
  const installed: typeof entries = []
  try {
    for (const entry of entries) {
      Object.defineProperty(prototype, entry.name, { ...entry.descriptor, value: entry.observed })
      installed.push(entry)
    }
  } catch (error) {
    // Atomic installation for ordinary prototypes; proxies are unsupported.
    for (const entry of installed.reverse())
      Object.defineProperty(prototype, entry.name, entry.descriptor)
    throw error
  }
  return {
    snapshot: () => ({ calls, observationErrors, overflows,
      unresolvedUnits: { ...counts.unresolvedUnits }, conditionalRoutes: { ...counts.conditionalRoutes },
      retainedRows: rows.length, retainedGeometry: false, additionalOriginalCalls: 0 }),
    restore: () => {
      let all = true
      for (const entry of entries) {
        if (entry.restored) continue
        const current = Object.getOwnPropertyDescriptor(prototype, entry.name)
        if (current?.value !== entry.observed) { observationErrors++; all = false; continue }
        Object.defineProperty(prototype, entry.name, entry.descriptor)
        entry.restored = true
      }
      return all
    },
  }
}
