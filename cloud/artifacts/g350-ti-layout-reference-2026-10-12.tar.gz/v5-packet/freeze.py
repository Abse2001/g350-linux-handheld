"""Prepare frozen source-only export packet; never invokes Circuit/exporter."""
import importlib.util,json,os,re,shutil,stat,subprocess
from pathlib import Path
from inventory import sha,tree
ROOT=Path(__file__).resolve().parent;BOARD=Path('/workspace/g350-linux-handheld');ENTRY='experiments/am3352-g350-ti-top-bottom-ddr-v5-layout.circuit.tsx';POLICY={'wallSeconds':180,'rssBytes':4*1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
assert not (ROOT/'packet-manifest.json').exists() and not (ROOT/'source').exists() and not (ROOT/'run').exists()
visited=set()
def visit(relative):
 relative=Path(relative).as_posix()
 if relative in visited:return
 p=BOARD/relative;assert p.is_file() and not p.is_symlink(),str(p);visited.add(relative)
 if p.suffix not in ['.ts','.tsx','.mjs','.js']:return
 s=p.read_text()
 for m in re.finditer(r'(?:from\s*|import\s*|require\s*\()([\"\'])(\.[^\"\']+)\1',s):
  candidate=p.parent/m[2];possibles=[candidate,*[Path(str(candidate)+suffix) for suffix in ['.ts','.tsx','.json','.mjs','.js']]]
  found=next((q for q in possibles if q.is_file()),None);assert found is not None,(relative,m[2]);assert BOARD==found.resolve() or BOARD in found.resolve().parents
  visit(found.resolve().relative_to(BOARD))
visit(ENTRY)
for p in ['package.json','package-lock.json','bun.lock','tsconfig.json','tscircuit.config.json','scripts/patch-tscircuit-via-pad-check.mjs']:visit(p)
source=ROOT/'source';source.mkdir();external=[]
for name in sorted(visited):
 src=BOARD/name;target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target);external.append(dict(path=str(src),sha256=sha(src),bytes=src.stat().st_size,kind='original-source-import-closure'))
os.symlink(str(BOARD/'node_modules'),source/'node_modules')
(ROOT/'inputs').mkdir();baseline=BOARD/'dist/g350-ddr-clear-cpu-ram-corridor-1081/fresh-layout.circuit.json';shutil.copy2(baseline,ROOT/'inputs/base-layout.circuit.json');external.append(dict(path=str(baseline),sha256=sha(baseline),bytes=baseline.stat().st_size,kind='immutable-layout-reference'))
for name in ['AGENTS.md','cloud/CONTINUE_BOARD.md','scripts/prepare-g350-ram90-four-layer.mjs','scripts/tune-g350-ram90-native-lengths.mjs','experiments/am3352-g350-ti-top-bottom-ddr-v1-layout.circuit.tsx']:
 p=BOARD/name;external.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size,kind='preserved-dirty-or-v1-source'))
for name in ['circuit.json','native-input.json','metadata.json']:
 p=Path('/workspace/bus-lanes-solver/tests/fixtures/g350-am3352')/name;external.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size,kind='frozen-original-repro'))
node=BOARD/'.cloud-tools/node/bin/node';bun=BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'
for p in [node,bun]:external.append(dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size,kind='pinned-runtime'))
versions={'node':subprocess.check_output([str(node),'--version'],text=True).strip(),'bun':subprocess.check_output([str(bun),'--version'],text=True).strip()}
assert versions=={'node':'v25.6.1','bun':'1.3.14'}
pins={}
for name,expected in [('tscircuit','0.0.2821'),('@tscircuit/core','0.0.2107'),('@tscircuit/cli','0.1.2258'),('@tscircuit/checks','0.0.242')]:
 p=BOARD/'node_modules'/name/'package.json';version=json.loads(p.read_text())['version'];assert version==expected;pins[name]=version
assert sha(BOARD/'node_modules/@tscircuit/checks/dist/index.js')=='1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc'
deps=tree(BOARD/'node_modules');(ROOT/'dependency-tree.json').write_text(json.dumps(deps,indent=2)+'\n')
resolver=[]
for name in visited:
 p=Path(name).parent
 while p.as_posix()!='.':
  candidate=source/p/'node_modules'
  if str(candidate) not in resolver:assert not candidate.exists() and not candidate.is_symlink();resolver.append(str(candidate))
  p=p.parent
for p in [ROOT/'node_modules',ROOT.parent/'node_modules']:
 assert not p.exists() and not p.is_symlink();resolver.append(str(p))
files=[]
for current,dirs,names in os.walk(ROOT,followlinks=False):
 dirs[:]=[d for d in dirs if d!='__pycache__' and not (Path(current)/d).is_symlink()]
 for n in sorted(names):
  p=Path(current)/n
  if p.is_symlink():continue
  assert p.is_file();files.append(dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=sha(p),mode=stat.S_IMODE(p.stat().st_mode)))
files.sort(key=lambda r:r['path'])
D=[{'name':'G350_TI_V2_INNER1_GND','layer':'inner1','net':'GND','clearanceMm':.12,'cutoutMarginMm':.12,'boardEdgeMarginMm':.35,'unbroken':False},{'name':'G350_TI_V2_INNER2_DDR_1V5','layer':'inner2','net':'DDR_1V5','clearanceMm':.12,'cutoutMarginMm':.12,'outline':[{'x':-18,'y':-10},{'x':18,'y':-10},{'x':18,'y':33},{'x':-18,'y':33}],'unbroken':False}]
text=(source/'experiments/am3352-g350-ti-top-bottom-ddr-v2-layout.circuit.tsx').read_text();assert text.count('<copperpour ')==2 and text.count('cutoutMargin={.12}')==2 and 'cutoutMargin={.2}' not in text and 'unbroken' not in text.replace('// Normal refillable zones preserve holes/antipads; unbroken fixed copper','')
manifest=dict(schemaVersion=1,scope='one-ti-v5-first-reference-bypass-no-signal-routing-no-cad',policy=POLICY,sourceEntry=ENTRY,sourceFileCount=len(visited),originalCommand=[str(bun),str(BOARD/'node_modules/tscircuit/cli.mjs'),'build',ENTRY,'--routing-disabled','--disable-parts-engine'],freshOutput='source/dist/experiments/am3352-g350-ti-top-bottom-ddr-v5-layout/circuit.json',planeDeclarations=D,pinnedVersions=pins,pinnedRuntimeVersions=versions,nativeChecksPatchSha256='1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc',dependencyTree={k:v for k,v in deps.items() if k!='items'},dependencyTreeManifestSha256=sha(ROOT/'dependency-tree.json'),files=files,externalFiles=external,resolverMustRemainAbsent=sorted(resolver),actualCircuitExecuted=False,cadRequested=False,autoroutingRequested=False,requireRootReceiptBeforeActual=True,fabricationReady=False)
(ROOT/'packet-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'packetSha256':sha(ROOT/'packet-manifest.json'),'files':len(files),'externalFiles':len(external),'sourceFileCount':len(visited),'boardDependencies':manifest['dependencyTree'],'actualCircuitExecuted':False}))
