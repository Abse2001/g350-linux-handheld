Source-only fresh TI CA window proposal over the qualified actual C source and
unchanged measured E geometry. It changes exactly two CA bus props and the same
two fields in each corresponding native metadata sidecar. The actual C endpoint
maximum is14.6mm. TI SPRS717L printed p187 Table7-68 row13/note9 gives
CACLM=max Manhattan+7.62mm and nominal CACLM±1.27mm, hence20.95–23.49mm.
The original21.15–23.69mm window was derived from V7's14.8mm and explicitly
preserved through V9+0.2Y/V10. This fresh derivation tightens the upper bound
while lowering the placement-derived lower bound by the same0.2mm.

BYTE0/1 have no authored minimum; maxima13.2/14.4 remain unchanged. The .635mm
bus skew, .127mm pair skew, widths, gaps, clearances, all-four physical signal
layers and existing singleton C carriers, all49 identities, original hardware,
cap/reference X movement and native checker patch are held. The original actual
E Core and17 zero-error native placement checks are inherited, not rerun.
Continuous references, impedance/electrical delay and fabrication are unqualified.

Preparation imports no project source and starts no worker. After the previous
Root route closes, Root may authorize one original60s/1GiB/24GiB+2GiB bounded
pure React capture. Identity-clone depth matches the proposal, and all React
types/keys/children/props except the exact two CA values must remain equal.
The packet validates the original C provenance without editing any prior files.
No route, reference-plane, timing or fabrication pass follows from this capture.
