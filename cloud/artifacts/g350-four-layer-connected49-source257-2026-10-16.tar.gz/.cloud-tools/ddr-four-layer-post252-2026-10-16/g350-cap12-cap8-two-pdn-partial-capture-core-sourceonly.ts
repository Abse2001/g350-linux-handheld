/** UNEXECUTED CAP12 +.79 / CAP8 two-PDN successor. Root supplies its execution guard.
 * capture performs React literal replay/inverse only; core renders only after
 * a passed capture of the same immutable plan. No raw IDs are assigned/edited.
 * Core source/ID/graph checks are distinct from per-run, barrel and whole-route
 * physical qualification. This successor requires all49 routed owners and two
 * added net-declared PDN vias. Plane continuity remains unqualified.
 */
type Row = Record<string, any>
let lastDiagnosticStage = "main:not-started"
function stageDiagnostic(stage:string,event:"before"|"after"){
 lastDiagnosticStage=`${stage}:${event}`
 process.stderr.write(JSON.stringify({diagnostic:"CAP12_CAP8_TWO_PDN_CAPTURE_CORE_STAGE",stage,event,utc:new Date().toISOString()})+"\n")
}
const BOARD = "/workspace/g350-linux-handheld"
const PARENT = `${BOARD}/.cloud-tools/ddr-source33b-source32-d4-exact-roster-types-after86-source-stages-sourceonly-next/source33b.circuit.tsx`
const PARENT_SHA = "f111667616c88a06f09815a710521f589f5859710580a8760f29767477d5de95"
const PROPOSAL = `${BOARD}/.cloud-tools/ddr-source33b-source32-d4-exact-roster-types-after86-source-stages-sourceonly-next/source33b-proposal.json`
const PROPOSAL_SHA = "d80dd679d9597dec00f1a5f4e0a015f822ec9c632bdd377d3c27a8e79a66d357"
const PARENT_CAPTURE = {path:"/tmp/g350-source33b-three-stage-root-20261015-after85/capture/output/source-capture.json",sha256:"1cc06d44b5d4d56ca01cbc7b0dd7d78b9afeb077c67af4da121e393c9c334b16"}
const PARENT_RAW = {path:"/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json",sha256:"d2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607"}
const PARENT_CONTROLS = {path:"/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/core-controls.json",sha256:"26323d939bbab3aba376630d9ba3629fbbd2a0bbf5c2a3bec2765893e10f0bc9"}
const MANUFACTURER = {path:"/tmp/g350-source33b-ti-placement-length-audit-20261016.json",sha256:"d0e43302fe97e25862a963182647930e5c215b961980f45ceecbaad23ec83583"}
const CAP8_DESCRIPTOR = {path:"/tmp/g350-current243-cap8-two-declared-pdn-nodes-Vdd72-descriptor-v2-sourceonly.json",sha256:"20e698e6225f7aa0759aa4acf70103c5f90f3894ae94726336e098598b3f3976"}
const CAP8_PROOF = {path:"/tmp/g350-cap8-two-plane-vias-Vdd72-finite-report.json",sha256:"ec002642c791f3fdcd041e647202712020f9acccf20ced6e22302db20c5601c3"}
const CAP8_PROFILE = "CAP8_AT_0_7P9_TWO_NEW_PLANE_VIAS_VDD7P2"
const OVERLAY_DEPENDENCIES = [
 {path:"/tmp/g350-cap12point79-partial-replay-overlay-sourceonly.ts",sha256:"5022522eadef74bcb2fcb0c3c603339d7f9a18d6fa3bdc3c2754fcde7226d4b2"},
 {path:"/tmp/g350-source33b-partial-mixed-source-replay-overlay-v3-sourceonly.ts",sha256:"256bea71cd157fdedb1d58fdc19ec5f48880e1ddcf27644ec2a86f59669d3906"},
]
const CORE_PATH = `${BOARD}/node_modules/@tscircuit/core/dist/index.js`
const CORE_SHA = "97b8a4eb484630c3ce2bfc2d68588801484d85adf94785d8849a1d91c4404905"
function need(ok:unknown,message:string):asserts ok {if(!ok)throw Error(message)}
function canonical(value:any):string {return Array.isArray(value)?`[${value.map(canonical).join(",")}]`:value&&typeof value==="object"?`{${Object.keys(value).sort().map(k=>`${JSON.stringify(k)}:${canonical(value[k])}`).join(",")}}`:JSON.stringify(value)??"undefined"}
const omit=(row:Row,keys:string[])=>Object.fromEntries(Object.entries(row).filter(([k])=>!keys.includes(k)))
const close=(a:number,b:number)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=1e-8
const at=(a:Row,b:Row)=>!!a&&!!b&&close(a.x,b.x)&&close(a.y,b.y)
function geometrySame(a:any,b:any):boolean {if(typeof a==="number"&&typeof b==="number")return close(a,b);if(Array.isArray(a)||Array.isArray(b))return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((v,i)=>geometrySame(v,b[i]));if(a&&b&&typeof a==="object"&&typeof b==="object")return canonical(Object.keys(a).sort())===canonical(Object.keys(b).sort())&&Object.keys(a).every(k=>geometrySame(a[k],b[k]));return a===b}
function wireGeometry(route:Row[]):Row[]{const out:Row[]=[];for(const p of route){need(p.route_type==="wire","Source pcbPaths must serialize separate wire runs");const next={route_type:p.route_type,x:p.x,y:p.y,width:p.width,layer:p.layer},last=out.at(-1);if(!last||!at(last,next)||last.layer!==next.layer||!close(last.width,next.width))out.push(next)}return out}
function planar(route:Row[]):number{return route.slice(1).reduce((s,p,i)=>s+(p.route_type==="wire"&&route[i].route_type==="wire"&&p.layer===route[i].layer?Math.hypot(p.x-route[i].x,p.y-route[i].y):0),0)}
const viaGeometry=(v:Row)=>Object.fromEntries(["x","y","hole_diameter","outer_diameter","layers","from_layer","to_layer","tented_on_top","tented_on_bottom"].filter(k=>Object.prototype.hasOwnProperty.call(v,k)).map(k=>[k,v[k]]))
const sameRoster=(a:any[],b:any[])=>a.length===b.length&&new Set(a).size===a.length&&a.every(n=>b.includes(n))
function typedComponentOwnership(raw:Row[],realCount:number,viaCount:number){
 const parts=raw.filter(r=>r.type==="source_component"),vias=raw.filter(r=>r.type==="source_manually_placed_via"),physical=raw.filter(r=>r.type==="pcb_component"),actualVias=raw.filter(r=>r.type==="pcb_via"),partIds=parts.map(r=>r.source_component_id),viaIds=vias.map(r=>r.source_manually_placed_via_id),physicalIds=physical.map(r=>r.pcb_component_id)
 need(parts.length===realCount&&vias.length===viaCount&&actualVias.length===viaCount&&physical.length===realCount+viaCount
  &&partIds.every(id=>typeof id==="string")&&viaIds.every(id=>typeof id==="string")&&physicalIds.every(id=>typeof id==="string")
  &&new Set(partIds).size===realCount&&new Set(viaIds).size===viaCount&&new Set(physicalIds).size===realCount+viaCount
  &&partIds.every(id=>!viaIds.includes(id))
  &&physical.every(r=>Number(partIds.includes(r.source_component_id))+Number(viaIds.includes(r.source_component_id))===1)
  &&[...partIds,...viaIds].every(id=>physical.filter(r=>r.source_component_id===id).length===1),
  "Exact typed physical-component ownership bijection: real source parts plus actual manual-via sources; no unknown, duplicate or missing owner")
 return {pcbComponents:physical.length,realSourceParts:parts.length,sourceManuallyPlacedVias:vias.length,onePhysicalComponentPerTypedSourceOwner:true,unknownOwners:0}
}

async function main(){
 const args=new Map<string,string>();for(let i=2;i<process.argv.length;i+=2){const k=process.argv[i],v=process.argv[i+1];need(["--caller-intent","--stage","--plan","--plan-sha","--candidate-sha","--overlay","--overlay-sha","--output","--capture","--capture-sha","--raw-output","--input"].includes(k)&&v&&!args.has(k),`Invalid argument ${k}`);args.set(k,v)}
 need(args.get("--caller-intent")==="ROOT_AUTHORIZED_PARTIAL_MIXED_EDITABLE_REPLAY","Explicit Root caller intent required")
 const stage=args.get("--stage");need(stage==="capture"||stage==="core","Stage must be capture or core")
 need(args.has("--plan")&&args.has("--output")&&/^[a-f0-9]{64}$/.test(args.get("--plan-sha")??"")&&/^[a-f0-9]{64}$/.test(args.get("--candidate-sha")??""),"Plan/output and explicit actual plan/candidate SHA256 required")
 need(/^[a-f0-9]{64}$/.test(args.get("--overlay-sha")??""),"Explicit reviewed combined overlay SHA256 required")
 if(stage==="core")need(args.has("--capture")&&args.has("--raw-output")&&/^[a-f0-9]{64}$/.test(args.get("--capture-sha")??""),"Core requires explicit passed capture SHA256 and separate raw-output")
 const fs=await import("node:fs"),path=await import("node:path"),crypto=await import("node:crypto"),url=await import("node:url")
 const sha=(text:string|Buffer)=>crypto.createHash("sha256").update(text).digest("hex")
 const readPin=(pin:Row)=>{const data=fs.readFileSync(pin.path);need(sha(data)===pin.sha256,`Pin changed: ${pin.path}`);return JSON.parse(data.toString())}
 const write=(filename:string,value:any)=>{need(!fs.existsSync(filename),`Output exists: ${filename}`);fs.mkdirSync(path.dirname(filename),{recursive:true});fs.writeFileSync(filename,JSON.stringify(value,replacer,2)+"\n",{flag:"wx",mode:0o600})}
 const replacer=(_k:string,v:any)=>typeof v==="function"?{diagnosticFunction:v.name,sourceSha256:sha(v.toString())}:typeof v==="symbol"?{diagnosticSymbol:String(v),globalSymbolKey:Symbol.keyFor(v)??null}:v
 const normalized=(v:any)=>JSON.parse(JSON.stringify(v,replacer))
 const planPath=path.resolve(args.get("--plan")!),output=path.resolve(args.get("--output")!),overlayPath=path.resolve(args.get("--overlay")??"/tmp/g350-cap12-cap8-two-pdn-partial-replay-overlay-sourceonly.ts")
 need(sha(fs.readFileSync(overlayPath))===args.get("--overlay-sha"),"Combined overlay explicit SHA256 mismatch")
 for(const pin of OVERLAY_DEPENDENCIES)need(sha(fs.readFileSync(pin.path))===pin.sha256,`Frozen overlay dependency changed: ${pin.path}`)
 const rawPlanText=fs.readFileSync(planPath,"utf8"),rawPlan=JSON.parse(rawPlanText),planSha256=sha(rawPlanText)
 need(planSha256===args.get("--plan-sha"),"Explicit actual plan SHA256 mismatch")
 need(rawPlan.scope==="SOURCE33B_PARTIAL_MIXED_JOINED_EDITABLE_PLAN_SOURCE_PROJECTION_ONLY"&&rawPlan.partialLayerProfile==="compact-four-layer-partial","Explicit partial compact mixed-layer plan required")
 const coordinateFrame=rawPlan.pcbPathCoordinateFrame,frameRaw:Row[]=readPin(PARENT_RAW)
 const capturedOriginalComponentOwnership=typedComponentOwnership(frameRaw,280,230)
 need(capturedOriginalComponentOwnership.pcbComponents===510,"Exact captured raw510 =280 real parts +230 manual-via physical components")
 const cap12=rawPlan.cap12HardwareDelta
 need(cap12?.profile==="CAP12_TRANSLATE_X_0P79_ONLY"&&cap12.candidateBinding?.sha256===args.get("--candidate-sha"),"Only the exact declared CAP12 +.79 profile and actual candidate binding are allowed")
 need(canonical(cap12.capturedOriginalComponentOwnership)===canonical(capturedOriginalComponentOwnership),"CAP12 descriptor must bind the actual original510 typed component-owner bijection")
 const capturedCap=frameRaw.filter(r=>r.type==="pcb_component"&&r.pcb_component_id==="pcb_component_136"),capturedCapSource=frameRaw.filter(r=>r.type==="source_component"&&r.source_component_id==="source_component_136")
 need(capturedCap.length===1&&capturedCapSource.length===1&&capturedCapSource[0].name==="C_DDR_RAM_12"&&capturedCap[0].source_component_id===capturedCapSource[0].source_component_id,"Exact captured real CAP12 source and part identity required")
 const expectedCapAfter=structuredClone(capturedCap[0]);expectedCapAfter.center.x=6.79;expectedCapAfter.display_offset_x=6.79
 need(at(capturedCap[0].center,{x:6,y:4.7})&&capturedCap[0].display_offset_x===6&&capturedCap[0].rotation===180&&capturedCap[0].layer==="bottom"&&cap12.component?.name==="C_DDR_RAM_12"&&canonical(cap12.component.before)===canonical(capturedCap[0])&&canonical(cap12.component.sourceComponent)===canonical(capturedCapSource[0])&&geometrySame(cap12.component.after,expectedCapAfter),"Only CAP12 physical center/display-offset X may shift +.79; all source metadata and other part fields remain literal")
 need(canonical(cap12.component.sourcePlacement)===canonical({before:{pcbX:6,pcbY:4.7,layer:"bottom",pcbRotation:180},after:{pcbX:6.79,pcbY:4.7,layer:"bottom",pcbRotation:180}}),"Exact CAP12 source placement delta required")
 const padSpecs=[{id:"pcb_smtpad_738",port:"pcb_port_737",oldX:5.579884,newX:6.369884},{id:"pcb_smtpad_737",port:"pcb_port_738",oldX:6.420116,newX:7.210116}],referenceSpecs=[{sid:"source_trace_994",id:"pcb_trace_164",name:"TI_HS_C_DDR_RAM_12_POWER",from:"C_DDR_RAM_12.pin1",to:".V_TI_HS_C_DDR_RAM_12_POWER > port.bottom",start:"pcb_port_737",end:"pcb_port_1286",points:[{x:6.369884,y:4.7},{x:5.469884,y:3.8},{x:5.2,y:3.8}]},{sid:"source_trace_995",id:"pcb_trace_165",name:"TI_HS_C_DDR_RAM_12_GROUND",from:"C_DDR_RAM_12.pin2",to:".V_TI_HS_C_DDR_RAM_12_GROUND > port.bottom",start:"pcb_port_738",end:"pcb_port_1288",points:[{x:7.210116,y:4.7},{x:6.8,y:4.289884},{x:6.8,y:3.8}]}]
 need(Array.isArray(cap12.typedSmtPads)&&cap12.typedSmtPads.length===2&&Array.isArray(cap12.typedPcbPorts)&&cap12.typedPcbPorts.length===2&&Array.isArray(cap12.references)&&cap12.references.length===2,"Exactly two typed cap lands/ports and two reference changes required")
 need(canonical(cap12.exactPhysicalScope)===canonical({componentCount:280,heldPlacements:279,translatedPlacements:1,totalLands:1165,heldLands:1163,translatedSmtPadsAndPorts:2,totalReferences:165,heldReferences:163,reroutedReferences:2,heldReferenceVias:129}),"Exact narrow CAP12 physical scope required; no general held-geometry waiver")
 for(const spec of padSpecs){for(const [kind,idKey,rows]of[["pcb_smtpad","pcb_smtpad_id",cap12.typedSmtPads],["pcb_port","pcb_port_id",cap12.typedPcbPorts]]as const){const id=kind==="pcb_smtpad"?spec.id:spec.port,old=frameRaw.filter(r=>r.type===kind&&r[idKey]===id),changes=rows.filter((r:Row)=>r.before?.[idKey]===id);need(old.length===1&&changes.length===1&&canonical(changes[0].before)===canonical(old[0]),"Exact captured typed CAP12 land/port before row");const expected={...structuredClone(old[0]),x:spec.newX};need(at(old[0],{x:spec.oldX,y:4.7})&&old[0].pcb_component_id==="pcb_component_136"&&geometrySame(changes[0].after,expected),"Only the exact CAP12 typed pad/port X changes are permitted")}}
 for(const spec of referenceSpecs){const before=frameRaw.filter(r=>r.type==="pcb_trace"&&r.pcb_trace_id===spec.id),changes=cap12.references.filter((r:Row)=>r.originalSourceTraceId===spec.sid);need(before.length===1&&changes.length===1,"Exact captured CAP12 reference identity");const r=changes[0],expectedBefore={...structuredClone(before[0]),connection_name:spec.sid},expectedRoute=[{...structuredClone(before[0].route[0]),...spec.points[0]},{route_type:"wire",...spec.points[1],layer:"bottom",width:.2},{...structuredClone(before[0].route.at(-1)),...spec.points[2]}],expectedAfter={...structuredClone(expectedBefore),route:expectedRoute,trace_length:planar(expectedRoute)};need(r.capturedPcbTraceId===spec.id&&r.literalTraceName===spec.name&&r.name===spec.name&&r.fromSelector===spec.from&&r.toSelector===spec.to&&r.width===.2&&canonical(r.before)===canonical(expectedBefore)&&geometrySame(r.after,expectedAfter)&&geometrySame(r.absolutePoints,spec.points)&&geometrySame(r.absolutePoints3,spec.points),"Only the two exact width.2 Bottom three-point CAP12 references are allowed");need(expectedRoute[0].start_pcb_port_id===spec.start&&expectedRoute.at(-1).end_pcb_port_id===spec.end,"Both original CAP12 reference nets and fixed via endpoints must remain")}
 const cap8=rawPlan.cap8HardwareDelta,cap8Declaration=readPin(CAP8_DESCRIPTOR);readPin(CAP8_PROOF)
 need(cap8?.profile===CAP8_PROFILE&&cap8.descriptorBinding?.path===CAP8_DESCRIPTOR.path&&cap8.descriptorBinding?.sha256===CAP8_DESCRIPTOR.sha256&&(!Object.prototype.hasOwnProperty.call(cap8.descriptorBinding,"bytes")||cap8.descriptorBinding.bytes===fs.statSync(CAP8_DESCRIPTOR.path).size)&&canonical(cap8.proofBinding)===canonical(CAP8_PROOF)&&canonical(cap8.originalDeclaration)===canonical(cap8Declaration),"Exact reviewed cap8 declaration and finite geometry proof are mandatory")
 need(cap8.candidateBinding?.sha256===args.get("--candidate-sha")&&cap8.freshCoreDerived===false&&cap8.capturedIdsAreMappingProvenanceOnly===true,"Cap8 is bound planned Source hardware; captured IDs never become fresh IDs")
 const capturedCap8=frameRaw.filter(r=>r.type==="pcb_component"&&r.pcb_component_id==="pcb_component_132"),capturedCap8Source=frameRaw.filter(r=>r.type==="source_component"&&r.source_component_id==="source_component_132")
 need(capturedCap8.length===1&&capturedCap8Source.length===1&&capturedCap8Source[0].name==="C_DDR_RAM_8"&&capturedCap8[0].source_component_id===capturedCap8Source[0].source_component_id,"Exact captured real cap8 source/physical ownership")
 const expectedCap8After=structuredClone(capturedCap8[0]);expectedCap8After.center={x:0,y:7.9};expectedCap8After.display_offset_x=0;expectedCap8After.display_offset_y=7.9
 need(at(capturedCap8[0].center,{x:1.2,y:9.799999999999999})&&capturedCap8[0].rotation===0&&capturedCap8[0].layer==="bottom"&&cap8.component?.name==="C_DDR_RAM_8"&&canonical(cap8.component.before)===canonical(capturedCap8[0])&&canonical(cap8.component.sourceComponent)===canonical(capturedCap8Source[0])&&geometrySame(cap8.component.after,expectedCap8After),"Only cap8 center/display XY translate to0,7.9; all other component fields held")
 need(canonical(cap8.component.sourcePlacement)===canonical({before:{pcbX:1.2,pcbY:9.799999999999999,layer:"bottom",pcbRotation:0},after:{pcbX:0,pcbY:7.9,layer:"bottom",pcbRotation:0}}),"Exact cap8 source placement inverse")
 const cap8PadSpecs=[{id:"pcb_smtpad_730",port:"pcb_port_729",oldX:1.620116,newX:.420116},{id:"pcb_smtpad_729",port:"pcb_port_730",oldX:.779884,newX:-.420116}]
 const cap8ReferenceSpecs=[{sid:"source_trace_986",id:"pcb_trace_156",name:"TI_HS_C_DDR_RAM_8_POWER",from:"C_DDR_RAM_8.pin1",oldTo:".V_TI_HS_C_DDR_RAM_8_POWER > port.bottom",viaName:"V_CAP8_REPLAY_DDR_1V5",net:"DDR_1V5",xy:{x:.4,y:7.2},points:[{x:.420116,y:7.9},{x:.420116,y:7.220116},{x:.4,y:7.2}]},{sid:"source_trace_987",id:"pcb_trace_157",name:"TI_HS_C_DDR_RAM_8_GROUND",from:"C_DDR_RAM_8.pin2",oldTo:".V_TI_HS_C_DDR_RAM_8_GROUND > port.bottom",viaName:"V_CAP8_REPLAY_GND",net:"GND",xy:{x:-1.6,y:7.4},points:[{x:-.420116,y:7.9},{x:-1.4,y:7.9},{x:-1.6,y:7.7},{x:-1.6,y:7.4}]}]
 need(cap8.typedSmtPads?.length===2&&cap8.typedPcbPorts?.length===2&&cap8.references?.length===2&&cap8.pdnVias?.length===2&&cap8.innerPortRegistrations?.length===4&&cap8.sourceEndpointInverses?.length===2,"Exactly two cap8 lands/ports, references, new fullspan PDN vias and four real inner aliases")
 for(const spec of cap8PadSpecs)for(const[kind,idKey,changes]of[["pcb_smtpad","pcb_smtpad_id",cap8.typedSmtPads],["pcb_port","pcb_port_id",cap8.typedPcbPorts]]as const){const id=kind==="pcb_smtpad"?spec.id:spec.port,old=frameRaw.filter(r=>r.type===kind&&r[idKey]===id),d=changes.filter((r:Row)=>r.before?.[idKey]===id);need(old.length===1&&d.length===1&&canonical(d[0].before)===canonical(old[0])&&old[0].pcb_component_id==="pcb_component_132"&&at(old[0],{x:spec.oldX,y:9.799999999999999})&&geometrySame(d[0].after,{...structuredClone(old[0]),x:spec.newX,y:7.9}),"Only exact cap8 typed land/port rigid translation")}
 for(const spec of cap8ReferenceSpecs){
  const before=frameRaw.filter(r=>r.type==="pcb_trace"&&r.pcb_trace_id===spec.id),refs=cap8.references.filter((r:Row)=>r.originalSourceTraceId===spec.sid),decl=cap8Declaration.powerReferenceInverses.filter((r:Row)=>r.before.pcb_trace_id===spec.id),vias=cap8.pdnVias.filter((r:Row)=>r.name===spec.viaName),inv=cap8.sourceEndpointInverses.filter((r:Row)=>r.originalSourceTraceId===spec.sid)
  need(before.length===1&&refs.length===1&&decl.length===1&&vias.length===1&&inv.length===1,"Unique exact cap8 reference, declared via and endpoint inverse")
  const r=refs[0],v=vias[0],to=`.${spec.viaName} > port.bottom`
  need(r.capturedPcbTraceId===spec.id&&r.name===spec.name&&r.literalTraceName===spec.name&&r.fromSelector===spec.from&&r.beforeToSelector===spec.oldTo&&r.toSelector===to&&r.width===.2&&canonical(r.before)===canonical({...before[0],connection_name:spec.sid})&&canonical(r.after)===canonical(decl[0].after)&&geometrySame(r.absolutePoints,spec.points)&&r.after.route.every((p:Row)=>p.route_type==="wire"&&p.layer==="bottom"&&p.width===.2)&&!Object.prototype.hasOwnProperty.call(r.after.route.at(-1),"end_pcb_port_id"),"Explicit cap8 .2 Bottom physical inverse ends at planned Source identity, never a fabricated new numeric ID")
  need(inv[0].beforeSelector===spec.oldTo&&inv[0].afterSelector===to&&v.connectsTo===`net.${spec.net}`&&at(v,spec.xy)&&v.fromLayer==="top"&&v.toLayer==="bottom"&&canonical(v.layers)===canonical(["top","inner1","inner2","bottom"])&&canonical(v.innerLayers)===canonical(["inner1","inner2"])&&v.outerDiameter===.4572&&v.holeDiameter===.254&&v.tented==="top_and_bottom_tented"&&v.futureFreshIds===null&&v.plannedIdsAreSourceIdentitiesOnly===true,"Two explicitly net-connected declared fullspan PDN vias with no authentic new raw IDs yet")
  for(const layer of ["inner1","inner2"])need(cap8.innerPortRegistrations.filter((p:Row)=>p.viaName===spec.viaName&&p.layer===layer&&at(p.xy,spec.xy)).length===1,"One real requested inner child per PDN barrel/layer")
 }
 const combinedHardwareExpectations={realComponents:280,heldRealComponents:278,movedRealComponents:2,originalCopperLands:1165,heldCopperLands:1161,movedCopperLands:4,referencePaths:165,heldReferencePaths:161,changedReferencePaths:4,originalReferenceVias:129,heldOriginalReferenceVias:129,addedPdnReferenceVias:2}
 const capturedCpuSources=frameRaw.filter(r=>r.type==="source_component"&&r.name==="U_SOC")
 need(capturedCpuSources.length===1,"One captured real CPU source component required")
 const capturedCpuParts=frameRaw.filter(r=>r.type==="pcb_component"&&r.source_component_id===capturedCpuSources[0].source_component_id)
 need(capturedCpuParts.length===1,"One captured real CPU physical component required")
 const capturedCpuPart=capturedCpuParts[0]
 need(coordinateFrame?.kind==="CAPTURED_CPU_COMPONENT_ORIGIN"&&coordinateFrame.componentName==="U_SOC"
  &&coordinateFrame.rotationDegrees===0&&capturedCpuPart.rotation===0&&at(coordinateFrame.originXY,capturedCpuPart.center)
  &&coordinateFrame.capturedOriginalSourceComponentId===capturedCpuSources[0].source_component_id
  &&coordinateFrame.capturedOriginalPcbComponentId===capturedCpuPart.pcb_component_id
  &&coordinateFrame.rawCoreBinding?.path===PARENT_RAW.path&&coordinateFrame.rawCoreBinding?.sha256===PARENT_RAW.sha256,
  "Source paths require the actual pinned unrotated CPU component-origin frame, never a numeric-pad origin")
 const routedOwnerIds:string[]=rawPlan.routedOwnerIds,pendingOwnerIds:string[]=rawPlan.pendingOwnerIds,allOwnerIds=Array.from({length:49},(_,i)=>`source_trace_${i}`)
 need(Array.isArray(routedOwnerIds)&&Array.isArray(pendingOwnerIds)&&routedOwnerIds.length===49&&pendingOwnerIds.length===0&&sameRoster([...routedOwnerIds,...pendingOwnerIds],allOwnerIds),"Exact full49 routed owner partition and no pending owner required")
 need(typeof rawPlan.inputBindings?.candidate?.path==="string"&&/^[a-f0-9]{64}$/.test(rawPlan.inputBindings?.candidate?.sha256??""),"Plan must explicitly bind candidate path and SHA256")
 need(rawPlan.inputBindings.candidate.sha256===args.get("--candidate-sha")&&canonical(cap12.candidateBinding)===canonical(rawPlan.inputBindings.candidate)&&canonical(cap8.candidateBinding)===canonical(rawPlan.inputBindings.candidate),"Future actual candidate SHA/path/bytes must match both plan and hardware delta bindings")
 need(rawPlan.inputBindings.candidate.sha256!=="cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720","New full49 candidate must not reuse captured243 partial48 binding")
 const current49=readPin(rawPlan.inputBindings.candidate)
 need(current49.all49Connected===true&&current49.all49Accepted===false&&current49.fabricationReady===false&&current49.allSavedCarriersCurrentSceneQualified===true&&sameRoster(current49.carrierTraces.map((t:Row)=>t.connection_name),routedOwnerIds)&&sameRoster(current49.joinedNumericPadTraces.map((t:Row)=>t.connection_name),routedOwnerIds),"Bound current candidate qualification provenance and joined graph roster required")
 need(current49.finalScenePhysicalReports.length===routedOwnerIds.length&&current49.finalScenePhysicalReports.every((r:Row)=>r.passed===true),"Exact current physical-report provenance required; no Source inheritance")
 need(Array.isArray(rawPlan.replacedOriginals)&&sameRoster(rawPlan.replacedOriginals.map((r:Row)=>r.originalSourceTraceId),allOwnerIds)&&sameRoster(rawPlan.projectedGeometry.map((r:Row)=>r.originalSourceTraceId),routedOwnerIds),"Replace all49 logical route props while projecting only the bound routed subset")
 for(const row of rawPlan.replacedOriginals)need(Array.isArray(row.afterRouteProps?.pcbPaths)&&(pendingOwnerIds.includes(row.originalSourceTraceId)?row.afterRouteProps.pcbPaths.length===0:row.afterRouteProps.pcbPaths.length>0),"Pending pcbPaths must be empty and routed pcbPaths real")
 need(Array.isArray(rawPlan.auxiliaryLocalTraces)&&Array.isArray(rawPlan.pendingOwnerApproaches)&&rawPlan.pendingOwnerApproaches.length===2*pendingOwnerIds.length,"Pending owners require two exact approach branches each")
 for(const sid of pendingOwnerIds)need(rawPlan.pendingOwnerApproaches.filter((r:Row)=>r.owner===sid&&r.originalSourceTraceId===sid).length===2,"Pending owner approach inventory incomplete")
 for(const row of rawPlan.pendingOwnerApproaches)need(pendingOwnerIds.includes(row.owner)&&current49.full49FanoutInput.traces.some((t:Row)=>t.pcb_trace_id===row.branchId&&canonical(t)===canonical(row.originalBranch)),"Pending approach must be an exact bound-current branch")
 for(const row of rawPlan.auxiliaryLocalTraces)need(pendingOwnerIds.includes(row.originalSourceTraceId)&&row.owner===row.originalSourceTraceId&&row.layer==="top"&&row.afterRouteProps?.pcbPaths?.length===1&&row.absolutePoints?.length>=2&&planar(row.absolutePoints.map((p:Row)=>({...p,route_type:"wire",layer:"top"})))>1e-8,"Auxiliary traces must serialize actual nonzero pending Top runs")
 for(const row of rawPlan.auxiliaryLocalTraces)need(/^U_SOC\.pin\d+$/.test(row.relativeAnchorSelector??"")
  &&row.afterRouteProps.pcbPathRelativeTo===row.relativeAnchorSelector&&at(row.relativeAnchorXY,coordinateFrame.originXY),
  "Auxiliary selectors use the held CPU component-origin frame, not CPU/RAM numeric-pad XY")
 const parentCapture=readPin(PARENT_CAPTURE),proposal=readPin({path:PROPOSAL,sha256:PROPOSAL_SHA});readPin(MANUFACTURER)
 need(parentCapture.passed===true&&parentCapture.fullInverseSourceTreePassed===true,"Actual Source33B capture required")
 const removed=new Set<string>(rawPlan.removeViaNames)
 const retained=proposal.added52RealInnerLayerPorts.filter((r:Row)=>!removed.has(r.viaName)).map((r:Row)=>({...r,xy:r.xy??r.viaXY}))
 need(retained.length===0,"No old signal/carrier inner-layer declarations may remain")
 const plan:Row={...rawPlan,partialLayerProfile:"compact-four-layer-partial",all49OriginalLogicalTraces:proposal.all49OriginalLogicalTraces,retainedInnerPortRegistrations:retained,parentCapturePin:PARENT_CAPTURE,parentCapturedSourceTree:parentCapture.actualSourceTree,manufacturerAuditPin:MANUFACTURER,effectiveConstraintBridge:{profile:"current-ti-compact-intersection",manufacturerAuditPin:MANUFACTURER,historical:{byte0Max:13.2,byte1Max:14.4,caMin:20.95,caMax:23.49},effective:{byte0Max:11.8,byte1Max:14.2,caMin:20.95,caMax:22.29},maxCohortSkew:.635,maxPairSkew:.127}}
 const augmentedPlanSha256=sha(canonical(plan))
 need(sha(fs.readFileSync(PARENT))===PARENT_SHA,"Parent Source33B module changed")
 stageDiagnostic("react-import","before")
 const ReactModule:any=await import(`${BOARD}/node_modules/react/index.js`),React:any=ReactModule.default??ReactModule
 stageDiagnostic("react-import","after")
 function snapshot(node:any):Row{if(!React.isValidElement(node)){const allowed=node===null||node===undefined||["boolean","string","number"].includes(typeof node);return {kind:allowed?"primitive":"unsupported",type:typeof node,key:null,value:node,props:{},children:[]}}const{children,...props}=node.props,kind=typeof node.type==="string"?"literal":node.type===React.Fragment?"fragment":"unsupported";return {kind,type:kind==="literal"?node.type:kind==="fragment"?"React.Fragment":String(node.type),key:node.key,props,children:React.Children.toArray(children).map(snapshot)}}
 const flatten=(r:Row):Row[]=>[r,...r.children.flatMap(flatten)]
 stageDiagnostic("parent-module-import","before")
 const parentModule=await import(url.pathToFileURL(PARENT).href)
 stageDiagnostic("parent-module-import","after")
 stageDiagnostic("overlay-import","before")
 const overlay=await import(url.pathToFileURL(overlayPath).href)
 stageDiagnostic("overlay-import","after")
 stageDiagnostic("parent-factory-build","before")
 const parent=await parentModule.buildOwnerD4Source33B()
 stageDiagnostic("parent-factory-build","after")
 need(canonical(normalized(snapshot(parent.element)))===canonical(parentCapture.actualSourceTree),"Parent factory no longer reproduces actual33B capture")
 stageDiagnostic("overlay-build","before")
 const replay=await overlay.buildAll49SourceReplay(parent.element,plan)
 stageDiagnostic("overlay-build","after")
 const before=snapshot(replay.parentElement),after=snapshot(replay.element),restored=overlay.inverseAll49ReplaySnapshot(after,replay.auditPlan)
 need(canonical(normalized(restored))===canonical(normalized(before)),"Full presence-aware inverse failed")
 const originalRestored=overlay.inverseAll49ReplayParentNormalization(restored,replay.auditPlan)
 need(canonical(normalized(originalRestored))===canonical(parentCapture.actualSourceTree),"Parent-key inverse must restore exact original captured33B keys, props and children")
 const afterRows=flatten(after);need(afterRows.every(r=>r.kind!=="unsupported"),"Unsupported source node")
 const N=plan.newVias.length,I=plan.innerPortRegistrations.length,R=plan.projectedGeometry.reduce((s:number,r:Row)=>s+r.wireRuns.length,0),A=plan.auxiliaryLocalTraces.length
 need(Number.isInteger(N)&&N>=0&&Number.isInteger(I)&&I>=0&&I<=2*N&&Number.isInteger(R)&&R>=routedOwnerIds.length&&Number.isInteger(A)&&A>=0,"Exact partial via/run/alias/auxiliary inventory required; pending barrels add no routed run")
 const P=cap8.pdnVias.length,J=cap8.innerPortRegistrations.length
 need(P===2&&J===4&&A===0,"Exactly two new PDN vias, four inner PDN aliases, no pending-owner auxiliary traces")
 const physicalVias=129+N+P
 const expected={physicalVias,pcbComponents:280+physicalVias,sourceAndPcbPorts:1419+2*N+I+2*P+J,sourceTraces:1097+A,physicalTraces:165+R+A,reactElements:2036+N+I+A+P+J,registeredInnerPorts:I+J,newVias:N+P,newSignalVias:N,newPdnVias:P,newInnerPorts:I+J,newSignalInnerPorts:I,newPdnInnerPorts:J,newWireRuns:R+A,routedWireRuns:R,auxiliaryWireRuns:A,auxiliaryLocalTraces:A,routedOwners:routedOwnerIds.length,pendingOwners:pendingOwnerIds.length}
 need(R===plan.replacedOriginals.reduce((s:number,r:Row)=>s+r.afterRouteProps.pcbPaths.length,0)&&expected.physicalTraces===replay.expectedCounts.physicalTraces,"Projected run counts and source declaration counts differ")
 need(afterRows.filter(r=>r.kind==="literal"||r.kind==="fragment").length===expected.reactElements,"Replay React count differs from exact delta")
 const immutableInputPins=[{path:planPath,sha256:planSha256},rawPlan.inputBindings.candidate,{path:overlayPath,sha256:args.get("--overlay-sha")},PARENT_CAPTURE,PARENT_RAW,PARENT_CONTROLS,MANUFACTURER,CAP8_DESCRIPTOR,CAP8_PROOF,{path:PARENT,sha256:PARENT_SHA},{path:PROPOSAL,sha256:PROPOSAL_SHA},...OVERLAY_DEPENDENCIES]
 const assertInputPinsUnchanged=()=>{for(const pin of immutableInputPins)need(sha(fs.readFileSync(pin.path))===pin.sha256,`Bound input changed during replay: ${pin.path}`)}
 const qualificationBoundary={regeneratedPlaneContinuityQualified:false,sourceHardwareNativeQualified:false,referenceQualified:false,tiQualified:false,cadQualified:false,wholeMixedC31Validated:false,perWireRunPhysicalQualified:false,allThroughViaBarrelsPhysicalQualified:false,mixedOwnNumericPadGraphQualified:false,nativeExecuted:false,wholeMixedNativeQualified:false,originalCouplingApisExecuted:false}
 const candidateDiagnostics={candidateBinding:rawPlan.inputBindings.candidate,qualificationProvenance:rawPlan.qualificationProvenance??null,currentCandidateFinalScenePhysicalReports:current49.finalScenePhysicalReports,physicalRunReports:rawPlan.physicalRunReports??[],newViaReports:rawPlan.newViaReports??[],policy:rawPlan.mixedPhysicalReportPolicy??"Candidate reports are provenance only; fresh Source physical qualification remains pending",inheritedQualification:false}
 const capture={scope:"PARTIAL_MIXED_JOINED_REAL_EDITABLE_SOURCE_CAPTURE",passed:true,fullInverseSourceTreePassed:true,parentNormalizationInversePassed:true,planPath,planSha256,augmentedPlanSha256,parentModulePin:{path:PARENT,sha256:PARENT_SHA},parentCapturePin:PARENT_CAPTURE,overlayPin:{path:overlayPath,sha256:sha(fs.readFileSync(overlayPath))},expectedCounts:expected,actualSourceTree:after,sourceRuleBridge:replay.auditPlan.effectiveConstraintBridge,removedLocalTraceNames:plan.removeLocalTraceNames,removedViaNames:plan.removeViaNames,newViaNames:[...plan.newVias,...cap8.pdnVias].map((v:Row)=>v.name),newPdnViaNames:cap8.pdnVias.map((v:Row)=>v.name),auxiliaryLocalTraceNames:plan.auxiliaryLocalTraces.map((r:Row)=>r.name),routedOwnerIds,pendingOwnerIds,guardInputPath:args.has("--input")?path.resolve(args.get("--input")!):null,partialLayerProfile:plan.partialLayerProfile,mixedPhysicalQualificationBoundary:qualificationBoundary,...qualificationBoundary,projectorCandidateDiagnostics:candidateDiagnostics,freshCoreDerived:false,newRawIdsAssigned:false,circuitConstructed:false,coreRendered:false,full49Accepted:false,all49Accepted:false,fullBoardPassed:false,electricalTimingQualified:false,fabricationReady:false}
 Object.assign(capture,{cap8HardwareDelta:cap8,cap8HardwareDeltaProfile:cap8.profile,combinedHardwareExpectations,cap12HardwareDelta:cap12,cap12HardwareDeltaProfile:cap12.profile,candidateSha256:args.get("--candidate-sha"),explicitPlanSha256:args.get("--plan-sha"),capturedOriginalComponentOwnership})
 if(stage==="capture"){assertInputPinsUnchanged();write(output,capture);process.stdout.write(JSON.stringify({stage,output,passed:true,expectedCounts:expected,coreRendered:false})+"\n");return}
 const actualCapture=readPin({path:path.resolve(args.get("--capture")!),sha256:args.get("--capture-sha")})
 need(actualCapture.candidateSha256===args.get("--candidate-sha")&&actualCapture.explicitPlanSha256===args.get("--plan-sha")&&canonical(actualCapture.cap12HardwareDelta)===canonical(cap12)&&canonical(actualCapture.cap8HardwareDelta)===canonical(cap8)&&canonical(actualCapture.combinedHardwareExpectations)===canonical(combinedHardwareExpectations),"Actual capture must bind the same explicit future candidate/plan hashes and both exact hardware descriptors")
 need(actualCapture.passed===true&&actualCapture.fullInverseSourceTreePassed===true&&actualCapture.parentNormalizationInversePassed===true&&actualCapture.partialLayerProfile===plan.partialLayerProfile&&actualCapture.planSha256===planSha256&&actualCapture.augmentedPlanSha256===augmentedPlanSha256,"Passed capture must bind exact partial plan and complete original-parent inverse")
 need(actualCapture.overlayPin.path===overlayPath&&actualCapture.overlayPin.sha256===sha(fs.readFileSync(overlayPath)),"Core must use the exact overlay/registrar bytes captured")
 need(canonical(normalized(after))===canonical(actualCapture.actualSourceTree),"Fresh source differs from passed capture")
 need(sha(fs.readFileSync(CORE_PATH))===CORE_SHA,"Pinned Core bytes changed")
 const baseline:Row[]=readPin(PARENT_RAW),controls=readPin(PARENT_CONTROLS)
 stageDiagnostic("core-import","before")
 const {Circuit}=await import(url.pathToFileURL(CORE_PATH).href)
 stageDiagnostic("core-import","after")
 const circuit=new Circuit();circuit.schematicDisabled=true;circuit.pcbRoutingDisabled=true
 stageDiagnostic("circuit-add","before")
 circuit.add(replay.element)
 stageDiagnostic("circuit-add","after")
 stageDiagnostic("inner-port-registration","before")
 const registered=await overlay.registerAll49SourceReplayInnerPorts(circuit,plan)
 stageDiagnostic("inner-port-registration","after")
 const signalRegistrations=Array.isArray(registered.signal)?registered.signal:registered.signal?.registrations,pdnRegistrations=registered.pdnRegistrations
 need(Array.isArray(signalRegistrations)&&Array.isArray(pdnRegistrations)&&signalRegistrations.length===I&&pdnRegistrations.length===J,"Separate genuine signal and PDN registrar results required")
 const registrations=[...signalRegistrations,...pdnRegistrations]
 need(registrations.length===expected.registeredInnerPorts,"Exact retained/new real inner-port registration count required")
 stageDiagnostic("render-until-settled","before")
 await circuit.renderUntilSettled()
 stageDiagnostic("render-until-settled","after")
 const rawPath=path.resolve(args.get("--raw-output")!);need(rawPath!==output&&rawPath!==planPath,"Separate raw output required")
 write(rawPath,circuit.getCircuitJson());const freshRawBytes=fs.readFileSync(rawPath),freshRawSha256=sha(freshRawBytes),core:Row[]=JSON.parse(freshRawBytes.toString()),rows=(kind:string)=>core.filter(r=>r.type===kind),oldRows=(kind:string)=>baseline.filter(r=>r.type===kind)
 const freshTypedComponentOwnership=typedComponentOwnership(core,280,rows("pcb_via").length)
 need(freshTypedComponentOwnership.sourceManuallyPlacedVias===expected.physicalVias&&freshTypedComponentOwnership.pcbComponents===280+rows("pcb_via").length,"Fresh Core physical-component count derives from280 real parts plus actual physical vias")
 // Expected comparison rows only. The actual fresh Core array is never edited.
 const hardwareDeltas=[cap12,cap8],allReferenceDeltas=[...cap12.references,...cap8.references]
 const expectedBaseline=baseline.map(r=>{
  if(r.type==="pcb_component"){const d=hardwareDeltas.find(d=>d.component.before.pcb_component_id===r.pcb_component_id);return d?structuredClone(d.component.after):r}
  if(r.type==="pcb_smtpad")return hardwareDeltas.flatMap(d=>d.typedSmtPads).find(d=>d.before.pcb_smtpad_id===r.pcb_smtpad_id)?.after??r
  if(r.type==="pcb_port")return hardwareDeltas.flatMap(d=>d.typedPcbPorts).find(d=>d.before.pcb_port_id===r.pcb_port_id)?.after??r
  return r
 })
 const expectedOldRows=(kind:string)=>expectedBaseline.filter(r=>r.type===kind)
 const checks:Row[]=[],check=(label:string,ok:boolean,actual?:any,expect?:any)=>checks.push({label,passed:ok,actual,expected:expect})
 for(const[k,n]of[["source_component",280],["source_trace",expected.sourceTraces],["pcb_component",expected.pcbComponents],["pcb_trace",expected.physicalTraces],["pcb_via",expected.physicalVias],["source_manually_placed_via",expected.physicalVias],["source_port",expected.sourceAndPcbPorts],["pcb_port",expected.sourceAndPcbPorts],["pcb_smtpad",1161],["pcb_plated_hole",4],["pcb_hole",2],["source_bus",8],["source_net",98],["pcb_keepout",2]]as const)check(`count-${k}`,rows(k).length===n,rows(k).length,n)
 const newSp=rows("source_port"),newPp=rows("pcb_port")
 function numeric(selector:string){const m=/^(.*)\.pin(\d+)$/.exec(selector);need(m,"Numeric selector required");const sc=rows("source_component").filter(r=>r.name===m[1]);need(sc.length===1,`Unique component ${m[1]}`);const sp=newSp.filter(r=>r.source_component_id===sc[0].source_component_id&&r.pin_number===Number(m[2]));need(sp.length===1,`Unique source pin ${selector}`);const pp=newPp.filter(r=>r.source_port_id===sp[0].source_port_id);need(pp.length===1,`Unique physical pin ${selector}`);return {source:sp[0],physical:pp[0]}}
 const components=oldRows("source_component").map(old=>{const found=rows("source_component").filter(r=>r.name===old.name),oldPc=expectedOldRows("pcb_component").filter(r=>r.source_component_id===old.source_component_id),newPc=found.length===1?rows("pcb_component").filter(r=>r.source_component_id===found[0].source_component_id):[];return {name:old.name,placementMode:old.name==="C_DDR_RAM_12"?"EXACT_CAP12_TRANSLATE_X_0P79_ONLY":old.name==="C_DDR_RAM_8"?"EXACT_CAP8_TRANSLATE_TO_0_7P9":"HELD_LITERAL",passed:found.length===1&&geometrySame(omit(old,["source_component_id"]),omit(found[0],["source_component_id"]))&&oldPc.length===1&&newPc.length===1&&geometrySame(omit(oldPc[0],["pcb_component_id","source_component_id"]),omit(newPc[0],["pcb_component_id","source_component_id"]))}})
 check("all280-real-parts-278-held-two-exact-cap12-cap8-translations",components.length===280&&components.filter(r=>r.placementMode==="HELD_LITERAL").length===278&&components.filter(r=>r.placementMode==="EXACT_CAP12_TRANSLATE_X_0P79_ONLY").length===1&&components.filter(r=>r.placementMode==="EXACT_CAP8_TRANSLATE_TO_0_7P9").length===1&&components.every(r=>r.passed),components.filter(r=>r.passed).length,280)
 const logical=plan.all49OriginalLogicalTraces.map((r:Row)=>{const from=numeric(r.from),to=numeric(r.to),found=rows("source_trace").filter(t=>t.name===r.name&&canonical(t.connected_source_port_ids)===canonical([from.source.source_port_id,to.source.source_port_id]));return {...r,actualSourceTraceId:found[0]?.source_trace_id,actualNumericPcbPortIds:[from.physical.pcb_port_id,to.physical.pcb_port_id],passed:found.length===1}})
 check("all49-original-logical-numeric-owners",logical.every((r:Row)=>r.passed),logical.filter((r:Row)=>r.passed).length,49)
 const busSemantics=(bus:Row,source:Row[])=>({...omit(bus,["source_bus_id","source_trace_ids"]),members:bus.source_trace_ids.map((id:string)=>{const t=source.find(r=>r.source_trace_id===id);return t?.name??t?.display_name??null})})
 const busChecks=oldRows("source_bus").map(old=>{const expectedBus=structuredClone(old),bounds:Row={DDR_BYTE0:{max:[13.2,11.8]},DDR_BYTE1:{max:[14.4,14.2]},DDR_COMMAND_CLOCK:{min:[20.95,20.95],max:[23.49,22.29]}};for(const[which,values]of Object.entries(bounds[old.name]??{}) as [string,number[]][])for(const key of [`${which}_length`,`${which}Length`])if(Object.prototype.hasOwnProperty.call(expectedBus,key)){need(expectedBus[key]===values[0],"Captured historical serialized cohort bound expected");expectedBus[key]=values[1]}const fresh=rows("source_bus").filter(r=>r.name===old.name);return {name:old.name,passed:fresh.length===1&&canonical(busSemantics(expectedBus,oldRows("source_trace")))===canonical(busSemantics(fresh[0],rows("source_trace")))}})
 check("all8-original-serialized-bus-rosters-and-skew-semantics-held",busChecks.length===8&&busChecks.every(r=>r.passed),busChecks.filter(r=>r.passed).length,8)
 const landGeometry=(r:Row)=>Object.fromEntries(["type","shape","hole_shape","x","y","center","width","height","radius","points","layer","layers","ccw_rotation","hole_diameter","hole_width","hole_height","outer_width","outer_height"].filter(k=>Object.prototype.hasOwnProperty.call(r,k)).map(k=>[k,r[k]]))
 for(const kind of ["pcb_smtpad","pcb_plated_hole","pcb_hole","pcb_keepout"]){const old=expectedOldRows(kind).map(landGeometry).sort((a,b)=>canonical(a).localeCompare(canonical(b))),fresh=rows(kind).map(landGeometry).sort((a,b)=>canonical(a).localeCompare(canonical(b)));check(kind==="pcb_smtpad"?"all-pcb_smtpad-1157-held-four-exact-cap12-cap8-translations":`all-${kind}-physical-geometries-held`,geometrySame(old,fresh),fresh.length,old.length)}
 // A Source pin can own several lands, and several physical ports can expose
 // the same Source pin. Bind every land through its actual physical port and
 // semantic component/pin, then find a geometry-preserving global bijection.
 // No first land/port is selected merely because its Source pin matches.
 const oldLands=[...expectedOldRows("pcb_smtpad"),...expectedOldRows("pcb_plated_hole")]
 const freshLands=[...rows("pcb_smtpad"),...rows("pcb_plated_hole")]
 const unique=(values:Row[])=>values.length===1?values[0]:undefined
 const portSemantics=(p:Row)=>omit(p,["pcb_port_id","pcb_component_id","source_port_id"])
 const sourcePinSemantics=(p:Row)=>omit(p,["source_port_id","source_component_id"])
 function bindLand(land:Row,source:Row[]):Row {
  const pp=unique(source.filter(r=>r.type==="pcb_port"&&r.pcb_port_id===land.pcb_port_id))
  const sp=pp?unique(source.filter(r=>r.type==="source_port"&&r.source_port_id===pp.source_port_id)):undefined
  const sc=sp?unique(source.filter(r=>r.type==="source_component"&&r.source_component_id===sp.source_component_id)):undefined
  const pc=pp?unique(source.filter(r=>r.type==="pcb_component"&&r.pcb_component_id===pp.pcb_component_id)):undefined
  const valid=!!pp&&!!sp&&!!sc&&!!pc&&land.pcb_component_id===pc.pcb_component_id&&pc.source_component_id===sc.source_component_id
  return {land,physicalPort:pp,sourcePort:sp,sourceComponent:sc,physicalComponent:pc,valid,
   semanticKey:valid?canonical([land.type,sc.name,sourcePinSemantics(sp)]):null}
 }
 const oldBindings=oldLands.map(land=>bindLand(land,expectedBaseline)),freshBindings=freshLands.map(land=>bindLand(land,core))
 const freshGroups=new Map<string,number[]>()
 freshBindings.forEach((b,index)=>{if(b.valid){const group=freshGroups.get(b.semanticKey)??[];group.push(index);freshGroups.set(b.semanticKey,group)}})
 const landCandidates=oldBindings.map(b=>b.valid?(freshGroups.get(b.semanticKey)??[]).filter(index=>{
  const f=freshBindings[index]
  return geometrySame(landGeometry(b.land),landGeometry(f.land))
   &&geometrySame(portSemantics(b.physicalPort),portSemantics(f.physicalPort))
   &&geometrySame(omit(b.sourceComponent,["source_component_id"]),omit(f.sourceComponent,["source_component_id"]))
 }):[])
 const freshToOld=new Map<number,number>()
 function assignLand(oldIndex:number,seen:Set<number>):boolean {
  for(const freshIndex of landCandidates[oldIndex]){
   if(seen.has(freshIndex))continue;seen.add(freshIndex)
   const previous=freshToOld.get(freshIndex)
   if(previous===undefined||assignLand(previous,seen)){freshToOld.set(freshIndex,oldIndex);return true}
  }
  return false
 }
 const landOrder=oldBindings.map((_,index)=>index).sort((a,b)=>landCandidates[a].length-landCandidates[b].length||a-b)
 for(const oldIndex of landOrder)assignLand(oldIndex,new Set<number>())
 const oldToFresh=new Map<number,number>();for(const[freshIndex,oldIndex]of freshToOld)oldToFresh.set(oldIndex,freshIndex)
 const landChecks=oldBindings.map((b,oldIndex)=>{const freshIndex=oldToFresh.get(oldIndex),f=freshIndex===undefined?undefined:freshBindings[freshIndex];return {
  originalLandId:b.land[`${b.land.type}_id`],componentName:b.sourceComponent?.name,sourcePinName:b.sourcePort?.name,
  geometryMode:b.land.type==="pcb_smtpad"&&padSpecs.some(s=>s.id===b.land.pcb_smtpad_id)?"EXACT_CAP12_TRANSLATE_X_0P79_ONLY":b.land.type==="pcb_smtpad"&&cap8PadSpecs.some(s=>s.id===b.land.pcb_smtpad_id)?"EXACT_CAP8_TRANSLATE_TO_0_7P9":"HELD_LITERAL",
  capturedPhysicalPortIdForMappingOnly:b.physicalPort?.pcb_port_id,actualLandId:f?.land[`${f.land.type}_id`],
  actualPhysicalPortId:f?.physicalPort?.pcb_port_id,actualSourcePortId:f?.sourcePort?.source_port_id,
  sameSemanticPinGeometryCandidateCount:landCandidates[oldIndex].length,
  matchedBijectively:freshIndex!==undefined,passed:b.valid&&!!f&&f.valid&&freshIndex!==undefined}})
 check("all1165-semantic-lands-and-ports-1161-held-four-exact-cap12-cap8-translations",landChecks.length===1165&&landChecks.filter(r=>r.geometryMode==="HELD_LITERAL").length===1161&&landChecks.filter(r=>r.geometryMode==="EXACT_CAP12_TRANSLATE_X_0P79_ONLY").length===2&&landChecks.filter(r=>r.geometryMode==="EXACT_CAP8_TRANSLATE_TO_0_7P9").length===2&&landChecks.every(r=>r.passed),landChecks.filter(r=>r.passed).length,1165)
 check("all1165-fresh-lands-covered-bijectively",oldBindings.length===1165&&freshBindings.length===1165
  &&freshToOld.size===1165&&oldToFresh.size===1165
  &&new Set(landChecks.map(r=>r.actualLandId)).size===1165, {old:oldBindings.length,fresh:freshBindings.length,matched:freshToOld.size},1165)
 const actualCpuSources=rows("source_component").filter(r=>r.name==="U_SOC")
 const actualCpuParts=actualCpuSources.length===1?rows("pcb_component").filter(r=>r.source_component_id===actualCpuSources[0].source_component_id):[]
 check("actual-source-path-component-origin-frame-held",actualCpuParts.length===1&&actualCpuParts[0].rotation===0
  &&at(actualCpuParts[0].center,coordinateFrame.originXY),actualCpuParts[0]?.center,coordinateFrame.originXY)
 const heldTraceIds=new Set<string>()
 const bodyOwners=new Set(plan.replacedOriginals.map((r:Row)=>r.originalSourceTraceId)),heldCarrierChecks=controls.carriers.filter((r:Row)=>!bodyOwners.has(r.originalSourceTraceId)).map((r:Row)=>{const old=oldRows("pcb_trace").filter(t=>t.source_trace_id===r.originalSourceTraceId),fresh=rows("pcb_trace").filter(t=>t.source_trace_id===logical.find((l:Row)=>l.originalSourceTraceId===r.originalSourceTraceId).actualSourceTraceId);fresh.forEach(t=>heldTraceIds.add(t.pcb_trace_id));return {originalSourceTraceId:r.originalSourceTraceId,passed:old.length===fresh.length&&old.every((t,i)=>geometrySame(wireGeometry(t.route),wireGeometry(fresh[i].route)))}})
 check("no-old-signal-carrier-source-wire-geometry-retained",heldCarrierChecks.length===0,heldCarrierChecks.length,0)
 const referenceChecks=controls.referenceProjection.map((r:Row)=>{
  const old=oldRows("pcb_trace").find(t=>t.pcb_trace_id===r.actualPcbTraceId),changed=allReferenceDeltas.find((d:Row)=>d.capturedPcbTraceId===r.actualPcbTraceId),freshSources=rows("source_trace").filter(t=>t.name===r.literalTraceName),fresh=freshSources.length===1?rows("pcb_trace").filter(t=>t.source_trace_id===freshSources[0].source_trace_id):[];fresh.forEach(t=>heldTraceIds.add(t.pcb_trace_id));let connected=true,actualEndpointPorts:any=null
  if(changed){const from=sourceSelector(changed.fromSelector),to=sourceSelector(changed.toSelector);actualEndpointPorts=[from.physical.pcb_port_id,to.physical.pcb_port_id];connected=!!old&&old.source_trace_id===changed.originalSourceTraceId&&changed.literalTraceName===r.literalTraceName&&freshSources.length===1&&canonical(freshSources[0].connected_source_port_ids)===canonical([from.source.source_port_id,to.source.source_port_id])&&fresh.length===1&&fresh[0].route[0]?.start_pcb_port_id===from.physical.pcb_port_id&&fresh[0].route.at(-1)?.end_pcb_port_id===to.physical.pcb_port_id&&fresh[0].route.length===changed.absolutePoints.length&&fresh[0].route.every((p:Row)=>p.route_type==="wire"&&p.layer==="bottom"&&p.width===.2)}
  const cap8Spec=cap8ReferenceSpecs.find(s=>s.id===r.actualPcbTraceId)
  let netProof:Row|null=null
  if(cap8Spec){const net=rows("source_net").filter(n=>n.name===cap8Spec.net),to=sourceSelector(changed.toSelector),instance=circuit.selectOne(`.${cap8Spec.viaName}`),manual=rows("source_manually_placed_via").filter(v=>v.source_manually_placed_via_id===instance?.source_manually_placed_via_id),via=rows("pcb_via").filter(v=>v.pcb_via_id===instance?.pcb_via_id);const ok=net.length===1&&manual.length===1&&via.length===1&&manual[0].source_net_id===net[0].source_net_id&&via[0].source_net_id===net[0].source_net_id&&to.source.source_component_id===manual[0].source_manually_placed_via_id&&freshSources.length===1&&canonical(freshSources[0].connected_source_net_ids)===canonical([net[0].source_net_id]);connected=connected&&ok;netProof={name:cap8Spec.net,actualSourceNetId:net[0]?.source_net_id,actualViaSourceId:manual[0]?.source_manually_placed_via_id,passed:ok,planeContinuityQualified:false}}
  const expectedRoute=changed?.after.route??old?.route
  return {literalTraceName:r.literalTraceName,geometryMode:cap8Spec?"EXACT_CAP8_NEW_PDN_REFERENCE":changed?"EXACT_CAP12_THREE_POINT_REFERENCE":"HELD_LITERAL",logicalEndpointMode:cap8Spec?"EXPLICIT_REPLACEMENT_TO_NEW_NET_CONNECTED_PDN_VIA":"HELD_LITERAL",declaredNetProof:netProof,capturedParentTraceIdForComparisonOnly:r.actualPcbTraceId,actualFreshSourceTraceId:freshSources[0]?.source_trace_id,actualFreshPcbTraceId:fresh[0]?.pcb_trace_id,actualEndpointPorts,endpointSourceAndPhysicalConnectivityHeld:connected,passed:!!old&&fresh.length===1&&geometrySame(wireGeometry(expectedRoute),wireGeometry(fresh[0].route))&&connected}
 })
 check("all165-reference-wires-161-held-four-exact-connected-cap12-cap8-paths",referenceChecks.length===165&&referenceChecks.filter((r:Row)=>r.geometryMode==="HELD_LITERAL").length===161&&referenceChecks.filter((r:Row)=>r.geometryMode==="EXACT_CAP12_THREE_POINT_REFERENCE").length===2&&referenceChecks.filter((r:Row)=>r.geometryMode==="EXACT_CAP8_NEW_PDN_REFERENCE").length===2&&referenceChecks.every((r:Row)=>r.passed),referenceChecks.filter((r:Row)=>r.passed).length,165)
 const viaChecks=controls.viaProjection.filter((r:Row)=>!removed.has(r.sourceViaName)).map((r:Row)=>{const old=oldRows("pcb_via").find(v=>v.pcb_via_id===r.actualViaId),instance=circuit.selectOne(`.${r.sourceViaName}`),fresh=rows("pcb_via").filter(v=>v.pcb_via_id===instance?.pcb_via_id),v=fresh[0],aliases=(v?.pcb_port_ids??[]).map((id:string)=>{const pp=newPp.find(p=>p.pcb_port_id===id),sp=newSp.find(p=>p.source_port_id===pp?.source_port_id);return {actualFreshPcbPortId:id,layer:pp?.layers?.length===1?pp.layers[0]:null,authentic:!!pp&&!!sp&&sp.source_component_id===instance?.source_manually_placed_via_id&&at(pp,v)}});return {name:r.sourceViaName,actualFreshPcbViaId:v?.pcb_via_id,aliases,passed:!!old&&fresh.length===1&&geometrySame(viaGeometry(old),viaGeometry(v))&&aliases.length===2&&sameRoster(aliases.map((a:Row)=>a.layer),["top","bottom"])&&aliases.every((a:Row)=>a.authentic)}})
 check("all129-reference-barrel-geometries-held",viaChecks.length===129&&viaChecks.every((r:Row)=>r.passed),viaChecks.filter((r:Row)=>r.passed).length,129)
 const heldStubChecks=controls.signalTopProjection.filter((r:Row)=>!bodyOwners.has(r.originalSourceTraceId)).map((r:Row)=>{const branch=proposal.all98NumericOwnedSignalBranches.find((b:Row)=>b.originalSourceTraceId===r.originalSourceTraceId&&b.side===r.side),np=numeric(branch.numericSelector).physical,instance=circuit.selectOne(`.${branch.viaName}`),via=rows("pcb_via").find(v=>v.pcb_via_id===instance?.pcb_via_id),topIds=new Set((via?.pcb_port_ids??[]).filter((id:string)=>newPp.some(p=>p.pcb_port_id===id&&p.layers?.length===1&&p.layers[0]==="top"))),fresh=rows("pcb_trace").filter(t=>{const a=t.route[0]?.start_pcb_port_id,b=t.route.at(-1)?.end_pcb_port_id;return a===np.pcb_port_id&&topIds.has(b)||b===np.pcb_port_id&&topIds.has(a)}),old=oldRows("pcb_trace").find(t=>t.pcb_trace_id===r.actualPcbTraceId);fresh.forEach(t=>heldTraceIds.add(t.pcb_trace_id));return {originalSourceTraceId:r.originalSourceTraceId,side:r.side,actualPcbTraceId:fresh[0]?.pcb_trace_id,passed:fresh.length===1&&(geometrySame(wireGeometry(old.route),wireGeometry(fresh[0].route))||geometrySame(wireGeometry(old.route),wireGeometry([...fresh[0].route].reverse())))}})
 check("all98-old-signal-endpoint-stubs-replaced",heldStubChecks.length===0,heldStubChecks.length,0)
 check("all165-exact-reference-trace-rows-accounted",heldTraceIds.size===165,heldTraceIds.size,165)
 const generatedViaSpecs=[...plan.newVias.map((r:Row)=>({...r,generatedKind:"SIGNAL"})),...cap8.pdnVias.map((r:Row)=>({...r,generatedKind:"PDN"}))]
 const newViaChecks=generatedViaSpecs.map((r:Row)=>{
  const instance=circuit.selectOne(`.${r.name}`),fresh=rows("pcb_via").filter(v=>v.pcb_via_id===instance?.pcb_via_id),v=fresh[0],manual=rows("source_manually_placed_via").filter(q=>q.source_manually_placed_via_id===instance?.source_manually_placed_via_id),pcs=manual.length===1?rows("pcb_component").filter(q=>q.source_component_id===manual[0].source_manually_placed_via_id):[]
  const aliases=(v?.pcb_port_ids??[]).map((id:string)=>{const pp=newPp.find(p=>p.pcb_port_id===id),sp=newSp.find(p=>p.source_port_id===pp?.source_port_id);return {id,actualSourcePortId:sp?.source_port_id,layer:pp?.layers?.length===1?pp.layers[0]:null,authentic:!!pp&&!!sp&&manual.length===1&&pcs.length===1&&sp.source_component_id===manual[0].source_manually_placed_via_id&&pp.pcb_component_id===pcs[0].pcb_component_id&&at(pp,v)&&pp.layers?.length===1}})
  const netName=r.generatedKind==="PDN"?String(r.connectsTo).slice(4):null,nets=netName?rows("source_net").filter(n=>n.name===netName):[]
  const netPassed=r.generatedKind!=="PDN"||(nets.length===1&&manual.length===1&&manual[0].source_net_id===nets[0].source_net_id&&v?.source_net_id===nets[0].source_net_id)
  return {name:r.name,generatedKind:r.generatedKind,actualPcbViaId:v?.pcb_via_id,actualViaSourceId:manual[0]?.source_manually_placed_via_id,actualPcbComponentId:pcs[0]?.pcb_component_id,declaredNetName:netName,actualDeclaredNetId:nets[0]?.source_net_id,declaredNetPassed:netPassed,aliases,passed:fresh.length===1&&manual.length===1&&pcs.length===1&&at(v,r)&&v.outer_diameter===.4572&&v.hole_diameter===.254&&v.from_layer==="top"&&v.to_layer==="bottom"&&v.tented_on_top===true&&v.tented_on_bottom===true&&canonical(v.layers)===canonical(["top","inner1","inner2","bottom"])&&aliases.length===2+r.innerLayers.length&&sameRoster(aliases.map((a:Row)=>a.layer),["top","bottom",...r.innerLayers])&&new Set(aliases.map((a:Row)=>a.actualSourcePortId)).size===aliases.length&&aliases.every((p:Row)=>p.authentic)&&netPassed}
 })
 check("all-generated-signal-and-pdn-vias-real-layer-aliases-and-declared-pdn-nets",newViaChecks.length===N+P&&newViaChecks.filter((r:Row)=>r.generatedKind==="SIGNAL").length===N&&newViaChecks.filter((r:Row)=>r.generatedKind==="PDN").length===P&&newViaChecks.every((r:Row)=>r.passed)&&new Set(newViaChecks.map((r:Row)=>r.actualPcbViaId)).size===N+P,newViaChecks.filter((r:Row)=>r.passed).length,N+P)
 const originalCohorts=oldRows("source_bus").filter(b=>["DDR_RESET","DDR_BYTE0","DDR_BYTE1","DDR_COMMAND_CLOCK"].includes(b.name)),cohortByOwner=new Map<string,string>(originalCohorts.flatMap(b=>b.source_trace_ids.map((id:string)=>[id,b.name] as [string,string])))
 function sourceSelector(selector:string){if(/^.*\.pin\d+$/.test(selector))return numeric(selector);const m=/^\.([A-Za-z][A-Za-z0-9_]*) > port\.(top|bottom|inner1|inner2)$/.exec(selector);need(m,"Numeric or explicit real via-layer selector required");const instance=circuit.selectOne(`.${m[1]}`),via=rows("pcb_via").find(v=>v.pcb_via_id===instance?.pcb_via_id),ports=(via?.pcb_port_ids??[]).map((id:string)=>newPp.find(p=>p.pcb_port_id===id)).filter((p:Row)=>p?.layers?.length===1&&p.layers[0]===m[2]);need(ports.length===1,"Unique actual pending via layer port required");const source=newSp.find(p=>p.source_port_id===ports[0].source_port_id);need(source,"Actual pending source port required");return {source,physical:ports[0]}}
 const auxiliaryWireChecks=plan.auxiliaryLocalTraces.map((a:Row)=>{const from=sourceSelector(a.fromSelector),to=sourceSelector(a.toSelector),sources=rows("source_trace").filter(t=>t.name===a.name&&canonical(t.connected_source_port_ids)===canonical([from.source.source_port_id,to.source.source_port_id])),fresh=sources.length===1?rows("pcb_trace").filter(t=>t.source_trace_id===sources[0].source_trace_id):[],expectedWire=wireGeometry(a.absolutePoints.map((p:Row)=>({...p,route_type:"wire",layer:"top",width:.1016}))),actual=fresh[0],first=actual?.route[0],last=actual?.route.at(-1),attached=first?.start_pcb_port_id===from.physical.pcb_port_id&&last?.end_pcb_port_id===to.physical.pcb_port_id;return {name:a.name,pendingOwner:a.originalSourceTraceId,actualFreshSourceTraceId:sources[0]?.source_trace_id,actualFreshPcbTraceId:actual?.pcb_trace_id,actualFromPortId:from.physical.pcb_port_id,actualToPortId:to.physical.pcb_port_id,passed:pendingOwnerIds.includes(a.originalSourceTraceId)&&sources.length===1&&fresh.length===1&&geometrySame(wireGeometry(actual.route),expectedWire)&&attached&&planar(actual.route)>1e-8}})
 check("all-pending-auxiliary-local-top-traces-real-and-exact",auxiliaryWireChecks.length===A&&auxiliaryWireChecks.every((r:Row)=>r.passed),auxiliaryWireChecks.filter((r:Row)=>r.passed).length,A)
 const pendingEmptyBodyChecks=pendingOwnerIds.map(sid=>{const actual=logical.find((r:Row)=>r.originalSourceTraceId===sid),fresh=rows("pcb_trace").filter(t=>t.source_trace_id===actual.actualSourceTraceId);return {originalSourceTraceId:sid,physicalBodyTraceCount:fresh.length,passed:fresh.length===0}})
 check("all-pending-original-bodies-removed",pendingEmptyBodyChecks.every(r=>r.passed),pendingEmptyBodyChecks.filter(r=>r.passed).length,pendingOwnerIds.length)
 const generatedWireChecks=plan.projectedGeometry.map((g:Row)=>{const actualOwner=logical.find((r:Row)=>r.originalSourceTraceId===g.originalSourceTraceId),fresh=rows("pcb_trace").filter(t=>t.source_trace_id===actualOwner.actualSourceTraceId),expectedRuns=g.wireRuns.map((r:Row)=>wireGeometry(r.absolutePoints.map((p:Row)=>({...p,route_type:"wire",layer:r.layer,width:.1016})))),length=fresh.reduce((s,t)=>s+planar(t.route),0),cohort=cohortByOwner.get(g.originalSourceTraceId),cap=cohort==="DDR_BYTE0"?11.8:cohort==="DDR_BYTE1"?14.2:cohort==="DDR_COMMAND_CLOCK"?22.29:Infinity,minimum=cohort==="DDR_COMMAND_CLOCK"?20.95:0;return {originalSourceTraceId:g.originalSourceTraceId,cohort,actualWholePlanarMm:length,expectedWholePlanarMm:plan.planarAudit.lengths[g.originalSourceTraceId],timingObservationOnly:{minimumMm:minimum,maximumMm:Number.isFinite(cap)?cap:null,aboveMinimum:length>=minimum-1e-8,withinMaximum:length<=cap+1e-8},passed:fresh.length===expectedRuns.length&&fresh.every((t,i)=>geometrySame(wireGeometry(t.route),expectedRuns[i]))&&close(length,plan.planarAudit.lengths[g.originalSourceTraceId])}})
 check("all-routed-source-wire-runs-and-planar-lengths",generatedWireChecks.length===routedOwnerIds.length&&generatedWireChecks.every((r:Row)=>r.passed),generatedWireChecks.filter((r:Row)=>r.passed).length,routedOwnerIds.length)
 const timingObservations:Row={observationsOnly:true,usedAsReplayControlGate:false,originalRulesPreserved:true,cohorts:[],pairs:[]}
 for(const cohort of ["DDR_BYTE0","DDR_BYTE1","DDR_COMMAND_CLOCK"]){const values=generatedWireChecks.filter((r:Row)=>r.cohort===cohort).map((r:Row)=>r.actualWholePlanarMm),skew=values.length?Math.max(...values)-Math.min(...values):null;timingObservations.cohorts.push({cohort,routedMembers:values.length,skewMm:skew,toleranceMm:.635,withinTolerance:skew!==null&&skew<=.635+1e-8})}
 for(const pair of oldRows("source_bus").filter(b=>["DDR_DQS0_PAIR","DDR_DQS1_PAIR","DDR_CK_PAIR"].includes(b.name))){const values=generatedWireChecks.filter((r:Row)=>pair.source_trace_ids.includes(r.originalSourceTraceId)).map((r:Row)=>r.actualWholePlanarMm),skew=values.length===2?Math.abs(values[0]-values[1]):null;timingObservations.pairs.push({pair:pair.name,routedMembers:values.length,skewMm:skew,toleranceMm:.127,withinTolerance:skew!==null&&skew<=.127+1e-8})}
 const graphs=logical.map((r:Row)=>{const adjacency=new Map<string,Set<string>>(),edge=(a:string,b:string)=>{if(!a||!b)return;for(const[x,y]of[[a,b],[b,a]]){if(!adjacency.has(x))adjacency.set(x,new Set());adjacency.get(x)!.add(y)}};const ownedSourceIds=new Set([r.actualSourceTraceId,...auxiliaryWireChecks.filter((a:Row)=>a.pendingOwner===r.originalSourceTraceId).map((a:Row)=>a.actualFreshSourceTraceId)]);for(const t of rows("pcb_trace").filter(t=>ownedSourceIds.has(t.source_trace_id)))edge(t.route[0]?.start_pcb_port_id,t.route.at(-1)?.end_pcb_port_id);for(const v of rows("pcb_via"))for(const p of v.pcb_port_ids??[])edge(p,v.pcb_via_id);const [start,end]=r.actualNumericPcbPortIds,seen=new Set([start]),queue=[start];for(let i=0;i<queue.length;i++)for(const next of adjacency.get(queue[i])??[])if(!seen.has(next)){seen.add(next);queue.push(next)}return {originalSourceTraceId:r.originalSourceTraceId,includedAuxiliarySourceTraceIds:[...ownedSourceIds].filter(id=>id!==r.actualSourceTraceId),physicallyConnectedByActualOwnedNumericIdGraph:seen.has(end)}})
 check("actual-owned-graphs-routed-connected-and-pending-disconnected",graphs.filter((r:Row)=>r.physicallyConnectedByActualOwnedNumericIdGraph).length===routedOwnerIds.length,graphs.filter((r:Row)=>r.physicallyConnectedByActualOwnedNumericIdGraph).length,routedOwnerIds.length)
 const expectedConnected=new Set<string>(routedOwnerIds)
 check("exact-routed-connected-pending-disconnected-roster",expectedConnected.size===routedOwnerIds.length&&graphs.every((r:Row)=>r.physicallyConnectedByActualOwnedNumericIdGraph===expectedConnected.has(r.originalSourceTraceId)),graphs.filter((r:Row)=>r.physicallyConnectedByActualOwnedNumericIdGraph).map((r:Row)=>r.originalSourceTraceId),[...expectedConnected])
 need(checks.length===35,"Combined two-cap/two-PDN successor retains all35 explicit replay controls")
 const passed=checks.every(r=>r.passed)
 need(sha(fs.readFileSync(rawPath))===freshRawSha256,"Unedited actual Core raw output changed during controls")
 assertInputPinsUnchanged();need(sha(fs.readFileSync(CORE_PATH))===CORE_SHA,"Pinned Core changed during render");need(sha(fs.readFileSync(args.get("--capture")!))===args.get("--capture-sha"),"Passed capture changed during Core render")
 write(output,{scope:"PARTIAL_MIXED_JOINED_FRESH_EDITABLE_CORE_CONTROLS",cap8HardwareDelta:cap8,cap8HardwareDeltaProfile:cap8.profile,combinedHardwareExpectations,immutableInputPinsUnchanged:true,cap12HardwareDelta:cap12,cap12HardwareDeltaProfile:cap12.profile,candidateSha256:args.get("--candidate-sha"),explicitPlanSha256:args.get("--plan-sha"),actualCaptureSha256:args.get("--capture-sha"),freshCoreControlPassed:passed,partialCoreControlPassed:passed,partialDiagnosticReplayControlsPassed:passed,checks,planPath,planSha256,augmentedPlanSha256,actualCapturePath:path.resolve(args.get("--capture")!),rawCorePath:rawPath,rawCoreSha256:freshRawSha256,expectedCounts:expected,components,landChecks,logical49Projection:logical,originalBusSemanticChecks:busChecks,heldCarrierChecks,referenceChecks,heldViaChecks:viaChecks,heldSignalStubChecks:heldStubChecks,generatedViaChecks:newViaChecks,generatedWireChecks,auxiliaryWireChecks,pendingEmptyBodyChecks,timingObservations,physicalGraphs:graphs,routedOwnerIds,pendingOwnerIds,expectedConnectedOwners:routedOwnerIds.length,expectedPendingOwners:pendingOwnerIds.length,registeredInnerPorts:registrations,sourceRuleBridge:replay.auditPlan.effectiveConstraintBridge,partialLayerProfile:plan.partialLayerProfile,mixedPhysicalQualificationBoundary:qualificationBoundary,...qualificationBoundary,projectorCandidateDiagnostics:candidateDiagnostics,sourceNumericIdsDerivedFromActualRows:true,freshCoreDerived:true,capturedIdsUsedAsFreshIds:false,circuitJsonGeometryEdited:false,rawIdsAssigned:false,all49Connected:passed&&pendingOwnerIds.length===0,all49Accepted:false,full49Accepted:false,fullBoardPassed:false,electricalTimingQualified:false,referenceQualified:false,fabricationReady:false})
 process.stdout.write(JSON.stringify({stage,output,rawPath,passed,checkCount:checks.length,full49Accepted:false})+"\n");if(!passed)process.exitCode=2
}
try{await main()}catch(error:unknown){
 const e=error as {name?:unknown;message?:unknown}|null
 process.stderr.write(JSON.stringify({diagnostic:"CAP12_CAP8_TWO_PDN_CAPTURE_CORE_FAILURE",lastStage:lastDiagnosticStage,name:String(e?.name??typeof error),message:String(e?.message??error)})+"\n")
 throw error
}
