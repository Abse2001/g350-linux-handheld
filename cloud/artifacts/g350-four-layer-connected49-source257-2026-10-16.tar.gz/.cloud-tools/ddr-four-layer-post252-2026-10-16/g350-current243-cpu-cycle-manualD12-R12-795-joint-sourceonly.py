"""Pure stdlib proof of complete manual D12 in an explicit conditional CPU fanout cycle.
No SDK/native/source/CAD checks. The authentic cap8 relocation still requires two references.
"""
ns={};s=open('/tmp/g350-current243-cpu-cycle-D12-I2-trunk-frontier-sourceonly.py').read();exec(s[:s.index('rows=[]')],ns)
for k in ('g','xy','json','math','Path','hashlib','r','P','PIN','RPIN','bodyinvs','removed'):globals()[k]=ns[k]
p=json.loads(Path(P).read_text());f=p['full49FanoutInput'];own=lambda t:t.get('connection_name') or t.get('source_trace_id');clone=lambda v:json.loads(json.dumps(v))
paths=[('inner1',[(0,15.2),(-.4134,14.7866),(-.4134,12.6634),(0,12.25)]),('inner2',[(0,12.25),(.6,12.25),(.8,12.05),(.8,8.35),(1.2,7.95)]),('top',[(1.2,7.95),(1.35,7.8),(3,7.8),(4.8,6),(4.8,5.8)])]
route=[]
for j,(layer,ps) in enumerate(paths):
 if j:route.append({'route_type':'via','x':ps[0][0],'y':ps[0][1],'from_layer':paths[j-1][0],'to_layer':layer,'layers':g['L'],'via_diameter':.4572,'via_hole_diameter':.254})
 route += [{'route_type':'wire','x':a[0],'y':a[1],'layer':layer,'width':.1016} for a in ps]
route[0]['pointId']='pcb_via_179';route[-1].update({'pointId':'pcb_port_375','pcb_port_id':'pcb_port_375'})
d12={'type':'pcb_trace','pcb_trace_id':'planned_cpu_cycle_manual_source_trace_26','connection_name':'source_trace_26','source_trace_id':'source_trace_26','route':route}
# Authentic complete branch/request before/after inverse for exact selected I1 CPU + numeric Top RAM.
cidx=next(i for i,c in enumerate(f['connections']) if c['name']=='source_trace_26');c=f['connections'][cidx];cpu=next((i,t) for i,t in enumerate(f['traces']) if t['pcb_trace_id']=='pcb_trace_66');ram=next((i,t) for i,t in enumerate(f['traces']) if t['pcb_trace_id']=='pcb_trace_68')
assert own(cpu[1])==own(ram[1])=='source_trace_26' and cpu[1]['route'][0]['start_pcb_port_id']=='pcb_port_63' and ram[1]['route'][0]['end_pcb_port_id']=='pcb_port_375'
cpuafter=clone(cpu[1]);cpuafter['route'][2]['to_layer']='inner1';cpuafter['route'][3]['layer']='inner1'
ramafter=clone(ram[1]);first=ramafter['route'][0];first.pop('start_pcb_port_id',None);first.pop('end_pcb_port_id',None);first['start_pcb_port_id']='pcb_port_375';ramafter['route']=[first];ramafter['trace_length']=0
cafter=clone(c);cafter['pointsToConnect']=[{'x':0,'y':15.2,'layer':'inner1','pointId':'pcb_via_179'},{'x':4.8,'y':5.8,'layer':'top','pointId':'pcb_port_375','pcb_port_id':'pcb_port_375'}]
endpointInverse={'connectionName':'source_trace_26','sourceTraceId':'source_trace_26','connection':{'index':cidx,'before':c,'after':cafter},'branches':[{'index':cpu[0],'before':cpu[1],'after':cpuafter},{'index':ram[0],'before':ram[1],'after':ramafter}],'releasedRamPhysicalBarrel':next(q for q in ram[1]['route'] if q['route_type']=='via'),'actualCpuNumericPcbPort':'pcb_port_63','actualRamNumericPcbPort':'pcb_port_375','noAlternateBarrelGoal':True}
wireHits=[]
for layer,ps in paths:
 for i,(a,b) in enumerate(zip(ps,ps[1:])):
  hs=g['wireContacts'](xy(a),xy(b),layer)
  if hs:wireHits.append({'layer':layer,'index':i,'a':a,'b':b,'contacts':[(o['owner'],o['id'],o.get('index',-1)) for o in hs]})
viaHits=[{'point':xy(v),'contacts':[(o['owner'],o['id'],o.get('index',-1)) for o in g['viaContacts'](xy(v))]} for v in [(0,12.25),(1.2,7.95)]]
# Reciprocal changed/unchanged owner material against ONLY new D12 material.
focus=ns['focus'];rcontact=[]
changed={inv['before']['pcb_trace_id']:inv['after'] for inv in bodyinvs+r['cpuFanoutInverses']}
all48=[*p['heldCarrierTraces'],*[next((inv['after'] for inv in bodyinvs if own(inv['after'])==own(t)),t) for t in p['ordinaryCarrierTraces']]]
for t in all48:
 n=int(own(t).split('_')[-1]);h=focus(n,P,PIN);h['objects'][:]=[]
 for i,q in enumerate(route):
  if q['route_type']=='via':o={'kind':'via','p':q,'radius':.2286,'holeRadius':.127,'layers':g['L'],'index':i,'owner':'source_trace_26','id':d12['pcb_trace_id']};o['bbox']=h['bbox'](o);h['objects'].append(o)
  elif i and route[i-1]['route_type']=='wire' and route[i-1]['layer']==q['layer']:
   a=route[i-1];o={'kind':'wire','a':a,'b':q,'radius':.0508,'layers':[q['layer']],'index':i,'owner':'source_trace_26','id':d12['pcb_trace_id']};o['bbox']=h['bbox'](o);h['objects'].append(o)
 contacts=[]
 for z in [t,*[changed.get(z['pcb_trace_id'],z) for z in f['traces'] if own(z)==own(t)]]:
  for i,q in enumerate(z['route']):
   if q['route_type']=='via':hs=h['viaContacts'](q)
   elif i and z['route'][i-1]['route_type']=='wire' and z['route'][i-1]['layer']==q['layer']:hs=h['wireContacts'](z['route'][i-1],q,q['layer'])
   else:continue
   if hs:contacts.append({'physicalId':z['pcb_trace_id'],'index':i,'contacts':[(o['owner'],o['id'],o.get('index',-1)) for o in hs]})
 rcontact.append({'owner':own(t),'contactsWithNewD12':contacts,'passedPureReciprocalScreen':not contacts})
angles=[]
for layer,ps in paths:
 aa=[math.degrees(math.atan2(b[1]-a[1],b[0]-a[0])) for a,b in zip(ps,ps[1:])];turns=[abs((b-a+180)%360-180) for a,b in zip(aa,aa[1:])];assert all(abs(a/45-round(a/45))<1e-7 for a in aa) and all(a<=45+1e-7 for a in turns);angles.append({'layer':layer,'headingsDegrees':aa,'turnsDegrees':turns})
# Pure same-layer nonadjacent wire centerline spacing; native corner neighborhoods stay runtime-owned.
selfHits=[]
for layer,ps in paths:
 for i,(a,b) in enumerate(zip(ps,ps[1:])):
  for j,(c,d) in enumerate(zip(ps,ps[1:])):
   if j<=i+1:continue
   distance=g['sd'](xy(a),xy(b),xy(c),xy(d))
   if distance<.2032-1e-8:selfHits.append({'layer':layer,'segments':[i,j],'distanceMm':distance,'adjacentCornerNeighborhoodMayApply':j==i+2})
fanout=math.sqrt(.32);bodyLength=sum(math.dist(a,b) for _,ps in paths for a,b in zip(ps,ps[1:]));whole=fanout+bodyLength
out={'scope':'PURE_COMPLETE_MANUAL_D12_WITH_CONDITIONAL_CPU42_A16_11SW_2NE_35_LEFT_AND_AUTHENTIC_CAP8_OVERLAY_PENDING_NO_SDK_NO_ACCEPTANCE','inputPath':P,'inputSha256':PIN,'jointPlanningProofPath':'/tmp/g350-current243-cpu-cycle42A16-11SW-2NE-joint-planning-screen-report.json','jointPlanningProofSha256':RPIN,'manualD12Carrier':d12,'paths':paths,'newCarrierViaCount':2,'allViasStandardFullspan':True,'wholePlanarLengthMm':whole,'actualCpuFanoutMm':fanout,'actualRamFanoutMm':0,'derivedWindowMm':[12.907653789032027,14.177653789032021],'minimumMatched':whole>=12.907653789032027,'maximumSatisfied':whole<=14.177653789032021,'endpointInverse':endpointInverse,'foreignWireContacts':wireHits,'foreignViaContacts':viaHits,'allForeignD12ContactsZero':not wireHits and not any(z['contacts'] for z in viaHits),'reciprocalAll48':[v for v in rcontact],'all48ClearOfNewD12Pure':all(v['passedPureReciprocalScreen'] for v in rcontact),'nativeHeadingPlanning':angles,'ownNonadjacentCloseSegments':selfHits,'cap8PlacementAndBothReferencesStillPending':True,'nativeOwnTerminalC31SourceAll49CriticalChecksPending':True,'originalCriticalSixHeldLiteral':True,'all49Accepted':False,'matched':False,'timingPassed':False,'fabricationReady':False}
O='/tmp/g350-current243-cpu-cycle-manualD12-R12-795-joint-report.json';Path(O).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'path':O,'sha256':hashlib.sha256(Path(O).read_bytes()).hexdigest(),'whole':whole,'allForeignD12ContactsZero':out['allForeignD12ContactsZero'],'all48ClearOfNewD12Pure':out['all48ClearOfNewD12Pure'],'self':selfHits},indent=2))
