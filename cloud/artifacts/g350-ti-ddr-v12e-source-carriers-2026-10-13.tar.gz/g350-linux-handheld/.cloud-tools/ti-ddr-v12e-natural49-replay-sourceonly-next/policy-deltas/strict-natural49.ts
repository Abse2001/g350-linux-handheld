/** PREPARATION ONLY. Caller must bind a real natural public output first.
 * Importing this module invokes no native checker, Scene, Grid or router. */
import assert from "node:assert/strict"
import { createHash } from "node:crypto"
import type { SimpleRouteJson, Trace } from "./source/lib/types"

const hash = (value: unknown) =>
  createHash("sha256").update(JSON.stringify(value)).digest("hex")

/** Registered reference vias are physical copper contacts; real cap pads are
 * the only component terminals. This does not create 51 routing requests. */
export function providedReferenceDrcView(
  input: SimpleRouteJson,
  output: SimpleRouteJson,
  registry: any,
) {
  assert(input.connections.length === 49 && input.obstacles.length === 856)
  assert(input.traces?.length === 2 && output.traces?.length === 51)
  assert(
    registry.sourceLayoutSha256 ===
      "0e2ce064e896db1d087474716d2e82b86155dbe28eecf28ce1727e73a466fee1",
  )
  assert(registry.sourceBindingVerifiedPureData === true)
  assert(Array.isArray(registry.owners) && registry.owners.length === 2)
  assert(hash(output.traces.slice(0, 2)) === hash(input.traces))
  for (const [i, owner] of registry.owners.entries()) {
    const name = `source_trace_${932 + i}`
    const net = i === 0 ? "source_net_5" : "source_net_0"
    const capPort = `pcb_port_${727 + i}`
    const aliasPort = i === 0 ? "pcb_port_1162" : "pcb_port_1164"
    assert(owner.name === name && owner.source_trace_id === name)
    assert(owner.rootConnectionName === net && owner.netConnectionName === net)
    assert(owner.providedCopperOwnerOnly === true)
    assert(owner.pointsToConnect.length === 1)
    const point = owner.pointsToConnect[0]
    const cap = registry.pcbPorts.find((p: any) => p.pcb_port_id === capPort)
    assert(cap?.pcb_component_id === "pcb_component_131")
    assert(point.pcb_port_id === capPort && point.layer === "bottom")
    assert(point.x === cap.x && point.y === cap.y)
    assert(owner.viaAliasContacts.length === 1)
    assert(owner.viaAliasContacts[0].pcb_port_id === aliasPort)
    const physicalVia = registry.physicalVias.find(
      (v: any) => v.pcb_via_id === `pcb_via_${i}`,
    )
    const fixed: Trace | undefined = input.traces.find(
      (t) => t.source_trace_id === name,
    )
    const routeVia: Trace["route"][number] | undefined = fixed?.route.find(
      (p) => p.route_type === "via",
    )
    assert(physicalVia?.source_net_id === net && routeVia?.route_type === "via")
    assert(routeVia.x === physicalVia.x && routeVia.y === physicalVia.y)
    assert(
      routeVia.via_diameter === 0.4572 && routeVia.via_hole_diameter === 0.254,
    )
    assert(routeVia.from_layer === "top" && routeVia.to_layer === "bottom")
    assert(
      hash(routeVia.layers) === hash(["top", "inner1", "inner2", "bottom"]),
    )
    const obstacle = input.obstacles.find(
      (o: any) => o.circuitJsonMetadata?.pcb_via_id === physicalVia.pcb_via_id,
    )
    assert(obstacle && obstacle.connectedTo.includes(name))
    assert(obstacle.connectedTo.includes(net))
    assert(
      obstacle.center.x === physicalVia.x &&
        obstacle.center.y === physicalVia.y,
    )
    assert(obstacle.width === 0.4572 && obstacle.height === 0.4572)
    assert(hash(obstacle.layers) === hash(routeVia.layers))
  }
  assert(new Set(registry.owners.map((o: any) => o.name)).size === 2)
  assert(
    registry.owners.every(
      (o: any) => !input.connections.some((c) => c.name === o.name),
    ),
  )
  const connections = [...input.connections, ...registry.owners]
  return {
    input: { ...input, connections },
    output: { ...output, connections },
  }
}

/** Actual invocation is held for root's real-output GO. No joining, tuning,
 * routing, output rewriting or replacement of original physical predicates. */
export async function qualifyNatural49Geometry(
  input: SimpleRouteJson,
  output: SimpleRouteJson,
  registry: any,
) {
  const before = hash({ input, output, registry })
  const physicalView = providedReferenceDrcView(input, output, registry)
  assert(
    hash({ ...input, traces: undefined }) ===
      hash({ ...output, traces: undefined }),
  )
  const traces: Trace[] = output.traces!.slice(2)
  const names = traces.map((t) => t.connection_name)
  assert(traces.length === 49 && new Set(names).size === 49)
  assert(names.every((n) => input.connections.some((c) => c.name === n)))
  // These original API imports occur only upon an explicit qualified call.
  const { validateG350Am3352Sample } = await import(
    "./source/scripts/validate-g350-am3352-sample"
  )
  const { nativeSignalGeometryIsValid } = await import(
    "./source/lib/native-signal-geometry"
  )
  const { busLengthReports, pairLengthReports } = await import(
    "./source/lib/route-lengths"
  )
  const native = validateG350Am3352Sample(input, output, physicalView)
  const angles = traces.map((t) => ({
    name: t.connection_name,
    valid: nativeSignalGeometryIsValid(t),
  }))
  const count = new Map(
    traces.map((t) => [
      t.connection_name!,
      t.route.filter((p) => p.route_type === "via").length,
    ]),
  )
  const charged = (report: ReturnType<typeof busLengthReports>[number]) => {
    const members = report.lengths.map((m) => ({
      name: m.name,
      planarMm: m.totalLengthMm,
      viaCount: count.get(m.name) ?? null,
      chargedMm:
        m.totalLengthMm === null || !count.has(m.name)
          ? null
          : m.totalLengthMm + 1.6 * count.get(m.name)!,
    }))
    const complete = members.every(
      (m) => m.chargedMm !== null && m.viaCount !== null,
    )
    const values = members.map((m) => m.chargedMm ?? 0)
    const viaCounts = members.map((m) => m.viaCount ?? 0)
    const skewMm = complete ? Math.max(...values) - Math.min(...values) : null
    const viaCountSkew = complete
      ? Math.max(...viaCounts) - Math.min(...viaCounts)
      : null
    return {
      group: report.busId,
      members,
      complete,
      viaCountSkew,
      zeroViaCountSkew: complete && viaCountSkew === 0,
      chargedSkewMm: skewMm,
      toleranceMm: report.toleranceMm,
      chargedMatched:
        complete &&
        (report.toleranceMm === null || skewMm! <= report.toleranceMm + 1e-7),
      absoluteTiBoundsApplyTo:
        "TOTAL_PLANAR_ONLY; never add via charge to absolute TI min/max",
    }
  }
  const buses = busLengthReports(input, traces).map(charged)
  const pairs = pairLengthReports(input, traces).map(charged)
  const chargedMatched = [...buses, ...pairs].every(
    (r) => r.chargedMatched && r.zeroViaCountSkew,
  )
  assert(
    hash({ input, output, registry }) === before,
    "Qualification mutated physical inputs",
  )
  return {
    native49GeometryPassed:
      native.valid && angles.every((r) => r.valid) && chargedMatched,
    native,
    nativeAngles: angles,
    planarAndChargedMatching: {
      viaChargeMm: 1.6,
      buses,
      pairs,
      matched: chargedMatched,
      exactTwoViasRequired: false,
    },
    physicalIngestion: {
      requestedSignals: 49,
      semanticDrcOwners: physicalView.input.connections.length,
      physicalReferences: 2,
      obstacles: physicalView.input.obstacles.length,
      allCopperTraces: physicalView.output.traces!.length,
    },
    inputAndOutputUnchanged: true,
    tiClassSpacingAndExposureQualified: false,
    fullBoardReferencePlanesQualified: false,
    impedanceQualified: false,
    electricalTimingQualified: false,
    accepted49: false,
    fabricationReady: false,
    pending:
      "Separate independent TI class/exposure/declaration gate plus full-board qualification; this function alone cannot assert acceptance",
  }
}
