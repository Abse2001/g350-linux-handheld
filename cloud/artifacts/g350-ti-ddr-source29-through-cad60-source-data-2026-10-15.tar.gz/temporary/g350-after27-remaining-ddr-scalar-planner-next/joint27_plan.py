"""Own finite scalar planner; no application imports or executions."""
import copy,json,math,pathlib,sys
sys.path.insert(0,'/tmp/g350-after26-remaining-ddr-scalar-planner-next');import joint26_plan as q
g=q.g;ROOT=pathlib.Path(__file__).resolve().parent
P=pathlib.Path('/tmp/g350-source7-moved144-inner1-joint26-geometry-sourceonly-next/SOURCE7_MOVED144_INNER1_PROPOSAL.json');assert g.sha(P)=='566615ece9d7ccb0bc7ba84092fc79cbc8d1191134b5e492f8214a65c4ebcff2';C=json.loads(P.read_bytes())
q.PRIMS=[p for p in q.PRIMS if p['id']!='pcb_via_144'and not p['id'].startswith('pcb_trace_244:')]
x,y=C['existingRamBarrelMove']['toXY'];r=.2286;q.PRIMS.append(dict(kind='circle',geom=(x,y),rad=r,layers=g.LAYERS,owners={'source_trace_7','pcb_via_144'},id='planned27_moved_pcb_via_144',bbox=(x-r,y-r,x+r,y+r)))
q.segment(C['changedRamTopStubNumericToViaPoints'],'top','source_trace_7','planned27_source7_ram_top');q.segment(C['newInner1CarrierPoints'],'inner1','source_trace_7','planned27_source7_i1')
BASE=copy.deepcopy(q.PRIMS)
PROPOSAL=json.loads(pathlib.Path('/tmp/g350-source27-source7-editable-over26-sourceonly-next/source27-proposal.json').read_bytes());BRANCHES={(b['originalSourceTraceId'],b['side']):b for b in PROPOSAL['all98NumericOwnedSignalBranches']}
OWNERS={(m['originalSourceTraceId'],m['side']):m for m in g.NATIVE['actualOwnershipProof']['signalMappings']}
def barrel(name,point):return min((q.distance(point,point,p)-p['rad']-.2286-g.GAP,p['id'])for p in q.PRIMS if name not in p['owners'])
def probe(name,side,point):
 q.PRIMS=copy.deepcopy(BASE)
 result=dict(name=name,side=side,xy=point,barrel=barrel(name,point))
 if result['barrel'][0]<1e-8:return result
 original=copy.deepcopy(g.CONNECTIONS[name]['pointsToConnect']);g.CONNECTIONS[name]['pointsToConnect'][side].update(x=point[0],y=point[1]);result['carrier']=q.search(name,'inner1',cap=40000)
 pad=g.xy(BRANCHES[name,side]['padXY'])
 for p,xy in zip(g.CONNECTIONS[name]['pointsToConnect'],(pad,point)):p['x'],p['y']=xy
 result['topStub']=q.search(name,'top',cap=35000)
 g.CONNECTIONS[name]['pointsToConnect']=original
 if result['carrier']['termination']=='FOUND'and result['topStub']['termination']=='FOUND':result['wholeBeforeTuningMm']=result['carrier']['carrierMm']+result['topStub']['carrierMm']+g.plen([g.xy(a)for a in BRANCHES[name,1-side]['topStub']])
 return result
if __name__=='__main__':
 results=[]
 for name in ['source_trace_20','source_trace_21']:
  for point in [(-8.2,7.8),(-8.2,6.2),(-7.4,6.2),(-9.,7.),(-9.,8.6),(-7.4,3.8),(-6.6,3.8),(-7.4,5.4),(-8.2,5.4),(-6.6,6.2)]:
   r=probe(name,1,point);results.append(r);print(json.dumps(r),flush=True)
 q.save=lambda *_:None
 p=ROOT/'CA20_CA21_RAM_PLACEMENT_FINITE_PROBES.json'
 with p.open('x')as f:json.dump(dict(scope='OWN_SCALAR_PROSPECTIVE27_CA_PLACEMENT_PROBES',geometrySource7Pin=str(P),results=results,globalInfeasibilityClaimed=False,anySourceAccepted=False),f,indent=2);f.write('\n')
 p.chmod(0o600)
