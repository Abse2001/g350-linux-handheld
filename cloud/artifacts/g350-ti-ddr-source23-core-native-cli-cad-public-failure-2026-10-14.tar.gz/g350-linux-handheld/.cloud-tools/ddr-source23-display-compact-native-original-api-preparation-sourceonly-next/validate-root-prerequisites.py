"""Stdlib-only future23 actual Source/types/Core0 verifier. Never launches apps.
All future artifact fields are unbound until Root fills actual collected values.
"""
import argparse,hashlib,json,re,stat
from pathlib import Path
SOURCE23='68798e7d9132d01d15cd2b67db31fdfe5d18bc745c86defd39de9e598129d565'
SDK='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'
SOLVER='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
SOURCE_PATH=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-owner23-display-offset-compact-source-successor-next/SOURCE-manifest.json')
def require(v,label):
 if not v:raise ValueError(label)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):h.update(block)
 return h.hexdigest()
def read(p):
 p=Path(p);require(p.is_absolute() and p.is_file() and not p.is_symlink() and p.stat().st_size<=32*1024*1024,'Concrete finite regular JSON input');return json.loads(p.read_bytes())
def exact(row):
 require(isinstance(row,dict) and isinstance(row.get('path'),str) and isinstance(row.get('sha256'),str) and re.fullmatch('[0-9a-f]{64}',row['sha256']),'Concrete actual binding, no placeholder')
 require(sha(row['path'])==row['sha256'],'Exact actual artifact SHA');return read(row['path'])
def verifyrows(rows):
 for row in rows:
  p=Path(row['path']);st=p.lstat();require(p.is_absolute() and stat.S_ISREG(st.st_mode) and not p.is_symlink(),'Regular bound Source')
  require(st.st_size==row['bytes'] and stat.S_IMODE(st.st_mode)==row['mode'] and sha(p)==row['sha256'],'Exact Source bytes/mode '+str(p))
def validate_collection(collection,post,phase,meta,core_source_sha):
 require(meta.get('phase')==phase and isinstance(meta.get('tool'),int) and meta['tool']>0 and isinstance(meta.get('scope'),str),'Actual phase/session/scope')
 require(collection['authorizedByRoot'] is True and collection['toolSessionId']==meta['tool'] and collection['scope']==meta['scope']==post['scope'],'Actual Root phase/session/scope')
 require(meta['scope']=='ACTUAL_ROOT_GENUINE_SOURCE_OWNER_MOVED_227_JOINT23' and collection['phase']==post['phase']==phase,'Exact actual genuine23 stage phase, never old18/22')
 require(collection['toolSessionCollected'] is True and collection['toolExitCode']==collection['toolWrapperExitCode']==0 and collection['passed'] is True,'Collected natural wrapper0/child0 prerequisite')
 require(collection['sourceManifestSha256']==post['sourceManifestSha256']==SOURCE23,'Exact genuine Source23 source31')
 require(core_source_sha==SOURCE23,'Same genuine31 Source seal includes capture and Core workers; no second seal invented')
 require(collection['sourceAndDependenciesHeld'] is True and post['sourceAndDependenciesHeld'] is True and post['passed'] is True,'Actual Source/SDK held')
 execution=collection['execution'];require(execution==post['execution'] and execution['exitCode']==0 and execution['diagnosticStopped'] is False and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values()),'Actual clean closed0/OOM0')
 require(post['dependenciesBefore']==post['dependenciesAfter'] and post['dependenciesAfter']['treeSha256']==SDK,'Exact ce3 before/after')
 require(post['solverDependenciesBefore']==post['solverDependenciesAfter'] and post['solverDependenciesAfter']['treeSha256']==SOLVER,'Exact476 before/after')
 require(collection['accepted49'] is False and collection['fabricationReady'] is False,'No broader acceptance')
 if phase=='core':require(collection['coreCalls']==1,'Exactly one fresh genuine Source23 Core render')
 require(isinstance(execution['pgid'],int) and execution['pgid']>1,'Authentic owned process group');return execution['pgid']
def validate_binding(m,a,msha):
 require(a.get('authorizedByRoot') is True and a.get('scope')==m['scope'] and a.get('packetSha256')==msha,'Source template cannot authorize')
 require(a.get('rootFullGuardReadPassed') is True and a.get('noConcurrentRootWorker') is True and a.get('allPreviousRootWorkersCollected') is True,'Root full read/serial prior actual closure')
 require(re.fullmatch('[0-9a-f]{32,128}',a.get('approvalToken','') or '') is not None,'Fresh Root token')
 require(a.get('sourceManifestSha256')==m.get('sourceManifestSha256') and isinstance(m.get('sourceManifestSha256'),str) and re.fullmatch('[0-9a-f]{64}',m['sourceManifestSha256']),'Native Source seal')
 require(m.get('genuineSource23ManifestSha256')==SOURCE23 and sha(SOURCE_PATH)==SOURCE23,'Exact genuine Source23')
 core_sha=m.get('coreSourceManifestSha256');require(core_sha==SOURCE23 and a.get('coreSourceManifestSha256')==SOURCE23,'Core workers are covered by the same genuine31 Source seal')
 require(a.get('freshArtifacts')==m.get('actualFreshArtifacts'),'Exact actual artifacts authority')
 require(a.get('requiredActualCollections')==m.get('requiredActualCollections') and set(m['requiredActualCollections'])=={'capture','types','core'},'All3 actual collections bound')
 policy=m['policy'];require(a.get('policy')==policy and policy['wallSeconds']==90 and policy['rssBytes']==1073741824 and policy['sharedBytes']==32212254720 and policy['sampleSeconds']==.05 and policy['termGraceSeconds']==5 and m['preforkReserveBytes']==1073741824,'Unchanged finite90s/1GiB/shared30GiB+1reserve')
 verifyrows(m['files']);verifyrows(m['externalFiles'])
 sm=read(SOURCE_PATH);verifyrows(sm['files']);verifyrows(sm['externalActualInputBindings']);verifyrows(sm['expandedLocalSourceAndControllerImportClosure'])
 require(m['expectedActualInventories']=={'vias':227,'traces':286,'pcbPorts':1651,'referenceMappings':165,'signalMappings':98,'carriers':23,'clocks':2,'expectedMissingOriginalSignalCount':26},'Exact moved23 inventory')
 peer=exact(a['nativeSourcePeerReview']);require(peer['sourceManifestSha256']==m['sourceManifestSha256'] and peer['decision']=='GO_SOURCE_ONLY_TO_ROOT_READ_AND_GUARDED_MOVED23_NATIVE_ALL3_APIS','Independent finite Source peer')
 pgids=[];posts={}
 for phase in ['capture','types','core']:
  meta=m['requiredActualCollections'][phase];collection=exact(meta);post=exact({'path':collection['postauditPath'],'sha256':collection['postauditSha256']});posts[phase]=post
  pgids.append(validate_collection(collection,post,phase,meta,core_sha));verifyrows(post['resultFileBindings'])
 artifacts=m['actualFreshArtifacts'];post=posts['core'];collection=exact(m['requiredActualCollections']['core']);require(collection['rawCorePath']==artifacts['actualCorePath'] and collection['rawCoreSha256']==artifacts['actualCoreSha256'] and collection['coreControlsPath']==artifacts['coreControlsPath'] and collection['coreControlsSha256']==artifacts['coreControlsSha256'],'Actual fresh23 collected raw/control0 outputs')
 raw=exact({'path':artifacts['actualCorePath'],'sha256':artifacts['actualCoreSha256']});controls=exact({'path':artifacts['coreControlsPath'],'sha256':artifacts['coreControlsSha256']})
 require(all(any(row['path']==p and row['sha256']==h for row in post['resultFileBindings']) for p,h in [(artifacts['actualCorePath'],artifacts['actualCoreSha256']),(artifacts['coreControlsPath'],artifacts['coreControlsSha256'])]),'Actual collected raw/controls')
 require(controls['scope']=='ROOT_FRESH_EDITABLE_SOURCE_CORE_OWNER_MOVED_227_JOINT23' and controls['rawCorePath']==artifacts['actualCorePath'] and controls['rawCoreSha256']==artifacts['actualCoreSha256'] and controls['freshCoreControlPassed'] is True and len(controls['checks'])==29 and all(c['passed'] is True for c in controls['checks']),'Actual29 fresh23 Core controls')
 require(controls['sourceNumericAndPhysicalIdsDerivedWithoutAssignment'] is True and controls['circuitJsonGeometryEdited'] is False and controls['pcbRoutingDisabled'] is True and controls['automaticCoreSrjForThisForkMustNotBeUsed'] is True and controls['expectedOriginalCarrierCount']==23 and controls['expectedMissingOriginalSignalCount']==26,'Genuine manual23,26 missing, no JSON geometry injection')
 require([sum(r['type']==t for r in raw)for t in ['pcb_via','pcb_trace','pcb_port']]==[227,286,1651],'Actual227/286/1651')
 return {'actualPreviousPgids':pgids,'rootOuterMustIndependentlyRequireOwnedGroupsEmptyNow':True,'rootOuterMustReinventoryCe3And476BeforeAfter':True,'rootOuterMustRequireSharedCurrentPlus1GiBRssPlus1GiBReserveBelow30GiB':True,'authorizedByThisValidator':False,'actualApplicationCalls':0}
def main():
 parser=argparse.ArgumentParser();parser.add_argument('binding',type=Path);parser.add_argument('binding_sha');parser.add_argument('root_authority',type=Path);parser.add_argument('root_authority_sha');args=parser.parse_args();m=exact({'path':str(args.binding),'sha256':args.binding_sha});a=exact({'path':str(args.root_authority),'sha256':args.root_authority_sha});print(json.dumps(validate_binding(m,a,args.binding_sha)))
if __name__=='__main__':main()
