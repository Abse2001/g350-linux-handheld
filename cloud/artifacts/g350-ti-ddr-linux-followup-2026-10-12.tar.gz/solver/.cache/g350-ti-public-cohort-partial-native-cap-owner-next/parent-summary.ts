import { strict as assert } from "node:assert"
import { createHash } from "node:crypto"
import { isDeepStrictEqual } from "node:util"
import type { OriginalCapture } from "./identity-order"
const sha = (value: string) => createHash("sha256").update(value).digest("hex")
/** Exact projection used by frozen original prefix runner186–190.
 * Boolean comparison keeps malformed-input diagnostic output bounded. */
export function validateParentCaptureSummaries(
  summaries: unknown,
  captures: OriginalCapture[],
) {
  const projected = captures.map(
    ({ arguments: args, result: value, ...summary }) => ({
      ...summary,
      argumentSha256: sha(JSON.stringify(args)),
      resultSha256: sha(JSON.stringify(value) ?? "undefined"),
    }),
  )
  assert.ok(
    isDeepStrictEqual(summaries, projected),
    "Actual parent-summary relationship changed",
  )
  return true
}
