#!/usr/bin/env python3
"""SOURCE ONLY: render exact243 cap12 partial48 with closed Source248/249/250 evidence.

Author did not execute/import this file or supplied code; Root owns rendering.

No SDK, native, Core or CAD execution. Frozen predecessor outputs stay intact.
"""
import argparse
import hashlib
import json
import io
import math
import os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', '/tmp/g350-plot248-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Circle, Rectangle
from matplotlib.transforms import Affine2D

CANDIDATE = Path('/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json')
CANDIDATE_SHA = 'cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
CRITICAL_REPORT = Path('/tmp/g350-joint48-critical-root-20261016-run244/byte0-result.json')
CRITICAL_SHA = '0867dce555fe0aea211bf269100b22cb21717ce2298551de7f071c967da05d99'
RAW_CORE = Path('/tmp/g350-cap12-48-core248-raw.json')
RAW_CORE_SHA = 'c5129a2ec734e873c209ab8cdccf2cad1753d177f1c87857ffae0cf7ff12a486'
CONTROLS = Path('/tmp/g350-cap12-48-core-diagnostic-root-20261016-run248/byte0-result.json')
CONTROLS_SHA = '5fb5a432d5854a8cccf689070d901ed4823a427cb42ec6487d474c50d081d525'
NATIVE = Path('/tmp/g350-cap12-48-native-root-20261016-run249/byte0-result.json')
NATIVE_SHA = '763ba597bf7708dbc508a2f42672da56e650eb5811eb916c3dd36edb4c048588'
AUTH = Path('/tmp/g350-cap12-48-via-track-root-20261016-run250/byte0-result.json')
AUTH_SHA = '28a4e908e638546542d97a21be165d14a7f6ba0c8ec77457e3820ae208cf1e7e'
POURS = Path('/tmp/g350-source248-all14-literal-pour-margin-root-aggregate-20261016.json')
POURS_SHA = '0eb6c21f4e27962f2f621f3586b3fd3d8bc7ca5f2f112a0741e1323c7260ae7a'
PLAN = Path('/tmp/g350-cap12-48-projector-root-20261016-run245/byte0-result.json')
PLAN_SHA = 'f57834ed51009d0a88df6a70beb6ea188284bae978516d8f389e254295425d64'
OUTPUT_DIR = Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-four-layer-post232-2026-10-16')
LAYERS = ['top', 'inner1', 'inner2', 'bottom']
COLORS = {'ordinary': '#16856d', 'source_trace_15': '#1170aa', 'source_trace_16': '#1170aa',
          'source_trace_27': '#dd761c', 'source_trace_28': '#dd761c',
          'source_trace_33': '#8b43b3', 'source_trace_34': '#8b43b3'}


def owner(trace):
    return trace.get('connection_name', trace.get('source_trace_id'))


def wire_segments(trace, layer):
    return [[(a['x'], a['y']), (b['x'], b['y'])] for a, b in zip(trace['route'], trace['route'][1:])
            if a['route_type'] == b['route_type'] == 'wire' and a['layer'] == b['layer'] == layer]


def pinned_json(location, expected_sha):
    data = location.read_bytes()
    if hashlib.sha256(data).hexdigest() != expected_sha:
        raise ValueError('Closed evidence hash mismatch: ' + str(location))
    return json.loads(data)


def require(value, message):
    if not value:
        raise ValueError(message)


def compact_run(points):
    result = []
    for p in points:
        q = (p['x'], p['y'])
        require(all(isinstance(x, (int, float)) and math.isfinite(x) for x in q), 'Finite actual wire coordinates required')
        if not result or math.dist(q, result[-1]) > 1e-8:
            result.append(q)
    return result


def same_run(a, b):
    return len(a) == len(b) and all(math.dist(x, y) <= 1e-8 for x, y in zip(a, b))


def joined_runs(trace):
    result, run, layer = [], [], None
    def flush():
        nonlocal run
        points = compact_run(run)
        if len(points) > 1:
            result.append((layer, points))
        run = []
    for point in trace['route']:
        if point['route_type'] != 'wire':
            flush(); layer = None
        else:
            if layer is not None and layer != point['layer']:
                flush()
            layer = point['layer']; run.append(point)
    flush()
    return result


def verify_closed_evidence(candidate, aggregate_path, aggregate_sha):
    require(aggregate_sha == POURS_SHA, 'Exact closed Source248 all-pour aggregate SHA required')
    raw, controls = pinned_json(RAW_CORE, RAW_CORE_SHA), pinned_json(CONTROLS, CONTROLS_SHA)
    plan = pinned_json(PLAN, PLAN_SHA)
    require(controls['rawCoreSha256'] == RAW_CORE_SHA and controls['freshCoreDerived'] is True and
            controls['partialDiagnosticReplayControlsPassed'] is True and len(controls['checks']) == 35 and
            all(c['passed'] is True for c in controls['checks']), 'Actual Source248 all35 replay controls must bind the exact raw')
    require(controls['planSha256'] == PLAN_SHA and controls['candidateSha256'] == CANDIDATE_SHA and
            controls['sourceRuleBridge']['candidatePin']['sha256'] == CANDIDATE_SHA and
            controls['referenceQualified'] is False, 'Exact candidate243/plan245 binding with reference qualification open')
    require(set(controls['pendingOwnerIds']) == {'source_trace_26'} and len(controls['routedOwnerIds']) == 48,
            'Exact48 routed/pending D12 roster')
    cap = plan['cap12HardwareDelta']
    require(plan['inputBindings']['candidate']['sha256'] == CANDIDATE_SHA and
            controls['cap12HardwareDelta'] == cap and cap['profile'] == 'CAP12_TRANSLATE_X_0P79_ONLY' and
            cap['component']['sourcePlacement'] == {
                'before': {'pcbX': 6, 'pcbY': 4.7, 'layer': 'bottom', 'pcbRotation': 180},
                'after': {'pcbX': 6.79, 'pcbY': 4.7, 'layer': 'bottom', 'pcbRotation': 180}} and
            candidate['requiredSourceHardwarePlacementDelta'] == cap['originalDeclaration'],
            'Exact declared cap12 placement and reference inverse ledger required')
    projected = {g['originalSourceTraceId']: g for g in plan['projectedGeometry']}
    logical = {g['originalSourceTraceId']: g for g in controls['logical49Projection']}
    joined = {owner(t): t for t in candidate['joinedNumericPadTraces']}
    require(set(projected) == set(joined) == set(controls['routedOwnerIds']), 'Exact candidate/source projected-owner roster')
    pcb_traces = [r for r in raw if r.get('type') == 'pcb_trace']
    wire_count = 0
    for sid, geometry in projected.items():
        expected = [(r['layer'], compact_run(r['absolutePoints'])) for r in geometry['wireRuns']]
        actual = []
        for trace in pcb_traces:
            if trace.get('source_trace_id') == logical[sid]['actualSourceTraceId']:
                points = compact_run(trace['route'])
                require(all(p['route_type'] == 'wire' for p in trace['route']), 'Source pcbPaths produce separate actual wire runs')
                actual.append((trace['route'][0]['layer'], points))
                wire_count += len(points) - 1
        for runs in (actual, joined_runs(joined[sid])):
            require(len(runs) == len(expected) and all(a[0] == b[0] and same_run(a[1], b[1]) for a, b in zip(runs, expected)),
                    'Exact raw248/candidate243 wire-run geometry must agree with plan245 for ' + sid)
    raw_pours = [r for r in raw if r.get('type') == 'pcb_copper_pour']
    via_count = sum(r.get('type') == 'pcb_via' for r in raw)
    require(via_count == controls['expectedCounts']['physicalVias'] == 129 + len(plan['newVias']) == 229,
            'Actual plan-derived229 via inventory required')
    native, auth = pinned_json(NATIVE, NATIVE_SHA), pinned_json(AUTH, AUTH_SHA)
    require(native['completed'] is True and native['finished'] is True and native['completedCheckCount'] == 16 and
            native['exceptionCount'] == 0 and native['inputBindings']['raw']['sha256'] == RAW_CORE_SHA and
            native['inputBindings']['controls']['sha256'] == CONTROLS_SHA, 'Exact closed focused16 native249 diagnostic required')
    results = {r['name']: r for r in native['results']}
    require(len(native['physical10']) == 10 and all(results[n]['findingCount'] == 0 for n in native['physical10']) and
            results['checkPcbBusLengthSkew']['findingCount'] == 3 and native['all32FreshNativeChecksExecuted'] is False,
            'All10 physical native checks zero and three bus-skew failures must remain explicit')
    require(auth['complete'] is True and auth['executed'] is True and auth['actualViaCount'] == via_count and
            auth['completedViaCount'] == via_count and auth['foreignViaTrackCopperClearancePassed'] is True and
            auth['inputBindings']['raw']['sha256'] == RAW_CORE_SHA and auth['inputBindings']['controls']['sha256'] == CONTROLS_SHA,
            'Exact closed authenticated229-via diagnostic250 required')
    require(all(not auth[k] for k in ['identityFailures', 'ambiguousVias', 'violations', 'invalidSegments', 'unresolvedSegmentOwners']),
            'Auth250 findings must remain zero')
    aggregate = pinned_json(aggregate_path, aggregate_sha)
    require(aggregate['scope'] == 'SOURCE248_PLAN245_ALL_ACTUAL_LITERAL_POURS_COMPLETED_COVERAGE_AGGREGATE_NOT_BOARD_QUALIFICATION' and
            aggregate['completed'] is True and aggregate['literalForeignPourMarginClear'] is True and
            aggregate['completedPourCount'] == aggregate['actualRawPourCount'] == len(raw_pours) and
            aggregate['completedPourIds'] == [r['pcb_copper_pour_id'] for r in raw_pours] and
            aggregate['actualViaCount'] == via_count and aggregate['wireSegmentCount'] == wire_count and
            aggregate['wireOwnerCount'] == 48 and aggregate['inputFilesUnchanged'] is True,
            'Complete exact Source248 dynamic pour/via/wire aggregate required')
    require(aggregate['inputBindings']['raw']['sha256'] == RAW_CORE_SHA and
            aggregate['inputBindings']['controls']['sha256'] == CONTROLS_SHA and
            aggregate['inputBindings']['current229Ownership']['sha256'] == AUTH_SHA and
            aggregate['inputBindings']['reviewedSourcePlan245']['sha256'] == PLAN_SHA and aggregate['violations'] == [],
            'Literal aggregate must bind these exact current inputs')
    cohorts = controls['timingObservations']['cohorts']
    require({r['cohort'] for r in cohorts} == {'DDR_BYTE0', 'DDR_BYTE1', 'DDR_COMMAND_CLOCK'} and
            all(r['withinTolerance'] is False for r in cohorts) and len(controls['timingObservations']['pairs']) == 3 and
            all(r['withinTolerance'] is True for r in controls['timingObservations']['pairs']),
            'Three bus-skew failures and three passed pair-skew observations remain explicit')
    for report in [controls, native, auth, aggregate]:
        require(report['fullBoardPassed'] is False and report['all49Accepted'] is False and report['fabricationReady'] is False,
                'Whole-board and fabrication acceptance flags must remain false')
    return {'pours': len(raw_pours), 'vias': via_count, 'wires': wire_count, 'cap': cap}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path, default=CANDIDATE)
    parser.add_argument('--output-dir', type=Path, default=OUTPUT_DIR)
    parser.add_argument('--pour-aggregate', type=Path, required=True)
    parser.add_argument('--pour-aggregate-sha', required=True)
    args = parser.parse_args()
    candidate = pinned_json(args.candidate, CANDIDATE_SHA)
    scene, bodies = candidate['full49FanoutInput'], candidate['carrierTraces']
    routed = {owner(t) for t in bodies}
    pending = [c for c in scene['connections'] if c['name'] not in routed]
    require(len(bodies) == len(routed) == 48 and {c['name'] for c in pending} == {'source_trace_26'},
            'Expected48 routed owners and only D12 pending')
    require(scene['allowedLayers'] == LAYERS and scene['layerCount'] == 4 and candidate['all49Accepted'] is False and
            candidate['fabricationReady'] is False, 'Exact partial four-layer candidate with fabricationReady=false')
    evidence = verify_closed_evidence(candidate, args.pour_aggregate, args.pour_aggregate_sha)
    physical = candidate['finalScenePhysicalReports']
    require(candidate['allSavedCarriersCurrentSceneQualified'] is True and len(physical) == 48 and all(r['passed'] for r in physical),
            'Actual243 all48 physical reports required')
    critical = pinned_json(CRITICAL_REPORT, CRITICAL_SHA)
    views = critical['criticalValidationViews']
    require(critical['inputSha256'] == CANDIDATE_SHA and critical['currentSceneCriticalAssertionsFreshlyQualified'] is True and
            critical['criticalProfileQualified'] is True and len(critical['criticalPhysicalReports']) == 6 and
            all(r['passed'] for r in critical['criticalPhysicalReports']), 'Exact244 critical6 physical evidence required')
    require(len(views) == 2 and {v['scope'] for v in views} == {'DQS1_LOWER_U_SHARED_VIEW', 'DQS1_EARLY_MEANDER_SHARED_VIEW'},
            'Both actual DQS1 shared-section views required')
    for view in views:
        require(view['passed'] is True and view['c31']['solved'] is True and
                set(view['reports']) == {'bus', 'pair', 'shared', 'coupling', 'exterior'} and
                all(len(rows) == 3 and all(r['matched'] for r in rows) for rows in view['reports'].values()),
                'Actual244 original five APIs and C31 must pass for all three critical pairs in both views')
    require(args.output_dir.resolve() == OUTPUT_DIR.resolve() and not args.output_dir.is_symlink(),
            'Only the new owned post232 visualization directory is authorized')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    outputs = [args.output_dir / ('SOURCE248_CAP12_PARTIAL48_FOUR_LAYER_MILESTONE.' + extension) for extension in ('png', 'svg')]
    require(not any(p.exists() for p in outputs), 'Fresh Source248 milestone output names required')
    fig, axes = plt.subplots(1, 4, figsize=(18, 9.5), sharex=True, sharey=True)
    for ax, layer in zip(axes, LAYERS):
        for obstacle in scene['obstacles']:
            if layer not in obstacle['layers']:
                continue
            x, y = obstacle['center']['x'], obstacle['center']['y']
            if x < -11 or x > 10 or y < 2 or y > 29:
                continue
            if obstacle.get('shape', obstacle.get('type')) == 'circle':
                patch = Circle((x, y), obstacle['width'] / 2)
            else:
                patch = Rectangle((x - obstacle['width'] / 2, y - obstacle['height'] / 2), obstacle['width'], obstacle['height'])
                patch.set_transform(Affine2D().rotate_deg_around(x, y, obstacle.get('ccwRotationDegrees', 0)) + ax.transData)
            patch.set(facecolor='#d5d9de', edgecolor='none', alpha=.55, zorder=1)
            ax.add_patch(patch)
        fixed = [segment for t in scene['traces'] for segment in wire_segments(t, layer)]
        ax.add_collection(LineCollection(fixed, colors='#aab2bb', linewidths=.5, zorder=2))
        for trace in scene['traces']:
            for p in trace['route']:
                if p['route_type'] == 'via' and layer in p.get('layers', []):
                    ax.add_patch(Circle((p['x'], p['y']), p.get('via_diameter', .4572) / 2, fill=False, edgecolor='#a5adb6', linewidth=.45, zorder=2))
        for trace in bodies:
            color = COLORS.get(owner(trace), COLORS['ordinary'])
            ax.add_collection(LineCollection(wire_segments(trace, layer), colors=color, linewidths=1.15, zorder=4))
            for p in trace['route']:
                if p['route_type'] == 'via' and layer in p.get('layers', []):
                    ax.add_patch(Circle((p['x'], p['y']), p['via_diameter'] / 2, fill=False, edgecolor=color, linewidth=.9, zorder=5))
        for connection in pending:
            a, b = connection['pointsToConnect']
            ax.plot([a['x'], b['x']], [a['y'], b['y']], color='#d9a21b', linewidth=.85, alpha=.9, linestyle=(0, (4, 3)), zorder=3)
            label = {'source_trace_26': 'D12 pending'}[connection['name']]
            ax.text((a['x'] + b['x']) / 2 + .12, (a['y'] + b['y']) / 2, label,
                    color='#9b6d03', fontsize=6, rotation=75, zorder=6,
                    bbox={'facecolor': 'white', 'edgecolor': 'none', 'alpha': .72, 'pad': .6})
        ax.add_patch(Rectangle((-7, 13), 14, 14, fill=False, edgecolor='#697386', linestyle='--', linewidth=.7))
        ax.add_patch(Rectangle((-5.01, 3.99), 12.42, 6.82, fill=False, edgecolor='#697386', linestyle='--', linewidth=.7))
        ax.text(-6.9, 26.35, 'AM3352', fontsize=8, color='#475467')
        ax.text(-4.9, 4.25, 'DDR3L', fontsize=8, color='#475467')
        ax.set(title={'top': 'Top', 'inner1': 'Inner1', 'inner2': 'Inner2', 'bottom': 'Bottom'}[layer],
               xlim=(-10.2, 9), ylim=(2.8, 28), aspect='equal', xlabel='X (mm)')
        ax.grid(alpha=.12)
        if layer == 'bottom':
            ax.annotate('C_DDR_RAM_12 +0.79 mm X', xy=(6.79, 4.7), xytext=(2.1, 3.15),
                        fontsize=6.3, color='#9c4707', arrowprops={'arrowstyle': '->', 'lw': .65, 'color': '#9c4707'}, zorder=7)
    axes[0].set_ylabel('Y (mm)')
    fig.suptitle('G350 · Source248 cap12 partial milestone · 48 of 49 DDR paths', fontsize=15, weight='bold', y=.965)
    fig.text(.5, .099, 'Green: ordinary routes   |   Blue: DQS0   |   Orange: DQS1   |   Purple: CK   |   Yellow dashed: D12 pending',
             ha='center', fontsize=10)
    fig.text(.5, .042,
             'Fresh editable Source248: 35/35 replay controls PASS. Native249: 10 physical checks zero; all three bus-skew checks fail.\n'
             + f"Auth250: {evidence['vias']} vias, zero foreign via-track violations. Literal {evidence['pours']} pours / {evidence['wires']} routed segments: zero margin violations.\n"
             + 'Cap12 +0.79 mm X with two explicit reference reroutes. Partial48/49; timing / TI / reference / independent CAD / fabrication unqualified; not default; fabricationReady=false.',
             ha='center', fontsize=8.6, color='#475467')
    fig.subplots_adjust(top=.92, bottom=.15, wspace=.13)
    bindings = [(args.candidate, CANDIDATE_SHA), (CRITICAL_REPORT, CRITICAL_SHA), (RAW_CORE, RAW_CORE_SHA),
                (CONTROLS, CONTROLS_SHA), (NATIVE, NATIVE_SHA), (AUTH, AUTH_SHA), (PLAN, PLAN_SHA),
                (args.pour_aggregate, args.pour_aggregate_sha)]
    require(all(hashlib.sha256(path.read_bytes()).hexdigest() == expected for path, expected in bindings),
            'All exact plot geometry/evidence inputs must remain unchanged')
    description = ('Exact243 geometry ' + CANDIDATE_SHA + '; Source248 raw ' + RAW_CORE_SHA + '; controls ' + CONTROLS_SHA
        + '; critical244 ' + CRITICAL_SHA + '; native249 ' + NATIVE_SHA + '; auth250 ' + AUTH_SHA
        + '; literal aggregate ' + args.pour_aggregate_sha + '; 48/49; pending26; cap12 X+.79 and two references; '
        + str(evidence['pours']) + ' actual pours/' + str(evidence['wires']) + ' routed segments/' + str(evidence['vias'])
        + ' vias; all three cohort skew checks fail; timing/TI/reference/CAD/fabrication unqualified; default unchanged; all49Accepted=false; fabricationReady=false.')
    for output, kind in zip(outputs, ('png', 'svg')):
        buffer = io.BytesIO()
        metadata = {'Description': description}
        if kind == 'svg':
            metadata['Date'] = None
        fig.savefig(buffer, format=kind, dpi=180, metadata=metadata)
        payload = buffer.getvalue()
        with output.open('xb') as stream:
            stream.write(payload)
        print(str(output) + ' ' + hashlib.sha256(payload).hexdigest())
    plt.close(fig)
    print(json.dumps({'candidateSha256': CANDIDATE_SHA, 'source248RawSha256': RAW_CORE_SHA,
                      'routedOwners': 48, 'pendingOwnerIds': ['source_trace_26'],
                      'actualPourCount': evidence['pours'], 'actualViaCount': evidence['vias'],
                      'actualRoutedWireSegmentCount': evidence['wires'], 'all49Accepted': False, 'fabricationReady': False}))


if __name__ == '__main__':
    main()
