 def closed64():
  prior=closed63();assert prior['actualClosedScopeCount']==63 and proposal['actual64ClosedSealed']is True
  for key in('actual64CollectionPin','actual64PostauditPin','actual64GuardManifestPin','actual64DiagnosticResultPin','actual64RawFinalStatePin','actual64AuthorityPin'):binding(proposal[key])
  r=read(proposal['actual64CollectionPin']['path']);p=read(proposal['actual64PostauditPin']['path']);e=p['execution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==88438 and r['toolWrapperExitCode']==r['toolExitCode']==2
  assert r['postauditPath']==proposal['actual64PostauditPin']['path']and r['postauditSha256']==proposal['actual64PostauditPin']['sha256']and r['execution']==e
  assert r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['toolSessionCollected']is False
  for k,v in p.items():
   if k!='toolSessionCollected':assert r[k]==v,'Corrected Root64 receipt preserves every historical POST value: '+k
  for doc in(r,p):
   assert doc['scope']=='ROOT_C31_CURRENT29_FULL49_PUBLIC_DIAGNOSTIC_WITH63_AUTHENTIC_PRIOR_CLOSURES'and doc['phase']=='public49-diagnostic'
   assert doc['sourceManifestSha256']==proposal['public49CallerPin']['sha256']and doc['rootGuardProposalManifestSha256']==proposal['actual64GuardManifestPin']['sha256']and doc['candidateSourceManifestSha256']==proposal['candidateSourcePin']['sha256']
   assert doc['runFailure']is doc['resultInspectionFailure']is None and doc['postverificationFailure']=='AssertionError: '
   for key in('sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','stageNaturallyCompleted','diagnosticCompleted','passed'):assert doc[key]is False
   for key in('actualOriginalStepCalls','actualGeneratedCarrierCount','naturalSdkSolved','naturalSdkFailed'):assert doc[key]is None
   assert doc['ownedGroupEmptyActuallyObserved']is True and doc['currentInputActualSource29']is doc['all49RequestsAnd263FixedRowsAnd1298ObstaclesAnd98EventsPreserved']is True and doc['staticCompleted29BodiesSeeded']is False
   assert doc['publicConstructorLimit']==1 and doc['publicStepLimit']==40000 and doc['checkpointCountLimit']==41 and doc['checkpointTotalByteLimit']==40000000 and doc['workspaceFreeBytesBefore']==3577614336
   for key in('originalAll11AcceptanceClaimed','fixReleaseQualificationPassed','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert doc[key]is False
   for key in('newRoutesAdopted','CoreCalls','nativeCalls','originalApiCalls','cliCalls','cadCalls'):assert doc[key]==0
  # Exact equal SDK snapshots are narrower evidence than the failed full postverification.
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  assert e['exitCode']==1 and e['accepted']is False and e['diagnosticStopped']is False and e['stopReasons']==[]and e['cleanupOwnedGroupEmpty']is True
  assert e['policy']==public_contract['policy']and e['policy']=={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['pid']==e['pgid']==517767 and e['currentGuardPid']==517632 and e['signalErrors']==[]and e['signalErrorCount']==0
  assert isinstance(e['oomDelta'],dict)and e['oomDelta']and all(v==0 for v in e['oomDelta'].values())and e['endedAt']>=e['startedAt']and 0<e['wallSeconds']<90
  assert e['peakOwnedRssBytes']==888311808<e['policy']['rssBytes']and e['peakSharedBytes']<e['policy']['sharedBytes']
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',proposal['public49WorkerPin']['path'],proposal['actual64AuthorityPin']['path']]
  assert c.guard.process_scope.owned(517767)==[]and not Path('/proc/517632').exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentlyObservedOwnedGroupMembers']=={'517767':[]}and r['independentProcReadErrors']==[]
  assert r['currentCheckedConnections']==29 and r['currentMissingConnections']==20 and r['partialAdoptionPerformedByThisCollection']is False
  assert len(p['outputFiles'])==45 and p['outputFiles']==proposal['actual64OutputFiles']
  for row in p['outputFiles']:binding(row)
  assert proposal['actual64DiagnosticResultPin']in p['outputFiles']and proposal['actual64RawFinalStatePin']in p['outputFiles']
  checkpoints=[row for row in p['outputFiles']if Path(row['path']).name.startswith('CHECKPOINT-')];assert len(checkpoints)==41 and sum(row['bytes']for row in checkpoints)==3001621<40000000
  v=read(proposal['actual64DiagnosticResultPin']['path']);raw=read(proposal['actual64RawFinalStatePin']['path'])
  assert v['scope']=='ROOT_C31_ACTUAL55_UNSEEDED_FRESH49_PUBLIC_DIAGNOSTIC'and v['originalStepCalls']==raw['publicStepCalls']==raw['iterations']==40000 and v['publicConstructorCalls']==raw['constructorCalls']==1
  assert v['actualGeneratedCarrierCount']==v['actualUniqueGeneratedCarrierCount']==raw['actualPublicTraceCount']==len(raw['traces'])==2 and len(v['missingOriginal49'])==47
  assert v['naturalSdkSolved']is raw['solved']is False and v['naturalSdkFailed']is raw['failed']is True and v['thrown']is raw['thrown']is None
  assert v['phase']==raw['phase']=='failed'and v['error']==raw['error']=='BusLanesSolver ran out of iterations'and v['failureCode']==raw['failureCode']=='search_budget_exhausted'
  assert v['currentC31Full49RoutingQualificationPassed']is False and v['checkpointCount']==41 and v['checkpointBytes']==3001621 and v['checkpointByteLimit']==40000000
  for doc in(v,raw):
   for key in('referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
  # Never call held_inventory_post on this failed64 POST or substitute raw-worker observations for its NULL qualified results.
  prior['actual64C31Public49PostverificationFailedCollectionPin']={k:proposal['actual64CollectionPin'][k]for k in('path','sha256')}
  prior['actual64PostverificationHeldFloorGitFalseAndQualifiedResultsNullPreserved']=True
  prior['actual64EqualSdkSnapshotDictionariesDoNotRepairFailedPostverification']=True
  prior['actual64RawWorkerBudgetFailure40000StepsTwoCarriersNotAcceptedOrPostQualified']=True
  prior['actual64NoEstablishedPostverificationFailureCause']=True
  prior['actual64NextScopeRequiresFreshSourceSdkGitAndDiskFloorHoldings']=True
  prior['actualClosedScopeCount']=64
  return prior

