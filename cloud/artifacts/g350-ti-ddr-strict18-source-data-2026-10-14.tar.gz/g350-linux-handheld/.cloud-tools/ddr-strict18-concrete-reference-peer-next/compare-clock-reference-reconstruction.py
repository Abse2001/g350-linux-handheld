"""Finite clock near/far reference comparison and concrete rectangle corridor screening."""
import ast,json,math,hashlib
from pathlib import Path
HERE=Path(__file__).parent;SRC=HERE/'derive-current18-reference-layout.py';a=ast.parse(SRC.read_text());cut=next(i for i,n in enumerate(a.body) if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='results'for t in n.targets));g={'__file__':str(SRC)};exec(compile(ast.Module(body=a.body[:cut],type_ignores=[]),'pinned-current18-inventory','exec'),g)
items=g['items'];r=g['r'];xy=g['xy'];sha=g['sha'];write=g['write'];require=g['require'];WIDTH=g['WIDTH'];CLEAR=g['CLEAR'];spans=g['spans_for']
imp=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-all4-impedance-research-sourceonly-next/PROPOSED_REFERENCE_IMPEDANCE_CONTRACT.json');require(sha(imp)=='e0b913480f18923406e483d46035c242f046fc147a6405015bdad661a39da464','Exact near/far impedance contract');contract=json.loads(imp.read_bytes())
far=next(x for x in contract['referenceOptions']if x['signal']=='Inner1'and x['reference']=='Inner2');require(far['dielectricFacesMm']==1.265 and far['currentFourMilChosen50OhmScreenFails']is True,'Far core fails existing width screen')
clockresults=[]
for rec in r['records']:
 if rec['sourceTraceId']not in ['source_trace_33','source_trace_34']:continue
 near=[i for i in items if'top'in i['layers']and i['net']!='GND'];farfixed=[i for i in items if'inner2'in i['layers']and i['net']!='DDR_1V5'];farmain=[i for i in farfixed if i['basis']=='CURRENT18_MAIN_SIGNAL']
 clockresults.append({'sourceTraceId':rec['sourceTraceId'],'signalLayer':'inner1','nearTopGndP12Footprint':spans(rec,near,WIDTH/2,CLEAR),'farInner2PowerMainOnlyP12Footprint':spans(rec,farmain,WIDTH/2,CLEAR),'farInner2PowerAllFixedP12Footprint':spans(rec,farfixed,WIDTH/2,CLEAR),'farCoreDielectricFacesMm':1.265,'currentFourMilChosen50OhmScreenFails':True,'farReferenceGenerationAcceptanceAllowed':False,'farElectricalQualified':False})
def pdrect(p,b):
 x0,x1,y0,y1=b;return math.hypot(max(x0-p[0],0,p[0]-x1),max(y0-p[1],0,p[1]-y1))
def psdist(p,a,b):
 dx,dy=b[0]-a[0],b[1]-a[1];den=dx*dx+dy*dy;t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den))if den else 0
 return math.dist(p,(a[0]+t*dx,a[1]+t*dy))
def segmentrect(a,b,rect):
 x0,x1,y0,y1=rect
 if pdrect(a,rect)==0 or pdrect(b,rect)==0 or g['g']['box_intervals'](a,b,rect):return 0
 return min(pdrect(a,rect),pdrect(b,rect),*(psdist(p,a,b)for p in [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]))
def rectangle_screen(rect,layer):
 conflicts=[];minedge=float('inf')
 for item in items:
  if layer not in item['layers']or item['net']=='GND':continue
  if item['kind']=='capsule':edge=segmentrect(item['a'],item['b'],rect)-item['radius']
  else:
   a,b,c,d=rect;x0,x1,y0,y1=item['box'];edge=math.hypot(max(a-x1,x0-b,0),max(c-y1,y0-d,0))
  minedge=min(minedge,edge)
  if edge<CLEAR-1e-12:conflicts.append({'foreignOwnerId':item['id'],'basis':item['basis'],'actualCopperEdgeDistanceToGroundRectangleMm':edge,'foreignReferenceNet':item['net']})
 return conflicts,minedge
candidates=[]
for name,rect in [('WEST_INTER_PACKAGE_WIDE',[-8.1,-2.5,9.8,12.4]),('WEST_INTER_PACKAGE_LOWER',[-8.1,-2.5,9.9,12.2]),('WEST_LEFT_OF_RAM',[-8.1,-5.2,8.8,12.4]),('WEST_INTER_PACKAGE_CENTRAL',[-7.9,-2.8,10.2,12.0])]:
 conflicts,minedge=rectangle_screen(rect,'top');x0,x1,y0,y1=rect;vs=[]
 for v in g['context']['referenceVias']:
  if v['source_net_id']!='source_net_0':continue
  dist=pdrect((v['x'],v['y']),rect)
  if dist<v['outer_diameter']/2:vs.append({'pcbViaId':v['pcb_via_id'],'sourceNetId':'source_net_0','x':v['x'],'y':v['y'],'realFullspanOuterDiameterMm':v['outer_diameter'],'realDrillDiameterMm':v['hole_diameter'],'newHole':False,'rectangleIntersectsOwnedGroundAnnulus':True})
 candidates.append({'name':name,'patchLayer':'top','referenceNet':'GND','groundRectangleBoundsMm':rect,'outline':[{'x':x0,'y':y0},{'x':x1,'y':y0},{'x':x1,'y':y1},{'x':x0,'y':y1}],'groundClearanceMm':CLEAR,'wholeRectangleConservativeForeignCopperClear':len(conflicts)==0,'minimumForeignCopperEdgeDistanceMm':minedge,'conflicts':conflicts,'ownedGroundAnnulusContacts':vs,'possibleInner1MainCenterBoundsForP4HalfReservation':[x0+.4,x1-.4,y0+.4,y1-.4],'clockLaunchesRemainOutsideAndNeedActualTransitionReturns':True,'clockLengthPairCouplingAndPhysicalCompatibilityNotProved':True})
result={'scope':'SOURCEONLY_CLOCK_REFERENCE_RECONSTRUCTION_COMPARISON_NOT_ROUTED_OR_QUALIFIED','strict18Sha256':g['PINS'][str(g['ROUTES'])],'physical0ReportSha256':g['PINS'][str(g['REPORT'])],'impedanceContractPath':str(imp),'impedanceContractSha256':sha(imp),'nearDielectricFacesMm':.0764,'farCoreDielectricFacesMm':1.265,'manufacturerSelectionUnconfirmed':True,'currentWidthMm':WIDTH,'clockAdjacentReferenceComparisons':clockresults,'concreteClockMeanderGroundCorridorCandidates':candidates,'requiredClockFutureRoutingControls':{'actualOriginalCpuRamNumericPadsAndOwnedSignalLaunchBarrelsHeld':True,'allOriginal225And96MapIdsHeld':True,'existingReportedPrimitivePlanarWindowMm':[20.95,23.49],'differentialSkewLimitMm':.127,'differentialTraceGapMm':.12,'noAutomaticCorePairSrjEquivalenceClaim':True},'farCoreImpedancePassClaim':False,'newStitchesProposed':0,'newHolesAdopted':0,'referenceQualified':False,'electricalTimingQualified':False,'accepted49':False,'fabricationReady':False,'actualAppImports':0,'nativeCalls':0,'cadCalls':0,'notes':['Only actual current Source and finite planar geometry are compared. Empty Root field/model authority remains a hard refusal.','Near-face Topreference remains preferred only if a reconstructed route/filledGNDpatch actually clears the fixedSource launch pads/stubs and all signals.','Whole-rectangle candidate screens inspect every fixedland,129reference+96signalbarrels,261fixedtraces,current18 actualsignals; Ground ownedcopper is allowed because it carries the intendedreference net.','Aclear Toprect requires actualSourcepour fill/component binding and real launches; no route passeslength,physical,coupling,returns merelybyfittinginsideit.','FarInner2Power reference across1.265mm core is geometricallyscreened only. Immutablecontract flags current4mil chosen50Ohm screenfailed, so it cannot beaccepted byexistinggenerator.','ActualEM, finishedstack, manufacturer/material models, package/viaRLC/PVT/RF returns and full49 remainopen.']}
write(HERE/'CLOCK_REFERENCE_RECONSTRUCTION_COMPARISON.json',result)
print(json.dumps({'sha256':sha(HERE/'CLOCK_REFERENCE_RECONSTRUCTION_COMPARISON.json'),'clock':[{ 'id':x['sourceTraceId'],'nearTopMm':x['nearTopGndP12Footprint']['blockedLengthMm'],'farMainMm':x['farInner2PowerMainOnlyP12Footprint']['blockedLengthMm'],'farFullMm':x['farInner2PowerAllFixedP12Footprint']['blockedLengthMm']}for x in clockresults],'corridors':[{'name':x['name'],'clear':x['wholeRectangleConservativeForeignCopperClear'],'minimumDistance':x['minimumForeignCopperEdgeDistanceMm'],'conflicts':len(x['conflicts']),'groundVias':[y['pcbViaId']for y in x['ownedGroundAnnulusContacts']]}for x in candidates]}))
