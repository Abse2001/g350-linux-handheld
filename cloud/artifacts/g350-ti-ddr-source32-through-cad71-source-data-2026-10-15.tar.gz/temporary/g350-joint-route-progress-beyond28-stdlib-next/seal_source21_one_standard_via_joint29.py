"""Own source-only scalar sealing; no SDK/helper imports or evaluations."""
import sys,pathlib,json,copy,math,hashlib,stat
sys.path.insert(0,'/tmp/g350-after27-remaining-ddr-scalar-planner-next');import joint27_plan as p
q=p.q;g=p.g;ROOT=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT));import probe_ca6_inner2_detours as own
JPATH=pathlib.Path('/tmp/g350-source29-joint7-ca6-ca18-reset-spacing-and-self-repair-sourceonly-next/JOINT_SOURCE29_GEOMETRY_PROPOSAL.json');assert g.sha(JPATH)=='2bd2ae7e5e92375dfeb3734165e63cc655e6487a62881d2dfda10c17a6ea427e';j=json.loads(JPATH.read_bytes());q.PRIMS=[o for o in q.PRIMS if not o['id'].startswith('planned26_reset_bottom:')];q.segment(j['explicitExistingResetSource26To29Repair']['afterBottomCarrierPoints'],'bottom','source_trace_10','planned29_reset')
for n in j['newTwoCarrierRoutes']:q.segment(n['newInner2CarrierPoints'],'inner2',n['originalSourceTraceId'],'planned29_'+n['originalSourceTraceId'])
PROPDIR=pathlib.Path('/tmp/g350-source29-authentic52-parent-qualified-activation-sourceonly-next');parent=json.loads((PROPDIR/'source29-proposal.json').read_text());actualpins=parent['parent26QualificationBindings'];raw=json.loads(pathlib.Path(actualpins['rawCore']['path']).read_bytes());controls=json.loads(pathlib.Path(actualpins['coreControls']['path']).read_bytes());model=json.loads(pathlib.Path(actualpins['fresh49Model']['path']).read_bytes());assert g.sha(actualpins['rawCore']['path'])==actualpins['rawCore']['sha256'] and g.sha(actualpins['fresh49Model']['path'])==actualpins['fresh49Model']['sha256']
NAME='source_trace_21';samples=json.loads((ROOT/'SOURCE21_STANDARD_VIA_EXACT_21_8_21_9_VERTICAL_TOP_U_PROBES_JOINT29.json').read_text());case=next(r for r in samples['results'] if r['target']==21.8 and r['U']==9.6 and r['V']==8.4);top=[tuple(v) for v in case['path']];via=(-8.5,14.4);cpu=p.BRANCHES[NAME,0];ram=p.BRANCHES[NAME,1];cp=[g.xy(x)for x in cpu['topStub']];rp=[g.xy(x)for x in reversed(ram['topStub'])];i2=[g.xy(cpu['viaXY']),via];fulltop=top+rp[1:];pieces=[dict(role='held_cpu_numeric_to_barrel_stub',layer='top',points=cp),dict(role='new_cpu_to_intermediate_carrier',layer='inner2',points=i2),dict(role='new_intermediate_to_ram_carrier',layer='top',points=top),dict(role='held_ram_barrel_to_numeric_stub',layer='top',points=rp)]
whole=sum(g.plen(x['points'])for x in pieces);assert abs(whole-21.8)<1e-12 and NAME not in g.PAIRS
foreign=[o for o in q.PRIMS if NAME not in o['owners']];traceRows=[]
for part in pieces:
 for o in foreign:
  if part['layer'] not in o['layers']:continue
  dist=min(q.distance(a,b,o)for a,b in zip(part['points'],part['points'][1:]));need=q.required(o,NAME);traceRows.append(dict(role=part['role'],layer=part['layer'],primitive=o['id'],minimumCenterDistanceMm=dist,requiredHardAndClassCenterMm=need,hardSurplusMm=dist-o['rad']-g.MARGIN,hardAndClassSurplusMm=dist-need))
assert min(r['hardAndClassSurplusMm']for r in traceRows)>-1e-10
viaRows=[]
for o in q.PRIMS:
 if NAME in o['owners'] and o['kind']=='segment':continue
 need=o['rad']+.2286+g.GAP
 if o['kind']=='segment'and any(q.CLASSES.get(x)for x in o['owners']):need=max(need,g.WIDTH*(3 if any(q.CLASSES.get(x)==q.CLASSES[NAME]for x in o['owners'])else 4))
 d=q.distance(via,via,o);viaRows.append(dict(primitive=o['id'],kind=o['kind'],layers=list(o['layers']),centerDistanceMm=d,foreignSurfaceDistanceMm=d-o['rad'],requiredCenterMm=need,annulusSurfaceClearanceMm=d-o['rad']-.2286,hardAndClassSurplusMm=d-need))
assert min(r['hardAndClassSurplusMm']for r in viaRows)>-1e-10
selfResult=own.selfcheck(fulltop);assert selfResult[0];cpuSelf=min(g.segdist(a,b,c,d)for a,b in zip(cp,cp[1:])for c,d in zip(fulltop,fulltop[1:]));assert cpuSelf>=3*g.WIDTH-1e-9
# Explicit hole/drill, keepout and board checks use genuine actual26 geometry.
drillRows=[]
for v in (r for r in raw if r['type']=='pcb_via'):
 d=math.dist(via,(v['x'],v['y']));surface=d-.127-v['hole_diameter']/2;drillRows.append(dict(kind='pcb_via',originActualId=v['pcb_via_id'],centerDistanceMm=d,drillEdgeClearanceMm=surface,requiredMm=model['minViaHoleEdgeToViaHoleEdgeClearance'],surplusMm=surface-model['minViaHoleEdgeToViaHoleEdgeClearance']))
assert len(drillRows)==227 and min(r['surplusMm']for r in drillRows)>0
for h in(r for r in raw if r['type']=='pcb_plated_hole'):
 # Enclosing circle is deliberately conservative for pill drills, on all layers.
 radius=max(h['hole_width'],h['hole_height'])/2;distance=math.dist(via,(h['x'],h['y']));need=model['minPlatedHoleDrillEdgeToDrillEdgeClearance'];drillRows.append(dict(kind='pcb_plated_hole_conservative_enclosing_drill_circle',originActualId=h['pcb_plated_hole_id'],drillEdgeClearanceMm=distance-.127-radius,requiredMm=need,surplusMm=distance-.127-radius-need))
npthRows=[]
for h in(r for r in raw if r['type']=='pcb_hole'):
 center=(h['x'],h['y']);radius=h['hole_diameter']/2
 for part in pieces:
  d=min(g.point_segment(center,a,b)for a,b in zip(part['points'],part['points'][1:]));sur=d-g.WIDTH/2-radius-model['minTraceToHoleEdgeClearance'];npthRows.append(dict(object='trace',role=part['role'],hole=h['pcb_hole_id'],surplusMm=sur))
 npthRows.append(dict(object='newViaAnnulus',hole=h['pcb_hole_id'],surplusMm=math.dist(via,center)-.2286-radius-model['minTraceToHoleEdgeClearance']))
assert min(r['surplusMm']for r in drillRows+npthRows)>0
keepoutRows=[]
for ko in(r for r in raw if r['type']=='pcb_keepout'):
 rect=(ko['center']['x'],ko['center']['y'],ko['width']/2,ko['height']/2,1.,0.)
 for part in pieces:
  if part['layer']in ko['layers']:keepoutRows.append(dict(role=part['role'],keepout=ko['pcb_keepout_id'],surplusMm=min(g.rectdist(a,b,rect)for a,b in zip(part['points'],part['points'][1:]))-g.WIDTH/2-g.GAP))
 keepoutRows.append(dict(role='newFullSpanViaAnnulus',keepout=ko['pcb_keepout_id'],surplusMm=g.rectdist(via,via,rect)-.2286-g.GAP))
assert min(r['surplusMm']for r in keepoutRows)>0
board=next(r for r in raw if r['type']=='pcb_board');outline=[g.xy(v)for v in board['outline']];edges=list(zip(outline,outline[1:]+outline[:1]));allpoints=[v for piece in pieces for v in piece['points']]
def inside(pt):
 x,y=pt;odd=False
 for a,b in edges:
  if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:odd=not odd
 return odd
assert all(inside(x)for x in allpoints)
edgeTrace=min(g.segdist(a,b,c,d)-g.WIDTH/2-model['minBoardEdgeClearance']for part in pieces for a,b in zip(part['points'],part['points'][1:])for c,d in edges);edgeVia=min(g.point_segment(via,a,b)-.2286-model['minBoardEdgeClearance']for a,b in edges);assert min(edgeTrace,edgeVia)>0
bus=next(b for b in model['buses']if NAME in b['connectionNames']);lengths={c['originalSourceTraceId']:c['expectedWholePlanarMm']for c in parent['selected29OriginalCarriers']if c['originalSourceTraceId']in bus['connectionNames']};lengths[NAME]=whole;span=max(lengths.values())-min(lengths.values());assert bus['minLength']<=whole<=bus['maxLength'] and span<=bus['maxLengthSkew']
# Preserve parent physical via roster; prospective new IDs remain explicitly absent.
actualOwnership={s:[r for r in controls['viaProjection']if r['sourceViaName']==s][0]for s in(cpu['viaName'],ram['viaName'])};assert all(r['passed']for r in actualOwnership.values())
D=pathlib.Path('/tmp/g350-source21-one-standard-through-via-joint29-geometry-sourceonly-next');D.mkdir(mode=0o700,exist_ok=False)
def pin(path):
 path=pathlib.Path(path);b=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),mode=stat.S_IMODE(path.stat().st_mode))
def save(name,obj):
 path=D/name;path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n');path.chmod(0o600);return pin(path)
proposal=dict(scope='UNACCEPTED_SOURCE21_SINGLE_STANDARD_FULLSPAN_INTERMEDIATE_VIA_OVER_EXPLICIT_JOINT29',originalSourceTraceId=NAME,originalLogicalDeclaration=next(r for r in parent['all49OriginalLogicalTraces']if r['originalSourceTraceId']==NAME),original49ConnectionAndBusHeld=dict(connection=next(c for c in model['connections']if c['name']==NAME),bus=bus),widthMm=g.WIDTH,allowedLayersHeld=bus['allowedLayers'],newStandardThroughVia=dict(proposedSourceLiteralName='V_TI_SIGNAL_INTERMEDIATE_source_trace_21_0',ownerOriginalSourceTraceId=NAME,xy=dict(x=via[0],y=via[1]),fromLayer='top',toLayer='bottom',layers=g.LAYERS,outerDiameterMm=.4572,drillDiameterMm=.254,futureFreshCoreIds=None),all227ExistingBarrelsPreserved=True,all98ExistingNumericBranchesPreserved=True,all29PriorCarriersAndExplicitResetRepairPreserved=True,source38OptionalUnapplied=True,existingEndpointBranches=dict(cpu=cpu,ram=ram),actual26EndpointOwnershipProvenanceOnly=actualOwnership,pieces=pieces,wholePlanarMm=whole,newIntermediateVias=1,newPhysicalCarrierPieces=2,requiredGenuineAdditionalInnerPorts=[dict(viaName=cpu['viaName'],layer='inner2',viaXY=cpu['viaXY'],numericSelector=cpu['numericSelector']),dict(viaName='V_TI_SIGNAL_INTERMEDIATE_source_trace_21_0',layer='inner2',viaXY=dict(x=via[0],y=via[1]),originalSourceTraceId=NAME)],prospectiveCountsOnly=dict(originalRoutedCarriers=30,missingOriginal49=19,physicalVias=228,referenceVias=129,originalSignalDogbones=98,intermediateSignalVias=1,physicalTraces=294,innerLiteralPorts=48,sourcePorts=1665,pcbComponentsIncludingViaAliases=508,ReactElements=2281,realParts=280),parentJoint29GeometryPin=pin(JPATH),actual26CorePin=actualpins['rawCore'],actual26Fresh49ModelPin=actualpins['fresh49Model'],sourceCompositionAuthored=False,futureFreshCoreIds=None,actualSourceStages=None,accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingPassed=False,fabricationReady=False)
pp=save('SOURCE21_ONE_STANDARD_VIA_GEOMETRY_PROPOSAL.json',proposal)
summary=dict(wholePlanarMm=whole,loadedCaPlanarLengthsMm=lengths,loadedCaSpanMm=span,requiredCaSpanMaximumMm=bus['maxLengthSkew'],minimumHardAndClassTraceSurplusMm=min(r['hardAndClassSurplusMm']for r in traceRows),minimumNewViaHardAndClassSurplusMm=min(r['hardAndClassSurplusMm']for r in viaRows),minimumNewViaDrillWebSurplusMm=min(r['surplusMm']for r in drillRows),minimumNpthSurplusMm=min(r['surplusMm']for r in npthRows),minimumKeepoutSurplusMm=min(r['surplusMm']for r in keepoutRows),traceBoardEdgeSurplusMm=edgeTrace,newViaBoardEdgeSurplusMm=edgeVia,topBridgeAndRamStubNonlocalSelfCenterMm=selfResult[1],cpuStubVersusTopBridgeCenterMm=cpuSelf,ordinaryJoinedBendRule='Only total turn <=90 degrees and intervening contour <=pi*(width+hardGap) are local, with all intersections rejected; every other nonadjacent same-layer pair >=3W.',allTraceAnglesAtMost45Degrees=True,all227ViaDrillsReplayed=True,newFullSpanViaNotInAnyPad=True,noOriginalRequestOrTimingRuleModified=True)
proofpin=save('SOURCE21_ONE_STANDARD_VIA_FULL_JOINT_SCALAR_PROOF.json',dict(scope='OWN_STDLIB_SCALAR_PROOF_NOT_NATIVE_API_OR_ELECTRICAL_QUALIFICATION',proposalPin=pp,summary=summary,traceClearanceRows=traceRows,newViaAllLayerAnnulusRows=viaRows,newViaDrillWebRows=drillRows,npthRows=npthRows,keepoutRows=keepoutRows,original227BarrelsPin=actualpins['rawCore'],actual26GeometryBasisEquivalencePin=pin('/tmp/g350-source29-joint7-ca6-ca18-reset-spacing-and-self-repair-sourceonly-next/JOINT_SOURCE29_FULL_SCALAR_PROOF.json'),allPriorGeometryPreservedByConstruction=True,pourAndPlaneQualification='Actual10 source pours are retained metadata; no refill/plane-reference qualification is claimed.',electricalLimit='Mixed Top/Inner2 carrier and one additional through-via need actual stackup/flight-time/via-stub analysis; planar CA length pass does not establish electrical timing.',sourceAccepted=False,all49Accepted=False,fabricationReady=False))
manifest=dict(scope='SOURCE_ONLY_SOURCE21_ONE_STANDARD_THROUGH_VIA_JOINT29_SCALAR_GEOMETRY',status='UNACCEPTED_AWAITING_INDEPENDENT_NUMERICAL_PEER_AND_FRESH_GENUINE_SOURCE_QUALIFICATION',files=[pp,proofpin],externalFiles=[pin(__file__),pin('/tmp/g350-source29-joint7-ca6-ca18-reset-spacing-and-self-repair-sourceonly-next/SOURCE-manifest.json'),pin('/tmp/g350-source29-joint-independent-numerical-peer.json'),actualpins['rawCore'],actualpins['coreControls'],actualpins['fresh49Model'],actualpins['fresh49ProjectionProof'],pin(PROPDIR/'source29-proposal.json'),pin(ROOT/'SOURCE21_STANDARD_VIA_EXACT_21_8_21_9_VERTICAL_TOP_U_PROBES_JOINT29.json'),pin('/tmp/g350-after27-remaining-ddr-scalar-planner-next/joint27_plan.py'),pin('/tmp/g350-after26-remaining-ddr-scalar-planner-next/joint26_plan.py'),pin('/tmp/g350-source24-remaining-nonpair-peer-planner-next/scalar_plan.py')],summary=summary,newStandardViaCount=1,all227ExistingViasHeld=True,all49OriginalConstraintsHeld=True,source38Unapplied=True,sourceOrPipelineAuthored=False,SDKOrAppsOrHelpersOrProcessesEvaluated=False,workspaceWrites=False,Source21Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingPassed=False,fabricationReady=False)
mp=save('SOURCE-manifest.json',manifest);print(json.dumps(dict(manifest=mp,proposal=pp,proof=proofpin,summary=summary),indent=2))
