// SOURCE ONLY. Complete actual13 manual topology, no A* search:
// exact215 + one13CPU NE dogbone + one retained12 body local outer-right
// reshape. Fresh before/after12, all46, authentic head/portal, full13 and
// finalall47 independent physical/native checks remain mandatory.
// Standard fullspan vias and every literal original rule retained.
import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {pathToFileURL} from 'node:url'
type R=Record<string,any>
const ROOT='/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib/'
const RAW='/tmp/g350-manual-d5-two-refills-root-20261016-run215/byte0-result.candidate.json',PIN='150b45fa398153a8e3fd1f6f8c52ed51d4dff981e538800b221e0a0e72a5da3d'
const CTOR='/tmp/g350-manual215-root-profile221/constructor.json',CTOR_PIN='49bd4dc1079ae7fd7a2766f4b9fb0f736e35f4d8ac792c973fd06dd671a721dc'
const RAW_CORE='/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json',RAW_CORE_PIN='d2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607'
const QUALIFIER='/tmp/g350-mixed-carrier-physical-four-vias-sourceonly.ts'
const QUALIFIER_PIN='cdea6326a318b332ba98bb74bb1c8fd52c3b757bde34d75402558bd6dc86623f'
const ENDPOINTS='/tmp/g350-native-top-or-barrel-endpoints-ripup-sourceonly.ts',ENDPOINTS_PIN='f737af519a0dbc4bde8edeced01fc5526284b16affa6949e973eb609c9fe8a45'
const SPARSE='/tmp/g350-bounded-sparse-state-store-sourceonly.ts',SPARSE_PIN='6eca0efdc6c97f459e6f4dffd8da8a6826d5fa3f760fcd6a40239eeb5f78db7f'
const L=['top','inner1','inner2','bottom'],STEP=.01016,VD=.4572,HD=.254,W=.1016
const req=(v:any,m:string)=>{if(!v)throw Error(m)},clone=<T>(x:T):T=>structuredClone(x),same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b),near=(a:R,b:R)=>Math.hypot(a.x-b.x,a.y-b.y)<1e-8
const owner=(t:R)=>t.connection_name??t.source_trace_id,sha=(b:any)=>createHash('sha256').update(b).digest('hex')
const planar=(t:R)=>t.route.slice(1).reduce((s:number,b:R,i:number)=>{const a=t.route[i];return s+(a.route_type==='wire'&&b.route_type==='wire'&&a.layer===b.layer?Math.hypot(b.x-a.x,b.y-a.y):0)},0)
const args=new Map<string,string>();for(let i=2;i<process.argv.length;i+=2){const k=process.argv[i],v=process.argv[i+1];req(['--input','--input-sha','--constructor','--output','--budget-ms','--case-ms','--max-expansions','--max-vias','--max-labels','--constructor-sha'].includes(k)&&v&&!args.has(k),'Invalid CLI '+k);args.set(k,v)}
const profilePin=args.get('--constructor-sha')??CTOR_PIN
const inputPath=path.resolve(args.get('--input')??RAW),inputPin=args.get('--input-sha')??PIN,ctorPath=path.resolve(args.get('--constructor')??CTOR),out=path.resolve(args.get('--output')??''),budget=Number(args.get('--budget-ms')??165000),perCase=Number(args.get('--case-ms')??6000),maxExpanded=Number(args.get('--max-expansions')??2000000),maxVias=Number(args.get('--max-vias')??4),maxLabels=Number(args.get('--max-labels')??4000000)
req(['--input','--input-sha','--constructor','--constructor-sha'].every(k=>args.has(k)),'Explicit current input and reviewed constructor paths/hashes required')
req(args.has('--output')&&!fs.existsSync(out)&&![inputPath,ctorPath,RAW_CORE,QUALIFIER,ENDPOINTS].includes(out),'Separate fresh output required')
req(budget>=1000&&budget<=170000&&perCase>=100&&perCase<=20000&&Number.isInteger(maxExpanded)&&maxExpanded>=1000&&maxExpanded<=2000000,'Finite time/state budgets required')
req([3,4].includes(maxVias)&&Number.isInteger(maxLabels)&&maxLabels>=1000&&maxLabels<=8000000,'Finite 3/4-via and sparse-label budgets required')
const read=(p:string,pin:string)=>{const b=fs.readFileSync(p);req(sha(b)===pin,'Pinned public input changed '+p);return JSON.parse(b.toString())}
req(/^[0-9a-f]{64}$/.test(profilePin),'Exact reviewed constructor SHA required')
req(/^[0-9a-f]{64}$/.test(inputPin),'Exact public current scene hash required')
const bun=(globalThis as any).Bun;req(typeof bun?.gc==='function','Bun full GC required between completed search cases')
const packet=read(inputPath,inputPin),constructor=read(ctorPath,profilePin),rawCore:R[]=read(RAW_CORE,RAW_CORE_PIN)
req(sha(fs.readFileSync(QUALIFIER))===QUALIFIER_PIN,'Reviewed independent mixed qualifier source required')
req(sha(fs.readFileSync(ENDPOINTS))===ENDPOINTS_PIN,'Reviewed genuine numeric Top endpoint-menu source required')
req(sha(fs.readFileSync(SPARSE))===SPARSE_PIN,'Reviewed bounded sparse state-store source required')
req(inputPin===PIN&&profilePin===CTOR_PIN,'Exact actual215 plus reviewed221 constructor required');const base:R=clone(packet.full49FanoutInput),held:R[]=clone(packet.heldCarrierTraces),parentCaptured:R[]=clone(packet.ordinaryCarrierTraces),captured:R[]=clone(parentCaptured),rules:R[]=clone(constructor.input.buses)
const critical=new Set(held.map(owner)),ordinary=base.connections.filter((c:R)=>!critical.has(c.name)),missing=ordinary.filter((c:R)=>!captured.some(t=>owner(t)===c.name)).map((c:R)=>c.name)
req(base.connections.length===49&&base.traces.length===263&&base.obstacles.length===1298&&held.length===6&&captured.length>=33&&captured.length<=43&&missing.length===43-captured.length,'Current coherent partial49 inventory')
req(new Set([...held,...captured].map(owner)).size===held.length+captured.length&&captured.every(t=>ordinary.some((c:R)=>c.name===owner(t))),'Unique current ordinary and critical owners')
req(base.layerCount===4&&same(base.allowedLayers,L)&&base.minTraceWidth===W&&base.minTraceToPadEdgeClearance===W&&base.minViaDiameter===VD&&base.minViaHoleDiameter===HD&&base.allowBlindAndBuriedVias===false,'Original physical stack and dimensions')
req(same(base,constructor.full49FanoutInput)&&same(held,constructor.heldCarrierTraces),'Actual current full foundation and six critical carriers must equal the explicit reviewed constructor profile')
req(constructor.profile?.sourcePacketSha256===inputPin&&same(base.buses,constructor.originalRules?.buses)&&same(base.differentialPairs,constructor.originalRules?.differentialPairs),'Reviewed constructor must bind this exact input SHA and preserve literal original rules')
req(base.differentialPairs.length===3&&base.differentialPairs.every((p:R)=>p.lengthTolerance===.127&&p.traceGap===.12)&&base.buses.find((b:R)=>b.busId==='DDR_BYTE0').maxLength===11.8&&base.buses.find((b:R)=>b.busId==='DDR_BYTE1').maxLength===14.2&&base.buses.find((b:R)=>b.busId==='DDR_COMMAND_CLOCK').minLength===20.95&&base.buses.find((b:R)=>b.busId==='DDR_COMMAND_CLOCK').maxLength===22.29,'All original limits retained')
const frozen=JSON.stringify({base,held,parentCaptured}),started=performance.now(),stem=out.endsWith('.json')?out.slice(0,-5):out,retained:R[]=[],rawCandidates:R[]=[]
let working=clone(base)
const releasedWorkingBranchMaterial:R[]=clone(packet.releasedWorkingBranchMaterial??[])
const report:R={scope:'ACTUAL215_MANUAL13_NE_CPU_ONE_FULLSPAN_PORTAL_DECLARED12_RIGHT_BODY_ALL46_HELD',inputPath,inputSha256:inputPin,constructorPath:ctorPath,constructorSha256:profilePin,qualifierSourceSha256:sha(fs.readFileSync(QUALIFIER)),endpointMenuSourceSha256:ENDPOINTS_PIN,sparseStoreSourceSha256:SPARSE_PIN,gridStepMm:STEP,maximumCellsPerLayer:2000000,maximumNewThroughViasPerOwner:maxVias,maxExpanded,maxLabels,attempts:[],retained:[],rawCandidatesPath:stem+'.raw-candidates.json',physicalRunReports:clone(packet.physicalRunReports??[]),newViaReports:clone(packet.newViaReports??[]),all49Connected:false,all49Accepted:false,wholeMixedC31Supported:false,matched:false,timingPassed:false,electricalTimingQualified:false,nativeExecuted:false,cadExecuted:false,fabricationReady:false}
fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,'',{flag:'wx'})
const save=()=>{report.elapsedMs=performance.now()-started;fs.writeFileSync(out+'.tmp',JSON.stringify(report,null,2)+'\n');fs.renameSync(out+'.tmp',out)}
save()
try{
 const imp=(n:string)=>import(pathToFileURL(ROOT+n+'.ts').href)
 const {GridVisibilitySearch}=await imp('grid-visibility'),{GridHeap}=await imp('grid-heap'),{VectorScene,fixedCopper,clearanceToCopper}=await imp('vector-scene')
 const {reduceOrdinaryTurns}=await imp('reduce-ordinary-turns'),{chamferOrdinaryCorners}=await imp('chamfer-ordinary-corners'),{nativeSignalGeometryIsValid}=await imp('native-signal-geometry'),{tuningPathIsSelfClear}=await imp('length-tuning')
 const {pointSegmentDistanceToPoints,segmentDistance,length}=await imp('geometry'),{boardOutlineViolations}=await imp('board-outline'),{BusLanesSolver}=await imp('bus-lanes-solver')
 const {retargetGeneratedEscape}=await imp('retarget-generated-escape'),{joinSignalEscapes}=await imp('join-signal-escapes'),lengths=await imp('route-lengths')
 const {qualifyMixedCarrier}=await import(pathToFileURL(QUALIFIER).href)
 const {createEndpointMenus,applyEndpointSelection}=await import(pathToFileURL(ENDPOINTS).href)
 const {BoundedSparseStateStore}=await import(pathToFileURL(SPARSE).href)
 const helpers={VectorScene,fixedCopper,clearanceToCopper,pointSegmentDistanceToPoints,segmentDistance,nativeSignalGeometryIsValid,tuningPathIsSelfClear,boardOutlineViolations,BusLanesSolver}
 const maximumWhole=(n:string)=>{const a=rules.filter(b=>b.connectionNames.includes(n)&&b.maxLength!==undefined);req(a.length===1,'One real bounded bus per missing owner '+n);return a[0].maxLength}
 const minimumWhole=(n:string)=>{const a=rules.filter(b=>b.connectionNames.includes(n)&&b.maxLength!==undefined);req(a.length===1,'One real bounded bus per bounded missing owner '+n);return a[0].minLength??0}
 const activeEscapes=(t:R,foundation:R=working)=>foundation.traces.filter((q:R)=>owner(q)===owner(t)).map((q:R)=>{const end=q.route.at(-1),layer=near(end,t.route[0])?t.route[0].layer:near(end,t.route.at(-1))?t.route.at(-1).layer:undefined;req(layer,'Owned branch must end at one exact carrier handoff');return retargetGeneratedEscape(clone(q),layer)})
 const joined=(t:R,foundation:R=working)=>{const escapes=activeEscapes(t,foundation),j=joinSignalEscapes(t,escapes),ends=[j.route[0],j.route.at(-1)];req(escapes.length===2&&ends.every((p:R)=>p.route_type==='wire'&&p.layer==='top'&&foundation.obstacles.some((o:R)=>o.circuitJsonMetadata?.pcb_port_id&&o.connectedTo.includes(owner(t))&&near(o.center,p))),'Actual numeric Top pads at both joined ends required');return j}
 const material=(t:R)=>t.route.slice(1).flatMap((b:R,i:number)=>{const a=t.route[i];return a.route_type==='wire'&&b.route_type==='wire'&&!near(a,b)?[{a:{x:a.x,y:a.y,layer:a.layer,width:a.width},b:{x:b.x,y:b.y,layer:b.layer,width:b.width}}]:[]})
 // Clean146 intentionally omitted141's inverse ledger. Recover only the six
 // already-authorized Top working-barrel deletions from pinned138 originals.
 if(!releasedWorkingBranchMaterial.length)for(const old of constructor.full49FanoutInput.traces){const current=working.traces.find((t:R)=>t.pcb_trace_id===old.pcb_trace_id);if(old.route.some((p:R)=>p.route_type==='via')&&current&&!current.route.some((p:R)=>p.route_type==='via')){req([8,21,41].some(i=>owner(old)==='source_trace_'+i)&&same(material(old),material(current)),'Inherited Top removal must preserve exact authorized owner/stub material');releasedWorkingBranchMaterial.push({owner:owner(old),reason:'INHERITED_ACTUAL141_TOP_WORKING_BARREL_REMOVAL_IN_CLEAN146',originalBranch:clone(old),replacementBranch:clone(current)})}}
 const extraHoles=(input:R)=>{
  const holes:R[]=[]
  for(const t of input.traces)for(const p of t.route)if(p.route_type==='via')holes.push({x:p.x,y:p.y,diameter:p.via_hole_diameter??HD,plated:true,owner:owner(t),physicalId:t.pcb_trace_id})
  for(const o of input.obstacles){const m=o.circuitJsonMetadata??{},id=m.pcb_via_id??m.pcb_hole_id??m.pcb_plated_hole_id;if(!id)continue;const r=rawCore.find((q:R)=>q.pcb_via_id===id||q.pcb_hole_id===id||q.pcb_plated_hole_id===id);req(r&&near(r,o.center),'Actual fixed hole record '+id);holes.push({x:o.center.x,y:o.center.y,diameter:r.hole_diameter??Math.hypot(r.hole_width,r.hole_height),plated:r.type!=='pcb_hole',physicalId:id,conservativeCircumscribedSlot:r.hole_shape!=='circle'&&r.shape==='pill'})}
  return holes
 }
 const nativeViaLandReport=(carrier:R,input:R)=>{
  const sites:R[]=[]
  for(const t of input.traces)if(owner(t)!==owner(carrier))for(const v of t.route)if(v.route_type==='via')sites.push({x:v.x,y:v.y,diameter:v.via_diameter,owner:owner(t),physicalId:t.pcb_trace_id})
  for(const o of input.obstacles)if(o.circuitJsonMetadata?.pcb_via_id&&!o.connectedTo?.includes(owner(carrier)))sites.push({x:o.center.x,y:o.center.y,diameter:Math.max(o.width,o.height),owner:o.connectedTo?.join(','),physicalId:o.circuitJsonMetadata.pcb_via_id})
  const reports=carrier.route.filter((v:R)=>v.route_type==='via').map((v:R)=>({via:{x:v.x,y:v.y,diameter:v.via_diameter},minimumGapMm:.15,violations:sites.flatMap(s=>{req(Number.isFinite(s.diameter)&&s.diameter>0,'Actual foreign via land diameter');const d=Math.hypot(v.x-s.x,v.y-s.y),required=v.via_diameter/2+s.diameter/2+.15;return d<required-1e-8?[{...s,actualCenterDistanceMm:d,requiredCenterDistanceMm:required,gapMm:d-v.via_diameter/2-s.diameter/2}]:[]})}))
  return {scope:'ACTUAL_NEW_CARRIER_VIAS_NATIVE_POINT15_LAND_GAP_SUPPLEMENT',passed:reports.every((r:R)=>r.violations.length===0),reports,allBoardNativeChecksExecuted:false}
 }
 // Native via-to-SMT/plated-pad edge clearance follows the explicit .1016
 // board rule. The separate native via-to-VIA land minimum remains .15.
 const nativePadClearanceScenes=(input:R)=>{
  const padOnly={...input,traces:[],obstacles:input.obstacles.filter((o:R)=>o.circuitJsonMetadata?.pcb_smtpad_id||o.circuitJsonMetadata?.pcb_plated_hole_id),minTraceToPadEdgeClearance:input.minViaEdgeToPadEdgeClearance??input.minTraceToPadEdgeClearance??.1016}
  return L.map(layer=>new VectorScene(padOnly,{name:'__NEW_FULLSPAN_VIA_PAD_CLEARANCE__',pointsToConnect:[{x:0,y:0,layer},{x:0,y:0,layer}]},VD,fixedCopper(padOnly)))
 }
 const allActualForeignViaSites=(input:R,name:string)=>[
  ...input.traces.filter((t:R)=>owner(t)!==name).flatMap((t:R)=>t.route.filter((v:R)=>v.route_type==='via').map((v:R)=>({x:v.x,y:v.y,diameter:v.via_diameter}))),
  ...input.obstacles.filter((o:R)=>o.circuitJsonMetadata?.pcb_via_id&&!o.connectedTo?.includes(name)).map((o:R)=>({x:o.center.x,y:o.center.y,diameter:Math.max(o.width,o.height)}))
 ]
 // Exactly one missing CPU branch/request changes. D5/D7, native repaired
 // ordinary bodies, manual north40/flat11, all references and critical169
 // remain bytewise literal to the reviewed actual215 constructor.
 const moves=[{name:'source_trace_13',side:0,pad:{x:-.4,y:14},beforeVia:{x:0,y:13.6},afterVia:{x:0,y:14.4}}],atomicInverses:R[]=[]
 req(missing.length===3&&same([...missing].sort(),['source_trace_13','source_trace_26','source_trace_30'])&&captured.length===40&&[32,43,46].every(i=>captured.some(t=>owner(t)==='source_trace_'+i)),'Exact actual215 46-path profile with D5/D7/A6 held and only13/26/30 missing')
 const manual11Inverse=clone(packet.manual11Inverse??null),manual40Inverse=clone(packet.manual40Inverse??null)

 const i12=captured.findIndex(t=>owner(t)==='source_trace_12'),before12=clone(captured[i12]),expected12=[[.8,14.4],[1.1828,14.7828],[5.8056,14.7828],[6.0088,14.5796],[6.0088,10.1912],[6.8,9.4]],new12Points=[[.8,14.4],[1.1828,14.7828],[6.8,14.7828],[7.2,14.3828],[7.2,9.8],[6.8,9.4]]
 req(i12>=0&&before12.route.length===6&&!before12.curvedSegments&&!before12.coupledSection&&before12.route.every((p:R,i:number)=>p.route_type==='wire'&&p.layer==='inner1'&&p.width===W&&near(p,{x:expected12[i][0],y:expected12[i][1]})),'Exact current12 ordinary carrier required before declared reshape')
 const after12={...clone(before12),route:new12Points.map(([x,y])=>({route_type:'wire',x,y,layer:'inner1',width:W}))};after12.trace_length=planar(after12);captured[i12]=after12
 const expectedCaptured=clone(parentCaptured);expectedCaptured[i12]=clone(after12);req(same(captured,expectedCaptured)&&parentCaptured.every(t=>owner(t)==='source_trace_12'||same(t,captured.find(q=>owner(q)===owner(t)))),'Only declared12 local body may change; allother45 carriers literal')
 const manual12Inverse={owner:'source_trace_12',reason:'DECLARED_OUTER_RIGHT_INNER1_CHANNEL_TO_OPEN_REAL13_RETURN_CORRIDOR_AROUND_FIXED_POWER124',before:before12,after:clone(after12),sameActualCpuAndRamEndpoints:true,noBranchesRequestsViasReferencesOrCriticalChanged:true,sourcePacketSha256:inputPin};report.manual12Inverse=clone(manual12Inverse)

 for(const move of moves){
  req(![...held,...captured].some(t=>owner(t)===move.name),'No routed/critical owner may move')
  const index=working.traces.findIndex((t:R)=>owner(t)===move.name&&near(t.route[0],move.pad)),before=clone(working.traces[index]);req(index>=0&&before,'Exact numeric missing CPU-owned approach')
  const events=before.route.filter((p:R)=>p.route_type==='via');req(events.length===1&&near(events[0],move.beforeVia)&&same(events[0].layers,L)&&events[0].via_diameter===VD&&events[0].via_hole_diameter===HD,'Exact old missing CPU fullspan barrel required')
  const ci=working.connections.findIndex((c:R)=>c.name===move.name),oldRequest=clone(working.connections[ci]);req(ci>=0&&near(oldRequest.pointsToConnect[move.side],move.beforeVia),'Original missing CPU request order required')
  const layer=before.route.at(-1).layer,first=clone(before.route[0]),after={...clone(before),trace_length:Math.hypot(first.x-move.afterVia.x,first.y-move.afterVia.y),route:[first,{route_type:'wire',...move.afterVia,layer:'top',width:W},{...clone(events[0]),...move.afterVia},{route_type:'wire',...move.afterVia,layer,width:W}]}
  working.traces[index]=after;const points=clone(oldRequest.pointsToConnect);points[move.side]={...points[move.side],...move.afterVia};working.connections[ci]={...clone(oldRequest),pointsToConnect:points}
  const inverse={owner:move.name,reason:'DECLARED_MISSING13_CPU_SE_TO_NE_DOGBONE_RELOCATION',branches:[{index,before,after:clone(after)}],connection:{index:ci,before:oldRequest,after:clone(working.connections[ci])},noForeignMaterialReleased:true};atomicInverses.push(inverse);releasedWorkingBranchMaterial.push(clone(inverse))
 }
 const changedIndices=new Set(atomicInverses.map(r=>r.branches[0].index)),changedOwners=new Set(moves.map(m=>m.name))
 req(base.traces.every((t:R,i:number)=>changedIndices.has(i)||same(t,working.traces[i]))&&base.connections.every((c:R,i:number)=>changedOwners.has(c.name)||same(c,working.connections[i]))&&same(base.obstacles,working.obstacles)&&same(base.buses,working.buses)&&same(base.differentialPairs,working.differentialPairs),'Only the declared missing13 CPU owned approach/request may change')
 const expectedWorking=clone(constructor.full49FanoutInput)
 for(const inverse of atomicInverses){for(const b of inverse.branches)expectedWorking.traces[b.index]=clone(b.after);expectedWorking.connections[inverse.connection.index]=clone(inverse.connection.after)}
 req(same(working,expectedWorking)&&same(held,constructor.heldCarrierTraces)&&same(base,constructor.full49FanoutInput),'Changed foundation must equal only the exact declared13 branch/request delta from actual215 constructor; no constructor bypass')
 report.constructorFoundationDelta={sourcePacketSha256:inputPin,constructorSha256:profilePin,declaredChangedBranchIds:atomicInverses.map(r=>r.branches[0].after.pcb_trace_id),declaredChangedRequests:atomicInverses.map(r=>r.owner),fullExpectedFoundationEqualityPassed:true,criticalSixLiteralUnchanged:true,allReferencesLiteralUnchanged:true}
 report.atomicFanoutInverses=clone(atomicInverses);report.atomicFanoutPhysicalReports=[];save()
 const atomicScene={...working,traces:[...working.traces,...held,...captured]}
 for(const inverse of atomicInverses){
  const t=inverse.branches[0].after,first=t.route[0],end=t.route[1],via=t.route[2],c=working.connections.find((c:R)=>c.name===owner(t)),pad=working.obstacles.filter((o:R)=>near(o.center,first)&&o.circuitJsonMetadata?.pcb_port_id&&o.connectedTo.includes(owner(t)))
  req(pad.length===1&&first.layer==='top'&&[first.start_pcb_port_id,first.end_pcb_port_id].filter(Boolean).every((id:string)=>id===pad[0].circuitJsonMetadata.pcb_port_id),'Actual numeric Top ball backing, no stale fanout-port alias')
  // Exclude only this installed approach for land checks; its incident own stub
  // naturally meets its own land. Other owned material and every foreign object
  // remain present. A radial straight stub has only initial numeric-pad contact.
  const other={...atomicScene,traces:atomicScene.traces.filter((q:R)=>q.pcb_trace_id!==t.pcb_trace_id)},fixed=fixedCopper(other),landViolations:R[]=[]
  for(const q of fixed)if(clearanceToCopper(via,via,q)<VD/2+(working.minViaEdgeToPadEdgeClearance??W)-1e-8)landViolations.push({layer:q.layer,owners:q.owners,distanceToCopperMm:clearanceToCopper(via,via,q)})
  const physicalHoles=extraHoles(other),drillViolations=physicalHoles.filter((h:R)=>Math.hypot(via.x-h.x,via.y-h.y)<HD/2+h.diameter/2+Math.max(working.minViaHoleEdgeToViaHoleEdgeClearance??.254,working.minPlatedHoleDrillEdgeToDrillEdgeClearance??0)-1e-8),wireDrillViolations=physicalHoles.filter((h:R)=>pointSegmentDistanceToPoints(h,first,end)<W/2+h.diameter/2+(working.minTraceToHoleEdgeClearance??.2)-1e-8)
  const stub={...clone(t),pcb_trace_id:t.pcb_trace_id+'_atomic_top_stub',route:[clone(first),clone(end)]},stubConnection={...c,pointsToConnect:[first,end].map((p:R)=>({x:p.x,y:p.y,layer:'top'}))},input={...atomicScene,connections:[stubConnection],buses:[],differentialPairs:[]},validator=BusLanesSolver.forValidation(input,[stub],{smoothTuning:true,denseSearch:true,maxSearchIterations:2000000});for(let k=0;k<8&&!validator.solved&&!validator.failed;k++)validator.step()
  const nativeViaLandGap=nativeViaLandReport(t,other),nativeViaPadScenes=nativePadClearanceScenes(other),nativeViaPadClearancePassed=nativeViaPadScenes.every(scene=>scene.visible(via,via)),outlineViolations=boardOutlineViolations(working,[t]),native=nativeSignalGeometryIsValid(t)&&nativeSignalGeometryIsValid(stub),self=tuningPathIsSelfClear(stub.route,W+(working.minTraceToPadEdgeClearance??W)),r={owner:owner(t),pcb_trace_id:t.pcb_trace_id,numericPadId:pad[0].circuitJsonMetadata.pcb_port_id,allFourLayersChecked:true,nativeViaLandGap,nativeViaPadClearancePassed,landViolations,drillViolations,wireDrillViolations,outlineViolations,nativeGeometry:native,selfClear:self,topStubC31:{solved:validator.solved,error:validator.error,failureCode:validator.failureCode},passed:nativeViaLandGap.passed&&nativeViaPadClearancePassed&&!landViolations.length&&!drillViolations.length&&!wireDrillViolations.length&&!outlineViolations.length&&native&&self&&validator.solved};report.atomicFanoutPhysicalReports.push(r);save()
 }
 report.atomicFanoutsPhysicallyPreflightPassed=report.atomicFanoutPhysicalReports.length===1&&report.atomicFanoutPhysicalReports.every((r:R)=>r.passed);req(report.atomicFanoutsPhysicallyPreflightPassed,'Atomic dogbone fullspan/stub physical preflight failed; no routing or acceptance')

 const check12=(foundation:R,others:R[],body:R)=>{const input={...foundation,traces:[...foundation.traces,...held,...others.filter(t=>owner(t)!=='source_trace_12')]},connection=foundation.connections.find((c:R)=>c.name==='source_trace_12');return qualifyMixedCarrier({...input,extraPhysicalHoles:extraHoles(input)},connection,body,helpers)}
 const before12Qualification=check12(base,parentCaptured,before12),after12Qualification=check12(working,captured,after12),whole12Mm=lengths.fixedRouteLength(working,'source_trace_12')+planar(after12),bound12=rules.find((b:R)=>b.connectionNames.includes('source_trace_12')&&b.maxLength!==undefined)
 report.manual12BeforeAfter={beforeQualification:before12Qualification,afterQualification:after12Qualification,wholeLengthMm:whole12Mm,derivedMinimumMm:bound12.minLength??null,derivedMaximumMm:bound12.maxLength,joinedNativeGeometry:nativeSignalGeometryIsValid(joined(after12)),withinDerivedCriticalWindow:whole12Mm<=bound12.maxLength+1e-7&&(bound12.minLength===undefined||whole12Mm>=bound12.minLength-1e-7)};save()
 req(before12Qualification.passed&&after12Qualification.passed&&report.manual12BeforeAfter.joinedNativeGeometry&&report.manual12BeforeAfter.withinDerivedCriticalWindow,'Declared12 body before/after physical/native/true-length qualification failed')
 report.beforeSearchAll46PhysicalReports=[]
 for(const t of [...held,...captured]){
  req(performance.now()-started<budget-3000,'Budget expired during required before-search46 physical controls')
  const walls={...working,traces:[...working.traces,...held,...captured].filter((q:R)=>owner(q)!==owner(t)||working.traces.includes(q))},c=working.connections.find((c:R)=>c.name===owner(t)),q=qualifyMixedCarrier({...walls,extraPhysicalHoles:extraHoles(walls)},c,t,helpers),numeric=joined(t),r={owner:owner(t),...q,joinedNativeGeometry:nativeSignalGeometryIsValid(numeric)}
  report.beforeSearchAll46PhysicalReports.push(r);save()
 }
 report.beforeSearchAll46Qualified=report.beforeSearchAll46PhysicalReports.length===46&&report.beforeSearchAll46PhysicalReports.every((r:R)=>r.passed&&r.joinedNativeGeometry)
 save();req(report.beforeSearchAll46Qualified,'Every retained46 must freshly qualify in exact atomic scene before searching')
 const persist=()=>{
  const all=[...held,...captured,...retained],numeric=all.map(t=>joined(t)),dormant:R[]=[]
  const ordinaryMinimumLengthObservations=[...captured,...retained].map(t=>{
   const name=owner(t),wholeLengthMm=lengths.fixedRouteLength(working,name)+planar(t),ownerRules=rules.filter(b=>b.connectionNames.includes(name));req(ownerRules.length===1,'Exactly one real ordinary bus rule including unbounded RESET');const r=ownerRules[0],minimumWholeMm=r.minLength??null,maximumWholeMm=r.maxLength??null,minimumMatched=minimumWholeMm===null?null:wholeLengthMm>=minimumWholeMm-1e-7,maximumSatisfied=maximumWholeMm===null?null:wholeLengthMm<=maximumWholeMm+1e-7
   return {owner:name,wholeLengthMm,derivedWholeWindowMm:[minimumWholeMm,maximumWholeMm],minimumBoundPresent:minimumWholeMm!==null,maximumBoundPresent:maximumWholeMm!==null,unboundedWholeLength:minimumWholeMm===null&&maximumWholeMm===null,minimumMatched,maximumSatisfied,belowMinimumNeedsLengthTuning:minimumMatched===false,physicalConnectivityStageOnly:true,matched:false,timingPassed:false}
  })
  const wholeByOwner=new Map(all.map(t=>[owner(t),lengths.fixedRouteLength(working,owner(t))+planar(t)]))
  const originalBusConstraintObservations=working.buses.map((rule:R)=>{
   const present=rule.connectionNames.filter((n:string)=>wholeByOwner.has(n)).map((n:string)=>({owner:n,wholePlanarLengthMm:wholeByOwner.get(n)!})),missingOwners=rule.connectionNames.filter((n:string)=>!wholeByOwner.has(n)),values=present.map((r:R)=>r.wholePlanarLengthMm),observedSkewMm=values.length>=2?Math.max(...values)-Math.min(...values):null,violations:R[]=[]
   for(const r of present){if(rule.minLength!==undefined&&r.wholePlanarLengthMm<rule.minLength-1e-7)violations.push({kind:'ORIGINAL_MIN_LENGTH',owner:r.owner,actualMm:r.wholePlanarLengthMm,requiredMm:rule.minLength});if(rule.maxLength!==undefined&&r.wholePlanarLengthMm>rule.maxLength+1e-7)violations.push({kind:'ORIGINAL_MAX_LENGTH',owner:r.owner,actualMm:r.wholePlanarLengthMm,requiredMm:rule.maxLength})}
   if(rule.maxLengthSkew!==undefined&&observedSkewMm!==null&&observedSkewMm>rule.maxLengthSkew+1e-7)violations.push({kind:'ORIGINAL_MAX_LENGTH_SKEW',actualMm:observedSkewMm,requiredMm:rule.maxLengthSkew})
   return {originalRule:clone(rule),measurement:'WHOLE_PLANAR_XY_CENTERLINE_MM_FANOUTS_PLUS_CARRIER',present,missingOwners,allMembersPresent:missingOwners.length===0,observedSkewMm,violations,observedPlanarConstraintsPassed:missingOwners.length===0&&violations.length===0,electricalTimingQualified:false}
  })
  const originalPairConstraintObservations=working.differentialPairs.map((rule:R)=>{
   const missingOwners=rule.connectionNames.filter((n:string)=>!wholeByOwner.has(n)),values=rule.connectionNames.filter((n:string)=>wholeByOwner.has(n)).map((n:string)=>({owner:n,wholePlanarLengthMm:wholeByOwner.get(n)!})),observedLengthSkewMm=values.length===2?Math.abs(values[0].wholePlanarLengthMm-values[1].wholePlanarLengthMm):null
   return {originalRule:clone(rule),values,missingOwners,observedLengthSkewMm,lengthToleranceSatisfied:observedLengthSkewMm===null?null:observedLengthSkewMm<=rule.lengthTolerance+1e-7,spacingCouplingGeometryExecutedByThisObservation:false,electricalTimingQualified:false}
  })
  report.originalBusConstraintObservations=clone(originalBusConstraintObservations);report.originalPairConstraintObservations=clone(originalPairConstraintObservations)
  report.ordinaryMinimumLengthObservations=clone(ordinaryMinimumLengthObservations);report.minimumMatched=ordinaryMinimumLengthObservations.filter(r=>r.minimumBoundPresent).every(r=>r.minimumMatched);report.physicalConnectivityStage='PARTIAL_CONNECTED_TOPOLOGY_UNMATCHED_TIMING_PENDING';report.minimumLengthFailuresRetained=ordinaryMinimumLengthObservations.filter(r=>r.minimumMatched===false).map(r=>r.owner)


  for(const t of working.traces)for(let i=0;i<t.route.length;i++){const p=t.route[i];if(p.route_type==='via'&&all.some(q=>owner(q)===owner(t))&&!numeric.find(q=>owner(q)===owner(t))!.route.some((q:R)=>q.route_type==='via'&&near(p,q)))dormant.push({owner:owner(t),pcb_trace_id:t.pcb_trace_id,routeIndex:i,...p})}
  const p={manual12Inverse:clone(manual12Inverse),manual12BeforeAfter:clone(report.manual12BeforeAfter),manual13Route:clone(report.manual13Route??null),manual13Head:clone(report.manual13Head??null),ordinaryBodyInverses:clone(packet.ordinaryBodyInverses??[]),manualD5Seed:clone(packet.manualD5Seed??null),scope:'ACTUAL215_COMPLETE_MANUAL13_DECLARED12_RIGHT_BODY_UNMATCHED_TOPOLOGY_CANDIDATE',manual11Inverse:clone(manual11Inverse),manual11BeforeAfter:clone(packet.manual11BeforeAfter??null),clockPairRepair:clone(packet.clockPairRepair??null),beforeSearchAll46Qualified:report.beforeSearchAll46Qualified,constructorFoundationDelta:clone(report.constructorFoundationDelta),ordinaryMinimumLengthObservations:clone(ordinaryMinimumLengthObservations),originalBusConstraintObservations:clone(originalBusConstraintObservations),originalPairConstraintObservations:clone(originalPairConstraintObservations),minimumMatched:report.minimumMatched,minimumLengthFailuresRetained:clone(report.minimumLengthFailuresRetained),physicalConnectivityStage:'PARTIAL_CONNECTED_TOPOLOGY_UNMATCHED_TIMING_PENDING',inheritedAtomicFanoutInverses:clone(packet.atomicFanoutInverses??[]),manual40Inverse:clone(manual40Inverse),manual40BeforeAfter:clone(packet.manual40BeforeAfter??null),atomicFanoutInverses:clone(atomicInverses),atomicFanoutPhysicalReports:clone(report.atomicFanoutPhysicalReports),workingChanges:[...clone(packet.workingChanges??[]),{type:'DECLARED_MISSING13_CPU_NE_AND_RETAINED12_BODY_OUTER_RIGHT_FOR_COMPLETE_MANUAL13',manual12Inverse:clone(manual12Inverse),manual11Inverse:clone(manual11Inverse),inverses:clone(atomicInverses),manual40Inverse:clone(manual40Inverse)}],source21NativeTopRepair:clone(packet.source21NativeTopRepair??null),full49FanoutInput:working,heldCarrierTraces:held,ordinaryCarrierTraces:[...captured,...retained],carrierTraces:all,joinedNumericPadTraces:numeric,dormantWorkingBarrels:dormant,releasedWorkingBranchMaterial,physicalRunReports:report.physicalRunReports,newViaReports:report.newViaReports,finalScenePhysicalReports:report.finalScenePhysicalReports??[],allSavedCarriersCurrentSceneQualified:report.allSavedCarriersCurrentSceneQualified===true,newViaEventCount:[...captured,...retained].reduce((s,t)=>s+t.route.filter((p:R)=>p.route_type==='via').length,0),capturedMixedOwners:captured.filter(t=>t.route.some((p:R)=>p.route_type==='via')).map(owner),retainedMixedOwners:retained.map(owner),all49Connected:all.length===49,all49Accepted:false,wholeMixedC31Supported:false,matched:false,timingPassed:false,electricalTimingQualified:false,nativeExecuted:false,cadExecuted:false,fabricationReady:false}
  fs.writeFileSync(stem+'.candidate.json',JSON.stringify(p,null,2)+'\n');report.connectedAll49Count=all.length;report.remaining=missing.filter((n:string)=>!retained.some(t=>owner(t)===n));report.all49Connected=all.length===49;save()
 }

 const headName='source_trace_13',portal={x:4.815,y:14.4},headPoints=[[0,14.4],[.38896,14.78896],[.93624,14.78896],[1.21056,15.06328],[1.21056,15.35792],[1.43408,15.58144],[4.3,15.58144],[4.4,15.48144],[4.4,14.815],[4.815,14.4]],headTrace:R={type:'pcb_trace',pcb_trace_id:'manual13_actual215_bottom_head',connection_name:headName,source_trace_id:headName,route:headPoints.map(([x,y])=>({route_type:'wire',x,y,layer:'bottom',width:W}))},headLengthMm=planar(headTrace),portalVia={route_type:'via',...portal,from_layer:'bottom',to_layer:'inner1',layers:clone(L),via_diameter:VD,via_hole_diameter:HD}
 const headWalls={...working,traces:[...working.traces,...held,...captured]},headConnection={...working.connections.find((c:R)=>c.name===headName),pointsToConnect:[headTrace.route[0],headTrace.route.at(-1)].map((p:R)=>({x:p.x,y:p.y,layer:'bottom'}))},headInput={...headWalls,connections:[headConnection],buses:[],differentialPairs:[]},headValidator=BusLanesSolver.forValidation(headInput,[headTrace],{smoothTuning:true,denseSearch:true,maxSearchIterations:2000000});for(let k=0;k<8&&!headValidator.solved&&!headValidator.failed;k++)headValidator.step()
 const headFixed=fixedCopper(headWalls),headPortalScenes=L.map(layer=>new VectorScene(headWalls,{name:headName,pointsToConnect:[{...portal,layer},{...portal,layer}]},VD,headFixed)),headPadScenes=nativePadClearanceScenes(headWalls),headHoles=extraHoles(headWalls).filter((h:R)=>h.owner!==headName),headViaLand=nativeViaLandReport({connection_name:headName,route:[portalVia]},headWalls),headPortalDrill=headHoles.filter((h:R)=>Math.hypot(portal.x-h.x,portal.y-h.y)<HD/2+h.diameter/2+Math.max(working.minViaHoleEdgeToViaHoleEdgeClearance??.254,working.minPlatedHoleDrillEdgeToDrillEdgeClearance??0)-1e-8),headWireDrill=headTrace.route.slice(1).flatMap((b:R,i:number)=>headHoles.filter((h:R)=>pointSegmentDistanceToPoints(h,headTrace.route[i],b)<W/2+h.diameter/2+(working.minTraceToHoleEdgeClearance??.2)-1e-8).map((h:R)=>({segmentIndex:i,...h})))
 report.manual13Head={owner:headName,carrierPrefix:clone(headTrace),wholeCarrierNotYetCreated:true,mandatoryFirstFullspanPortalEvent:true,searchInitialViaCount:1,headPlanarLengthMm:headLengthMm,actualCPUFanoutMm:lengths.fixedRouteLength({...working,traces:working.traces.filter((t:R)=>owner(t)===headName&&near(t.route[0],{x:-.4,y:14}))},headName),portal:clone(portal),standardFullspanVia:clone(portalVia),allFourLayerLandClear:headPortalScenes.every(s=>s.visible(portal,portal)),actualViaPadClear:headPadScenes.every(s=>s.visible(portal,portal)),nativeViaLandGap:headViaLand,drillViolations:headPortalDrill,wireDrillViolations:headWireDrill,outlineViolations:boardOutlineViolations(working,[headTrace,{...headTrace,route:[portalVia]}]),prefixNative:nativeSignalGeometryIsValid(headTrace),prefixSelfClear:tuningPathIsSelfClear(headTrace.route,W+W),prefixC31:{solved:headValidator.solved,error:headValidator.error,failureCode:headValidator.failureCode},maximumWholeMm:maximumWhole(headName),minimumWholeMm:minimumWhole(headName),matched:false,timingPassed:false};save()
 req(report.manual13Head.allFourLayerLandClear&&report.manual13Head.actualViaPadClear&&headViaLand.passed&&!headPortalDrill.length&&!headWireDrill.length&&!report.manual13Head.outlineViolations.length&&report.manual13Head.prefixNative&&report.manual13Head.prefixSelfClear&&headValidator.solved,'Required authentic13 manual head/portal physical preflight failed')

 const tail13=[[4.815,14.4],[5.6,13.615],[5.6,11.8],[6,11.4],[6,11],[5.6,10.6],[5.6,9],[5.2,8.6]],manualTrace:R={type:'pcb_trace',pcb_trace_id:'manual13_NE_cpu_bottom_head_I1_fixed124_bypass',connection_name:headName,source_trace_id:headName,route:[...clone(headTrace.route),{...clone(portalVia),to_layer:'inner1'},...tail13.map(([x,y])=>({route_type:'wire',x,y,layer:'inner1',width:W}))]}
 const connection=clone(working.connections.find((c:R)=>c.name===headName)),menus=createEndpointMenus(working,connection,{retargetGeneratedEscape}),selection=applyEndpointSelection(working,connection,manualTrace,menus,{retargetGeneratedEscape}),next=selection.foundation,numeric=joined(manualTrace,next),whole13Mm=lengths.fixedRouteLength(next,headName)+planar(manualTrace),minimum13Mm=minimumWhole(headName),maximum13Mm=maximumWhole(headName),walls={...next,traces:[...next.traces,...held,...captured]}
 rawCandidates.push({name:headName,carrierTrace:clone(manualTrace),joinedNumericPadTrace:clone(numeric),unqualifiedEndpointChanges:clone(selection.inverse),declared12BodyInverse:clone(manual12Inverse),qualified:false,matched:false,all49Accepted:false});fs.writeFileSync(report.rawCandidatesPath,JSON.stringify({scope:'COMPLETE_MANUAL13_UNQUALIFIED_BEFORE_INDEPENDENT_CHECKS',candidates:rawCandidates,all49Accepted:false},null,2)+'\n')
 const qualification=qualifyMixedCarrier({...walls,extraPhysicalHoles:extraHoles(walls)},next.connections.find((c:R)=>c.name===headName),manualTrace,helpers),nativeViaLand=nativeViaLandReport(manualTrace,walls),nativeJoined=nativeSignalGeometryIsValid(numeric)
 report.manual13Route={owner:headName,carrierTrace:clone(manualTrace),joinedNumericPadTrace:clone(numeric),endpointInverse:clone(selection.inverse),physicalQualification:qualification,nativeViaLandGap:nativeViaLand,joinedNativeGeometry:nativeJoined,wholePlanarLengthMm:whole13Mm,derivedMinimumWholeMm:minimum13Mm,derivedMaximumWholeMm:maximum13Mm,minimumMatched:whole13Mm>=minimum13Mm-1e-7,maximumSatisfied:whole13Mm<=maximum13Mm+1e-7,belowMinimumNeedsLengthTuning:whole13Mm<minimum13Mm-1e-7,maximumSlackMm:maximum13Mm-whole13Mm,newThroughViaCount:manualTrace.route.filter((p:R)=>p.route_type==='via').length,matched:false,timingPassed:false,electricalTimingQualified:false,fabricationReady:false};save()
 req(whole13Mm<=maximum13Mm+1e-7&&qualification.passed&&nativeViaLand.passed&&nativeJoined,'Complete manual13 must freshly pass true max/native/per-run/via physical checks')
 working=next;releasedWorkingBranchMaterial.push(clone(selection.inverse));retained.push(manualTrace);report.retained.push(clone(manualTrace));report.physicalRunReports.push(...qualification.physicalRunReports.map((r:R)=>({owner:headName,...r})));report.newViaReports.push(...qualification.newViaReports.map((r:R)=>({owner:headName,...r})));report.manual13Route.qualified=true
 persist()
 const all=[...held,...captured,...retained];report.finalScenePhysicalReports=[]
 for(const t of [...retained,...held,...captured]){
  req(performance.now()-started<budget,'Finite budget expired during required final47 physical controls')
  const input={...working,traces:[...working.traces,...all.filter(q=>owner(q)!==owner(t))]},c=working.connections.find((c:R)=>c.name===owner(t)),q=qualifyMixedCarrier({...input,extraPhysicalHoles:extraHoles(input)},c,t,helpers)
  report.finalScenePhysicalReports.push({owner:owner(t),...q,joinedNativeGeometry:nativeSignalGeometryIsValid(joined(t))});save()
 }
 report.allSavedCarriersCurrentSceneQualified=report.finalScenePhysicalReports.length===47&&report.finalScenePhysicalReports.every((r:R)=>r.passed&&r.joinedNativeGeometry)
 persist();req(report.allSavedCarriersCurrentSceneQualified,'All47 must qualify in actual complete manual13 scene');req(JSON.stringify({base,held,parentCaptured})===frozen,'Held public scene mutated')
 report.terminalOutcome='MANUAL13_CONNECTED_47_WITH_ALL47_PHYSICAL_NATIVE_GEOMETRY_CONTROLS_TIMING_SOURCE_NATIVE_PENDING'
}catch(e){report.terminalOutcome='EXCEPTION_NO_ACCEPTANCE';report.error=e instanceof Error?e.stack:String(e);process.exitCode=2}finally{save()}
console.log(JSON.stringify({out,terminalOutcome:report.terminalOutcome,connectedAll49:report.connectedAll49Count,remaining:report.remaining,all49Accepted:false}))
