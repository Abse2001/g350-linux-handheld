#!/usr/bin/env python3
"""Root-run stdlib persistence of scoped Source313 pour evidence; no SDK/geometry.

The full bounded325 report, complete326 retry and327 aggregate are preserved.
Only completed comparison rows qualified in the reviewed Root327 aggregate.
Base is Source313's220 actual targets, never Model318's239-target model branch.
"""
import argparse
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import time

BOARD = Path('/workspace/g350-linux-handheld')
BASE = Path('/tmp/g350-source313-portable-increment-20261016')
BASE_REL = '.cloud-tools/ddr-four-layer-source313-2026-10-16'
BASE_STEM = 'g350-four-layer-both-bytes-ca16-connected49-source313-2026-10-16'
BASE_ARCHIVE_SHA = '6204924e3299369cfe4be5e54f983187879f34f983560cef5583b7704a7467ed'
BASE_MANIFEST_SHA = '5e866e577fe4f2245cafa0f71416a56e99ffe3f2f7221c603c08490e34b7ff5b'
BASE_PINS = {
    'PROGRESS.json': '98699140728e17eed957ebd151b4a4902a0603440385cd860cd912731ea7b553',
    'README.md': '50e1f3abedbbb264df109f13396de71592088b1cfbd857f43c151456942a26b8',
    'WORKSPACE_HASH_INDEX.json': '355676fce02c9eb42a134ebb0cb779621998bc5b5ddd35335519f3fba3de9422',
    'WORKSPACE_RESTORE_MANIFEST.json': 'df9b65e530773f88f559679154e2444357a1919ca9c2e483b37fe0a9598ac49d'}
PROFILE = Path('/tmp/g350-source313-pour327-portable-profile-sourceonly.json')
PROFILE_SHA = 'a635a025e93262a0dbb17114e9bb90cade242f37551fd12a96645aa22f214bc1'
SAVED = Path('/tmp/g350-source313-pour327-portable-increment-20261017')
REL = '.cloud-tools/ddr-source313-pour327-2026-10-17'
STEM = 'g350-source313-scoped-all19-pour-margin-2026-10-17'
SCOPE = 'PORTABLE_SOURCE313_SCOPED19_DDR_FOREIGN_POUR_MARGIN_EVIDENCE_NOT_BOARD_QUALIFICATION'
AGGREGATE_SHA = '60a3e0f6c0ca9bf0a91390385e314f116b7926cad2bcaa7e0ce6e99d4f9aa5cd'
AUDITOR_SHA = 'c6b5c774f306331c8f658c735c0d5e48cd8d3f53c9eb0656ce4119ff71a9163a'
COMBINER_SHA = 'ad1092a5e44d39619cd478863c7cc82176ea5a88db945c0c4eb5392682d23061'
INPUTS = {
    'raw': ('/tmp/g350-both-bytes-ca16-ti3w-model299-core313-raw.json', '2899641a823e870db43b4dde16cec50bcebec8434ef09ebf5d980300d087c59e'),
    'controls': ('/tmp/g350-both-bytes-ca16-ti3w-model299-core-smol-root-20261016-run313/byte0-result.json', '3bda070f41549fef4c33f455132b2e3a5d34100a7c3abbf01cc1b8014373a33a'),
    'current234Ownership': ('/tmp/g350-both-bytes-ca16-ti3w-model299-via-track-root-20261016-run315/byte0-result.json', '2b1a6c073b9dcf00577d4e0e2546b0178932c1dd2f87d4f8f3ec0db483d4ec9c'),
    'reviewedSourcePlan311': ('/tmp/g350-both-bytes-ca16-ti3w-model299-projector-root-20261016-run311/byte0-result.json', '35f5fb65d14e5386797eaf24475813f6205a65466ac2df600e12f38f31b0ce74')}
RESTORER = BOARD / 'scripts/restore-g350-routing-evidence.py'
RESTORER_SHA = '148bad0fc4132ece5f78f18b05e4bc71d79019312343eda954ed7ca91874a643'
HELPER = BOARD / 'scripts/restore-g350-four-layer-routing-workspace.py'
HELPER_SHA = '6c5d321a256eadf58697f0f565b5bffa4a55491fce39ed0db7e7675604b6f3cc'
SOLVER_ROOT = '/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib'
META = ('README.md', 'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json')
FALSE = dict.fromkeys(('all49Accepted', 'fullBoardPassed', 'nativeBoardPassed', 'fullTimingPassed',
    'electricalTimingQualified', 'tiQualified', 'referenceContinuityQualified', 'cadQualified',
    'defaultBoardPromoted', 'fabricationReady', 'currentPourQualified', 'ownNetReentryQualified',
    'freshPdnPlaneConnectivityQualified', 'referenceWireGeometryIncluded'), False)

def need(value, message):
    if not value:
        raise ValueError(message)

def regular(path):
    return path.is_file() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
        os.posix_fadvise(stream.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return h.hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def md(path):
    need(regular(path), 'Regular public evidence: ' + str(path))
    return dict(bytes=path.stat().st_size, sha256=sha(path), mode=stat.S_IMODE(path.stat().st_mode))

def exact(path, row):
    need(md(path) == {k: row[k] for k in ('bytes', 'sha256', 'mode')}, 'Exact bytes/hash/mode: ' + str(path))

def relative(name):
    p = PurePosixPath(name)
    need(p.parts and not p.is_absolute() and '..' not in p.parts and str(p) == name and '\\' not in name
         and not any(x in name.upper() for x in ('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'BOUND_CONTEXT', 'CONTEXT_BODY')),
         'Canonical public relative member')
    return Path(*p.parts)

def write(path, value):
    with path.open('x') as stream:
        os.fchmod(stream.fileno(), 0o600)
        json.dump(value, stream, indent=2, allow_nan=False); stream.write('\n')
        stream.flush(); os.fsync(stream.fileno())

def publish(temporary, final):
    os.link(temporary, final); temporary.unlink()

def source313(args):
    need(args.source313_archive_sha == BASE_ARCHIVE_SHA and args.source313_manifest_sha == BASE_MANIFEST_SHA,
         'Explicit actual Source313 archive/manifest pins')
    for name, h in BASE_PINS.items():
        need(regular(BASE / name) and sha(BASE / name) == h, 'Frozen Source313 metadata')
    index, manifest, progress = [read(BASE / n) for n in ('WORKSPACE_HASH_INDEX.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'PROGRESS.json')]
    need(len(index['files']) == 43 and len(manifest['files']) == 40 and len(manifest['baseDependencyRestoreFiles']) == 180,
         'Exact Source31344/40/180 closure')
    need({p.name for p in BASE.iterdir()} == {r['path'] for r in index['files']} | {'WORKSPACE_HASH_INDEX.json'}, 'Complete base inventory')
    for row in index['files']:
        exact(BASE / relative(row['path']), row)
    targets = [{'baseSavedDirectory': BASE_REL, **r} for r in manifest['files']] + manifest['baseDependencyRestoreFiles']
    need(len(targets) == len({r['restorePath'] for r in targets}) == 220, 'Source313220 base targets, not Model318239')
    for row in targets:
        exact(Path(row['restorePath']), row)
    by_path = {r['restorePath']: r for r in targets}
    for path, h in INPUTS.values():
        need(path in by_path and by_path[path]['sha256'] == h, 'All current raw/control/auth/plan inputs restored by base')
    archive = BOARD / ('cloud/artifacts/' + BASE_STEM + '.tar.gz'); metadata = archive.with_name(BASE_STEM + '.manifest.json')
    need(sha(archive) == BASE_ARCHIVE_SHA and sha(metadata) == BASE_MANIFEST_SHA, 'Published Source313 archive pair')
    am = read(metadata)
    need(am['scope'] == 'PORTABLE_SOURCE313_CA16_TI3W_EDITABLE_CONNECTED49_CHECKPOINT'
         and am['archive']['sha256'] == BASE_ARCHIVE_SHA and am['archive']['bytes'] == archive.stat().st_size
         and len(am['files']) == 44 and am['snapshotPins'] == {BASE_REL + '/' + n: h for n, h in BASE_PINS.items()}, 'Exact portable Source313 base')
    need(manifest['solverSourceRoot'] == SOLVER_ROOT and progress['latestEditableSourceCoreScope'] == 313,
         'Actual editable Source313 and pinned solver import root')
    for dependency in progress['baseArchiveDependenciesInRestoreOrder']:
        for key, h in (('path', dependency['sha256']), ('manifest', dependency['manifestSha256'])):
            path = BOARD / relative(dependency[key])
            need(regular(path) and sha(path) == h, 'All prior archive dependencies unchanged')
    dep = {**am['archive'], 'manifest': metadata.relative_to(BOARD).as_posix(), 'manifestSha256': BASE_MANIFEST_SHA,
           'mustBeRestoredFirst': True, 'payloadCopiedByThisCollector': False}
    return manifest, progress, targets, dep

def evidence():
    need(sha(PROFILE) == PROFILE_SHA, 'Frozen compact public payload profile')
    profile = read(PROFILE); rows = profile['artifacts']
    need(len(rows) == len({r['restorePath'] for r in rows}) == len({r['savedPath'] for r in rows}) == 20,
         'Exact20 unique whole report/source/receipt payloads')
    need(sum(r['bytes'] for r in rows) == profile['plannedPayloadBytes'] == 40927357, 'Measured whole unfiltered payload')
    for row in rows:
        need(row['restorePath'].startswith('/tmp/g350-') and Path(row['restorePath']).resolve().is_relative_to('/tmp')
             and relative(row['savedPath']).name == row['savedPath'] and row['savedPath'] not in META, 'Tmp-only flat public evidence')
        exact(Path(row['restorePath']), row)
    indexed = {r['savedPath']: r for r in rows}
    load = lambda name: read(Path(indexed[name]['restorePath']))
    first, retry, aggregate = [load(n) for n in ('RUN325_pour-report.json', 'RUN326_pour-report.json', 'RUN327_coverage-report.json')]
    need(indexed['AUDITOR_SOURCE.py']['sha256'] == AUDITOR_SHA and indexed['COMBINER_SOURCE.py']['sha256'] == COMBINER_SHA
         and indexed['RUN327_coverage-report.json']['sha256'] == AGGREGATE_SHA, 'Reviewed sources and actual Root327 output')
    for report in (first, retry, aggregate):
        need(report['inputFilesUnchanged'] is True and report['auditSourceSha256'] == AUDITOR_SHA
             and all(report['inputBindings'][k]['sha256'] == h for k, (_, h) in INPUTS.items())
             and report['actualRawPourCount'] == 19 and report['actualViaCount'] == 234 and report['wireSegmentCount'] == 5623,
             'All contributions bind the same actual Source313 inputs and literal catalogues')
        need(all(report[k] == [] for k in ('violations', 'unsupportedGeometry'))
             and all(report[k] is False for k in ('ownNetReentryQualified', 'freshPdnPlaneConnectivityQualified',
                 'referenceWireGeometryIncluded', 'fullBoardPassed', 'fabricationReady')), 'Exact scoped result boundaries and no filtered findings')
    completed = [p['pcbCopperPourId'] for p in first['pourReports'] if p['state'] == 'COMPLETED']
    partials = [p for p in first['pourReports'] if p['state'] != 'COMPLETED']
    need(first['completed'] is False and first['allActualPoursCompleted'] is False and len(completed) == 16
         and len(partials) == 1 and partials[0]['pcbCopperPourId'] == 'pcb_copper_pour_93'
         and partials[0]['state'] == 'BOUNDED_PARTIAL' and partials[0]['viaChecks'] == [] and partials[0]['wireChecks'] == [],
         'Whole bounded325 preserved; its partial93 has zero qualifying checks')
    last_ids = ['pcb_copper_pour_93', 'pcb_copper_pour_98', 'pcb_copper_pour_99']
    need(retry['completed'] is True and retry['literalForeignPourMarginClear'] is True
         and retry['selectedPourIds'] == last_ids and len(retry['pourReports']) == 3
         and [p['pcbCopperPourId'] for p in retry['pourReports']] == last_ids
         and all(p['state'] == 'COMPLETED' for p in retry['pourReports']), 'Actual326 completed retry of all last3')
    need(aggregate['completed'] is True and aggregate['literalForeignPourMarginClear'] is True
         and aggregate['sameExactRawControlsAuthAcrossAllContributions'] is True
         and aggregate['allCompletedComparisonRostersReconstructedFromExactRaw'] is True
         and aggregate['completedPourCount'] == 19 and aggregate['wireOwnerCount'] == 49
         and aggregate['completedPourIds'] == aggregate['actualRawPourIds'] == first['actualRawPourIds'] == retry['actualRawPourIds']
         and len(set(completed + last_ids)) == 19 and not set(completed) & set(last_ids)
         and aggregate['identityFailures'] == [] and aggregate['minimumForeignEdgeGapMm'] >= .1016
         and aggregate['requiredForeignViaPourEdgeMm'] == aggregate['requiredForeignWirePourEdgeMm'] == .1016,
         'Exact Root327 full19/234/5623/49 completed coverage and unchanged margins')
    need(aggregate['excludedBoundedPartialReports'] == [dict(report='report_0', pcbCopperPourId='pcb_copper_pour_93',
        state='BOUNDED_PARTIAL', viaChecksExcluded=0, wireChecksExcluded=0)], 'Only bounded partial comparison rows excluded')
    for i, name in enumerate(('RUN325_pour-report.json', 'RUN326_pour-report.json')):
        need(aggregate['inputBindings']['report_' + str(i)]['sha256'] == indexed[name]['sha256'], 'Actual327 contribution hashes')
    for scope in (325, 326, 327):
        receipt = load('RUN' + str(scope) + '_COLLECTED.json'); execution = receipt['execution']
        need(receipt['scope'] == scope and receipt['sourcePinsUnchanged'] is True and receipt['protectedFilesUnchanged'] is True
             and execution['exitCode'] == 0 and execution['cleanupOwnedGroupEmpty'] is True
             and execution['diagnosticStopped'] is False and execution == load('RUN' + str(scope) + '_owned_execution.json'), 'Actual closed literal execution receipt')
        need(execution['policy']['wallSeconds'] == 180 and execution['policy']['rssBytes'] == 2 * 1024**3
             and execution['policy']['sharedBytes'] == 30 * 1024**3, 'Original bounded policies retained')
    return profile, rows, aggregate

def build(args):
    need(not SAVED.exists(), 'Fresh scoped-pour snapshot only')
    base, progress, base_targets, dependency = source313(args); profile, payloads, aggregate = evidence()
    workload = profile['plannedPayloadBytes']
    need(shutil.disk_usage('/tmp').free > 3 * workload + 1024**3
         and int(Path('/sys/fs/cgroup/memory.current').read_text()) + 128 * 1024**2 + 1024**3 < 30 * 1024**3,
         'Bounded staging/compression plus shared30GiB/+1GiB reserve')
    archive = BOARD / ('cloud/artifacts/' + STEM + '.tar.gz'); metadata = archive.with_name(STEM + '.manifest.json')
    need(not archive.exists() and not metadata.exists(), 'New immutable portable increment only')
    extras = [(PROFILE, 'POUR_INCREMENT_PROFILE.json'), (Path(__file__).resolve(), 'PORTABLE_INCREMENT_SOURCE.py')]
    rows = payloads + [dict(restorePath=str(p), savedPath=n, **md(p)) for p, n in extras]
    need(len(rows) == len({r['savedPath'] for r in rows}) == 22
         and not {r['restorePath'] for r in rows} & {r['restorePath'] for r in base_targets}, '22 new targets distinct from220 base')
    SAVED.mkdir(mode=0o700)
    for row in rows:
        target = SAVED / row['savedPath']
        with Path(row['restorePath']).open('rb') as f, target.open('xb') as g:
            shutil.copyfileobj(f, g, 1048576); os.fchmod(g.fileno(), row['mode'])
        exact(target, row)
    scoped = dict(aggregateSha256=AGGREGATE_SHA, savedAggregate='RUN327_coverage-report.json', sourceCoreScope=313,
        actualPours=19, actualVias=234, routedWireSegments=5623, routedWireOwners=49,
        scopedForeignPourMarginPassed=True, minimumForeignEdgeGapMm=aggregate['minimumForeignEdgeGapMm'],
        requiredForeignEdgeGapMm=.1016, sourceReportsPreservedWhole=True, bounded325Partial93ExcludedFromQualification=True,
        completedFirstReportPours=16, completedRetryPours=3, geometryRecomputedByCollector=False, **FALSE)
    dependencies = progress['baseArchiveDependenciesInRestoreOrder'] + [dependency]
    common = dict(scope=SCOPE, frozenCheckpoint=True, updatedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        latestClosedScopeIncluded=327, latestSourceVerifiedCheckpoint=progress['latestSourceVerifiedCheckpoint'],
        latestEditableSourceSavedDirectory=BASE_REL, latestEditableSourceCoreScope=313,
        scopedPourMarginEvidence=scoped, baseArchiveDependency=dependency, baseArchiveDependenciesInRestoreOrder=dependencies,
        model318DependencyIncluded=False, priorSourcePourOrCadQualificationInherited=False, sdkExecutedByCollector=False, **FALSE)
    write(SAVED / 'WORKSPACE_RESTORE_MANIFEST.json', dict(**common, solverSourceRoot=SOLVER_ROOT, files=rows,
        baseDependencyRestoreFiles=base_targets, immutableWorkspaceAssets=[],
        immutableAssetsRestoredByBaseArchives=base['immutableAssetsRestoredByBaseArchives']))
    write(SAVED / 'PROGRESS.json', dict(**common, evidence=rows))
    with (SAVED / 'README.md').open('x') as f:
        os.fchmod(f.fileno(), 0o600)
        f.write('Source313 scoped pour evidence: all19 actual pours/234 vias/5623 routed segments/49 signal owners PASS foreign .1016mm edge margin.\n'
                'Whole bounded325 report is retained:16 completed pours,93 partial with0 checks,98/99 not started.\n'
                'Whole326 retry completes93/98/99; exact327 aggregate excludes only the bounded partial rows.\n'
                'No own-net reentry, reference-wire, PDN island continuity, TI, whole-board, CAD or fabrication qualification.\n'
                'Base is editable Source313 with220 targets, not the separate Model318 branch.\n'
                'Restore209→228→248→257→272-v2→289→Model299→Source313 before this increment.\n'
                'Collection and archive smoke execute stdlib/restoration only; no SDK or geometry helpers.\n')
    index = [dict(path=p.name, **md(p)) for p in sorted(SAVED.iterdir())]
    write(SAVED / 'WORKSPACE_HASH_INDEX.json', dict(scope=SCOPE, files=index, selfExcluded=True, frozenCheckpoint=True))
    members = [dict(path=REL + '/' + p.name, **md(p)) for p in sorted(SAVED.iterdir())]
    need(len(members) == 26 and len(index) == 25, 'Exact26 members/index25')
    temporary = durable = mt = None
    try:
        fd, n = tempfile.mkstemp(prefix='g350-pour327-', suffix='.tar.gz', dir='/tmp'); temporary = Path(n)
        with os.fdopen(fd, 'wb') as output:
            os.fchmod(output.fileno(), 0o600)
            with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=6) as gz:
                with tarfile.open(mode='w|', fileobj=gz, format=tarfile.PAX_FORMAT) as tf:
                    for row in members:
                        p = SAVED / Path(row['path']).name; exact(p, row)
                        info = tarfile.TarInfo(row['path']); info.size = row['bytes']; info.mode = row['mode']
                        info.uid = info.gid = 0; info.uname = info.gname = ''; info.mtime = 0
                        with p.open('rb') as f:
                            tf.addfile(info, f)
                        exact(p, row)
            output.flush(); os.fsync(output.fileno())
        source313(args); evidence()
        for row in rows:
            exact(Path(row['restorePath']), row)
        doc = dict(schemaVersion=1, scope=SCOPE, regularFilesOnly=True, historicalDataOnly=True,
            archive=dict(path=archive.relative_to(BOARD).as_posix(), **md(temporary)), files=members,
            inputDirectories=[REL], extraWorkspaceAssetMembers=[], baseArchivesIncluded=False,
            baseArchiveDependenciesInRestoreOrder=dependencies, workspaceRestoreTargetCount=22, baseRestoreTargetCount=220,
            snapshotPins={REL + '/' + n: sha(SAVED / n) for n in META}, latestSourceVerifiedCheckpoint=progress['latestSourceVerifiedCheckpoint'],
            latestEditableSourceCoreScope=313, solverSourceRoot=SOLVER_ROOT, scopedPourMarginEvidence=scoped, **FALSE)
        fd, n = tempfile.mkstemp(prefix='.' + metadata.name + '.', suffix='.partial', dir=metadata.parent); mt = Path(n)
        with os.fdopen(fd, 'w') as f:
            os.fchmod(f.fileno(), 0o600); json.dump(doc, f, indent=2, allow_nan=False); f.write('\n'); f.flush(); os.fsync(f.fileno())
        need(shutil.disk_usage(archive.parent).free > temporary.stat().st_size + 256 * 1024**2, 'Measured durable archive plus256MiB workspace reserve')
        fd, n = tempfile.mkstemp(prefix='.' + archive.name + '.', suffix='.partial', dir=archive.parent); durable = Path(n)
        with temporary.open('rb') as f, os.fdopen(fd, 'wb') as g:
            os.fchmod(g.fileno(), 0o600); shutil.copyfileobj(f, g, 1048576); g.flush(); os.fsync(g.fileno())
        exact(durable, doc['archive']); need(shutil.disk_usage(archive.parent).free > 256 * 1024**2, 'Durable reserve retained')
        publish(durable, archive); durable = None; publish(mt, metadata); mt = None
        print(json.dumps(dict(archive=str(archive), archiveSha256=sha(archive), manifest=str(metadata), manifestSha256=sha(metadata),
            members=26, localTargets=22, baseTargets=220, sdkExecuted=False, **FALSE)))
    finally:
        for p in (temporary, durable, mt):
            if p is not None and p.exists():
                p.unlink()

def verify(args):
    _, _, base_targets, _ = source313(args); _, payloads, aggregate = evidence()
    archive = BOARD / ('cloud/artifacts/' + STEM + '.tar.gz'); metadata = archive.with_name(STEM + '.manifest.json')
    for p, h in ((archive, args.archive_sha), (metadata, args.manifest_sha)):
        need(h is not None and re.fullmatch('[0-9a-f]{64}', h) and regular(p) and sha(p) == h, 'Explicit actual increment hashes')
    am = read(metadata)
    need(am['scope'] == SCOPE and am['archive']['sha256'] == args.archive_sha and len(am['files']) == 26
         and am['scopedPourMarginEvidence']['aggregateSha256'] == AGGREGATE_SHA, 'Exact26-member scoped pour increment')
    for p, h in ((RESTORER, RESTORER_SHA), (HELPER, HELPER_SHA)):
        need(regular(p) and sha(p) == h, 'Pinned existing restoration helper')
    need(shutil.disk_usage('/tmp').free > 2 * sum(r['bytes'] for r in am['files']) + 1024**3
         and int(Path('/sys/fs/cgroup/memory.current').read_text()) + 128 * 1024**2 + 1024**3 < 30 * 1024**3,
         'Bounded isolated extraction plus shared reserve')
    prior_umask = os.umask(0o077); owned = Path(tempfile.mkdtemp(prefix='g350-pour327-smoke-', dir='/tmp'))
    dest = owned / 'extracted'; commands = []; started = time.monotonic()
    def run(argv):
        remaining = 165 - (time.monotonic() - started); need(remaining > 0, '165s restoration-only budget')
        result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, timeout=remaining, check=False)
        commands.append(dict(argv=argv, returncode=result.returncode, stdout=result.stdout, stderr=result.stderr))
        need(result.returncode == 0, 'Restoration-only subprocess'); return result.stdout.strip()
    try:
        command = [sys.executable, str(RESTORER), str(metadata), '--destination', str(dest)]
        need(run(command + ['--verify-archive']) == 'Verified 26 evidence members; restored 0', 'Exact archive verification')
        expected = {r['path']: r for r in am['files']}; need(len(expected) == 26, 'Unique26 members')
        seen = set()
        with tarfile.open(archive, 'r|gz') as tf:
            for member in tf:
                name = str(relative(member.name)); need(member.isfile() and name in expected and name not in seen, 'Only exact regular members')
                row = expected[name]
                need(member.size == row['bytes'] and stat.S_IMODE(member.mode) == row['mode']
                     and member.uid == member.gid == 0 and member.uname == member.gname == '' and member.mtime == 0, 'Normalized exact tar headers')
                stream = tf.extractfile(member); need(stream is not None, 'Readable member'); h = hashlib.sha256(); size = 0
                for block in iter(lambda: stream.read(1048576), b''):
                    h.update(block); size += len(block)
                need(size == row['bytes'] and h.hexdigest() == row['sha256'], 'Full member hash'); seen.add(name)
        need(seen == set(expected), 'No omitted member')
        need(run(command) == 'Verified 26 evidence members; restored 26', 'Isolated26 extraction')
        need({p.relative_to(dest).as_posix() for p in dest.rglob('*') if p.is_file()} == set(expected), 'Only exact extracted files')
        for name, row in expected.items():
            exact(dest / relative(name), row)
        for name, h in am['snapshotPins'].items():
            need(sha(dest / relative(name)) == h, 'All extracted metadata pins')
        saved = dest / REL; mf = read(saved / 'WORKSPACE_RESTORE_MANIFEST.json')
        need(len(mf['files']) == 22 and mf['baseDependencyRestoreFiles'] == base_targets and mf['latestEditableSourceCoreScope'] == 313
             and mf['scopedPourMarginEvidence'] == am['scopedPourMarginEvidence'] and mf['currentPourQualified'] is False,
             'Scoped evidence does not rewrite editable Source or qualify the whole pour/PDN graph')
        targets = mf['files'] + base_targets; need(len(targets) == len({r['restorePath'] for r in targets}) == 242, 'All242 actual targets preexist')
        for row in targets:
            exact(Path(row['restorePath']), row)
        link = Path(mf['solverSourceRoot']).parent / 'node_modules'
        need(link.is_symlink() and link.resolve() == (BOARD.parent / 'bus-lanes-solver/node_modules').resolve(), 'Correct preexisting dependency link')
        before = link.lstat(); identity = (before.st_dev, before.st_ino, before.st_mode, before.st_mtime_ns, before.st_ctime_ns, os.readlink(link))
        result = json.loads(run([sys.executable, str(HELPER), '--saved-directory', str(saved), '--restore']))
        need(result['savedFilesVerified'] == 22 and result['restoredFiles'] == 0 and result['mode'] == 'restore'
             and result['routingExecuted'] is False and result['all49Accepted'] is False and result['fabricationReady'] is False,
             'Existing complete restore branch writes zero')
        for row in targets:
            exact(Path(row['restorePath']), row)
        after = link.lstat(); need((after.st_dev, after.st_ino, after.st_mode, after.st_mtime_ns, after.st_ctime_ns, os.readlink(link)) == identity, 'Dependency link unchanged')
        source313(args); evidence()
        need(sha(archive) == args.archive_sha and sha(metadata) == args.manifest_sha
             and sha(RESTORER) == RESTORER_SHA and sha(HELPER) == HELPER_SHA, 'All archive/helper inputs unchanged')
        shutil.rmtree(dest)
        write(owned / 'REPORT.json', dict(scope='SOURCE313_POUR327_PORTABLE26_AND242_TARGET_ZERO_WRITE_SMOKE_NOT_BOARD_QUALIFICATION',
            passed=True, commands=commands, archiveSha256=args.archive_sha, manifestSha256=args.manifest_sha,
            normalizedHeadersVerified=True, all26MemberHashesBytesModesVerified=True, all242ActualTargetsUnchanged=True,
            isolatedPayloadRemoved=True, restoredWorkspaceFiles=0, scopedPourMarginAggregateSha256=AGGREGATE_SHA,
            sdkExecuted=False, geometryRecomputed=False, **FALSE))
        print(json.dumps(dict(report=str(owned / 'REPORT.json'), reportSha256=sha(owned / 'REPORT.json'), passed=True, sdkExecuted=False)))
    except BaseException as error:
        write(owned / 'FAILURE.json', dict(passed=False, error=str(error), commands=commands, isolatedPayloadPreserved=dest.exists(), **FALSE))
        raise
    finally:
        os.umask(prior_umask)

def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('mode', choices=('build', 'verify'))
    parser.add_argument('--source313-archive-sha', required=True); parser.add_argument('--source313-manifest-sha', required=True)
    parser.add_argument('--archive-sha'); parser.add_argument('--manifest-sha'); args = parser.parse_args()
    (build if args.mode == 'build' else verify)(args)

if __name__ == '__main__':
    main()
