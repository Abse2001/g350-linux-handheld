"""UNEXECUTED SOURCE: strict original Core hardware/logic plus known new cuts."""
from pathlib import Path
import collections
import hashlib
import json
import math
import sys
from urllib.parse import urlparse,unquote

ROOT = Path(__file__).resolve().parent
BOARD = Path('/workspace/g350-linux-handheld')
TOLERANCE = 1e-7  # Existing source-forward coordinate/dimension convention.

def require(v, message):
    if not v:
        raise ValueError(message)

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def equivalent(a, b, key='root'):
    if isinstance(a, dict) and isinstance(b, dict):
        require(a.keys() == b.keys(), 'Fields differ: ' + key)
        for k in a:
            equivalent(a[k], b[k], key + '.' + k)
    elif isinstance(a, list) and isinstance(b, list):
        require(len(a) == len(b), 'Inventory differs: ' + key)
        for i, (x, y) in enumerate(zip(a, b)):
            equivalent(x, y, key + ':' + str(i))
    elif type(a) in (int, float) and type(b) in (int, float):
        require(math.isfinite(a) and math.isfinite(b) and abs(a - b) <= TOLERANCE, 'Numeric geometry differs: ' + key)
    else:
        require(a == b and type(a) == type(b), 'Value/type differs: ' + key)

def key(row):
    ident = row['type'] + '_id'
    require(ident in row, 'Original keyed row missing identity: ' + row['type'])
    return row['type'], row[ident]

def main():
    actual_path, expected_sha, output = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
    require(len(sys.argv) == 4 and not output.exists(), 'Fresh exclusive verification output required')
    require(sha(actual_path) == expected_sha, 'Exact fresh actual Core hash required')
    original_path = ROOT / 'inputs/original-core-0e.circuit.json'
    require(sha(original_path) == '0e2ce064e896db1d087474716d2e82b86155dbe28eecf28ce1727e73a466fee1', 'Frozen original Core0e differs')
    old, actual = json.loads(original_path.read_bytes()), json.loads(actual_path.read_bytes())
    proposal = json.loads((ROOT / 'source/joint-owner-proposal.json').read_bytes())
    additions = [r for r in proposal['owners'] if r['status'].startswith('RAW_JOINT')]
    require(len(additions) == 62, 'Exactly62 new terminal loops required')
    original_metadata = [r for r in old if r['type'] == 'source_project_metadata']
    actual_metadata = [r for r in actual if r['type'] == 'source_project_metadata']
    # Direct Core does not promise CLI's generated filesystem hash record.
    require(len(actual_metadata) <= 1, 'Unexpected generated metadata inventory')
    by_key = {key(r): r for r in actual if r['type'] != 'source_project_metadata'}
    require(len(by_key) == len(actual) - len(actual_metadata), 'Duplicated actual row identity')
    added_keys = set(by_key) - {key(r) for r in old if r['type'] != 'source_project_metadata'}
    allowed_additions = {'source_manually_placed_via':62,'source_port':124,'pcb_component':62,'pcb_port':124,'source_trace':62,'pcb_trace':62,'pcb_via':62}
    require(collections.Counter(k[0] for k in added_keys) == collections.Counter(allowed_additions), 'Only declared new owner/alias/stub/via records allowed')
    assets = []
    pours = []
    for before in old:
        if before['type'] == 'source_project_metadata':
            continue
        after = by_key[key(before)]
        if before['type'] == 'pcb_copper_pour':
            original_brep, new_brep = before['brep_shape'], after['brep_shape']
            comparable_old, comparable_new = dict(before), dict(after)
            del comparable_old['brep_shape'];del comparable_new['brep_shape']
            equivalent(comparable_old, comparable_new, 'retained-pour-owner')
            require(original_brep['outer_ring'] == new_brep['outer_ring'], 'Original reference outline must remain exact')
            # Actual selected same-rail via cutouts can overlap. Compare the
            # exact old BREP minus the explicitly declared foreign via circles,
            # rather than guessing one independent ring per new via.
            from shapely.geometry import Polygon
            from shapely.ops import unary_union
            import shapely
            require(shapely.__version__ == '2.1.2', 'Pinned host Shapely required')
            def polygon(brep):
                outer = [(v['x'],v['y']) for v in brep['outer_ring']['vertices']]
                holes = [[(v['x'],v['y']) for v in r['vertices']] for r in brep['inner_rings']]
                shape = Polygon(outer,holes);require(shape.is_valid and not shape.is_empty,'Invalid reference BREP; no repair allowed')
                return shape
            old_shape, new_shape = polygon(original_brep), polygon(new_brep)
            foreign = [r for r in additions if r['via']['source_net_id'] != before['source_net_id']]
            require(len(foreign) == 31, 'Exactly31 new foreign reference vias per retained pour required')
            cuts = [Polygon([(round(r['via']['x']+.3486*math.sin(i*math.pi/16),6),round(r['via']['y']-.3486*math.cos(i*math.pi/16),6)) for i in range(32)]) for r in foreign]
            expected = old_shape.difference(unary_union(cuts))
            require(expected.is_valid and not expected.is_empty,'Declared source cut union invalid')
            # Core BREP clipping rounds vertices to1e-6mm. The explicit Boolean
            # cut model may round intersection coordinates differently. This
            # is only that source serialization bound; native clearances hold.
            require(new_shape.boundary.hausdorff_distance(expected.boundary) <= 1e-6, 'Reference boundary contains a change outside explicit owned cut model')
            require(new_shape.symmetric_difference(expected).area <= 1e-6*(new_shape.length+expected.length), 'Reference copper differs from exact known cut model beyond serialization bound')
            pours.append({'pcb_copper_pour_id':before['pcb_copper_pour_id'],'net':before['source_net_id'],'layer':before['layer'],'newForeignViaCuts':31,'outerRingExact':True,'originalCopperMinusOnlyOwnedAntipads':True,'serializationBoundaryToleranceMm':1e-6})
            continue
        if before['type'] == 'cad_component' and before.get('cad_component_id') == 'cad_component_188':
            a,b=dict(before),dict(after)
            require(a['pcb_component_id']==b['pcb_component_id']=='pcb_component_207','Only known USBLC6 CAD URL resolution is eligible')
            old_root=BOARD/'.cloud-tools/ti-ddr-v12e-ram7-reference-right-actual-source-control-next/source'
            new_root=BOARD/'.cloud-tools/ti-ddr-v10-ca-top-bytes-bottom-prefork-successor-next/source'
            def asset_path(value,base):
                require(isinstance(value,str),'Concrete CAD asset string required')
                if value.startswith('file:'):
                    url=urlparse(value);require(url.scheme=='file' and url.netloc in ('','localhost') and not url.query and not url.fragment,'Only concrete local file asset URI allowed')
                    return Path(unquote(url.path)).resolve()
                require('://' not in value,'Remote or unknown CAD asset scheme refused')
                return (base/value).resolve()
            for field in ['model_obj_url','model_step_url']:
                x=asset_path(a[field],old_root);y=asset_path(b[field],new_root)
                require(x==y and x.is_file() and not x.is_symlink(),'CAD model must resolve to same preserved concrete file')
                assets.append({'field':field,'oldUrl':a[field],'actualUrl':b[field],'resolvedFile':str(x),'sha256':sha(x)})
                b[field]=a[field]
            equivalent(a,b,'preserved-asset-row');continue
        equivalent(before,after,'original.'+':'.join(map(str,key(before))))
    # RAM7's physical two stubs/vias are stronger than numerical parity.
    for kind in ['pcb_trace','pcb_via']:
        rows=[r for r in old if r['type']==kind]
        require(len(rows)==2 and all(by_key[key(r)]==r for r in rows),'RAM7 original physical records must be byte-structure-exact')
    for kind,count in [('source_component',280),('pcb_smtpad',1161),('source_net',98),('source_bus',8)]:
        require(sum(r['type']==kind for r in actual)==count,'Original hardware/logical inventory changed: '+kind)
    old_named_links = sum(r['type']=='source_trace' and len(r.get('connected_source_port_ids',[]))==2 and r['source_trace_id'] not in ('source_trace_932','source_trace_933') for r in old)
    require(old_named_links==119,'Original explicit connection inventory differs')
    report={'scope':'STRICT_FRESH_CORE_ORIGINAL_HARDWARE_LOGIC_PLUS62_DECLARED_REFERENCE_LOOPS','actualCoreSha256':expected_sha,'originalCoreSha256':sha(original_path),'original280Parts1161ContactsHeld':True,'original217LogicalLinksHeldByOriginal119TwoPortTracesAnd98Nets':True,'allOriginalSourcePortsAnd934TraceRecordsHeld':True,'new62TraceRecordsAreAdditionalBranchesNotNewHardwareLinks':True,'ram7CorePhysicalRecordsExact':True,'addedRecordCounts':dict(collections.Counter(k[0] for k in added_keys)),'retainedReferenceCutProofs':pours,'concretePreservedAssetResolutions':assets,'generatedFilesystemMetadataBefore':original_metadata,'generatedFilesystemMetadataAfter':actual_metadata,'noFilesystemMetadataParityClaim':True,'nativeChecksStillRequired':True,'sourceForwardPassed':True,'referenceQualified':False,'accepted49':False,'fabricationReady':False}
    with output.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps({'sourceForwardPassed':True,'original217LogicalLinksHeld':True,'accepted49':False}))

if __name__=='__main__':
    main()
