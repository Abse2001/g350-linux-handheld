// Source declarations only. This module never injects Circuit JSON or assigns fresh IDs.
// Resolve the pinned board React package and its types from this ignored workspace packet.
import { Children, cloneElement, createElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { buildOwnerMoved24Source, registerOwnerMoved24InnerPorts } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-source24-joint-editable-source-stages-sourceonly-next/source24.circuit"
import data from "./source26-proposal.json"
import type { Source26Proposal } from "./source26-types"
const proposal = data as unknown as Source26Proposal
const plan = proposal.source26Delta
const fields = ["pcbPath", "pcbPaths", "pcbPathRelativeTo"] as const
type Props = Record<string, unknown> & { name?: string; children?: ReactNode }
const canonical = (v: unknown): string => Array.isArray(v) ? `[${v.map(canonical).join(",")}]`
  : v && typeof v === "object" ? `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical((v as Record<string, unknown>)[k])}`).join(",")}}` : JSON.stringify(v) ?? "undefined"
const mm = (v: unknown): number => {
  if (typeof v === "number" && Number.isFinite(v)) return v
  if (typeof v === "string" && /^-?\d+(?:\.\d+)?mm$/.test(v)) return Number(v.slice(0, -2))
  throw Error("A finite genuine millimeter value is required")
}
const routeProps = (p: Props) => Object.fromEntries(fields.filter(k => p[k] !== undefined).map(k => [k, p[k]]))
function requireSealedShape() {
  if (proposal.scope !== "UNEXECUTED_EDITABLE_SOURCE26_RESET_AND_SOURCE3_SUCCESSOR_OF_SOURCE24"
    || proposal.parent24Source.sha256 !== "1f2cb464522f81a773a326078acbf0d76d50afb5b757b6783c011d4cbb9f74a9"
    || proposal.sealedSource3Geometry.sha256 !== "413a1fccacc1d59c65064add218f93b3a324965f4e6426ae490e8fb12b3502fd"
    || proposal.sealedResetGeometry.sha256 !== "29c5903c1047c114314cd004fedd57d4e60b120db157743a73cbb68d3ab436f2"
    || plan.sealedResetCandidatePin.sha256 !== proposal.sealedResetGeometry.sha256
    || plan.sealedCandidatePin.sha256 !== proposal.sealedSource3Geometry.sha256
    || plan.movedVia.name !== "V_TI_SIGNAL_source_trace_3_0"
    || canonical(plan.routeChanges.map(r => r.originalSourceTraceId).sort()) !== canonical(["source_trace_10", "source_trace_3"])
    || canonical(plan.newTwoInnerPorts.map(p => `${p.viaName}:${p.layer}`).sort()) !== canonical(["V_TI_SIGNAL_source_trace_3_0:inner1", "V_TI_SIGNAL_source_trace_3_1:inner1"])
    || plan.localSuppressions.length !== 4 || proposal.all49OriginalLogicalTraces.length !== 49
    || proposal.expectedCounts.carrierPaths !== 26 || proposal.expectedCounts.physicalTraces !== 289
    || proposal.expectedCounts.innerLiteralPorts !== 40 || proposal.expectedCounts.expectedSourcePorts !== 1655
    || proposal.expectedCounts.expectedReactElements !== 2272 || proposal.expectedCounts.remainingOriginal49Requests !== 23
    || proposal.primaryCoupledSectionView !== "lower_coupled_U" || proposal.secondaryCoupledSectionView !== "early_reflected_meander"
    || proposal.singleCoupledSectionCoversBoth !== false || proposal.bothActualSharedMeandersMustBeChecked !== true)
    throw Error("The exact reviewed Source24/Reset/Source3 declaration contract is required")
}
/** One existing CPU barrel move, two original logical route declarations,
 * four local path suppressions and two real inner Port children; all else held. */
export function buildOwnerMoved26Source() {
  requireSealedShape()
  const base = buildOwnerMoved24Source()
  const moved = new Set<string>(), changed = new Set<string>(), locals = new Set<string>(), ports = new Set<string>(), logical = new Set<string>()
  let boards = 0
  function fork(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const props: Props = { ...node.props }
    const children = Children.toArray(props.children).map(fork)
    if (props.name === plan.movedVia.name) {
      if (node.type !== "via" || mm(props.pcbX) !== plan.movedVia.before.x || mm(props.pcbY) !== plan.movedVia.before.y
        || props.fromLayer !== "top" || props.toLayer !== "bottom" || mm(props.outerDiameter) !== .4572 || mm(props.holeDiameter) !== .254
        || moved.has(props.name)) throw Error("Exact parent existing full-span CPU owner required")
      props.pcbX = plan.movedVia.after.x; props.pcbY = plan.movedVia.after.y; moved.add(props.name)
    }
    const requested = plan.newTwoInnerPorts.find(p => p.viaName === props.name)
    if (requested) {
      if (node.type !== "via" || children.length !== 0 || props.fromLayer !== "top" || props.toLayer !== "bottom"
        || mm(props.outerDiameter) !== .4572 || mm(props.holeDiameter) !== .254
        || mm(props.pcbX) !== requested.viaXY.x || mm(props.pcbY) !== requested.viaXY.y || ports.has(requested.viaName))
        throw Error("An existing exact full-span owner must receive one genuine Inner1 Port")
      children.push(createElement("port", { name: requested.layer, layer: requested.layer })); ports.add(requested.viaName)
    }
    const change = plan.routeChanges.find(c => c.logicalName === props.name)
    if (change) {
      if (node.type !== "trace" || props.from !== change.fromSelector || props.to !== change.toSelector || props.path !== undefined
        || canonical(routeProps(props)) !== canonical(change.beforeRouteProps) || changed.has(change.originalSourceTraceId))
        throw Error("Exact parent original numeric route declaration required")
      for (const field of fields) props[field] = undefined
      props.pcbPaths = change.after.newPcbPaths; props.pcbPathRelativeTo = change.after.newPcbPathRelativeTo
      changed.add(change.originalSourceTraceId)
    }
    const local = plan.localSuppressions.find(c => c.traceName === props.name)
    if (local) {
      if (node.type !== "trace" || props.from !== local.numericSelector || props.to !== `.${local.viaName} > port.top`
        || mm(props.thickness) !== .1016 || props.pcbPathRelativeTo !== `.${local.viaName} > port.top`
        || props.pcbPaths !== undefined || canonical(props.pcbPath) !== "[]" || locals.has(local.traceName))
        throw Error("Exact parent Source3/Reset Top local declaration required")
      props.pcbPath = undefined; locals.add(local.traceName)
    }
    const original = proposal.all49OriginalLogicalTraces.find(row => row.name === props.name)
    if (original) {
      if (node.type !== "trace" || props.from !== original.from || props.to !== original.to || logical.has(original.originalSourceTraceId))
        throw Error("Every original49 numeric pad-to-pad logical owner must remain exact")
      logical.add(original.originalSourceTraceId)
    }
    if (node.type === "board") {
      boards++
      if (props.layers !== 4 || props.routeRemaining !== false || (props.pcbX ?? 0) !== 0 || (props.pcbY ?? 0) !== 0 || (props.pcbRotation ?? 0) !== 0)
        throw Error("Existing manual unrotated four-layer board required")
    }
    return cloneElement(node as ReactElement<Props>, props, ...children)
  }
  const element = fork(base.element)
  if (boards !== 1 || moved.size !== 1 || changed.size !== 2 || locals.size !== 4 || ports.size !== 2 || logical.size !== 49)
    throw Error("Exact narrow Source26 declaration delta required")
  return { ...base, element, ownerMoved26Proposal: data, ownerMoved26SourceIntegration: {
    scope: "UNQUALIFIED_SOURCE26_EDITABLE_DECLARATIONS", changedViaNames: [...moved], changedOriginalSourceTraceIds: [...changed],
    changedLocalTraceNames: [...locals], newRealPortParents: [...ports], expectedCounts: proposal.expectedCounts,
    newBarrelsAdded: false, circuitJsonInjectionOrIdAssignment: false, source26ActualCoreQualified: false,
    bothDqs1CoupledViewsRequireFreshOriginalApi: true, singleCoupledSectionCoversBoth: false,
    automaticCoreSrjForManualPairBusForkMustNotBeUsed: true, all49Accepted: false, referenceQualified: false, electricalTimingPassed: false, fabricationReady: false,
  } }
}
type Via = { componentName: string; props: Props; pcb_via_id?: string | null; source_manually_placed_via_id?: string | null }
type Port = { componentName: string; props: Props; parent: unknown; matchedComponents: unknown[]; source_port_id?: string | null; pcb_port_id?: string | null; registerMatch(component: unknown): void; getAvailablePcbLayers(): string[] }
type Circuit = { _hasRenderedAtleastOnce?: boolean; schematicDisabled?: boolean; selectOne(selector: string, options?: { type?: string }): unknown }
/** Public matches only, before first render. Core must allocate fresh IDs. */
export function registerOwnerMoved26InnerPorts(circuitUnknown: unknown) {
  requireSealedShape()
  const circuit = circuitUnknown as Circuit
  if (circuit._hasRenderedAtleastOnce || circuit.schematicDisabled !== true) throw Error("Unrendered actual PCB-only Circuit required")
  const prior = registerOwnerMoved24InnerPorts(circuitUnknown)
  if (prior.registrations.length !== 38) throw Error("Exactly38 held real parent registrations required")
  const registrations = [...prior.registrations]
  for (const requested of plan.newTwoInnerPorts) {
    const via = circuit.selectOne(`.${requested.viaName}`) as Via | null
    const port = circuit.selectOne(`.${requested.viaName} > port.${requested.layer}`, { type: "port" }) as Port | null
    if (!via || via.componentName !== "Via" || via.props.name !== requested.viaName || via.props.fromLayer !== "top" || via.props.toLayer !== "bottom"
      || mm(via.props.outerDiameter) !== .4572 || mm(via.props.holeDiameter) !== .254
      || mm(via.props.pcbX) !== requested.viaXY.x || mm(via.props.pcbY) !== requested.viaXY.y
      || !port || port.componentName !== "Port" || port.parent !== via || port.props.name !== requested.layer || port.props.layer !== requested.layer
      || port.source_port_id || port.pcb_port_id || via.pcb_via_id || via.source_manually_placed_via_id
      || port.getAvailablePcbLayers().join(",") !== requested.layer || port.matchedComponents.some(owner => owner !== via))
      throw Error("One genuine unrendered Inner1 Port and its exact existing full-span Via required")
    if (!port.matchedComponents.includes(via)) port.registerMatch(via)
    if (port.matchedComponents.length !== 1 || port.matchedComponents[0] !== via) throw Error("Exact public owner registration required")
    registrations.push({ viaName: requested.viaName, layer: requested.layer, xy: requested.viaXY, numericSelector: requested.numericSelector })
  }
  if (registrations.length !== 40 || new Set(registrations.map(row => `${row.viaName}:${row.layer}`)).size !== 40)
    throw Error("Exactly40 unique real inner registrations required")
  return { registrations, extraPhysicalViaFromPortRegistration: false, coreRendered: false, nativeExecuted: false }
}
export default () => buildOwnerMoved26Source().element
