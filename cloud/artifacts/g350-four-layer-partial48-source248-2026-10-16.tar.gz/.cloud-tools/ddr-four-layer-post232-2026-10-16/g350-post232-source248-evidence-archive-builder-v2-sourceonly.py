#!/usr/bin/env python3
"""Stream a pinned, immutable partial-routing evidence archive; no SDK execution.

There is deliberately no default build action. The caller must pass --build and
the hashes of the final saved index, restore manifest, and progress document.
Only the separate post232 evidence directory is an eligible archive input.
Source209 and Source228 archives are required prior restoration dependencies;
neither dependency archive nor either older frozen folder is included/modified.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile
import tempfile

SAVED_REL = '.cloud-tools/ddr-four-layer-post232-2026-10-16'
OUTPUT_STEM = 'g350-four-layer-partial48-source248-2026-10-16'
MODEL_SHA = 'cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
FALLBACK_SHA = '71bbec7babdeabda657ba1b2be75d35f5d7210d5a53d55cd2fc2b279ffb0d17b'
SOURCE248_RAW_PATH = '/tmp/g350-cap12-48-core248-raw.json'
SOURCE248_RAW_SHA = 'c5129a2ec734e873c209ab8cdccf2cad1753d177f1c87857ffae0cf7ff12a486'
SOURCE248_CONTROLS_PATH = '/tmp/g350-cap12-48-core-diagnostic-root-20261016-run248/byte0-result.json'
SOURCE248_CONTROLS_SHA = '5fb5a432d5854a8cccf689070d901ed4823a427cb42ec6487d474c50d081d525'
DEPENDENCIES = [
    {'path': 'cloud/artifacts/g350-four-layer-partial46-source209-2026-10-16.tar.gz',
     'sha256': 'c4cfe7d590a67368586ef49a6178dbc6b6519576a654a690d8f5ef91be0b9178', 'bytes': 31488547,
     'manifest': 'cloud/artifacts/g350-four-layer-partial46-source209-2026-10-16.manifest.json',
     'manifestSha256': '09b834bb43d98f55d98e9c87652d28c74ae9230b2c10bfb2f0a1d97d83f96832'},
    {'path': 'cloud/artifacts/g350-four-layer-partial47-source228-2026-10-16.tar.gz',
     'sha256': '4fff876a140edbd45cffdc445bd82d7b45a5abcedc630b8ea5633a4d1d9937f1', 'bytes': 10505776,
     'manifest': 'cloud/artifacts/g350-four-layer-partial47-source228-2026-10-16.manifest.json',
     'manifestSha256': 'cfeff46232c9afdbab49186f3e115c725862fb5a5695f3955ffb9e8dcfc5026e'},
]
FROZEN_FOLDERS = {
    '.cloud-tools/ddr-four-layer-manual-2026-10-16': {
        'WORKSPACE_HASH_INDEX.json': '7d471d7f282e2b50e8a10991a50946b6068d114e4f79d7c0b85ee2d26701e6eb',
        'WORKSPACE_RESTORE_MANIFEST.json': '6937e1bd2512ec77d3c9adc97c45c9d5f8e09d420b613b2ca9151ee683102e3d',
        'PROGRESS.json': '2d255e885f078cef97fc7b698b7a9f71025418fabcd07eca4c64f10d18d6f437'},
    '.cloud-tools/ddr-four-layer-post209-2026-10-16': {
        'WORKSPACE_HASH_INDEX.json': '809a4437af0306c37aa759044131fbaa9939032244284705c31a3910d339a83d',
        'WORKSPACE_RESTORE_MANIFEST.json': 'd8a8ebdc11a3900affe120fdd70c946403c4e26bf9b7b02bd9a1088a98369cef',
        'PROGRESS.json': 'fac4424b0ca0fe1b74fc640687a0567b7b3264267a65da5acfff5eb9091b5ef0'},
}
CHUNK = 1024 * 1024


def drop_cache(fd, offset=0, length=0):
    os.posix_fadvise(fd, offset, length, os.POSIX_FADV_DONTNEED)


def digest_file(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        offset = 0
        while chunk := f.read(CHUNK):
            h.update(chunk)
            drop_cache(f.fileno(), offset, len(chunk))
            offset += len(chunk)
        drop_cache(f.fileno())
    return h.hexdigest()


def read_json(path):
    with path.open('rb') as f:
        value = json.load(f)
        drop_cache(f.fileno())
    return value


def safe_relative(value):
    p = PurePosixPath(value)
    assert not p.is_absolute() and p.parts and all(x not in ('', '.', '..') for x in p.parts)
    assert str(p) == value and '\\' not in value, 'Noncanonical archive path'
    return p


def verify_dependencies(root, dependencies):
    assert len(dependencies) == 2, 'Restore209 then228 before this archive'
    for dependency, expected in zip(dependencies, DEPENDENCIES):
        assert all(dependency.get(k) == v for k, v in expected.items())
        assert dependency.get('mustBeRestoredFirst') is True
        for key, hash_key in (('path', 'sha256'), ('manifest', 'manifestSha256')):
            relative = safe_relative(dependency[key])
            p = root / relative
            assert relative.parts[:2] == ('cloud', 'artifacts') and p.resolve().is_relative_to(root)
            assert p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
            if key == 'path':
                assert p.stat().st_size == dependency['bytes']
            assert digest_file(p) == dependency[hash_key], 'Restore dependency changed'


def verify_frozen_folders(root):
    for relative, pins in FROZEN_FOLDERS.items():
        folder = root / relative
        assert folder.is_dir() and not folder.is_symlink() and folder.resolve().is_relative_to(root)
        for name, expected in pins.items():
            assert digest_file(folder / name) == expected, 'Frozen saved metadata changed'
        indexed_rows = read_json(folder / 'WORKSPACE_HASH_INDEX.json')['files']
        assert len(indexed_rows) == (195 if 'post209' in relative else 586)
        for row in indexed_rows:
            p = folder / safe_relative(row['path'])
            assert p.resolve().is_relative_to(folder.resolve()) and p.is_file() and not p.is_symlink()
            assert stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size == row['bytes']
            assert stat.S_IMODE(p.stat().st_mode) == row['mode'] and digest_file(p) == row['sha256'], 'Frozen saved payload changed'


def collect(root, relative):
    base = root / relative
    assert base.is_dir() and not base.is_symlink()
    result = []
    for current, directories, files in os.walk(base, followlinks=False):
        for name in directories:
            p = Path(current) / name
            assert not p.is_symlink() and stat.S_ISDIR(p.lstat().st_mode), str(p)
        for name in files:
            p = Path(current) / name
            s = p.lstat()
            assert stat.S_ISREG(s.st_mode) and not p.is_symlink(), str(p)
            rel = p.relative_to(root).as_posix()
            safe_relative(rel)
            mode = stat.S_IMODE(s.st_mode)
            assert 0 <= mode <= 0o777, 'Special permission bits are unsupported'
            result.append({'path': rel, 'bytes': s.st_size, 'mode': mode,
                           '_source': p, '_identity': (s.st_dev, s.st_ino, s.st_size,
                                                      s.st_mtime_ns, s.st_ctime_ns, s.st_mode)})
    return sorted(result, key=lambda x: x['path'])


class DigestReader:
    def __init__(self, stream):
        self.stream, self.hash, self.count = stream, hashlib.sha256(), 0

    def read(self, size=-1):
        assert 0 <= size <= CHUNK, 'Archive reader requested unbounded payload'
        chunk = self.stream.read(size)
        self.hash.update(chunk)
        drop_cache(self.stream.fileno(), self.count, len(chunk))
        self.count += len(chunk)
        return chunk


class DigestWriter:
    def __init__(self, stream):
        self.stream, self.hash, self.count = stream, hashlib.sha256(), 0

    def write(self, chunk):
        written = self.stream.write(chunk)
        assert written == len(chunk)
        self.hash.update(chunk)
        self.count += written
        return written

    def flush(self):
        self.stream.flush()


def publish_new(temporary, destination):
    # link is an atomic no-replace publication, unlike os.replace.
    os.link(temporary, destination)
    temporary.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--board-root', type=Path, default=Path('/workspace/g350-linux-handheld'))
    parser.add_argument('--archive-relative', required=True)
    parser.add_argument('--manifest-relative', required=True)
    parser.add_argument('--index-sha256', required=True)
    parser.add_argument('--restore-manifest-sha256', required=True)
    parser.add_argument('--progress-sha256', required=True)
    parser.add_argument('--readme-sha256', required=True)
    parser.add_argument('--primary-sha256', required=True)
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    assert args.build, 'No archive created: explicit --build is required'
    assert hasattr(os, 'posix_fadvise') and hasattr(os, 'POSIX_FADV_DONTNEED')
    root = args.board_root.resolve()
    for value in (args.archive_relative, args.manifest_relative):
        p = safe_relative(value)
        assert p.parts[:2] == ('cloud', 'artifacts'), 'Outputs must be in cloud/artifacts'
    archive_path, manifest_path = root / args.archive_relative, root / args.manifest_relative
    assert args.archive_relative == 'cloud/artifacts/' + OUTPUT_STEM + '.tar.gz'
    assert args.manifest_relative == 'cloud/artifacts/' + OUTPUT_STEM + '.manifest.json'
    assert archive_path.suffixes[-2:] == ['.tar', '.gz']
    assert manifest_path.name.endswith('.manifest.json')
    assert not archive_path.exists() and not manifest_path.exists(), 'Immutable output already exists'
    assert archive_path.parent.resolve().is_relative_to(root)
    assert manifest_path.parent.resolve().is_relative_to(root)
    saved = root / SAVED_REL
    pins = {saved / 'WORKSPACE_HASH_INDEX.json': args.index_sha256,
            saved / 'WORKSPACE_RESTORE_MANIFEST.json': args.restore_manifest_sha256,
            saved / 'PROGRESS.json': args.progress_sha256,
            saved / 'README.md': args.readme_sha256}
    for path, expected in pins.items():
        assert len(expected) == 64 and all(c in '0123456789abcdef' for c in expected) and digest_file(path) == expected, 'Final metadata pin mismatch'
    index = read_json(saved / 'WORKSPACE_HASH_INDEX.json')
    restore = read_json(saved / 'WORKSPACE_RESTORE_MANIFEST.json')
    progress = read_json(saved / 'PROGRESS.json')
    base_dependency = restore['baseArchiveDependency']
    if 'baseArchiveDependency' in progress:
        assert progress['baseArchiveDependency'] == base_dependency, 'Base dependency metadata differs'
    dependencies = progress['baseArchiveDependenciesInRestoreOrder']
    assert dependencies == restore['baseArchiveDependenciesInRestoreOrder']
    assert all(base_dependency.get(k) == v for k, v in DEPENDENCIES[1].items())
    assert all(base_dependency.get(k) == dependencies[1].get(k) for k in DEPENDENCIES[1])
    verify_dependencies(root, dependencies)
    verify_frozen_folders(root)
    assert progress['primaryCandidate'] == restore['primaryCandidate']
    assert progress['primaryCandidate']['candidateSha256'] == args.primary_sha256 == FALLBACK_SHA
    primary = saved / safe_relative(progress['primaryCandidate']['savedCandidate'])
    assert primary.resolve().is_relative_to(saved.resolve())
    assert digest_file(primary) == args.primary_sha256, 'Primary candidate mismatch'
    models = [m for m in progress['separateModelMilestones'] if m.get('candidate', {}).get('sha256') == MODEL_SHA]
    assert len(models) == 1 and progress['separateModelMilestones'] == restore['separateModelMilestones']
    model = models[0]
    model_candidate = saved / safe_relative(model['candidate']['savedPath'])
    assert model_candidate.resolve().is_relative_to(saved.resolve()) and digest_file(model_candidate) == MODEL_SHA
    assert model['routedOwners'] == 48 and model['pendingOwnerIds'] == ['source_trace_26']
    assert model['allCriticalApisFreshForModel'] is True and model['criticalCompanionPending'] is False
    assert model['all49Accepted'] is False and model['fabricationReady'] is False
    restored_rows = {r['restorePath']: r for r in restore['files']}
    assert len(restored_rows) == len(restore['files'])
    source248_rows = {}
    for original, expected in ((SOURCE248_RAW_PATH, SOURCE248_RAW_SHA), (SOURCE248_CONTROLS_PATH, SOURCE248_CONTROLS_SHA)):
        row = restored_rows[original]
        assert row['sha256'] == expected
        payload = saved / safe_relative(row['savedPath'])
        assert payload.resolve().is_relative_to(saved.resolve()) and digest_file(payload) == expected
        source248_rows[original] = row
    source248_controls = read_json(saved / source248_rows[SOURCE248_CONTROLS_PATH]['savedPath'])
    assert source248_controls['rawCoreSha256'] == SOURCE248_RAW_SHA and source248_controls['candidateSha256'] == MODEL_SHA
    assert source248_controls['partialCoreControlPassed'] is True and source248_controls['freshCoreControlPassed'] is True
    assert len(source248_controls['checks']) == 35 and all(r['passed'] is True for r in source248_controls['checks'])
    assert source248_controls['expectedConnectedOwners'] == 48 and source248_controls['pendingOwnerIds'] == ['source_trace_26']
    assert progress.get('all49Accepted', False) is False
    assert progress.get('fabricationReady', False) is False
    rows = collect(root, SAVED_REL)
    rows.sort(key=lambda x: x['path'])
    assert len(rows) == len({r['path'] for r in rows})
    indexed = {SAVED_REL + '/' + v['path']: v for v in index['files']}
    assert len(indexed) == len(index['files'])
    actual_saved = {r['path'] for r in rows if r['path'].startswith(SAVED_REL + '/')}
    assert actual_saved == set(indexed) | {SAVED_REL + '/WORKSPACE_HASH_INDEX.json'}, 'Saved file index is incomplete'
    restore_paths = set()
    for row in restore['files']:
        assert row['restorePath'] not in restore_paths
        restore_paths.add(row['restorePath'])
        v = indexed[SAVED_REL + '/' + row['savedPath']]
        assert v['sha256'] == row['sha256'] and v['bytes'] == row['bytes']
        if 'mode' in row:
            assert v['mode'] == row['mode']
    for r in rows:
        if r['path'] in indexed:
            v = indexed[r['path']]
            assert r['bytes'] == v['bytes'] and r['mode'] == v['mode']
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    archive_temp = manifest_temp = None
    try:
        fd, temporary = tempfile.mkstemp(prefix='.' + archive_path.name + '.', suffix='.partial', dir=archive_path.parent)
        archive_temp = Path(temporary)
        with os.fdopen(fd, 'wb') as output:
            os.fchmod(output.fileno(), 0o600)
            writer = DigestWriter(output)
            with gzip.GzipFile(filename='', mode='wb', fileobj=writer, compresslevel=6, mtime=0) as compressed:
                with tarfile.open(mode='w|', fileobj=compressed, format=tarfile.PAX_FORMAT) as archive:
                    for row in rows:
                        source = row['_source']
                        before = source.lstat()
                        identity = (before.st_dev, before.st_ino, before.st_size,
                                    before.st_mtime_ns, before.st_ctime_ns, before.st_mode)
                        assert identity == row['_identity'], 'Evidence changed before streaming'
                        info = tarfile.TarInfo(row['path'])
                        info.size, info.mode, info.mtime = row['bytes'], row['mode'], 0
                        info.uid = info.gid = 0
                        info.uname = info.gname = ''
                        with source.open('rb') as f:
                            reader = DigestReader(f)
                            archive.addfile(info, reader)
                            drop_cache(f.fileno())
                        assert reader.count == row['bytes']
                        row['sha256'] = reader.hash.hexdigest()
                        if row['path'] in indexed:
                            assert row['sha256'] == indexed[row['path']]['sha256'], 'Saved payload hash mismatch'
                        elif source in pins:
                            assert row['sha256'] == pins[source]
                        after = source.lstat()
                        assert (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns,
                                after.st_ctime_ns, after.st_mode) == identity, 'Evidence changed while streaming'
            output.flush()
            os.fsync(output.fileno())
            drop_cache(output.fileno())
        # Reject new/deleted inputs or changed final metadata before publication.
        current = collect(root, SAVED_REL)
        assert {r['path']: r['_identity'] for r in current} == {r['path']: r['_identity'] for r in rows}
        for path, expected in pins.items():
            assert digest_file(path) == expected
        verify_dependencies(root, dependencies)
        verify_frozen_folders(root)
        files = [{k: v for k, v in row.items() if not k.startswith('_')} for row in rows]
        manifest = {'schemaVersion': 1, 'scope': 'PORTABLE_POST232_PARTIAL48_SOURCE248_SOURCE_AND_DATA',
                    'regularFilesOnly': True, 'historicalDataOnly': True,
                    'archive': {'path': args.archive_relative, 'bytes': writer.count,
                                'sha256': writer.hash.hexdigest()},
                    'files': files, 'inputDirectories': [SAVED_REL],
                    'baseArchiveDependency': base_dependency, 'baseArchiveIncluded': False,
                    'baseArchiveDependenciesInRestoreOrder': dependencies, 'baseArchivesIncluded': False,
                    'snapshotPins': {str(p.relative_to(root)): h for p, h in pins.items()},
                    'primaryCandidate': {'path': primary.relative_to(root).as_posix(), 'sha256': args.primary_sha256},
                    'workspaceRestoreTargetCount': len(restore_paths),
                    'latestCollectedScope': progress.get('latestClosedScopeIncluded'),
                    'partialMilestoneMetadata': progress['primaryCandidate'],
                    'separateModelMilestones': progress['separateModelMilestones'],
                    'partial48Candidate': {'path': model_candidate.relative_to(root).as_posix(), 'sha256': MODEL_SHA},
                    'source248ReplayControls': {'raw': source248_rows[SOURCE248_RAW_PATH],
                        'controls': source248_rows[SOURCE248_CONTROLS_PATH], 'passedControlCount': 35,
                        'connectedOwners': 48, 'pendingOwnerIds': ['source_trace_26'],
                        'scope': 'FRESH_EDITABLE_SOURCE_CORE_REPLAY_CONTROLS_NOT_BOARD_ACCEPTANCE'},
                    'tarMetadata': {'uid': 0, 'gid': 0, 'uname': '', 'gname': '', 'mtime': 0},
                    'gzipMtime': 0, 'all49Accepted': False, 'electricalTimingQualified': False,
                    'referenceQualified': False, 'cadQualified': False, 'fabricationReady': False}
        fd, temporary = tempfile.mkstemp(prefix='.' + manifest_path.name + '.', suffix='.partial', dir=manifest_path.parent)
        manifest_temp = Path(temporary)
        with os.fdopen(fd, 'w') as f:
            os.fchmod(f.fileno(), 0o600)
            json.dump(manifest, f, indent=2, allow_nan=False)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        publish_new(archive_temp, archive_path)
        archive_temp = None
        publish_new(manifest_temp, manifest_path)
        manifest_temp = None
        print(json.dumps({'archive': args.archive_relative, 'manifest': args.manifest_relative,
                          'members': len(files), 'restoreTargets': len(restore_paths),
                          'archiveBytes': writer.count, 'archiveSha256': writer.hash.hexdigest(),
                          'sdkExecuted': False, 'all49Accepted': False, 'fabricationReady': False}))
    finally:
        for temporary in (archive_temp, manifest_temp):
            if temporary is not None and temporary.exists():
                temporary.unlink()


if __name__ == '__main__':
    main()
