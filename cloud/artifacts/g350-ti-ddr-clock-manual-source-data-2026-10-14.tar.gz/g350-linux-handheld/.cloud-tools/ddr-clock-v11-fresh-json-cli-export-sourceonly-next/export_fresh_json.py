"""Source-only worker for Root's future separately guarded CLI export.
It never evaluates a Source module, constructs Core, runs KiCad or routes.
"""
import argparse,hashlib,json,os,stat,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BOARD=Path('/workspace/g350-linux-handheld')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def require(v,label):
 if not v:raise ValueError(label)
def binding(r):
 p=Path(r['path']);s=p.lstat();require(stat.S_ISREG(s.st_mode) and not p.is_symlink() and s.st_size==r['bytes'] and stat.S_IMODE(s.st_mode)==r['mode'] and sha(p)==r['sha256'],'Immutable CLI packet/source/runtime file changed')
def exact(r):
 require(sha(r['path'])==r['sha256'],'Exact actual receipt hash changed');return read(r['path'])
def core_from_actual_native(a,m):
 c=exact(a['actualNativeCollection'])
 require(c.get('authorizedByRoot') is True and c.get('toolSessionCollected') is True and c.get('toolWrapperExitCode')==0 and isinstance(c.get('toolSessionId'),int),'Actual successful collected Native Root tool required')
 p=exact({'path':c['postauditPath'],'sha256':c['postauditSha256']});e=p['execution']
 require(c.get('execution')==e and e['exitCode']==0 and e['diagnosticStopped'] is False and e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()) and p['passed'] is True,'Actual Native owned worker did not close successfully')
 require(c.get('packetSha256')==m['nativePreparedManifestSha256'] and p['packetSha256Before']==m['nativePreparedManifestSha256'] and p['packetSha256After']==m['nativePreparedManifestSha256'],'Wrong Native Source packet')
 require(p['sourceAndDependenciesHeld'] is True and p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter'],'Actual complete Source/SDK inventories must be held')
 require(p['sourcePreparedManifestSha256']==m['sourcePreparedManifestSha256'] and p['sourceManifestSha256']==m['sourceManifestSha256'],'Wrong successful Source/Core predecessor')
 result=exact({'path':p['resultPath'],'sha256':p['resultSha256']});require(result['passed'] is True and result['nativeCalls']==1 and result['clockApiCalls']==1 and result['coreCalls']==0 and result['cliCalls']==0 and result['cadCalls']==0,'Actual complete Native/API result required')
 native=exact({'path':result['nativeReportPath'],'sha256':result['nativeReportSha256']});api=exact({'path':result['clockApiReportPath'],'sha256':result['clockApiReportSha256']})
 actual=p['actualFreshCoreArtifacts'];require(actual==a['freshArtifacts'],'Root fresh artifact authority differs from actual qualified Native input')
 require(native['physicalErrors']==0 and native['actualClockNativeFindings']==[] and native['actualCoreSha256']==actual['actualCoreSha256'] and api['allOriginalApiClockChecksPassed'] is True and api['actualCoreSha256']==actual['actualCoreSha256'],'Actual Native/API qualifications do not cover this raw Core')
 require(sha(actual['actualCorePath'])==actual['actualCoreSha256'] and sha(actual['coreControlsPath'])==actual['coreControlsSha256'],'Actual qualified raw/control changed')
 require(Path(actual['actualCorePath'])==Path(m['expectedActualRawCorePath']),'Only fresh guarded41840 successor Core path accepted')
 return actual

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--root-receipt',type=Path,required=True);parser.add_argument('--root-receipt-sha256',required=True);parser.add_argument('--output-directory',type=Path,required=True);args=parser.parse_args()
 require(os.environ.get('G350_CLOCK_FRESH_JSON_CLI_ROOT_GUARDED')=='1','Root must execute through its owned process/resource guard')
 manifest=ROOT/'SOURCE-manifest.json';m=read(manifest);packet=sha(manifest)
 for r in m['files']+m['externalFiles']:binding(r)
 a=exact({'path':str(args.root_receipt),'sha256':args.root_receipt_sha256})
 require(a.get('authorizedByRoot') is True and a.get('scope')==m['scope'] and a.get('sourceManifestSha256')==packet and a.get('actualPreviousScopesCollectedAndEmpty') is True and a.get('noConcurrentRootWorker') is True and a.get('rootFullWorkerReadPassed') is True,'Exact fresh Root CLI authority/read/serial guard required')
 actual=core_from_actual_native(a,m)
 run=args.output_directory.resolve();require(run.is_dir() and not run.is_symlink() and not any(run.iterdir()),'Fresh owned exclusive empty CLI output directory required')
 copied=run/'fresh-core.circuit.json';output=run/'clock-v11.kicad_pcb';log=run/'pinned-cli-export.log';report=run/'cli-export-report.json'
 data=Path(actual['actualCorePath']).read_bytes();core=json.loads(data);require(isinstance(core,list),'Actual Circuit JSON array')
 require(sum(r['type']=='pcb_via' for r in core)==225 and sum(r['type']=='pcb_trace' for r in core)==263,'Fresh complete local copper inventory required')
 with copied.open('xb') as f:f.write(data)
 copied.chmod(0o600);require(sha(copied)==actual['actualCoreSha256'],'Only byte-identical filename suffix copy is allowed')
 argv=[m['bun'],'--smol',m['cliMainPath'],'export',str(copied),'--format','kicad_pcb','--output',str(output),'--disable-parts-engine']
 result={'scope':m['scope'],'sourceManifestSha256':packet,'actualFreshCoreArtifacts':actual,'recognizedCircuitJsonInputPath':str(copied),'recognizedCircuitJsonSha256':sha(copied),'byteIdenticalCopyOnly':True,'originalRawCoreEdited':False,'argv':argv,'cliCalls':1,'CoreCalls':0,'sourceModuleEvaluated':False,'sourcePortHookReplayedByCli':False,'automaticCoreSrjUsed':False,'cadConnectivityExecuted':False,'cadSerializerChecksExecuted':False,'nativeExecutedByThisWorker':False,'exportPassed':False,'accepted49':False,'fabricationReady':False}
 started=time.monotonic()
 try:
  with log.open('xb') as f:p=subprocess.run(argv,cwd=BOARD,stdout=f,stderr=subprocess.STDOUT,check=False)
  result.update(cliExitCode=p.returncode,wallSeconds=time.monotonic()-started,outputPath=str(output),outputSha256=sha(output) if output.is_file() else None,logPath=str(log),logSha256=sha(log))
  require(p.returncode==0 and output.is_file() and output.stat().st_size>0,'Fresh pinned CLI export failed; raw output/log retained')
  require(sha(copied)==actual['actualCoreSha256'] and sha(actual['actualCorePath'])==actual['actualCoreSha256'] and sha(actual['coreControlsPath'])==actual['coreControlsSha256'],'Raw fresh Core/control bytes changed during export')
  for r in m['files']+m['externalFiles']:binding(r)
  require(sha(args.root_receipt)==args.root_receipt_sha256,'Root authority changed')
  result['exportPassed']=True
 except BaseException as e:
  result['failure']=type(e).__name__+': '+str(e)
  with report.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
  raise
 with report.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'exportPassed':True,'output':str(output),'report':str(report),'freshCadConnectivityStillRequired':True,'accepted49':False}));return 0
if __name__=='__main__':raise SystemExit(main())
