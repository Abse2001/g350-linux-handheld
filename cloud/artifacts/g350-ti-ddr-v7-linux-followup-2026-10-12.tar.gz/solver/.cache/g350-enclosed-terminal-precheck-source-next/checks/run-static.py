from pathlib import Path
import hashlib,importlib.util,json,os,sys
ROOT=Path(__file__).resolve().parent.parent
SOURCE=ROOT/'source'
SCOPE=Path('/workspace/bus-lanes-solver/.cache/g350-ti-v5-combined-public-pipeline-v3-memory-next/process_scope.py')
assert hashlib.sha256(SCOPE.read_bytes()).hexdigest()=='7bdc74b15af3ba5b2c306d34a816b48cf8b9d68479b0c06a57f43787d4a4a993'
spec=importlib.util.spec_from_file_location('owned_static_scope',SCOPE);scope=importlib.util.module_from_spec(spec);spec.loader.exec_module(scope)
POLICY={'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
baseline=scope.memory()
def gate(current):
 if current['current']+POLICY['rssBytes']+2*1024**3>=POLICY['sharedBytes']:raise ValueError('Static checks require own1GiB+2GiB margin')
 if any(current['events'][k]!=baseline['events'][k] for k in scope.OOM_KEYS):raise ValueError('New OOM before static check')
paths=json.loads((ROOT/'checks/changed-paths.json').read_bytes())
BUN='/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
checks=[]
commands=[('format-changed-v4',[BUN,'run','./node_modules/@biomejs/biome/bin/biome','format','--write',*paths]),('typecheck-v3',[BUN,'run','typecheck'])]
if '--format-only' in sys.argv:commands=commands[:1]
for name,command in commands:
 execution=scope.run_guarded(command,SOURCE,ROOT/'checks'/name,POLICY,{'TMPDIR':str(ROOT/'checks/tmp'),'PATH':'/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin:'+os.environ.get('PATH','')},before_spawn=gate)
 checks.append({'name':name,'execution':execution})
 if execution['exitCode']!=0 or execution['diagnosticStopped'] or not execution['cleanupOwnedGroupEmpty']:break
(ROOT/'checks/static-checks.json').write_text(json.dumps({'policy':POLICY,'checks':checks,'scope':'format/type only; no solver runtime/constructor/Grid/routing','accepted49':False},indent=2)+'\n')
print(json.dumps({'checks':[(x['name'],x['execution']['exitCode'],x['execution']['stopReasons']) for x in checks]}))
