"""Own stdlib dedicated3W/native self proof. No SDK/Node/Bun/parser execution.
Every local exception and actual before/after failingpair is retained, not waived.
"""
from pathlib import Path
import json,math,copy,hashlib,collections
AUTHOR='/tmp/g350-actual318-four-body20-23-25-36-exhaustive-new-wire-TI3W4W-proof-v2-sourceonly.py';exec(Path(AUTHOR).read_text().rsplit("\nif __name__=='__main__':",1)[0]);MAIN='/tmp/g350-actual318-four-body20-23-25-36-exhaustive-new-wire-TI3W4W-proof-v2-report.json';MS='3629499aaf79d74c300a77692accaba815eee80e3c7ba0ffc8c5358afa27cfeb';mb=Path(MAIN).read_bytes();assert hashlib.sha256(mb).hexdigest()==MS;M=json.loads(mb);assert M['inputSha256']==S and M['inputReportSha256']=='c4a9e37ab8967b1f1b3c315580fff4c98d01737779f476a45b59c5c9967ebb08';RPTS={z['owner']:z for z in M['changedBodyNativeStyleSelfHeadingOwnFullspanRows']};CL={z['owner']:z for z in M['genericAllFourOwnersPreferredSelfClassifications']};AB={z['owner']:z['after']for z in M['bodyInverses']};assert all(strict(AB[n],newB[n])for n in ids)

def edgekey(a,b):return json.dumps([a,b],separators=(',',':'))
def nonlocal_new_geometry(t,before,run):
 ps=[q for _,q in run];oldkeys={edgekey(a,b)for rr in runs(before)for(_,a),(_,b)in zip(rr,rr[1:])};changed={i for i,(a,b)in enumerate(zip(ps,ps[1:]))if edgekey(a,b)not in oldkeys};cumulative=[0];turning=[0];unsafe=[0]
 for i in range(1,len(ps)-1):
  a=(ps[i]['x']-ps[i-1]['x'],ps[i]['y']-ps[i-1]['y']);b=(ps[i+1]['x']-ps[i]['x'],ps[i+1]['y']-ps[i]['y']);cr=abs(a[0]*b[1]-a[1]*b[0]);angle=abs(math.atan2(a[0]*b[1]-a[1]*b[0],a[0]*b[0]+a[1]*b[1]));radius=math.inf if cr<1e-12 else math.hypot(*a)*math.hypot(*b)*math.dist((ps[i-1]['x'],ps[i-1]['y']),(ps[i+1]['x'],ps[i+1]['y']))/(2*cr);turning.append(turning[-1]+angle);unsafe.append(unsafe[-1]+int(angle>math.pi/8+1e-8 or radius<.3048/2-1e-8))
 sxp=[0];sxn=[0];syp=[0];syn=[0]
 for a,b in zip(ps,ps[1:]):
  dx,dy=b['x']-a['x'],b['y']-a['y'];cumulative.append(cumulative[-1]+math.hypot(dx,dy));sxp.append(sxp[-1]+int(dx>1e-8));sxn.append(sxn[-1]+int(dx< -1e-8));syp.append(syp[-1]+int(dy>1e-8));syn.append(syn[-1]+int(dy< -1e-8))
 newpairs=0;nonlocalpairs=0;localcounts=collections.Counter();minimum=None;local_min=None
 for i in range(len(ps)-1):
  for j in range(i+2,len(ps)-1):
   if i not in changed and j not in changed:continue
   newpairs+=1;sep=sd(ps[i],ps[i+1],ps[j],ps[j+1]);gap=cumulative[j]-cumulative[i+1];intersection=sep<1e-9 and gap>1e-8
   corner=not intersection and gap<=math.pi*.3048+1e-8 and(turning[j]-turning[i]<=math.pi/2+1e-8 or(turning[j]-turning[i]<=math.pi+1e-8 and unsafe[j]==unsafe[i]));monotone=not intersection and not((sxp[j+1]-sxp[i]>0 and sxn[j+1]-sxn[i]>0)or(syp[j+1]-syp[i]>0 and syn[j+1]-syn[i]>0))
   why='contiguous_corner'if corner else'monotone_contiguous_copper'if monotone else'nonlocal_returning_arm'
   row={'runLocalSegments':[i,j],'wholeRouteSegmentStarts':[run[i][0],run[j][0]],'centerDistanceMm':sep,'pathGapMm':gap,'samePureLocalPairAuthority':why,'atLeastOneOrderedEdgeChangedFromActual318':True}
   if corner or monotone:
    localcounts[why]+=1
    if local_min is None or sep<local_min['centerDistanceMm']:local_min=row
   else:
    nonlocalpairs+=1
    if minimum is None or sep<minimum['centerDistanceMm']:minimum=row
 return{'scope':'Allnonadjacentpairswithatleastoneorderededgechanged; localpairauthorityidenticaltopurehelperincludingallcontiguouscornerandmonotonecases; precomputedaxiscountsareequivalenttosignloop','changedRunLocalSegmentIndices':sorted(changed),'changedWholeRouteSegmentStarts':[run[i][0]for i in sorted(changed)],'nonadjacentPairsWithChangedEdge':newpairs,'allowedLocalPairCounts':dict(localcounts),'allowedLocalMinimum':local_min,'nonlocalChangedPairCount':nonlocalpairs,'minimumNonlocalNewGeometryPair':minimum,'minimumNonlocalNewGeometryMeetsPreferred3W':minimum is None or minimum['centerDistanceMm']>=.3048-1e-8}

def classify_failure_four_endpoints(n,rr,classification):
 out=[];before_runs=CL[n]['baselineBeforeRunRows'];afterbody=AB[n];beforebody=B[n]
 for z in classification['preferredSelfFailureRows']:
  matches=z['matchingBeforeFailurePairs'];pts=[]
  if matches:
   mt=matches[0];br=before_runs[mt['beforeRunIndex']];ai,aj=z['segments'];bi,bj=mt['beforeRunLocalSegments'];after_idx=[rr[ai][0],rr[ai+1][0],rr[aj][0],rr[aj+1][0]];before_idx=[br['wholeRouteWireIndices'][bi],br['wholeRouteWireIndices'][bi+1],br['wholeRouteWireIndices'][bj],br['wholeRouteWireIndices'][bj+1]]
   for k,(a,b)in enumerate(zip(after_idx,before_idx)):pts.append({'endpointOrdinal':k,'afterWholeRouteWireIndex':a,'beforeWholeRouteWireIndex':b,'orderedObjectLiteral':strict(afterbody['route'][a],beforebody['route'][b])})
  out.append({**z,'fourEndpointLiteralComparisons':pts,'allFourEndpointsLiteralFromSameBeforeFailurePair':len(pts)==4 and all(p['orderedObjectLiteral']for p in pts)})
 return out

if __name__=='__main__':
 ownerrows=[]
 for n in ids:
  t=AB[n];rrows=[]
  for ri,(rr,z)in enumerate(zip(runs(t),RPTS[n]['runRows'])):
   native=self_math([q for _,q in rr]);strong=self_math([q for _,q in rr],.3048);assert strict(native,z['nativeSelf'])and strict(strong,z['preferred3WSelf']);classrow=CL[n]['afterRunClassificationRows'][ri];failureRows=classify_failure_four_endpoints(n,rr,classrow);assert len(failureRows)==len(strong['failures']);minNew=nonlocal_new_geometry(t,B[n],rr);rrows.append({'runIndex':ri,'layer':rr[0][1]['layer'],'wholeRouteWireIndices':[i for i,_ in rr],'nativeSelf':native,'preferred3WSelf':strong,'allPreferredFailurePairsWithFourEndpointLiteralClassification':failureRows,'preferredFailureCount':len(strong['failures']),'inheritedFailureCount':classrow['retainedFailureCount'],'introducedFailureCount':classrow['introducedFailureCount'],'allowedNativeContiguousCornerAndMonotoneComparisonCount':len(native['allowedCloseLocalCornerPairs']),'allowedPreferredContiguousCornerAndMonotoneComparisonCount':len(strong['allowedCloseLocalCornerPairs']),'allAllowedComparisonsPresentInBothSelfReports':True,'minimumNewNonlocalGeometryAudit':minNew});assert not classrow['introducedFailureCount']and all(v['allFourEndpointsLiteralFromSameBeforeFailurePair']for v in failureRows)and minNew['minimumNonlocalNewGeometryMeetsPreferred3W']
  ownerrows.append({'owner':n,'beforeRunPreferredSelfReportsIncludingAllAllowedComparisons':CL[n]['baselineBeforeRunRows'],'afterRunReports':rrows,'nativeSelfPassedEveryRun':all(z['nativeSelf']['passedPureMath']for z in rrows),'preferredSelfPassedEveryRun':all(z['preferred3WSelf']['passedPureMath']for z in rrows),'inheritedPreferredFailureCount':sum(z['inheritedFailureCount']for z in rrows),'introducedPreferredFailureCount':sum(z['introducedFailureCount']for z in rrows),'zeroIntroducedPreferredSelfFailures':all(z['introducedFailureCount']==0 for z in rrows),'allNewNonlocalGeometryMeetsPreferredSelf':all(z['minimumNewNonlocalGeometryAudit']['minimumNonlocalNewGeometryMeetsPreferred3W']for z in rrows)});print(n,'selfclass',ownerrows[-1]['inheritedPreferredFailureCount'],ownerrows[-1]['introducedPreferredFailureCount'],'nonlocalMin',[(z['layer'],z['minimumNewNonlocalGeometryAudit']['minimumNonlocalNewGeometryPair'])for z in rrows],flush=True)
 cross=[];t=AB['source_trace_25'];rs=runs(t)
 for i,ra in enumerate(rs):
  for j,rb in enumerate(rs[i+1:],i+1):
   if ra[0][1]['layer']!=rb[0][1]['layer']:continue
   pairs=[]
   for ai,((wi,a),(wa,b))in enumerate(zip(ra,ra[1:])):
    for bi,((wj,c),(wb,d))in enumerate(zip(rb,rb[1:])):
     sep=sd(a,b,c,d);pairs.append({'runLocalSegments':[ai,bi],'wholeRouteSegmentStarts':[wi,wj],'centerDistanceMm':sep,'nativeRequiredMm':.2032,'preferredRequiredMm':.3048,'nativePassed':sep>=.2032-1e-8,'preferredPassed':sep>=.3048-1e-8})
   cross.append({'owner':'source_trace_25','runIndices':[i,j],'layer':ra[0][1]['layer'],'allPairRows':pairs,'minimumPair':min(pairs,key=lambda z:z['centerDistanceMm']),'allNativePassed':all(z['nativePassed']for z in pairs),'allPreferredPassed':all(z['preferredPassed']for z in pairs),'allCornersAreCrossRunNonlocalNoLocalExceptionUsed':True})
 assert all(z['allNativePassed']and z['allPreferredPassed']for z in cross)
 R={'scope':'DEDICATED_STRONG_SELF_COMPANION_EXACT318_MAIN_V2; PURE_STDLIB_NOT_ACTUALSDK; allallowedcomparisonsandallfailurepairsretained, nofailurewaiver','mainProofPath':MAIN,'mainProofSha256':MS,'mainProofAuthorPath':AUTHOR,'mainProofAuthorSha256':hashlib.sha256(Path(AUTHOR).read_bytes()).hexdigest(),'inputPath':P,'inputSha256':S,'inputReportPath':M['inputReportPath'],'inputReportSha256':M['inputReportSha256'],'inputReportByteCount':M['inputReportByteCount'],'bodyInverses':M['bodyInverses'],'nativeCenterlineRequirementMm':.2032,'preferredCenterlineRequirementMm':.3048,'selfMathSourcePath':'/tmp/g350-actual253-plus-Byte1-byte0-local-self-math-sourceonly.py','selfMathSourceSha256':hashlib.sha256(Path('/tmp/g350-actual253-plus-Byte1-byte0-local-self-math-sourceonly.py').read_bytes()).hexdigest(),'selfMathFunctionUnchangedFromEarlierProof':True,'allPerOwnerPerRunRows':ownerrows,'source25BottomCrossRunChecks':cross,'allChangedNativeSelfPassed':all(z['nativeSelfPassedEveryRun']for z in ownerrows),'zeroIntroducedPreferredSelfFailuresAllFourOwners':all(z['zeroIntroducedPreferredSelfFailures']for z in ownerrows),'allNewNonlocalPairsMeetPreferredSelf':all(z['allNewNonlocalGeometryMeetsPreferredSelf']for z in ownerrows),'allLocalCornerAndMonotoneComparisonsPreservedInReports':True,'rawPreferredSelfBooleansRemainFalseForInheritedLegacyFailures':True,'legacyFailuresRemainExplicitNotAcceptedAsFullBoardTI':True,'rootActualSdkBooleanAgreementStillRequired':True,'actualSdkExecuted':False,'nativeExecuted':False,'all49Accepted':False,'fullBoardTIQualification':False,'timingPassed':False,'electricalTimingQualified':False,'fabricationReady':False};out='/tmp/g350-actual318-four-body20-23-25-36-preferred-self-companion-v2-report.json';Path(out).write_text(json.dumps(R,indent=2)+'\n');print(out,hashlib.sha256(Path(out).read_bytes()).hexdigest(),'bytes',Path(out).stat().st_size,'crossrunMin',[(z['runIndices'],z['minimumPair']['centerDistanceMm'])for z in cross],flush=True)
