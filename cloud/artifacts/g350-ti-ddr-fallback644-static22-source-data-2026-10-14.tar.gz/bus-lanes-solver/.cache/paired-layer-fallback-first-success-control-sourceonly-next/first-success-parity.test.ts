import { expect, test } from "bun:test"
import { BusLanesSolver as Baseline } from "/workspace/bus-lanes-solver/lib/bus-lanes-solver"
import { BusLanesSolver as Proposed } from "/workspace/bus-lanes-solver/.cache/paired-layer-fallback-sourceonly-next/lib/bus-lanes-solver"
import { makeFixture } from "/workspace/bus-lanes-solver/.cache/paired-layer-fallback-sourceonly-next/fixture"

test("a coupled pair's first successful layer preserves the baseline output", () => {
  const input = makeFixture()
  for (const c of input.connections)
    for (const p of c.pointsToConnect) p.layer = "inner1"
  const before = structuredClone(input)
  const layers = () => new Map([
    ["P", ["inner1", "top"]],
    ["N", ["inner1", "top"]],
  ])
  const options = { denseSearch: true, maxSearchIterations: 20000 }
  const baseline = new Baseline(input, options, layers())
  baseline.solve()
  expect(baseline.solved).toBe(true)
  const proposed = new Proposed(input, options, layers())
  proposed.solve()
  expect(proposed.solved).toBe(true)
  expect(proposed.getOutput()).toEqual(baseline.getOutput())
  expect(proposed.traces).toEqual(baseline.traces)
  expect(input).toEqual(before)
})
