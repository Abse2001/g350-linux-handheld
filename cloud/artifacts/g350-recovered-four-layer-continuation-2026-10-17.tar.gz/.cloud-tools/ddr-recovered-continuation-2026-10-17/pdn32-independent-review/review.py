#!/usr/bin/env python3
"""Independent finite, pure-data review. Does not import or execute the producer."""
import collections
import copy
import hashlib
import json
import math
from pathlib import Path

ROOT = Path('/workspace/g350-linux-handheld/.cloud-tools/recovery-2026-10-17')
PROPOSAL = ROOT / 'pdn32-study/proposal.packet.json'
REPORT = ROOT / 'pdn32-study/report.json'
SCRIPT = ROOT / 'pdn32-study/reconstruct.py'
PINS = {
 str(PROPOSAL): 'a2acf37995e31136ee21ed0216905f1cf2be250b051d7b7032244d7a35622168',
 str(REPORT): '9b328d42a3f3732726cfec11311b2386ef7387fb18c29b1a99abf2e84a178ca8',
 str(SCRIPT): 'a74c2a12e02a6c5b500762d41807ca59b9faa68b6c5868b1fd7d6d4f23b3ddf9',
 '/tmp/g350-four-body-ca18-strong-self-root-20261017-run328/byte0-result.candidate.json': '056cac41c6a654b417f6c088d871b8aab41bdaf1bfd42f570acd9dd42d7a09c8',
 '/tmp/g350-both-bytes-ca18-model328-core333-raw.json': 'fcb39e6bb43d972f8d511671ffe30b40819d53aeaeb48fd05d8017f30667990d',
 '/tmp/g350-both-bytes-ca18-model328-capture-root-20261017-run332/byte0-result.json': 'a164a7b04c44096c8d0f9cdcc33fd09d0d4a2e37047f699aebd38aa527cc4237',
}
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p, h in PINS.items(): assert digest(p) == h, p
packet = json.loads(PROPOSAL.read_text())
model = json.loads(Path(list(PINS)[3]).read_text())
raw = json.loads(Path(list(PINS)[4]).read_text())
capture = json.loads(Path(list(PINS)[5]).read_text())
scene = model['full49FanoutInput']
bytype = collections.defaultdict(dict)
for row in raw:
 key = row.get(row['type'] + '_id')
 if key is not None: assert key not in bytype[row['type']]
 bytype[row['type']][key] = row
traces = bytype['source_trace']
def net(s): return traces[s]['subcircuit_connectivity_map_key']
def port_net(pid):
 p = bytype['pcb_port'][pid]
 return bytype['source_port'][p['source_port_id']].get('subcircuit_connectivity_map_key')
power = bytype['source_net']['source_net_5']['subcircuit_connectivity_map_key']
ground = bytype['source_net']['source_net_0']['subcircuit_connectivity_map_key']
assert bytype['source_net']['source_net_5']['name'] == 'DDR_1V5'
assert bytype['source_net']['source_net_0']['name'] == 'GND'
assert net('source_trace_964') == net('source_trace_1045') == power != ground == net('source_trace_965')
expected = {
 'source_trace_964': ('source_port_701', 'source_port_1226'),
 'source_trace_965': ('source_port_702', 'source_port_1228'),
 'source_trace_1045': ('source_port_82', 'source_port_1225'),
}
for sid, ports in expected.items():
 assert set(traces[sid]['connected_source_port_ids']) == set(ports)
 assert traces[sid]['min_trace_thickness'] == .2
assert bytype['source_component']['source_component_118']['name'] == 'C_DDR_CPU_16'
assert bytype['source_port']['source_port_701']['pin_number'] == 1
assert bytype['source_port']['source_port_702']['pin_number'] == 2
assert bytype['source_port']['source_port_82']['pin_number'] == 83
for v in bytype['pcb_via'].values():
 assert v['outer_diameter'] == .4572 and v['hole_diameter'] == .254
 assert v['layers'] == ['top', 'inner1', 'inner2', 'bottom']
assert bytype['pcb_via']['pcb_via_32']['source_net_id'] == 'source_net_5'

checks = {}
def at(root, path):
 for k in path: root = root[k]
 return root
for inv in packet['sourceInverseNodes']:
 assert at(capture['actualSourceTree'], inv['path']) == inv['before']
 assert inv['before']['props']['name'] == inv['after']['props']['name']
for option, invs in packet['sourceReferenceOptions'].items():
 for inv in invs:
  assert at(capture['actualSourceTree'], inv['path']) == inv['before']
  before, after = inv['before']['props'], inv['after']['props']
  for k in before.keys() | after.keys():
   if k not in ('pcbPath', 'pcbPathRelativeTo'): assert before.get(k) == after.get(k)
  assert after['thickness'] == .2 and after['pcbPathRelativeTo'] == after['to']
  sid = inv['sourceTraceId']
  via = (.8, 16.84) if sid != 'source_trace_965' else (-.8,16.8)
  waypoint = after['pcbPath'][0]
  actual = inv['geometry']['route'][1]
  assert math.dist((via[0]+waypoint['x'],via[1]+waypoint['y']), (actual['x'],actual['y'])) < 1e-12
  assert all(q['width'] == .2 for q in inv['geometry']['route'])
checks['sourcePathsAndLogicalAliasesAuthenticated'] = True
for inv in packet['typedRawInverseRows']: assert raw[inv['rawIndex']] == inv['before']
for inv in packet['obstacleInverses']: assert scene['obstacles'][inv['index']] == inv['before']
for inv in packet['referenceInverses']: assert scene['traces'][inv['index']] == inv['before']
checks['allDeclaredBeforeRowsMatchPinnedSources'] = True
raw_reference_mapping = []
for inv in packet['referenceInverses']:
 old = inv['before']; sid = old['source_trace_id']
 actual = [r for r in raw if r['type']=='pcb_trace' and r.get('source_trace_id')==sid]
 assert len(actual)==1
 actual = actual[0]
 assert old['route'] == actual['route'] and old['trace_length'] == actual['trace_length']
 raw_reference_mapping.append({'sourceTraceId':sid,'modelPhysicalId':old['pcb_trace_id'],
  'actualRawPhysicalId':actual['pcb_trace_id'], 'modelPhysicalIdNamesDifferentActualRawOwner':
  bytype['pcb_trace'][old['pcb_trace_id']]['source_trace_id'] != sid})

# Independently implement closed-segment distance and exact rectangle boundaries.
def xy(p): return (p['x'],p['y'])
def subtract(a,b): return (a[0]-b[0],a[1]-b[1])
def dot(a,b): return a[0]*b[0]+a[1]*b[1]
def cross(a,b): return a[0]*b[1]-a[1]*b[0]
def point_line(p,a,b):
 d=subtract(b,a); dd=dot(d,d)
 t=max(0.,min(1.,dot(subtract(p,a),d)/dd)) if dd else 0.
 return math.dist(p,(a[0]+t*d[0],a[1]+t*d[1]))
def segment_distance(a,b,c,d):
 u=subtract(b,a);v=subtract(d,c);w=subtract(c,a);div=cross(u,v)
 if abs(div)>1e-18 and 0<=cross(w,v)/div<=1 and 0<=cross(w,u)/div<=1: return 0.
 return min(point_line(a,c,d),point_line(b,c,d),point_line(c,a,b),point_line(d,a,b))
def relative(p,o):
 a=-math.radians(o.get('ccwRotationDegrees',0));x,y=subtract(p,xy(o['center']))
 return (x*math.cos(a)-y*math.sin(a),x*math.sin(a)+y*math.cos(a))
def point_box(p,o):
 x,y=relative(p,o)
 return math.hypot(max(0,abs(x)-o['width']/2),max(0,abs(y)-o['height']/2))
def segment_box(a,b,o):
 a,b=relative(a,o),relative(b,o);x=o['width']/2;y=o['height']/2
 if any(abs(p[0])<=x and abs(p[1])<=y for p in (a,b)):return 0.
 corners=[(-x,-y),(x,-y),(x,y),(-x,y)]
 return min(segment_distance(a,b,corners[k],corners[(k+1)%4])for k in range(4))
def segments(t):
 out=[]
 for k,(a,b) in enumerate(zip(t['route'],t['route'][1:])):
  if a['route_type']==b['route_type']=='wire' and a['layer']==b['layer'] and xy(a)!=xy(b):
   out.append({'sid':t['source_trace_id'],'index':k,'layer':a['layer'],'a':xy(a),'b':xy(b),
    'width':max(a['width'],b['width']),'net':net(t['source_trace_id'])})
 return out
def obstacle_net(o):
 keys=set()
 for key in o.get('connectedTo',[]):
  if key in traces: keys.add(net(key))
  if key in bytype['pcb_port']:
   n=port_net(key)
   if n:keys.add(n)
 assert len(keys)<=1
 return next(iter(keys),None)
def line_obstacle(s,o):
 if o.get('shape')=='circle':return point_line(xy(o['center']),s['a'],s['b'])-o['width']/2-s['width']/2
 return segment_box(s['a'],s['b'],o)-s['width']/2
obstacles=copy.deepcopy(scene['obstacles'])
for inv in packet['obstacleInverses']:obstacles[inv['index']]=inv['after']
for o in obstacles:o['_net']=obstacle_net(o)
held=[t for t in scene['traces']if t['source_trace_id']not in expected]
held_segments=[s for t in model['joinedNumericPadTraces']+held for s in segments(t)]
assert len(set(t['source_trace_id']for t in model['joinedNumericPadTraces']))==49
checks['heldJoined49AndFixed260Included']={'joinedOwners':49,'heldFixedBodies':len(held),'segments':len(held_segments)}
option_results={}
contacts=[]
all_nonlocal_same_net_gaps=[]
foreign_findings=[]
for option, invs in packet['sourceReferenceOptions'].items():
 changed=[s for x in invs for s in segments(x['geometry'])]
 minimum=None;comparisons=0
 for s in changed:
  for h in held_segments:
   if s['layer']!=h['layer']:continue
   gap=segment_distance(s['a'],s['b'],h['a'],h['b'])-(s['width']+h['width'])/2
   row={'option':option,'changed':s['sid'],'changedSegment':s['index'],'other':h['sid'],
    'otherSegment':h['index'],'layer':s['layer'],'gap':gap,'kind':'reference_to_held_track'}
   if s['net']==h['net']:
    if gap<.1016-1e-9:all_nonlocal_same_net_gaps.append(row)
    if gap<=1e-9:contacts.append(row)
   else:
    comparisons+=1
    if minimum is None or gap<minimum['gap']:minimum=row
    if gap<.1016-1e-9:foreign_findings.append(row)
  own_ports={pid for pid,row in bytype['pcb_port'].items() if row['source_port_id'] in expected[s['sid']]}
  for o in obstacles:
   if s['layer']not in o['layers']:continue
   gap=line_obstacle(s,o)
   own=bool(own_ports.intersection(o.get('connectedTo',[])))
   row={'option':option,'changed':s['sid'],'changedSegment':s['index'],'other':o['obstacleId'],
    'layer':s['layer'],'gap':gap,'kind':'reference_to_obstacle','genuineTerminal':own}
   if s['net']==o['_net']:
    if not own and gap<.1016-1e-9:all_nonlocal_same_net_gaps.append(row)
    if not own and gap<=1e-9:contacts.append(row)
   else:
    comparisons+=1
    if minimum is None or gap<minimum['gap']:minimum=row
    if gap<.1016-1e-9:foreign_findings.append(row)
 option_results[option]={'independentForeignComparisonsWithoutInlineBarrels':comparisons,'minimum':minimum}

# Review every same-net track/pad comparison suppressed for the moved barrel.
via_center=(.8,16.84);via_radius=.4572/2
for s in held_segments:
 gap=point_line(via_center,s['a'],s['b'])-via_radius-s['width']/2
 row={'changed':'pcb_via_32','other':s['sid'],'segment':s['index'],'layer':s['layer'],
  'gap':gap,'kind':'moved_via_to_held_track'}
 if s['net']==power:
  if gap<.1016-1e-9:all_nonlocal_same_net_gaps.append(row)
  if gap<=1e-9:contacts.append(row)
 elif gap<.1016-1e-9:foreign_findings.append(row)
for o in obstacles:
 if o['obstacleId']=='pcb_via_32':continue
 gap=(math.dist(via_center,xy(o['center']))-via_radius-o['width']/2 if o.get('shape')=='circle'
      else point_box(via_center,o)-via_radius)
 row={'changed':'pcb_via_32','other':o['obstacleId'],'gap':gap,'kind':'moved_via_to_obstacle'}
 if o['_net']==power:
  if gap<.1016-1e-9:all_nonlocal_same_net_gaps.append(row)
  if gap<=1e-9:contacts.append(row)
 elif gap<.1016-1e-9:foreign_findings.append(row)

drill_rows=[]
for v in bytype['pcb_via'].values():
 if v['pcb_via_id']=='pcb_via_32':continue
 gap=math.dist(via_center,xy(v))-(.254+v['hole_diameter'])/2
 drill_rows.append({'other':v['pcb_via_id'],'drillEdgeGap':gap,'required':.254,'margin':gap-.254})
assert len(drill_rows)==235

review={
 'scope':'INDEPENDENT_STATIC_AND_STDLIB_GEOMETRY_REVIEW_PDN32_PACKET_A2ACF379',
 'producerFilesUpdatedDuringInitialRead': {
  'packetUnchanged':True,
  'firstReadScriptSha256':'57ceb0867694deff10c28df5d6bcc632938d07bb09ae6bb66212f5b511168a12',
  'firstReadReportSha256':'9842b0624b3f36bc14e002d99d39ab69e3fa2ec943016672e354310be43800a9',
  'authorExplanation':'Old pour containment field added before freeze request; originals then frozen.',
 },
 'inputPins':PINS,'reviewerSourceSha256':digest(__file__),'checks':checks,
 'actualRawReferenceMapping':raw_reference_mapping,
 'packetMissingExplicitRawReferenceInverses':True,
 'independentChangedReferenceForeignChecks':option_results,
 'sameNetNonlocalClearanceRoster':all_nonlocal_same_net_gaps,
 'sameNetNonlocalPhysicalContacts':contacts,
 'independentForeignFindings':foreign_findings,
 'actual235OtherViaDrillComparison':{'count':len(drill_rows),'minimum':min(drill_rows,key=lambda x:x['margin']),
  'findings':[r for r in drill_rows if r['margin'] < -1e-9]},
 'notCertified':['Producer same-net exclusions are broader than genuine own-terminal exclusions.',
  'Original packet lacks separately bound fresh raw pcb_trace186/187/267 inverses.',
  'Fresh source replay, SDK/native/CAD, regenerated pour margin/continuity and electrical qualification not executed.'],
 'sdkExecuted':False,'sourceExecuted':False,'nativeExecuted':False,'cadExecuted':False,
 'accepted':False,'fabricationReady':False,
}
for p,h in PINS.items():assert digest(p)==h, ('input_changed',p)
target=Path(__file__).with_name('review.json')
target.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'review':str(target),'sha256':digest(target),
 'foreignFindings':len(foreign_findings),'sameNetContacts':len(contacts),
 'sameNetClearanceRows':len(all_nonlocal_same_net_gaps),
 'minimumRawViaDrillMargin':review['actual235OtherViaDrillComparison']['minimum']}))
