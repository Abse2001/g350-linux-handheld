export const sitesExtra = Symbol("sites original export")
export function* negotiateSignalSites(input: any) {
  yield input
  return null
}
