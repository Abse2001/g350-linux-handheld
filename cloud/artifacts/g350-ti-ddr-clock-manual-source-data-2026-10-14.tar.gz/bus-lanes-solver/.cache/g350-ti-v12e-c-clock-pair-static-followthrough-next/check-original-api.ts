import fs from "node:fs"
import crypto from "node:crypto"
import assert from "node:assert/strict"
import { VectorScene, routeCopper } from "../g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/vector-scene"
import { tuningPathIsSelfClear } from "../g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/length-tuning"
import { sharedPairSpacingReports } from "../g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/shared-pair-spacing"
import { exteriorPairSpacingReports } from "../g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/exterior-pair-spacing"
import { pairCouplingReports } from "../g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/pair-coupling"
import { pairLengthReports, busLengthReports, fixedRouteLength } from "../g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/route-lengths"
import { routeAnglesAreConventional } from "../g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/route-angle-validation"
import type { SimpleRouteJson, Trace } from "../g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/types"

const [inputPath, candidatePath, outputPath] = process.argv.slice(2)
assert.ok(inputPath && candidatePath && outputPath, "input, candidate and new output paths required")
assert.equal(fs.existsSync(outputPath), false, "Preserve every previous output")
const inputRaw = fs.readFileSync(inputPath), candidateRaw = fs.readFileSync(candidatePath)
const input: SimpleRouteJson = JSON.parse(inputRaw.toString()), candidate = JSON.parse(candidateRaw.toString())
const names = ["source_trace_33", "source_trace_34"]
assert.equal(input.connections.length, 26)
assert.equal(input.obstacles.length, 1298)
assert.equal(input.traces!.length, 261)
assert.equal(input.layerCount, 4)
const pair = input.differentialPairs!.find(p => JSON.stringify(p.connectionNames) === JSON.stringify(names))!
assert.ok(pair); assert.equal(pair.lengthTolerance, .127); assert.equal(pair.traceGap, .12)
const ca = input.buses!.find(b => b.busId === "DDR_COMMAND_CLOCK")!
assert.ok(ca); assert.equal(ca.minLength, 20.95); assert.equal(ca.maxLength, 23.49)
assert.equal(ca.maxLengthSkew, .635)
assert.equal(candidate.scope, "fully-offset-common-clock-pair-static-v11")
assert.equal(candidate.accepted49, false); assert.equal(candidate.fabricationReady, false)
assert.equal(candidate.capturedSourceSha256, "6bca749985625ab2fc0de67563aa4031e7527f7951b35b4725f1bb5b33eeb0c8")
assert.equal(candidate.package101CoreSha256, "ed33a0a335b1fbf0da9adcdeacaa954b655c3c4964c600efb6ef3c72aef4040e")
const traces: Trace[] = names.map(name => ({
  type: "pcb_trace", pcb_trace_id: `manual_clock_pair_v8_${name}`,
  source_trace_id: name, connection_name: name,
  route: candidate[name].path.map((p: { x: number, y: number }) => ({
    route_type: "wire", x: p.x, y: p.y, layer: "inner1", width: .1016,
  })), coupledSection: candidate.coupledSections[name],
}))
const before = JSON.stringify({ input, candidate, traces })
const continuity = traces.map((trace, index) => {
  const connection = input.connections.find(c => c.name === names[index])!
  assert.ok(connection)
  const begin = trace.route[0], end = trace.route.at(-1)!
  assert.ok(Math.hypot(begin.x - connection.pointsToConnect[0].x, begin.y - connection.pointsToConnect[0].y) < 1e-12)
  assert.ok(Math.hypot(end.x - connection.pointsToConnect[1].x, end.y - connection.pointsToConnect[1].y) < 1e-12)
  const scene = new VectorScene(input, connection, .1016, routeCopper(traces[1-index]))
  return {
    connectionName: names[index], pathVisible: scene.pathVisible(trace.route),
    segmentsVisible: trace.route.slice(1).map((p, i) => scene.visible(trace.route[i], p)),
    selfClear: tuningPathIsSelfClear(trace.route, .2032),
    conventionalAngles: routeAnglesAreConventional([trace]),
    fixedPlanarLength: fixedRouteLength(input, names[index]),
  }
})
const shared = sharedPairSpacingReports(input, traces)
const exterior = exteriorPairSpacingReports(input, traces)
const coupling = pairCouplingReports(input, traces)
const pairLengths = pairLengthReports(input, traces)
// Qualification view of two completed clocks only; all26 hardware CA requests are unchanged.
const clockWindow = busLengthReports({ ...input, buses: [{ ...ca, connectionNames: names }] }, traces)
const held = before === JSON.stringify({ input, candidate, traces })
const report = {
  scope: "original-c72-vector-self-shared-exterior-coupling-planar-clock-pair-qualification",
  input: { path: inputPath, sha256: crypto.createHash("sha256").update(inputRaw).digest("hex") },
  candidate: { path: candidatePath, sha256: crypto.createHash("sha256").update(candidateRaw).digest("hex") },
  exactMaterialHeld: held, sourceRouteCount: 2, completeHardwareCARequested: 26,
  continuity, shared, exterior, coupling, pairLengths, clockWindow,
  nativeManufacturingCheckerExecuted: false, freshCoreExecuted: false, freshCadExecuted: false,
  originalGridOrPublicSolverExecuted: false, accepted49: false, fabricationReady: false,
  fullCohortTimingPassed: false, electricalDelayModelQualified: false,
  allOriginalApiClockChecksPassed: held && continuity.every(r => r.pathVisible && r.segmentsVisible.every(Boolean) && r.selfClear && r.conventionalAngles)
    && shared.every(r => r.matched) && exterior.every(r => r.matched) && coupling.every(r => r.matched)
    && pairLengths.every(r => r.matched) && clockWindow.every(r => r.aboveMinimumLength && r.withinLengthLimit && r.matched),
}
fs.writeFileSync(outputPath, `${JSON.stringify(report, null, 2)}\n`, { flag: "wx", mode: 0o600 })
assert.equal(report.allOriginalApiClockChecksPassed, true, "Raw diagnostic report persisted before qualification assertion")
console.log(JSON.stringify({ scope: report.scope, allOriginalApiClockChecksPassed: true, accepted49: false, outputPath }))
