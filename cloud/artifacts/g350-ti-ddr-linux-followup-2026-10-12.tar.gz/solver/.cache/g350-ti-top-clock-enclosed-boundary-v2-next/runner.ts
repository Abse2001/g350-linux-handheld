import assert from "node:assert/strict"
import { createHash } from "node:crypto"
import { readFileSync, writeFileSync } from "node:fs"
import { join } from "node:path"
import { mock } from "bun:test"
import { buildOriginalUnreservedJob, fingerprint } from "./recipe"
import { installGridProfile } from "./grid-telemetry"
import {
  makeBoundaryCapture,
  wrapBoundaryConstructor,
} from "./boundary-capture"
import { captureUntilEnclosedBoundary } from "./boundary-control"

assert.deepEqual(process.argv.slice(2), ["--run-one-approved"])
assert.equal(process.env.G350_TI_CLOCK_ENCLOSED_BOUNDARY_APPROVED, "1")
const root = import.meta.dir
const sha = (raw: string | Uint8Array) =>
  createHash("sha256").update(raw).digest("hex")
const packetRaw = readFileSync(join(root, "packet-manifest.json"))
const packet = JSON.parse(packetRaw.toString())
const bound = (name: string) => {
  const raw = readFileSync(join(root, name))
  assert.equal(sha(raw), packet.inputBindings[name].sha256)
  return JSON.parse(raw.toString())
}
const job = buildOriginalUnreservedJob(
  bound("captured-reserved-job-3.json"),
  bound("parent-prefix-result.json"),
  bound("parent-prefix-postflight.json"),
)
const before = fingerprint(job.unreservedArguments)
const parent = bound("parent-telemetry-result.json")
assert.equal(
  bound("parent-telemetry-postflight.json").resultTrustEligible,
  true,
)
assert.equal(parent.unreservedArgumentSha256, before)
assert.equal(parent.status, "ORIGINAL6000_CLOCK_CAP_UNKNOWN")
let bytes = 0
const save = (name: string, value: unknown) => {
  const raw = JSON.stringify(value) + "\n"
  assert.ok(Buffer.byteLength(raw) + bytes <= 4 * 1024 ** 2)
  writeFileSync(join(root, "run", name), raw, { flag: "wx" })
  bytes += Buffer.byteLength(raw)
}
let captureSha256: string | null = null
const capture = makeBoundaryCapture(
  job.input,
  job.pair.connectionNames,
  job.physical,
  (value) => {
    save("first-enclosed-grid-constructor.json", value)
    captureSha256 = sha(
      readFileSync(join(root, "run", "first-enclosed-grid-constructor.json")),
    )
  },
)
const gridPath = new URL("./source/lib/grid-visibility.ts", import.meta.url)
  .pathname
const gridModule = await import("./source/lib/grid-visibility")
const originalExports = { ...gridModule }
const Original = gridModule.GridVisibilitySearch
const stepDescriptor = Object.getOwnPropertyDescriptor(
  Original.prototype,
  "step",
)!
const cancelDescriptor = Object.getOwnPropertyDescriptor(
  Original.prototype,
  "cancel",
)!
let boundaryProxy: ReturnType<typeof wrapBoundaryConstructor> | undefined
const profile = installGridProfile(
  gridModule,
  () => {},
  32,
  (value) => {
    const exported =
      value === Original
        ? Original
        : (boundaryProxy = wrapBoundaryConstructor(
            value,
            capture.observeConstructor,
          )).Constructor
    mock.module(gridPath, () => ({
      ...originalExports,
      GridVisibilitySearch: exported,
    }))
  },
  job.input.connections.filter((c) =>
    job.pair.connectionNames.includes(c.name),
  ),
)
let lifecycle: ReturnType<typeof captureUntilEnclosedBoundary> | undefined
let originalException: string | null = null
let bindingsRestored = false
try {
  const active = await import("./source/lib/grid-visibility")
  assert.notEqual(active.GridVisibilitySearch, Original)
  assert.equal(active.GridVisibilitySearch.prototype, Original.prototype)
  const producer = await import("./source/lib/coupled-pair-routing")
  lifecycle = captureUntilEnclosedBoundary(
    producer,
    job.unreservedArguments,
    capture.attempted,
  )
} catch (error) {
  originalException = String(error).slice(0, 2048)
} finally {
  profile.restore()
  const restored = await import("./source/lib/grid-visibility")
  bindingsRestored =
    restored.GridVisibilitySearch === Original &&
    Object.getOwnPropertyDescriptor(Original.prototype, "step")!.value ===
      stepDescriptor.value &&
    Object.getOwnPropertyDescriptor(Original.prototype, "cancel")!.value ===
      cancelDescriptor.value
}
const telemetry = profile.snapshot()
const status = capture.status()
const producerInputsUnchanged = fingerprint(job.unreservedArguments) === before
const originalBoundaryClosed =
  lifecycle?.diagnosticBoundaryStopped === true &&
  lifecycle.boundedDone &&
  lifecycle.originalReturnCalls === 1 &&
  lifecycle.originalTerminalMethod === "return" &&
  !lifecycle.naturalCompletion
const diagnosticQualified =
  originalException === null &&
  status.succeeded &&
  captureSha256 !== null &&
  originalBoundaryClosed &&
  producerInputsUnchanged &&
  bindingsRestored &&
  telemetry.observationErrors === 0 &&
  boundaryProxy?.observationErrors() === 0 &&
  lifecycle?.originalFactories === 1 &&
  lifecycle.originalNextCalls <= 6001 &&
  lifecycle.chargedYields <= 6000
const result = {
  status: diagnosticQualified
    ? "FIRST_ENCLOSED_GRID_CAPTURED_ORIGINAL_RETURN_BOUNDARY"
    : "BOUNDARY_CAPTURE_UNKNOWN",
  diagnosticQualified,
  packetSha256: sha(packetRaw),
  sourceCommit: packet.sourceRevision,
  libTree: packet.libTree,
  lifecycle: lifecycle ?? null,
  originalException,
  capture: status,
  captureSha256,
  capturedBytesBeforeReport: bytes,
  telemetry,
  boundaryProxyObservationErrors: boundaryProxy?.observationErrors() ?? null,
  originalBoundaryClosed,
  bindingsRestored,
  producerInputsUnchanged,
  originalPhysicalFingerprint: job.originalPhysicalFingerprint,
  unreservedArgumentSha256: before,
  physicalCuRecipeAudited: true,
  allPhysicalFixedHeld: true,
  physicalRecordCount: job.physical.length,
  sourceProvisionalGuidanceRemoved: job.reservations.length,
  originalPerJobYieldBudget: 6000,
  innerGridCapsUnchanged: true,
  enclosedGridConstructorsBeforeBoundary:
    telemetry.stages.enclosed_terminal.constructors,
  enclosedGridStepsBeforeBoundary: telemetry.stages.enclosed_terminal.steps,
  firstSubsequentOriginalYieldThenReturn: originalBoundaryClosed,
  boundaryScope:
    "Capture exact first enclosed constructor data, forward original construction until first subsequent original yield, then original RETURN. Actual enclosed steps are reported. Raw clock Copper suffix is a preliminary finished candidate, not an accepted or naturally returned clock.",
  optionalArgumentsUnchanged:
    "Original enclosed constructor supplied exactly three arguments; soft/penalty/history/grid options remain unsupplied.",
  newInitializerCalls: 0,
  originalOrdinaryFactories: 0,
  nativeCheckerCalls: 0,
  capturedClockAccepted: false,
  publicPipelineExecutedInThisRun: false,
  accepted49: false,
  tiEligibleBoard: false,
  timingReady: false,
  fabricationReady: false,
}
save("result.json", result)
console.log(
  JSON.stringify({
    status: result.status,
    diagnosticQualified,
    captureSha256,
    accepted49: false,
  }),
)
if (!diagnosticQualified) process.exitCode = 2
