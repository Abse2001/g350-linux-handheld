/** Unexecuted source. Root-only direct pinned Core; no CLI/CAD/autorouter. */
import assert from "node:assert/strict"
import {readFileSync,writeFileSync,existsSync} from "node:fs"
import {createHash} from "node:crypto"
import {resolve} from "node:path"
import {buildPackageApproachSource} from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/package-approaches-overlay"
const [output,...extra]=process.argv.slice(2)
assert(output&&extra.length===0&&!existsSync(output));assert.equal(process.versions.bun,"1.3.14")
const BOARD="/workspace/g350-linux-handheld",core=resolve(BOARD,"node_modules/@tscircuit/core/dist/index.js")
const digest=(p:string)=>createHash("sha256").update(readFileSync(p)).digest("hex")
assert.equal(digest(core),"97b8a4eb484630c3ce2bfc2d68588801484d85adf94785d8849a1d91c4404905")
assert.equal(digest(resolve(BOARD,"node_modules/@tscircuit/checks/dist/index.js")),"1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc")
const {Circuit}=await import("/workspace/g350-linux-handheld/node_modules/@tscircuit/core/dist/index.js")
const circuit=new Circuit();circuit.schematicDisabled=true;circuit.pcbRoutingDisabled=true
circuit.add(buildPackageApproachSource().element as any);await circuit.renderUntilSettled()
assert(circuit.pcbRoutingDisabled&&circuit.schematicDisabled)
const json=circuit.getCircuitJson() as Array<Record<string,any>>
for(const [kind,count] of [["pcb_trace",165],["pcb_via",129],["source_component",280],["pcb_smtpad",1161],["source_net",98],["source_bus",8]] as const)assert.equal(json.filter(r=>r.type===kind).length,count,"Exact append-only inventory: "+kind)
assert(!json.some(r=>r.type==="pcb_autorouting_error"))
const raw=JSON.stringify(json,null,2)+"\n";writeFileSync(output,raw,{flag:"wx",mode:0o600})
console.log(JSON.stringify({scope:"ONE_DIRECT_PINNED_CORE_PACKAGE101_ROUTING_DISABLED_RENDER",actualCoreOutputSha256:createHash("sha256").update(raw).digest("hex"),physicalTopPackageBranches:101,retainedPhysicalBottomHsBranches:64,physicalFullThroughVias:129,newCanonicalVias:65,reusedHsSites:7,originalRealParts:280,pcbRoutingDisabled:true,cliInvoked:false,cadExportInvoked:false,all101PhysicalChecksStillRequired:true,referenceQualified:false,accepted49:false,fabricationReady:false}))
