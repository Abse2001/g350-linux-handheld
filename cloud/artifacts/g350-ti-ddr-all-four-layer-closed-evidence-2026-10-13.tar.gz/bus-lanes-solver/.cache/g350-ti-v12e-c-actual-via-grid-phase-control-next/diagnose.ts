import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { createHash } from "node:crypto"
import { GridVisibilitySearch } from "/workspace/bus-lanes-solver/lib/grid-visibility"
import { fixedCopper, VectorScene } from "/workspace/bus-lanes-solver/lib/vector-scene"
import type { SimpleRouteJson, Trace } from "/workspace/bus-lanes-solver/lib/types"
import { validateRoutedCopperDrc } from "../g350-fanout-source-layer-clearance-fix-next/source/lib/validate-routed-copper-drc"
import { pitchAlignedRetryGrid } from "./pitch-aligned-retry-proposal"

const ROOT = import.meta.dir
const sha = (value: string | Uint8Array) => createHash("sha256").update(value).digest("hex")
assert.deepEqual(process.argv.slice(2), ["--run-one-approved"])
assert.equal(process.env.G350_GRID_PHASE_APPROVED, "1")
const manifestRaw = fs.readFileSync(path.join(ROOT, "SOURCE-manifest.json"))
const manifest = JSON.parse(manifestRaw.toString())
const authRaw = fs.readFileSync(process.env.G350_GRID_PHASE_AUTH_PATH!)
assert.equal(sha(authRaw), process.env.G350_GRID_PHASE_AUTH_SHA)
const auth = JSON.parse(authRaw.toString())
assert.equal(auth.authorizedByRoot, true)
assert.equal(auth.scope, manifest.scope)
assert.equal(auth.packetSha256, sha(manifestRaw))
assert.ok(/^[0-9a-f]{32,128}$/.test(auth.approvalToken))
assert.equal(fs.existsSync(path.join(ROOT, "run", "result.json")), false)
const inputRaw = fs.readFileSync(manifest.inputPath)
const jointRaw = fs.readFileSync(manifest.jointGeometryPath)
assert.equal(sha(inputRaw), manifest.inputSha256)
assert.equal(sha(jointRaw), manifest.jointGeometrySha256)
const original = JSON.parse(inputRaw.toString()) as SimpleRouteJson
const joint = JSON.parse(jointRaw.toString()) as { connections: SimpleRouteJson["connections"]; traces: Trace[] }
assert.equal(original.connections.length, 49)
assert.equal(original.obstacles.length, 856)
assert.equal(original.traces?.length, 2)
assert.equal(joint.connections.length, 49)
assert.equal(joint.traces.length, 96)
const physicalVias = joint.traces.flatMap(trace => trace.route.flatMap(point => point.route_type === "via" ? [{ trace, point }] : []))
assert.equal(physicalVias.length, 96)
const getVia = (name: string) => {
  const row = physicalVias.filter(({ trace, point }) => trace.connection_name === name && Math.abs(point.y - 7.4) < 1e-9)
  assert.equal(row.length, 1)
  assert.deepEqual(row[0].point.layers, ["top", "inner1", "inner2", "bottom"])
  assert.equal(row[0].point.via_diameter, .4572)
  assert.equal(row[0].point.via_hole_diameter, .254)
  return row[0].point
}
const left = getVia("source_trace_18"), right = getVia("source_trace_42")
assert.ok(Math.abs(left.x - 1.2) < 1e-9 && Math.abs(right.x - 2) < 1e-9)
const pitch = right.x - left.x
assert.ok(Math.abs(pitch - .8) < 1e-9)
const phase = { x: (left.x + right.x) / 2, y: (left.y + right.y) / 2 }
// This is an explicit diagnostic probe through actual foreign copper, not an
// authored DDR connection. Existing physical geometry is never moved or pruned.
const name = "diagnostic_actual_ram_via_throat"
const connection = { name, pointsToConnect: [{ x: phase.x, y: phase.y - .4, layer: "inner1" }, { x: phase.x, y: phase.y + .4, layer: "inner1" }] }
const input: SimpleRouteJson = { ...original, connections: [...original.connections, connection], traces: [...original.traces!, ...joint.traces] }
const before = JSON.stringify(input)
const width = .1016, clearance = .1016
const scene = new VectorScene(input, connection, width, fixedCopper(input))
assert.ok(Math.abs(scene.margin - .1524) < 1e-12)
const bounds = { minX: 1.5684, maxX: 1.67, minY: 6.9936, maxY: 7.8064 }
const coarseStep = width / 2, fineStep = width / 10
const alignedOptions = { enabled: true, pitch, phase, coarseStep, fineStep, bounds, boardBounds: input.bounds }
const helperBefore = JSON.stringify(alignedOptions)
assert.equal(pitchAlignedRetryGrid({ ...alignedOptions, enabled: undefined }), undefined)
assert.equal(pitchAlignedRetryGrid({ ...alignedOptions, enabled: false }), undefined)
assert.equal(pitchAlignedRetryGrid({ ...alignedOptions, pitch: NaN }), undefined)
assert.equal(pitchAlignedRetryGrid({ ...alignedOptions, pitch: 0 }), undefined)
assert.equal(pitchAlignedRetryGrid({ ...alignedOptions, fineStep: coarseStep }), undefined)
assert.equal(pitchAlignedRetryGrid({ ...alignedOptions, pitch: .009 }), undefined)
assert.equal(pitchAlignedRetryGrid({ ...alignedOptions, boardBounds: bounds }), undefined)
const aligned = pitchAlignedRetryGrid(alignedOptions)
assert.ok(aligned)
assert.ok(Math.abs(aligned.step - .05) < 1e-12)
assert.ok(aligned.bounds.minX <= bounds.minX && aligned.bounds.maxX >= bounds.maxX && aligned.bounds.minY <= bounds.minY && aligned.bounds.maxY >= bounds.maxY)
assert.equal(JSON.stringify(alignedOptions), helperBefore)
const native = (trace?: Trace) => validateRoutedCopperDrc({
  inputSrj: input,
  routedSrj: { ...input, traces: [...input.traces!, ...(trace ? [trace] : [])] },
  clearance,
  allowBlindAndBuriedVias: false,
} as unknown as Parameters<typeof validateRoutedCopperDrc>[0])
const baselineNative = native()
const relevant = (issue: { traceId?: string; otherTraceId?: string; connectionName?: string; otherConnectionName?: string }) => issue.traceId === name || issue.otherTraceId === name || issue.connectionName === name || issue.otherConnectionName === name
assert.equal(baselineNative.issues.some(relevant), false)
const makeTrace = (points: Array<{ x: number; y: number }>): Trace => ({ type: "pcb_trace", pcb_trace_id: name, connection_name: name, route: points.map(point => ({ ...point, route_type: "wire", layer: "inner1", width })) })
// Independent exact native witness establishes the throat is physically open;
// the direct Grid constructor below deliberately tests grid representation.
const witness = makeTrace(connection.pointsToConnect)
assert.equal(scene.pathVisible(connection.pointsToConnect), true)
const witnessNative = native(witness)
const witnessIssues = witnessNative.issues.filter(relevant)
const rows: Array<Record<string, unknown>> = []
for (const [label, grid] of [
  ["original-coarse", { step: coarseStep, bounds }],
  ["unaligned-pitch-step-counterexample", { step: aligned.step, bounds: { ...bounds, minX: 1.5752, maxX: 1.6768 } }],
  ["phase-aligned-intermediate", aligned],
  ["original-fine-fallback", { step: fineStep, bounds }],
] as const) {
  const search = new GridVisibilitySearch(scene, connection.pointsToConnect[0], connection.pointsToConnect[1], [], 0, undefined, { ...grid, checkReachability: true })
  const access = search.getRoutingAccess()
  assert.ok(access.cellCount < 1000)
  let calls = 0
  try {
    while (!search.solved && !search.failed && search.expanded < 500000) { search.step(); calls++ }
    const nativeResult = search.solved ? native(makeTrace(search.result)) : undefined
    const addedProbeIssues = nativeResult?.issues.filter(relevant)
    const baselineIssuesHeld = !nativeResult || JSON.stringify(nativeResult.issues.filter(issue => !relevant(issue))) === JSON.stringify(baselineNative.issues)
    rows.push({ label, grid, cellCount: access.cellCount, solved: search.solved, naturallyFailed: search.failed, expanded: search.expanded, calls, endpointsHeld: search.solved ? search.result[0].x === connection.pointsToConnect[0].x && search.result[0].y === connection.pointsToConnect[0].y && search.result.at(-1)!.x === connection.pointsToConnect[1].x && search.result.at(-1)!.y === connection.pointsToConnect[1].y : null, continuouslyClear: search.solved ? scene.pathVisible(search.result) : null, route: search.solved ? search.result : null, addedProbeIssues: addedProbeIssues ?? null, baselineIssuesHeld, nativeCheckedSegmentCount: nativeResult?.checkedSegmentCount ?? null, nativeCheckedViaCount: nativeResult?.checkedViaCount ?? null })
  } finally { search.cancel() }
  assert.equal(JSON.stringify(input), before)
}
const output = {
  scope: manifest.scope, diagnosticOnly: true, accepted49: false, fabricationReady: false,
  jointGeometryOnlyQualified: true, jointToolSessionCollectionLostPreserved: true,
  inputSha256: sha(inputRaw), jointGeometrySha256: sha(jointRaw),
  actualForeignViaPair: [left, right], derivedPitch: pitch, phase, width, clearance,
  nominalForbiddenRadius: .2286 + scene.margin, nominalThroatWidth: pitch - 2 * (.2286 + scene.margin),
  originalHardwareGeometryHeld: true, sceneInputUnchanged: JSON.stringify(input) === before,
  actualGridControls: rows, helperPureControls: 8,
  baselineNative, witnessNative, witnessProbeIssues: witnessIssues,
  originalExpandedCapPerGridSearch: 500000, fixtureGridCalls: rows.length,
  defaultOff: true, productionIntegrationApplied: false,
  previousCoarseAndFineSearchesUnmodified: true,
  additionalRetryCanIncreaseInternalAttemptsAndPublicSteps: true,
  scopeLimit: "Actual native Grid phase-control fixture on measured foreign RAM vias with all 856 obstacles, two fixed references and 96 local fanouts retained. Probe endpoints are explicit diagnostic points, not hardware ports. Native DRC is fixture-only; existing baseline issues are preserved and only added probe clearance is asserted. No public routing, CPU-to-RAM completion, fabrication or reference-plane acceptance."
}
fs.writeFileSync(path.join(ROOT, "run", "result.json"), JSON.stringify(output, null, 2) + "\n", { flag: "wx" })
assert.deepEqual(witnessIssues, [])
assert.equal(rows.length, 4)
for (const row of rows) {
  const shouldSolve = row.label === "phase-aligned-intermediate" || row.label === "original-fine-fallback"
  assert.equal(row.solved, shouldSolve)
  if (shouldSolve) { assert.equal(row.endpointsHeld, true); assert.equal(row.continuouslyClear, true); assert.deepEqual(row.addedProbeIssues, []); assert.equal(row.baselineIssuesHeld, true) }
  else assert.equal(row.naturallyFailed, true)
}
console.log(JSON.stringify({ diagnosticOnly: true, grids: rows.map(({ label, solved, expanded, cellCount }) => ({ label, solved, expanded, cellCount })), accepted49: false }))
