"""Own pure stdlib independent physical and complete DDR class-spacing review. No SDK."""
exec(open('/tmp/g350-actual286-static-helper-sourceonly.py').read())
P='/tmp/g350-actual318-four-body20-23-25-36-exhaustive-new-wire-TI3W4W-proof-v2-report.json';PH='3629499aaf79d74c300a77692accaba815eee80e3c7ba0ffc8c5358afa27cfeb';assert hashlib.sha256(Path(P).read_bytes()).hexdigest()==PH;r=json.load(open(P));CP=r['inputPath'];CS=r['inputSha256'];assert hashlib.sha256(Path(CP).read_bytes()).hexdigest()==CS;p=json.load(open(CP));f=p['full49FanoutInput'];B={owner(t):t for t in p['carrierTraces']};after={**B};changed={}
for iv in r['bodyInverses']:
 n=iv['owner'];assert json.dumps(iv['before'],separators=(',',':'))==json.dumps(B[n],separators=(',',':'));after[n]=iv['after'];changed[n]=iv['after'];assert all(json.dumps(iv['before']['route'][k],separators=(',',':'))==json.dumps(iv['after']['route'][k],separators=(',',':'))for k in[0,-1])
g=focus(-318,CP,CS);g['objects'][:]=[o for o in g['objects']if o['id']not in{B[n]['pcb_trace_id']for n in changed}]
for t in changed.values():addTrace(g,t)
for o in g['objects']:
 o['ownedBy']=set(o['owner'].split(','));o['role']='material'
 if o['id']in{z['plannedObstacle']['after']['obstacleId']for z in p['cap8PdnInsertions']}:o['isVia']=True;o['holeRadius']=.127
mats=g['mats'];bbox=g['bbox'];sd=g['sd'];pd=g['pd'];srect=g['segmentRect'];prect=g['pointRect'];L=g['L'];ss=Path('/tmp/g350-actual260-ca233-compatibility-sourceonly.py').read_text();exec(ss[ss.index('def length('):ss.index('def selectedScene(')]);sc=Scene(g['objects']);reciprocal=[]
for n,t in after.items():cs=sc.contacts(t);reciprocal.append({'owner':n,'contacts':cs,'passedPure':not cs})
reverse=[]
for t in f['traces']:
 cs=[c for c in sc.contacts(t)if c['otherOwner']in changed];reverse.append({'owner':owner(t),'pcbTraceId':t['pcb_trace_id'],'contactsWithChanged':cs,'passedPure':not cs})
classes={n:b['busId']for b in f['buses']for n in b['connectionNames']};foreign=[];total=0;minimum={}
def segments(t):
 return[(i,a,b)for i,(a,b)in enumerate(zip(t['route'],t['route'][1:]))if a['route_type']==b['route_type']=='wire'and a['layer']==b['layer']]
oldkeysByOwner={n:{json.dumps([u,v],separators=(',',':'))for _,u,v in segments(B[n])}for n in changed}
for n,t in changed.items():
 for i,a,b in segments(t):
  for ft in [*after.values(),*f['traces']]:
   fn=owner(ft)
   if fn==n or fn not in classes:continue
   req=.3048 if classes[fn]==classes[n]else.4064
   for j,c,d in segments(ft):
    if a['layer']!=c['layer']:continue
    dd=sd(a,b,c,d);total+=1;isNew=json.dumps([a,b],separators=(',',':'))not in oldkeysByOwner[n];row={'candidateEdgeNewTo318':isNew,'owner':n,'segment':i,'layer':a['layer'],'foreignOwner':fn,'foreignTraceId':ft['pcb_trace_id'],'foreignSegment':j,'distanceMm':dd,'requiredMm':req,'gapToGuidanceMm':dd-req,'sameClass':classes[fn]==classes[n]};key=n+'/'+a['layer']
    if key not in minimum or dd<minimum[key]['distanceMm']:minimum[key]=row
    if dd<req-1e-8:foreign.append(row)
old20=B['source_trace_20'];new20=after['source_trace_20'];curves=new20.get('curvedSegments',[]);assert len(curves)==72 and all(json.dumps(new20['route'][i-1:i+1],separators=(',',':'))==json.dumps(old20['route'][i-1:i+1],separators=(',',':'))for i in curves);new25=after['source_trace_25'];assert not new25.get('curvedSegments');via=[q for q in new25['route']if q['route_type']=='via'];assert len(via)==2 and all(q['via_diameter']==.4572 and q['via_hole_diameter']==.254 and q['layers']==L for q in via)
def plen(t):return sum(math.dist((a['x'],a['y']),(b['x'],b['y']))for _,a,b in segments(t))
cohorts=[]
for bus in f['buses']:
 vals=[{'owner':n,'wholeMm':plen(after[n])+sum(plen(z)for z in f['traces']if owner(z)==n)}for n in bus['connectionNames']];vv=[z['wholeMm']for z in vals];cohorts.append({'originalRule':bus,'values':vals,'skewMm':max(vv)-min(vv),'minimumPassCount':sum(z['wholeMm']>=bus.get('minLength',0)-1e-7 for z in vals)})
newFailures=[z for z in foreign if z['candidateEdgeNewTo318']];selfProof=[];sself=Path('/tmp/g350-actual253-plus-Byte1-byte0-local-self-math-sourceonly.py').read_text();gbase=g;exec(sself[sself.index('def self_math('):sself.index('gbase=objectsFor(43)')]);
for n,t in changed.items():
 rr=[];runs=[];cur=[]
 for q in t['route']:
  if q['route_type']=='wire':cur.append(q)
  else:runs.append(cur);cur=[]
 if cur:runs.append(cur)
 oldkeys={json.dumps([u,v],separators=(',',':'))for _,u,v in segments(B[n])}
 for ri,run in enumerate(runs):
  native=self_math(run);strong=self_math(run,.3048);introduced=[]
  for fail in strong['failures']:
   i,j=fail['segments'];a,b=run[i:i+2];c,d=run[j:j+2];held=all(json.dumps([u,v],separators=(',',':'))in oldkeys for u,v in[(a,b),(c,d)])
   if not held:introduced.append(fail)
  rr.append({'runIndex':ri,'layer':run[0]['layer'],'nativePassed':native['passedPureMath'],'whole3WPassed':strong['passedPureMath'],'whole3WFailurePairCount':len(strong['failures']),'introduced3WFailurePairs':introduced})
 selfProof.append({'owner':n,'runs':rr})
byOwner={n:sorted({z['foreignOwner']for z in foreign if z['owner']==n})for n in changed};allnative=all(z['passedPure']for z in reciprocal+reverse);R={'scope':'INDEPENDENT_OWN_STDLIB_EXACT318_FOUR_BODY_NATIVE_PHYSICAL_ALL_NEW_DDR_CLASS_3W4W_PASS_HELD_LEGACY_FAILURES_RETAINED_NO_SDK','inputProofPath':P,'inputProofSha256':PH,'candidateSha256':CS,'bodyOwners':list(changed),'other45BodiesAndFoundationHeld':True,'matched37WholeHeldMm':plen(after['source_trace_37']),'all49ReciprocalRows':reciprocal,'all263FixedReverseRows':reverse,'nativeForeignGeometryPassedPure':allnative,'source20RetainedUpperCurveCount':len(curves),'source25NewPhysicalCarrierViaEvents':via,'completeCohorts':cohorts,'guidanceAllDDRWirePairComparisons':total,'minimumForeignPairsByOwnerLayer':list(minimum.values()),'allSubGuidancePairs':foreign,'subGuidancePairCount':len(foreign),'introducedForeignGuidanceFailurePairs':newFailures,'allChangedNewWireForeign3W4WPassed':not newFailures,'independentAllChangedRunSelfRows':selfProof,'allNativeSelfPassed':all(q['nativePassed']for z in selfProof for q in z['runs']),'introducedStrongSelfFailures':sum(len(q['introduced3WFailurePairs'])for z in selfProof for q in z['runs']),'guidanceFailureOwners':byOwner,'wholeNewGeometryTiGuidancePassed':not foreign,'nativeExecuted':False,'all49Accepted':False,'wholeTiRoutingQualified':False,'electricalTimingQualified':False,'fabricationReady':False};O='/tmp/g350-actual318-four-body20-23-25-36-independent-full-peer-v2-report.json';Path(O).write_text(json.dumps(R,indent=2)+'\n');print(O,hashlib.sha256(Path(O).read_bytes()).hexdigest(),'native',allnative,'pairs',len(foreign),'owners',byOwner,'comparisons',total);assert allnative and not newFailures and R['allNativeSelfPassed']and R['introducedStrongSelfFailures']==0
