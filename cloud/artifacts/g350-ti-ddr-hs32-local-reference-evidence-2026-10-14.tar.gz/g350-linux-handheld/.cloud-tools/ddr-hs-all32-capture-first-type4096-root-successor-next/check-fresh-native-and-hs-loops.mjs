// UNEXECUTED SOURCE: future Root-owned fresh Core/native18 + HS local graph.
// This does not prove filled-plane connectivity or DDR interconnect readiness.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {getFullConnectivityMapFromCircuitJson} from 'circuit-json-to-connectivity-map'
import * as checks from '/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js'
import {g350DdrPhysicalChecks,checkG350ViaTrackManufacturingClearance} from '/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v10-ca-top-bytes-bottom-prefork-successor-next/source/scripts/lib/g350-ddr-physical-checks.mjs'

const [input,expectedSourceSha,output,...extra]=process.argv.slice(2)
assert(input&&expectedSourceSha&&output&&extra.length===0&&!fs.existsSync(output))
const sha=raw=>createHash('sha256').update(raw).digest('hex'),raw=fs.readFileSync(input)
assert.equal(sha(raw),expectedSourceSha)
const checkerSha=sha(fs.readFileSync('/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js'))
assert.equal(checkerSha,'1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc')
const proposal=JSON.parse(fs.readFileSync(new URL('./source/joint-owner-proposal.json',import.meta.url),'utf8'))
const circuit=JSON.parse(raw),type=t=>circuit.filter(e=>e.type===t),results={}
for(const name of [...g350DdrPhysicalChecks,'checkPadPadClearance','checkTracesAreContiguous','checkDanglingTraces','checkPcbTracesOutOfBoard','checkPcbCopperOverKeepout','checkPcbComponentOverlap','checkPcbComponentsOutOfBoard'])results[name]=checks[name](circuit)
assert.equal(Object.keys(results).length,17)
const rows=[],ports=type('pcb_port'),sourcePorts=type('source_port'),traces=type('pcb_trace'),vias=type('pcb_via'),sourceTraces=type('source_trace'),conn=getFullConnectivityMapFromCircuitJson(circuit)
assert.equal(proposal.owners.length,64);assert.equal(traces.length,64);assert.equal(vias.length,64)
const near=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y)<1e-8
for(const owner of proposal.owners){
 const component=type('source_component').find(e=>e.name===owner.capacitor);assert(component)
 const sourcePort=sourcePorts.find(p=>p.source_component_id===component.source_component_id&&p.pin_number===owner.numericPin);assert(sourcePort)
 assert.equal(sourcePort.source_port_id,owner.source_port_id)
 const capPort=ports.find(p=>p.source_port_id===sourcePort.source_port_id);assert(capPort&&near(capPort,owner));assert.deepEqual(capPort.layers,['bottom'])
 const net=type('source_net').find(n=>n.name===owner.referenceNet);assert(net)
 assert.equal(net.source_net_id,owner.numericPin===1?'source_net_5':'source_net_0')
 const matches=sourceTraces.filter(t=>t.name===owner.traceName);assert.equal(matches.length,1)
 const st=matches[0];assert(st.connected_source_port_ids.includes(sourcePort.source_port_id));assert(st.connected_source_net_ids.includes(net.source_net_id))
 const physical=traces.filter(t=>t.source_trace_id===st.source_trace_id);assert.equal(physical.length,1)
 const trace=physical[0]
 const expectedVia=owner.via;const candidates=vias.filter(v=>near(v,expectedVia));assert.equal(candidates.length,1)
 const via=candidates[0];assert.equal(via.source_net_id,net.source_net_id)
 assert.equal(via.hole_diameter,.254);assert.equal(via.outer_diameter,.4572);assert.deepEqual(via.layers,['top','inner1','inner2','bottom'])
 assert.equal(via.tented_on_top,true);assert.equal(via.tented_on_bottom,true)
 const capIndex=trace.route.findIndex(p=>p.route_type==='wire'&&p.layer==='bottom'&&near(p,capPort))
 const viaIndex=trace.route.findIndex(p=>p.route_type==='wire'&&p.layer==='bottom'&&near(p,via))
 assert(capIndex>=0&&viaIndex>=0)
 assert(trace.route.every(p=>p.route_type==='wire'&&p.layer==='bottom'&&p.width===.2))
 const expected=owner.status==='RETAIN_EXISTING_RAM7_BYTE_EXACT'?owner.physicalStub.route:owner.candidateBottomStub
 assert.equal(trace.route.length,expected.length)
 const forward=trace.route.every((p,i)=>near(p,expected[i]))
 const reverse=trace.route.every((p,i)=>near(p,expected[expected.length-1-i]))
 assert(forward||reverse,'Exact declared Bottom cap/via centerline must survive Core')
 const ends=[trace.route[0],trace.route[trace.route.length-1]]
 const alias=ports.filter(p=>via.pcb_port_ids.includes(p.pcb_port_id)&&p.layers.includes('bottom'));assert.equal(alias.length,1)
 assert(st.connected_source_port_ids.includes(alias[0].source_port_id))
 const aliasSource=sourcePorts.find(p=>p.source_port_id===alias[0].source_port_id);assert(aliasSource)
 const authoredVia=type('source_manually_placed_via').find(v=>v.source_manually_placed_via_id===aliasSource.source_component_id);assert(authoredVia)
 assert.equal(authoredVia.source_net_id,net.source_net_id)
 assert(conn.areIdsConnected(capPort.pcb_port_id,via.pcb_via_id)&&conn.areIdsConnected(st.source_trace_id,via.pcb_via_id)&&conn.areIdsConnected(net.source_net_id,via.pcb_via_id),'Actual known-rail Circuit JSON graph must bind own cap/stub/via')
 assert(ends.some(p=>p.start_pcb_port_id===capPort.pcb_port_id||p.end_pcb_port_id===capPort.pcb_port_id))
 assert(ends.some(p=>p.start_pcb_port_id===alias[0].pcb_port_id||p.end_pcb_port_id===alias[0].pcb_port_id))
 const length=trace.route.slice(1).reduce((sum,b,i)=>sum+Math.hypot(b.x-trace.route[i].x,b.y-trace.route[i].y),0)
 assert(length<=2.54+1e-8)
 rows.push({capacitor:owner.capacitor,numericPin:owner.numericPin,source_port_id:sourcePort.source_port_id,pcb_port_id:capPort.pcb_port_id,source_trace_id:st.source_trace_id,pcb_trace_id:trace.pcb_trace_id,pcb_via_id:via.pcb_via_id,net:net.name,padToViaBottomCopperExact:true,actualAliasOwnerLinked:true,stubLengthMm:length,filledReferenceConnected:false})
}
assert.equal(new Set(rows.map(r=>r.pcb_via_id)).size,64)
// The historical manufacturing helper resolves via ownership solely through
// pcb_via.pcb_trace_id. Standalone authored reference vias omit that field.
// Supply ONLY the ownership proved above, on a separate geometry-identical
// projection; never annotate the raw source or alter native17's input.
const ownedTraceByVia=new Map(rows.map(r=>[r.pcb_via_id,r.pcb_trace_id]))
const manufacturingProjection=circuit.map(e=>{
 if(e.type!=='pcb_via')return e
 const own=ownedTraceByVia.get(e.pcb_via_id);assert(own)
 assert(e.pcb_trace_id===undefined||e.pcb_trace_id===own,'An existing foreign via owner must never be replaced')
 return {...e,pcb_trace_id:own}
})
manufacturingProjection.forEach((row,i)=>{
 const original=circuit[i],restored={...row}
 if(original.type==='pcb_via'&&original.pcb_trace_id===undefined)delete restored.pcb_trace_id
 assert.equal(JSON.stringify(restored),JSON.stringify(original),'Manufacturing projection must round-trip every original record byte-structure-exact; only proved missing owner metadata may differ')
})
results.checkG350ViaTrackManufacturingClearance=checkG350ViaTrackManufacturingClearance(manufacturingProjection)
const physicalErrors=Object.values(results).flat().length
const report={sourceSha256:sha(raw),proposalSha256:sha(fs.readFileSync(new URL('./source/joint-owner-proposal.json',import.meta.url))),checkerSha256:checkerSha,checkCount:18,counts:Object.fromEntries(Object.entries(results).map(([k,v])=>[k,v.length])),results,physicalErrors,hsTerminalLoops:rows,manufacturingOnlyProvedStandaloneViaTraceOwners:rows.map(r=>({pcb_via_id:r.pcb_via_id,pcb_trace_id:r.pcb_trace_id,source_trace_id:r.source_trace_id})),allManufacturingProjectionGeometryAndNetsHeld:true,rawNative17InputUnmodified:true,scope:'Fresh actual Core64 HS local cap-to-owned-full-through-via graphs plus unchanged native17 and explicit manufacturing guard; no filled-plane or DDR route acceptance',filledReferencesQualified:false,referenceQualified:false,accepted49:false,fabricationReady:false}
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600})
process.exitCode=physicalErrors?1:0
