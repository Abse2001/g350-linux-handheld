Source333:49 editable connected signal routes;35 fresh Core controls PASS.
Resume raw-core.json, core-controls.json, source-plan.json and source-capture.json here.
Candidate328 is in the required Model328 base;20/23/25/36 changed from318, including2 new25 fullspan vias.
Both byte cohorts and all3 pairs pass planar skew; CA18/26 meet20.95mm,8 remain short.
FullCA skew17.6628187566mm FAILS. WholeTI/electrical/default/fabrication remain false.
Fresh334+336 complete all32 native checks:951 unfiltered findings,0 exceptions.
Findings:1 CA skew,70 missing source traces,718 unconnected ports,162 thickness warnings.
Current49 direct logical DDR owners have0 thickness warnings; broader findings are retained.
Fresh335 authenticates236 vias,0 ambiguity/identity/foreign-track findings over5747 physical wire segments.
Fresh339 plus340 retry and341 aggregate pass scoped .1016mm foreign margins for19 pours/236vias/5573 DDR segments.
Whole339 bounded108 comparisons are retained and excluded; fresh340 completed108 supplies qualification.
Reference wires,own-net reentry and freshPDN/reference continuity remain unqualified.
No Source313 pour or Source272 CAD qualification is inherited.
Restore209→228→248→257→272-v2→289→Model299→Source313→Model318→Model328,then Source333.
Only stdlib copying/archiving and restoration checks execute here; no SDK/native/CAD/geometry.
