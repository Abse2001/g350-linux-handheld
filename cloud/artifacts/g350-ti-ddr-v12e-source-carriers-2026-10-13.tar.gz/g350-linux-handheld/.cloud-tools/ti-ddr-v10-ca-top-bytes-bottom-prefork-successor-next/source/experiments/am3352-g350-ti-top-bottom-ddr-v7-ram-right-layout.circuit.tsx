import { Children, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import OriginalV6 from "./am3352-g350-ti-top-bottom-ddr-v6-alternate-layout.circuit"
import translation from "../lib/am3352/placement/g350-ti-top-bottom-ddr-v7-translation.json"
type Props = Record<string, unknown> & { name?: string; children?: ReactNode }
// IsolatedV7: rigidly translate only RAM and its17 local supports +1.2mmX.
// Existing RAM7 reference vias/stubs translate with their owning capacitor.
// All original source logic, CPU, CPU13, layers and other hardware remain.
function translateRamCohort(node: ReactNode): ReactNode {
  if (!isValidElement<Props>(node)) return node
  const props = { ...node.props }
  const move = (translation.parts as Record<string, Record<string, unknown>>)[props.name ?? ""]
  const reference = (translation.references as Record<string, Record<string, unknown>>)[props.name ?? ""]
  if (move) Object.assign(props, move)
  if (reference) Object.assign(props, reference)
  if (node.type === "board") props.routeRemaining = false
  return cloneElement(node as ReactElement<Props>, props, ...Children.toArray(node.props.children).map(translateRamCohort))
}
export default () => translateRamCohort(OriginalV6())
