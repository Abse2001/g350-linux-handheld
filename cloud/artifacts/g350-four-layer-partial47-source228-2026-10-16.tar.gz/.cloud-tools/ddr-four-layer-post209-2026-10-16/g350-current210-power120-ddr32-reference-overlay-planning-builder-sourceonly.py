#!/usr/bin/env python3
"""SOURCE ONLY. Pure JSON builder for one declared reference/DDR dogbone swap.

This does not execute SDK/CAD, modify frozen source, or qualify new geometry.
The one reference trace and one via obstacle are explicit reversible overlays.
"""
import argparse,copy,hashlib,json,math
from pathlib import Path
INPUT=Path('/tmp/g350-ramcycle-d1-d7-root-20261016-run210/byte0-result.candidate.json')
INPUT_SHA='67635f33c309d547adb5e1e925b5c3cd1445a68c7ac3c8a9598ca75f1921b453'
SCREEN=Path('/tmp/g350-current210-power120-ddr32-slot-exchange-screen-report.json')
SCREEN_SHA='4249510c37b0f329304beca16f6fc2051f93b38675b81faeb0ad3a079897aa27'
def require(v,m):
    if not v:raise ValueError(m)
def read(p,pin):
    b=p.read_bytes();require(hashlib.sha256(b).hexdigest()==pin,'Pinned input changed '+str(p));d=json.loads(b);json.dumps(d,allow_nan=False);return d
def owner(t):return t.get('connection_name',t.get('source_trace_id'))
def near(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])<1e-8
def build(parent,s):
    require(s['inputSha256']==INPUT_SHA and s['powerScreen']['allFourLayerGeometryClear'] and s['ddrScreen']['allFourLayerGeometryClear'],'Exact passing pure geometry screen')
    p=copy.deepcopy(parent);old=parent['full49FanoutInput'];b=copy.deepcopy(old);require(len(parent['carrierTraces'])==46 and len(parent['heldCarrierTraces'])==6 and len(parent['ordinaryCarrierTraces'])==40,'Exact current21046 inventory')
    require(len(old['connections'])==49 and len(old['traces'])==263 and len(old['obstacles'])==1298,'Exact49/263/1298')
    rd=s['referenceTraceDelta'];od=s['referenceViaObstacleDelta'];dd=s['ddrWorkingBranchDelta'];cd=s['ddrConnectionDelta'];require(rd['index']<165 and dd['index']>=165,'One real reference and one ordinary working branch')
    require(b['traces'][rd['index']]==rd['before'] and b['obstacles'][od['index']]==od['before'] and b['traces'][dd['index']]==dd['before'] and b['connections'][cd['index']]==cd['before'],'Exact before material')
    require(rd['before']['pcb_trace_id']==rd['after']['pcb_trace_id']=='pcb_trace_185' and owner(rd['before'])==owner(rd['after'])=='source_trace_1015','Power reference identity/net')
    require({k:v for k,v in rd['before'].items() if k!='route'}=={k:v for k,v in rd['after'].items() if k!='route'} and rd['before']['route'][1:]==rd['after']['route'][1:] and {k:v for k,v in rd['before']['route'][0].items() if k not in ['x','y']}=={k:v for k,v in rd['after']['route'][0].items() if k not in ['x','y']},'Only power via-end coordinates change, actual pin55 and .2 width preserved')
    require(all(q['width']==.2 and q['layer']=='top' for q in rd['after']['route']) and rd['after']['route'][-1]['end_pcb_port_id']=='pcb_port_378' and near(rd['after']['route'][-1],{'x':2.4,'y':5.8}),'Genuine unchanged power numeric port378')
    require({k:v for k,v in od['before'].items() if k!='center'}=={k:v for k,v in od['after'].items() if k!='center'} and od['after']['circuitJsonMetadata']['pcb_via_id']=='pcb_via_120' and near(od['before']['center'],{'x':2,'y':6.2}) and near(od['after']['center'],{'x':2,'y':5.4}),'Only declared via120 obstacle position changes')
    require(owner(dd['before'])==owner(dd['after'])=='source_trace_32' and dd['before']['pcb_trace_id']==dd['after']['pcb_trace_id'] and dd['before']['route'][0]==dd['after']['route'][0] and near(dd['after']['route'][0],{'x':1.6,'y':5.8}),'D7 keeps authentic numeric ball/net')
    for a,z in zip(dd['before']['route'],dd['after']['route']):require({k:v for k,v in a.items() if k not in ['x','y']}=={k:v for k,v in z.items() if k not in ['x','y']},'Only working32 RAM coordinates, no barrel/pin identity swap')
    require(cd['before']['name']==cd['after']['name']=='source_trace_32' and cd['before']['pointsToConnect'][0]==cd['after']['pointsToConnect'][0] and near(cd['after']['pointsToConnect'][1],{'x':2,'y':6.2}),'Only canonical D7 RAM handoff moves')
    b['traces'][rd['index']]=copy.deepcopy(rd['after']);b['obstacles'][od['index']]=copy.deepcopy(od['after']);b['traces'][dd['index']]=copy.deepcopy(dd['after']);b['connections'][cd['index']]=copy.deepcopy(cd['after']);require(b==s['plannedFull49FanoutInput'],'Exact reconstructed planned scene')
    require(all(i==rd['index'] or t==b['traces'][i] for i,t in enumerate(old['traces'][:165])),'Other164 reference geometries frozen')
    origin=s['authenticNumericAliasOrigin'];require(origin['sourceTrace']['source_trace_id']=='source_trace_1015' and origin['sourceTrace']['name']=='TI_PKG_U_RAM_PIN55_DDR_1V5' and origin['sourceNetId']=='source_net_5' and origin['numericPowerPortId']=='pcb_port_378','Authentic original power source/pin/net provenance')
    require(origin['rawViaBefore']['hole_diameter']==origin['plannedViaAfter']['hole_diameter']==.254 and origin['rawViaBefore']['outer_diameter']==origin['plannedViaAfter']['outer_diameter']==.4572 and origin['rawViaBefore']['layers']==origin['plannedViaAfter']['layers']==['top','inner1','inner2','bottom'],'Exact via fullspan drill/land physics')
    require({k:v for k,v in origin['rawViaBefore'].items() if k not in ['x','y']}=={k:v for k,v in origin['plannedViaAfter'].items() if k not in ['x','y']},'Reference via identity/net unchanged')
    p['full49FanoutInput']=b;p['scope']='PLANNED_CURRENT210_EXPLICIT_POWER_REFERENCE120_DDR_D7_SLOT_EXCHANGE';p['planningOnly']=True;p['freshSource']=False;p['freshSourceCoreDerived']=False;p['joinedNumericPadTraces']=[];p['joinedNumericPadTracesRequireFreshRebuild']=True
    delta={k:copy.deepcopy(s[k]) for k in ['referenceTraceDelta','referenceViaObstacleDelta','ddrWorkingBranchDelta','ddrConnectionDelta','physicalDrillPlacementOverride','authenticNumericAliasOrigin','physicalBarrelLocationMultisetUnchanged','wholeD7Floors']};delta.update({'parentPacketSha256':INPUT_SHA,'pureScreenSha256':SCREEN_SHA,'other164ReferenceGeometriesUnchanged':True,'all46CarrierObjectsUnchanged':True,'requiresFreshPhysicalAndCriticalProfileQualification':True,'freshSourceCoreDerived':False});p['plannedPowerReferenceSlotExchange']=delta
    p['declaredReferenceViaPlacementOverrides']=copy.deepcopy(s['physicalDrillPlacementOverride']);p.setdefault('releasedWorkingBranchMaterial',[]).append({'owner':'source_trace_32','reason':'DECLARED_POWER_REFERENCE_DDR_DOGBONE_PHYSICAL_SLOT_EXCHANGE','branches':[{'index':dd['index'],'before':copy.deepcopy(dd['before']),'after':copy.deepcopy(dd['after'])}],'connection':copy.deepcopy(cd),'powerReferenceOverlayRequired':True})
    p.setdefault('workingChanges',[]).append({'type':'DECLARED_POWER_REFERENCE185_VIA120_AND_DDR32_SLOT_EXCHANGE','delta':copy.deepcopy(delta)})
    inherited=p.setdefault('inheritedQualificationEvidence',{})
    for k in ['physicalRunReports','newViaReports','finalScenePhysicalReports','criticalValidationViews','joinedNativeGeometryReports','atomicRamFanoutPhysicalReports']:
        if k in p:inherited['beforePowerReferenceExchange_'+k]=p.pop(k)
    p.update({'physicalRunReports':[],'newViaReports':[],'finalScenePhysicalReports':[],'allSavedCarriersCurrentSceneQualified':False,'all49Connected':False,'all49Accepted':False,'wholeMixedC31Supported':False,'matched':False,'timingPassed':False,'electricalTimingQualified':False,'nativeExecuted':False,'cadExecuted':False,'fabricationReady':False})
    require(p['carrierTraces']==parent['carrierTraces'] and p['heldCarrierTraces']==parent['heldCarrierTraces'] and p['ordinaryCarrierTraces']==parent['ordinaryCarrierTraces'],'All46 current carriers preserved bytewise');json.dumps(p,allow_nan=False);return p
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--input',type=Path,default=INPUT);ap.add_argument('--input-sha',default=INPUT_SHA);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();require(a.input_sha==INPUT_SHA and not a.output.exists() and a.output.resolve()!=a.input.resolve(),'Exact current210 input and fresh output');p=build(read(a.input,a.input_sha),read(SCREEN,SCREEN_SHA));a.output.parent.mkdir(parents=True,exist_ok=True)
    with a.output.open('x') as f:json.dump(p,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({'output':str(a.output),'sha256':hashlib.sha256(a.output.read_bytes()).hexdigest(),'planningOnly':True,'connectedCarrierCount':46,'referenceGeometryChangedExplicitly':['pcb_trace_185','pcb_via_120'],'all49Accepted':False,'fabricationReady':False}))
if __name__=='__main__':main()
