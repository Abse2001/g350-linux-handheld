from pathlib import Path
import datetime
import hashlib
import json
import stat

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / "g350-ti-top-clock-stage-telemetry-v3-next"
ACTUAL = ROOT.parent / "g350-ti-top-clock-stage-telemetry-v2-next"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def item(path, relative=False):
    return {"path": str(path.relative_to(ROOT)) if relative else str(path),
            "bytes": path.stat().st_size, "sha256": sha(path),
            "mode": stat.S_IMODE(path.stat().st_mode)}


assert not (ROOT / "run").exists() and not (ROOT / "run").is_symlink()
assert not (ROOT / "root-launch-receipt.json").exists() and not (ROOT / "root-launch-receipt.json").is_symlink()
old = json.loads((OLD / "packet-manifest.json").read_bytes())
assert sha(OLD / "packet-manifest.json") == "ff9bf553261f69b2aa08ca6828f7fe37ad02551688bf84b1efafcf1e60f33bc7"
for name, expected in json.loads(Path(old["originalPreparedPath"]).read_bytes())["sourceHashes"].items():
    assert sha(ROOT / "source" / name) == expected
for name in ["recipe.ts", "grid-telemetry.ts", "grid-telemetry.test.ts", "process_scope.py"]:
    assert sha(ROOT / name) == sha(OLD / name)
files = [item(path, True) for path in sorted(ROOT.rglob("*")) if path.is_file() and not path.is_symlink()
         and not any(part in {"node_modules", "__pycache__"} for part in path.relative_to(ROOT).parts)
         and path.name not in {"packet-manifest.json", "root-launch-receipt.json"}]
external = old["externalFiles"] + [item(OLD / name) for name in ["packet-manifest.json", "grid-telemetry.ts", "grid-telemetry.test.ts"]]
external += [item(ACTUAL / "run" / name) for name in ["result.json", "postflight.json"]]
external.append(item(ROOT.parent / "g350-ti-top-clock-enclosed-boundary-next" / "packet-manifest.json"))
manifest = {"schemaVersion": 1, "preparedUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "sourceRevision": old["sourceRevision"], "libTree": old["libTree"],
            "originalPreparedPath": old["originalPreparedPath"], "originalSourceMemberCount": 177,
            "files": files, "externalFiles": external,
            "requiredAbsentRuntimeFiles": [name.replace(str(OLD), str(ROOT)) for name in old["requiredAbsentRuntimeFiles"]],
            "policy": {"wallSeconds": 30, "rssBytes": 768 * 1024 ** 2, "sharedBytes": 24 * 1024 ** 3, "sampleSeconds": .05, "termGraceSeconds": 5},
            "maximumOriginalFactories": 1, "producerCaps": old["producerCaps"], "sourceContextCaps": old["sourceContextCaps"],
            "captureLimits": {"perArtifactBytes": 4 * 1024 ** 2, "aggregateBytes": 4 * 1024 ** 2},
            "dependencyReceiptSha256": old["dependencyReceiptSha256"], "dependencyTreeSha256": old["dependencyTreeSha256"], "dependencyArchiveSha256": old["dependencyArchiveSha256"],
            "inputBindings": {name: item(ROOT / name, True) for name in ["input.json", "original-unrestricted-input.json", "captured-reserved-job-3.json", "parent-prefix-result.json", "parent-prefix-postflight.json", "parent-unreserved-result.json", "parent-unreserved-postflight.json", "parent-telemetry-result.json", "parent-telemetry-postflight.json"]},
            "boundary": "First enclosed constructor data copied; forward original construction and first subsequent original yield, then original RETURN",
            "reusableV3ObserverByteExact": True, "algorithmCapsChanged": False,
            "actualLaunchCount": 0, "rootActualGoRequired": True, "authorityPathExcludedAndAbsentAtFreeze": True,
            "acceptedClock": False, "accepted49": False, "timingReady": False, "fabricationReady": False}
(ROOT / "packet-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"packetSha256": sha(ROOT / "packet-manifest.json"), "files": len(files), "external": len(external), "actualGridRoutingCheckerInitializerCalls": 0}))
