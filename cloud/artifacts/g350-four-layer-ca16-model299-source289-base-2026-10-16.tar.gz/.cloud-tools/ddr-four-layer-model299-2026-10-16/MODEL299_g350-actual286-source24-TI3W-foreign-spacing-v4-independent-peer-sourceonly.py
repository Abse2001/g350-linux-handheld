"""Independent own Python stdlib audit only; no native/SDK modules."""
import collections
exec(open('/tmp/g350-actual286-static-helper-sourceonly.py').read())
P='/tmp/g350-actual286-source24-TI3W-bank-foreign-spacing-v4-worker-proof.json';PIN='391332a7f7756d461102a6903f1599d72c5d4b22057bc4104a065e2c1325d61e';b=Path(P).read_bytes();assert hashlib.sha256(b).hexdigest()==PIN;r=json.loads(b);inv=r['bodyInverses'][0];assert inv['before']==bodyByOwner['source_trace_24'];new=inv['after'];assert len(r['bodyInverses'])==1
assert json.dumps(new['route'][0],separators=(',',':'))==json.dumps(inv['before']['route'][0],separators=(',',':'));assert json.dumps(new['route'][-1],separators=(',',':'))==json.dumps(inv['before']['route'][-1],separators=(',',':'));assert [p for p in new['route']if p['route_type']=='via']==[]
g=objectsFor(-9999,{'source_trace_24':new});mats=g['mats'];bbox=g['bbox'];sd=g['sd'];pd=g['pd'];srect=g['segmentRect'];prect=g['pointRect'];L=g['L']
s=Path('/tmp/g350-actual260-ca233-compatibility-sourceonly.py').read_text();exec(s[s.index('def length('):s.index('def selectedScene(')])
for o in g['objects']:o['ownedBy']=set(o['owner'].split(','));o['role']='material'
scene=Scene(g['objects']);rows=[]
for name,t in {**bodyByOwner,'source_trace_24':new}.items():
 c=scene.contacts(t);rows.append({'owner':name,'count':len(c),'contactRows':c[:5]})
s=Path('/tmp/g350-actual253-plus-Byte1-byte0-local-self-math-sourceonly.py').read_text();exec(s[s.index('def self_math('):s.index('gbase=objectsFor(43)')]);gbase=g;sr=self_math(new['route']);assert sr['passedPureMath'];assert not any(z['count']for z in rows)
wholeAfter=whole(new);assert 20.95<=wholeAfter<=21.585658
R={'scope':'INDEPENDENT_STDLIB_PEER_ONLY24_EXACT286_FULL49_RECIPROCAL_GEOMETRY_NO_NATIVE_ACCEPTANCE','proofPath':P,'proofSha256':PIN,'all49ForeignRows':rows,'whole24':wholeAfter,'pureSelfPassed':sr['passedPureMath'],'minimumReturningArmCenterlineMm':.2032,'declaredBankPitchMm':.31,'typicalTi3WNonlocalBankPitchSatisfied':True,'wholeTiQualified':False,'orderedEndpointsLiteral':True,'allFixedMaterialAndOther48BodiesHeld':True,'nativeExecuted':False,'all49Accepted':False,'timingPassed':False,'fabricationReady':False}
O='/tmp/g350-actual286-source24-TI3W-foreign-spacing-v4-independent-peer-report.json';Path(O).write_text(json.dumps(R,indent=2)+'\n');print(json.dumps({'report':O,'sha256':hashlib.sha256(Path(O).read_bytes()).hexdigest(),'whole24':wholeAfter,'all49ForeignZero':True,'selfPassed':True}))
