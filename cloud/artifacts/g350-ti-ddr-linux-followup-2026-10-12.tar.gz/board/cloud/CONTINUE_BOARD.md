Latest placement: user-requested CPU/RAM corridor cleared by moving five parts; read cloud/DDR_CLEAR_CPU_RAM_CORRIDOR_2026-10-11.md. Checked scene1081 preserves26/49 Top/Bottom DDR paths,23 missing, all17 local physical checks zero and fresh KiCad connectivity. Fresh editable layout source reproduces280 placements/1161 contacts and exact logical constraints; routing is disabled in that layout source. Nine saved local copper segments need recovery, and full routing/timing remain unfinished. Restore the new hash-indexed corridor archive before continuing. fabricationReady=false. Older sections below preserve history.

Latest partial result: RAM `(0,6)`, rotation270; trial1054 checks22/49 Top/Bottom DDR channels and fresh KiCad1055 confirms22. Read cloud/DDR_OUTER_LAYER_22_CHANNELS_2026-10-11.md.27 remain missing; references/timing/full-board qualification are open. Earlier90-degree proofs are history. fabricationReady=false.

Current runtime: verified tscircuit0.0.2821; read cloud/RUNTIME_REFRESH_2026-10-11_2821.md. All reviewed core/solver/checker pins and native patch remain. Earlier0.0.2819 notes describe preserved history.

Latest partial checkpoint: trial1040 checks18/49 Top/Bottom DDR channels,31 missing. Fresh KiCad1042 confirms18. Read the latest section of cloud/DDR_OUTER_LAYER_17_CHANNELS_2026-10-11.md; prior17-channel notes below are preserved history. All board/timing qualification remains open; fabricationReady=false.

## Current partial DDR interconnect checkpoint (2026-10-11 UTC)

Read cloud/DDR_OUTER_LAYER_17_CHANNELS_2026-10-11.md and the outer-placement
summary first. Trial1027 retains17 complete CPU-to-RAM DDR paths on Top/Bottom,
with32 missing. All16 local native physical/manufacturing/width/via-count/
contiguity/constraint checks are zero, including remaining package fanouts and
42 RAM reference reservations. Fresh KiCad1028 independently confirms17/49;
its connectivity checker correctly exits1 for32 missing. This is a partial
planning checkpoint, not a fresh editable source or a qualified board.
RAM remains `(0,6)`, rotation90; PCB stays four layers. Trial1026 proves13 actual
DDR paths compatible with18 power and21 ground approaches on inner layers;
1024 proves41 reference approaches without actual DDR carriers. Do not combine
these proofs into a claimed17-plus41 connected board. ZQ/peripheral/GND rebuild,
full source replay, matching and independent all-rule CAD/Gerbers remain open.
Preserve source836/KiCad837/Gerber838, hardware sources, all pins/native patch
and pre-existing local edits. There are1032 required active source ports;
1161 physical source ports include NC,1165 copper lands and2 NPTH guides.
Keep fabricationReady=false. No routing is accepted from failed/incomplete
public Bus Lanes output. The existing checkout is isolated; no worktree needed.

## Current local package milestone (2026-10-11 UTC)

Read cloud/DDR_OUTER_LAYER_PLACEMENT_CONTINUATION.md and
checks/integrated/g350-outer-ddr-placement-continuation/summary.json first.
RAM `(0,6)`, rotation90, has jointly checked49 CPU and91 RAM local escapes:
native physical/manufacturing/width/via-count/constraint/edge checks all zero.
These are local fanouts, not49 CPU-to-RAM channels or a connected board.
Trial1005 is the checked joint reference;1000 repairs only ODT's CPU approach;
1004 is the open input with explicit removed branches requiring reconstruction.
Manual1006 finds49 paths but fails physical checks. Public dual-package Bus
Lanes1007 is initially running; central-aisle fanouts1008 also pass every local
physical/manufacturing check. Inspect later execution reports before promotion. Preserve four layers, Top/Bottom DDR signal wires,
all source bus/pair limits, reviewed pins/native patch and frozen hardware sources.
Source836/KiCad837/Gerber838 remains the connected fallback, with inner DDR and
two matching failures. No new board is promoted; fabricationReady=false.
Do not treat missing power/ground/reference/LCD branches as complete. Require
fresh editable source, all217 connections/298 grounds/1032 numeric pads, matching,
every KiCad rule/severity and all-layer shorts before promotion. The existing
checkout is isolated; do not create a worktree. Older sections preserve history.

## Current request: DDR on Top/Bottom only (2026-10-11, Africa/Tripoli)

The user now requires DDR signal wires on Top and Bottom only, while retaining
four PCB layers, and asks for latest tscircuit plus public Bus Lanes. Runtime
wrapper 0.0.2819 is installed/source-verified; reviewed Core 0.0.2107, CLI 0.1.2258,
checks 0.0.242 and solver pins remain. Read cloud/DDR_OUTER_LAYER_REQUEST_2026-10-11.md
and checks/integrated/g350-outer-ddr-request-2026-10-11/summary.json first.
The last connected source836/KiCad837/Gerber838 is a protected fallback: only4/49
DDR traces already use outer layers exclusively. It does not satisfy the new
Top/Bottom-only request. New public BusLanes package/whole-bus attempts fail or
time out; guarded partial plans914/918/919/925 and reset merge927 are rejected.
No new candidate is promoted. Do not describe these trials as routed or checked.
Rebuild package approaches and qualify all49 signals/all217 board connections,
298 grounds, all numeric pads, native physical/manufacturing checks, every KiCad
rule/severity and all-layer shorts before promotion. Do not weaken checks/pins.
All frozen sources remain. fabricationReady=false; electrical timing and shell
fit remain open. Existing checkouts are isolated; do not create a worktree.

## Previous checked four-layer signal checkpoint (preserved fallback)

## Latest checked four-layer length progress (2026-10-10 UTC)

Latest checked continuation (2026-10-10 UTC): use
`experiments/am3352-g350-full-board-ground-preserving-clean-corners-replay.circuit.tsx` and read
`cloud/DDR_CLEAN_CORNERS_FORWARD_PROGRESS_2026-10-10.md` plus `checks/integrated/g350-clean-corners-forward-progress/summary.json`.
Fresh source 836 / KiCad 837 / Gerber838 retain all 217 connections,49 DDR,
298 grounds,1,032 numeric pads,280 placements,RAM90,four layers and824 original
standard through-vias. Native physical/manufacturing/ground checks, all-rule
KiCad errors/warnings/opens/dangling copper and all-layer shorts are zero.
Byte0 passes 0.574882 mm; byte1 4.211624 mm and
command/clock 4.410969 mm still fail 0.635 mm. All pairs pass 0.127 mm.
Source exit 1 is exactly those two failures; complete independent qualification exits 0.
D8 now has zero corners below 25 degrees. Seven completed byte1 rounds814 and
three completed command rounds815 are retained snapshots, not entire parent
runs780/781. Selective cleanup811/816 and merge 817 preserve every original hole,
CPU/RAM endpoint, peripheral trace, placement, logical constraint and runtime pin.
Exact planned834 canonical DDR copper and physical hole records reproduce in source.
The existing two bounded A0 barrel moves remain unchanged relative source 770.
Bottom DDR copper is restored exactly from checked source 770; CASn is retuned
on Top only. No new hole, removed hole or failed topology trial is promoted. Public pinned
BusLanes trials 787/788/800/801 find no complete qualifying route. Fine-grid809
passes an independent clearance control; board trials 808/810/812/813 fail the
unchanged overlap/self-short guards. Keep those planning helpers experimental.
Native1.6 mm per transition is not qualified electrical delay. Clock/stackup/
package/via models, impedance/coupling/returns, PDN/footprints, Linux and measured
shell fit remain open. fabricationReady=false; the board is not ready to order.
Preserve source 770/737/699/643/610/591/565/540/532/319 and all frozen evidence.
Further edits require fresh source and complete independent qualification.

## Previous shorter-byte1 checkpoint (preserved history)

Latest checked continuation (2026-10-10 UTC): use
`experiments/am3352-g350-full-board-shorter-byte1-second-batch-replay.circuit.tsx` and read
`cloud/DDR_SHORTER_BYTE1_SECOND_BATCH_2026-10-10.md` plus `checks/integrated/g350-shorter-byte1-second-batch-progress/summary.json`.
Fresh source770 / KiCad771 / Gerber772 retain all217 connections,49 DDR,
298 grounds,1,032 numeric pads,280 placements,RAM90,four layers and824 standard
through-vias. Native physical/manufacturing/ground checks, all-rule KiCad
errors/warnings/opens/dangling copper and all-layer shorts are zero.
Byte0 passes 0.574882 mm; byte1 5.461624 mm and
command/clock 6.210969 mm still fail0.635 mm. All pairs pass0.127 mm.
Source build exit1 is exactly those two failures; complete qualification exits0.
D8 removes three existing acute corners and shortens5.380863 mm; one acute
corner remains. DQM1 shortens5.461572 mm, with its floor adjusted by real0.1 mm
copper. Original pad endpoints, all foreign copper, placements and constraints
stay exact. A0's same two bounded middle-barrel moves are retained; all824
original hole IDs/dimensions/full depth remain. Exact planned copper reproduces
in source. Joint public BusLanes11/37-lane trials find no complete route and
are not promoted. Snapshot763 is completed round2, not the entire8-round parent.
Keep runtime pins, reviewed native patch and every existing physical assertion.
Native1.6 mm per transition is not electrical delay. Clock/stackup/package/via
models, impedance/coupling/returns, PDN/footprints, Linux and measured shell fit
remain open. fabricationReady=false; the board is not ready to order.
Preserve source737/699/643/610/591/565/540/532/319 and frozen evidence.
Future edits require fresh source and complete independent qualification.

## Previous four-layer owned-via checkpoint (preserved history)

Latest checked continuation (2026-10-10 UTC): use
`experiments/am3352-g350-full-board-four-layer-owned-via-replay.circuit.tsx` and read
`cloud/DDR_FOUR_LAYER_OWNED_VIA_PROGRESS_2026-10-10.md` plus `checks/integrated/g350-four-layer-owned-via-progress/summary.json`.
Fresh source737 / KiCad738 / Gerber739 retain all217 connections, 49DDR,
298 ground ports, 1,032 numeric ports, 280 placements and824 standard through-vias.
Native physical/manufacturing checks, all-rule DRC errors/warnings, opens,
dangling copper and all-layer shorts are zero. Byte0 passes0.574882 mm;
byte1 5.561624 mm and command/clock6.464305 mm still fail0.635 mm.
All differential pairs pass0.127 mm. Build exit1 is solely those two failures;
complete source/CAD/Gerber qualification exits0. fabricationReady=false.
Four-layer matching includes CASn's existing top/bottom route. Two owned A0
barrels move within1.5 mm; all original hole identities, dimensions, full depth,
CPU/RAM endpoints, peripheral copper, placements and source constraints remain.
Exact planned copper and hole records are reproduced by the fresh source.
Public pinned BusLanes remains the starting point and its default adapter is
retested by744. Keep all runtime pins and reviewed native checks.
Native length includes1.6 mm per transition, not qualified electrical delay.
Clock/stackup/package/via delay, impedance/coupling/returns, PDN/footprints,
Linux and measured shell fit remain open. The board is not ready to order.
Preserve source699/643/610/591/565/540/532/319 and all frozen evidence.
Short-D9 planning730 and the still-incomplete parent724 must not be promoted.
Further candidate edits require full independent qualification.

## Previous BusLanes and smoothing checkpoint (preserved history)

## Latest checked BusLanes and smoothing progress (2026-10-10 UTC)

Latest checked continuation (2026-10-10 UTC): use
`experiments/am3352-g350-full-board-bus-lanes-smoothed-replay.circuit.tsx` and read
`cloud/DDR_BUS_LANES_SMOOTHED_PROGRESS_2026-10-10.md` plus `checks/integrated/g350-bus-lanes-timing-progress/summary.json`.
Fresh source699 / KiCad700 / Gerber701 retain all217 connections, 49DDR,
298 ground ports, 1,032 numeric ports, 280 placements and824 standard through-vias.
Native physical/manufacturing checks, all-rule DRC errors/warnings, opens,
dangling copper and all-layer shorts are zero. Byte0 passes0.574882 mm;
byte1 5.766561 mm and command/clock8.056486 mm still fail0.635 mm.
All differential pairs pass0.127 mm. Build exit1 is solely those two failures;
complete source/CAD/Gerber qualification exits0. fabricationReady=false.
Pinned public BusLanes shortens A6's Inner1 carrier by6 mm; guarded smoothing
and matching preserve every original barrel, endpoint, outer-layer wire,
peripheral trace, placement and logical constraint. Keep all runtime pins and
reviewed native checks. Native length includes1.6 mm per transition, not
qualified electrical delay. Target clock, stackup, package/via delay, impedance,
coupling, return paths, PDN/footprints, Linux and measured shell fit remain open.
Preserve source643/610/591/565/540/532/319 and frozen evidence. The board is not
ready to order. Further candidate edits require full independent qualification.

## Previous RAM-end window checkpoint (preserved history)

## Latest checked reverse-window timing progress (2026-10-10 UTC)

Latest checked continuation (2026-10-10): use
`experiments/am3352-g350-full-board-reverse-window-replay.circuit.tsx`
and read `cloud/DDR_REVERSE_WINDOW_PROGRESS_2026-10-10.md` plus
`checks/integrated/g350-reverse-window-progress/summary.json`.
Fresh source643 / KiCad644 / Gerber645 retain all217 connections, 49DDR,
298 ground ports, 1,032 numeric ports, 280 placements and824 standard through-vias.
Native physical checks, all-rule DRC errors/warnings, opens, dangling copper and
all-layer shorts are zero. Byte0 passes0.574882 mm; byte1 6.973572 mm and
command/clock8.600328 mm still fail0.635 mm. All differential pairs pass.
Build exit1 is solely those two failures; full qualification exits0.
Inner-layer tuning now scans bend/block windows from the RAM end, preserving
original barrels/endpoints, outer-layer wire points, peripheral copper and logic.
All pins, minimum clearances, physical and fresh-ground assertions stay fixed.
Native length includes1.6 mm per transition; electrical timing, stackup,
PDN/footprints, Linux and measured shell fit remain unqualified.
Preserve source610/591/565/540/532/319, BusLanes bootstrap and frozen evidence.
Rejected631/635/639 lose215 ground ports; do not promote those candidates.
Keep fabricationReady=false. The board is not ready to order.

## Previous protected-layer checkpoint (preserved history)

## Latest checked protected-layer timing progress (2026-10-10 UTC)

Latest checked continuation (2026-10-10): use
`experiments/am3352-g350-full-board-protected-layer-replay.circuit.tsx`
and read `cloud/DDR_PROTECTED_LAYER_PROGRESS_2026-10-10.md` plus
`checks/integrated/g350-protected-layer-progress/summary.json`.
Fresh source610 / KiCad621 / Gerber622 retain all217 connections, 49DDR,
298 ground ports, 1,032 numeric ports, 280 placements and824 standard through-vias.
Native physical checks, all-rule DRC errors/warnings, opens, dangling copper and
all-layer shorts are zero. Byte0 passes0.574882 mm; byte1 7.333572 mm and
command/clock9.650328 mm still fail0.635 mm. All differential pairs pass.
Build exit1 is solely those two failures; full qualification exits0.
A9 gains3 mm on Inner2 while its other-layer geometry remains exact. Original
barrels/endpoints, peripheral copper, logical constraints and all pins/guards stay
fixed. Native length includes1.6 mm per transition; electrical timing, stackup,
PDN/footprints, Linux and measured shell fit remain unqualified.
Preserve source591/565/540/532/319, BusLanes bootstrap and all frozen evidence.
Read cloud/LINUX_VALIDATION.md for tested VFS space preflight and Xvfb socket fixes.
Keep fabricationReady=false. The board is not ready to order.

## Previous ascending-group checkpoint (preserved history)

## Latest checked ascending-group timing progress (2026-10-10 UTC)

Latest checked continuation (2026-10-10): use
`experiments/am3352-g350-full-board-ascending-group-restored-replay.circuit.tsx`
and read `cloud/DDR_ASCENDING_GROUP_RESTORED_2026-10-10.md` plus
`checks/integrated/g350-ascending-group-restored-progress/summary.json`.
Fresh source 591 / KiCad 592 / Gerber 593 preserve all 217 connections, 49 DDR,
298 ground ports, 1,032 numeric ports, 280 placements and 824 standard through-vias.
Native physical checks, all-rule DRC errors/warnings, opens, dangling copper and
all-layer shorts are zero. Byte0 passes native matching at 0.574882 mm; byte1
7.373572 mm and command/clock 10.350328 mm still fail 0.635 mm. All pairs pass.
Build exit is 1 for exactly those two failures; qualification wrapper exit is 0.
Native length counts 1.6 mm per transition, not electrical delay. The broader
batch586 fails native ground with215 errors and is rolled back. Restoring the
checked A9 route retains other growth and passes complete qualification591–593.
Preserve source565/540/532/319, the BusLanes bootstrap and all frozen evidence.
Further tuning requires complete qualification. Keep fabricationReady=false.

## Previous larger-group checkpoint (preserved history)

Previous checked continuation (2026-10-10): use
`experiments/am3352-g350-full-board-large-group-restored-replay.circuit.tsx`
and read `cloud/DDR_LARGE_GROUP_RESTORED_2026-10-10.md` plus
`checks/integrated/g350-large-group-restored-progress/summary.json`.
Fresh source 565 / KiCad 566 / Gerber 567 preserve all 217 connections, 49 DDR,
298 ground ports, 1,032 numeric ports, 280 placements and 824 standard through-vias.
Native physical checks, all-rule DRC errors/warnings, opens, dangling copper and
all-layer shorts are zero. Byte0 passes native matching at 0.574882 mm; byte1
7.693572 mm and command/clock 11.150328 mm still fail 0.635 mm. All pairs pass.
Build exit is 1 for exactly those two failures; qualification wrapper exit is 0.
Native length counts 1.6 mm per transition, not electrical delay. Keep all
original barrels/endpoints, source540/532/319 and frozen evidence. The A0
shortcut in source560 creates a native self-short and is rejected; source565
restores the entire checked A0 route while retaining accepted growth elsewhere.
Further tuning requires complete qualification. Keep fabricationReady=false.

## Previous constant-neck checkpoint (preserved history)

Previous checked continuation (2026-10-10): use
`experiments/am3352-g350-full-board-constant-neck-timing-replay.circuit.tsx`
and read `cloud/DDR_CONSTANT_NECK_TIMING_2026-10-10.md` plus
`checks/integrated/g350-constant-neck-timing-progress/summary.json`.
Fresh source 540 / KiCad 541 / Gerber 542 preserve all 217 connections, 49 DDR,
298 ground ports, 1,032 numeric ports, 280 placements and 824 standard through-vias.
Native physical checks, all-rule DRC errors/warnings, opens, dangling copper and
all-layer shorts are zero. Byte0 passes native matching at 0.574882 mm; byte1
8.033572 mm and command/clock 12.450328 mm still fail 0.635 mm. All pairs pass.
Build exit is 1 for exactly those two failures; qualification wrapper exit is 0.
Native length counts 1.6 mm per transition; byte0's planar spread is 8 mm with
2–7 transitions. This is not electrical delay qualification. Preserve source532
as a qualified ground-safe fallback, preceding81078ba/ac0dcaf, source319 and all
frozen evidence. Trial497/515 has a ground open and must not be promoted.
Further tuning requires complete qualification. Keep fabricationReady=false.

## Previous connected byte1 checkpoint (preserved history)

Previous checked continuation (2026-10-10): use
`experiments/am3352-g350-full-board-byte1-integrated-clean-replay.circuit.tsx`
and read `cloud/DDR_BYTE1_INTEGRATED_2026-10-10.md` plus
`checks/integrated/g350-integrated-byte1-progress/summary.json`.
Fresh source 468 / KiCad 472 / Gerber 473 preserve all 217 connections, 49 DDR,
298 ground ports, 1,032 numeric ports, 280 placements and 824 standard through-vias.
Native physical checks, all-rule DRC errors/warnings, opens, dangling copper and
all-layer shorts are zero. Byte0 passes native matching at 0.574882 mm; byte1
15.221372 mm and command/clock 24.150328 mm still fail 0.635 mm. All pairs pass.
Build exit is 1 for exactly those two failures; qualification wrapper exit is 0.
Native length counts 1.6 mm per transition; byte0's planar spread is 8 mm with
2–7 transitions. This is not electrical delay qualification. Preserve preceding
ac0dcaf / source 443, source319 and all frozen evidence. Further byte1/command combinations
are unqualified; joint tuner464 and rerouting trials require complete qualification. Keep fabricationReady=false.

## Latest checked ground-preserving byte growth (2026-10-10 UTC)

Continue `experiments/am3352-g350-full-board-ground-safe-byte-growth-stable-replay.circuit.tsx`.
Read `cloud/DDR_GROUND_SAFE_BYTE_GROWTH_2026-10-10.md` and
`checks/integrated/g350-ground-safe-byte-growth-progress/summary.json`.
Source 319, KiCad 320 and Gerber 321 preserve all 217 connections, 49 DDR,
298 ground ports, placements and 824 standard through-vias, with zero DRC
warnings/errors, opens, dangling copper and shorts. Native bus skews are
15.124882 / 23.748074 / 24.300328 mm against 0.635 mm; pairs pass. Build still
exits 1 for matching. Preserve prior 8284474 and all frozen evidence, retain
runtime/checker pins, and keep fabricationReady false. See the working report
for unqualified small gains, rejected ground interactions and cache-order fixes.

## Latest checked DDR shortcuts and runtime (2026-10-09 UTC)

Continue `experiments/am3352-g350-clean-full-board-checked-shortcuts-replay.circuit.tsx`.
Read `cloud/DDR_CHECKED_SHORTCUT_PROGRESS_2026-10-09.md`,
`cloud/RUNTIME_REFRESH_2026-10-09.md` and
`checks/integrated/g350-checked-shortcut-progress/summary.json`. Fresh source 178,
independent refill/export 179 and Gerber 180 retain 217/217 connections, 49 DDR
signals, 280 placements, RAM90, four layers and 824 standard full-depth vias.
DRC errors/warnings, opens, dangling copper and shorts are zero. All native checks
pass except three bus-skew failures: 29.148292 / 33.385093 / 24.480252 mm versus
0.635 mm; differential pairs pass. Only D2/D12/A0 copper changes. Other DDR and
peripheral geometry, logical constraints, pads, placements and vias are preserved.
The new tscircuit 0.0.2803 wrapper is source-tested with unchanged reviewed
Core/CLI/checker/solver pins. The preceding connected 7b08fba checkpoint and frozen
evidence remain. A separate exit-bound final artifact verifier passes; the initial
combined wrapper's exit 1 is retained and explained in the report. GitHub
authentication briefly failed, then recovered; a fresh fetch confirms the same
7b08fba parent. Preserve any newer transfer records before pushing. Matching and electrical
clock/stackup/package/via/impedance/return-path qualification remain unfinished.
Keep fabricationReady false. Older sections describe preserved checkpoints.

## Latest checked DDR bend progress (2026-10-09)

Continue `experiments/am3352-g350-clean-full-board-bend-timing-replay.circuit.tsx`.
Read `cloud/DDR_BEND_TIMING_PROGRESS_2026-10-09.md` and
`checks/integrated/g350-bend-timing-progress/summary.json`. Fresh source 166,
independent refill/export 167 and isolated Gerber 168 retain 217/217 connections,
49 DDR signals, all 280 placements, RAM90 and four layers. DRC errors/warnings,
opens, dangling copper and shorts are zero. All native checks pass except three
bus-skew failures: 30.621477 / 34.678381 / 24.692716 mm versus 0.635 mm.
Differential pairs pass. Non-DDR copper geometry, logical constraints and all
824 standard through-vias are unchanged; derived pour annotations renumber.
The preceding connected checkpoint and all new trials are hash-indexed and
retained. Runtime/checker/solver pins stay fixed. Whole-bus matching is unfinished;
target DDR clock and manufacturer stackup are still needed for electrical timing.
Keep fabricationReady false. Older sections describe preserved checkpoints.

## Latest checked middle-shortcut continuation (2026-10-07)

Continue `experiments/am3352-g350-clean-full-board-middle-shortcut-replay.circuit.tsx`.
Read `cloud/DDR_MIDDLE_SHORTCUT_PROGRESS_2026-10-07.md` and
`checks/integrated/g350-middle-shortcut-progress/summary.json` first. Fresh source
144 / independent refill 145 / isolated Gerber 146 retain all 217 connections,
49 DDR signals, 280 placements, RAM90 and four layers. DRC errors/warnings,
opens, dangling copper and shorts are zero. All native checks pass except three
bus-skew failures: 33.771477 / 36.800514 / 27.930389 mm versus 0.635 mm.
All differential pairs pass. Runtime pins remain tscircuit 0.0.2759 / Core
0.0.2107 / CLI 0.1.2258 with unchanged reviewed checks and solvers. Core 0.0.2108
was tested in isolation and did not change any non-metadata source record;
it is not silently substituted into the board runtime. Preserve the rejected
recovery/physical-via bypass trials and restore their rasters only if needed.
Target DDR clock and manufacturer's stackup remain unspecified; full electrical
timing and measured shell fit are unqualified. Keep fabricationReady false.
Older entries below preserve historical checked checkpoints.

## Latest checked clean whole-board length progress (2026-10-07)

Continue `experiments/am3352-g350-clean-full-board-length-progress-replay.circuit.tsx`.
Read `cloud/CLEAN_DDR_LENGTH_PROGRESS_2026-10-07.md`, its integrated summary and
`cloud/RUNTIME_REFRESH_2026-10-07.md` first. Source 123 / independent 129 / Gerber
130 retain 217/217 connections and 49 DDR signals, with zero KiCad errors,
warnings, opens, dangling copper and shorts. All 280 placements remain fixed.
Three bus-skew failures remain: 34.278647 / 37.400514 / 28.530389 mm versus
0.635 mm. All differential pairs pass. Runtime is tscircuit 0.0.2759, Core
0.0.2107 and CLI 0.1.2258; checker/solver pins and reviewed patch remain intact.
Keep fabricationReady false. Matched-DDR rest-recovery and later tuning trials
are unqualified until fresh source and independent checks pass. Older sections
below are historical checked checkpoints.

## Latest checked whole-board continuation (2026-10-07)

Use `experiments/am3352-g350-full-board-dangling-clean-replay.circuit.tsx`.
Read `cloud/DANGLING_COPPER_CLEANUP_2026-10-07.md`,
`checks/integrated/g350-dangling-copper-cleanup/summary.json` and
`cloud/RUNTIME_UPGRADE_2026-10-07.md` before the historical sections below.
All 217 connections and 49 DDR signals are independently checked. KiCad errors,
warnings, dangling tracks/vias, opens and all-layer Gerber shorts are zero.
119 unused vias and 135.834855 mm of non-DDR planar copper were removed.
All DDR copper and component placements are exactly preserved. Three bus-skew
failures remain: Byte0 34.878647 mm, Byte1 41.191260 mm, command/clock 29.576845 mm
against 0.635 mm. All three differential pairs pass their 0.127 mm limits.
Keep fabricationReady false: full electrical timing and measured shell fit remain
unfinished. Restore only the final source archive during normal startup; large
compressed scratch rasters are preservation evidence, not startup dependencies.
Use the isolated Gerber wrapper, run KiCad containers sequentially and preserve
all original evidence. Older entries below are historical checkpoints.

# Latest whole-board continuation (2026-10-07)

The user requested the rest of the rotated-RAM board routed. The newest checked
entry is `experiments/am3352-g350-full-board-ground-joined-replay.circuit.tsx`.
Read `cloud/FULL_BOARD_CONNECTED_2026-10-07.md` and
`checks/integrated/g350-full-board-progress/summary.json` first. Fresh source and
independent checks verify 217/217 connections, all 49 DDR signals and 298 ground
ports; native connectivity/physical checks and all-rule KiCad error categories
are zero. All-layer shorts are zero. Three whole-DDR-bus skew failures still
make the complete build exit 1. Restore its hash-indexed archive as documented;
keep the default, DDR-only zero-skew evidence and failed trials frozen. Continue
whole-board DDR matching and remaining electrical, mechanical and release gates.
`fabricationReady` stays false. Older instructions below are historical context.

# Continue the G350 board in cloud

Read `AGENTS.md`, `docs/CLOUD_HANDOFF.md`, `design-status.json` and the original
user-visible conversation in `docs/CHAT_CONTEXT.md`. Continue the same bare-AM3352
Linux handheld toward fabrication readiness. Preserve all accepted requirements:
original G350 shell, maximum four copper layers, both assembly sides, eleven
front membrane buttons, FPC display, microSD, one USB-C for charging and data,
no analog sticks or rear buttons, individual JLCPCB components, tsci, native
bus_lanes DDR bootstrap phases and checked manual repairs.

Verify the environment and pinned native solver first. Complete pending byte1
independent checks and the generated KiCad ignore-rule audit without weakening
checks. Repair/restructure the native byte1 carrier phase, replay actual editable
source and qualify combined copper. Preserve checked byte0 and power planes,
complete full DDR/peripheral routing, Linux boot/USB provisioning and release
checks. Do not merge routes from incompatible historical placements. Preserve
failed runs and only push meaningful verified breakthroughs after this transfer.

Keep fabricationReady false until every electrical, mechanical and manufacturing
gate passes; the user wants an order-ready prototype, not a partial routing image.
Shell measurements remain missing, so continue independently useful electronics
work while clearly recording the remaining physical-fit evidence needed.

## Latest rotated-RAM DDR candidate

The user requested RAM rotated 90 degrees and four-layer routing with inner
layer priority. The new source-verified candidate connects all 49 DDR signals
with zero native physical errors and zero Gerber shorts. Read
`cloud/DDR49_ROTATED_RAM_2026-10-06.md` and its evidence before continuing.
Six native length/skew failures, power/reference copper and peripheral routing
remain unfinished. The default 11/49 layout is unchanged; preserve its evidence,
but continue the user-requested rotated candidate rather than mixing placements.
`fabricationReady` stays false.

## Rotated-RAM timing repair (2026-10-06)

Continue `experiments/am3352-g350-ram90-three-pairs-safe-replay.circuit.tsx`
from `cloud/DDR_TIMING_REPAIR_2026-10-06.md`. Its fresh editable source retains
49/49 DDR connectivity and all 280 component placements. All three differential
pairs pass; native skew failures decreased from six to three whole-bus failures.
Native physical checks, all-layer shorts, manufacturing clearance and independent
KiCad connectivity pass. The default and the prior 49/49 evidence remain frozen.
Power/reference copper, peripheral routing, electrical timing and shell fit remain
unfinished. `fabricationReady` is false. The earlier three-pairs entry without
`safe` was rejected for manufacturing clearance and must not be promoted.

## DDR native skew cleared (2026-10-06)

The latest checked continuation is
`experiments/am3352-g350-ram90-zero-skew-replay.circuit.tsx`.
Read `cloud/DDR_ZERO_SKEW_2026-10-06.md` and
`checks/integrated/g350-ram90-zero-skew/summary.json`.
Fresh editable-source replay has 49/49 DDR connections, zero native length/skew
violations, zero physical/manufacturing errors and zero all-layer shorts.
Independent KiCad verifies all 49 connections with no ignored checks/exclusions.
All 280 placements, RAM at 90 degrees and four layers are retained; about 60% of
planar DDR copper uses Inner1/Inner2. Native pair bootstrap and checked manual
repairs are archived. The old default and all older evidence remain frozen.
This clears the native skew milestone, not full electrical timing or fabrication:
power/reference copper, nominal/package/via timing, impedance/return paths,
peripherals, Linux and measured original-shell fit remain unqualified.
`fabricationReady` stays false. Continue this newest checked entry; older timing
sections describe preserved historical checkpoints.

## Latest connected inner-layer timing checkpoint (2026-10-10 UTC)

Continue `experiments/am3352-g350-full-board-inner-timing-ground-preserved-replay.circuit.tsx`.
Read `cloud/DDR_INNER_TIMING_CONNECTED_2026-10-10.md` and
`checks/integrated/g350-inner-ground-timing-progress/summary.json`. Fresh source 209,
independent fresh-fill KiCad 210 and Gerber 211 retain 217/217 connections, all 49 DDR
signals, 298 ground ports and 1,032 required numeric ports. All 280 placements, RAM90,
four layers and 824 full-depth vias are preserved. DRC errors/warnings/opens/dangling
copper and shorts are zero. Source/fresh-filled native checks pass except three
bus-skew failures: 19.293662 / 25.185093 / 24.480252 mm versus 0.635 mm. Pairs pass.
The build exits 1 for matching; the qualification wrapper exits 0. The b70590b
checkpoint and frozen evidence remain. Distributed growth trials that broke ground
are rejected; 215 native ground errors reflected the whole-net assertion, while
KiCad identified three stranded pads. Checked outer spans were restored while
retaining inner-layer tuning. Further recovery 212/217/220 is unqualified and must
not replace the checked entry. Preserve native whole-net assertions and runtime pins;
fresh numeric/ground/Gerber checks remain mandatory. Electrical clock/stackup/timing,
PDN, Linux and measured shell fit remain unfinished. Keep fabricationReady false.
