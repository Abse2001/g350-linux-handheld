"""Fail-closed preparation/ONE authorized fresh source-only exporter guard."""
import argparse,hashlib,importlib.util,json,os,re,stat,sys,time
from pathlib import Path
from inventory import sha,tree
ROOT=Path(__file__).resolve().parent;BOARD=Path('/workspace/g350-linux-handheld');POLICY={'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}

def load_scope():
 s=importlib.util.spec_from_file_location('owned_scope',ROOT/'process_scope.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def receipt(value,packet):
 if value.get('authorizedByRoot') is not True or value.get('packetSha256')!=packet or value.get('policy')!=POLICY or value.get('scope')!='one-ti-v7-exported-source-validation-only-no-new-export-no-router' or not re.fullmatch('[0-9a-f]{32,128}',value.get('approvalToken','')):raise ValueError('Exact root source-export authority required')

def checked():
 raw=(ROOT/'packet-manifest.json').read_bytes();m=json.loads(raw)
 if m['policy']!=POLICY or m['scope']!='one-ti-v7-exported-source-validation-only-no-new-export-no-router':raise ValueError('Policy/scope mismatch')
 for row in m['files']:
  p=ROOT/row['path']
  if p.is_symlink() or not p.is_file() or sha(p)!=row['sha256'] or stat.S_IMODE(p.stat().st_mode)!=row['mode']:raise ValueError('Packet bytes changed: '+row['path'])
 for row in m['externalFiles']:
  p=Path(row['path'])
  if not p.is_file() or sha(p)!=row['sha256']:raise ValueError('Original source/runtime/dirty binding changed: '+row['path'])
 link=ROOT/'source/node_modules'
 if not link.is_symlink() or os.readlink(link)!=str(BOARD/'node_modules'):raise ValueError('Trusted board dependency resolver link required')
 expected_source={r['path'] for r in m['files'] if r['path'].startswith('source/')}
 for directory,dirs,files in os.walk(ROOT/'source',followlinks=False):
  dirs[:]=[d for d in dirs if not ((Path(directory)/d)==ROOT/'source/node_modules')]
  for name in dirs:
   if (Path(directory)/name).is_symlink():raise ValueError('Unlisted source symlink')
  for name in files:
   p=Path(directory)/name;relative=p.relative_to(ROOT).as_posix()
   if p.is_symlink() or not stat.S_ISREG(p.lstat().st_mode):raise ValueError('Nonregular source entry')
   if relative not in expected_source and not relative.startswith('source/dist/'):
    raise ValueError('Unlisted import-resolvable source entry:'+relative)
 for p in m['resolverMustRemainAbsent']:
  if Path(p).exists() or Path(p).is_symlink():raise ValueError('Unexpected nearest resolver: '+p)
 fresh=ROOT/m['freshOutput']
 # Source outputs may exist only after this one actual run; preflight checks
 # exact absence separately. They are never part of source import closure.
 deps=tree(BOARD/'node_modules');expected=m['dependencyTree']
 for k in ['treeSha256','regularFiles','regularBytes','symlinks','directories']:
  if deps[k]!=expected[k]:raise ValueError('Full installed board dependencies changed: '+k)
 return m,hashlib.sha256(raw).hexdigest(),{k:v for k,v in deps.items() if k!='items'}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--preflight',action='store_true');parser.add_argument('--launch-receipt',type=Path);parser.add_argument('--receipt-sha256');a=parser.parse_args()
 if a.preflight==bool(a.launch_receipt) or (a.preflight and a.receipt_sha256):raise ValueError('Select preflight OR one root-authorized export')
 if (ROOT/'run').exists() or (ROOT/'run').is_symlink():raise ValueError('Fresh exclusive run required')
 if a.preflight and (ROOT/'root-launch-receipt.json').exists():raise ValueError('Authority absent until root review')
 started=time.monotonic();m,pkt,depbefore=checked();output=ROOT/m['freshOutput']
 if not output.is_file() or sha(output)!=m['actualV7SourceSha256']:raise ValueError('Original exported V7 source must remain exact')
 scope=load_scope();memory=scope.memory();
 if memory['current']+POLICY['rssBytes']+2*1024**3>=POLICY['sharedBytes']:raise ValueError('Insufficient shared launch headroom')
 if a.preflight:
  print(json.dumps({'phase':'PREFLIGHT_ONLY','packetSha256':pkt,'dependencyTree':depbefore,'sourceFileCount':m['sourceFileCount'],'actualCircuitExecuted':False,'seconds':time.monotonic()-started}));return 0
 raw=a.launch_receipt.read_bytes();actual=hashlib.sha256(raw).hexdigest()
 if not re.fullmatch('[0-9a-f]{64}',a.receipt_sha256 or '') or actual!=a.receipt_sha256:raise ValueError('Exact root receipt hash required')
 receipt(json.loads(raw),pkt)
 def before_spawn(current):
  if current['current']+POLICY['rssBytes']+2*1024**3>=POLICY['sharedBytes']:raise ValueError('Insufficient immediate shared headroom')
  if any(current['events'][k]!=memory['events'][k] for k in scope.OOM_KEYS):raise ValueError('New OOM before fork')
 execution=scope.run_guarded([sys.executable,str(ROOT/'runner.py'),'--one-approved-validation-recovery'],ROOT,ROOT/'run',POLICY,{'G350_TI_V7_VALIDATION_APPROVED':'1','G350_TI_V7_VALIDATION_PACKET_SHA':pkt},before_spawn=before_spawn)
 _,afterhash,depafter=checked();resultpath=ROOT/'run/result.json';result=json.loads(resultpath.read_text()) if resultpath.is_file() else None
 trust=execution['exitCode']==0 and not execution['diagnosticStopped'] and execution.get('cleanupOwnedGroupEmpty') is True and not any(execution['oomDelta'].values()) and afterhash==pkt and result is not None and result.get('packetSha256')==pkt and result.get('sourceOnlyQualified') is True and result.get('validation',{}).get('passed') is True and result.get('autoroutingPerformed') is False and result.get('cadPerformed') is False and result.get('fabricationReady') is False
 report={'packetSha256Before':pkt,'packetSha256After':afterhash,'receiptSha256':actual,'policy':POLICY,'dependencyBefore':depbefore,'dependencyAfter':depafter,'execution':execution,'resultTrustEligible':trust,'resultSha256':sha(resultpath) if resultpath.is_file() else None,'totalGuardSeconds':time.monotonic()-started,'sourceOnlyQualified':trust,'actualBoardDdr49Accepted':False,'fabricationReady':False}
 (ROOT/'run/postflight.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'exitCode':execution['exitCode'],'resultTrustEligible':trust,'sourceOnlyQualified':trust,'routingPerformed':False}));return 0 if trust else 2
if __name__=='__main__':raise SystemExit(main())
