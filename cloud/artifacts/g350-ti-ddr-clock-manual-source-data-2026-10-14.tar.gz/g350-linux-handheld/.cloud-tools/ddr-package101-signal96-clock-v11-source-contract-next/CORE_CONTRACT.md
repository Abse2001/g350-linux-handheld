The proposed source can reproduce the two clocks on Inner1 using the existing
standard through-vias. It remains unexecuted: source capture, types, Core,
native checks and CAD must pass before adopting it.

Pinned Core 0.0.2107 is the actual inspected implementation. Its installed
`dist/index.js` is SHA256
`97b8a4eb484630c3ce2bfc2d68588801484d85adf94785d8849a1d91c4404905`.
Relevant implementation locations are `Via` at line 5668, `Port.registerMatch`
at 5196, `Port.getAvailablePcbLayers` at 5244, `Via.doInitialPcbPortAttachment`
at 5852 and manual `pcbPaths` rendering at 6303–6462.

Core creates Via ports in the constructor before attaching the via to the board.
The constructor therefore creates Top and Bottom ports, although subsequent
physical via rendering sees all four board layers. This is why an Inner1 port
cannot be assumed to exist. The source explicitly appends four real Inner1
`port` elements to the four existing clock vias. After `circuit.add(element)`,
before the first render, `registerClockInnerPorts(circuit)` matches each actual
Port object to its actual Via object using Core's public `registerMatch` method.
The hook verifies the existing name, position, diameters, physical span, parent,
layer, unrendered state and unique match. It creates no extra hole or soup record.

`pcbPath` and `pcbPaths` insert new holes for every explicit via marker. The
proposed clock paths contain no via marker. Each uses real layer-port selectors;
Core chooses the first selector's available layer. Three paths belong directly
to each original numeric clock trace:

1. CPU numeric Top pad to its existing via's Top port.
2. CPU via's real Inner1 port, through the V11 carrier, to RAM via's Inner1 port.
3. RAM via's Top port to the original numeric RAM Top pad.

The frozen Source737/Source836 replay examples use saved `autoroutingphase`
paths with explicit wire/via layers. Core's saved-phase materializer can reuse a
physical hole only when coordinates, dimensions, full physical layer span,
subcircuit and a nonempty connectivity key match (`pcbViasSharePhysicalHole`,
line 52075; materialization at 120745–120868). Unbound new signal Via objects do
not provide that key reliably. The proposed real-port paths avoid depending on
this deduplication contract.

A pure append-only prototype, `clock-source-overlay.tsx`, adds two new six-port
carrier traces and preserves all existing source props. It cannot qualify the
original clock bus lengths: reviewed checks 0.0.242 groups PCB traces by their
direct `source_trace_id` (`getPcbTracesBySourceTraceId`, line 5971), rather than
walking the connected source graph. The original `DDR_CK`/`DDR_CKn` bus members
would then lack their carrier lengths. This prototype is preserved for inspection.

The recommended fidelity successor is `clock-fidelity-source-overlay.tsx`.
It keeps all original logical `from`/`to`, trace names, 49 requests, bus/pair
membership and limits. It adds four real ports, assigns three PCB paths to each
of the original two clock traces, and omits physical PCB rendering on only the
four unrendered local-clock Top prototype branches. Those four source branches
remain declared; their exact Top copper is now rendered under the original
clock IDs, once each. This changes six elements through eight PCB-only property
deltas. No original file is modified.

The proposed literal count is **2,232**: 2,228 preserved definitions plus four
real layer ports. Expected physical counts are **225 vias, 263 PCB traces,
1,161 SMT pads and 280 real parts**. The 263 traces comprise the 165 original
reference paths, 92 other Top signal stubs and six clock paths (four Top stubs,
two Inner1 carriers). Original 98 named source nets and eight buses remain.
New manual clock paths can change generated PCB trace numbering; qualification
must prove a complete bijection by original source IDs and geometry instead of
assuming generated PCB IDs stay unchanged. Frozen evidence remains untouched.

`capture-clock-fidelity-source.ts` checks the actual React tree, then inversely
removes precisely four ports and the six PCB-only element changes to recover
all 2,228 original definitions, including types, normalized React keys, props
and child order. `render-clock-fidelity-core.ts` registers the
real ports and runs one direct pinned Core render with schematic and automatic
routing disabled. It preserves raw Core before checking inventory, original
numeric clock IDs, three physical paths per clock, Inner1 geometry and full
planar length including Top stubs. It also checks exact bijections for all 129
old reference barrels and 165 reference wires, single instances of all 96 new
signal barrels and 96 Top stubs, real Inner1 endpoint-port attachment, all 49
original logical trace rows, all eight original bus rows, all 98 named net
identities/definitions and the original two NPTH/four plated-hole physical
shapes. These controls
have not executed. Binary floating-point differences introduced
by relative coordinate transformation are reported and bounded by 1e-9 mm;
width, layer, point count and source identities remain exact.

Native qualification must additionally call the original clock bus length
functions, prove both original numeric CPU/RAM connections through the actual
barrels, preserve all reference and signal fanout geometry, and run the full
manufacturing checks. Source/Core controls do not replace those checks. Fresh
KiCad 10 connectivity and serializer checks remain required. Clock via primitives
are absent from the three paths, while the physical connection still uses two
existing full-span barrels; report physical transitions separately rather than
claiming the route has zero transitions. The historical 1.6 mm transition model
is not an electrical delay qualification.

The untouched Native `getPcbTraceLength` function (reviewed checks line 5943)
adds its historical 1.6 mm only for an explicit `route_type:"via"` point. It
does not add a barrel's height merely because two different-layer path endpoints
share that existing physical barrel. Native aggregation of these three manual
wire paths will therefore see the complete planar copper, while the physical
connection uses two Top-to-Inner1 transitions. Keep these metrics separate.
Adding fake via markers to force the length would create extra holes in this
Core implementation and is not part of the proposal. Independent physical-path
and electrical-delay qualification remains mandatory.

Nothing here qualifies all 49 DDR routes, full-cohort matching, reference planes,
impedance, PDN, other board nets or shell fit. `fabricationReady=false`.

Root should run pure Source capture first, then the direct Core worker, only
within its existing process/resource guard and after it authorizes the
corresponding step. The worker flags are `G350_CLOCK_FIDELITY_SOURCE_APPROVED=1`
and `G350_CLOCK_FIDELITY_CORE_APPROVED=1`; they are internal scheduling gates,
not requests for additional user permission. Source `cloud/env.sh` before either
invocation. Both workers require fresh exclusive output paths. Neither worker
performs the independent native or CAD qualification.

```bash
source cloud/env.sh
G350_CLOCK_SOURCE_RUN="$(mktemp -d .cloud-tools/ddr-package101-signal96-clock-v11-source-contract-next/run-root-XXXXXX)"
G350_CLOCK_FIDELITY_SOURCE_APPROVED=1 bun \
  .cloud-tools/ddr-package101-signal96-clock-v11-source-contract-next/capture-clock-fidelity-source.ts \
  "$G350_CLOCK_SOURCE_RUN/source-capture.json"
G350_CLOCK_FIDELITY_CORE_APPROVED=1 bun \
  .cloud-tools/ddr-package101-signal96-clock-v11-source-contract-next/render-clock-fidelity-core.ts \
  "$G350_CLOCK_SOURCE_RUN/raw-core.json" "$G350_CLOCK_SOURCE_RUN/core-controls.json"
```

Root must collect the successful Source capture before authorizing Core. The
commands above must remain separate guarded steps. Frozen old source737/source836
and all earlier V11/API failures stay untouched.
