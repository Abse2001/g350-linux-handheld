def closed56():
  prior=closed55();assert prior['actualClosedScopeCount']==55
  for key in('actual56CollectionPin','actual56PostauditPin','actual56ReportPin','actual56ExportPin','actual56AuthorityPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  r=read(proposal['actual56CollectionPin']['path']);p=read(proposal['actual56PostauditPin']['path']);v=read(proposal['actual56ReportPin']['path']);e=r['execution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==proposal['actual56ToolSessionId'] and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE29_FRESH_PINNED_CLI_WITH55_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cli'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual56GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual56PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['execution']==e
  for doc in(r,p):
   for key in('passed','resultPassed','stageNaturallyCompleted','ownedChildNatural0','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['cliCalls']==1 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(e,0);assert e['policy']==cli29_policy and e['pid']==e['pgid']==proposal['actual56Pgid'] and e['currentGuardPid']==proposal['actual56GuardPid'] and c.guard.process_scope.owned(proposal['actual56Pgid'])==[]and not Path('/proc',str(proposal['actual56GuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert e['command']==[cli29_contract['pythonInterpreterPin']['path'],'-B',cli29_contract['cliWorkerPin']['path'],'--root-receipt',proposal['actual56AuthorityPin']['path'],'--root-receipt-sha256',proposal['actual56AuthorityPin']['sha256'],'--output-directory',str(Path(proposal['actual56ExportPin']['path']).parent)]
  assert r['reportPath']==p['reportPath']==proposal['actual56ReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual56ReportPin']['sha256']and r['exportPath']==p['exportPath']==proposal['actual56ExportPin']['path']and sha(r['exportPath'])==r['exportSha256']==p['exportSha256']==proposal['actual56ExportPin']['sha256']
  assert r['actualCoreSha256']==p['actualCoreSha256']==v['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==v['coreControlsSha256']==proposal['actual53CoreControlsPin']['sha256']
  assert v['scope']==cli29_preparation['scope']and v['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and v['exportPassed']is v['byteIdenticalCopyOnly']is v['nativeAndOriginalApiStagesPassed']is True and v['cliExitCode']==0
  assert v['recognizedCircuitJsonSha256']==proposal['actual53CoreRawPin']['sha256']and v['outputPath']==proposal['actual56ExportPin']['path']and v['outputSha256']==proposal['actual56ExportPin']['sha256']and v['actualSourceSegmentCount']==1053 and v['actualSourceOwnedCarrierCount']==29 and v['actualPhysicalViaCount']==227 and v['actualPhysicalTraceCount']==292 and v['sourceOnlyMissingRoutes']==20
  assert v['actualNativeReport']==proposal['actual54ReportPin']and v['actualOriginalApiReport']==proposal['actual55ApiReportPin']
  assert v['argv']==[cli29_preparation['bun'],'--smol',cli29_preparation['cliMainPath'],'export',str(Path(proposal['actual56ExportPin']['path']).parent/'fresh-source29.circuit.json'),'--format','kicad_pcb','--output',proposal['actual56ExportPin']['path'],'--disable-parts-engine']
  for key in('originalRawEdited','sourceModuleEvaluated','sourcePortHookReplayedByCli','automaticCoreSrjUsed','complete29Accepted','referenceQualified','electricalTimingQualified','accepted49','fabricationReady'):assert v[key]is False
  for row in p['outputFiles']:binding(row)
  prior['actual56Source29CliSuccessCollectionPin']={'path':proposal['actual56CollectionPin']['path'],'sha256':proposal['actual56CollectionPin']['sha256']};prior['actualClosedScopeCount']=56;prior['actual56CliDoesNotQualifyFreshCadOrFull49']=True
  return prior
