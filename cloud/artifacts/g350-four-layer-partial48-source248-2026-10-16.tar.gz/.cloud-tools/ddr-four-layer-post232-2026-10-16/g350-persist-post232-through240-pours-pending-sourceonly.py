#!/usr/bin/env python3
"""Append closed239/240 and two bounded Source236 pour reports, own stdlib only.

No SDK or application imports. Mutations are confined to the NEW post232 saved
directory; the initial collection and all older saved workspaces stay verifiable.
Neither a 48-path result nor whole-pour qualification is inferred here.
"""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat

ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post232-2026-10-16'
OLD = ROOT / '.cloud-tools/ddr-four-layer-post209-2026-10-16'
INITIAL = {
    'README.md': 'e809d4d53fbf06f03bf8e1b85566a67fe51df36d730d26f751f347f985d48c7d',
    'PROGRESS.json': 'b5d30a6a994fa08e0233e3f64281efbc712f5215e847374a7280f4c78d41add3',
    'WORKSPACE_RESTORE_MANIFEST.json': 'd8f94fd67308f55a275886760f58ecb73161f71f0399b6f291ed4bcb9d7678d7',
    'WORKSPACE_HASH_INDEX.json': '5a1302d61df44e0ea04086ef326b212d649743d01774fd96232d54a3f669c9c7',
}
OLD_PINS = {
    'WORKSPACE_HASH_INDEX.json': '809a4437af0306c37aa759044131fbaa9939032244284705c31a3910d339a83d',
    'WORKSPACE_RESTORE_MANIFEST.json': 'd8a8ebdc11a3900affe120fdd70c946403c4e26bf9b7b02bd9a1088a98369cef',
    'PROGRESS.json': 'fac4424b0ca0fe1b74fc640687a0567b7b3264267a65da5acfff5eb9091b5ef0',
}
PINS = {
    '/tmp/g350-joint48-cap12-root-20261016-run239/COLLECTED.json': '652bb40c56261fda2718ba9d277804002e3983b5a6a19812ee60eae3a0af0f65',
    '/tmp/g350-joint48-cap12-root-20261016-run240/COLLECTED.json': 'c9b4b6223a3f837eae351f2493a656b2e021a273022610e12f430f949ecf03b7',
    '/tmp/g350-joint48-cap12-root-20261016-run240/byte0-result.json': '579a0c8b3dbe6b3a174d1913a83750406f326d01204107ba2bc0258f7d1bc151',
    '/tmp/g350-actual223-deterministic48-joint1-30-cap12point79-twoRAM14-32-v2-topology-sourceonly.ts': '65850dd86fc9f4a7f6b499ff616c1d94b4849b3640561b4d86682a6974224f50',
    '/tmp/g350-actual223-deterministic48-joint1-30-cap12point79-twoRAM14-32-v3-topology-sourceonly.ts': '485a4c5b924070365450c1b9f2987c6f23784b0ef43110b299d59365e76600c0',
    '/tmp/g350-actual223-deterministic48-joint1-30-cap12point79-twoRAM14-32-v3a-topology-sourceonly.ts': '2a18fac18cfb3751ff388e6b7a484ec0042e87796b91ee9c56b9e275ada867a6',
    '/tmp/g350-source236-all15-literal-pour-margin-root-20261016.json': '0e2f67dc304884dd334001464303e6e2155665f119df9c8909d2b38f691745ab',
    '/tmp/g350-source236-selected94-literal-pour-margin-root-20261016.json': '0f6d3eb46af29e0eeccea14ce138e75a3db98ad17220653b60f392008f470aa9',
    '/tmp/g350-partial47-plan234-source236-literal-selected-pour-clearance-audit-sourceonly.py': '68d33314f2a984e1c260d4f2bca7b04eb9b7370135a5ff1befd354b1604878d5',
}
RAW_SHA = 'd49c3d6f8661527cf007d3676d6cdae7f9fcec99535373997c6adda8705dc18d'
CTRL_SHA = 'b618de34ab2c681f53f9422cd06916471db95fda97772e16754a814541546563'
AUTH_SHA = '05ef57bc48db7d5cb2bcc012fa584143d037fdecbf1f6fb55d89be57da0f9997'
PLAN_SHA = '0e3757ae6e367158090a2f14dbaf20f9f57422576d89ee2ca1acfa6c77ef1707'
POURS = ['pcb_copper_pour_' + str(i) for i in (0,22,23,30,37,38,39,48,71,74,80,81,83,87,94)]


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
        if hasattr(os, 'posix_fadvise'):
            os.posix_fadvise(stream.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return h.hexdigest()


def read(p):
    with p.open('rb') as stream:
        return json.load(stream)


def regular(p):
    return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)


def safe(p):
    denied = ('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT', 'AUTHORITY_PACKET')
    return (p.is_absolute() and str(p).startswith('/tmp/g350-') and p.resolve().is_relative_to('/tmp')
            and not any(part in str(p).upper() for part in denied))


def metadata(p):
    s = p.stat()
    return {'bytes': s.st_size, 'sha256': digest(p), 'mode': stat.S_IMODE(s.st_mode)}


def verify_rows(folder, rows):
    for row in rows:
        p = folder / row['path']
        require(regular(p) and metadata(p) == {k: row[k] for k in ('bytes', 'sha256', 'mode')}, 'Saved bytes/mode changed: ' + str(p))


def verify_old():
    for name, pin in OLD_PINS.items():
        require(digest(OLD / name) == pin, 'Frozen post209 metadata changed')
    verify_rows(OLD, read(OLD / 'WORKSPACE_HASH_INDEX.json')['files'])


def atomic_json(name, value):
    p = SAVED / name
    temp = SAVED / ('.append240-' + name + '.tmp')
    with temp.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        os.fchmod(stream.fileno(), 0o600)
    os.replace(temp, p)


def main():
    require(SAVED.is_dir() and not SAVED.is_symlink(), 'Existing new post232 directory required')
    for name, pin in INITIAL.items():
        require(digest(SAVED / name) == pin, 'Expected immutable initial through238 metadata')
    before_index = read(SAVED / 'WORKSPACE_HASH_INDEX.json')
    verify_rows(SAVED, before_index['files'])
    verify_old()
    for name, pin in PINS.items():
        require(safe(Path(name)) and regular(Path(name)) and digest(Path(name)) == pin, 'Exact closed public input required: ' + name)
    manifest = read(SAVED / 'WORKSPACE_RESTORE_MANIFEST.json')
    progress = read(SAVED / 'PROGRESS.json')
    require(progress['latestClosedScopeIncluded'] == 238 and progress['primaryCandidate']['routedOwners'] == 47
            and progress['primaryCandidate']['candidateSha256'] == '71bbec7babdeabda657ba1b2be75d35f5d7210d5a53d55cd2fc2b279ffb0d17b', 'Exact current23347 snapshot required')
    primary = copy.deepcopy(progress['primaryCandidate'])
    require(primary['literalPourAuditPending'] is True and primary['literalPourClearanceQualified'] is False
            and primary['prior228PourPassInherited'] is False, 'No existing combined pour qualification')
    # Preserve all four exact initial metadata files as history before replacing
    # the appendable metadata. No original payload is overwritten.
    for name in INITIAL:
        dest = SAVED / ('HISTORY_THROUGH238_' + name)
        require(not dest.exists(), 'Append history must be fresh')
        with (SAVED / name).open('rb') as reader, dest.open('xb') as writer:
            shutil.copyfileobj(reader, writer, 1024 * 1024)
            os.fchmod(writer.fileno(), stat.S_IMODE((SAVED / name).stat().st_mode))
        require(digest(dest) == INITIAL[name], 'Exact initial metadata history')
    targets = {r['restorePath']: copy.deepcopy(r) for r in manifest['files']}
    bases = {r['restorePath']: copy.deepcopy(r) for r in manifest['baseDependencyRestoreFiles']}
    base_catalog = {}
    for folder in (ROOT / '.cloud-tools/ddr-four-layer-manual-2026-10-16', OLD):
        for r in read(folder / 'WORKSPACE_RESTORE_MANIFEST.json')['files']:
            base_catalog[r['restorePath']] = {'baseSavedDirectory': folder.relative_to(ROOT).as_posix(), **r}
    inputs = {}

    def save(p, name=None, force=False):
        p = Path(p)
        require(safe(p) and regular(p), 'Only public regular sources: ' + str(p))
        s = p.stat()
        rowdata = metadata(p)
        inputs[str(p)] = rowdata
        if str(p) in targets:
            require(rowdata == {k: targets[str(p)][k] for k in rowdata}, 'Existing restore target changed')
            return targets[str(p)]
        old = base_catalog.get(str(p))
        if not force and old and rowdata == {k: old[k] for k in rowdata}:
            bases[str(p)] = copy.deepcopy(old)
            return old
        dest = SAVED / (name or p.name)
        require(dest.parent == SAVED, 'Flat safe saved filename')
        if dest.exists() and metadata(dest) != rowdata:
            dest = dest.with_name(dest.stem + '__' + rowdata['sha256'][:16] + dest.suffix)
        if not dest.exists():
            with p.open('rb') as reader, dest.open('xb') as writer:
                shutil.copyfileobj(reader, writer, 1024 * 1024)
                os.fchmod(writer.fileno(), rowdata['mode'])
        require(metadata(dest) == rowdata, 'Saved source bytes/mode')
        after = p.stat()
        require((s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns) ==
                (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'Public source changed during copy')
        r = {'savedPath': dest.name, 'restorePath': str(p), **rowdata}
        targets[str(p)] = r
        return r

    additions = []
    sources = set()
    for scope in (239, 240):
        folder = Path('/tmp/g350-joint48-cap12-root-20261016-run' + str(scope))
        c = read(folder / 'COLLECTED.json')
        e = read(folder / 'owned/execution.json')
        require(c['scope'] == scope and c.get('closedAt') and c['sourcePinsUnchanged'] is True
                and c['protectedFilesUnchanged'] is True and c['all49Accepted'] is False, 'Exact closed nonaccepting scope')
        if scope == 239:
            require(c['execution'] is None and e['exitCode'] is None and e['diagnosticStopped'] is True
                    and e.get('guardError') == 'AssertionError' and 'pid' not in e, '239 stopped at memory admission; no runtime')
            outcome = 'MEMORY_ADMISSION_REFUSED_NO_CHILD_RUNTIME'
        else:
            r = read(folder / 'byte0-result.json')
            require(c['execution']['exitCode'] == 2 and r['terminalOutcome'] == 'EXCEPTION_NO_ACCEPTANCE'
                    and r['attempts'] == [] and r['retained'] == []
                    and 'Actual cap12 identity/placement and all280 parts required' in r['error'], '240 stopped at raw component-count guard before routing')
            outcome = 'RAW_COMPONENT_COUNT_GUARD_FAILED_BEFORE_GEOMETRY_SEARCH'
        label = 'CAP12_TOPOLOGY' + str(scope) + '_NO_GEOMETRY_RESULT'
        save(folder / 'COLLECTED.json', label + '_COLLECTED.json', True)
        for p in sorted(folder.glob('byte0-result*.json')):
            save(p, label + '_' + p.name, True)
        for filename in ('child.log', 'execution.json', 'memory.jsonl'):
            p = folder / 'owned' / filename
            if regular(p):
                save(p, label + '_owned_' + filename, True)
        worker = Path(e['command'][1])
        save(worker, force=True)
        sources.add(worker)
        for arg in e['command'][2:]:
            p = Path(arg)
            if str(arg).startswith('/tmp/g350-') and regular(p):
                save(p, 'INPUT_' + label + '_' + p.parent.name + '_' + p.name)
                for sibling in ('proof.json', 'contacts.json'):
                    q = p.parent / sibling
                    if regular(q):
                        save(q, 'INPUT_' + label + '_' + q.parent.name + '_' + q.name)
        additions.append({'scope': scope, 'closedAt': c['closedAt'], 'terminalOutcome': outcome,
                          'exitCode': e['exitCode'], 'childRuntimeExecuted': scope == 240,
                          'geometryRoutingExecuted': False, 'inheritedDiagnosticArraysAreFreshEvidence': False,
                          'newConnectedOwnerCount': None, 'all49Accepted': False, 'fabricationReady': False})
    for name in PINS:
        row = save(Path(name), force=True)
        if Path(name).suffix in ('.py', '.ts', '.tsx'):
            sources.add(Path(name))
    save(Path(__file__), force=True)
    visited = set()
    for _ in range(3):
        next_sources = set()
        for p in sorted(sources - visited):
            visited.add(p)
            for value in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]", p.read_text()):
                q = Path(value)
                if safe(q) and regular(q):
                    save(q)
                    if q.suffix in ('.py', '.ts', '.tsx', '.mjs'):
                        next_sources.add(q)
        sources |= next_sources
    first = read(Path('/tmp/g350-source236-all15-literal-pour-margin-root-20261016.json'))
    retry = read(Path('/tmp/g350-source236-selected94-literal-pour-margin-root-20261016.json'))
    for d in (first, retry):
        require(d['auditSourceSha256'] == PINS['/tmp/g350-partial47-plan234-source236-literal-selected-pour-clearance-audit-sourceonly.py']
                and d['inputBindings']['raw']['sha256'] == RAW_SHA
                and d['inputBindings']['controls']['sha256'] == CTRL_SHA
                and d['inputBindings']['current227Ownership']['sha256'] == AUTH_SHA
                and d['inputBindings']['reviewedSourcePlan234']['sha256'] == PLAN_SHA
                and d['actualRawPourIds'] == POURS and d['wireScope'] == 'all-routed'
                and len(d['wireOriginalOwners']) == 47 and d['actualViaCount'] == 227
                and d['inputFilesUnchanged'] is True and not d['violations']
                and not d['globalIdentityFailures'] and not d['viaIdentityFailures'], 'Exact Source236 same-scene bounded pour reports')
    require(first['completed'] is False and len(first['pourReports']) == 15
            and [r['pcbCopperPourId'] for r in first['pourReports'] if r['state'] == 'COMPLETED'] == POURS[:-1]
            and first['pourReports'][-1]['state'] == 'BOUNDED_PARTIAL', 'First report14 completed/last94 bounded')
    require(retry['completed'] is True and retry['selectedPourIds'] == [POURS[-1]]
            and retry['literalForeignPourMarginClear'] is True and len(retry['pourReports']) == 1
            and retry['pourReports'][0]['state'] == 'COMPLETED', 'Selected94 retry completed independently')
    evidence = {'scope': 'TWO_SAME_SCENE_BOUNDED_REPORTS_COVERAGE_COMBINER_PENDING',
                'auditSource': copy.deepcopy(targets['/tmp/g350-partial47-plan234-source236-literal-selected-pour-clearance-audit-sourceonly.py']),
                'firstReport': copy.deepcopy(targets['/tmp/g350-source236-all15-literal-pour-margin-root-20261016.json']),
                'selected94Retry': copy.deepcopy(targets['/tmp/g350-source236-selected94-literal-pour-margin-root-20261016.json']),
                'firstCompletedPourIds': POURS[:-1], 'retryCompletedPourIds': POURS[-1:],
                'wholeCoverageCombinerPassed': False, 'literalPourClearanceQualified': False,
                'prior228PourPassInherited': False, 'all49Accepted': False, 'fabricationReady': False}
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    progress['updatedAt'] = now
    progress['scope'] = 'Separate post232 evidence through closed240; primary233 remains47; whole-pour combiner pending'
    progress['latestClosedScopeIncluded'] = 240
    progress['closedExperiments'].extend(additions)
    progress['literalPourBoundedEvidence'] = evidence
    progress['correctedTopologySourcesSavedWithoutRuntimeClosure'] = [copy.deepcopy(targets[n]) for n in PINS if '-v3' in n]
    progress['appendCollector'] = str(Path(__file__))
    progress['initialThrough238MetadataPins'] = INITIAL
    require(progress['primaryCandidate'] == primary, 'Current23347 primary/qualification flags unchanged')
    manifest['updatedAt'] = now
    manifest['files'] = sorted(targets.values(), key=lambda r: r['restorePath'])
    manifest['baseDependencyRestoreFiles'] = sorted(bases.values(), key=lambda r: r['restorePath'])
    manifest['literalPourBoundedEvidence'] = evidence
    progress['publicBaseRestoreDependencies'] = copy.deepcopy(manifest['baseDependencyRestoreFiles'])
    for name, rowdata in inputs.items():
        require(metadata(Path(name)) == rowdata, 'Collected public input changed')
    for name, pin in PINS.items():
        require(digest(Path(name)) == pin, 'Pinned input changed at closure')
    # Verify original immutable payloads, excluding just the three appendable
    # metadata files and README, before updating the metadata index.
    verify_rows(SAVED, [r for r in before_index['files'] if r['path'] not in INITIAL])
    verify_old()
    atomic_json('WORKSPACE_RESTORE_MANIFEST.json', manifest)
    readme = (SAVED / 'README.md').read_text()
    readme += """

Append through closed240:239 was refused by shared-memory admission with no
child runtime.240 stopped at the raw component-count guard before geometry
search; its inherited diagnostic arrays do not establish fresh qualification.
No48-path result is claimed. Exact v2/v3/v3a worker bytes are preserved; no v3
runtime closure is included in this append.

The two same-Source236 pour reports are preserved: the first completed14 pours
and bounded before finishing94; the separate94 retry completed. Whole-pour
qualification REMAINS PENDING until the independently reviewed coverage combiner
passes. No Source228 pour pass is inherited. Initial through238 metadata is
preserved byte-for-byte under HISTORY_THROUGH238_*.
"""
    temp = SAVED / '.append240-README.tmp'
    with temp.open('x') as stream:
        stream.write(readme)
        os.fchmod(stream.fileno(), 0o600)
    os.replace(temp, SAVED / 'README.md')
    excluded = {'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
    progress['artifacts'] = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir()) if regular(p) and p.name not in excluded]
    atomic_json('PROGRESS.json', progress)
    rows = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir()) if regular(p) and p.name != 'WORKSPACE_HASH_INDEX.json']
    atomic_json('WORKSPACE_HASH_INDEX.json', {'scope': 'Post232 through240; current23347, whole-pour combiner pending',
                'updatedAt': now, 'files': rows, 'selfExcluded': True, 'all49Accepted': False, 'fabricationReady': False})
    verify_rows(SAVED, rows)
    for r in manifest['files']:
        require(metadata(SAVED / r['savedPath']) == {k: r[k] for k in ('bytes', 'sha256', 'mode')}, 'Restore payload mismatch')
        require(metadata(Path(r['restorePath'])) == {k: r[k] for k in ('bytes', 'sha256', 'mode')}, 'Restore target mismatch')
    verify_old()
    print(json.dumps({'savedDirectory': str(SAVED), 'savedFiles': len(list(SAVED.iterdir())),
          'indexedFiles': len(rows), 'restoreTargets': len(manifest['files']),
          'baseDependencies': len(manifest['baseDependencyRestoreFiles']), 'latestClosedScope': 240,
          'currentRoutedOwners': 47, 'wholePourQualificationPending': True, 'all49Accepted': False,
          'metadataHashes': {n: digest(SAVED / n) for n in INITIAL}}, indent=2))


if __name__ == '__main__':
    main()
