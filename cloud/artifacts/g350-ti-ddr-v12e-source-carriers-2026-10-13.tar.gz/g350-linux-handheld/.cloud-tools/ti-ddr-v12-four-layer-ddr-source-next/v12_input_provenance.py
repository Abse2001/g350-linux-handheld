"""Pure V12 authored layer-policy bridge, with reference redesign still pending.
No Core/native/checker/router/CAD call. Existing2312 geometry/17 placement checks
are inherited, not a check of four-signal-layer reference compatibility.
"""
from pathlib import Path
import hashlib, json, stat, copy, importlib.util, sys
sys.dont_write_bytecode = True
ROOT=Path(__file__).resolve().parent
V11=Path('/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v11-ca-byte1-top-layer-bridge-next')
V11_MANIFEST='44623c2a94deaf8f4629528a72577c3098208f8cb96d0112cb494713791fb5a8'
V11_MODULE='ccf1c73a8e3d0bc42183d65972998a39be2cb735b716b081efbe998164bf1b6e'
V11_CAPTURE=Path('/workspace/bus-lanes-solver/.cache/g350-ti-v11-public-error-capture-next/error-capture-qualification/final-v11-authored-props.json')
V11_CAPTURE_SHA='f2b4de73f91e612a2fe63a695461b8df905ef7d7516d3bc17913c06903f2af48'
V11_FINAL=Path('/workspace/bus-lanes-solver/.cache/g350-ti-v11-public-error-capture-build-lifecycle-next/FINAL-manifest.json')
V11_FINAL_SHA='e8b1f4b9bc71a79707614558df8fe7271a195f996c2f9c388980042af4992538'
INPUT_SHA='3f002d2978f46f21e8a5b4e957815a05db566f4c5f52379398a9bc7ed838e7ce'
LAYERS=['top','inner1','inner2','bottom']
PREFERENCES={'DDR_RESET':['inner2','inner1','bottom','top'],'DDR_BYTE0':['inner2','inner1','bottom','top'],'DDR_BYTE1':['inner1','inner2','top','bottom'],'DDR_COMMAND_CLOCK':['inner1','inner2','top','bottom']}
def require(v,s):
    if not v: raise ValueError(s)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_bytes())
def verify_rows(base,rows):
    for row in rows:
        p=Path(row['path']) if base is None else base/row['path']
        require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Binding changed: '+str(p))
def verify(expected_manifest_sha256):
    require(sha(ROOT/'SOURCE-INPUT-manifest.json')==expected_manifest_sha256,'Exact frozen V12 source-policy manifest required')
    manifest=load(ROOT/'SOURCE-INPUT-manifest.json');verify_rows(ROOT,manifest['files']);verify_rows(None,manifest['externalFiles'])
    require(sha(V11/'v11_input_provenance.py')==V11_MODULE,'Frozen independent V11 source/input binder changed')
    spec=importlib.util.spec_from_file_location('g350_frozen_v11_source_bridge',V11/'v11_input_provenance.py');v11=importlib.util.module_from_spec(spec);spec.loader.exec_module(v11)
    inherited=v11.verify(V11_MANIFEST)
    require(sha(V11_CAPTURE)==V11_CAPTURE_SHA and sha(V11_FINAL)==V11_FINAL_SHA,'Actual V11 final props/frozen qualified producer changed')
    actual_v11=v11.verify_actual_authored_props(V11_CAPTURE)
    final=load(V11_FINAL);execution=final['inheritedActualReactExecution']
    require(final['inheritedActualReactCaptureSha256']==V11_CAPTURE_SHA and execution['exitCode']==0 and execution['diagnosticStopped'] is False and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values()),'Actual clean V11 pure React evaluation required')
    require(inherited['inputSha256']=='171ab7893fa92315e2b5ef39afb35145a5c4a6dff9b04ca45ec2afdc3f3babd5' and inherited['freshCircuitSha256']=='2312aa3be3feb3b95a25ea7df72d46344ce3837f4cbff4353872744f67c80613','Exact prior physical source/input required')
    require(sha(ROOT/'input.json')==sha(ROOT/'original-unrestricted-input.json')==INPUT_SHA,'Exact all4 broad counterpart bytes required; not old top/bottom ff2')
    require(sha(ROOT/'original-top-bottom-unrestricted-input.json')=='ff2eee3ce065e6264d6d9fa20b61a964f21fd3b13ed220f032a916807f076b60','Frozen historical top/bottom counterpart changed')
    before=load(V11/'input.json');expected=copy.deepcopy(before);expected['allowedLayers']=LAYERS
    for bus in expected['buses']:bus['allowedLayers']=LAYERS.copy();bus['preferredLayers']=PREFERENCES[bus['busId']]
    actual=load(ROOT/'input.json');require(actual==expected,'Only global/perbus allowed and preferred signal-layer lists may change')
    require(actual['layerCount']==4 and len(actual['connections'])==49 and len(actual['obstacles'])==856 and len(actual['traces'])==2,'Exact4/49/856/2 physical inventory required')
    policy=load(ROOT/'v12-layer-policy.json')
    require(actual['buses']==[g['nativeBus'] for g in policy['groups']] and policy['globalSignalLayers']==LAYERS and policy['naturalGenericDefaultCap']==800000,'Actual native policy differs from authored all4 authority')
    require(policy['referenceQualified'] is False and policy['TIplaneArrangement'] is False and policy['existingReferenceCopperCandidatesHeldNotProvenCompatible'] is True,'Reference compatibility must remain unqualified')
    before_props=load(V11_CAPTURE)['authoredPolicyProof'];props=copy.deepcopy(before_props)
    for group in props['groups']:group['pcbAllowedLayers']=LAYERS.copy();group['preferredLayers']=PREFERENCES[group['busId']]
    derived=load(ROOT/'derived-final-authored-props.json')
    require(derived['authoredPolicyProof']==props and derived['actualV11FinalPropsCaptureSha256']==V11_CAPTURE_SHA and derived['physicalGeometrySourceSha256']==inherited['freshCircuitSha256'],'Pure final V12 props must bind exact actual V11 source props and existing2312 geometry')
    for g,p in zip(policy['groups'],props['groups']):
        b=g['nativeBus'];require(p['busId']==b['busId'] and p['connections']==g['logicalConnections'] and p['pcbTraceWidth']==b['traceWidth'] and p['pcbAllowedLayers']==b['allowedLayers'] and p['preferredLayers']==b['preferredLayers'],'Source class membership/width/layers differ')
        for key in ['maxLengthSkew','minLength','maxLength']:require(p.get(key)==b.get(key),'Original planar matching/window changed: '+key)
    for key in ['referenceQualified','TIplaneArrangement','actualV12ReactEvaluationPerformed','newCoreBuildPerformed','newNativePlacementCheckPerformed','accepted49','fabricationReady']:require(derived[key] is False,'Pure source/reference readiness flag must be false: '+key)
    require(derived['globalSignalLayerProjection']==LAYERS and derived['naturallyDerivedGenericDefaultCap']==800000,'Source global4 projection/generic default differs')
    return {'scope':'PURE_V12_FOUR_SIGNAL_LAYER_SOURCE_BRIDGE_REFERENCE_REDESIGN_PENDING','inputSha256':INPUT_SHA,'unrestrictedInputSha256':INPUT_SHA,'freshCircuitSha256':inherited['freshCircuitSha256'],'physicalInputExactlyHeld':True,'physicalGeometryInputExactlyHeld':True,'onlyLayerListsChanged':True,'nativePlacementChecks':17,'nativePlacementErrors':0,'nativePlacementChecksInheritedNotRerun':True,'routingRequests':49,'obstacles':856,'fixedReferences':2,'signalLayersAllowed':LAYERS,'naturallyDerivedGenericDefaultCap':800000,'explicitSearchCapSupplied':False,'referenceQualified':False,'TIplaneArrangement':False,'referenceRedesignStillRequired':True,'actualV12ReactEvaluationPerformed':False,'actualFinalReactEvaluationRequiredBeforeMain':True,'captureScript':str(ROOT/'capture-v12-authored-props.ts'),'newCoreBuildPerformed':False,'nativeCoreOrRouterApiInvoked':False,'accepted49':False,'fabricationReady':False}
def verify_producer_inputs(producer_directory,expected_manifest_sha256):
    result=verify(expected_manifest_sha256);p=Path(producer_directory)
    require(sha(p/'input.json')==sha(p/'original-unrestricted-input.json')==INPUT_SHA,'Producer must use exact V12 all4 input/broad counterpart')
    return result
def verify_actual_authored_props(path):
    d=load(ROOT/'derived-final-authored-props.json')
    expected={'scope':'PURE_ACTUAL_V12_FINAL_REACT_PROPS_REFERENCE_UNQUALIFIED','actualFinalReactTreeEvaluated':True,'derivedProofSha256':sha(ROOT/'derived-final-authored-props.json'),'authoredPolicyProof':d['authoredPolicyProof'],'referenceCopperCandidates':d['referenceCopperCandidates'],'globalSignalLayerProjection':LAYERS,'naturallyDerivedGenericDefaultCap':800000,'referenceQualified':False,'TIplaneArrangement':False,'coreRenderCalled':False,'nativePlacementChecksInvoked':False,'routingSolverInstantiated':False,'accepted49':False,'fabricationReady':False}
    require(load(path)==expected,'Actual final V12 React capture differs from exact frozen source/reference-pending projection')
    return {'actualFinalReactTreeEvaluated':True,'captureSha256':sha(path),'derivedProofSha256':expected['derivedProofSha256'],'signalLayersAllowed':LAYERS,'naturallyDerivedGenericDefaultCap':800000,'referenceQualified':False,'TIplaneArrangement':False,'newCoreBuildPerformed':False,'newNativePlacementCheckPerformed':False,'accepted49':False,'fabricationReady':False}
