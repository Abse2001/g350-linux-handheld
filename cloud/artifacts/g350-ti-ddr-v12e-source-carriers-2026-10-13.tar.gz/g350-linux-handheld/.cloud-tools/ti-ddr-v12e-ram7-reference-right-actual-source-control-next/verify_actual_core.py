"""Pure actual fresh-Core/source-projection comparison after root runs the build.

This script neither builds Core nor calls native physics. It cannot qualify
placement, plane continuity or routing by itself.
"""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TOLERANCE_MM = 1e-7  # Original established V7/V8 forward source geometry tolerance.


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def equivalent(expected, actual, key='root'):
    if isinstance(expected, dict) and isinstance(actual, dict):
        require(expected.keys() == actual.keys(), 'Changed fields at ' + key)
        for field in expected:
            equivalent(expected[field], actual[field], key + '.' + field)
    elif isinstance(expected, list) and isinstance(actual, list):
        require(len(expected) == len(actual), 'Changed inventory/order at ' + key)
        for index, (first, second) in enumerate(zip(expected, actual)):
            equivalent(first, second, key + ':' + str(index))
    elif type(expected) in (int, float) and type(actual) in (int, float):
        require(math.isfinite(expected) and math.isfinite(actual) and abs(expected - actual) <= TOLERANCE_MM,
                'Changed coordinate/dimension at ' + key)
    else:
        require(expected == actual, 'Changed value at ' + key)


def verify(args):
    require(sha(args.actual_circuit)==args.actual_circuit_sha256,'Explicit actual fresh Core artifact hash required')
    original_path=ROOT/'inputs/proven-v10-actual-layout.circuit.json'
    require(sha(original_path)=='2312aa3be3feb3b95a25ea7df72d46344ce3837f4cbff4353872744f67c80613','Frozen actual V10 full board changed')
    require(args.actual_circuit.resolve()!=original_path.resolve(),'A new actual V12e Core output is required')
    original=json.loads(original_path.read_bytes());expected=copy.deepcopy(original);actual=json.loads(args.actual_circuit.read_bytes())
    changed_rows=[];owned={'pcb_component_131','pcb_component_280','pcb_component_281'}
    expected_vias={'pcb_via_0','pcb_via_1'};expected_traces={'source_trace_932','source_trace_933'}
    def shift_point(point):
        require(type(point.get('x')) in (int,float) and math.isfinite(point['x']),'Owned physical X missing')
        point['x']+=1.4
    for index,row in enumerate(expected):
        changed=False
        if row.get('pcb_component_id') in owned:
            if row['type']=='pcb_component':
                shift_point(row['center'])
                if 'display_offset_x' in row:row['display_offset_x']+=1.4
            elif row['type'] in ('pcb_port','pcb_smtpad','pcb_solder_paste'):shift_point(row)
            elif row['type']=='pcb_silkscreen_path':
                for point in row['route']:shift_point(point)
            elif row['type']=='pcb_silkscreen_text':shift_point(row['anchor_position'])
            elif row['type']=='pcb_courtyard_outline':
                for point in row['outline']:shift_point(point)
            elif row['type']=='cad_component':shift_point(row['position'])
            else:raise ValueError('Unsupported owned physical row type: '+row['type'])
            changed=True
        if row['type']=='pcb_via' and row['pcb_via_id'] in expected_vias:shift_point(row);changed=True
        if row['type']=='pcb_trace' and row['source_trace_id'] in expected_traces:
            for point in row['route']:shift_point(point)
            changed=True
        if changed:changed_rows.append({'index':index,'type':row['type']})
    require(len(changed_rows)==30,'Exact original cap/alias/artwork/stub physical records required')
    for kind in ('source_component','source_port','source_trace','source_net','source_bus','source_board','source_manually_placed_via','source_component_internal_connection'):
        old_rows=[r for r in original if r['type']==kind];new_rows=[r for r in actual if r['type']==kind]
        require(old_rows==new_rows,'Original logical/numeric identities changed: '+kind)
        if kind=='source_port':require(all(type(a.get('pin_number'))==type(b.get('pin_number')) for a,b in zip(old_rows,new_rows)),'Numeric pin types changed')
    old_metadata=[r for r in original if r['type']=='source_project_metadata'];new_metadata=[r for r in actual if r['type']=='source_project_metadata']
    require(len(old_metadata)==len(new_metadata)==1,'Exactly one generated filesystem metadata record required')
    require(set(new_metadata[0])=={'type','source_filesystem_md5_hash'} and isinstance(new_metadata[0]['source_filesystem_md5_hash'],str) and len(new_metadata[0]['source_filesystem_md5_hash'])==32 and all(c in '0123456789abcdef' for c in new_metadata[0]['source_filesystem_md5_hash']),'Malformed generated filesystem metadata')
    equivalent([r for r in expected if r['type']!='source_project_metadata'],[r for r in actual if r['type']!='source_project_metadata'],'actualFreshV12eExactlyRigidThreeObjectMove')
    require(len([r for r in actual if r['type']=='source_component'])==280 and len([r for r in actual if r['type']=='pcb_smtpad'])==1161 and len([r for r in actual if r['type']=='source_port'])==1165 and len([r for r in actual if r['type']=='pcb_component'])==282,'Original physical/source inventories changed')
    require(len([r for r in actual if r['type']=='pcb_trace'])==2 and len([r for r in actual if r['type']=='pcb_via'])==2,'Only original two reference stubs/vias permitted')
    require(not any(r['type']=='pcb_autorouting_error' for r in actual),'Actual routing-disabled source errors present')
    for via in [r for r in actual if r['type']=='pcb_via']:
        require(via['layers']==['top','inner1','inner2','bottom'] and via['from_layer']=='top' and via['to_layer']=='bottom' and via['outer_diameter']==.4572 and via['hole_diameter']==.254,'Original full-depth reference via dimensions/layers changed')
    raw_input=json.loads(args.actual_ddr_input.read_bytes());proposal_path=ROOT/'inputs/proposed-native-input-not-core-forwarded.json'
    require(sha(proposal_path)=='dc67beee6b0e901f914835cd0fe27fad0060066e3213001574a98eefb8c44fa8','Frozen proposal changed')
    equivalent(json.loads(proposal_path.read_bytes()),raw_input,'actualCoreProjectionMatchesBoundedSourceProposal')
    baseline_path=ROOT/'inputs/proven-v12d-input.json';require(sha(baseline_path)=='ff3de67bc83c036b7780561690806227b3981c9eee88920497c6a7e9889f56aa','Frozen V12d input changed')
    baseline=json.loads(baseline_path.read_bytes())
    for key in baseline:
        if key not in ('obstacles','traces'):equivalent(baseline[key],raw_input[key],'originalLimitsEndpointsClassesHeld.'+key)
    policy_path=Path('/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12d-byte0-top-reset-bottom-next/v12d-layer-policy.json');policy=json.loads(policy_path.read_bytes())
    require(raw_input['buses']==[g['nativeBus'] for g in policy['groups']] and raw_input['differentialPairs']==[g['nativePair'] for g in policy['pairs']],'Original four singleton cohorts and three pairs changed')
    require(raw_input['allowedLayers']==['top','inner1','inner2','bottom'] and raw_input['layerCount']==4 and len(raw_input['connections'])==49 and len(raw_input['obstacles'])==856 and len(raw_input['traces'])==2,'Original four-layer49/856/2 inventory changed')
    bridge_path=args.actual_ddr_input.parent/'authored-layer-policy-proof.json';bridge=json.loads(bridge_path.read_bytes())
    require(bridge['derivedMembershipAndSkewFromActualPinnedCoreSource'] is True and bridge['sourceBusDoesNotPersistLayersPreferencesOrAbsoluteWindows'] is True and bridge['finalAuthoredReactPropsUsedForLayerAndAbsoluteWindowBridge'] is True and bridge['policyAppliedAfterAllV9Wrappers'] is True and bridge['allocation']=={'top':11,'inner1':26,'inner2':11,'bottom':1},'Actual source/final authored props bridge missing')
    for field in ['referenceQualified','TIplaneArrangement','accepted49','fabricationReady']:require(bridge[field] is False,'Do not qualify reference/routing/readiness in projection')
    require(not args.output.exists(),'Fresh exclusive validated-input directory required');args.output.mkdir(parents=True)
    # Emit the actual new raw Core projection unchanged; the proposal served only
    # as the independent forward expectation, never as an adopted input.
    (args.output/'input.json').write_bytes(args.actual_ddr_input.read_bytes())
    unrestricted=copy.deepcopy(raw_input)
    for bus in unrestricted['buses']:bus['allowedLayers']=['top','inner1','inner2','bottom'];bus['preferredLayers']=['inner1','inner2','bottom','top']
    with (args.output/'original-unrestricted-input.json').open('x') as out:json.dump(unrestricted,out,indent=2);out.write('\n')
    report={'scope':'ACTUAL_FRESH_V12E_CORE_FORWARD_THREE_RIGID_X_PLACEMENT_OVERRIDES',
      'actualCircuitSha256':args.actual_circuit_sha256,'actualRawCoreDdrInputSha256':sha(args.actual_ddr_input),'heldOriginalActualV10CircuitSha256':sha(original_path),'heldOriginalV12dInputSha256':sha(baseline_path),'proposalUsedOnlyAsForwardExpectationSha256':sha(proposal_path),'layerPolicyAuthoritySha256':sha(policy_path),'actualAuthoredPolicyBridgeProofSha256':sha(bridge_path),'layerPolicyDerivedFromFinalAuthoredPropsAndActualCoreRoster':True,'layerPreferenceAndAbsoluteWindowsNotClaimedPresentInSourceBus':True,'changedPhysicalRows':changed_rows,'onlyOneCapAndTwoOwnedReferencesMovedRigidlyMm':{'x':1.4,'y':0},'allOriginal280Parts1161Contacts217LogicalConnectionsHeld':True,'all49OriginalCpuRamNumericContactIdsHeld':True,'allOtherPhysicalAndLogicalSourceFieldsExactlyHeldWithinOriginalTolerance':True,'freshSourceGeometryToleranceMm':TOLERANCE_MM,'emittedValidatedInputsUseActualRawCoreGeometry':True,'validatedInputRawBytesCopiedWithoutReserialization':True,'generatedSourceFilesystemMetadataBefore':old_metadata[0],'generatedSourceFilesystemMetadataAfter':new_metadata[0],'generatedSourceFilesystemMetadataClaimedUnchanged':False,'validatedInputSha256':sha(args.output/'input.json'),'validatedUnrestrictedInputSha256':sha(args.output/'original-unrestricted-input.json'),'nativePlacementChecksStillRequired':True,'nativeApiInvoked':False,'routingInputQualified':False,'referenceQualified':False,'TIplaneArrangement':False,'accepted49':False,'fabricationReady':False}
    with (args.output/'actual-source-validation.json').open('x') as out:json.dump(report,out,indent=2);out.write('\n')
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--actual-circuit',type=Path,required=True);parser.add_argument('--actual-circuit-sha256',required=True);parser.add_argument('--actual-ddr-input',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    report=verify(parser.parse_args());print(json.dumps({'actualForwardSourceProjectionPassed':True,'inputSha256':report['validatedInputSha256'],'nativePlacementChecksStillRequired':True,'accepted49':False}))
