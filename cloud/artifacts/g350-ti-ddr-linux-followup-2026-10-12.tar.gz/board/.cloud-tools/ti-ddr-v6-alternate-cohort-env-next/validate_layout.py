"""Pure current-source validator. No Circuit, CAD, router or process launch."""
import collections,copy,json,math
from pathlib import Path
LOGIC=('source_component','source_port','source_trace','source_net','source_bus','source_component_internal_connection')
GEOMETRY=('pcb_component','pcb_port','pcb_smtpad','pcb_plated_hole','pcb_hole','pcb_keepout','pcb_courtyard_outline','pcb_courtyard_circle','pcb_courtyard_rect')
ALLOWED={'C_DDR_CPU_13','C_DDR_CPU_16','C_DDR_CPU_19',*(f'C_DDR_RAM_{i}' for i in range(7,13))}

def require(v,message):
 if not v:raise ValueError(message)
def typed(x,t):return [e for e in x if e['type']==t]
def by_id(x,t):
 rows=typed(x,t);d={e[t+'_id']:e for e in rows};require(len(d)==len(rows),'Duplicate '+t);return d
def near(a,b):return type(a) in [int,float] and type(b) in [int,float] and math.isfinite(a) and math.isfinite(b) and abs(a-b)<1e-7

def rotate_point(p,old,new):
 a,b=p['x']-old['center']['x'],p['y']-old['center']['y'];r=math.radians(new['pcbRotation']-old['rotation'])
 return {**p,'x':new['pcbX']+a*math.cos(r)-b*math.sin(r),'y':new['pcbY']+a*math.sin(r)+b*math.cos(r)}
def expected_geometry(e,old,new):
 v=copy.deepcopy(e)
 if 'x' in v and 'y' in v:v=rotate_point(v,old,new)
 for k in ('center','position','anchor_position'):
  if isinstance(v.get(k),dict) and 'x' in v[k] and 'y' in v[k]:v[k]=rotate_point(v[k],old,new)
 for k in ('outline','points','route'):
  if isinstance(v.get(k),list):v[k]=[rotate_point(p,old,new) if 'x' in p and 'y' in p else p for p in v[k]]
 if v['type']=='pcb_component':
  v['rotation']=new['pcbRotation'];v['layer']=new['layer']
  for k,newk in [('display_offset_x','pcbX'),('display_offset_y','pcbY')]:
   if k in v:v[k]=new[newk]
 return v

def equivalent(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  require(set(a)==set(b),'Changed fields at '+path)
  for k in a:equivalent(a[k],b[k],path+'.'+k)
 elif isinstance(a,list) and isinstance(b,list):
  require(len(a)==len(b),'Changed list length '+path)
  for i,(v,w) in enumerate(zip(a,b)):equivalent(v,w,path+':'+str(i))
 elif type(a) in [int,float] and type(b) in [int,float]:require(near(a,b),'Changed number '+path)
 else:require(a==b,'Changed value '+path)

def validate_declarations(declarations):
 require(declarations==[
 {'name':'G350_TI_V2_INNER1_GND','layer':'inner1','net':'GND','clearanceMm':.12,'cutoutMarginMm':.12,'boardEdgeMarginMm':.35,'unbroken':False},
 {'name':'G350_TI_V2_INNER2_DDR_1V5','layer':'inner2','net':'DDR_1V5','clearanceMm':.12,'cutoutMarginMm':.12,'outline':[{'x':-18,'y':-10},{'x':18,'y':-10},{'x':18,'y':33},{'x':-18,'y':33}],'unbroken':False}], 'Invalid source-declared reference stack')

def validate(base,compiled,table,declarations):
 validate_declarations(declarations);require(set(table)==ALLOWED,'Cap move allowlist changed')
 require(all(p['layer']=='bottom' and p['pcbRotation'] in [0,180] for p in table.values()),'Invalid cap side/rotation')
 for t in LOGIC:require(typed(base,t)==typed(compiled,t),'Changed logical inventory '+t)
 require(len(typed(compiled,'source_component'))==len(typed(compiled,'pcb_component'))==280,'Require280 parts')
 require(len(typed(compiled,'source_port'))==len(typed(compiled,'pcb_port'))==len(typed(compiled,'pcb_smtpad'))==1161,'Require1161 physical contacts')
 ports=by_id(compiled,'source_port');traces=by_id(compiled,'source_trace');nets=by_id(compiled,'source_net')
 require(len(traces)==932 and len(nets)==98 and len(typed(compiled,'source_bus'))==8,'Changed932/98/8 inventory')
 active={p for t in traces.values() for p in t['connected_source_port_ids']};gndid=next(n for n,e in nets.items() if e['name']=='GND')
 grounds={p for t in traces.values() if gndid in t['connected_source_net_ids'] for p in t['connected_source_port_ids']}
 require(len(active)==1032 and len(grounds)==298,'Changed active1032/ground298 membership')
 grouped=collections.defaultdict(set)
 for p in typed(compiled,'pcb_port'):
  key=ports[p['source_port_id']].get('subcircuit_connectivity_map_key')
  if key:grouped[key].add(p['pcb_port_id'])
 memberships={n:grouped[e['subcircuit_connectivity_map_key']] for n,e in nets.items()}
 memberships.update({n:{p['pcb_port_id'] for p in typed(compiled,'pcb_port') if p['source_port_id'] in e['connected_source_port_ids']} for n,e in traces.items() if not e['connected_source_net_ids']})
 require(len(memberships)==217 and len(set().union(*memberships.values()))==1032 and len(memberships[gndid])==298,'Require217/1032/298 compiled membership')
 require(sum(e.get('name','').startswith('DDR_') for e in traces.values())==49,'Require49 logical DDR')
 require(not any(e['type'] in ['pcb_trace','pcb_via','source_autorouting_phase','pcb_autorouting_phase'] for e in compiled),'Forbidden traces/vias/routing phases imported')
 sc=by_id(base,'source_component');bc=by_id(base,'pcb_component');names={pid:sc[e['source_component_id']]['name'] for pid,e in bc.items()}
 for t in GEOMETRY:
  before=by_id(base,t);after=by_id(compiled,t);require(set(before)==set(after),'Changed physical IDs '+t)
  for ident,old in before.items():
   name=names.get(old.get('pcb_component_id'));expected=expected_geometry(old,bc[old['pcb_component_id']],table[name]) if name in table else old
   equivalent(expected,after[ident],ident)
 board=typed(compiled,'pcb_board');require(len(board)==1,'Requireone board');equivalent(typed(base,'pcb_board')[0],board[0],'pcb_board')
 require(board[0]['num_layers']==4 and near(board[0]['thickness'],1.6),'Require4 layers/1.6mm')
 for name,xy,r in [('U_SOC',(0,20),0),('U_RAM',(0,6),270)]:
  e=next(c for c in typed(compiled,'pcb_component') if sc[c['source_component_id']]['name']==name)
  require(near(e['center']['x'],xy[0]) and near(e['center']['y'],xy[1]) and e['rotation']==r and e['layer']=='top','CPU/RAM pose changed')
 powers={e['source_net_id']:e['name'] for e in nets.values()};pours=typed(compiled,'pcb_copper_pour');require(pours,'New references absent from source output')
 owners={(e['layer'],powers.get(e.get('source_net_id'))) for e in pours};require(owners=={('inner1','GND'),('inner2','DDR_1V5')},'Invalid compiled plane owners/layers')
 for e in pours:
  require(e.get('shape')=='brep' and e.get('brep_shape',{}).get('outer_ring',{}).get('vertices'),'Invalid reference geometry')
  if e['layer']=='inner2':
   points=e['brep_shape']['outer_ring']['vertices'];require(all(-18-1e-7<=p['x']<=18+1e-7 and -10-1e-7<=p['y']<=33+1e-7 for p in points),'DDR plane outside declared region')
 return dict(passed=True,components=280,physicalContacts=1161,activeContacts=1032,connections=217,gndContacts=298,ddrSignals=49,allowedMovedCaps=sorted(ALLOWED),planes=sorted([list(x) for x in owners]),referencePourPieces=len(pours),traces=0,vias=0,sourceLogicalRecordsUnchanged=True,onlyNineDeclaredCapMoves=True,sourcePlaneDeclarationsValid=True,actualRoutingVerified=False,actualBypassLoopsQualified=False,referenceContinuityQualified=False,electricalTimingQualified=False,fabricationReady=False)

def synthetic_control(base,table,declarations):
 """Synthetic ONLY for pure-validator controls; never an actual source artifact."""
 x=copy.deepcopy(base);sc=by_id(base,'source_component');bc=by_id(base,'pcb_component');names={pid:sc[e['source_component_id']]['name'] for pid,e in bc.items()}
 for i,e in enumerate(x):
  name=names.get(e.get('pcb_component_id'))
  if e['type'] in GEOMETRY and name in table:x[i]=expected_geometry(e,bc[e['pcb_component_id']],table[name])
 net={e['name']:e['source_net_id'] for e in typed(base,'source_net')}
 for i,d in enumerate(declarations):
  pts=d.get('outline',typed(base,'pcb_board')[0]['outline']);x.append({'type':'pcb_copper_pour','pcb_copper_pour_id':'SYNTHETIC_CONTROL_'+str(i),'shape':'brep','layer':d['layer'],'source_net_id':net[d['net']],'brep_shape':{'outer_ring':{'vertices':pts},'inner_rings':[]}})
 return x
