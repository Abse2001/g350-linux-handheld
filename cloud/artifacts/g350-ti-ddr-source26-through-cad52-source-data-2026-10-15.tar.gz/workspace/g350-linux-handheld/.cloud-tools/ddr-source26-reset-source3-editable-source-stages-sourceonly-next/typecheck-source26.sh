#!/usr/bin/env bash
set -euo pipefail
source /workspace/g350-linux-handheld/cloud/env.sh
[[ "${G350_RESET_SOURCE3_26_TYPES_ROOT_GUARDED:-}" == 1 ]]
cd /workspace/g350-linux-handheld
packet=/workspace/g350-linux-handheld/.cloud-tools/ddr-source26-reset-source3-editable-source-stages-sourceonly-next
exec "$G350_REPO_ROOT/.cloud-tools/node/bin/node" --max-old-space-size=4096 "$G350_REPO_ROOT/node_modules/typescript/bin/tsc" --noEmit --strict --target ES2020 --module ESNext --moduleResolution node --jsx react-jsx --resolveJsonModule --esModuleInterop --skipLibCheck --rootDir /workspace --types tscircuit,bun-types,node "$packet/source26.circuit.tsx" "$packet/capture-source26.ts" "$packet/render-source26-core.ts"
