Resume from latestSourceVerifiedCheckpoint: actual SOURCE257 has all49/49
numeric-connected DDR routes, with no pending owner. Its exact candidate253
passed all49 routing-model physical gates and both critical DQS1 views/all five
APIs. Source254 projection,255 capture/full literal+key inverse, fresh Core257
all35 controls, focused native258 physical10 and other requested geometry checks,
authenticated234-via check259, and all14 literal-pour foreign-margin checks PASS
their stated scopes. Two new net-declared PDN barrels have separate actual filled-
polygon local contact proofs. Root rendered and reviewed the four-layer PNG/SVG:
all49 routes are shown across Top/Inner1/Inner2/Bottom with no pending owner.
This checkpoint is FROZEN at closed259 plus the all14-pour and local PDN proofs
and reviewed plot. All later routing or Source experiments need a NEW folder.

Candidate after dependency restore: /tmp/g350-cpu-cycle-manual49-root-20261016-run253/byte0-result.candidate.json
SHA256 f76709a0c4cf1a19920b1e9361e7d5f994ee1671f975836f88d775e17651df87
Saved current candidate: byte0-result.candidate.json
Report: /tmp/g350-cpu-cycle-manual49-root-20261016-run253/byte0-result.json
Actual raw Source257: /tmp/g350-cap8-pdn49-core257-raw.json
SHA256 db3cc308c41304d57c37ca027de5bfa45379e149c1eb313940eed65050807d6d
Controls: /tmp/g350-cap8-pdn49-core-objloader-root-20261016-run257/byte0-result.json
Plan254: /tmp/g350-cap8-pdn49-projector-root-20261016-run254/byte0-result.json
Capture255: /tmp/g350-cap8-pdn49-capture-root-20261016-run255/byte0-result.json
Native258: /tmp/g350-cap8-pdn49-native-root-20261016-run258/byte0-result.json
Authenticated234-via result259: /tmp/g350-cap8-pdn49-via-track-root-20261016-run259/byte0-result.json
All14-pour aggregate: /tmp/g350-source257-all14-literal-pour-margin-root-aggregate-20261016.json
Local PDN contact proof: /tmp/g350-source257-new-pdn-annular-same-polygon-root-20261016.json
No Source248 or Source236 qualification is inherited.
All3 original cohort skew checks still FAIL: 6.655202281574553,
2.4000719198310776 and17.43870093419864mm. Full timing, electrical readiness,
TI/reference continuity, CAD, default promotion, all49 acceptance and fabrication
readiness remain FALSE.

The CPU2NE/CPU11SW branches, four body replacements, manual26 endpoint changes,
cap8 move and two planned PDN declarations each have exact inverse/proof records.
The two new PDN Source declarations now have actual Core257 via232/233,
manual Source232/233 and PCBcomponent512/513 identities, authenticated on all4
layers and real Source nets5/0. Latest253 foundation authority is the REPORT's
constructorFoundationDelta; the candidate's same-named inherited cap12 field is
preserved only as provenance. The plural requiredSourceHardwarePlacementDeltas
contains both actual cap12 and cap8 descriptors.

The fresh foreign-pour aggregate covers all14 actual BREP pours,234 vias and979
routed signal-wire segments at0.1016mm. Reference-wire geometry and own-net
reentry are excluded. The PDN proof retains fullNEW.2286mm-OD land disks inside
the respective filled islands. VDD has held full-land witnesses; GND has the
specifically authenticated site010 positive plated annular contact band outside
its drill, joined by the genuine Top reference to numericU_RAM.pin14. The older
c437/a7e83 overstrong fullHELDdisk negative is preserved, not edited or relabeled.
This proves two local contacts, not complete DDR reference-plane continuity,
electrical timing, TI stack compliance, or whole-board fabrication readiness.

Failed Core256 is preserved: it exited1 on OBJ asset loading and emitted no
raw/control geometry evidence. Core257 used exact1174 pinned OBJ loading with
the ORIGINAL b4a68fd/565628byte USBLC6 asset. That unchanged asset is saved as a
regular indexed payload with a separate immutableWorkspaceAssets row. The exact
original53901e8/3277419byte STEP asset is also saved, together with the prepared
df7e383 OBJ+STEP loader successor. That successor and STEP loading were NOT used
for Source257, and no later263/264 runtime or geometry qualification is included.
The legacy
saved-workspace helper restores only /tmp targets; it does NOT restore workspace
assets. A future portable archive must include this asset at its exact recorded
boardRelativePath, or an explicit byte/hash/mode checked copy must place it there
without overwriting differing local work. No loader or application file is edited.

The frozen post232 Source24848 checkpoint (all scoped checks+all14 pours) and its
INDEPENDENT Source233/23647-route CA13 timing fallback remain base dependencies.
No fallback geometry or qualification is combined with this Source257. Failed
Core247's loader exception remains preserved in that frozen dependency. Restore
Source209 -> Source228 -> Source248 before this new saved workspace; hashes and
exact byte/mode restore rows are recorded in WORKSPACE_RESTORE_MANIFEST.json.
The compatible helper is scripts/restore-g350-four-layer-routing-workspace.py
--saved-directory .cloud-tools/ddr-four-layer-post252-2026-10-16; --restore refuses
different existing bytes/modes. This collector does not run the supplied helper.

No older saved folder, archive, tracked application Source, cloud document or
commit is modified. Only this NEW post252 directory is written, using own stdlib.
SOURCE257_CAP12_CAP8_PDN_CONNECTED49_FOUR_LAYER_MILESTONE.png and.svg are the
exact Root-rendered/reviewed files; plot Source and all hashes are indexed.
Later Byte1 model/source experiments are independent. Closed260+ results and
their geometry are outside this frozen checkpoint and cannot inherit Source257
native/pour/contact qualification. Frozen post232, its failed247 receipt and all
prior payload archives remain unchanged.

The earlier c607 collector failed before metadata when an old dependency used
the current candidate alias filename. Root preserved its partial files in
.cloud-tools/ddr-four-layer-post252-failed-alias-save-2026-10-16; its exact Source and
profile are saved as failed provenance, not qualification. This v4 collector
reserves EVERY canonical alias before copying dependencies and writes each alias
fresh afterward. It never overwrites prior partial files or existing payloads.
