/** Local diagnostic only. No imports, constructor replacement or solver calls. */
"use strict"

const LIMITS = Object.freeze({ records: 2, attempts: 16, totalBytes: 2 * 1024 * 1024,
  copyNodes: 100000, copyDepth: 48, stringBytes: 1536 * 1024 })
const bytes = value => new TextEncoder().encode(value).byteLength
const own = (object, key, optional = false) => {
  if (!object || typeof object !== "object") throw Error("Own data object required")
  const descriptor = Object.getOwnPropertyDescriptor(object, key)
  if (!descriptor && optional) return undefined
  if (!descriptor || !("value" in descriptor)) throw Error("Own data field required: " + key)
  return descriptor.value
}
const number = value => {
  if (typeof value !== "number" || !Number.isFinite(value)) throw Error("Finite number required")
  return value
}
const point = value => [number(own(value, "x")), number(own(value, "y"))]
const samePoint = (a, b) => {
  const p = point(a), q = point(b)
  return p[0] === q[0] && p[1] === q[1]
}

// Preserve own undefined fields through JSON by recording paths. No getter,
// toJSON, typed-array, Set/Map, solver method or geometry predicate is invoked.
function copyData(value, budget, undefinedPaths, path = [], depth = 0) {
  if (++budget.nodes > LIMITS.copyNodes || depth > LIMITS.copyDepth) throw Error("Copy bound")
  if (value === undefined) { undefinedPaths.push(path); return null }
  if (value === null || typeof value === "boolean") return value
  if (typeof value === "number") return number(value)
  if (typeof value === "string") {
    budget.strings += bytes(value)
    if (budget.strings > LIMITS.stringBytes) throw Error("String bound")
    return value
  }
  if (typeof value !== "object") throw Error("JSON data required")
  const prototype = Object.getPrototypeOf(value)
  const array = Array.isArray(value)
  if (array ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null)
    throw Error("Plain data required")
  if (budget.active.has(value)) throw Error("Cyclic data")
  budget.active.add(value)
  const result = array ? [] : Object.create(null)
  const keys = Reflect.ownKeys(value)
  if (array && keys.length !== own(value, "length") + 1) throw Error("Dense array required")
  for (const key of keys) {
    if (array && key === "length") continue
    if (typeof key !== "string" || key === "__proto__") throw Error("Plain string key required")
    const descriptor = Object.getOwnPropertyDescriptor(value, key)
    if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) throw Error("Enumerable own data required")
    if (array && !/^(0|[1-9][0-9]*)$/.test(key)) throw Error("Plain array required")
    result[key] = copyData(descriptor.value, budget, undefinedPaths, [...path, key], depth + 1)
  }
  if (array && result.length !== own(value, "length")) throw Error("Dense array required")
  budget.active.delete(value)
  return result
}

function restoreOwnUndefined(record) {
  for (const path of record.undefinedPaths) {
    if (!Array.isArray(path) || !path.length) throw Error("Recorded path required")
    let target = record.data
    for (const key of path.slice(0, -1)) target = own(target, key)
    const key = path.at(-1)
    if (own(target, key) !== null) throw Error("Undefined placeholder required")
    Object.defineProperty(target, key, { value: undefined, writable: true, configurable: true, enumerable: true })
  }
  return record.data
}

/** Install AFTER the existing Stage observer; restore BEFORE that observer.
 * publish receives only bounded serialized data. It must synchronously publish
 * to a new ignored local file. Sink exceptions never change original behavior.
 * Root's existing owned-process controller decides when to stop; this hook does
 * not cancel a Grid, signal a process or claim solver success.
 */
function installClockHardSceneCapture(prototype, publish, sourceBindings, expectedClockSceneInput, verifyClockGroupProjection) {
  const descriptor = Object.getOwnPropertyDescriptor(prototype, "step")
  const cancelDescriptor = Object.getOwnPropertyDescriptor(prototype, "cancel")
  if (!descriptor || !("value" in descriptor) || typeof descriptor.value !== "function" || !descriptor.writable)
    throw Error("Original writable step descriptor required")
  if (!cancelDescriptor || !("value" in cancelDescriptor) || typeof cancelDescriptor.value !== "function" || !cancelDescriptor.writable)
    throw Error("Original writable cancel descriptor required")
  if (typeof publish !== "function") throw Error("Sink required")
  // Caller supplies immutable JSON identifiers only; no receiver graph retained.
  const bindingUndefined = []
  const bindings = copyData(sourceBindings, { nodes: 0, strings: 0, active: new Set() }, bindingUndefined)
  if (bindingUndefined.length) throw Error("Complete source bindings required")
  for (const name of ["callerSha256", "gridSha256", "publicInputSha256", "stageObserverSha256"])
    if (typeof bindings[name] !== "string" || !/^[0-9a-f]{64}$/.test(bindings[name]))
      throw Error("Exact source hash binding required: " + name)
  if (bindings.precheckEnclosedTerminals !== true) throw Error("Frozen caller reachability option required")
  if (typeof verifyClockGroupProjection !== "function") throw Error("Bound exact projection verifier required")
  const expectedUndefined = []
  const expectedData = copyData(expectedClockSceneInput, { nodes: 0, strings: 0, active: new Set() }, expectedUndefined)
  const expected = restoreOwnUndefined({ data: expectedData, undefinedPaths: expectedUndefined })
  const expectedConnections = own(expected, "connections")
  if (!Array.isArray(expectedConnections)) throw Error("Complete expected connection array required")
  let expectedClockConnection
  for (let i = 0; i < own(expectedConnections, "length"); i++) {
    const candidate = own(expectedConnections, String(i))
    if (own(candidate, "name") === "source_trace_34") {
      if (expectedClockConnection !== undefined) throw Error("Unique expected clock descriptor required")
      expectedClockConnection = candidate
    }
  }
  if (expectedClockConnection === undefined) throw Error("Expected clock descriptor required")
  const original = descriptor.value
  const originalCancel = cancelDescriptor.value
  const seen = new WeakSet()
  const canceledSeen = new WeakSet()
  const ids = new WeakMap()
  let records = new Map()
  let observedAttempts = 0, persistedAttempts = 0, nextID = 1
  let releasedSuccesses = 0, releasedAbandoned = 0, attemptBudgetExhausted = false, captureDisabled = false
  let errors = 0, matched = 0, published = 0, outcomePublications = 0, lastBytes = 0, restored = false
  function serialize(prospective, counters = {}) {
    const rows = [...prospective.values()]
    const persistedFailingScenes = rows.filter(record => record.outcome
      && (record.outcome.kind === "NATURAL_FAILURE" || record.outcome.kind === "CAP_STOP")).length
    const serialized = JSON.stringify({ diagnosticOnly: true, accepted49: false, fabricationReady: false,
      limits: LIMITS, bindings, complete: rows.length === LIMITS.records,
      persistedFailingScenes, observedAttempts, persistedAttempts, releasedSuccesses, releasedAbandoned,
      attemptBudgetExhausted, ...counters, records: rows }) + "\n"
    const size = bytes(serialized)
    if (size > LIMITS.totalBytes) throw Error("Serialized total exceeds bound")
    return { serialized, size }
  }
  function persist(serialized) {
    // Failed persistence conservatively disables later capture work. This is
    // live diagnostic state only: no saved geometry/counters are committed.
    try {
      if (publish(serialized) !== undefined) throw Error("Synchronous void sink required")
    } catch (error) { captureDisabled = true; throw error }
  }
  function noActive(prospective) {
    return [...prospective.values()].every(record => record.outcome !== null)
  }
  function capture(receiver) {
    if (captureDisabled || seen.has(receiver)) return
    seen.add(receiver)
    if (observedAttempts >= LIMITS.attempts) {
      if (!attemptBudgetExhausted && noActive(records)) {
        const { serialized, size } = serialize(records, { attemptBudgetExhausted: true })
        persist(serialized)
        attemptBudgetExhausted = true
        lastBytes = size
        published++
      }
      return
    }
    if (records.size >= LIMITS.records) return
    const scene = own(receiver, "scene")
    const connection = own(scene, "connection")
    if (own(connection, "name") !== "source_trace_34") return
    const terminals = own(connection, "pointsToConnect")
    if (own(own(terminals, "0"), "layer") !== "inner1" || own(own(terminals, "1"), "layer") !== "inner1") return
    const start = own(receiver, "start"), end = own(receiver, "end")
    // Use the actual current RAM-side terminal. Do not impose the old target
    // coordinates or a dogbone orientation from a different routing attempt.
    if (!samePoint(start, own(terminals, "1"))) return
    const width = number(own(scene, "width"))
    const step = number(own(receiver, "stepSize"))
    const kind = Math.abs(step - width / 2) < 1e-12 ? "original-coarse"
      : Math.abs(step - Math.max(.01, width / 10)) < 1e-12 ? "original-fine" : null
    if (!kind) return
    const copper = own(scene, "copper")
    if (!Array.isArray(copper)) throw Error("Own copper array required")
    let hasReservedTail = false
    for (let i = 0; i < own(copper, "length") && !hasReservedTail; i++) {
      const owners = own(own(copper, String(i)), "owners")
      if (!Array.isArray(owners)) throw Error("Own copper owners required")
      for (let j = 0; j < own(owners, "length"); j++)
        if (own(owners, String(j)) === "reserved_pair_tail") hasReservedTail = true
    }
    if (!hasReservedTail) return
    matched++
    if (own(receiver, "expanded") !== 0 || own(receiver, "solved") !== false || own(receiver, "failed") !== false)
      throw Error("First original unfinished step required")
    if (own(receiver, "penalty") !== 0 || own(receiver, "history", true) !== undefined
      || own(receiver, "hasSoftCopper") !== false || own(receiver, "softBuckets", true) !== undefined
      || own(receiver, "maxLength") !== Infinity || own(receiver, "lengthFrontier", true) !== undefined)
      throw Error("Unsupported history, soft copper or length mode")
    if (own(receiver, "gridOffsetX") !== 0 || own(receiver, "gridOffsetY") !== 0)
      throw Error("Unsupported cropped grid phase")
    const bounds = own(receiver, "gridBounds"), origin = own(receiver, "origin")
    const nx = number(own(receiver, "nx")), ny = number(own(receiver, "ny"))
    if (!Number.isSafeInteger(nx) || !Number.isSafeInteger(ny)
      || point(origin)[0] !== own(bounds, "minX") || point(origin)[1] !== own(bounds, "minY")
      || nx !== Math.ceil((own(bounds, "maxX") - own(bounds, "minX")) / step) + 1
      || ny !== Math.ceil((own(bounds, "maxY") - own(bounds, "minY")) / step) + 1)
      throw Error("Effective grid phase mismatch")
    // Eligibility is observed before bounded detached copying or persistence.
    // The live scalar bounds work even if copying or publication later fails.
    observedAttempts++
    const raw = { input: own(scene, "input"), connection, width,
      hardCopper: copper, margin: number(own(scene, "margin")),
      start, end, grid: { step, bounds, checkReachability: true },
      stateBeforeFirstStep: { nx, ny, origin, alternateAttachments: own(receiver, "alternateAttachments"),
        startAttachments: own(receiver, "startAttachments"), endAttachments: own(receiver, "endAttachments"),
        startPath: own(receiver, "startPath"), endPath: own(receiver, "endPath"), goal: own(receiver, "goal") } }
    const undefinedPaths = []
    const data = copyData(raw, { nodes: 0, strings: 0, active: new Set() }, undefinedPaths)
    // Compare two detached complete inputs, preserving every unknown own field.
    const candidateUndefined = []
    const candidateInput = copyData(data.input, { nodes: 0, strings: 0, active: new Set() }, candidateUndefined)
    const inputPaths = undefinedPaths.filter(path => path[0] === "input").map(path => path.slice(1))
    restoreOwnUndefined({ data: candidateInput, undefinedPaths: inputPaths })
    if (verifyClockGroupProjection(candidateInput, expected) !== true) throw Error("Exact derived clock input mismatch")
    const connectionUndefined = []
    const candidateConnection = copyData(data.connection, { nodes: 0, strings: 0, active: new Set() }, connectionUndefined)
    const connectionPaths = undefinedPaths.filter(path => path[0] === "connection").map(path => path.slice(1))
    restoreOwnUndefined({ data: candidateConnection, undefinedPaths: connectionPaths })
    if (verifyClockGroupProjection(candidateConnection, expectedClockConnection) !== true)
      throw Error("Exact derived clock descriptor mismatch")
    const id = nextID
    const record = { id, kind, data, undefinedPaths, captureAt: "before-first-original-step", outcome: null,
      constructorOptionsProvenance: "frozen runtime128 pair escape caller with precheckEnclosedTerminals=true",
      exactTargetTakenFromReceiver: true, constructorOrSolverMethodsCalled: 0 }
    const prospective = new Map(records)
    prospective.set(id, record)
    const exhausted = observedAttempts === LIMITS.attempts && noActive(prospective)
    const { serialized, size } = serialize(prospective, { persistedAttempts: persistedAttempts + 1, attemptBudgetExhausted: exhausted })
    persist(serialized)
    // Only a successful synchronous sink establishes a persisted scene.
    // Retain only a detached own-data copy; never the live scene or search.
    records = prospective
    ids.set(receiver, id)
    nextID++
    persistedAttempts++
    attemptBudgetExhausted = exhausted
    lastBytes = size
    published++
  }
  const wrapper = function(...args) {
    try { capture(this) } catch { errors++ }
    return Reflect.apply(original, this, args)
  }
  const cancelWrapper = function(...args) {
    let candidate = null
    try {
      const id = ids.get(this)
      if (id !== undefined && records.has(id) && !canceledSeen.has(this)) {
        canceledSeen.add(this)
        const solved = own(this, "solved"), failed = own(this, "failed")
        const expanded = number(own(this, "expanded"))
        if (typeof solved !== "boolean" || typeof failed !== "boolean"
          || !Number.isSafeInteger(expanded) || expanded < 0) throw Error("Original scalar cancel state required")
        const kind = failed ? "NATURAL_FAILURE" : !solved && expanded >= 500000 ? "CAP_STOP"
          : solved ? "SUCCESS" : "ABANDONED"
        candidate = { id, outcome: { kind, solved, failed, expanded,
          observedAt: "before-first-original-cancel", originalCancelReturned: true } }
      }
    } catch { errors++ }
    // The original cancel executes exactly once. Its error propagates unchanged;
    // no outcome is published if the original call throws.
    const result = Reflect.apply(originalCancel, this, args)
    if (candidate) {
      try {
        const record = { ...records.get(candidate.id), outcome: candidate.outcome }
        const prospective = new Map(records)
        const success = candidate.outcome.kind === "SUCCESS"
        const abandoned = candidate.outcome.kind === "ABANDONED"
        if (success || abandoned) prospective.delete(candidate.id)
        else prospective.set(candidate.id, record)
        const exhausted = observedAttempts === LIMITS.attempts && noActive(prospective)
        const { serialized, size } = serialize(prospective, {
          attemptBudgetExhausted: exhausted,
          releasedSuccesses: releasedSuccesses + Number(success),
          releasedAbandoned: releasedAbandoned + Number(abandoned) })
        persist(serialized)
        records = prospective
        attemptBudgetExhausted = exhausted
        releasedSuccesses += Number(success)
        releasedAbandoned += Number(abandoned)
        lastBytes = size
        published++
        outcomePublications++
      } catch { errors++ }
    }
    return result
  }
  Object.defineProperty(prototype, "step", { ...descriptor, value: wrapper })
  Object.defineProperty(prototype, "cancel", { ...cancelDescriptor, value: cancelWrapper })
  return {
    snapshot: () => ({ records: records.size, published, outcomePublications, matched, errors,
      observedAttempts, persistedAttempts, nextID, releasedSuccesses, releasedAbandoned, attemptBudgetExhausted, captureDisabled,
      serializedBytes: lastBytes, complete: records.size === LIMITS.records,
      persistedFailingScenes: [...records.values()].filter(record => record.outcome
        && (record.outcome.kind === "NATURAL_FAILURE" || record.outcome.kind === "CAP_STOP")).length,
      retainedLiveGeometry: false, additionalSolverCalls: 0, diagnosticOnly: true }),
    restore() {
      if (restored) throw Error("Restore once")
      if (Object.getOwnPropertyDescriptor(prototype, "step")?.value !== wrapper) throw Error("Wrapper changed")
      if (Object.getOwnPropertyDescriptor(prototype, "cancel")?.value !== cancelWrapper) throw Error("Cancel wrapper changed")
      Object.defineProperty(prototype, "step", descriptor)
      Object.defineProperty(prototype, "cancel", cancelDescriptor)
      restored = true
      return true
    },
  }
}

module.exports = { installClockHardSceneCapture, restoreOwnUndefined, LIMITS }
