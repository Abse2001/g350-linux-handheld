#!/usr/bin/env python3
"""Read-only, local arithmetic/provenance review; writes only this ignored report."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
FILES = [
    "cloud/DDR_ANALYSIS_DEFAULTS_2026-10-12.md",
    "imports/AM3352BZCZ100.tsx",
    "imports/MT41K256M16TW_107_P.tsx",
    "lib/am3352/PowerNetworks.ts",
    "dist/g350-ddr-clear-cpu-ram-corridor-1081/fresh-layout.circuit.json",
    "reference/am3352/am3352.txt",
    "reference/am3352/micron-ddr3l.txt",
    ".cloud-tools/ddr-settings-research/boot-clock-audit.json",
    ".cloud-tools/ddr-settings-research/calculator-source/report.json",
    ".cloud-tools/ddr-settings-research/calculator-source/prepared-forward-inputs.json",
    ".cloud-tools/ddr-settings-research/calculator-source/JLC04161H-3313-template.json",
    ".cloud-tools/ddr-settings-research/calculator-source/JLC04161H-1080-template.json",
    ".cloud-tools/ddr-settings-research/guarantee-audit/report.json",
]


def binding(path):
    data = (ROOT / path).read_bytes()
    return {"path": path, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def quote(path, first, last):
    lines = (ROOT / path).read_text().splitlines()
    return {"path": path, "firstLine": first, "lastLine": last,
            "exactText": "\n".join(lines[first - 1:last])}


before = [binding(path) for path in FILES]
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
defaults = "cloud/DDR_ANALYSIS_DEFAULTS_2026-10-12.md"
assert (ROOT / defaults).read_bytes() == subprocess.check_output(
    ["git", "show", f"{head}:{defaults}"], cwd=ROOT)
scene = json.loads((ROOT / FILES[4]).read_text())
parts = [{key: obj.get(key) for key in ["source_component_id", "name",
         "manufacturer_part_number", "supplier_part_numbers"]}
         for obj in scene if obj.get("type") == "source_component"
         and obj.get("name") in {"U_SOC", "U_RAM"}]
assert {part["manufacturer_part_number"] for part in parts} == {
    "AM3352BZCZ100", "MT41K256M16TW-107:P"}
ti = "reference/am3352/am3352.txt"
micron = "reference/am3352/micron-ddr3l.txt"
clock_ns = 2.5
minimum_cycles = []
for parameter, minimum_ns in [("tAA/CL", 13.91), ("tRCD", 13.91),
                              ("tRP", 13.91), ("tRAS", 34), ("tRC", 47.91)]:
    cycles = math.ceil(minimum_ns / clock_ns)
    minimum_cycles.append({"parameter": parameter, "documentedMinimumNs": minimum_ns,
                           "ceilingCyclesAt400MHz": cycles,
                           "nominalRepresentedNs": cycles * clock_ns,
                           "notAnEmifRegisterEncoding": True})

stackups = []
for name in ["3313", "1080"]:
    relative = f".cloud-tools/ddr-settings-research/calculator-source/JLC04161H-{name}-template.json"
    template = json.loads((ROOT / relative).read_text())
    dielectric = template["basicDataList"][1]
    er = dielectric["dielectricConstant"]
    # This is an illustrative ideal quasi-TEM scale, NOT a qualified flight-time bound.
    scale_ps_per_mm = math.sqrt(er) / 0.299792458
    stackups.append({
        "name": template["appointName"],
        "officialTemplateAccessId": template["impedanceDefaultTemplateAccessId"],
        "nominalBoardThicknessMm": template["plateThickness"],
        "publishedFinishedThicknessLabelMm": 1.56 if name == "3313" else 1.52,
        "publishedFinishedThicknessLabelTolerancePercent": 10,
        "outerCopperOz": 1, "innerCopperOz": template["innerCopperThickness"],
        "prepreg": dielectric["materialName"],
        "outerToReferenceHeightMm": dielectric["dielectricThick"],
        "publishedPrepregEr": er,
        "idealHomogeneousDielectricDelayScalePsPerMm": scale_ps_per_mm,
        "idealScaleFor635umPs": 0.635 * scale_ps_per_mm,
        "idealScaleFor127umPs": 0.127 * scale_ps_per_mm,
        "idealScaleFor635umPercentOf1250psUi": 100 * 0.635 * scale_ps_per_mm / 1250,
        "exactSingleEndedImpedanceOhm": None,
        "exactDifferentialImpedanceOhm": None,
        "actualElectricalDelayAndSkewQualified": False,
    })

report = {
    "schemaVersion": 1,
    "createdUtc": datetime.now(timezone.utc).isoformat(),
    "kind": "Independent local review of user-selected DDR analysis defaults",
    "boardHead": head,
    "reviewedDefaultsMatchGitHead": True,
    "actualFreshSourceParts": parts,
    "workingTargets": {"ddrClockHz": 400000000, "clockPeriodNs": clock_ns,
                       "transferRateMtPerSecond": 800, "unitIntervalNs": 1.25,
                       "boardNominalThicknessMm": 1.6, "layers": 4,
                       "ddrWireLayers": ["Top", "Bottom"]},
    "speedCompatibility": {
        "documentedCompatible": True,
        "supportedConfiguration": "One x16 DDR3-compatible 4Gb part; DDR_1V5 hardware rail",
        "tiMinimumMemoryGradeAt2p5ns": "DDR3-1600",
        "micronActualPartGrade": "-107 DDR3L-1866; backward compatible DDR3-1600",
        "micronDocumented400MHzOperatingPoint": {"cl": 6, "cwl": 5,
                                                 "validTckNs": [2.5, 3.3]},
        "onePointFiveVoltSameSpeedTimingsDocumented": True,
        "programmedPllOrEmifEstablished": False,
        "firmwareCaution": "Do not copy CL13/CWL9 from the1866 speed-bin label to400MHz; Table56 specifies CL6/CWL5 at tCK2.5–3.3ns. Review exact EMIF/MR encodings, all timings/refresh/ODT/calibration and actual clock separately.",
        "nominalMinimumCycleArithmeticOnly": minimum_cycles,
        "cl6NominalReadLatencyNs": 15,
        "table56TaaMaximumNs": 20,
        "memoryOrBoardTimingPassed": False,
    },
    "officialStackupCandidates": stackups,
    "provisionalEvaluationOrder": ["JLC04161H-3313", "JLC04161H-1080"],
    "provisionalOrderReason": "3313 provides the nearer nominal1.6mm finished label and retains an exact saved coated-microstrip input; compare1080 before choosing. Order is a bounded analysis workflow, not an impedance or manufacturing approval.",
    "delayCalculationLimits": [
        "Computed sqrt(Er)/c for homogeneous, ideal, nondispersive quasi-TEM material is a descriptive scale, not a prediction or verified upper bound for the actual coated microstrip/vias/package.",
        "An ideal outer-layer cross-section with effectiveEr between air1 and the listed prepregEr would have planar delay between3.33564095198152ps/mm and the listed scale. Real effectiveEr, dispersion, tolerances, mask, couplings, package/via/stub delay, reference returns and slew are unqualified.",
        "0.635mm/0.127mm geometric matching includes fixed fanouts but does not establish setup/hold margin. DifferentTop/Bottom impedances or via distributions can produce flight-time skew even at equal geometric lengths.",
        "Board checker1.6mm per layer transition is geometric accounting. Do not use it as an electrical via delay model or relax either planar/native matching constraint.",
    ],
    "retainedCalculatorStatus": {
        "exactImpedanceResults": None,
        "anonymousForwardAcknowledgementHadNoImpedance": True,
        "toolsJlcComWebsocketProxy403AlreadyDocumented": True,
        "noNewNetworkRequestsOrRepeatedBlockedAttempt": True,
    },
    "manufacturingTolerance": {
        "tiChosenNominalZoOhmRange": [50, 75],
        "tiPerSegmentToleranceOhm": 5,
        "jlcPublishedStandardTolerancePercent": 10,
        "jlcPublishedConditionalSpecialTolerancePercent": 5,
        "boardSpecificGuaranteeConfirmed": False,
        "explanation": "Standard±10% consumes>±5Ω at selectedZo>50Ω; conditional±5% is not a commitment for these exact boards. Calculator nominal is not manufacturing acceptance.",
    },
    "nextQualificationStepsWithoutVendorContact": [
        "Freeze the exact3313 and1080 official templateIDs/materials and saved finite trapezoidal copper/mask inputs; retain0.1016mm width and0.12mm pair gap unchanged. Nominal1.6mm alone does not select dielectric or finished copper.",
        "Prepare a separately reviewed local2D quasi-TEM coated-microstrip/coupled-line analysis of both symmetric outer layers and both candidates, using the saved input W1.1016/W2.0889/T.04064mm, maskC1/C3.0254/C2.01524mm/Er3.8. Verify convergence and established limiting cross-sections; report nominalZo/Zdiff/effectiveEr/group-delay and explicit uncertainty, without calling it a JLC result or guarantee.",
        "Choose no stackup until single-endedZo50–75Ω and differential nominal2Zo are supported on identical width/gap geometry; retain explicit unqualified tolerance if exact material/finished-copper variation is unavailable. Public calculator delivery remains blocked; do not bypass its host policy.",
        "On an actual accepted49 geometry, qualify TopadjacentGND and BottomadjacentcontinuousDDR_1V5 under every segment, zero plane cuts, and local return-transfer bypass at each signal layer change. Read TI7-62/7-68 directly; innerplane availability alone is insufficient.",
        "Audit TIlong-run spacing separately from native minimumclearance:4w center.4064mm(edge.3048mm) to otherclasses and3w center.3048mm(edge.2032mm) withinDQ orADDR classes; document exceptions and their≤1250mil(31.75mm) routed extent. Fixedpairgap.12mm is a differential-model input, not a substitute for these other-net spacing requirements.",
        "Build a per-net electrical budget for bothDQbytes andCK/ADDR using actual layer lengths, fixedpackage fanouts, CPU/RAM package delays, via/return discontinuities and counts, calibratedZo/propagation, driver/ODT/MR settings, slew-dependent setup/hold, jitter and crosstalk. Compare source-synchronousDQtoDQS andCKtoADDR at400MHz; do not compare only with the1.25nsUI.",
        "Review actual DDRPLL/EMIF/MR register configuration against the exact part, including documentedCL6/CWL5 candidate and rounded minima plus all omittedtRFC/tFAW/tRRD/refresh/power/calibration timings. This task does not create or validate firmware. Final manufacturing confirmation and measuredbringup remain later gates.",
    ],
    "quotes": [quote(ti, 7815, 7821), quote(ti, 7834, 7838),
               quote(ti, 8019, 8031), quote(ti, 8053, 8078),
               quote(micron, 11, 26), quote(micron, 41, 68),
               quote(micron, 2371, 2372), quote(micron, 3864, 3876),
               quote(micron, 3894, 3902), quote(ti, 8513, 8536),
               quote(ti, 8575, 8598)],
    "boundFiles": before,
    "networkRequests": 0, "routingOrSolverJobs": 0, "nativeOrCadChecks": 0,
    "trackedHardwareOrFirmwareOrEvidenceChanges": False,
    "accepted49": False, "fabricationReady": False,
}
after = [binding(path) for path in FILES]
assert before == after, "Declared read-only input bytes changed during review"
report["boundFilesUnchangedBeforeAfter"] = True
(OUT / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"report": str(OUT / "report.json"),
                  "sha256": hashlib.sha256((OUT / "report.json").read_bytes()).hexdigest(),
                  "boundFilesUnchanged": True, "fabricationReady": False}))
