Separate post209 routing evidence, through closed232 plus the completed Source228 literal-pour audit.

Primary223 has47/49 current-scene physical paths; fresh225 critical6 and allfive
report APIs pass in both actual DQS1 views. Projector224 passes. D12/source26 and
DQM0/source30 remain pending. Fresh capture227/Core228 now pass all35 fidelity controls:47 connected, two pending,
227 actual vias. Fresh native230 completes16 checks: physical10 and five other
focused geometry checks return zero; three bus-skew failures remain unfiltered.
Auth231 authenticates all227 vias with zero foreign via-track findings. All14 actual fresh literal pours now pass the exact audit against227 authenticated
vias and937 routed wire segments: zero foreign-margin violations, minimum gap
0.11832052949719676mm against0.1016mm. This is not reference-plane/TI qualification. Other native185 checks are historical
and not inherited as current passes.
Original matching/electrical/reference/CAD/fabrication qualification remains false.
The accepted default board remains32; the last fully checked partial Source is20946.

Restore prior Source32 prerequisites and immutable Source209 archive first, as
documented in cloud/DDR_FOUR_LAYER_MANUAL_ROUTING_2026-10-16.md. Then run:

python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post209-2026-10-16 --restore
python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post209-2026-10-16

The existing helper verifies local saved hashes/modes and refuses differing targets;
it does not interpret the extra baseArchiveDependency metadata, so restore order
is a caller precondition. No SDK is executed by this collector or restoration.
Closed failures216/217 are retained with their logs and no invented qualification.
The qualified reference-overlay219 is a separate branch; it does not alter223.
Closed226/229 preserve47 and add no route; their alternate attempts are retained separately. No archive, commit or push is performed.

Snapshot boundary: closed SDK215–232, Source228/native230/auth231 and its completed
14-pour audit. Later233/CA-merge experiments are excluded and belong in a fresh
post232 folder. Source209 remains an independent timing fallback; its CA204
minimum-window improvements have not been combined with this47-path candidate.
