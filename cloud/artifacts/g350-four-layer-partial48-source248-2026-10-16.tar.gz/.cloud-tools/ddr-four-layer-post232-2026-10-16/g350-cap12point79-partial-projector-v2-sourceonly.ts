/** Source-only v2 narrow projector successor for one declared cap12 translation.
 * Imports are pure data modules; Root alone runs the CLI under its guard. */
import { projectPartialMixedJoined, type ProjectionInput } from '/tmp/g350-source33b-partial-mixed-joined-editable-projector-v2-sourceonly.ts'
import { deriveCap12HardwareDelta, CAP12_PROFILE } from '/tmp/g350-cap12point79-hardware-delta-v2-sourceonly.ts'
type Row = Record<string, any>
const need = (ok: unknown, message: string): asserts ok => { if (!ok) throw Error(message) }
const RAW_SHA = 'd2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607'

export function projectCap12Point79Partial(packet: ProjectionInput): Row {
  const delta = deriveCap12HardwareDelta(packet.rawCore, packet.input, packet.candidate, packet.candidateBinding!)
  const plan = projectPartialMixedJoined({ ...packet, input: delta.effectiveProjectionInput })
  plan.hardwareDeltaProfile = CAP12_PROFILE
  plan.cap12HardwareDelta = delta.cap12HardwareDelta
  plan.sourceHardwarePlacementRequired = true
  plan.effectiveProjectionInputDerivation = {
    originalInputFileUnchanged: true, originalCapturedRawUnchanged: true,
    onlyTwoCap12ObstaclesTranslated: true, onlyTwoCap12ReferencesRerouted: true,
    heldPlacements: 279, translatedPlacements: 1, heldLands: 1163, translatedLands: 2,
    heldReferencePaths: 163, reroutedReferencePaths: 2, heldReferenceVias: 129,
    capturedIdsAreMappingProvenanceOnly: true, freshCoreIdsAssigned: false,
    effectiveInputIsAnExplicitDerivedModelNotCapturedRaw: true,
  }
  plan.qualificationRequired = [
    'Exact three-literal editable replay and full presence-aware inverse to original Source33B',
    'Fresh Core: 279 held parts plus one exact cap12 move; 1163 held lands plus two exact translated pads/ports',
    'Fresh Core: 163 held reference paths plus the exact two .2 Bottom reroutes and all129 held reference barrels',
    'Original49 logical numeric graphs and original rules; current physical/native/coupling/CAD/electrical checks remain separate',
  ]
  plan.all49Accepted = false; plan.fabricationReady = false
  return plan
}

if (import.meta.main) {
  const args = new Map<string, string>()
  for (let i = 2; i < process.argv.length; i += 2) {
    const key = process.argv[i], value = process.argv[i + 1]
    need(['--caller-intent', '--input', '--candidate', '--candidate-sha', '--contacts', '--proof', '--proposal',
      '--raw-core', '--raw-core-sha', '--output', '--namespace'].includes(key) && value && !args.has(key), `Invalid argument ${key}`)
    args.set(key, value)
  }
  need(args.get('--caller-intent') === 'ROOT_AUTHORIZED_PROJECT_COMPACT_PARTIAL_MIXED_JOINED_V2', 'Existing explicit Root projection intent required')
  for (const key of ['--input', '--candidate', '--candidate-sha', '--contacts', '--proof', '--proposal', '--raw-core', '--raw-core-sha', '--output'])
    need(args.has(key), `Requires ${key}`)
  const fs = await import('node:fs/promises'), path = await import('node:path'), crypto = await import('node:crypto')
  const sha = (data: Uint8Array) => crypto.createHash('sha256').update(data).digest('hex')
  const bindings: Row = {}, packet: Row = {}
  for (const key of ['input', 'candidate', 'contacts', 'proof', 'proposal', 'raw-core']) {
    const filename = path.resolve(args.get('--' + key)!), data = await fs.readFile(filename)
    const property = key === 'raw-core' ? 'rawCore' : key
    bindings[property] = { path: filename, sha256: sha(data) }; packet[property] = JSON.parse(data.toString('utf8'))
  }
  need(/^[a-f0-9]{64}$/.test(args.get('--candidate-sha')!) && bindings.candidate.sha256 === args.get('--candidate-sha'), 'Exact future candidate SHA required')
  need(args.get('--raw-core-sha') === RAW_SHA && bindings.rawCore.sha256 === RAW_SHA, 'Exact genuine original Source33B raw SHA required')
  const plan = projectCap12Point79Partial({ ...packet, candidateBinding: bindings.candidate,
    rawCoreBinding: bindings.rawCore, namespace: args.get('--namespace') ?? 'V_CAP12_P79' } as ProjectionInput)
  plan.inputBindings = bindings
  const output = path.resolve(args.get('--output')!)
  need(Object.values(bindings).every((b: any) => b.path !== output), 'Separate new output required')
  await fs.mkdir(path.dirname(output), { recursive: true })
  await fs.writeFile(output, JSON.stringify(plan, null, 2) + '\n', { flag: 'wx', mode: 0o600 })
  process.stdout.write(JSON.stringify({ output, hardwareDeltaProfile: CAP12_PROFILE,
    routedOwners: plan.routedOwnerIds.length, pendingOwners: plan.pendingOwnerIds.length,
    sourceHardwarePlacementApplied: false, freshCoreDerived: false, all49Accepted: false, fabricationReady: false }) + '\n')
}
