from pathlib import Path
import json,hashlib,stat,difflib,ast
OLD=Path('/tmp/g350-source29-native-fresh49-original-api131-final-preparation-sourceonly-next');NEW=Path('/tmp/g350-source29-promoted-pins-stable-native-fresh49-api-runtime-sourceonly-next');TARGET=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-source29-joint7-ca6-ca18-reset-editable-source-stages-sourceonly-next');assert not NEW.exists();NEW.mkdir(mode=0o700)
def pin(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def put(p,b):
 with p.open('xb')as f:f.write(b)
 p.chmod(0o600)
def js(p,v):put(p,(json.dumps(v,indent=2)+'\n').encode())
a=pin(TARGET/'SOURCE-manifest.json');b=pin(TARGET/'source29-proposal.json');assert a['sha256']=='00421ca4aba188174b657a0787367231e19c7a4c2b1cade7e0f548378cbf1c5a'and b['sha256']=='34a35a2ef12829ac11303dfb98ce8c955efcf0c897fa133c79ddcd63d99cf86a'
substitutions={
'qualify-fresh-native.mjs':[('const FUTURE_SOURCE29_CORE_SOURCE_SHA=null,FUTURE_SOURCE29_PROPOSAL_SHA=null','const FUTURE_SOURCE29_CORE_SOURCE_SHA='+json.dumps(a['sha256'])+',FUTURE_SOURCE29_PROPOSAL_SHA='+json.dumps(b['sha256']))],
'derive-fresh29-core49-input.py':[('FUTURE_SOURCE29_CORE_SOURCE_SHA = None','FUTURE_SOURCE29_CORE_SOURCE_SHA = '+repr(a['sha256'])),('FUTURE_SOURCE29_PROPOSAL_SHA = None','FUTURE_SOURCE29_PROPOSAL_SHA = '+repr(b['sha256']))],
'check-fresh-original-all3-pair-api29.ts':[('const FUTURE_SOURCE29_CORE_SOURCE_SHA:string|null=null,FUTURE_SOURCE29_PROPOSAL_SHA:string|null=null','const FUTURE_SOURCE29_CORE_SOURCE_SHA:string|null='+json.dumps(a['sha256'])+',FUTURE_SOURCE29_PROPOSAL_SHA:string|null='+json.dumps(b['sha256']))]}
m0=json.loads((OLD/'SOURCE-manifest.json').read_text());inverse=[];delta=[]
for row in m0['files']:
 p=Path(row['path']);assert pin(p)==row
 if p.name=='FUTURE_ACTUAL_BINDINGS_TEMPLATE_NO_AUTHORIZATION.json':continue
 raw=p.read_bytes()
 if p.name in substitutions:
  src=raw.decode();changed=src
  for before,after in substitutions[p.name]:assert changed.count(before)==1;changed=changed.replace(before,after)
  restored=changed
  for before,after in reversed(substitutions[p.name]):assert restored.count(after)==1;restored=restored.replace(after,before)
  assert restored==src
  if p.suffix=='.py':ast.parse(changed)
  delta.extend(difflib.unified_diff(src.splitlines(True),changed.splitlines(True),fromfile='0c52/'+p.name,tofile='six-bound-literals/'+p.name));raw=changed.encode();inverse.append(dict(file=p.name,exactByteInverse=True,parentPin=row,newSourceSha256=hashlib.sha256(raw).hexdigest(),literalEdits=substitutions[p.name]))
 put(NEW/p.name,raw)
template=json.loads((OLD/'FUTURE_ACTUAL_BINDINGS_TEMPLATE_NO_AUTHORIZATION.json').read_text());template.update(scope='UNAUTHORIZED_PARTIALLY_BOUND_PROMOTED_SOURCE29_NATIVE_AND_ORIGINAL_API131',coreSourceManifestSha256=a['sha256'],genuineSource29ManifestSha256=a['sha256'],futurePromotedSource29ManifestPath=a['path'],futurePromotedSource29ManifestSha256=a['sha256'],futurePromotedSource29ProposalPath=b['path'],futurePromotedSource29ProposalSha256=b['sha256'],source29ProposalPath=b['path'],source29ProposalSha256=b['sha256'],nativeWorkerPath=str(NEW/'qualify-fresh-native.mjs'),nativeWorkerSha256=pin(NEW/'qualify-fresh-native.mjs')['sha256'])
template['files']=[pin(NEW/name)for name in('qualify-fresh-native.mjs','fresh-owner-factory.mjs','fresh-via-branch-manufacturing-clearance.mjs')]
template['batchProvenanceRequired']='Only an authentic Root-collected Source29 batch53 may supply current actualCore artifacts: ordered capture/types/Core, three separate phase POSTs, serial natural0 owned children, same guard identity, independent empty groups and guard absence, Source186/SDK/native/Git/floor holds. Never retag Source26 material as29. Known promoted source/proposal constants are stable across Native/projector/API; actual report/model/authority pins remain data-bound by fresh Root scope.'
js(NEW/'PARTIAL_BINDINGS_TEMPLATE_NO_AUTHORIZATION.json',template);put(NEW/'EXACT_SIX_NATIVE_PROJECTOR_API_SOURCE_CONSTANTS_ONLY_DELTA.patch',''.join(delta).encode())
proof=dict(scope='SOURCE_ONLY_EXACT_SIX_PROMOTED_CONSTANTS_STABLE_NATIVE_PROJECTOR_API_RUNTIME',parentFinalPreparationManifest=pin(OLD/'SOURCE-manifest.json'),historicalNativeOnlyUnrunRuntimePin=pin('/tmp/g350-source29-promoted-pins-native-fresh49-api-partial-runtime-sourceonly-next/SOURCE-manifest.json'),knownPromotedSource29Manifest=a,knownPromotedSource29Proposal=b,functionalChangedFileCount=3,functionalChangedConstantCount=6,exactInverses=inverse,allOtherAlgorithmPredicateFactoryAndManufacturingBodiesByteExact=True,all13OriginalApiSourcesByteExact=True,actual53CollectionAndCoreUnset=True,noRootAuthorityCreated=True,noOperationalModuleHelperSdkAppOrProcessEvaluated=True,workspaceWrites=False,Source29Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingQualified=False,fabricationReady=False)
js(NEW/'SOURCE_ONLY_SIX_CONSTANTS_AND_EXACT_INVERSE_PROOF.json',proof)
m=dict(scope='SOURCE_ONLY_PROMOTED_SOURCE29_STABLE_NATIVE18_FRESH49_ORIGINAL_API131_PARTIAL_RUNTIME',status='AUTHOR_DONE_SOURCE_ONLY_ALL_SIX_PROMOTED_CONSTANTS_BOUND_ACTUAL53_NULL',parentFinalPreparationManifest=pin(OLD/'SOURCE-manifest.json'),knownPromotedSource29Manifest=a,knownPromotedSource29Proposal=b,original13PrivateApiFiles=m0['original13PrivateApiFiles'],originalManufacturingByteExact=True,all18PhysicalCheckPredicatesHeld=True,prospectiveCounts=m0['prospectiveCounts'],prospectiveApiInventory=m0['prospectiveApiInventory'],actual53CollectionPin=None,actual53CoreRawPin=None,actual53CoreControlsPin=None,actualNativeReport=None,actualFresh49Input=None,actualOriginalApi=None,allThreeWorkersKnownPromotedConstantsBound=True,sameStableSourceManifestCanQualifyNativeProjectionAndApi=True,RootAuthorityCreated=False,SDKOrOperationalCodeEvaluated=False,workspaceWrites=False,Source29Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingQualified=False,fabricationReady=False)
m['files']=[pin(p)for p in sorted(NEW.iterdir())if p.is_file()];by={}
for row in[pin(OLD/'SOURCE-manifest.json'),*m0['files'],*m0['externalFiles'],a,b,proof['historicalNativeOnlyUnrunRuntimePin'],pin('/tmp/g350-source29-native-api131-finite-independent-peer-corrected-next/PEER_REVIEW.json'),pin(Path(__file__))]:assert row['path']not in by or by[row['path']]==row;by[row['path']]=row
m['externalFiles']=list(by.values());m['ownFileCountExcludingManifest']=len(m['files']);m['externalFileCount']=len(m['externalFiles']);js(NEW/'SOURCE-manifest.json',m)
print(json.dumps(dict(manifest=pin(NEW/'SOURCE-manifest.json'),worker=pin(NEW/'qualify-fresh-native.mjs'),projector=pin(NEW/'derive-fresh29-core49-input.py'),api=pin(NEW/'check-fresh-original-all3-pair-api29.ts'),template=pin(NEW/'PARTIAL_BINDINGS_TEMPLATE_NO_AUTHORIZATION.json'),delta=pin(NEW/'EXACT_SIX_NATIVE_PROJECTOR_API_SOURCE_CONSTANTS_ONLY_DELTA.patch')),indent=2))
