/** Root-only Source evaluation, not a Circuit/Core render. Source22 is planned
 * here solely for the inverse; its unrun status is not actual acceptance. */
import { Children, Fragment, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { readFileSync, writeFileSync, existsSync } from "node:fs"
import { createHash } from "node:crypto"
import assert from "node:assert/strict"
import { buildStrict18ManualSource } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-strict18-smooth-manual-source-core-successor-next/strict18-source-overlay"
import { buildOwnerMoved22Source } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-owner22-child-clear-source-successor-next/source22.circuit"
import { buildOwnerMoved23Source } from "./source23.circuit"
import proposal from "./source23-proposal.json"
import parent22Proposal from "/workspace/g350-linux-handheld/.cloud-tools/ddr-owner-moved22-editable-source-proposal-next/source22-proposal.json"
const [output, diagnostic, ...extra] = process.argv.slice(2)
assert.equal(process.env.G350_MOVED23_SOURCE_ROOT_GUARDED,"1")
assert.equal(process.versions.bun,"1.3.14")
assert.ok(output && diagnostic && extra.length===0 && output!==diagnostic && !existsSync(output) && !existsSync(diagnostic))
const sha=(v:string|Buffer)=>createHash("sha256").update(v).digest("hex")
for(const binding of Object.values(proposal.inputBindings))assert.equal(sha(readFileSync(binding.path)),binding.sha256)
type Props=Record<string,unknown>&{children?:ReactNode}
type Row={kind:"literal"|"fragment"|"primitive"|"unsupported";type:string;key:string|null;props:Record<string,unknown>;children:Row[];value?:unknown}
function identity(node:ReactNode):ReactNode{
  if(!isValidElement<Props>(node))return node
  return cloneElement(node as ReactElement<Props>,{...node.props},...Children.toArray(node.props.children).map(identity))
}
function snapshot(node:ReactNode):Row{
  if(!isValidElement<Props>(node)){
    const allowed=node===null||node===undefined||["boolean","string","number"].includes(typeof node)
    return {kind:allowed?"primitive":"unsupported",type:typeof node,key:null,value:node,props:{},children:[]}
  }
  const {children,...props}=node.props,actualType:unknown=node.type
  const kind=typeof actualType==="string"?"literal":actualType===Fragment?"fragment":"unsupported"
  return {kind,type:kind==="literal"?actualType as string:kind==="fragment"?"React.Fragment":`${typeof actualType}:${String(actualType)}`,key:node.key,props,children:Children.toArray(children).map(snapshot)}
}
const flatten=(row:Row):Row[]=>[row,...row.children.flatMap(flatten)]
const clone=(row:Row):Row=>({...row,props:{...row.props},children:row.children.map(clone)})
function canonical(v:unknown):string{
  if(Array.isArray(v))return `[${v.map(canonical).join(",")}]`
  if(v&&typeof v==="object")return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical((v as Record<string,unknown>)[k])}`).join(",")}}`
  if(typeof v==="function")return `function:${v.toString()}`
  if(typeof v==="symbol")return `symbol:${String(v)}`
  return JSON.stringify(v)??"undefined"
}
const replacer=(_key:string,v:unknown)=>typeof v==="function"?{diagnosticFunction:v.name,sourceSha256:sha(v.toString())}
  :typeof v==="symbol"?{diagnosticSymbol:String(v),globalSymbolKey:Symbol.keyFor(v)??null}:v
const counts=(rows:Row[])=>({reactElements:rows.filter(r=>r.kind==="literal"||r.kind==="fragment").length,literalStrings:rows.filter(r=>r.kind==="literal").length,fragments:rows.filter(r=>r.kind==="fragment").length,primitiveChildren:rows.filter(r=>r.kind==="primitive").length,unsupported:rows.filter(r=>r.kind==="unsupported").length})
function validateCorrectedParent22(before:Row,after:Row){
  const proposal=parent22Proposal,oldRows=flatten(before),newRows=flatten(after)
assert.equal(counts(oldRows).unsupported, 0); assert.equal(counts(newRows).unsupported, 0)
assert.equal(counts(oldRows).reactElements, 2256); assert.equal(counts(newRows).reactElements, proposal.expectedCounts.expectedReactElements)
assert.equal(counts(newRows).literalStrings - counts(oldRows).literalStrings, proposal.expectedCounts.innerLiteralPorts - 28 + 4)
assert.equal(counts(newRows).fragments, counts(oldRows).fragments)
assert.equal(counts(newRows).primitiveChildren, counts(oldRows).primitiveChildren)
const one = (rows: Row[], label: string) => { assert.equal(rows.length, 1, label); return rows[0] }
const byName = (rows: Row[], name: string) => one(rows.filter(row => row.kind === "literal" && row.props.name === name), name)
const selected = new Map(proposal.selected22OriginalCarriers.map(row => [row.originalSourceTraceId, row]))
const routeFields = ["pcbPath", "pcbPaths", "pcbPathRelativeTo"] as const
const omit = (props: Record<string, unknown>, fields: readonly string[]) => Object.fromEntries(Object.entries(props).filter(([key]) => !fields.includes(key)))
for (const change of proposal.coordinateChanges) {
  const row = byName(newRows, change.name), old = byName(oldRows, change.name)
  assert.equal(row.type, change.type); assert.deepEqual({ pcbX: old.props.pcbX, pcbY: old.props.pcbY }, change.before)
  assert.deepEqual({ pcbX: row.props.pcbX, pcbY: row.props.pcbY }, change.after)
  assert.deepEqual(omit(row.props, ["pcbX", "pcbY"]), omit(old.props, ["pcbX", "pcbY"]), "No metadata/footprint/dimension/rotation or other Via prop change")
}
for (const owner of proposal.all98NumericOwnedSignalBranches) {
  const via = byName(newRows, owner.viaName), local = byName(newRows, owner.traceName)
  assert.equal(via.type, "via"); assert.ok(Math.hypot(Number(via.props.pcbX) - owner.viaXY.x, Number(via.props.pcbY) - owner.viaXY.y) < 1e-9)
  assert.equal(via.props.fromLayer, "top"); assert.equal(via.props.toLayer, "bottom")
  assert.equal(via.props.outerDiameter, .4572); assert.equal(via.props.holeDiameter, .254)
  assert.equal(local.type, "trace"); assert.equal(local.props.from, owner.numericSelector)
  assert.equal(local.props.to, `.${owner.viaName} > port.top`); assert.equal(local.props.thickness, .1016)
  assert.equal(local.props.pcbPathRelativeTo, `.${owner.viaName} > port.top`)
  assert.equal(local.props.pcbPaths, undefined)
  assert.deepEqual(local.props.pcbPath, selected.has(owner.originalSourceTraceId) ? undefined : [])
  const ports = proposal.added32RealInnerLayerPorts.filter(port => port.viaName === owner.viaName)
  assert.equal(via.children.length, ports.length)
  for (const requested of ports) {
    const port = one(via.children.filter(child => child.kind === "literal" && child.type === "port"), "One genuine inner Port")
    assert.deepEqual(port.props, { name: requested.layer, layer: requested.layer }); assert.equal(port.children.length, 0)
  }
}
for (const logical of proposal.all49OriginalLogicalTraces) {
  const row = byName(newRows, logical.name), old = byName(oldRows, logical.name), carrier = selected.get(logical.originalSourceTraceId)
  assert.equal(row.type, "trace"); assert.equal(row.props.from, logical.from); assert.equal(row.props.to, logical.to)
  assert.equal(row.props.pcbPath, undefined)
  assert.deepEqual(row.props.pcbPaths, carrier?.newPcbPaths)
  assert.equal(row.props.pcbPathRelativeTo, carrier?.newPcbPathRelativeTo)
  assert.deepEqual(omit(row.props, routeFields), omit(old.props, routeFields), "Every original numeric logical/timing/width prop remains exact")
}
const restored = clone(after), restoredRows = flatten(restored), untouchedActual = canonical(after)
let coordinatesRestored = 0, originalRouteFieldsRestored = 0, localsRestored = 0, portParentsRestored = 0
for (const change of proposal.coordinateChanges) {
  const row = byName(restoredRows, change.name), old = byName(oldRows, change.name)
  row.props.pcbX = old.props.pcbX; row.props.pcbY = old.props.pcbY; coordinatesRestored++
}
for (const logical of proposal.all49OriginalLogicalTraces) {
  const row = byName(restoredRows, logical.name), old = byName(oldRows, logical.name)
  for (const field of routeFields) { delete row.props[field]; if (Object.prototype.hasOwnProperty.call(old.props, field)) row.props[field] = old.props[field] }
  originalRouteFieldsRestored++
}
for (const owner of proposal.all98NumericOwnedSignalBranches.filter(owner => owner.originalSourceTraceId !== "source_trace_10")) {
  const local = byName(restoredRows, owner.traceName), oldLocal = byName(oldRows, owner.traceName)
  assert.deepEqual(omit(local.props, ["pcbPath"]), omit(oldLocal.props, ["pcbPath"]), "No local logical owner or extra routing prop changed")
  delete local.props.pcbPath; if (Object.prototype.hasOwnProperty.call(oldLocal.props, "pcbPath")) local.props.pcbPath = oldLocal.props.pcbPath; localsRestored++
  const via = byName(restoredRows, owner.viaName), oldVia = byName(oldRows, owner.viaName)
  via.children = oldVia.children.map(clone); portParentsRestored++
}
const resetDeclarations = [...proposal.resetViaDeclarations, ...proposal.resetLocalTraceDeclarations]
assert.equal(restored.type, "board"); assert.equal(restored.children.length, before.children.length + 4)
for (let i = 0; i < 4; i++) {
  const actual = restored.children[before.children.length + i], expected = resetDeclarations[i]
  assert.equal(actual.kind, "literal"); assert.equal(actual.type, expected.type)
  assert.deepEqual(actual.props, expected.props); assert.equal(actual.children.length, 0)
  assert.equal(oldRows.filter(row => row.props.name === expected.props.name).length, 0)
}
restored.children.splice(before.children.length, 4)
assert.equal(coordinatesRestored, 129); assert.equal(originalRouteFieldsRestored, 49)
assert.equal(localsRestored, 96); assert.equal(portParentsRestored, 96)
assert.equal(canonical(restored), canonical(before), "Full inverse: every container, key, prop, literal and child order remains exact outside declared deltas")
assert.equal(canonical(after), untouchedActual, "The actual proposed tree was never edited by the inverse")
for (const name of proposal.all129ReferenceViaNames) assert.equal(byName(newRows, name).type, "via")
assert.equal(newRows.filter(row => row.kind === "literal" && row.type === "via").length, 227)
assert.equal(newRows.filter(row => row.kind === "literal" && row.type === "bus").length, 8)
  return {fullInverseSourceTreePassed:true,actualParent22ReactElements:counts(newRows).reactElements,actualParent22InnerPorts:newRows.filter(row=>row.kind==="literal"&&row.type==="port").length}
}
const parent22BeforeBuildDiagnosticPath=diagnostic+".parent22-before-source23.json"
assert.ok(!existsSync(parent22BeforeBuildDiagnosticPath),"Exclusive raw parent diagnostic required")
const original18=buildStrict18ManualSource(),parent22=buildOwnerMoved22Source()
const historical18=snapshot(original18.element),planned22=snapshot(parent22.element)
writeFileSync(parent22BeforeBuildDiagnosticPath,JSON.stringify({scope:"ACTUAL_CORRECTED_PARENT22_TREE_BEFORE_SOURCE23_BUILD_AND_INVERSE_ASSERTIONS",actualOld18Tree:historical18,actualParent22Tree:planned22,actualParent22Counts:counts(flatten(planned22)),parent22ActualCoreAcceptanceInherited:false,parent22InverseChecksExecuted:false,transitiveAncestorCoreDefinitionsImported:true,circuitConstructed:false,coreRendered:false,nativeExecuted:false,cadExecuted:false,all49Accepted:false,fabricationReady:false},replacer,2)+"\n",{flag:"wx",mode:0o600})
const parent22Inverse=validateCorrectedParent22(snapshot(identity(original18.element)),planned22)
const source23=buildOwnerMoved23Source()
const before=snapshot(identity(parent22.element)),after=snapshot(source23.element)
const oldRows=flatten(before),newRows=flatten(after)
writeFileSync(diagnostic,JSON.stringify({scope:"ACTUAL_SOURCE23_AND_PLANNED_SOURCE22_TREES_BEFORE_INVERSE_ASSERTIONS",beforeCounts:counts(oldRows),afterCounts:counts(newRows),actualOld18TreeReevaluated:historical18,plannedSource22Tree:planned22,keyNormalizedPlannedSource22BeforeTree:before,actualProposedSource23Tree:after,parent22ActualAcceptanceInherited:false,actualParent22FullInverse:parent22Inverse,parent22BeforeBuildDiagnosticPath,parent22BeforeBuildDiagnosticSha256:sha(readFileSync(parent22BeforeBuildDiagnosticPath)),inverseChecksExecuted:false,transitiveAncestorCoreDefinitionsImported:true,circuitConstructed:false,coreRendered:false,nativeExecuted:false,cadExecuted:false,referenceQualified:false,all49Accepted:false,fabricationReady:false},replacer,2)+"\n",{flag:"wx",mode:0o600})
const oldCapture=JSON.parse(readFileSync(proposal.inputBindings.actualSmooth18Capture.path,"utf8"))
assert.equal(oldCapture.passed,true);assert.equal(oldCapture.fullInverseSourceTreePassed,true)
assert.equal(canonical(JSON.parse(JSON.stringify(historical18,replacer))),canonical(oldCapture.actualSourceTree),"Actual old18 checkpoint is retained; no Source22 acceptance invented")
assert.equal(counts(oldRows).unsupported,0);assert.equal(counts(newRows).unsupported,0)
assert.equal(counts(oldRows).reactElements,2264);assert.equal(counts(newRows).reactElements,2268)
assert.equal(counts(newRows).literalStrings-counts(oldRows).literalStrings,4)
assert.equal(counts(newRows).fragments,counts(oldRows).fragments);assert.equal(counts(newRows).primitiveChildren,counts(oldRows).primitiveChildren)
const one=(rows:Row[],label:string)=>{assert.equal(rows.length,1,label);return rows[0]}
const named=(rows:Row[],name:string)=>one(rows.filter(r=>r.kind==="literal"&&r.props.name===name),name)
const routeFields=["pcbPath","pcbPaths","pcbPathRelativeTo"] as const
const omit=(p:Record<string,unknown>,fields:readonly string[])=>Object.fromEntries(Object.entries(p).filter(([k])=>!fields.includes(k)))
for(const port of proposal.newFourInnerLayerPorts){
  const old=named(oldRows,port.viaName),now=named(newRows,port.viaName)
  assert.equal(old.type,"via");assert.equal(now.type,"via");assert.deepEqual(now.props,old.props)
  assert.equal(old.children.length,0);assert.equal(now.children.length,1)
  const child=now.children[0];assert.equal(child.kind,"literal");assert.equal(child.type,"port")
  assert.deepEqual(child.props,{name:port.layer,layer:port.layer});assert.deepEqual(child.children,[])
}
for(const change of proposal.twoOriginalCarrierChanges){
  const old=named(oldRows,change.logicalName),now=named(newRows,change.logicalName),carrier=change.afterCarrier
  assert.equal(now.type,"trace");assert.deepEqual(omit(now.props,routeFields),omit(old.props,routeFields))
  assert.equal(now.props.pcbPath,undefined);assert.deepEqual(now.props.pcbPaths,carrier.newPcbPaths);assert.equal(now.props.pcbPathRelativeTo,carrier.newPcbPathRelativeTo)
}
for(const owner of proposal.all98NumericOwnedSignalBranches.filter(row=>row.originalSourceTraceId==="source_trace_4")){
  const old=named(oldRows,owner.traceName),now=named(newRows,owner.traceName)
  assert.deepEqual(old.props.pcbPath,[]);assert.equal(now.props.pcbPath,undefined)
  assert.deepEqual(omit(now.props,["pcbPath"]),omit(old.props,["pcbPath"]))
}
const restored=clone(after),restoredRows=flatten(restored),untouched=canonical(after)
for(const port of proposal.newFourInnerLayerPorts)named(restoredRows,port.viaName).children=[]
for(const change of proposal.twoOriginalCarrierChanges){
  const row=named(restoredRows,change.logicalName),old=named(oldRows,change.logicalName)
  for(const field of routeFields){delete row.props[field];if(Object.prototype.hasOwnProperty.call(old.props,field))row.props[field]=old.props[field]}
}
for(const owner of proposal.all98NumericOwnedSignalBranches.filter(row=>row.originalSourceTraceId==="source_trace_4")){
  const row=named(restoredRows,owner.traceName),old=named(oldRows,owner.traceName)
  delete row.props.pcbPath;if(Object.prototype.hasOwnProperty.call(old.props,"pcbPath"))row.props.pcbPath=old.props.pcbPath
}
assert.equal(canonical(restored),canonical(before),"Full Source22 inverse: every key/container/child order/property presence outside the exact deltas remains held")
assert.equal(canonical(after),untouched,"Actual proposed Source23 tree was not mutated by the inverse")
assert.equal(newRows.filter(r=>r.kind==="literal"&&r.type==="via").length,227)
assert.equal(newRows.filter(r=>r.kind==="literal"&&r.type==="bus").length,8)
for(const logical of proposal.all49OriginalLogicalTraces){const now=named(newRows,logical.name);assert.equal(now.type,"trace");assert.equal(now.props.from,logical.from);assert.equal(now.props.to,logical.to)}
writeFileSync(output,JSON.stringify({scope:"ACTUAL_ROOT_SOURCE23_CAPTURE_WITH_PLANNED_SOURCE22_INVERSE",passed:true,fullInverseSourceTreePassed:true,parent22ActualQualificationInherited:false,parent22FullInverseSourceTreePassed:parent22Inverse.fullInverseSourceTreePassed,parent22BeforeBuildDiagnosticPath,parent22BeforeBuildDiagnosticSha256:sha(readFileSync(parent22BeforeBuildDiagnosticPath)),plannedSource22ReactElements:2264,proposedReactElementCount:2268,original49LogicalTracesHeld:true,original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse:true,genuineNewInnerPortCount:36,exactNewPortDeclarations:4,exactChangedOriginalRouteDeclarations:2,exactChangedLocalSource4Suppressions:2,expectedPhysicalVias:227,expectedPhysicalTraces:286,expectedCarrierPaths:23,missingOriginal49RequestsExpected:26,sourceOnlyProposalSha256:sha(readFileSync(new URL("./source23-proposal.json",import.meta.url))),actualSourceTree:after,actualDiagnosticPath:diagnostic,actualDiagnosticSha256:sha(readFileSync(diagnostic)),actualOld18SourceCheckpointHeld:true,transitiveAncestorCoreDefinitionsImported:true,pureSourceEvaluationExecuted:true,circuitConstructed:false,coreRendered:false,nativeExecuted:false,cadExecuted:false,automaticCoreSrjForThisForkMustNotBeUsed:true,referenceQualified:false,electricalTimingPassed:false,all49Accepted:false,fabricationReady:false},replacer,2)+"\n",{flag:"wx",mode:0o600})
