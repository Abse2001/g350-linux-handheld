"""Pure18-part/+2existingvia coordinate proposal from qualifiedV6; no source runtime."""
from pathlib import Path
import copy,hashlib,json,math
ROOT=Path(__file__).resolve().parent
old=json.loads((ROOT/'inputs/v6-layout.circuit.json').read_bytes())
sources={e['source_component_id']:e for e in old if e['type']=='source_component'}
components={sources[e['source_component_id']]['name']:e for e in old if e['type']=='pcb_component' and e['source_component_id'] in sources}
moved=['U_RAM',*[f'C_DDR_RAM_{i}' for i in range(1,13)],'C_DDR_RAM_BULK1','C_DDR_RAM_BULK2','C_VREF_RAM_CA','C_VREF_RAM_DQ','R_DDR_ZQ']
assert len(moved)==18 and len(set(moved))==18
poses={n:{'pcbX':components[n]['center']['x']+1.2,'pcbY':components[n]['center']['y'],'layer':components[n]['layer'],'pcbRotation':components[n]['rotation']} for n in moved}
refs={'V_TI_RAM7_POWER':{'pcbX':6.65+1.2,'pcbY':8.55},'V_TI_RAM7_GROUND':{'pcbX':6.45+1.2,'pcbY':7.95}}
rows=[{'name':n,'pcbComponentId':components[n]['pcb_component_id'],'before':components[n]['center'],'after':{'x':poses[n]['pcbX'],'y':poses[n]['pcbY']},'layer':poses[n]['layer'],'rotation':poses[n]['pcbRotation']} for n in moved]
(ROOT/'source/lib/am3352/placement/g350-ti-top-bottom-ddr-v7-translation.json').write_text(json.dumps({'parts':poses,'references':refs},indent=2)+'\n')
proposal={'scope':'Copied physicalV7 only; exact+1.2mmX/0Y RAM/support/reference translation','baseV6LayoutSha256':hashlib.sha256((ROOT/'inputs/v6-layout.circuit.json').read_bytes()).hexdigest(),'deltaMm':{'x':1.2,'y':0},'originalPartsMoved':rows,'movedOriginalParts':18,'supportPartCount':17,'referencePrimitives':refs,'referenceSourceTraceIds':['source_trace_932','source_trace_933'],'referenceViaIds':['pcb_via_0','pcb_via_1'],'referenceAliasPorts':['pcb_port_1161','pcb_port_1162','pcb_port_1163','pcb_port_1164'],'cpuAndCpu13AllOtherPartsFixed':True,'originalParts':280,'originalPhysicalContacts':1161,'logicalDdrSignals':49,'freshEndpointAuditRequired':True,'prospectiveConstraints':{'byte0MaxPlanarMm':13.2,'byte1MaxPlanarMm':14.4,'derivedByte1ManhattanMm':15.6,'commandMaxManhattanMm':14.8,'caclmMm':22.42,'commandMinPlanarMm':21.15,'commandMaxPlanarMm':23.69,'busSkewMm':.635,'pairSkewMm':.127},'actualSourceBuilds':0,'actualRoutingPerformed':False,'accepted49':False,'fabricationReady':False}
(ROOT/'source-delta.json').write_text(json.dumps(proposal,indent=2)+'\n');print(json.dumps({'movedOriginalParts':18,'referenceVias':2,'sourceExecuted':False}))
