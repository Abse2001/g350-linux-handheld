#!/usr/bin/env python3
"""SOURCE ONLY: Root-run Source313 evidence increment and restoration-only smoke.

No SDK/native/CAD/application modules are imported or executed. Build copies the
closed311--316 evidence into a new /tmp checkpoint, then publishes a new regular
deterministic archive. Verify executes only the two existing pinned restorers.
Every actual target and dependency link is checked before the zero-write test.
"""
import argparse, datetime, gzip, hashlib, json, os, re, shutil, stat, subprocess, sys, tarfile, tempfile
from pathlib import Path, PurePosixPath

BOARD = Path('/workspace/g350-linux-handheld')
BASE = Path('/tmp/g350-model299-portable-increment-20261016')
BASE_REL = '.cloud-tools/ddr-four-layer-model299-2026-10-16'
BASE_STEM = 'g350-four-layer-ca16-model299-source289-base-2026-10-16'
BASE_ARCHIVE_SHA = 'bf63e126db40168b7bdda4031d10a9ed8e56f87d1de67118caa3fb9ff64257cb'
BASE_MANIFEST_SHA = 'f5d91f0edda8b93a0a49a6a7c10a9a25fc3a074c363b4bf5410c68a4ecc66443'
BASE_PINS = {
    'PROGRESS.json': 'b1fe7980a26238a9b9327866888cf0a73cb3a0f6302800aadc6c40f3bdcf5e69',
    'README.md': 'e558bc5d80a1e0578d7c6ecd649988c40c5a20d5d7f881bde9f513e713be711f',
    'WORKSPACE_HASH_INDEX.json': 'cb9381505a36e5be2f05e3231c0ff4a052c021327b7f70907fe6077dbacdefc9',
    'WORKSPACE_RESTORE_MANIFEST.json': '1394350eaa5ba10290a0dacdc38fe1cfafd7c2677d74c979fc715fb71009e075',
}
SAVED = Path('/tmp/g350-source313-portable-increment-20261016')
SAVED_REL = '.cloud-tools/ddr-four-layer-source313-2026-10-16'
STEM = 'g350-four-layer-both-bytes-ca16-connected49-source313-2026-10-16'
SCOPE = 'PORTABLE_SOURCE313_CA16_TI3W_EDITABLE_CONNECTED49_CHECKPOINT'
PROFILE = Path('/tmp/g350-source313-portable-increment-profile-sourceonly.json')
PROFILE_SHA = '50fe53eb0adc0868d0e13f2607d4b5bae67931a8f6a7f72869bb3a4e0167c441'
CANDIDATE_SHA = '8abef05761375014f8a310f9cfcab92d7a5b7da978598fe4a49b1c118658d34d'
PLAN_SHA = '35f5fb65d14e5386797eaf24475813f6205a65466ac2df600e12f38f31b0ce74'
CAPTURE_SHA = '8da7d8270e6994c5afa255cc90953e7f3393e84f32cba674c0b838457a5c05b0'
RAW_SHA = '2899641a823e870db43b4dde16cec50bcebec8434ef09ebf5d980300d087c59e'
CONTROL_SHA = '3bda070f41549fef4c33f455132b2e3a5d34100a7c3abbf01cc1b8014373a33a'
SOLVER_ROOT = '/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib'
RESTORER = BOARD/'scripts/restore-g350-routing-evidence.py'
RESTORER_SHA = '148bad0fc4132ece5f78f18b05e4bc71d79019312343eda954ed7ca91874a643'
HELPER = BOARD/'scripts/restore-g350-four-layer-routing-workspace.py'
HELPER_SHA = '6c5d321a256eadf58697f0f565b5bffa4a55491fce39ed0db7e7675604b6f3cc'
META = ('README.md', 'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json')
FALSE = dict.fromkeys(('all49Accepted', 'fullBoardPassed', 'nativeBoardPassed', 'fullTimingPassed',
    'electricalTimingQualified', 'tiQualified', 'referenceContinuityQualified', 'cadQualified',
    'defaultBoardPromoted', 'fabricationReady', 'currentPourQualified'), False)

def need(value, message):
    if not value:
        raise ValueError(message)

def regular(path):
    return path.is_file() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)

def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            result.update(block)
        os.posix_fadvise(stream.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return result.hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def md(path):
    return {'bytes': path.stat().st_size, 'sha256': sha(path), 'mode': stat.S_IMODE(path.stat().st_mode)}

def exact(path, row):
    need(regular(path) and md(path) == {key: row[key] for key in ('bytes', 'sha256', 'mode')}, 'Exact bytes/hash/mode '+str(path))

def relative(name):
    path = PurePosixPath(name)
    need(path.parts and not path.is_absolute() and '..' not in path.parts and str(path) == name and '\\' not in name, 'Canonical relative member')
    return Path(*path.parts)

def write(path, data):
    with path.open('x') as stream:
        os.fchmod(stream.fileno(), 0o600)
        json.dump(data, stream, indent=2, allow_nan=False)
        stream.write('\n')

def publish(temporary, final):
    os.link(temporary, final)
    temporary.unlink()

def base_controls(args):
    need(args.model299_archive_sha == BASE_ARCHIVE_SHA and args.model299_manifest_sha == BASE_MANIFEST_SHA, 'Explicit reviewed Model299 archive pins')
    for name, digest in BASE_PINS.items():
        need(regular(BASE/name) and sha(BASE/name) == digest, 'Frozen Model299 metadata '+name)
    index, manifest, progress = [read(BASE/name) for name in ('WORKSPACE_HASH_INDEX.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'PROGRESS.json')]
    need(len(index['files']) == 16 and len(manifest['files']) == 13 and len(manifest['baseDependencyRestoreFiles']) == 167, 'Exact base17/13/167')
    need(manifest['solverSourceRoot'] == SOLVER_ROOT and progress['primaryCandidate']['candidateSha256'] == CANDIDATE_SHA, 'Real solver root/current model299')
    need({path.name for path in BASE.iterdir()} == {row['path'] for row in index['files']} | {'WORKSPACE_HASH_INDEX.json'}, 'Complete immutable Model299 inventory')
    for row in index['files']:
        exact(BASE/relative(row['path']), row)
    targets = [{'baseSavedDirectory': BASE_REL, **row} for row in manifest['files']] + manifest['baseDependencyRestoreFiles']
    need(len(targets) == len({row['restorePath'] for row in targets}) == 180, 'Unique180 existing base targets')
    for row in targets:
        exact(Path(row['restorePath']), row)
    archive = BOARD/('cloud/artifacts/'+BASE_STEM+'.tar.gz')
    metadata = archive.with_name(BASE_STEM+'.manifest.json')
    for path, digest in ((archive, BASE_ARCHIVE_SHA), (metadata, BASE_MANIFEST_SHA)):
        need(regular(path) and sha(path) == digest, 'Actual published Model299 archive/manifest')
    am = read(metadata)
    need(am['scope'] == 'PORTABLE_MODEL299_CA16_INCREMENT_NOT_FRESH_SOURCE' and am['archive']['sha256'] == BASE_ARCHIVE_SHA and am['archive']['bytes'] == archive.stat().st_size, 'Exact Model299 archive metadata')
    need(len(am['files']) == 17 and am['workspaceRestoreTargetCount'] == 13 and am['baseRestoreTargetCount'] == 167, 'Complete portable Model299 closure')
    need(am['snapshotPins'] == {BASE_REL+'/'+name: digest for name, digest in BASE_PINS.items()}, 'All four Model299 metadata pins')
    for row in am['files']:
        member = relative(row['path'])
        need(member.parent.as_posix() == BASE_REL, 'Only exact base canonical folder')
        exact(BASE/member.name, row)
    for dependency in progress['baseArchiveDependenciesInRestoreOrder']:
        for key, digest in (('path', dependency['sha256']), ('manifest', dependency['manifestSha256'])):
            path = BOARD/relative(dependency[key])
            need(regular(path) and sha(path) == digest, 'All six prior archive dependencies unchanged')
    dependency = {**am['archive'], 'manifest': metadata.relative_to(BOARD).as_posix(), 'manifestSha256': BASE_MANIFEST_SHA,
        'mustBeRestoredFirst': True, 'payloadCopiedByThisCollector': False}
    return manifest, progress, targets, dependency

def evidence():
    need(regular(PROFILE) and sha(PROFILE) == PROFILE_SHA, 'Frozen Source313 profile')
    profile = read(PROFILE)
    rows = profile['artifacts']
    need(len(rows) == len({r['savedPath'] for r in rows}) == len({r['restorePath'] for r in rows}) == 38, 'Unique exact38 payloads')
    need(sum(r['bytes'] for r in rows) == profile['plannedPayloadBytes'] == 45976719, 'Measured closed payload bytes')
    need(not ({r['savedPath'] for r in rows} & set(META)), 'No metadata alias collisions')
    for row in rows:
        need(Path(row['restorePath']).is_absolute() and Path(row['restorePath']).is_relative_to('/tmp'), 'Tmp-only actual restore targets')
        need(relative(row['savedPath']).parent == Path('.'), 'Flat explicit aliases')
        exact(Path(row['restorePath']), row)
    by_name = {r['savedPath']: r for r in rows}
    load = lambda name: read(Path(by_name[name]['restorePath']))
    plan, capture, controls, raw = [load(name) for name in ('source-plan.json', 'source-capture.json', 'core-controls.json', 'raw-core.json')]
    need([by_name[name]['sha256'] for name in ('source-plan.json', 'source-capture.json', 'core-controls.json', 'raw-core.json')] == [PLAN_SHA, CAPTURE_SHA, CONTROL_SHA, RAW_SHA], 'Exact311/312/313 bindings')
    need(plan['inputBindings']['candidate']['sha256'] == CANDIDATE_SHA and len(plan['routedOwnerIds']) == 49 and plan['pendingOwnerIds'] == [], 'Actual model299 all49 plan')
    need(len(plan['newVias']) == 103 and len(plan['innerPortRegistrations']) == 80 and all(v['name'].startswith('V_BOTH_BYTES_CA16_TI3W_MATCH49_') for v in plan['newVias']), 'Unique replay namespace/N103/I80')
    need(capture['passed'] is True and capture['fullInverseSourceTreePassed'] is True and capture['parentNormalizationInversePassed'] is True and capture['planSha256'] == PLAN_SHA and capture['candidateSha256'] == CANDIDATE_SHA, 'Actual312 complete capture inverse')
    need(controls['rawCoreSha256'] == RAW_SHA and controls['planSha256'] == PLAN_SHA and controls['actualCaptureSha256'] == CAPTURE_SHA and controls['candidateSha256'] == CANDIDATE_SHA, 'Fresh Core313 actual byte bindings')
    need(controls['freshCoreControlPassed'] is True and controls['freshCoreDerived'] is True and len(controls['checks']) == 35 and all(q['passed'] is True for q in controls['checks']), 'All35 fresh controls')
    owners = {'source_trace_'+str(i) for i in range(49)}
    need({r['originalSourceTraceId'] for r in controls['logical49Projection']} == owners and all(r['passed'] is True for r in controls['logical49Projection']), 'Original49 actual semantic ownership')
    need(len(controls['physicalGraphs']) == 49 and all(r['physicallyConnectedByActualOwnedNumericIdGraph'] is True for r in controls['physicalGraphs']) and controls['pendingOwnerIds'] == [] and controls['all49Connected'] is True, 'All49 actual owned numeric graphs')
    expected = {'physicalVias': 234, 'pcbComponents': 514, 'sourceAndPcbPorts': 1713, 'sourceTraces': 1097, 'physicalTraces': 317, 'reactElements': 2225, 'newSignalVias': 103, 'newPdnVias': 2, 'routedWireRuns': 152, 'auxiliaryLocalTraces': 0}
    need(all(controls['expectedCounts'][k] == v for k, v in expected.items()), 'Exact current actual inventory')
    need(isinstance(raw, list) and sum(r['type'] == 'pcb_copper_pour' for r in raw) == 19, 'Nineteen current pours remain unqualified')
    timing = controls['timingObservations']
    need([r['withinTolerance'] for r in timing['cohorts']] == [True, True, False] and len(timing['pairs']) == 3 and all(r['withinTolerance'] is True for r in timing['pairs']), 'Observed both bytes/pairs pass; CA still fails')
    focused, auth, complement = [load('RUN'+str(n)+'_byte0-result.json') for n in (314, 315, 316)]
    for report in (focused, complement):
        need(report['completed'] is True and report['finished'] is True and report['completedCheckCount'] == 16 and report['exceptionCount'] == 0 and report['allPinnedInputsUnchanged'] is True, 'Actual fresh complete16 no exceptions')
        need(report['inputBindings']['raw']['sha256'] == RAW_SHA and report['inputBindings']['controls']['sha256'] == CONTROL_SHA and report['inputBindings']['reviewedSourcePlan']['sha256'] == PLAN_SHA, 'Same actual313 inputs for native union')
        need(len(report['results']) == 16 and all(r['state'] == 'completed' and r['findingCount'] == len(r['findings']) and r['checkInputMutated'] is False for r in report['results']), 'All unfiltered native result objects retained')
    results = focused['results'] + complement['results']
    names = [r['name'] for r in results]
    need(len(names) == len(set(names)) == 32 and set(names) == set(complement['original32CheckNames']), 'Exact disjoint original32 roster')
    summary = [{'name': r['name'], 'findingCount': len(r['findings'])} for r in results]
    need(summary == profile['native32ObservedCheckSummary'] and sum(r['findingCount'] for r in summary) == 951, 'Actual full32 total951')
    nonzero = {r['name']: len(r['findings']) for r in results if r['findings']}
    need(nonzero == {'checkPcbBusLengthSkew': 1, 'checkSourceTracesHavePcbTraces': 70, 'checkEachPcbPortConnectedToPcbTraces': 718, 'checkSourceTracesMatchPcbTraceThickness': 162}, 'Exact unfiltered951 distribution; no board pass')
    audit = complement['direct49ThicknessWarningAudit']
    need(audit['completed'] is True and audit['totalUnfilteredThicknessFindingCount'] == 162 and audit['direct49FindingCount'] == 0 and audit['direct49Findings'] == [] and audit['unresolvedFindingSourceIdentities'] == [] and audit['zeroDirect49ThicknessWarnings'] is True and audit['findingsFilteredOrWaived'] is False, 'Current direct49 thickness audit0 without filtering')
    need(auth['complete'] is True and auth['executed'] is True and auth['actualViaCount'] == auth['completedViaCount'] == len(auth['viaReports']) == 234 and auth['foreignViaTrackCopperClearancePassed'] is True and auth['exactInputFilesUnchanged'] is True, 'Actual315 all234 authenticated')
    need(all(auth[k] == [] for k in ('violations', 'ambiguousVias', 'identityFailures', 'invalidSegments', 'unresolvedSegmentOwners')), 'No auth/foreign-track ambiguity or violation')
    need(auth['inputBindings']['raw']['sha256'] == RAW_SHA and auth['inputBindings']['controls']['sha256'] == CONTROL_SHA and auth['inputBindings']['plan']['sha256'] == PLAN_SHA, 'Auth315 binds same actual Source313')
    for n in range(311, 317):
        receipt = load('RUN'+str(n)+'_COLLECTED.json')
        execution = receipt['execution']
        need(receipt['scope'] == n and receipt['sourcePinsUnchanged'] is True and receipt['protectedFilesUnchanged'] is True and execution['exitCode'] == 0 and execution['cleanupOwnedGroupEmpty'] is True and execution['diagnosticStopped'] is False, 'Actual closed'+str(n)+' passed/no owned process')
        need(load('RUN'+str(n)+'_owned_execution.json') == execution, 'Literal execution closure'+str(n))
        need(execution['policy']['wallSeconds'] == 180 and execution['policy']['rssBytes'] == 2*1024**3 and execution['policy']['sharedBytes'] == 30*1024**3, 'Original bounded resource policy')
    return profile, rows, controls, summary

def build(args):
    need(not SAVED.exists(), 'Fresh Source313 staging folder')
    base, progress, base_targets, dependency = base_controls(args)
    profile, payloads, controls, summary = evidence()
    need(shutil.disk_usage('/tmp').free > profile['plannedPayloadBytes']+1024**3, 'Measured tmp payload plus1GiB reserve')
    need(int(Path('/sys/fs/cgroup/memory.current').read_text())+128*1024**2+1024**3 < 30*1024**3, 'Shared30GiB plus1GiB reserve')
    archive = BOARD/('cloud/artifacts/'+STEM+'.tar.gz')
    manifest_path = archive.with_name(STEM+'.manifest.json')
    need(not archive.exists() and not manifest_path.exists(), 'New immutable archive pair')
    SAVED.mkdir(mode=0o700)
    rows = []
    extras = [(PROFILE, 'SOURCE313_CHECKPOINT_PROFILE.json'), (Path(__file__).resolve(), 'SOURCE313_PORTABLE_INCREMENT_SOURCE.py')]
    source_rows = payloads + [{'restorePath': str(p), 'savedPath': name, **md(p)} for p, name in extras]
    need(len(source_rows) == len({r['savedPath'] for r in source_rows}) == 40 and not ({r['restorePath'] for r in source_rows} & {r['restorePath'] for r in base_targets}), 'Unique40 local plus180 base targets')
    for row in source_rows:
        source, destination = Path(row['restorePath']), SAVED/row['savedPath']
        exact(source, row)
        with source.open('rb') as src, destination.open('xb') as dst:
            shutil.copyfileobj(src, dst, 1048576)
            os.fchmod(dst.fileno(), row['mode'])
        exact(destination, row)
        rows.append(row)
    dependencies = progress['baseArchiveDependenciesInRestoreOrder']+[dependency]
    checkpoint = {'scope': SCOPE, 'candidateSha256': CANDIDATE_SHA, 'candidateBaseSavedDirectory': BASE_REL,
        'savedCandidate': progress['primaryCandidate']['savedCandidate'], 'coreScope': 313, 'planSha256': PLAN_SHA,
        'captureSha256': CAPTURE_SHA, 'rawCoreSha256': RAW_SHA, 'controlsSha256': CONTROL_SHA,
        'savedRawCore': 'raw-core.json', 'savedControls': 'core-controls.json', 'savedPlan': 'source-plan.json',
        'savedCapture': 'source-capture.json', 'routedOwners': 49, 'pendingOwnerIds': [], 'freshCoreControlsPassed': 35,
        'all49OwnedNumericGraphsPassed': True, 'byte0PlanarSkewPassed': True, 'byte1PlanarSkewPassed': True,
        'caMinimumPassingCount': 16, 'caUnderMinimumCount': 10, 'caPlanarSkewPassed': False,
        'freshOriginal32Completed': True, 'nativeExceptionCount': 0, 'nativeTotalFindings': 951,
        'authenticatedViaCount': 234, 'authenticatedForeignViaTrackPassed': True,
        'unqualifiedCurrentPourCount': 19, 'previousSourceOrCadQualificationInherited': False, **FALSE}
    common = {'scope': SCOPE, 'frozenCheckpoint': True, 'updatedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'latestClosedScopeIncluded': 316, 'primaryCandidate': checkpoint, 'latestSourceVerifiedCheckpoint': checkpoint,
        'latestEditableSourceSavedDirectory': SAVED_REL, 'latestEditableSourceCoreScope': 313,
        'baseArchiveDependency': dependency, 'baseArchiveDependenciesInRestoreOrder': dependencies,
        'laterWorkRequiresNewSavedDirectory': True, 'source272CadQualificationInherited': False,
        'source289NativeQualificationInherited': False, 'sdkExecutedByCollector': False, **FALSE}
    restore = {**common, 'solverSourceRoot': SOLVER_ROOT, 'files': rows, 'baseDependencyRestoreFiles': base_targets,
        'immutableWorkspaceAssets': [], 'immutableAssetsRestoredByBaseArchives': base['immutableAssetsRestoredByBaseArchives']}
    write(SAVED/'WORKSPACE_RESTORE_MANIFEST.json', restore)
    with (SAVED/'README.md').open('x') as stream:
        os.fchmod(stream.fileno(), 0o600)
        stream.write('Source313:49 editable connected signal routes;35 fresh Core controls PASS.\n'
            'Resume raw-core.json, core-controls.json, source-plan.json and source-capture.json here.\n'
            'Candidate299 is in the required Model299 base increment; only Source24 body changed from286.\n'
            'Both byte cohorts and all three pairs pass planar skew; CA16/26 meet minimum,10 remain short.\n'
            'FullCA skew17.6628187566mm FAILS. WholeTI/electrical/default/fabrication are false.\n'
            'Fresh314+316 complete all32 native checks:951 unfiltered findings,0 exceptions:\n'
            '1 CA skew,70 missing source traces,718 unconnected ports,162 thickness warnings.\n'
            'Current49 direct logical DDR owners have0 thickness warnings; broader findings are retained.\n'
            'Fresh315 authenticates234 vias with0 ambiguity/identity/foreign-track violations.\n'
            'All19 current pours remain UNQUALIFIED. Source272 CAD/earlier pour results are not inherited.\n'
            'Restore209→228→248→257→272-v2→289→Model299, then this Source313 increment.\n'
            'Only stdlib copying/archiving and restoration-only checks run in this helper; no SDK/CAD.\n')
    write(SAVED/'PROGRESS.json', {**common, 'currentTimingObservations': controls['timingObservations'],
        'native32ObservedCheckSummary': summary, 'fullNativeFindingsRetained': True,
        'evidence': rows, 'archiveCreatedByOwnStdlib': True})
    index = [{'path': p.name, **md(p)} for p in sorted(SAVED.iterdir())]
    write(SAVED/'WORKSPACE_HASH_INDEX.json', {'scope': SCOPE, 'files': index, 'selfExcluded': True, 'frozenCheckpoint': True})
    members = [{'path': SAVED_REL+'/'+p.name, '_source': p, **md(p)} for p in sorted(SAVED.iterdir())]
    need(len(members) == 44 and len(index) == 43 and len(rows) == 40, 'Exact44members/index43/40targets')
    temporary = durable = metadata_temporary = None
    try:
        fd, name = tempfile.mkstemp(prefix='g350-source313-', suffix='.tar.gz', dir='/tmp')
        temporary = Path(name)
        with os.fdopen(fd, 'wb') as output:
            os.fchmod(output.fileno(), 0o600)
            with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=6) as gz:
                with tarfile.open(mode='w|', fileobj=gz, format=tarfile.PAX_FORMAT) as tf:
                    for row in members:
                        exact(row['_source'], row)
                        info = tarfile.TarInfo(row['path'])
                        info.size, info.mode, info.mtime = row['bytes'], row['mode'], 0
                        info.uid = info.gid = 0
                        info.uname = info.gname = ''
                        with row['_source'].open('rb') as source:
                            tf.addfile(info, source)
                        exact(row['_source'], row)
            output.flush()
            os.fsync(output.fileno())
        base_controls(args)
        evidence()
        for row in source_rows:
            exact(Path(row['restorePath']), row)
        actual = {'path': archive.relative_to(BOARD).as_posix(), **md(temporary)}
        am = {'schemaVersion': 1, 'scope': SCOPE, 'regularFilesOnly': True, 'historicalDataOnly': True, 'archive': actual,
            'files': [{k: v for k, v in row.items() if k != '_source'} for row in members],
            'inputDirectories': [SAVED_REL], 'extraWorkspaceAssetMembers': [], 'baseArchiveDependenciesInRestoreOrder': dependencies,
            'baseArchivesIncluded': False, 'workspaceRestoreTargetCount': 40, 'baseRestoreTargetCount': 180,
            'snapshotPins': {SAVED_REL+'/'+name: sha(SAVED/name) for name in META},
            'primaryCandidate': {'baseSavedDirectory': BASE_REL, 'path': BASE_REL+'/'+checkpoint['savedCandidate'], 'sha256': CANDIDATE_SHA},
            'latestSourceVerifiedCheckpoint': checkpoint, 'latestEditableSourceCoreScope': 313, 'solverSourceRoot': SOLVER_ROOT, **FALSE}
        fd, name = tempfile.mkstemp(prefix='.'+manifest_path.name+'.', suffix='.partial', dir=manifest_path.parent)
        metadata_temporary = Path(name)
        with os.fdopen(fd, 'w') as stream:
            os.fchmod(stream.fileno(), 0o600)
            json.dump(am, stream, indent=2, allow_nan=False)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        need(shutil.disk_usage(archive.parent).free > temporary.stat().st_size+256*1024**2, 'Measured compressed archive plus256MiB durable reserve')
        fd, name = tempfile.mkstemp(prefix='.'+archive.name+'.', suffix='.partial', dir=archive.parent)
        durable = Path(name)
        with temporary.open('rb') as source, os.fdopen(fd, 'wb') as output:
            shutil.copyfileobj(source, output, 1048576)
            os.fchmod(output.fileno(), 0o600)
            output.flush()
            os.fsync(output.fileno())
        exact(durable, actual)
        publish(durable, archive)
        durable = None
        publish(metadata_temporary, manifest_path)
        metadata_temporary = None
        print(json.dumps({'archive': str(archive), 'archiveSha256': sha(archive), 'manifest': str(manifest_path),
            'manifestSha256': sha(manifest_path), 'members': 44, 'tmpTargets': 40, 'baseTargets': 180,
            'latestEditableSource': 313, 'nativeFindings': 951, 'currentPoursQualified': False, 'sdkExecuted': False}))
    finally:
        for path in (temporary, durable, metadata_temporary):
            if path is not None and path.exists():
                path.unlink()

def verify(args):
    _, _, base_targets, _ = base_controls(args)
    evidence()
    archive = BOARD/('cloud/artifacts/'+STEM+'.tar.gz')
    metadata = archive.with_name(STEM+'.manifest.json')
    for path, digest in ((archive, args.archive_sha), (metadata, args.manifest_sha)):
        need(digest and re.fullmatch('[0-9a-f]{64}', digest) and regular(path) and sha(path) == digest, 'Explicit actual Source313 archive hashes')
    am = read(metadata)
    need(am['scope'] == SCOPE and am['archive']['sha256'] == args.archive_sha and len(am['files']) == 44, 'Exact44-member Source313 increment')
    for path, digest in ((RESTORER, RESTORER_SHA), (HELPER, HELPER_SHA)):
        need(regular(path) and sha(path) == digest, 'Pinned existing restoration helper')
    owned = Path(tempfile.mkdtemp(prefix='g350-source313-smoke-', dir='/tmp'))
    destination = owned/'extracted'
    commands = []
    def run(argv):
        result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=120, check=False)
        commands.append({'argv': argv, 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
        need(result.returncode == 0, 'Restoration-only verifier returned success')
        return result.stdout
    try:
        command = [sys.executable, str(RESTORER), str(metadata), '--destination', str(destination)]
        need(run(command+['--verify-archive']).strip() == 'Verified 44 evidence members; restored 0', 'Exact archive verification')
        need(run(command).strip() == 'Verified 44 evidence members; restored 44', 'Isolated44-file extraction')
        need({p.relative_to(destination).as_posix() for p in destination.rglob('*') if p.is_file()} == {r['path'] for r in am['files']}, 'Only exact regular extracted members')
        for row in am['files']:
            exact(destination/relative(row['path']), row)
        for name, digest in am['snapshotPins'].items():
            need(sha(destination/relative(name)) == digest, 'All extracted metadata pins')
        saved = destination/SAVED_REL
        manifest = read(saved/'WORKSPACE_RESTORE_MANIFEST.json')
        need(len(manifest['files']) == 40 and manifest['baseDependencyRestoreFiles'] == base_targets and manifest['solverSourceRoot'] == SOLVER_ROOT and manifest['latestEditableSourceCoreScope'] == 313, 'Exact compatible40+180 restore schema')
        targets = manifest['files']+base_targets
        need(len(targets) == len({r['restorePath'] for r in targets}) == 220, 'All220 distinct actual targets exist before no-op restore')
        for row in targets:
            exact(Path(row['restorePath']), row)
        link = Path(SOLVER_ROOT).parent/'node_modules'
        need(link.is_symlink() and link.resolve() == (BOARD.parent/'bus-lanes-solver/node_modules').resolve(), 'Exact preexisting dependency symlink')
        link_id = (link.lstat().st_dev, link.lstat().st_ino, link.lstat().st_mtime_ns, link.lstat().st_ctime_ns, os.readlink(link))
        result = json.loads(run([sys.executable, str(HELPER), '--saved-directory', str(saved), '--restore']))
        need(result['savedFilesVerified'] == 40 and result['restoredFiles'] == 0 and result['mode'] == 'restore', 'Actual unchanged restore branch writes zero files')
        for row in targets:
            exact(Path(row['restorePath']), row)
        need((link.lstat().st_dev, link.lstat().st_ino, link.lstat().st_mtime_ns, link.lstat().st_ctime_ns, os.readlink(link)) == link_id, 'Dependency link unchanged')
        base_controls(args)
        evidence()
        need(sha(archive) == args.archive_sha and sha(metadata) == args.manifest_sha, 'Archive inputs unchanged')
        shutil.rmtree(destination)
        write(owned/'REPORT.json', {'scope': 'SOURCE313_ISOLATED_EXTRACTION_AND220_TARGET_NOOP_RESTORE', 'passed': True,
            'commands': commands, 'archiveSha256': args.archive_sha, 'manifestSha256': args.manifest_sha,
            'isolatedPayloadRemoved': True, 'all220ActualTargetsUnchanged': True, 'existingHelperRestoreCodePathExecuted': True,
            'restoredWorkspaceFiles': 0, 'latestEditableSource': 313, 'sdkExecuted': False, **FALSE})
        print(json.dumps({'report': str(owned/'REPORT.json'), 'sha256': sha(owned/'REPORT.json'), 'passed': True, 'sdkExecuted': False}))
    except BaseException as error:
        write(owned/'FAILURE.json', {'passed': False, 'error': str(error), 'commands': commands, 'isolatedPayloadPreserved': destination.exists(), **FALSE})
        raise

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['build', 'verify'])
    parser.add_argument('--model299-archive-sha', required=True)
    parser.add_argument('--model299-manifest-sha', required=True)
    parser.add_argument('--archive-sha')
    parser.add_argument('--manifest-sha')
    args = parser.parse_args()
    (build if args.mode == 'build' else verify)(args)

if __name__ == '__main__':
    main()
