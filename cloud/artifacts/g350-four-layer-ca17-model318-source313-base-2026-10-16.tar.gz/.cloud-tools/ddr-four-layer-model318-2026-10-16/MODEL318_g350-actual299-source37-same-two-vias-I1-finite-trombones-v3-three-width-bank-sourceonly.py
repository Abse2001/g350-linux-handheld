"""Own stdlib finite manualI1 trombone proposals for37, two authenticexistingcarrier vias, noSDK."""
exec(open('/tmp/g350-actual286-source7-lower-arc-straight-refill-draft-sourceonly.py').read().split('old7=')[0])
P299='/tmp/g350-source24-TI3W-foreign34W-matched49-finite1g-root-20261016-run299/byte0-result.candidate.json';B299=Path(P299).read_bytes();assert hashlib.sha256(B299).hexdigest()=='8abef05761375014f8a310f9cfcab92d7a5b7da978598fe4a49b1c118658d34d';p299=json.loads(B299);assert p299['full49FanoutInput']==f;bt={owner(t):t for t in p299['carrierTraces']};oo=[o for o in os if o['id']not in{t['pcb_trace_id']for t in by.values()}]
for t in bt.values():oo.extend(bodyobjects(t))
pp='/tmp/g350-actual284-source37-first-signal-via-SWpoint1-exact-inverse-report.json';bb=Path(pp).read_bytes();assert hashlib.sha256(bb).hexdigest()=='a624a59ef08d6808aa537925e8e8cbaea4517d0ccc9b2c07d57c5452ace414a0';proof=json.loads(bb);assert proof['bodyInverse']['before']==bt['source_trace_37'];old=copy.deepcopy(proof['bodyInverse']['after']);old['pcb_trace_id']='PLANNED37_SW1_I1_MATCHING_TROMBONES';ss=Scene([o for o in oo if o['id']!=bt['source_trace_37']['pcb_trace_id']]);assert not ss.contacts(old);assert all(x['passedPureMath']for x in selfreports(old));t=copy.deepcopy(old);baseWhole=length(t)+sum(length(a)for a in f['traces']if owner(a)==owner(t));started=time.monotonic();attempts=0;passed=0;history=[];lim=45.;target=21.2

def bump(a,b,p,q,D,c=.002):
 ll=math.hypot(b['x']-a['x'],b['y']-a['y']);ux=(b['x']-a['x'])/ll;uy=(b['y']-a['y'])/ll;nx=-uy;ny=ux;sn=1 if D>0 else-1;dd=abs(D)
 def pt(d,n):return{'route_type':'wire','layer':a['layer'],'width':.1016,'x':a['x']+ux*d+nx*n*sn,'y':a['y']+uy*d+ny*n*sn}
 return[pt(p-c,0),pt(p,c),pt(p,dd-c),pt(p+c,dd),pt(q-c,dd),pt(q,dd-c),pt(q,c),pt(q+c,0)]

classes={n:b['busId']for b in f['buses']for n in b['connectionNames']}
foreignWires=[]
for ot in[*f['traces'],*bt.values()]:
 n=owner(ot)
 if n=='source_trace_37'or n not in classes:continue
 for a,b in zip(ot['route'],ot['route'][1:]):
  if a.get('route_type')==b.get('route_type')=='wire'and a.get('layer')==b.get('layer'):foreignWires.append((n,ot['pcb_trace_id'],a,b,.3048 if classes[n]=='DDR_COMMAND_CLOCK'else.4064))
def guidanceClear(nt):
 for a,b in zip(nt['route'],nt['route'][1:]):
  if a.get('route_type')!=b.get('route_type')or a.get('route_type')!='wire'or a.get('layer')!=b.get('layer'):continue
  for n,pid,c,d,required in foreignWires:
   if a['layer']==c['layer']and sd(a,b,c,d)<required-1e-8:return False
 return True

def ownViaRows(nt):
 runs=[];cur=[];ev=[]
 for i,v in enumerate(nt['route']):
  if v.get('route_type')=='wire':cur.append(v)
  else:
   runs.append(cur);cur=[];ev.append((i,v,len(runs)-1,len(runs)))
 runs.append(cur);rows=[]
 for ix,v,before,after in ev:
  rr=[]
  for j,run in enumerate(runs):
   pts=list(reversed(run))if j==before else run
   if len(pts)<2:continue
   incident=j in[before,after];exited=False;bad=[]
   if incident:assert math.hypot(pts[0]['x']-v['x'],pts[0]['y']-v['y'])<1e-8
   for k,(a,b)in enumerate(zip(pts,pts[1:])):
    dist=pd(v,a,b)
    if (exited or not incident)and dist<.381-1e-8:bad.append({'segment':k,'distanceMm':dist})
    if math.hypot(b['x']-v['x'],b['y']-v['y'])>.381+1e-8:exited=True
   rr.append({'runIndex':j,'incident':incident,'passed':not bad,'violations':bad})
  rows.append({'routeIndex':ix,'via':v,'runReports':rr,'passed':all(z['passed']for z in rr)})
 return rows

def strictI1Self(nt):
 runs=[];cur=[]
 for v in nt['route']:
  if v.get('route_type')=='wire'and v.get('layer')=='inner1':cur.append(v)
  elif cur:runs.append(cur);cur=[]
 if cur:runs.append(cur)
 return all(self_math(run,.3048)['passedPureMath']for run in runs)

for it in range(12):
 best=None;whole=length(t)+sum(length(a)for a in f['traces']if owner(a)==owner(t));remaining=target-whole
 for i,(a,b)in enumerate(zip(t['route'],t['route'][1:])):
  if not(a.get('route_type')==b.get('route_type')=='wire'and a.get('layer')==b.get('layer')=='inner1'):continue
  ll=math.hypot(b['x']-a['x'],b['y']-a['y'])
  if ll<.31:continue
  depths=[.25,.35,.5,.7,1.,1.3,1.7,2.,2.5,3.,3.5,4.,(remaining+.00468629150101524)/2]
  depths=sorted(set(round(x,10)for x in depths if x>=.25 and 2*x-.00468629150101524<=remaining+.0000001),reverse=True)
  for width in[.31,.36,.42,.55,.7,1.,1.5,2.,2.5]:
   if width+.05>ll:continue
   for frac in[0.,.25,.5,.75,1.]:
    p=.025+frac*(ll-width-.05);q=p+width
    for d in depths:
     for sign in[-1,1]:
      if time.monotonic()-started>lim:break
      cc=bump(a,b,p,q,d*sign);part={**t,'route':[a]+cc+[b]};attempts+=1
      if ss.contacts(part):continue
      raw=t['route'][:i+1]+cc+t['route'][i+1:];rr=[]
      for v in raw:
       if rr and v.get('route_type')==rr[-1].get('route_type')=='wire'and v.get('layer')==rr[-1].get('layer')and math.hypot(v['x']-rr[-1]['x'],v['y']-rr[-1]['y'])<1e-10:continue
       rr.append(v)
      nt={**t,'route':rr};ww=length(nt)+sum(length(a)for a in f['traces']if owner(a)==owner(t))
      if best and ww<=best['whole']+1e-8:continue
      if not all(x['passedPureMath']for x in selfreports(nt))or not strictI1Self(nt)or not all(x['passed']for x in ownViaRows(nt)):continue
      passed+=1;best={'body':nt,'whole':ww,'segment':i,'width':width,'p':p,'q':q,'depth':d*sign}
     if time.monotonic()-started>lim:break
    if time.monotonic()-started>lim:break
   if time.monotonic()-started>lim:break
  if time.monotonic()-started>lim:break
 if best is None:break
 t=best['body'];history.append({k:v for k,v in best.items()if k!='body'});print(json.dumps({'iteration':it,'whole':best['whole'],'points':len(t['route']),'elapsed':time.monotonic()-started}),flush=True)
 if best['whole']>=20.95 or time.monotonic()-started>lim:break
R={'scope':'OWN_STDLIB_ACTUAL299_FINITE_SAME_TWO_FULLSPAN_37_SW1_AND_MANUAL_I1_MATCHING_NOT_NATIVE','actual299Path':P299,'actual299Sha256':hashlib.sha256(B299).hexdigest(),'firstViaProposal':{'path':pp,'sha256':hashlib.sha256(bb).hexdigest()},'bodyInverse':{'before':bt['source_trace_37'],'after':t},'wholeBeforeMm':baseWhole,'wholeAfterMm':length(t)+sum(length(a)for a in f['traces']if owner(a)==owner(t)),'foreignContacts':ss.contacts(t),'selfReports':selfreports(t),'strictI1ThreeWidthSelfPassed':strictI1Self(t),'ownInlineViaAfterFirstExitReports':ownViaRows(t),'history':history,'attempts':attempts,'passingProposals':passed,'elapsedSeconds':time.monotonic()-started,'allOther48BodiesLiteral':True,'allFoundationLiteral':True,'nativeExecuted':False,'sourceCoreDerived':False,'all49Accepted':False,'timingPassed':False,'fabricationReady':False}
out=Path('/tmp/g350-actual299-source37-same-two-vias-I1-finite-trombones-v3-three-width-bank-report.json');out.open('x').write(json.dumps(R,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'whole':R['wholeAfterMm'],'elapsed':R['elapsedSeconds']}))
