#!/usr/bin/env python3
"""Own stdlib-only data/math screen, authorized by Root. No SDK/imported helper.

Preserve223's complete47 roster/foundation. Replace only ordinaryCA carriers
with exact204 objects. All results remain unqualified pending fresh C31/source.
"""
import copy
import hashlib
import json
import math
from pathlib import Path

CURRENT = Path('/tmp/g350-deterministic-manual47-root-20261016-run223/byte0-result.candidate.json')
CURRENT_SHA = 'ddaa4efd8d20f16cefca89b9166e834a956113194beed6f0f13903e346e36ea0'
DONOR = Path('/tmp/g350-ca24-matching-root-20261016-run204/byte0-result.candidate.json')
DONOR_SHA = '454b1b02ca5fa4a8bdce8e4e752097090cc8a28d449360c075be65bc6d1be86f'
RAW = Path('/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json')
RAW_SHA = 'd2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607'
OUT = Path('/tmp/g350-current223-ca204-merge-pure-screen.json')
L = ['top', 'inner1', 'inner2', 'bottom']
EPS = 1e-8
CRITICAL = {'source_trace_' + str(i) for i in (15, 16, 27, 28, 33, 34)}


def require(value, message):
    if not value:
        raise ValueError(message)


def read(path, pin):
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == pin, 'Pinned public bytes changed: ' + str(path))
    return json.loads(data)


def own(t):
    return t.get('connection_name', t.get('source_trace_id'))


def xy(p):
    return p['x'], p['y']


def planar(t):
    return sum(math.dist(xy(a), xy(b)) for a, b in zip(t['route'], t['route'][1:])
               if a['route_type'] == b['route_type'] == 'wire' and a['layer'] == b['layer'])


def bbox(a, b, expand=0):
    return min(a[0], b[0])-expand, max(a[0], b[0])+expand, min(a[1], b[1])-expand, max(a[1], b[1])+expand


def overlap(a, b):
    return a[0] <= b[1] and b[0] <= a[1] and a[2] <= b[3] and b[2] <= a[3]


def point_segment(p, a, b):
    dx, dy = b[0]-a[0], b[1]-a[1]
    den = dx*dx+dy*dy
    t = max(0.0, min(1.0, ((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den)) if den else 0.0
    q = a[0]+t*dx, a[1]+t*dy
    return math.dist(p, q), q


def segment_distance(a, b, c, d):
    ux, uy, vx, vy = b[0]-a[0], b[1]-a[1], d[0]-c[0], d[1]-c[1]
    cross = ux*vy-uy*vx
    if abs(cross) > 1e-16:
        wx, wy = c[0]-a[0], c[1]-a[1]
        t, u = (wx*vy-wy*vx)/cross, (wx*uy-wy*ux)/cross
        if 0 <= t <= 1 and 0 <= u <= 1:
            q = a[0]+t*ux, a[1]+t*uy
            return 0.0, q, q
    cases = []
    for p in (a, b):
        dist, q = point_segment(p, c, d)
        cases.append((dist, p, q))
    for p in (c, d):
        dist, q = point_segment(p, a, b)
        cases.append((dist, q, p))
    return min(cases, key=lambda x: x[0])


def route_objects(t):
    objects = []
    for i, p in enumerate(t['route']):
        require(p['route_type'] in ('wire', 'via'), 'Unsupported route primitive')
        if p['route_type'] == 'via':
            require(p['layers'] == L and p['via_diameter'] == .4572 and p['via_hole_diameter'] == .254,
                    'Actual fullspan dimensions required')
            objects.append({'kind': 'circle', 'a': xy(p), 'b': xy(p), 'radius': p['via_diameter']/2,
                            'layers': L, 'owner': own(t), 'id': t['pcb_trace_id'], 'routeIndex': i,
                            'hole': p['via_hole_diameter']/2, 'box': bbox(xy(p), xy(p), p['via_diameter']/2)})
        if i:
            a = t['route'][i-1]
            if a['route_type'] == p['route_type'] == 'wire' and a['layer'] == p['layer'] and math.dist(xy(a), xy(p)) > EPS:
                require(a['width'] == p['width'] and a['width'] > 0, 'Exact constant adjacent wire widths')
                objects.append({'kind': 'segment', 'a': xy(a), 'b': xy(p), 'radius': p['width']/2,
                                'layers': [p['layer']], 'owner': own(t), 'id': t['pcb_trace_id'],
                                'routeIndex': [i-1, i], 'box': bbox(xy(a), xy(p), p['width']/2)})
    return objects


def witness(a, b, clearance):
    if not set(a['layers']).intersection(b['layers']):
        return None
    required = .15 if a['kind'] == b['kind'] == 'circle' else clearance
    expanded = (a['box'][0]-required, a['box'][1]+required, a['box'][2]-required, a['box'][3]+required)
    if not overlap(expanded, b['box']):
        return None
    dist, qa, qb = segment_distance(a['a'], a['b'], b['a'], b['b'])
    gap = dist-a['radius']-b['radius']
    if gap < required-EPS:
        return {'a': {k: a[k] for k in ('kind', 'owner', 'id', 'routeIndex')},
                'b': {k: b[k] for k in ('kind', 'owner', 'id', 'routeIndex')},
                'layers': sorted(set(a['layers']).intersection(b['layers'])),
                'nearestA': qa, 'nearestB': qb, 'copperGapMm': gap, 'requiredMm': required}
    return None


def bodies_conflicts(a, b):
    result = []
    for x in route_objects(a):
        for y in route_objects(b):
            r = witness(x, y, .1016)
            if r:
                result.append(r)
    return result


current, donor, raw = read(CURRENT, CURRENT_SHA), read(DONOR, DONOR_SHA), read(RAW, RAW_SHA)
base, donor_base = current['full49FanoutInput'], donor['full49FanoutInput']
old = {own(t): t for t in current['carrierTraces']}
new = {own(t): t for t in donor['carrierTraces']}
require(len(old) == 47 and {f'source_trace_{i}' for i in range(49)}-old.keys() == {'source_trace_26', 'source_trace_30'}, 'Exact22347/pending26+30')
require(current['allSavedCarriersCurrentSceneQualified'] is True and donor['allSavedCarriersCurrentSceneQualified'] is True, 'Both parent physical provenance flags required')
require(base['traces'][:165] == donor_base['traces'][:165], 'All165 references unchanged')
require({k: v for k, v in base.items() if k not in ('connections', 'traces')} ==
        {k: v for k, v in donor_base.items() if k not in ('connections', 'traces')}, 'Literal original49 controls/obstacles/rules must match')
ca = next(b for b in base['buses'] if b['busId'] == 'DDR_COMMAND_CLOCK')
ordinary = [sid for sid in ca['connectionNames'] if sid not in CRITICAL]
require(len(ordinary) == 24 and all(sid in old and sid in new for sid in ca['connectionNames']), 'AllCA26 connected in both parents')
require(all(old[sid] == new[sid] for sid in CRITICAL), 'All six exact critical rail objects held')
for sid in ordinary:
    require([t for t in base['traces'][165:] if own(t) == sid] ==
            [t for t in donor_base['traces'][165:] if own(t) == sid], 'CA approach material changed: ' + sid)
    require(next(c for c in base['connections'] if c['name'] == sid) ==
            next(c for c in donor_base['connections'] if c['name'] == sid), 'CA handoff changed: ' + sid)
    require([p for p in old[sid]['route'] if p['route_type'] == 'via'] ==
            [p for p in new[sid]['route'] if p['route_type'] == 'via'], 'CA tuner must retain all actual via objects')
changed = [sid for sid in ordinary if old[sid] != new[sid]]
fixed_bodies = [t for sid, t in old.items() if sid not in changed]
fixed_branch_deltas = [(i, t) for i, t in enumerate(base['traces'][165:], 165) if t != donor_base['traces'][i]]
require(all(own(t) not in ordinary for _, t in fixed_branch_deltas), 'Only nonCA foundation approaches may differ')
hard, implications, newnew = {}, {}, []
for sid in changed:
    errors = []
    for t in fixed_bodies:
        errors.extend(bodies_conflicts(new[sid], t))
    for _, t in fixed_branch_deltas:
        if own(t) != sid:
            errors.extend(bodies_conflicts(new[sid], t))
    hard[sid] = errors
    implications[sid] = []
    for other in changed:
        if other != sid:
            errors = bodies_conflicts(new[sid], old[other])
            if errors:
                implications[sid].append({'requiresNewOwner': other, 'violations': errors})
for i, sid in enumerate(changed):
    for other in changed[:i]:
        errors = bodies_conflicts(new[sid], new[other])
        if errors:
            newnew.append({'a': sid, 'b': other, 'violations': errors})

blocked = {sid for sid in changed if hard[sid]}
reasons = {sid: ['FOREIGN_CURRENT223_BODY_OR_CHANGED_APPROACH'] for sid in blocked}
while True:
    extra = {sid for sid in changed if sid not in blocked and any(e['requiresNewOwner'] in blocked for e in implications[sid])}
    if not extra:
        break
    for sid in extra:
        reasons[sid] = ['CROSS_OLD_NEW_CA_REQUIRES_BLOCKED_' + e['requiresNewOwner'] for e in implications[sid] if e['requiresNewOwner'] in blocked]
    blocked.update(extra)
selected = [sid for sid in changed if sid not in blocked]
require(not newnew, 'Unexpected204 donor CA-to-CA collision; inspect report generation model before proceeding')
def whole(t):
    return planar(t)+sum(planar(b) for b in base['traces'][165:] if own(b) == own(t))

def write_candidate(label, selected_ids):
    result = copy.deepcopy(current)
    by = {sid: copy.deepcopy(new[sid] if sid in selected_ids else t) for sid, t in old.items()}
    result['carrierTraces'] = [by[own(t)] for t in current['carrierTraces']]
    result['ordinaryCarrierTraces'] = [by[own(t)] for t in current['ordinaryCarrierTraces']]
    result['joinedNumericPadTraces'] = []
    result['joinedNumericPadTracesRequireFreshRebuild'] = True
    for field in ('finalScenePhysicalReports', 'criticalValidationViews', 'physicalRunReports', 'newViaReports', 'joinedNativeGeometryReports'):
        result[field] = []
    result.update(scope='PLANNED_CURRENT22347_WITH_EXACT204_CA_TIMING_CARRIERS_' + label,
                  allSavedCarriersCurrentSceneQualified=False, all49Accepted=False, matched=False,
                  timingPassed=False, electricalTimingQualified=False, freshSourceCoreDerived=False,
                  nativeExecuted=False, cadExecuted=False, fabricationReady=False)
    result['ca204Merge'] = {'current223Sha256': CURRENT_SHA, 'donor204Sha256': DONOR_SHA,
                          'selectedOwners': selected_ids, 'allCurrentNonCAAndCriticalBodiesUnchanged': True,
                          'allCurrentFoundationObjectsUnchanged': True,
                          'inverse': [{'owner': sid, 'before': old[sid], 'after': new[sid]} for sid in selected_ids],
                          'pureGeometryOnly': True, 'freshFull47AndCriticalSourceNativeRequired': True}
    file = OUT.with_name('g350-current223-ca204-' + label.lower() + '-planning.json')
    data = (json.dumps(result, indent=2, allow_nan=False)+'\n').encode()
    with file.open('xb') as stream:
        stream.write(data)
    lengths = {sid: whole(by[sid]) for sid in ca['connectionNames']}
    return {'path': str(file), 'sha256': hashlib.sha256(data).hexdigest(), 'selectedOwners': selected_ids,
            'caMinPassCount': sum(v >=20.95-1e-7 for v in lengths.values()), 'caWholeLengthsMm': lengths,
            'partialCaSkewMm': max(lengths.values())-min(lengths.values())}

report = {'scope': 'PURE_CURRENT22347_EXACT204_CA_MERGE_CROSS_SCENE_PRIMITIVE_SCREEN',
          'inputBindings': {'current223': {'path': str(CURRENT), 'sha256': CURRENT_SHA},
                            'donor204': {'path': str(DONOR), 'sha256': DONOR_SHA}},
          'ordinaryCAOwners24': ordinary, 'changedCAOwners': changed,
          'changedFoundationNonCABranches': [{'index': i, 'owner': own(t), 'id': t['pcb_trace_id']} for i, t in fixed_branch_deltas],
          'hardForeignConflicts': hard, 'crossOldNewCAImplications': implications, 'newNewCAConflicts': newnew,
          'blockedNewOwners': sorted(blocked), 'blockReasons': reasons,
          'full24DonorMergeClearInCrossScenePrimitiveModel': not any(hard.values()) and not newnew,
          'selectedMaximalCompatibleNewOwners': selected,
          'scopeLimits': ['Unchanged204 CA-to-fixed reference/pad/obstacle and own-contact qualification is parent provenance, not freshly executed here.',
                          'The screen directly checks every newCA against all actual223 nonCA/critical bodies and every changed actual223 foundation approach.',
                          'Every new/old CA cross alternative is screened; new/new CA geometry is screened directly.',
                          'No pour regeneration, SDK, native, freshSource/Core, electrical, timing, or board acceptance claim.'],
          'all49Accepted': False, 'freshPhysicalQualification': False, 'sdkExecuted': False,
          'nativeExecuted': False, 'fabricationReady': False}
report['selectedPlanningCandidate'] = write_candidate('MAXIMAL_CLEAR', selected)
for p, h in ((CURRENT, CURRENT_SHA), (DONOR, DONOR_SHA), (RAW, RAW_SHA)):
    require(hashlib.sha256(p.read_bytes()).hexdigest() == h, 'Input modified during pure screen')
data = (json.dumps(report, indent=2, allow_nan=False)+'\n').encode()
with OUT.open('xb') as stream:
    stream.write(data)
print(json.dumps({'output': str(OUT), 'sha256': hashlib.sha256(data).hexdigest(),
                  'changedCAOwners': len(changed), 'hardBlockedOwners': sorted(sid for sid in changed if hard[sid]),
                  'maximalSelectedOwners': selected, 'selectedCandidate': report['selectedPlanningCandidate'],
                  'all49Accepted': False}))
