"""Bounded MOCK/pure/type/format checks only. No production runtime imports/constructors."""
from pathlib import Path
import ast,hashlib,importlib.util,json,time
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/bus-lanes-solver')
BUN='/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
NODE='/workspace/g350-linux-handheld/.cloud-tools/node/bin/node'
POLICY={'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
scope=load('prefix_prep_scope',ROOT/'process_scope.py');audit=load('prefix_prep_source',ROOT/'source-audit.py');verify=load('prefix_prep_deps',ROOT/'verify-installed-dependencies.py')
source_before=audit.verify();dependencies_before=verify.verify(ROOT/'dependencies/archive-receipt.json','1a49a60909258b542c7f4899e6378fa9f10c1cea08ef1aaf4b5366480dbf71b7',ROOT/'audit-installed-dependencies.py');baseline=scope.memory()
def gate(current):
 if current['current']+POLICY['rssBytes']+2*1024**3>=POLICY['sharedBytes']:raise ValueError('Tiny preparation headroom required')
 if any(current['events'][key]!=baseline['events'][key] for key in scope.OOM_KEYS):raise ValueError('New OOM before tiny checks')
checks=[]
names=['runner.ts','pair-stage-telemetry.ts','pair-stage-telemetry.test.ts','public-pipeline-protocol.ts','public-pipeline-protocol.test.ts','input-parity.ts','input-parity.test.ts']
commands=[
 ('format-v1',[NODE,str(REPO/'node_modules/@biomejs/biome/bin/biome'),'format','--config-path',str(ROOT/'biome.json'),'--write',*[str(ROOT/n) for n in names]]),
 ('mock-pure-v1',[BUN,'--smol','test',*[str(ROOT/n) for n in ['pair-stage-telemetry.test.ts','public-pipeline-protocol.test.ts','input-parity.test.ts']]]),
 ('guard-mocks-v1',['python3','-B',str(ROOT/'guard.test.py')]),
 ('typecheck-v1',[NODE,str(REPO/'node_modules/typescript/bin/tsc'),'--noEmit','--strict','--skipLibCheck','--target','ESNext','--module','ESNext','--moduleResolution','Bundler','--esModuleInterop','--types','bun',*[str(ROOT/n) for n in names]])]
for name,command in commands:
 tool_inputs={n:sha(ROOT/n) for n in names+['guard.py','guard.test.py','process_scope.py','source-audit.py','prep-checks.py']}
 execution=scope.run_guarded(command,ROOT,ROOT/'checks'/name,POLICY,{'TMPDIR':str(ROOT/'checks/tmp'),'PYTHONDONTWRITEBYTECODE':'1'},before_spawn=gate)
 checks.append({'name':name,'execution':execution,'toolInputHashesBefore':tool_inputs,'toolInputHashesAfter':{n:sha(ROOT/n) for n in tool_inputs}})
 if execution['exitCode']!=0 or execution['diagnosticStopped'] or not execution['cleanupOwnedGroupEmpty']:
  (ROOT/'checks/prep-failed.json').write_text(json.dumps({'allPassed':False,'checks':checks,'sourceAfter':audit.verify(),'actualProductionCtorCalls':0},indent=2)+'\n')
  raise ValueError('Tiny preparation check failed '+name)
for path in ROOT.glob('*.py'):ast.parse(path.read_text())
source_after=audit.verify();dependencies_after=verify.verify(ROOT/'dependencies/archive-receipt.json','1a49a60909258b542c7f4899e6378fa9f10c1cea08ef1aaf4b5366480dbf71b7',ROOT/'audit-installed-dependencies.py')
if source_before!=source_after or dependencies_before!=dependencies_after:raise ValueError('Preparation source/dependencies changed')
report={'allPassed':True,'policy':POLICY,'sourceBefore':source_before,'sourceAfter':source_after,'dependenciesBefore':dependencies_before,'dependenciesAfter':dependencies_after,'checks':checks,'pythonSyntaxPassed':True,'actualSceneGridSolverCheckerCtorCalls':0,'productionRuntimeImported':False,'gridDoublesOnly':True,'accepted49':False}
(ROOT/'checks/prep-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'allPassed':True,'actualProductionCtorCalls':0,'checks':[(c['name'],c['execution']['exitCode']) for c in checks]}))
