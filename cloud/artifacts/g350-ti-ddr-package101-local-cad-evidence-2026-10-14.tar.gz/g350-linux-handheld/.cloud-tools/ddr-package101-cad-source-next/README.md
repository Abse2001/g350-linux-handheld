# Source-only physical export and local CAD qualification

Root owns two serial stages against accepted exact Core `ed33a0a335b1fbf0da9adcdeacaa954b655c3c4964c600efb6ef3c72aef4040e` and native101+64 receipt `99ce86ce927006668067f1c1b84bcdf937da64cc010457026f5fda6d2003ff68`. The actual collected readonly pass is a required prerequisite. No source capture, compiler, Core render or routing is repeated.

`export` verifies the tested fa7 physical CLI copy before and after one new KiCad export. It consumes the untouched actual Core, uses copied CLI main87829b4a…/lib7e4b8ae0…, and leaves the installed CLI/Core/lockfiles/native patch unchanged. No input normalization, ignored pour removal or converter iteration-budget patch is introduced.

`cad` requires the export's naturally passed and collected Root receipt. Its new offline wrapper uses the unchanged managed-socket Docker selector script and exact already-loaded KiCad10 image `sha256:11b9360b20752e87f20942639e229b0d111e96f6e30b1bd1cb2eaafce9f26cfc`. It preserves Docker client credentials/proxy configuration, uses `--network none`, and never uses host networking. No pull, build, image/archive change or daemon recovery occurs in this stage. A missing image/daemon remains a setup diagnostic for Root. The existing ignored archive stays retained. Since no HTTPS occurs, no TLS setting or CA trust is bypassed.

The container has a separate2GiB memory/swap ceiling,2 CPUs and256 pids. Workspace/source/raw files mount read-only; only this fresh output directory and ephemeral XDG/tmpfs directories are writable. Its unique name binds packet and Root authority hashes. Cleanup removes only that owned container; the guard checks exact image/storage-driver and absence of same-image containers before and after. The tested VFS disk preflight is retained. Host group monitoring alone does not bound daemon/container RSS; the explicit container limit and shared-machine monitor are separate controls.

| Stage | Wall / host owned RSS | Container limit | Shared / reserve |
| --- | --- | --- | --- |
| export |120s /3GiB |None |26GiB /2GiB |
| cad |120s /1GiB |2GiB |26GiB /2GiB |

Both require actual live shared memory below22,548,578,304 bytes before their capped host/container work plus reserve. Root must wait for all previous workers to be collected and bind the exact source/dependency/numerical trees. Each stage uses a new exclusive `run-STAGE` directory. A stopped or uncollected stage cannot authorize the next one.

The source inspector maps all129 source-owned manual-via placeholders through actual source/PCB aliases/components and the pinned converter UUID seed. It refuses unknown, duplicated or nonempty mappings. A fresh cleaned copy deletes only those129 empty footprints by lexical spans; all real280 footprints and every raw via/segment/zone byte remain. Neither raw export nor frozen board is rewritten or saved through pcbnew.

The independent KiCad10 check verifies1,161 original logical numeric contacts across1,161 SMT and4 plated copper lands. It supports the two original three-land polygon numeric ports without merging unrelated ownership. Every logical port must HitTest its mapped copper union. Circle/rectangle and original plated-pill dimensions, numeric identity, layers, anchors and raw/native UUID/net continuity are checked; full custom polygon copper-shape qualification remains separate.

All129 full-through.4572/.254 vias and165 trace records (168 actual segments) must retain exact source/raw/native geometry, layer, width, nonzero rail and unique UUID mapping. Connectivity uses a temporary zone-free copy, so filled planes cannot mask missing local branches. It requires all101 package-pad/owned-via paths, all64 HS-pad/owned-via paths and the specific new GND via89→old HS8 pad729/strip55→old via55 physical junction. The cleaned output retains original zones for a later qualified refill; no fill, SaveBoard or route occurs here.

Root creates fresh authority from the false/null template with exact stage scope/policy/packet hash, a hex approval token, truthful exclusivity flags and actual latest closed postaudit hashes. For CAD additionally supply `exportRootCollectionPath`/`exportRootCollectionSha256`. That actual collection binds `phase:export`, this packet hash, `toolSessionCollected:true`, zero wrapper exit and exact `run-export/POSTAUDIT.json` path/hash.

```bash
source /workspace/g350-linux-handheld/cloud/env.sh
python3 -B /workspace/g350-linux-handheld/.cloud-tools/ddr-package101-cad-source-next/guard.py --stage export --root-receipt ABS_EXPORT_AUTHORITY --root-receipt-sha256 EXACT_EXPORT_AUTHORITY_HASH
python3 -B /workspace/g350-linux-handheld/.cloud-tools/ddr-package101-cad-source-next/guard.py --stage cad --root-receipt ABS_CAD_AUTHORITY --root-receipt-sha256 EXACT_CAD_AUTHORITY_HASH
```

This packet is source-only and unexecuted by its authors. Root's actual new export/CAD reports determine acceptance. These local checks do not qualify full supply distribution, custom all-four-signal-layer continuous adjacent filled references, DDR49 routing/timing/impedance, whole-board DRC or fabrication. `referenceQualified=false`, `accepted49=false`, `fabricationReady=false`.
