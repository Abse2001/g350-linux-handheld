# Source-only local KiCad inspection candidate

`inspect-local101-hs64.py` is prepared for Root's bounded, offline KiCad 10
wrapper. It has not been imported or run during source preparation. Its Python
syntax was checked with `ast.parse`; no hardware, CAD or connectivity execution
was performed by this child.

Inputs are the fresh raw KiCad board, the exact accepted Core
`ed33a0a335b1fbf0da9adcdeacaa954b655c3c4964c600efb6ef3c72aef4040e`,
and its exact passed native-owner report
`99ce86ce927006668067f1c1b84bcdf937da64cc010457026f5fda6d2003ff68`.
The arguments are `--raw-board`, `--source`, `--native-report`,
`--cleaned-board` and `--report`. Output paths must be fresh.

The script identifies 129 empty via placeholder footprints through actual
manual-via ownership, Top/Bottom aliases, PCB component IDs, coordinates and the
pinned converter's footprint UUID rule. It deletes only their lexical expression
spans in a new copied board. It preserves the raw board and every remaining byte,
including all 129 real through-via records, trace segments and original zones.
It never calls SaveBoard, a router or a fill operation.

For future actual execution, it maps 280 real footprints, all 1,161 SMT lands
and four plated connector lands to their original source owners. Those 1,165
physical lands represent 1,161 logical numeric PCB ports: two inductor ports each
have three authored overlapping lands. Each logical port must hit its mapped land
union in the transformed KiCad coordinate frame. Numeric identities, raw/native
pad UUIDs, net assignments, assembly layers and circle/rectangle dimensions are
checked. The four plated pill lands additionally require their source size,
slotted drill, orientation and full copper span. Full custom-polygon copper-shape
qualification remains explicitly outside this inspector's scope.

The script removes every zone only in a private temporary copy used for native
connectivity. On that copy, all 101 new package Top branches and 64 retained HS
Bottom branches must physically connect their numeric pad, exact trace segments
and owned through-via. The approved HS8 junction must connect new via 89 through
original ground pad 729 and strip 55 to original via 55. Same net names alone
cannot satisfy these gates. The one-argument GetConnectedItems API and multi-hop
behavior are inherited from the previously executed tiny-Core KiCad 10 boundary;
compatibility with this fresh export remains Root's actual execution gate.

This candidate qualifies only local power/reference approaches if actual
execution passes. It does not qualify filled reference planes, the 49 DDR
signals, DDR timing, the four-layer custom reference arrangement, complete-board
manufacturing or fabrication readiness. Reports keep `referenceQualified`,
`accepted49` and `fabricationReady` false.
