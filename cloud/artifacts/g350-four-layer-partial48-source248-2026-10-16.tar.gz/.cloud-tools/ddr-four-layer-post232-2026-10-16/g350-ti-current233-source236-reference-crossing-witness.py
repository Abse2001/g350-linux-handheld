#!/usr/bin/env python3
import collections,hashlib,json,math,pathlib,time
C=pathlib.Path('/tmp/g350-ca-merge47-root-20261016-run233/byte0-result.candidate.json');R=pathlib.Path('/tmp/g350-ca-merged47-core236-raw.json');O=pathlib.Path('/tmp/g350-ti-current233-source236-reference-crossing-witness.json');assert not O.exists()
assert hashlib.sha256(C.read_bytes()).hexdigest()=='71bbec7babdeabda657ba1b2be75d35f5d7210d5a53d55cd2fc2b279ffb0d17b'
assert hashlib.sha256(R.read_bytes()).hexdigest()=='d49c3d6f8661527cf007d3676d6cdae7f9fcec99535373997c6adda8705dc18d'
c=json.loads(C.read_bytes());r=json.loads(R.read_bytes());layers=collections.defaultdict(list)
for t in c['joinedNumericPadTraces']:
 for k,(a,b) in enumerate(zip(t['route'],t['route'][1:])):
  if a['route_type']==b['route_type']=='wire' and a['layer']==b['layer'] and math.hypot(a['x']-b['x'],a['y']-b['y'])>1e-8:
   layers[a['layer']].append({'owner':t['source_trace_id'],'routeSegmentIndex':k,'a':(a['x'],a['y']),'b':(b['x'],b['y'])})
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def inter(a,b):
 p,q=a['a'],b['a'];u=(a['b'][0]-p[0],a['b'][1]-p[1]);v=(b['b'][0]-q[0],b['b'][1]-q[1]);den=cross(u,v)
 if abs(den)<1e-14:return None
 d=(q[0]-p[0],q[1]-p[1]);s=cross(d,v)/den;t=cross(d,u)/den
 if 1e-5<s<1-1e-5 and 1e-5<t<1-1e-5:return(p[0]+s*u[0],p[1]+s*u[1])
 return None
def ring(p,verts):
 x,y=p;inside=False
 for a,b in zip(verts,verts[1:]+verts[:1]):
  if (a['y']>y)!=(b['y']>y) and x<(b['x']-a['x'])*(y-a['y'])/(b['y']-a['y'])+a['x']:inside=not inside
 return inside
def material(p,layer,net):
 hits=[]
 for pour in r:
  if pour['type']!='pcb_copper_pour' or pour['layer']!=layer or pour['source_net_id']!=net:continue
  brep=pour['brep_shape']
  if ring(p,brep['outer_ring']['vertices']) and not any(ring(p,h['vertices']) for h in brep['inner_rings']):hits.append(pour['pcb_copper_pour_id'])
 return hits
witnesses=[];checks=0
for signal,ref,net in [('top','inner1','source_net_0'),('bottom','inner2','source_net_5'),('inner1','inner2','source_net_5'),('inner2','inner1','source_net_0')]:
 found=None
 for a in layers[signal]:
  for b in layers[ref]:
   checks+=1
   if a['owner']==b['owner']:continue
   pt=inter(a,b)
   if pt is None:continue
   hits=material(pt,ref,net)
   if not hits:
    found={'signalLayer':signal,'candidateReferenceLayer':ref,'candidateReferenceNet':net,'signalOwner':a['owner'],'signalSegmentIndex':a['routeSegmentIndex'],'crossingForeignSignalOwnerOnReferenceLayer':b['owner'],'foreignSegmentIndex':b['routeSegmentIndex'],'projectedPoint':list(pt),'referencePourMaterialIdsAtPoint':hits,'meaning':'Actual different-layer signal crossing has zero intended reference-pour material at the projected signal centerline. It is not a same-layer short; it witnesses a local reference gap for this particular layer/net assignment.'};break
  if found:break
 witnesses.append(found or {'signalLayer':signal,'candidateReferenceLayer':ref,'witnessFound':False})
report={'scope':'BOUNDED_CURRENT233_SOURCE236_REFERENCE_GAP_WITNESSES_ONLY','candidateSha256':hashlib.sha256(C.read_bytes()).hexdigest(),'rawSha256':hashlib.sha256(R.read_bytes()).hexdigest(),'segmentIntersectionTests':checks,'method':'Exact proper line intersections between real joined47 different-layer wires, followed by even-odd point-in-literal-BREP polygon material test at projected point. No reference interpolation, field extraction, SDK, or board mutation. Coincident endpoints and same-owner crossings excluded.','witnesses':witnesses,'wholeReferenceContinuityQualified':False,'returnConnectivityQualified':False,'electricalTimingQualified':False,'fabricationReady':False}
O.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'report':str(O),'sha256':hashlib.sha256(O.read_bytes()).hexdigest(),'checks':checks,'witnesses':witnesses},indent=2))
