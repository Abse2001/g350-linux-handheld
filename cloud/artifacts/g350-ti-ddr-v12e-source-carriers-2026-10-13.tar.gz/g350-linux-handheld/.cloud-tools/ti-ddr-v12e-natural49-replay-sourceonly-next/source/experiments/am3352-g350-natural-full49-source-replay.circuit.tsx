import { Children, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import {buildV12eSource} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-ram7-reference-right-source-proposal-next/v12e-ram7-reference-right-overlay"
import { createNatural49Replay, createUnroutedLaterPhase, ddrRamSelectors, ddrTraceNames, ddrBusNames } from "../full49-replay/natural-array-transport"

type Props = Record<string, unknown> & { name?: string; children?: ReactNode }
function replay(node: ReactNode): ReactNode {
  if (!isValidElement<Props>(node)) return node
  if (node.type === "autoroutingphase") return null
  const props = { ...node.props }
  if (["trace", "net", "bus"].includes(String(node.type))) {
    // React.cloneElement merges inherited props: explicit undefined clears old
    // membership. Deleting the copied key would restore the inherited value.
    props.routingPhaseIndex = undefined
    const isDdr = node.type === "trace" ? ddrTraceNames.has(props.name ?? "") :
      node.type === "bus" && ddrBusNames.has(props.name ?? "")
    if (isDdr) props.routingPhaseIndex = 0
    else props.routingPhaseIndex = Number.isSafeInteger(node.props.routingPhaseIndex) &&
      Number(node.props.routingPhaseIndex) >= 1 ? node.props.routingPhaseIndex : 1
  }
  const children = Children.toArray(node.props.children).map(replay)
  if (node.type === "board") {
    props.routeRemaining = false
    props.autorouter = { local: true, algorithmFn: async (input: Parameters<typeof createUnroutedLaterPhase>[0]) => createUnroutedLaterPhase(input) }
    children.push(<autoroutingphase name="NATURAL_FULL49_ORIGINAL_ARRAY_REPLAY" phaseIndex={0}
      connections={ddrRamSelectors} autorouter={{ local: true }}
      algorithmFn={async (input: Parameters<typeof createNatural49Replay>[0]) => createNatural49Replay(input)} />)
  }
  return cloneElement(node as ReactElement<Props>, props, ...children)
}
export default () => replay(buildV12eSource().element)
