"""One original bounded pure final React capture; no Core/native/router worker."""
import argparse,hashlib,importlib.util,json,re,stat,sys
from pathlib import Path
import inventory,process_scope
ROOT=Path(__file__).resolve().parent
BOARD=Path('/workspace/g350-linux-handheld')
PARENT=BOARD/'.cloud-tools/ti-ddr-v12d-byte0-top-reset-bottom-next'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def require(v,s):
 if not v:raise ValueError(s)
def checked():
 packet=load(ROOT/'CAPTURE-manifest.json')
 for base in [ROOT,ROOT.parent]:
  for name in ['node_modules','.pnp.cjs','.pnp.loader.mjs','.yarn']:
   require(not (base/name).exists() and not (base/name).is_symlink(),'Unexpected nearest dependency resolver')
 for key,base in [('files',ROOT),('externalFiles',None)]:
  for row in packet[key]:
   p=base/row['path'] if base else Path(row['path'])
   require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Frozen member changed: '+str(p))
 spec=importlib.util.spec_from_file_location('g350_v12d_parent_capture',PARENT/'v12d_input_provenance.py');parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent)
 parent.verify(packet['parentManifestSha256'])
 actual=parent.verify_actual_authored_props(Path(packet['parentActualCapture']))
 receipt=load(packet['parentActualReceipt']);e=receipt['execution']
 require(receipt['passed'] is True and receipt['sourceHeld'] is True and receipt['proof']==actual and e['exitCode']==0 and e['diagnosticStopped'] is False and e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()),'Actual clean V12d final props capture required')
 deps=inventory.tree(BOARD/'node_modules');small={k:deps[k] for k in ['treeSha256','regularFiles','regularBytes','symlinks','directories']}
 require(small==packet['boardDependencyInventory'],'Pinned complete board dependencies changed')
 return packet,sha(ROOT/'CAPTURE-manifest.json'),small

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--preflight',action='store_true');parser.add_argument('--launch-receipt',type=Path);parser.add_argument('--receipt-sha256');args=parser.parse_args()
 require(args.preflight!=bool(args.launch_receipt),'Select pure preflight or one exact root launch receipt')
 packet,packet_sha,before=checked()
 if args.preflight:
  print(json.dumps({'preflightOnly':True,'packetSha256':packet_sha,'sourceHeld':True,'actualCoreCalls':0,'nativeCalls':0,'routerCalls':0}));return 0
 require(re.fullmatch('[0-9a-f]{64}',args.receipt_sha256 or '') and sha(args.launch_receipt)==args.receipt_sha256,'Exact root receipt hash required')
 a=load(args.launch_receipt)
 require(a.get('authorizedByRoot') is True and a.get('scope')==packet['authorityScope'] and a.get('packetSha256')==packet_sha and a.get('policy')==packet['policy'] and re.fullmatch('[0-9a-f]{32,128}',a.get('approvalToken','')),'Exact root authority scope/packet/policy required')
 require(not (ROOT/'run').exists(),'One fresh exclusive capture only')
 output=ROOT/'run/actual-final-props.json'
 def before_spawn(memory):
  require(memory['current']+packet['policy']['rssBytes']+packet['preforkReserveBytes']<packet['policy']['sharedBytes'],'Strict original prefork reserve required')
 execution=process_scope.run_guarded([packet['bun'],'--smol',str(ROOT/'capture-v12e-authored-props.ts'),str(output)],str(ROOT),ROOT/'run',packet['policy'],{},before_spawn=before_spawn)
 after_packet,after_sha,after=checked();capture=load(output) if output.is_file() else None
 passed=(execution['exitCode']==0 and execution['diagnosticStopped'] is False and execution.get('cleanupOwnedGroupEmpty') is True and not any(execution['oomDelta'].values()) and before==after and packet_sha==after_sha and capture is not None)
 if passed:
  prior=load(packet['parentActualCapture']);expected=[{'name':'C_DDR_RAM_7','oldX':6.8,'pcbX':8.2,'pcbY':8.75},{'name':'V_TI_RAM7_POWER','oldX':7.85,'pcbX':9.25,'pcbY':8.75},{'name':'V_TI_RAM7_GROUND','oldX':7.65,'pcbX':9.05,'pcbY':8.15}]
  passed=(capture['scope']=='PURE_ACTUAL_V12E_FINAL_REACT_THREE_RIGID_X_PROPS_ONLY' and capture['actualFinalReactTreeEvaluated'] is True and capture['allOtherTreePropsTypesKeysChildrenExactlyHeld'] is True and capture['comparedElements']>280 and capture['changedProps']==expected and capture['placementProposal']['changedProps']==expected and capture['placementProposal']['rigidTranslationMm']=={'x':1.4,'y':0} and sorted(x['name'] for x in capture['placementProposal']['manualReferencePathPropsUnchanged'])==['TI_RAM7_GROUND_BYPASS','TI_RAM7_POWER_BYPASS'])
  for key in ['authoredPolicyProof','referenceCopperCandidates','globalSignalLayerProjection','naturallyDerivedGenericDefaultCap']:passed=passed and capture[key]==prior[key]
  for key in ['referenceQualified','TIplaneArrangement','coreRenderCalled','nativePlacementChecksInvoked','routingSolverInstantiated','accepted49','fabricationReady']:passed=passed and capture[key] is False
 report={'passed':passed,'sourceManifestSha256':packet_sha,'execution':execution,'captureSha256':sha(output) if output.is_file() else None,'boardDependenciesBefore':before,'boardDependenciesAfter':after,'sourceHeld':packet_sha==after_sha,'scope':packet['authorityScope'],'actualNewCoreOrNativeCheckPerformed':False,'accepted49':False,'fabricationReady':False}
 with (ROOT/'run/RECEIPT.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
 print(json.dumps({'passed':passed,'captureSha256':report['captureSha256'],'actualNewCoreOrNativeCheckPerformed':False}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
