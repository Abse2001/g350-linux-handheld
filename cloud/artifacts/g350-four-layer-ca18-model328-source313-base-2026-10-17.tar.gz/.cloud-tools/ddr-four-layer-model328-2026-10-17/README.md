MODEL328 physical-only:49 model paths/both11-signal byte cohorts PASS; CA18/26 at minimum,eight short/fullCA skew17.6628187566mm FAILS.
Only20/23/25/36 bodies change; two new25 fullspan portals have no fresh raw IDs. All45 other bodies/foundation/critical6/reference/PDN/hardware remain literal318.
Actual328 passes before49/after49,four full numeric joins,both critical views/all5 original APIs/C31 and fresh indexed self checks with zero NEW preferred failures.
All12105 retained preferred-self failures and inherited foreign-guidance findings remain unfiltered. WholeTI/electrical/fabrication are false.
This snapshot cuts at328. Later331/332/333 or other replay results are excluded. Editable Source313 is the checkpoint carried in this restore chain, with951 native findings and19 unqualified pours; its separate pour sibling is not a dependency or inherited qualification.
No fresh Source/Core/native-board/pour/PDN-plane/CAD qualification is claimed for328. Pending Source0 topology notes and failed/unexecuted predecessors remain UNACCEPTED.
Restore209→228→248→257→272-v2→289→Model299→Source313→Model318, then this increment. The unchanged generic archive restorer and legacy tmp helper remain compatible.
No SDK/application code is executed by this helper.
