"""Pure Python layered clearance diagnostic along an explicitly supplied D12 corridor.
No route-SDK, runtime, native checker, geometric acceptance or fabrication claim.
"""
exec(open('/tmp/g350-d12-topology-static-sourceonly.py').read().split('T=next')[0])
raw=json.load(open('/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json'))
physical={r.get('pcb_via_id',r.get('pcb_hole_id',r.get('pcb_plated_hole_id'))):r for r in raw if r['type'] in ('pcb_via','pcb_hole','pcb_plated_hole')}
objects=[]
for t in f['traces']+p['carrierTraces']:
 if owner(t)=='source_trace_26':continue
 for m in mats(t):objects.append({**m,'owner':owner(t),'id':t['pcb_trace_id']})
for o in f['obstacles']:
 if 'source_trace_26' in o.get('connectedTo',[]):continue
 meta=o.get('circuitJsonMetadata',{});key=meta.get('pcb_via_id',meta.get('pcb_hole_id',meta.get('pcb_plated_hole_id')));r=physical.get(key)
 objects.append({'kind':'obstacle','p':o['center'],'shape':o.get('shape'),'width':o['width'],'height':o['height'],'layers':o['layers'],'radius':max(o['width'],o['height'])/2,'holeRadius':(r.get('hole_diameter') or math.hypot(r.get('hole_width',0),r.get('hole_height',0)))/2 if r else 0,'owner':','.join(o.get('connectedTo',[])),'id':o.get('obstacleId'),'isVia':bool(meta.get('pcb_via_id')),'isPad':bool(meta.get('pcb_smtpad_id'))})

def rectCorners(o):
 x,y=o['p']['x'],o['p']['y'];w,h=o['width']/2,o['height']/2
 return [{'x':x-w,'y':y-h},{'x':x+w,'y':y-h},{'x':x+w,'y':y+h},{'x':x-w,'y':y+h}]
def pointRect(p,o):return math.hypot(max(0,abs(p['x']-o['p']['x'])-o['width']/2),max(0,abs(p['y']-o['p']['y'])-o['height']/2))
def segmentRect(a,b,o):
 if pointRect(a,o)<1e-10 or pointRect(b,o)<1e-10:return 0
 cs=rectCorners(o);return min(sd(a,b,c,cs[(i+1)%4]) for i,c in enumerate(cs))
def bbox(o):
 if o['kind']=='wire':return (min(o['a']['x'],o['b']['x'])-o['radius'],max(o['a']['x'],o['b']['x'])+o['radius'],min(o['a']['y'],o['b']['y'])-o['radius'],max(o['a']['y'],o['b']['y'])+o['radius'])
 q=o['p'];rx=o.get('width',2*o['radius'])/2;ry=o.get('height',2*o['radius'])/2;return q['x']-rx,q['x']+rx,q['y']-ry,q['y']+ry
for o in objects:o['bbox']=bbox(o)

def wireContacts(a,b,layer):
 out=[]
 for o in objects:
  if layer not in o['layers']:continue
  box=o['bbox'];r=.0508+.2
  if max(a['x'],b['x'])<box[0]-r or min(a['x'],b['x'])>box[1]+r or max(a['y'],b['y'])<box[2]-r or min(a['y'],b['y'])>box[3]+r:continue
  if o['kind']=='wire':d=sd(a,b,o['a'],o['b']);need=.0508+o['radius']+.1016
  elif o['kind']=='via':d=pd(o['p'],a,b);need=.0508+max(o['radius']+.1016,o['holeRadius']+.2)
  elif o['shape']=='circle':d=pd(o['p'],a,b);need=.0508+max(o['radius']+.1016,o['holeRadius']+.2)
  else:
   d=segmentRect(a,b,o);need=.0508+.1016
   if o['holeRadius'] and pd(o['p'],a,b)<.0508+o['holeRadius']+.2-1e-8:out.append(o);continue
  if d<need-1e-8:out.append(o)
 return out

def viaContacts(q):
 out=[]
 for o in objects:
  box=o['bbox'];r=.2286+.2
  if q['x']<box[0]-r or q['x']>box[1]+r or q['y']<box[2]-r or q['y']>box[3]+r:continue
  if o['kind']=='wire':d=pd(q,o['a'],o['b']);need=max(.2286+.1016,.127+.2)+o['radius']
  elif o['kind']=='via':d=math.hypot(q['x']-o['p']['x'],q['y']-o['p']['y']);need=max(.2286+o['radius']+.15,.127+o['holeRadius']+.254)
  elif o['shape']=='circle':d=math.hypot(q['x']-o['p']['x'],q['y']-o['p']['y']);need=max(.2286+o['radius']+.15,.127+o['holeRadius']+.254 if o['holeRadius'] else 0)
  else:
   d=pointRect(q,o);need=.2286+.15
   if o['holeRadius'] and math.hypot(q['x']-o['p']['x'],q['y']-o['p']['y'])<.127+o['holeRadius']+.254-1e-8:out.append(o);continue
  if d<need-1e-8:out.append(o)
 return out

def plan_corridor(path,step=.03,maxVias=4):
 points=[dict(path[0])];distance=[0]
 for a,b in zip(path,path[1:]):
  length=math.hypot(b['x']-a['x'],b['y']-a['y']);n=math.ceil(length/step)
  for j in range(1,n+1):points.append({'x':a['x']+(b['x']-a['x'])*j/n,'y':a['y']+(b['y']-a['y'])*j/n});distance.append(distance[-1]+length/n)
 states={l:(0,None) for l in L};rows=[];parents={};cut=None
 for i,q in enumerate(points):
  via=[] if i in (0,len(points)-1) else viaContacts(q)
  if not via:
   best=min(states,key=lambda l:states[l][0]) if states else None
   if best is not None:
    cost=states[best][0]+1
    for l in L:
     if l not in states or states[l][0]>cost:
      states[l]=(cost,best);parents[i,l]=(i,best)
  row={'index':i,'point':q,'distanceMm':distance[i],'viaBlockers':sorted(set(o['owner'] for o in via)),'reachableLayers':{l:s[0] for l,s in states.items()}}
  if i+1<len(points):
   blockers={l:wireContacts(q,points[i+1],l) for l in L};row['wireBlockers']={l:sorted(set(o['owner'] for o in obs)) for l,obs in blockers.items()};new={}
   for l,s in states.items():
    if not blockers[l]:new[l]=(s[0],l);parents[i+1,l]=(i,l)
   if states and not new and cut is None:cut=row
   states=new
  rows.append(row)
 if states:
  l=min(states,key=lambda l:states[l][0]);i=len(points)-1;chain=[(i,l)]
  while (i,l) in parents:
   i,l=parents[i,l];chain.append((i,l))
  chain.reverse();return {'passedStaticCorridorOnly':True,'newViaCount':states[chain[-1][1]][0],'route':[{'x':points[i]['x'],'y':points[i]['y'],'layer':l} for i,l in chain],'rows':rows,'corridorLengthMm':distance[-1]}
 return {'passedStaticCorridorOnly':False,'firstLayerCut':cut,'rows':rows,'corridorLengthMm':distance[-1]}

if __name__=='__main__':
 t=next(t for t in old['carrierTraces'] if owner(t)=='source_trace_26');path=[{'x':0,'y':15.2},{'x':-.4,'y':14.8},*({'x':q['x'],'y':q['y']} for q in t['route'][5:])]
 report=plan_corridor(path)
 json.dump(report,open('/tmp/g350-d12-fixed-corridor-portals-current171-static.json','w'),indent=2)
 print('static',report['passedStaticCorridorOnly'],'length',report['corridorLengthMm'],'via',report.get('newViaCount'))
 if not report['passedStaticCorridorOnly']:print(json.dumps(report['firstLayerCut'],indent=2))
 else:print('route layer switches',[(i,q) for i,q in enumerate(report['route']) if i==0 or q['layer']!=report['route'][i-1]['layer'] or i==len(report['route'])-1])
