"""Root-only single fresh original Grid replay; no solver import in this guard."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,re,stat,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
POLICY={'wallSeconds':360,'rssBytes':1024**3,'sharedBytes':26*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
RESERVE=2*1024**3

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
def verify():
    raw=(ROOT/'SOURCE-manifest.json').read_bytes();packet=json.loads(raw)
    for row in packet['files']+packet['externalFiles']:
        path=Path(row['path']);assert path.is_file() and not path.is_symlink(),str(path)
        assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes'],str(path)
        assert stat.S_IMODE(path.stat().st_mode)==row['mode'],str(path)
    runtime=json.loads(Path(packet['runtimeSourceManifestPath']).read_bytes())
    assert sha(packet['runtimeSourceManifestPath'])==packet['runtimeSourceManifestSha256']
    for row in runtime['files']+runtime['externalFiles']:
        path=Path(row['path']);assert path.is_file() and not path.is_symlink(),str(path)
        assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes'],str(path)
        assert stat.S_IMODE(path.stat().st_mode)==row['mode'],str(path)
    collected=json.loads(Path(packet['actualCaptureCollectedPath']).read_bytes())
    post=json.loads(Path(packet['actualCapturePostauditPath']).read_bytes())
    assert collected['toolSessionId']==51063 and collected['toolSessionCollected'] is True
    assert collected['toolExitCode']==collected['toolWrapperExitCode']==0
    assert collected['sourceAndDependenciesHeld'] is True and collected['execution']==post['execution']
    assert collected['qualifiedActiveCpuGeometryCapture'] is True and post['qualifiedActiveCpuGeometryCapture'] is True
    assert collected['actualActiveCpuGeometryCaptured'] is True and collected['actualFailureCaptured'] is False
    assert collected['captureSha256']==packet['actualCaptureSha256'] and collected['captureBytes']==442908
    assert collected['privateNativePreludeZero'] is True
    execution=collected['execution'];assert execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values())
    assert execution['stopReasons']==['OWNED_ACTIVE_CPU_GEOMETRY_CAPTURE'] and execution['exitCode']<0
    scope=module('original_owned_replay_scope7bd',packet['processScopePath'])
    assert sha(packet['processScopePath'])=='7bdc74b15af3ba5b2c306d34a816b48cf8b9d68479b0c06a57f43787d4a4a993'
    return packet,hashlib.sha256(raw).hexdigest(),scope
def dependencies(packet):
    verifier=module('original_installed_replay_dependencies',packet['dependencyVerifierPath'])
    result=verifier.verify(Path(packet['dependencyReceiptPath']),packet['dependencyReceiptSha256'],Path(packet['dependencyAuditPath']))
    assert result['treeSha256']==packet['dependencyTreeSha256'];return result
def closed(auth,scope):
    assert auth['allWorkersCollected'] is True and auth['allOwnedGroupsClosed'] is True
    assert isinstance(auth['closedScopes'],list) and auth['closedScopes']
    for row in auth['closedScopes']:
        assert sha(row['closurePath'])==row['closureSha256']
        receipt=json.loads(Path(row['closurePath']).read_bytes());execution=receipt['execution']
        assert execution['pgid']==row['pgid'] and execution['cleanupOwnedGroupEmpty']
        assert not any(execution['oomDelta'].values()) and not scope.owned(row['pgid'])
        if 'sourceAndDependenciesHeld' in receipt:assert receipt['sourceAndDependenciesHeld'] is True
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true');parser.add_argument('--preflight-only',action='store_true');parser.add_argument('--root-receipt');parser.add_argument('--root-receipt-sha256');args=parser.parse_args()
    packet,digest,scope=verify()
    if args.preflight_only:
        print(json.dumps({'sourcePreflightPassed':True,'packetSha256':digest,'workerStarted':False}));return 0
    assert args.run and args.root_receipt and args.root_receipt_sha256
    auth_path=Path(args.root_receipt);assert sha(auth_path)==args.root_receipt_sha256
    auth=json.loads(auth_path.read_bytes())
    assert auth['authorizedByRoot'] is True and auth['scope']==packet['scope'] and auth['packetSha256']==digest
    assert auth['policy']==POLICY and auth['preforkReserveBytes']==RESERVE
    assert re.fullmatch('[0-9a-f]{32,128}',auth['approvalToken'])
    closed(auth,scope);assert not (ROOT/'run').exists() and not (ROOT/'EXECUTION-postaudit.json').exists()
    before=dependencies(packet);baseline=scope.memory()
    def gate(now):
        assert now['current']+POLICY['rssBytes']+RESERVE<POLICY['sharedBytes'],'Authorized26GiB shared cap+2GiB reserve required'
        assert all(now['events'][key]==baseline['events'][key] for key in scope.OOM_KEYS)
    execution=scope.run_guarded([packet['bunPath'],str(ROOT/'replay-manual.ts'),'--run-one-approved'],ROOT,ROOT/'run',POLICY,
        {'G350_ORIGINAL_CPU34_GRID_REPLAY_APPROVED':'1','G350_ORIGINAL_CPU34_GRID_REPLAY_PACKET_SHA':digest,'PYTHONDONTWRITEBYTECODE':'1'},before_spawn=gate)
    verify();closed(auth,scope);after=dependencies(packet);assert before==after
    result_path=ROOT/'run/replay-result.json';result=json.loads(result_path.read_bytes()) if result_path.is_file() else None
    clean=execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values())
    manual=result.get('separateManualCandidateValidation') if result else None
    manual_complete=bool(isinstance(manual,dict) and manual['segmentCount']==5 and manual['originalPathVisibleCalls']==6
        and len(manual['segments'])==5 and [row['index'] for row in manual['segments']]==list(range(5))
        and all(type(row['visible']) is bool for row in manual['segments']) and type(manual['wholePathVisible']) is bool
        and manual['separateSceneAndInputFromOriginalGridReplay'] is True and manual['clonedManualMaterialHeld'] is True
        and manual['manualVisibilityDoesNotControlOriginalGridReplay'] is True and manual['nativeCalls']==0
        and manual['nativeCandidateValidated'] is False and manual['pairTimingMatchingQualified'] is False)
    qualified=bool(clean and result and result['diagnosticQualified'] is True and result['constructorStateMatchedCapture'] is True
        and result['materialHeld'] is True and result['originalGridConstructionCount']==1 and result['observerHooksInstalled']==0
        and result['originalCancelCalls']==1 and result['nativeCalls']==0 and manual_complete
        and result['originalExpansionCap']==500000 and result['frontierCheckpointReplayed'] is False
        and result['accepted49'] is False and result['fabricationReady'] is False)
    receipt={'diagnosticQualified':qualified,'execution':execution,'packetSha256':digest,'sourceAndDependenciesHeld':True,
        'dependenciesBefore':before,'dependenciesAfter':after,'replayResultSha256':sha(result_path) if result else None,
        'termination':result['termination'] if result else None,'actualFreshLocalPathSolved':result['termination']=='NATURAL_SOLVED' if result else False,
        'originalGridConstructionCount':1 if result else None,'observedModeConstructorNotRawArgumentReplay':True,
        'coldFreshModuleNotImportedPipelineCache':True,'frontierCheckpointReplayed':False,'engine':'Bun1.3.14',
        'noTimingComparisonAgainstNodePublic':True,'separateManualCandidateValidation':manual,
        'nativeCandidateValidated':False,'accepted49':False,'fabricationReady':False}
    (ROOT/'EXECUTION-postaudit.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'diagnosticQualified':qualified,'termination':receipt['termination'],'postauditSha256':sha(ROOT/'EXECUTION-postaudit.json'),'accepted49':False}))
    return 0 if qualified else 2

if __name__=='__main__':raise SystemExit(main())
