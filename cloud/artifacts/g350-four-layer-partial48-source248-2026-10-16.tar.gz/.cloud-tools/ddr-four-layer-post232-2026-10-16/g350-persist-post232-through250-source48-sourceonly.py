#!/usr/bin/env python3
"""Own-stdlib append245..250: capture/Core, focused native and via-track scopes.

Writes only the post232 saved directory. The Source23347/Source236 fallback and
all older saved folders remain unchanged. Source24848 is a separate partial
milestone; all timing fails and its actual14-pour margin remains pending.
"""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat

ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post232-2026-10-16'
OLD = ROOT / '.cloud-tools/ddr-four-layer-post209-2026-10-16'
INITIAL = {
    'PROGRESS.json': '5579cda8fca6a185135a660ff7c25709839fb7528b4874936ae1a8f78f3287d0',
    'WORKSPACE_HASH_INDEX.json': '49fc5bc2df2f3744263bec0701bf5c58a3a2e8b1d203951be4fe01ab40c253b2',
    'WORKSPACE_RESTORE_MANIFEST.json': 'ad49ff2d4a96d18009b370fc133bf71c74ca13677d92fd76d3498f688495e521',
    'README.md': '977f2cc46c3637c949469af2568d058bab8d6d4b532c6905c32b1a25d96df9a0',
}
OLD_PINS = {
    'WORKSPACE_HASH_INDEX.json': '809a4437af0306c37aa759044131fbaa9939032244284705c31a3910d339a83d',
    'WORKSPACE_RESTORE_MANIFEST.json': 'd8a8ebdc11a3900affe120fdd70c946403c4e26bf9b7b02bd9a1088a98369cef',
    'PROGRESS.json': 'fac4424b0ca0fe1b74fc640687a0567b7b3264267a65da5acfff5eb9091b5ef0',
}
RUNS = {
    245: Path('/tmp/g350-cap12-48-projector-root-20261016-run245'),
    246: Path('/tmp/g350-cap12-48-capture-root-20261016-run246'),
    247: Path('/tmp/g350-cap12-48-core-root-20261016-run247'),
    248: Path('/tmp/g350-cap12-48-core-diagnostic-root-20261016-run248'),
    249: Path('/tmp/g350-cap12-48-native-root-20261016-run249'),
    250: Path('/tmp/g350-cap12-48-via-track-root-20261016-run250'),
}
PLAN = RUNS[245] / 'byte0-result.json'
CAPTURE = RUNS[246] / 'byte0-result.json'
CORE_RAW = Path('/tmp/g350-cap12-48-core247-raw.json')
FRESH_RAW = Path('/tmp/g350-cap12-48-core248-raw.json')
CONTROLS, NATIVE, AUTH = [RUNS[i] / 'byte0-result.json' for i in (248, 249, 250)]
RAW_SHA = 'c5129a2ec734e873c209ab8cdccf2cad1753d177f1c87857ffae0cf7ff12a486'
CONTROLS_SHA = '5fb5a432d5854a8cccf689070d901ed4823a427cb42ec6487d474c50d081d525'
NATIVE_SHA = '763ba597bf7708dbc508a2f42672da56e650eb5811eb916c3dd36edb4c048588'
AUTH_SHA = '28a4e908e638546542d97a21be165d14a7f6ba0c8ec77457e3820ae208cf1e7e'
PLAN_SHA = 'f57834ed51009d0a88df6a70beb6ea188284bae978516d8f389e254295425d64'
CAPTURE_SHA = '0fe8c94fbfc1e9fce30006045580260f4906f1d348012605b73bbe279de90c09'
CANDIDATE_SHA = 'cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
PINS = {
    str(FRESH_RAW): RAW_SHA, str(CONTROLS): CONTROLS_SHA, str(NATIVE): NATIVE_SHA, str(AUTH): AUTH_SHA,
    str(RUNS[248] / 'COLLECTED.json'): '495d51da5763a5bd74406d5b3aa1c8090f014d3e13ec5b0051219188644b2f23',
    str(RUNS[249] / 'COLLECTED.json'): '6be6dff3497aea64d1bacb0e4463d2dbeb3cd1fc7cf9f13e38c25c9ee3ed2b96',
    str(RUNS[250] / 'COLLECTED.json'): 'b9fb201368b4ff9e63c248a06d4f4629524fbb904f6595aa9e2e202eb23b77eb',
    str(RUNS[248] / 'owned/execution.json'): '7fa01e27c143fe55d44cb78cb6d12015ed3eebdb90c8af51a67a95d98b5a1068',
    str(RUNS[249] / 'owned/execution.json'): '1341b0678947385bea5af49393726deb4cc15cfafda0d86e3bac6a7d7a2f4241',
    str(RUNS[250] / 'owned/execution.json'): '9af15a1ae148916532cb2ced9b506e38c9535b9671ed96c882d025674a62adf4',
    str(PLAN): PLAN_SHA, str(CAPTURE): CAPTURE_SHA,
    str(RUNS[245] / 'COLLECTED.json'): '31c030d6a7ddf589a9d5ebbd3c361034a86a310b6785e177416dc04be8a3ab96',
    str(RUNS[246] / 'COLLECTED.json'): 'cfe82b82f3b3243f3a98afd4dcb4b928fb529dcb58220c763b4da7efe0e73d97',
    str(RUNS[247] / 'COLLECTED.json'): 'e66eb020b877c163e6862232bb4d9311b0f41aa3bf9705afac9b6ddc87251b73',
    str(RUNS[245] / 'owned/execution.json'): '40a1b40adf225a4b2fdd9d293967069a5732bbee9095251de53008e241f34314',
    str(RUNS[246] / 'owned/execution.json'): '8d4cd69118c155cb9ee875f4f6a241c58b20b97f1868482bc770cb1ff6049a12',
    str(RUNS[247] / 'owned/execution.json'): 'ca4b7ac8a76cf216e8b8cefc7ab12f27335da91bed889270de77f233f9799483',
    '/tmp/g350-cap12point79-hardware-delta-v2-sourceonly.ts': 'f78c28a11b973e524ecac17867589186ad1fff0ff901cf993fec88d3a58fabef',
    '/tmp/g350-cap12point79-partial-projector-v2-sourceonly.ts': '1d448e11101bdb3dcfaaf72027adcf5f1ea20fa431a0a0a0a3034d8bbcc0f4cb',
    '/tmp/g350-cap12point79-partial-replay-overlay-sourceonly.ts': '5022522eadef74bcb2fcb0c3c603339d7f9a18d6fa3bdc3c2754fcde7226d4b2',
    '/tmp/g350-cap12point79-partial-capture-core-v2-sourceonly.ts': '0eea72375bdc45680f5b0835214d1c22cff351bb2283063b4b68a6b9b56d8694',
    '/tmp/g350-partial48-plan245-focused-native-checks-sourceonly.ts': 'f53652c628acce15744ebdffc37c0a88c1feac1f74f157fd9d3cd02717ddc1c4',
    '/tmp/g350-partial48-plan245-manual-via-track-manufacturing-sourceonly.ts': 'faa5e2e7cd017a816662c5bf10da570aaf8d841568d305099ef9dc21df90f14b',
    '/tmp/g350-cap12point79-partial-capture-core-v3-diagnostic-sourceonly.ts': '9b81ebcc262a92c50521ae0911ed07fb1bc8e083cd5b9e41c06705cf35500779',
}
HANDOFF = Path('/tmp/g350-cap12point79-editable-replay-handoff-20261016.md')


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
        if hasattr(os, 'posix_fadvise'):
            os.posix_fadvise(stream.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return h.hexdigest()


def read(p):
    with p.open('rb') as stream:
        return json.load(stream)


def regular(p):
    return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)


def safe(p):
    denied = ('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT', 'AUTHORITY_PACKET')
    return (p.is_absolute() and str(p).startswith('/tmp/g350-') and p.resolve().is_relative_to('/tmp')
            and not any(part in str(p).upper() for part in denied))


def metadata(p):
    s = p.stat()
    return {'bytes': s.st_size, 'sha256': digest(p), 'mode': stat.S_IMODE(s.st_mode)}


def verify_rows(folder, rows):
    for row in rows:
        relative = Path(row['path'])
        p = folder / relative
        require(not relative.is_absolute() and '..' not in relative.parts
                and p.resolve().is_relative_to(folder.resolve()) and regular(p)
                and metadata(p) == {k: row[k] for k in ('bytes', 'sha256', 'mode')}, 'Saved bytes/mode changed: ' + str(p))


def verify_old():
    for name, pin in OLD_PINS.items():
        require(digest(OLD / name) == pin, 'Frozen post209 metadata changed')
    rows = read(OLD / 'WORKSPACE_HASH_INDEX.json')['files']
    require(len(rows) == 195, 'Exact frozen post209195-row index required')
    verify_rows(OLD, rows)


def atomic_json(name, value):
    temp = SAVED / ('.append250-' + name + '.tmp')
    with temp.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        os.fchmod(stream.fileno(), 0o600)
    os.replace(temp, SAVED / name)


def main():
    require(SAVED.is_dir() and not SAVED.is_symlink(), 'Existing new post232 folder required')
    for name, pin in INITIAL.items():
        require(digest(SAVED / name) == pin, 'Exact through244 metadata required')
    index_before = read(SAVED / 'WORKSPACE_HASH_INDEX.json')
    verify_rows(SAVED, index_before['files'])
    verify_old()
    for name, pin in PINS.items():
        p = Path(name)
        require(safe(p) and regular(p) and digest(p) == pin, 'Pinned public input changed: ' + name)
    progress = read(SAVED / 'PROGRESS.json')
    manifest = read(SAVED / 'WORKSPACE_RESTORE_MANIFEST.json')
    require(progress['latestClosedScopeIncluded'] == 244, 'Append exactly after closed244')
    primary, pours = copy.deepcopy(progress['primaryCandidate']), copy.deepcopy(progress['literalPourCoverageAggregate'])
    model = copy.deepcopy(progress['separateModelMilestones'][0])
    require(primary == manifest['primaryCandidate'] and pours == manifest['literalPourCoverageAggregate']
            and progress['separateModelMilestones'] == manifest['separateModelMilestones']
            and primary['routedOwners'] == 47 and primary['caMinimumPassingCount'] == 13
            and primary['candidateSha256'] == '71bbec7babdeabda657ba1b2be75d35f5d7210d5a53d55cd2fc2b279ffb0d17b'
            and primary['literalPourClearanceQualified'] is True
            and model['candidate']['sha256'] == CANDIDATE_SHA and model['routedOwners'] == 48
            and model['criticalCompanionPending'] is False and model['allCriticalApisFreshForModel'] is True
            and model['caPlanarTimingObservations']['minimumPassingCount'] == 3, 'Preserve distinct Source47 fallback and Model48 critical244 status')
    plan, capture = read(PLAN), read(CAPTURE)
    require(plan['inputBindings']['candidate']['sha256'] == CANDIDATE_SHA
            and plan['hardwareDeltaProfile'] == 'CAP12_TRANSLATE_X_0P79_ONLY'
            and plan['cap12HardwareDelta']['profile'] == 'CAP12_TRANSLATE_X_0P79_ONLY'
            and plan['pendingOwnerIds'] == ['source_trace_26'] and len(plan['routedOwnerIds']) == 48
            and len(plan['newVias']) == 100 and len(plan['innerPortRegistrations']) == 80
            and len(plan['auxiliaryLocalTraces']) == 2
            and sum(len(g['wireRuns']) for g in plan['projectedGeometry']) == 146,
            'Actual245 candidate/cap profile and N100/I80/A2/R146 inventory')
    require(capture['passed'] is True and capture['fullInverseSourceTreePassed'] is True
            and capture['parentNormalizationInversePassed'] is True and capture['planSha256'] == PLAN_SHA
            and capture['candidateSha256'] == CANDIDATE_SHA
            and capture['cap12HardwareDelta'] == plan['cap12HardwareDelta']
            and capture['freshCoreDerived'] is False and capture['circuitConstructed'] is False
            and capture['coreRendered'] is False, 'Passed246 literal capture/full inverse, explicitly no Core at that stage')
    controls, native, auth, fresh_raw = read(CONTROLS), read(NATIVE), read(AUTH), read(FRESH_RAW)
    require(controls['rawCoreSha256'] == RAW_SHA and controls['planSha256'] == PLAN_SHA
            and controls['candidateSha256'] == CANDIDATE_SHA and controls['actualCaptureSha256'] == CAPTURE_SHA
            and controls['cap12HardwareDelta'] == plan['cap12HardwareDelta']
            and controls['partialCoreControlPassed'] is True and controls['partialDiagnosticReplayControlsPassed'] is True
            and controls['freshCoreDerived'] is True and len(controls['checks']) == 35
            and all(c['passed'] is True for c in controls['checks'])
            and controls['expectedConnectedOwners'] == 48 and controls['expectedPendingOwners'] == 1
            and controls['pendingOwnerIds'] == ['source_trace_26'] and len(controls['physicalGraphs']) == 49
            and all(g['physicallyConnectedByActualOwnedNumericIdGraph'] is (g['originalSourceTraceId'] != 'source_trace_26')
                    for g in controls['physicalGraphs']), 'Fresh248 all35 controls and exact48/1 actual numeric graphs')
    require(all(controls['expectedCounts'][k] == v for k, v in {
                'physicalVias': 229, 'pcbComponents': 509, 'sourceAndPcbPorts': 1699, 'sourceTraces': 1099,
                'physicalTraces': 313, 'reactElements': 2218, 'registeredInnerPorts': 80,
                'newVias': 100, 'newInnerPorts': 80, 'routedWireRuns': 146, 'auxiliaryLocalTraces': 2}.items()),
            'Exact actual Source248 inventories')
    native_results = {r['name']: r for r in native['results']}
    require(native['completed'] is True and native['exceptionCount'] == 0 and len(native_results) == 16
            and native['completedCheckCount'] == 16 and native['onlyFocused16WereRetested'] is True
            and native['all32FreshNativeChecksExecuted'] is False and len(native['notRetestedChecks']) == 16
            and len(native['physical10']) == 10
            and all(native_results[n]['state'] == 'completed' and not native_results[n]['findings'] for n in native['physical10'])
            and len(native_results['checkPcbBusLengthSkew']['findings']) == 3
            and all(r['state'] == 'completed' and not r['findings'] for n, r in native_results.items() if n != 'checkPcbBusLengthSkew')
            and native['allFindingsRetainedWithoutFilteringOrDedupe'] is True
            and native['rawFileUnchanged'] is True and native['controlsFileUnchanged'] is True
            and native['reviewedPlan245FileUnchanged'] is True, 'Native249 focused16: geometry zero; all3 skew findings retained')
    require(auth['scope'] == 'EXPLICITLY_PINNED_M48_PLAN245_CAP12_AUTHENTICATED_229_MANUAL_VIA_TRACK_MANUFACTURING_DIAGNOSTIC'
            and auth['complete'] is True and auth['actualViaCount'] == auth['completedViaCount'] == 229
            and auth['foreignViaTrackCopperClearancePassed'] is True and auth['exactInputFilesUnchanged'] is True
            and all(auth[k] == [] for k in ('violations', 'ambiguousVias', 'identityFailures', 'invalidSegments', 'unresolvedSegmentOwners'))
            and auth['source236GeometryOrPourQualificationInherited'] is False
            and auth['source233TimingQualificationInherited'] is False, 'Auth250 exact229 genuine aliases/foreign-wire pass')
    for d in (native, auth):
        require(d['inputBindings']['raw']['sha256'] == RAW_SHA
                and d['inputBindings']['controls']['sha256'] == CONTROLS_SHA, 'Both fresh diagnostics bind actual248 bytes')
    require(native['inputBindings']['reviewedSourcePlan245']['sha256'] == PLAN_SHA
            and native['inputBindings']['reviewedSourcePlan245']['candidate243Sha256'] == CANDIDATE_SHA
            and auth['inputBindings']['plan']['sha256'] == PLAN_SHA
            and auth['inputBindings']['candidate']['sha256'] == CANDIDATE_SHA, 'Exact245/243 diagnostic bindings')
    fresh_pour_ids = [r['pcb_copper_pour_id'] for r in fresh_raw if r.get('type') == 'pcb_copper_pour']
    require(fresh_pour_ids == ['pcb_copper_pour_' + str(i) for i in (0,13,19,25,26,27,36,42,50,54,55,57,61,67)],
            'Actual Source24814-pour roster; no Source23615-pour inheritance')
    closed_rows = []
    for scope, folder in RUNS.items():
        closed, execution = read(folder / 'COLLECTED.json'), read(folder / 'owned/execution.json')
        require(closed['scope'] == scope and closed.get('closedAt') and closed['execution'] == execution
                and closed['sourcePinsUnchanged'] is True and closed['protectedFilesUnchanged'] is True
                and closed['all49Accepted'] is False and execution['cleanupOwnedGroupEmpty'] is True
                and execution['accepted'] is False, 'Exact closed nonaccepting receipt: ' + str(scope))
        require(execution['exitCode'] == (1 if scope == 247 else 0), 'Only247 failed; other collected stages passed')
        if scope == 247:
            log = (folder / 'owned/child.log').read_text()
            require(not (folder / 'byte0-result.json').exists() and not CORE_RAW.exists()
                    and 'USBLC6_2SC6.obj' in log and 'Expected ";"' in log,
                    '247 OBJ loader exception without raw/Core-control outputs')
        closed_rows.append((scope, folder, closed, execution))
    for name, pin in INITIAL.items():
        dest = SAVED / ('HISTORY_THROUGH244_' + name)
        require(not dest.exists(), 'Fresh exact through244 history')
        with (SAVED / name).open('rb') as reader, dest.open('xb') as writer:
            shutil.copyfileobj(reader, writer, 1024 * 1024)
            os.fchmod(writer.fileno(), stat.S_IMODE((SAVED / name).stat().st_mode))
        require(digest(dest) == pin, 'Exact metadata history')
    targets = {r['restorePath']: copy.deepcopy(r) for r in manifest['files']}
    bases = {r['restorePath']: copy.deepcopy(r) for r in manifest['baseDependencyRestoreFiles']}
    catalog = {}
    for folder in (ROOT / '.cloud-tools/ddr-four-layer-manual-2026-10-16', OLD):
        for row in read(folder / 'WORKSPACE_RESTORE_MANIFEST.json')['files']:
            catalog[row['restorePath']] = {'baseSavedDirectory': folder.relative_to(ROOT).as_posix(), **row}
    inputs = {}

    def save(p, name=None, force=False):
        p = Path(p)
        require(safe(p) and regular(p), 'Only public regular sources: ' + str(p))
        before, data = p.stat(), metadata(p)
        inputs[str(p)] = data
        if str(p) in targets:
            require(data == {k: targets[str(p)][k] for k in data}, 'Existing restore target changed')
            return targets[str(p)]
        old = bases.get(str(p)) or catalog.get(str(p))
        if not force and old and data == {k: old[k] for k in data}:
            bases[str(p)] = copy.deepcopy(old)
            return old
        dest = SAVED / (name or p.name)
        require(dest.parent == SAVED, 'Flat saved filename required')
        if dest.exists() and metadata(dest) != data:
            dest = dest.with_name(dest.stem + '__' + data['sha256'][:16] + dest.suffix)
        if not dest.exists():
            with p.open('rb') as reader, dest.open('xb') as writer:
                shutil.copyfileobj(reader, writer, 1024 * 1024)
                os.fchmod(writer.fileno(), data['mode'])
        require(metadata(dest) == data, 'Exact saved payload bytes/mode')
        after = p.stat()
        require((before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
                (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'Source changed during copy')
        row = {'savedPath': dest.name, 'restorePath': str(p), **data}
        targets[str(p)] = row
        bases.pop(str(p), None)
        return row

    sources, additions = set(), []
    for scope, folder, closed, execution in closed_rows:
        label = 'CAP12_SOURCE' + str(scope) + ('_LOADER_FAILED_NO_CORE' if scope == 247 else '_SCOPED_PASSED')
        receipt = save(folder / 'COLLECTED.json', label + '_COLLECTED.json', True)
        for p in sorted(folder.glob('byte0-result*.json')):
            save(p, label + '_' + p.name, True)
        for filename in ('execution.json', 'child.log', 'memory.jsonl'):
            p = folder / 'owned' / filename
            require(regular(p), 'Owned closed runtime evidence required')
            save(p, label + '_owned_' + filename, True)
        command = execution['command']
        worker = Path(command[1])
        save(worker, force=True)
        sources.add(worker)
        for arg in command[2:]:
            p = Path(arg)
            if safe(p) and regular(p):
                save(p)
                if p.suffix in ('.ts', '.tsx', '.py', '.mjs'):
                    sources.add(p)
                for sibling in ('contacts.json', 'proof.json'):
                    if regular(p.parent / sibling):
                        save(p.parent / sibling)
        additions.append({'scope': scope, 'closedAt': closed['closedAt'], 'exitCode': execution['exitCode'],
                          'closure': copy.deepcopy(receipt),
                          'terminalOutcome': {245:'EDITABLE_PLAN_PROJECTION_PASSED',246:'EDITABLE_LITERAL_CAPTURE_FULL_INVERSE_PASSED',
                              247:'OBJ_AS_JS_LOADER_EXCEPTION_NO_RAW_OR_CONTROLS',248:'ALL35_FRESH_CORE_CONTROLS_PASSED',
                              249:'FOCUSED16_NATIVE_COMPLETED_PHYSICAL_ZERO_THREE_BUS_SKEW_FINDINGS',
                              250:'ALL229_AUTHENTICATED_MANUAL_VIA_TRACK_CHECKS_PASSED'}[scope],
                          'freshCorePassed': scope == 248, 'freshNativeExecuted': scope == 249,
                          'geometryFindingsProduced': scope == 249,
                          'all49Accepted': False, 'fabricationReady': False})
    for name in PINS:
        save(Path(name), force=True)
        if Path(name).suffix in ('.ts', '.tsx', '.py', '.mjs'):
            sources.add(Path(name))
    handoff = save(HANDOFF, force=True)
    save(Path(__file__), force=True)
    visited = set()
    for _ in range(3):
        following = set()
        for p in sorted(sources - visited):
            visited.add(p)
            for literal in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]", p.read_text()):
                q = Path(literal)
                if safe(q) and regular(q):
                    save(q)
                    if q.suffix in ('.py', '.ts', '.tsx', '.mjs'):
                        following.add(q)
        sources |= following
    binding = {'projectionScope': 245, 'plan': copy.deepcopy(targets[str(PLAN)]),
               'captureScope': 246, 'capture': copy.deepcopy(targets[str(CAPTURE)]),
               'candidateSha256': CANDIDATE_SHA, 'hardwareDeltaProfile': 'CAP12_TRANSLATE_X_0P79_ONLY',
               'projectionPassed': True, 'editableLiteralCapturePassed': True,
               'fullSourceInversePassed': True, 'originalKeyNormalizationInversePassed': True,
               'newViaCount': 100, 'innerPortRegistrations': 80, 'routedWireRuns': 146, 'pendingTopAuxiliaryTraces': 2,
               'expectedPhysicalVias': 229, 'expectedPhysicalTraces': 313,
               'freshCorePassed': True, 'freshCoreControlReportExists': True, 'freshCoreScope': 248,
               'raw': copy.deepcopy(targets[str(FRESH_RAW)]), 'controls': copy.deepcopy(targets[str(CONTROLS)]),
               'core247FailureClosure': copy.deepcopy(targets[str(RUNS[247] / 'COLLECTED.json')]),
               'core247Failure': 'USBLC6_2SC6.obj parsed as JavaScript; no geometry findings or Core raw/control outputs',
               'successful248DiagnosticSource': copy.deepcopy(targets['/tmp/g350-cap12point79-partial-capture-core-v3-diagnostic-sourceonly.ts']),
               'loaderFixProven': False, 'assetBehaviorChangedByDiagnosticSource': False,
               'native249Report': copy.deepcopy(targets[str(NATIVE)]), 'focusedNativeChecksCompleted': 16,
               'physical10FindingCount': 0, 'nativeBusSkewFindingCount': 3, 'other16NativeChecksNotRetested': True,
               'auth250Report': copy.deepcopy(targets[str(AUTH)]), 'authenticatedManualViaCount': 229,
               'foreignViaTrackViolationCount': 0, 'ambiguousViaCount': 0,
               'freshLiteralPourCount': 14, 'freshLiteralPourIds': fresh_pour_ids,
               'literalPourClearanceQualified': False, 'literalPourAuditPending': True,
               'priorSource236PourPassInherited': False,
               'handoff': copy.deepcopy(handoff), 'all49Accepted': False, 'fabricationReady': False}
    model.update({'priorModelScope': model['scope'],
                  'scope': 'ROOT243_CAP12_PLUS_X0P79_SOURCE248_48_SCOPED_EVIDENCE_NOT_FULL_BOARD_QUALIFICATION',
                  'editableSourceProjection245Passed': True, 'editableSourceCapture246Passed': True,
                  'editableSourceReplayEvidence': binding, 'freshCorePending': False,
                  'freshSourceCaptureCorePending': False, 'freshCore248All35Passed': True,
                  'latestSucceededCoreScope': 248, 'focusedNative249Completed': True,
                  'focusedNative249Physical10Passed': True, 'freshViaTrackAuth250Passed': True,
                  'source248TimingObservations': copy.deepcopy(controls['timingObservations']),
                  'freshLiteralPourCount': 14, 'freshLiteralPourIds': fresh_pour_ids,
                  'literalPourClearanceQualified': False, 'literalPourAuditPending': True,
                  'latestFailedCoreScope': 247, 'coreFailureIsGeometryFinding': False})
    require(model['freshSourceCaptureCorePending'] is False and model['allBoardNativeChecksPending'] is True
            and model['allCriticalApisFreshForModel'] is True and model['criticalCompanionPending'] is False
            and model['source236PourPassInherited'] is False and model['merged233CAGeometryOrTimingPassInherited'] is False
            and all(model[k] is False for k in ('fullTimingPassed', 'tiQualified', 'cadQualified',
                    'defaultBoardPromoted', 'all49Accepted', 'fabricationReady')), 'All other model boundaries retained')
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    progress['updatedAt'] = manifest['updatedAt'] = now
    progress['scope'] = 'Post232 through250; Source23347 fallback; separate Source24848/focused native249/auth250 pass;14pours pending'
    progress['latestClosedScopeIncluded'] = 250
    require(not any(r['scope'] in RUNS for r in progress['closedExperiments']), 'New245..250 append only')
    progress['closedExperiments'].extend(additions)
    progress['separateModelMilestones'] = [model]
    manifest['separateModelMilestones'] = copy.deepcopy(progress['separateModelMilestones'])
    prepared = [copy.deepcopy(targets[n]) for n in PINS if 'partial48-plan245' in n or 'v3-diagnostic' in n]
    progress['preparedModel48Diagnostics'] = {'sources': prepared, 'executedByThisCollector': False,
                                             'rootExecutedScopes': [248,249,250],
                                             'newNativeOrAuthenticatedViaPassInherited': False}
    manifest['preparedModel48Diagnostics'] = copy.deepcopy(progress['preparedModel48Diagnostics'])
    manifest['files'] = sorted(targets.values(), key=lambda r: r['restorePath'])
    manifest['baseDependencyRestoreFiles'] = sorted(bases.values(), key=lambda r: r['restorePath'])
    progress['publicBaseRestoreDependencies'] = copy.deepcopy(manifest['baseDependencyRestoreFiles'])
    progress['through244MetadataPins'] = INITIAL
    progress['appendCollector'] = str(Path(__file__))
    require(progress['primaryCandidate'] == manifest['primaryCandidate'] == primary
            and progress['literalPourCoverageAggregate'] == manifest['literalPourCoverageAggregate'] == pours,
            'Source23347/Source236 fallback must remain literal')
    for name, data in inputs.items():
        require(metadata(Path(name)) == data, 'Collected public input changed')
    for name, pin in PINS.items():
        require(digest(Path(name)) == pin, 'Pinned public input changed at closure')
    require(not CORE_RAW.exists() and not (RUNS[247] / 'byte0-result.json').exists(), 'No247 raw/control output created')
    verify_rows(SAVED, [r for r in index_before['files'] if r['path'] not in INITIAL])
    verify_old()
    atomic_json('WORKSPACE_RESTORE_MANIFEST.json', manifest)
    readme = """CURRENT THROUGH250: Source23347 remains the Source/Core-verified fallback with
focused native237 results, scoped Source23615-pour pass and13 CA minimum owners.
Separate SOURCE248 has48 numeric-connected routes, pending26, critical244 pass,
245 projection/246 literal capture with full inverse, and all35 fresh Core248
controls passed. Native249 completed focused16: physical10 and the requested
other geometry checks returned zero findings; all3 bus-skew findings remain.
Other16 native checks were not retested. Auth250 authenticated229 actual vias and
found zero foreign via-track violations, ambiguities, identities or unresolved
owners. The new actual raw has14 pours whose margin is NOT YET QUALIFIED. No
Source23615-pour pass or233 CA13 timing progress is inherited. Its own CA minimum
count remains3; complete timing, TI/reference continuity, electrical/default,
all49/CAD/fabrication readiness remain FALSE.

Core247's USBLC6 OBJ-as-JavaScript failure and log are retained; it produced no
raw/control outputs or geometry findings. Core248 passed using the diagnostic
wrapper with no asset-behavior changes; no loader fix is asserted. Older status
paragraphs are historical. Four exact through244 metadata files remain
HISTORY_THROUGH244_*. No candidate geometry changed in this append.

""" + (SAVED / 'README.md').read_text()
    temp = SAVED / '.append250-README.tmp'
    with temp.open('x') as stream:
        stream.write(readme)
        os.fchmod(stream.fileno(), 0o600)
    os.replace(temp, SAVED / 'README.md')
    excluded = {'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
    progress['artifacts'] = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir()) if regular(p) and p.name not in excluded]
    atomic_json('PROGRESS.json', progress)
    rows = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir()) if regular(p) and p.name != 'WORKSPACE_HASH_INDEX.json']
    atomic_json('WORKSPACE_HASH_INDEX.json', {'scope': 'Post232 through250; Source23347 fallback; separate Source24848 scoped checks,14pours pending',
                'updatedAt': now, 'files': rows, 'selfExcluded': True, 'all49Accepted': False, 'fabricationReady': False})
    verify_rows(SAVED, rows)
    for row in manifest['files']:
        wanted = {k: row[k] for k in ('bytes', 'sha256', 'mode')}
        require(metadata(SAVED / row['savedPath']) == wanted and metadata(Path(row['restorePath'])) == wanted, 'Exact restore bytes/mode')
    verify_old()
    print(json.dumps({'savedDirectory': str(SAVED), 'latestClosedScope': 250, 'savedFiles': len(list(SAVED.iterdir())),
          'indexedFiles': len(rows), 'restoreTargets': len(manifest['files']), 'baseDependencies': len(manifest['baseDependencyRestoreFiles']),
          'sourceVerifiedFallbackOwners': 47, 'modelRoutedOwners': 48, 'editableCapture246Passed': True,
          'freshCore247Passed': False, 'freshCore248All35Passed': True, 'focusedNative249Physical10Passed': True,
          'auth250All229Passed': True, 'actualSource248PourCount': 14, 'source248PourQualificationPending': True,
          'all49Accepted': False, 'fabricationReady': False,
          'metadataHashes': {n: digest(SAVED / n) for n in INITIAL}}, indent=2))


if __name__ == '__main__':
    main()
