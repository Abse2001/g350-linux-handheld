"""One Root-owned pure metadata derivation; reuse original successful native CAD."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
 phase=sys.argv[1] if len(sys.argv)==2 else None
 if phase!='readonly' or os.environ.get('G350_DERIVED_CAD_STAGE')!=phase:raise ValueError('Exact Root readonly stage required')
 manifest=ROOT/'PREPARED-manifest.json';m=json.loads(manifest.read_bytes())
 if os.environ.get('G350_DERIVED_CAD_PACKET_SHA')!=sha(manifest):raise ValueError('Readonly source packet changed')
 auth=Path(os.environ['G350_DERIVED_CAD_ROOT_RECEIPT']);a=json.loads(auth.read_bytes())
 if sha(auth)!=os.environ['G350_DERIVED_CAD_ROOT_RECEIPT_SHA'] or a.get('authorizedByRoot') is not True or a.get('phase')!=phase or a.get('packetSha256')!=sha(manifest):raise ValueError('Exact Root readonly authority required')
 run=ROOT/'run-readonly';report={'phase':phase,'packetSha256':sha(manifest),'commands':[],'passed':False,'coreBuildCount':0,'cliCalls':0,'routingCalls':0,'cadCalls':0,'dockerCalls':0,'accepted49':False,'fabricationReady':False}
 def save():(run/'result.json').write_text(json.dumps(report,indent=2)+'\n')
 try:
  output=run/'derived-count-report.json';argv=[sys.executable,'-B',str(ROOT/'verify-derived-cad-count.py'),'--output',str(output)]
  started=time.monotonic()
  with (run/'pure-source-raw-native-derived-count.log').open('xb') as out:result=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=False)
  report['commands'].append({'name':'pure-source-raw-native-derived-count','argv':argv,'cwd':str(ROOT),'exitCode':result.returncode,'seconds':time.monotonic()-started});save()
  if result.returncode:raise ValueError('Strict derived-count evidence gate failed')
  derived=json.loads(output.read_bytes())
  if derived.get('passed') is not True or derived['derivedSourceSegmentCount']!=derived['rawSegmentCount'] or derived['rawSegmentCount']!=derived['actualNativeOwnedSegmentCount'] or derived['zeroMicroscopicOrNativeCollapsedPairs']!=0 or derived['allOriginalCadPredicatesHeldExceptSupersededLiteral168'] is not True or derived['sourceAndEvidenceFilesHeld'] is not True:raise ValueError('Derived count or original physical acceptance differs')
  report.update(passed=True,derivedCountReportSha256=sha(output),derivedSourceRawNativeCount=derived['derivedSourceSegmentCount'],originalFailedWrapperPreserved=True,originalActualCadReportSha256=m['actualCadReportSha256'],referenceQualified=False)
  save();print(json.dumps({'phase':phase,'passed':True,'derivedSourceRawNativeCount':derived['derivedSourceSegmentCount'],'newCadCalls':0,'accepted49':False}));return 0
 except BaseException as error:
  report['failure']=str(error);save();raise
if __name__=='__main__':raise SystemExit(main())
