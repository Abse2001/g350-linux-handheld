# Existing Core readonly Python-path successor

This packet repairs the import path omitted by the previous verifier. No package installation is needed: `.cloud-tools/python-routing` already holds Shapely 2.1.2 and NumPy 2.3.5, both CPython 3.12 wheels. The compatible existing interpreter is CPython 3.12.14 under the Codex runtime. `/usr/bin/python3` is 3.13 and is unsuitable for these wheels. The supported setup already inserts this target in `scripts/verify-g350-routing-tools.py`; the new wrapper does the same before the unchanged verifier.

The prior source capture and full type stage actually passed. Direct pinned Core rendering actually passed and saved `384628cd46c2b5cb5b32a94d442651eda3c604c8acf19bd85fc68b728f529769`; the previous strict verification stopped at `ModuleNotFoundError: shapely`, so strict forward/native/manufacturing verification remains unrun. Preserve that failed stage and its closed Root receipt. This packet reuses its exact board, with no source capture, typecheck, Core build, routing, CLI, CAD export, Docker, refill, or hardware edit.

The strict source verifier, frozen original Core fixture, owner proposal, native18 helper, installed board dependencies, source closure and protected files are hash bound. The verifier is byte exact and still requires both retained pours to equal their original copper minus the explicit union of precisely 31 new foreign via antipads each, with its existing serialization bound. It still preserves the 280 parts, 1,161 contacts, original 217 logical links, source pins/nets, and RAM7 two exact physical traces/vias. Native17 runs on raw actual Core; check18 runs only on the separately proved geometry-identical known-net ownership projection.

Python is bound by executable hash, ABI/version and complete imported NumPy/Shapely package, metadata and bundled-library tree hashes. The future worker inserts only the existing target, checks exact imported module and extension locations, verifies NumPy 2.3.5/Shapely 2.1.2/GEOS 3.13.1, and runs a tiny 3-4-5 geometry gate. Bytecode writes are disabled; package/source/dependency/board hashes must remain equal afterward. No installation was performed.

Root runs this packet only after every previous actual worker has been collected and no Root worker remains active. The bounded owned process/session scope is 60 seconds, 2 GiB sampled owned RSS, 26 GiB sampled shared memory, plus a 2 GiB prefork reserve. Exact prefork requirement is `memory.current + 2,147,483,648 + 2,147,483,648 < 27,917,287,424` bytes. Limits are sampled, with the inherited pidfd/WNOWAIT/subreaper ownership cleanup.

Root may first run metadata-only preflight:

```bash
cd /workspace/g350-linux-handheld
source cloud/env.sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -B .cloud-tools/ddr-hs-all32-existing-core-pinned-python-readonly-next/guard.py --preflight
```

For the one actual run, Root writes an exclusive authority receipt outside this packet containing `authorizedByRoot=true`, `phase=readonly`, the exact manifest SHA, the manifest stage scope and policy, `allPreviousRootWorkersCollected=true`, `noConcurrentRootWorker=true`, an approval token, and `previousClosedPostaudits` with the latest actually collected Root scope path/hash. Root then runs:

```bash
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -B .cloud-tools/ddr-hs-all32-existing-core-pinned-python-readonly-next/guard.py --root-receipt /absolute/root-auth.json --root-receipt-sha256 EXACT_AUTH_SHA
```

Preparation performs only metadata reads, hashing and Python AST parsing. It never imports Shapely, NumPy, board source, Core or native checks and never launches an actual qualification worker. Root must read the helpers, obtain finite peer review, and collect the actual future result before claiming a pass. Even a passing result qualifies only these 64 local cap/stub/via graphs and native checks. Package supply connections, filled-reference connectivity, custom all-four-layer DDR reference design, 49 DDR interconnects, timing, impedance and whole-board manufacturing remain open. `fabricationReady=false`.
