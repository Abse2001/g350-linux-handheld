#!/usr/bin/env python3
"""Freeze Source248 partial48 evidence at closed252 + all14 pours + reviewed plot.

Own stdlib only: no SDK, application import, geometry execution, archive or commit.
Only the post232 saved folder is changed. All later routing needs a new folder.
"""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat

ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post232-2026-10-16'
OLD = ROOT / '.cloud-tools/ddr-four-layer-post209-2026-10-16'
INITIAL = {
    'PROGRESS.json': 'e1cfc15568d1c411a264b46b364f32c3e358fe35e2cb51f976a238650f97337d',
    'WORKSPACE_HASH_INDEX.json': 'e73e7dd62023f5d18507ab0eef3f6168b43880ffe288a7b8a661c6a3f2311c63',
    'WORKSPACE_RESTORE_MANIFEST.json': '855cb794d4b1c101005c756280f268e58e2aa8ef71f235d21917ed0a451a81d9',
    'README.md': '55da1dcb0e4d01b9a75bb53b7dce8aa7e2fef20aa221d3431c5e8cbaaed122bc',
}
OLD_PINS = {
    'WORKSPACE_HASH_INDEX.json': '809a4437af0306c37aa759044131fbaa9939032244284705c31a3910d339a83d',
    'WORKSPACE_RESTORE_MANIFEST.json': 'd8a8ebdc11a3900affe120fdd70c946403c4e26bf9b7b02bd9a1088a98369cef',
    'PROGRESS.json': 'fac4424b0ca0fe1b74fc640687a0567b7b3264267a65da5acfff5eb9091b5ef0',
}
RUNS = {
    251: Path('/tmp/g350-last-d12-new42-root-20261016-run251'),
    252: Path('/tmp/g350-last-d12-new42-inner2-root-20261016-run252'),
}
AUDIT = Path('/tmp/g350-source248-all14-literal-pour-margin-root-20261016.json')
AGGREGATE = Path('/tmp/g350-source248-all14-literal-pour-margin-root-aggregate-20261016.json')
AUDITOR = Path('/tmp/g350-partial48-plan245-literal-selected-pour-clearance-audit-sourceonly.py')
COMBINER = Path('/tmp/g350-partial48-plan245-literal-pour-coverage-combiner-sourceonly.py')
PLOT_SOURCE = Path('/tmp/g350-plot-source248-cap12-manual48-root-sourceonly.py')
ARCHIVE_SOURCE = Path('/tmp/g350-post232-source248-evidence-archive-builder-v2-sourceonly.py')
SMOKE_SOURCE = Path('/tmp/g350-source248-portable-archive-smoke-validator-sourceonly.py')
CANDIDATE = '/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json'
CANDIDATE_SHA = 'cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
RAW = '/tmp/g350-cap12-48-core248-raw.json'
RAW_SHA = 'c5129a2ec734e873c209ab8cdccf2cad1753d177f1c87857ffae0cf7ff12a486'
CONTROLS = '/tmp/g350-cap12-48-core-diagnostic-root-20261016-run248/byte0-result.json'
CONTROLS_SHA = '5fb5a432d5854a8cccf689070d901ed4823a427cb42ec6487d474c50d081d525'
AUTH = '/tmp/g350-cap12-48-via-track-root-20261016-run250/byte0-result.json'
AUTH_SHA = '28a4e908e638546542d97a21be165d14a7f6ba0c8ec77457e3820ae208cf1e7e'
PLAN = '/tmp/g350-cap12-48-projector-root-20261016-run245/byte0-result.json'
PLAN_SHA = 'f57834ed51009d0a88df6a70beb6ea188284bae978516d8f389e254295425d64'
POURS = ['pcb_copper_pour_' + str(i) for i in (0,13,19,25,26,27,36,42,50,54,55,57,61,67)]
PINS = {
    str(RUNS[251] / 'COLLECTED.json'): 'b7496a040c8c65e1d1208b0f7a37beec3d43ecdfab7779f6c2f620215ff4f419',
    str(RUNS[251] / 'byte0-result.json'): '816dbab0b3ed50376a929758501283dda520536af25c3972d171e9243784e8c7',
    str(RUNS[251] / 'owned/execution.json'): 'ee98bd7c81118dcf85503f11cadaa7c5152ac816dac16a10c6329d7db2600f6b',
    str(RUNS[252] / 'COLLECTED.json'): '89d9bbf1499a5314fe908f1228ef9558f7b28ba3641d3aa5be89fd6d07ba0ccc',
    str(RUNS[252] / 'byte0-result.json'): '1e48f82db0f86fd0bceed0c265b4cb622a180e5662a0441209dfe5a4655f3fc2',
    str(RUNS[252] / 'owned/execution.json'): 'edd09ddd8156d080a64d8a46f628f5799c3bd645345ed52fde1732bea3b47b70',
    '/tmp/g350-current243-new42-two-fullspan-d12P1225-four-layer-suffix-v2-sourceonly.ts': '9137270a40524ce4e29e2a29a7f7d58b14380f092fb147d555c46390e8894ba6',
    '/tmp/g350-current243-new42-inner2-two-fullspan-d12P1225-four-layer-suffix-v3-sourceonly.ts': 'ae73dd53680d43ed56f91a71d5198013fad26d38a93727bfc1de0060941110fb',
    '/tmp/g350-current243-new42-two-portals-d12P1225-joint-review-report.json': '13b74e6d5a5462f2e820222f1aa68eaf32c35526de4d06db4654f8bc85444185',
    '/tmp/g350-current243-new42-inner2-two-portals-d12P1225-joint-review-report.json': 'fb335b0292911442556fe8a07abb0cb4f56b94e976b62a2bbbd29dfa294d5cff',
    '/tmp/g350-current243-new42-D12P1225-independent-static.json': '5d47e7b26879caa2758cf4f716c184496b8d4384ab06954617d692497d0786e9',
    str(AUDIT): '24bcf74b621ee9530b71cac52a8a6158410ebd0db0cc8e625068bd686ee9cc55',
    str(AGGREGATE): '0eb6c21f4e27962f2f621f3586b3fd3d8bc7ca5f2f112a0741e1323c7260ae7a',
    str(AUDITOR): '8bca2fe7c63fb3fc74fdc6f2930590d891358b7fff09fcf8d46b08452f07f443',
    str(COMBINER): 'd4c60a75baf28f3312381a48aab5ee2d0b201eb4f78a8e85eba67db15878a641',
    str(PLOT_SOURCE): 'a3b2d4aaf0d6f826e25d62394e57a1edebf6bac81204285fc2c69c117145aac3',
    str(ARCHIVE_SOURCE): 'e503fe783e1f7bebc2ea9dc9315d8835ad1aef06c3574b8983ff3c5b019613b9',
    str(SMOKE_SOURCE): '29c6128019599e4def01b517bec140e62c07df7006fc3f03362a37f254d42330',
}
PLOT_PINS = {
    'SOURCE248_CAP12_PARTIAL48_FOUR_LAYER_MILESTONE.png': '994d95f7fe7a4a9b21f6da3447d051d7e28089e3734e793ee7eef3c6ccb42dee',
    'SOURCE248_CAP12_PARTIAL48_FOUR_LAYER_MILESTONE.svg': 'b61e412ff310ac183aaee4af043b95933c8182ad69372c561fed2b2e2ecaa5f3',
}


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
        if hasattr(os, 'posix_fadvise'):
            os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return h.hexdigest()


def read(p):
    with p.open('rb') as f:
        return json.load(f)


def regular(p):
    return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)


def safe(p):
    denied = ('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT', 'AUTHORITY_PACKET')
    return (p.is_absolute() and str(p).startswith('/tmp/g350-') and p.resolve().is_relative_to('/tmp')
            and not any(part in str(p).upper() for part in denied))


def metadata(p):
    s = p.stat()
    return {'bytes': s.st_size, 'sha256': digest(p), 'mode': stat.S_IMODE(s.st_mode)}


def verify_rows(folder, rows):
    for row in rows:
        relative = Path(row['path'])
        p = folder / relative
        require(not relative.is_absolute() and '..' not in relative.parts
                and p.resolve().is_relative_to(folder.resolve()) and regular(p)
                and metadata(p) == {k: row[k] for k in ('bytes', 'sha256', 'mode')}, 'Saved bytes/mode changed: ' + str(p))


def verify_old():
    for name, pin in OLD_PINS.items():
        require(digest(OLD / name) == pin, 'Frozen post209 metadata changed')
    rows = read(OLD / 'WORKSPACE_HASH_INDEX.json')['files']
    require(len(rows) == 195, 'Exact frozen post209195-row inventory')
    verify_rows(OLD, rows)


def atomic_json(name, value):
    temp = SAVED / ('.final252-' + name + '.tmp')
    with temp.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')
        os.fchmod(f.fileno(), 0o600)
    os.replace(temp, SAVED / name)


def main():
    require(SAVED.is_dir() and not SAVED.is_symlink(), 'Existing new post232 folder')
    for name, pin in INITIAL.items():
        require(digest(SAVED / name) == pin, 'Exact through250 metadata')
    prior_index = read(SAVED / 'WORKSPACE_HASH_INDEX.json')
    verify_rows(SAVED, prior_index['files'])
    expected_existing = {r['path'] for r in prior_index['files']} | {'WORKSPACE_HASH_INDEX.json'} | set(PLOT_PINS)
    require({p.name for p in SAVED.iterdir()} == expected_existing, 'Only two Root-rendered plots may be newly unindexed')
    for name, pin in PLOT_PINS.items():
        require(regular(SAVED / name) and digest(SAVED / name) == pin, 'Exact Root-rendered and viewed plot')
    verify_old()
    for name, pin in PINS.items():
        p = Path(name)
        require(safe(p) and regular(p) and digest(p) == pin, 'Pinned public final input: ' + name)
    progress, manifest = read(SAVED / 'PROGRESS.json'), read(SAVED / 'WORKSPACE_RESTORE_MANIFEST.json')
    require(progress['latestClosedScopeIncluded'] == 250 and not progress.get('frozenCheckpoint'), 'Freeze exactly after250')
    primary = copy.deepcopy(progress['primaryCandidate'])
    fallback_pours = copy.deepcopy(progress['literalPourCoverageAggregate'])
    require(primary == manifest['primaryCandidate'] and fallback_pours == manifest['literalPourCoverageAggregate']
            and primary['routedOwners'] == 47 and primary['caMinimumPassingCount'] == 13
            and primary['candidateSha256'] == '71bbec7babdeabda657ba1b2be75d35f5d7210d5a53d55cd2fc2b279ffb0d17b', 'Literal independent Source233/23647 timing fallback')
    model = copy.deepcopy(progress['separateModelMilestones'][0])
    require(progress['separateModelMilestones'] == manifest['separateModelMilestones']
            and model['candidate']['sha256'] == CANDIDATE_SHA and model['routedOwners'] == 48
            and model['pendingOwnerIds'] == ['source_trace_26'] and model['freshCore248All35Passed'] is True
            and model['focusedNative249Physical10Passed'] is True and model['freshViaTrackAuth250Passed'] is True
            and model['allCriticalApisFreshForModel'] is True and model['caPlanarTimingObservations']['minimumPassingCount'] == 3,
            'Latest actual Source24848 with current scoped controls/native/auth/critical evidence')
    audit, aggregate = read(AUDIT), read(AGGREGATE)
    for d in (audit, aggregate):
        b = d['inputBindings']
        require(b['raw']['sha256'] == RAW_SHA and b['controls']['sha256'] == CONTROLS_SHA
                and b['current229Ownership']['sha256'] == AUTH_SHA and b['reviewedSourcePlan245']['sha256'] == PLAN_SHA
                and d['completed'] is True and d['literalForeignPourMarginClear'] is True
                and d['actualRawPourIds'] == POURS and d['actualRawPourCount'] == 14
                and d['actualViaCount'] == 229 and d['wireSegmentCount'] == 957
                and d['requiredForeignViaPourEdgeMm'] == d['requiredForeignWirePourEdgeMm'] == .1016
                and d['coordinateToleranceMm'] == 1e-8 and d['inputFilesUnchanged'] is True
                and d['violations'] == [] and d['unsupportedGeometry'] == []
                and d['source236GeometryOrPourQualificationInherited'] is False
                and all(d[k] is False for k in ('all49Accepted','fullBoardPassed','electricalTimingQualified',
                        'ownNetReentryQualified','referenceWireGeometryIncluded','nativeExecuted','cadExecuted','fabricationReady')),
                'Exact Source248 all14/229/957 scoped pass with unchanged thresholds and no inheritance')
    require(audit['auditSourceSha256'] == PINS[str(AUDITOR)] and audit['allActualPoursCompleted'] is True
            and audit['selectedPourIds'] == POURS and audit['omittedPourIds'] == []
            and len(audit['pourReports']) == 14 and all(p['state'] == 'COMPLETED' and not p['violations'] for p in audit['pourReports'])
            and audit['globalIdentityFailures'] == audit['viaIdentityFailures'] == audit['unknownPourIdentities'] == [], 'All14 actual audit pours completed without failures')
    require(aggregate['candidate243Sha256'] == CANDIDATE_SHA
            and aggregate['inputBindings']['report_0']['sha256'] == PINS[str(AUDIT)]
            and aggregate['auditSourceSha256'] == PINS[str(AUDITOR)]
            and aggregate['wireOwnerCount'] == 48 and aggregate['completedPourCount'] == 14
            and aggregate['completedPourIds'] == POURS and aggregate['excludedBoundedPartialReports'] == []
            and aggregate['identityFailures'] == [] and aggregate['referenceQualified'] is False
            and aggregate['allCompletedComparisonRostersReconstructedFromExactRaw'] is True
            and aggregate['sameExactRawControlsAuthAcrossAllContributions'] is True, 'Exact independent complete-coverage aggregate')
    receipts = []
    for scope, folder in RUNS.items():
        closed, execution, report = read(folder / 'COLLECTED.json'), read(folder / 'owned/execution.json'), read(folder / 'byte0-result.json')
        require(closed['scope'] == scope and closed.get('closedAt') and closed['execution'] == execution
                and closed['sourcePinsUnchanged'] is True and closed['protectedFilesUnchanged'] is True
                and execution['exitCode'] == 0 and execution['cleanupOwnedGroupEmpty'] is True
                and closed['all49Accepted'] is False, 'Closed251/252 negative receipts')
        require(report['inputBindings']['current']['sha256'] == CANDIDATE_SHA
                and report['terminalOutcome'] == 'FINITE_FOUR_LAYER_PORTAL_SUFFIX_NO_QUALIFIED_D12_NO_BOARD_INFEASIBILITY_CLAIM'
                and report['fixedHeadPreflight']['passed'] is True
                and len(report['beforeSearchAll48PhysicalReports']) == 48
                and all(r['passed'] is True for r in report['beforeSearchAll48PhysicalReports'])
                and len(report['beforeSearchCriticalViews']) == 2 and all(v['passed'] is True for v in report['beforeSearchCriticalViews'])
                and report['allSavedCarriersCurrentSceneQualified'] is False and report['all49Accepted'] is False
                and not (folder / 'byte0-result.candidate.json').exists(), 'Bounded diagnostic failure, not a new current candidate or board infeasibility proof')
        receipts.append((scope, folder, closed, execution, report))
    for name, pin in INITIAL.items():
        dest = SAVED / ('HISTORY_THROUGH250_' + name)
        require(not dest.exists(), 'Fresh through250 metadata history')
        with (SAVED / name).open('rb') as src, dest.open('xb') as dst:
            shutil.copyfileobj(src, dst, 1024 * 1024)
            os.fchmod(dst.fileno(), stat.S_IMODE((SAVED / name).stat().st_mode))
        require(digest(dest) == pin, 'Exact preserved through250 metadata')
    targets = {r['restorePath']: copy.deepcopy(r) for r in manifest['files']}
    bases = {r['restorePath']: copy.deepcopy(r) for r in manifest['baseDependencyRestoreFiles']}
    catalog = {}
    for folder in (ROOT / '.cloud-tools/ddr-four-layer-manual-2026-10-16', OLD):
        for row in read(folder / 'WORKSPACE_RESTORE_MANIFEST.json')['files']:
            catalog[row['restorePath']] = {'baseSavedDirectory': folder.relative_to(ROOT).as_posix(), **row}
    inputs = {}

    def save(p, name=None, force=False):
        p = Path(p)
        require(safe(p) and regular(p), 'Only regular public /tmp sources')
        before, data = p.stat(), metadata(p)
        inputs[str(p)] = data
        if str(p) in targets:
            require(data == {k: targets[str(p)][k] for k in data}, 'Existing restore target changed')
            return targets[str(p)]
        old = bases.get(str(p)) or catalog.get(str(p))
        if not force and old and data == {k: old[k] for k in data}:
            bases[str(p)] = copy.deepcopy(old)
            return old
        dest = SAVED / (name or p.name)
        require(dest.parent == SAVED, 'Flat saved source names')
        if dest.exists() and metadata(dest) != data:
            dest = dest.with_name(dest.stem + '__' + data['sha256'][:16] + dest.suffix)
        if not dest.exists():
            with p.open('rb') as src, dest.open('xb') as dst:
                shutil.copyfileobj(src, dst, 1024 * 1024)
                os.fchmod(dst.fileno(), data['mode'])
        after = p.stat()
        require((before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns) ==
                (after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns) and metadata(dest) == data, 'Stable source bytes/mode')
        row = {'savedPath': dest.name, 'restorePath': str(p), **data}
        targets[str(p)] = row
        bases.pop(str(p), None)
        return row

    sources, negative_runs = set(), []
    for scope, folder, closed, execution, report in receipts:
        label = 'D12_NEGATIVE' + str(scope) + '_NO_NEW_CURRENT_ROUTE'
        closure = save(folder / 'COLLECTED.json', label + '_COLLECTED.json', True)
        saved_report = save(folder / 'byte0-result.json', label + '_byte0-result.json', True)
        for filename in ('execution.json','child.log','memory.jsonl'):
            save(folder / 'owned' / filename, label + '_owned_' + filename, True)
        worker = Path(execution['command'][1])
        save(worker, force=True)
        sources.add(worker)
        for pin in report['inputBindings'].values():
            p = Path(pin['path'])
            if safe(p) and regular(p):
                require(digest(p) == pin['sha256'], 'Negative-run public dependency pin')
                save(p)
        negative_runs.append({'scope':scope,'closedAt':closed['closedAt'],'exitCode':0,
             'closure':closure,'report':saved_report,'terminalOutcome':report['terminalOutcome'],
             'all48BeforeSearchPassed':True,'fixedHeadPassed':True,'bothCriticalViewsBeforeSearchPassed':True,
             'newD12Qualified':False,'newCurrentCandidateEmitted':False,'boardInfeasibilityClaimed':False,
             'source248GeometryReplaced':False,'all49Accepted':False,'fabricationReady':False})
    for name in PINS:
        save(Path(name), force=True)
        if Path(name).suffix in ('.py','.ts','.tsx','.mjs') and Path(name) not in (ARCHIVE_SOURCE, SMOKE_SOURCE):
            sources.add(Path(name))
    save(Path(__file__), force=True)
    # Follow only explicit public dependencies of the two closed workers and
    # scoped audit/plot sources. No directory-wide later-routing collection.
    visited = set()
    for _ in range(2):
        following = set()
        for p in sorted(sources - visited):
            visited.add(p)
            for literal in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]", p.read_text()):
                q = Path(literal)
                if safe(q) and regular(q):
                    require('lowerbank' not in q.name.lower() and 'source2-' not in q.name.lower(), 'Later routing diagnostics belong in a new saved folder')
                    save(q)
                    if q.suffix in ('.py','.ts','.tsx','.mjs'):
                        following.add(q)
        sources |= following
    scoped_pours = {'scope':aggregate['scope'],'report':copy.deepcopy(targets[str(AUDIT)]),
        'aggregate':copy.deepcopy(targets[str(AGGREGATE)]),'auditorSource':copy.deepcopy(targets[str(AUDITOR)]),
        'combinerSource':copy.deepcopy(targets[str(COMBINER)]),'actualPourCount':14,'actualPourIds':POURS,
        'actualViaCount':229,'routedWireSegmentCount':957,'routedWireOwnerCount':48,
        'requiredForeignEdgeClearanceMm':.1016,'minimumForeignEdgeGapMm':aggregate['minimumForeignEdgeGapMm'],
        'literalForeignPourMarginClear':True,'referenceWireGeometryIncluded':False,'ownNetReentryQualified':False,
        'referenceContinuityQualified':False,'source236PassInherited':False,'all49Accepted':False,'fabricationReady':False}
    plot = {'source':copy.deepcopy(targets[str(PLOT_SOURCE)]),'rootRenderedAndViewed':True,
            'views':['top','inner1','inner2','bottom'],'pendingOwnerIds':['source_trace_26'],
            'files':[{'savedPath':name,**metadata(SAVED/name)} for name in PLOT_PINS],
            'all49Accepted':False,'fabricationReady':False}
    model.update({'literalPourClearanceQualified':True,'literalPourAuditPending':False,
                  'literalPourCoverageAggregate':scoped_pours,'reviewedFourLayerPlot':plot})
    model['editableSourceReplayEvidence'].update({'literalPourClearanceQualified':True,'literalPourAuditPending':False,
                                                'literalPourCoverageAggregate':copy.deepcopy(scoped_pours)})
    latest = {'scope':'FINAL_SOURCE248_PARTIAL48_VERIFIED_SCOPES_NOT_FULL_BOARD_QUALIFICATION',
        'resumeRoutingFromThisCheckpoint':True,'candidateSha256':CANDIDATE_SHA,
        'candidate':copy.deepcopy(targets[CANDIDATE]),'savedCandidate':targets[CANDIDATE]['savedPath'],
        'raw':copy.deepcopy(targets[RAW]),'controls':copy.deepcopy(targets[CONTROLS]),
        'plan':copy.deepcopy(targets[PLAN]),'routedOwners':48,'pendingOwnerIds':['source_trace_26'],
        'all35CoreControlsPassed':True,'freshCritical244BothViewsPassed':True,'focusedNative249Physical10Passed':True,
        'focusedNativeCheckCount':16,'other16NativeChecksNotRetested':True,'authenticated229ViaTrackPassed':True,
        'literalPourCoverageAggregate':copy.deepcopy(scoped_pours),'reviewedFourLayerPlot':plot,
        'source248TimingObservations':copy.deepcopy(model['source248TimingObservations']),
        'caMinimumPassingCount':3,'busSkewFailureCount':3,'fullTimingPassed':False,
        'source233TimingFallbackIsIndependent':True,'tiQualified':False,'referenceContinuityQualified':False,
        'electricalTimingQualified':False,'cadQualified':False,'defaultBoardPromoted':False,
        'all49Accepted':False,'fabricationReady':False}
    freeze = {'scope':'CLOSED252_PLUS_SOURCE248_ALL14_LITERAL_POURS_AND_REVIEWED_FOUR_LAYER_PLOT',
              'lastClosedRoutingScope':252,'sourceCoreScope':248,'candidateSha256':CANDIDATE_SHA,
              'aggregateSha256':PINS[str(AGGREGATE)],'laterRoutingWorkRequiresNewSavedDirectory':True,
              'archiveCreatedByCollector':False,'all49Accepted':False,'fabricationReady':False}
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    progress['updatedAt'] = manifest['updatedAt'] = now
    progress['scope'] = 'FROZEN Source24848 checkpoint at closed252 plus all14 scoped-pour pass and reviewed plot; independent Source23347 fallback'
    progress['latestClosedScopeIncluded'] = 252
    require(not any(r['scope'] in RUNS for r in progress['closedExperiments']), '251/252 append once')
    progress['closedExperiments'].extend(negative_runs)
    progress['separateModelMilestones'] = [model]
    progress['latestSourceVerifiedCheckpoint'] = latest
    progress['frozenCheckpoint'] = True
    progress['freezeBoundary'] = freeze
    progress['laterRoutingWorkRequiresNewSavedDirectory'] = True
    progress['through250MetadataPins'] = INITIAL
    progress['appendCollector'] = str(Path(__file__))
    manifest['separateModelMilestones'] = copy.deepcopy(progress['separateModelMilestones'])
    manifest['latestSourceVerifiedCheckpoint'] = copy.deepcopy(latest)
    manifest['frozenCheckpoint'] = True
    manifest['freezeBoundary'] = copy.deepcopy(freeze)
    manifest['files'] = sorted(targets.values(), key=lambda r:r['restorePath'])
    manifest['baseDependencyRestoreFiles'] = sorted(bases.values(), key=lambda r:r['restorePath'])
    progress['publicBaseRestoreDependencies'] = copy.deepcopy(manifest['baseDependencyRestoreFiles'])
    require(progress['primaryCandidate'] == manifest['primaryCandidate'] == primary
            and progress['literalPourCoverageAggregate'] == manifest['literalPourCoverageAggregate'] == fallback_pours,
            'Independent47/13CA fallback and Source23615-pour evidence must remain literal')
    for name, data in inputs.items():
        require(metadata(Path(name)) == data, 'Collected public input changed')
    for name, pin in PINS.items():
        require(digest(Path(name)) == pin, 'Pinned final input changed')
    for name, pin in PLOT_PINS.items():
        require(digest(SAVED/name) == pin, 'Root plot changed')
    verify_rows(SAVED,[r for r in prior_index['files'] if r['path'] not in INITIAL])
    verify_old()
    atomic_json('WORKSPACE_RESTORE_MANIFEST.json',manifest)
    readme = f"""Resume routing from latestSourceVerifiedCheckpoint in PROGRESS.json: actual
SOURCE248 has48/49 numeric-connected DDR routes. Only DDR_D12/source_trace_26
is pending. Its editable Source capture/full inverse, all35 Core248 controls,
critical244 both actual DQS1 views/all five APIs, focused native249 physical10
and other requested geometry checks, authenticated229-via track checks250, and
all14 literal-pour foreign-margin comparisons passed their stated scopes.

Current routing candidate after restoration:
{CANDIDATE}
SHA256 {CANDIDATE_SHA}
Saved payload: {targets[CANDIDATE]['savedPath']}
Actual raw Source248: {RAW}
Controls: {CONTROLS}
Exact plan: {PLAN}
These paths and mode/hash restore rows are in WORKSPACE_RESTORE_MANIFEST.json.
The named cap12 moves+X0.79 with exactly two pads/ports and two0.2mm Bottom
reference reroutes; its complete inverse and all held hardware remain explicit.

The all14-pour aggregate checks actual229 fullspan vias and957 routed-signal wire
segments against the exact fresh BREP regions, at0.1016mm foreign edge margin.
It excludes reference-wire geometry and does not prove reference continuity or
own-net reentry. No Source23615-pour result is inherited. Only focused16 native
checks were rerun; other16 are historical/not retested. All3 bus-skew checks FAIL;
this branch has only3/26 CA owners at the retained20.95mm minimum. Full timing,
TI/reference continuity, electrical readiness, CAD, default-board promotion,
all49 acceptance and fabrication readiness remain FALSE.

The primaryCandidate field intentionally remains the INDEPENDENT Source233 /
Source23647-route, CA13 timing fallback for archive-schema and dependency
continuity. It is not the preferred routing resume point. Its candidate and
Source23615-pour aggregate are unchanged and must not be combined with this48
branch's qualification. latestSourceVerifiedCheckpoint unambiguously names48.

Closed251/252 are negative bounded alternatives: all48 pre-search paths, fixed
head and critical views passed, but neither found a qualified D12 in that model.
Their proposed42 bodies, two proofs and independent static report are diagnostic
only and do not replace Source248. They do not prove board-wide infeasibility.
Core247's OBJ loader exception remains recorded; Core248's unchanged-behavior
diagnostic retry passed. No loader fix is asserted.

SOURCE248_CAP12_PARTIAL48_FOUR_LAYER_MILESTONE.png and.svg are the actual Root-
rendered/reviewed four-layer views with only D12 highlighted pending. Plot Source
and exact image hashes are indexed. The7 earlier TI analysis files retain their
reference-material gap witnesses and stricter original Source CA minimum; no
TI/reference/electrical claim is made by this snapshot.

Restore Source209, then Source228, then this Source248 archive/saved directory.
Exact prior archive/manifest dependencies are recorded; this collector does not
copy or rewrite either prior archive. The compatible saved-workspace verifier is:
python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post232-2026-10-16
Use its --restore flag only after prior dependencies are restored; it refuses
different existing bytes/modes. This collector ran no SDK/application import,
archive creation or commit, and did not execute that supplied restore helper.

FROZEN at closed252 + scoped all14-pour pass + reviewed plot. All later Source2,
lower-bank or other routing diagnostics MUST use a NEW saved directory. Exact
earlier metadata remains in HISTORY_THROUGH* files. Older Source209/post209
payloads/metadata and all independent fallback geometry remain frozen unchanged.
"""
    temp=SAVED/'.final252-README.tmp'
    with temp.open('x') as f:
        f.write(readme)
        os.fchmod(f.fileno(),0o600)
    os.replace(temp,SAVED/'README.md')
    excluded={'PROGRESS.json','WORKSPACE_RESTORE_MANIFEST.json','WORKSPACE_HASH_INDEX.json'}
    progress['artifacts']=[{'path':p.name,**metadata(p)} for p in sorted(SAVED.iterdir()) if regular(p) and p.name not in excluded]
    atomic_json('PROGRESS.json',progress)
    rows=[{'path':p.name,**metadata(p)} for p in sorted(SAVED.iterdir()) if regular(p) and p.name!='WORKSPACE_HASH_INDEX.json']
    atomic_json('WORKSPACE_HASH_INDEX.json',{'scope':freeze['scope'],'updatedAt':now,'files':rows,'selfExcluded':True,
                'frozenCheckpoint':True,'laterRoutingWorkRequiresNewSavedDirectory':True,'all49Accepted':False,'fabricationReady':False})
    verify_rows(SAVED,rows)
    for row in manifest['files']:
        expected={k:row[k] for k in ('bytes','sha256','mode')}
        require(metadata(SAVED/row['savedPath'])==expected and metadata(Path(row['restorePath']))==expected,'Exact restored payload/target bytes and modes')
    verify_old()
    print(json.dumps({'savedDirectory':str(SAVED),'frozenCheckpoint':True,'latestClosedScope':252,
        'savedFiles':len(list(SAVED.iterdir())),'indexedFiles':len(rows),'restoreTargets':len(manifest['files']),
        'baseDependencies':len(manifest['baseDependencyRestoreFiles']),'latestSourceVerifiedOwners':48,
        'pendingOwnerIds':['source_trace_26'],'source248All14ScopedPourPass':True,'independentTimingFallbackOwners':47,
        'all49Accepted':False,'fabricationReady':False,'archiveCreated':False,
        'metadataHashes':{name:digest(SAVED/name) for name in INITIAL}},indent=2))


if __name__=='__main__':
    main()
