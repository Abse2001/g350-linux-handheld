// Root only after source/peer/receipt/SDK checks. Never edits circuit JSON.
import assert from 'node:assert/strict'
import fs from 'node:fs'
import {createHash} from 'node:crypto'
import * as checks from '/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js'
import {g350DdrPhysicalChecks} from '/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v10-ca-top-bytes-bottom-prefork-successor-next/source/scripts/lib/g350-ddr-physical-checks.mjs'
import {proveSharedPackageLoops} from '/workspace/g350-linux-handheld/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/prove-shared-package-loops.mjs'
import {proveFreshStrict18Core} from './fresh-owner-factory.mjs'
import {checkG350ProvedViaBranchManufacturingClearance} from './fresh-via-branch-manufacturing-clearance.mjs'
const BOARD='/workspace/g350-linux-handheld',ROOT=import.meta.dir
const digest=b=>createHash('sha256').update(b).digest('hex')
const [manifestPath,manifestSha,authorityPath,authoritySha,output,...extra]=process.argv.slice(2)
assert.equal(process.env.G350_STRICT18_FRESH_NATIVE_APPROVED,'1');assert.equal(process.versions.bun,'1.3.14')
assert(manifestPath&&manifestSha&&authorityPath&&authoritySha&&output&&!extra.length&&!fs.existsSync(output))
const load=(path,sha)=>{const raw=fs.readFileSync(path);if(sha)assert.equal(digest(raw),sha);return JSON.parse(raw)}
try {
const manifest=load(manifestPath,manifestSha),authority=load(authorityPath,authoritySha)
assert.equal(authority.authorizedByRoot,true);assert.equal(authority.scope,manifest.scope);assert.equal(authority.packetSha256,manifestSha)
assert.equal(authority.rootFullGuardReadPassed,true);assert.equal(authority.noConcurrentRootWorker,true)
assert.equal(authority.sourceManifestSha256,manifest.sourceManifestSha256)
assert.equal(authority.coreSourceManifestSha256,'6c4bf7ee94347c8cb21307b22d6ef231e136589a77752f0702f34fa8d3ab2c4d')
for(const row of [...manifest.files,...manifest.externalFiles]){const p=fs.lstatSync(row.path);assert(p.isFile()&&!p.isSymbolicLink());const b=fs.readFileSync(row.path);assert.equal(b.length,row.bytes);assert.equal(p.mode&0o777,row.mode);assert.equal(digest(b),row.sha256)}
assert.equal(digest(fs.readFileSync(BOARD+'/node_modules/@tscircuit/checks/dist/index.js')),'1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc')
const artifacts=manifest.actualFreshArtifacts
assert.deepEqual(authority.freshArtifacts,artifacts)
const fresh=load(artifacts.actualCorePath,artifacts.actualCoreSha256),controls=load(artifacts.coreControlsPath,artifacts.coreControlsSha256)
assert.equal(controls.rawCorePath,artifacts.actualCorePath);assert.equal(controls.rawCoreSha256,artifacts.actualCoreSha256);assert.equal(controls.freshCoreControlPassed,true)
const old=load(BOARD+'/.cloud-tools/ddr-package101-core-qualification-source-next/run-core/fresh-core.circuit.json','ed33a0a335b1fbf0da9adcdeacaa954b655c3c4964c600efb6ef3c72aef4040e')
const golden=load(BOARD+'/.cloud-tools/ddr-hs-all32-capture-first-type4096-root-successor-next/run-core/fresh-core.circuit.json','384628cd46c2b5cb5b32a94d442651eda3c604c8acf19bd85fc68b728f529769')
const proposal=load(BOARD+'/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/grouped-proposal.json','fffd02510548c16606eff4f6489da9860e45af82aca1cbc8e053a1201bc148a5')
const signal=load(BOARD+'/.cloud-tools/ddr-package101-signal96-joint-native-sourceonly-next/signal-source-proposal.json','7430bd5d5201af6e53dde9d07dc38395811adb4e6fc923949d4b4a772c8d304a')
const clock=load(BOARD+'/.cloud-tools/ddr-package101-signal96-clock-v11-source-contract-next/clock-fidelity-source-proposal.json','ad1ed113e5c35b81b94839808d8e22c8c00aafb2f9f57889e4a3d8a1794bb973')
const integration=load(BOARD+'/.cloud-tools/ddr-strict18-manual-source-integration-sourceonly-next/strict18-source-proposal.json','02c2957a1e514cc55211efe0b3bd53647a4e9d4aee4d6eb5da6852515342b4e4')
const originalProof=proveSharedPackageLoops({proposal,goldenCore:golden,freshCore:old})
const signature=JSON.stringify(fresh),proof=proveFreshStrict18Core({freshCore:fresh,controls,oldCore:old,oldPackageProof:originalProof,signalProposal:signal,clockProposal:clock,strict18Proposal:integration})
const names=[...g350DdrPhysicalChecks,'checkPadPadClearance','checkTracesAreContiguous','checkDanglingTraces','checkPcbTracesOutOfBoard','checkPcbCopperOverKeepout','checkPcbComponentOverlap','checkPcbComponentsOutOfBoard'];assert.equal(names.length,17)
const results={},timing={}
for(const name of names){assert.equal(typeof checks[name],'function');results[name]=checks[name](fresh)}
results.checkG350ProvedViaBranchManufacturingClearance=checkG350ProvedViaBranchManufacturingClearance(fresh,proof)
// Full fresh circuit, unchanged native APIs; preserve every incomplete global finding.
timing.checkPcbBusLengthSkew=checks.checkPcbBusLengthSkew(fresh)
timing.checkPcbRoutingConstraints=checks.checkPcbRoutingConstraints(fresh)
const expectedPairs=[['DDR_DQS0_PAIR',['source_trace_15','source_trace_16']],['DDR_DQS1_PAIR',['source_trace_28','source_trace_27']],['DDR_CK_PAIR',['source_trace_33','source_trace_34']]]
const actualPairBuses=expectedPairs.map(([name,ids])=>{const rows=fresh.filter(r=>r.type==='source_bus'&&r.name===name);assert.equal(rows.length,1);assert.deepEqual(rows[0].source_trace_ids,ids);assert.equal(rows[0].max_length_skew,.127);return rows[0]})
const pairIds=new Set(actualPairBuses.map(b=>b.source_bus_id)),actualNativePairFindings=Object.values(timing).flat().filter(r=>pairIds.has(r.source_bus_id))
assert.equal(JSON.stringify(fresh),signature,'Native functions must not mutate actual raw Core')
const physicalErrors=Object.values(results).flat().length
const report={scope:'ACTUAL_FRESH_STRICT18_CORE279_NATIVE18_PHYSICAL_AND_NUMERIC_OWNER_GRAPH_QUALIFICATION',packetSha256:manifestSha,sourceManifestSha256:manifest.sourceManifestSha256,actualCorePath:artifacts.actualCorePath,actualCoreSha256:artifacts.actualCoreSha256,actualCoreControlsSha256:artifacts.coreControlsSha256,checkCount:18,counts:Object.fromEntries(Object.entries(results).map(([name,issues])=>[name,issues.length])),results,physicalErrors,unchangedNativeTimingFunctions:timing,actualPairBuses,actualNativePairFindings,actualOwnershipProof:proof,physicalCpuRamConnectedCarrierCount:proof.carriers.filter(c=>c.actualSourceOwnedPhysicalGraph.physicallyConnected).length,expectedMissingOriginalSignalCount:31,all165ReferencePathsPreserved:true,all129ReferenceBarrelsPreserved:true,all96SignalBarrelsAndTopStubsPreserved:true,all49OriginalLogicalNumericRequestsPreserved:true,rawCircuitUnmodified:true,sourceNetFabricationPerformed:false,circuitJsonGeometryOrIdentitiesEdited:false,globalSameNetManufacturingExemption:false,onlyAuthenticRam25Hs8PadAndStripContactRegistered:true,originalAll3CouplingApisAgainstActualGeometryRequiredSeparately:true,noCoreRenderPerformed:true,noRoutingPerformed:true,noCliOrCadPerformed:true,full49RoutesUnfinished:true,fullCohortTimingPassed:false,electricalTimingQualified:false,referenceQualified:false,complete18Accepted:false,accepted49:false,fabricationReady:false}
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600})
assert.equal(physicalErrors,0,'Actual full Native18 physical/manufacturing findings retained before assertion')
assert.equal(actualNativePairFindings.length,0,'Actual native findings from all3 original differential buses retained')
assert.equal(report.physicalCpuRamConnectedCarrierCount,18)
console.log(JSON.stringify({actualNative18PhysicalErrors:physicalErrors,actualAll3PairNativeFindings:actualNativePairFindings.length,physicalCpuRamConnectedCarrierCount:18,expectedMissingOriginalSignalCount:31,accepted49:false,fabricationReady:false}))

} catch(error) {
 if(!fs.existsSync(output))fs.writeFileSync(output,JSON.stringify({scope:'UNRESOLVED_STRICT18_NATIVE_PRECONDITION_OR_OWNERSHIP',passed:false,failure:String(error),rawCircuitUnmodified:true,accepted49:false,referenceQualified:false,electricalTimingQualified:false,fabricationReady:false},null,2)+'\n',{flag:'wx',mode:0o600})
 throw error
}
