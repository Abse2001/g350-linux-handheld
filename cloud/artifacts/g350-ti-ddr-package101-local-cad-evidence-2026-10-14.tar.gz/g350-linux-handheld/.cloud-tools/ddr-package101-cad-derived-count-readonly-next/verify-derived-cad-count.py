"""Pure readonly derived-count gate; no CLI, Docker, wx or pcbnew imports.

Copied data-reader functions are unchanged from the actual passing inspector.
Actual native graph acceptance comes only from the hash-bound collected report.
"""
import argparse,collections,hashlib,json,math
from pathlib import Path
LAYER_NAMES={'top':'F.Cu','inner1':'In1.Cu','inner2':'In2.Cu','bottom':'B.Cu'}
MM_SERIALIZATION_TOLERANCE=1e-5
def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_regular(path):
    require(path.is_file() and not path.is_symlink(), 'Concrete regular input required: ' + str(path))
    data = path.read_bytes()
    require(len(data) <= 32 * 1024 * 1024, 'Finite board/source/report input required')
    return data


def near(a, b):
    return math.isfinite(a) and math.isfinite(b) and abs(a - b) <= MM_SERIALIZATION_TOLERANCE


def at(a, b):
    return near(a[0], b[0]) and near(a[1], b[1])


def transform(x, y):
    return [100 + x, 100 - y]


def one(values, message):
    require(len(values) == 1, message + ' (matches=' + str(len(values)) + ')')
    return values[0]




class Node:
    def __init__(self, start):
        self.start, self.end, self.items = start, None, []

    @property
    def head(self):
        return self.items[0] if self.items and isinstance(self.items[0], str) else None


def parse_sexpressions(data):
    """Byte spans, quoted strings and escapes; never evaluate KiCad text."""
    roots, stack, index = [], [], 0
    while index < len(data):
        char = data[index]
        if char in b' \t\r\n':
            index += 1
            continue
        if char == ord('('):
            node = Node(index)
            (stack[-1].items if stack else roots).append(node)
            stack.append(node)
            index += 1
            continue
        if char == ord(')'):
            require(stack, 'Unbalanced closing board expression')
            stack.pop().end = index + 1
            index += 1
            continue
        require(stack, 'Unexpected token outside board expression')
        if char == ord('"'):
            index += 1
            token = bytearray()
            while index < len(data) and data[index] != ord('"'):
                if data[index] == ord('\\'):
                    index += 1
                    require(index < len(data), 'Truncated quoted board escape')
                token.append(data[index])
                index += 1
            require(index < len(data), 'Unterminated quoted board string')
            index += 1
            stack[-1].items.append(bytes(token).decode('utf-8'))
        else:
            start = index
            while index < len(data) and data[index] not in b'() \t\r\n':
                index += 1
            stack[-1].items.append(data[start:index].decode('utf-8'))
    require(not stack and len(roots) == 1 and roots[0].head == 'kicad_pcb', 'Exactly one complete KiCad PCB root required')
    return roots[0]


def children(node, kind):
    return [item for item in node.items if isinstance(item, Node) and item.head == kind]


def values(node, kind):
    item = one(children(node, kind), 'Unique ' + kind + ' field required')
    require(all(isinstance(value, str) for value in item.items), 'Scalar field required: ' + kind)
    return item.items[1:]




def map_raw_copper(root, lookup, native):
    net_names = {int(node.items[1]): node.items[2] for node in children(root, 'net')}
    raw_vias, raw_segments = children(root, 'via'), children(root, 'segment')
    require(len(raw_vias) == 129, 'Exactly129 raw physical via records required')
    via_uuids, segment_uuids, used = {}, {}, set()
    for ident, source_via in lookup['pcb_via'].items():
        target = transform(source_via['x'], source_via['y'])
        node = one([item for item in raw_vias if at([float(v) for v in values(item, 'at')[:2]], target)], 'Unique source/raw physical via required')
        ident_uuid = one(values(node, 'uuid'), 'Raw via UUID required')
        require(ident_uuid not in used, 'Raw physical via UUIDs must be unique')
        used.add(ident_uuid)
        require(values(node, 'layers') == ['F.Cu', 'B.Cu'], 'Raw physical through-via span differs')
        require(near(float(values(node, 'size')[0]), source_via['outer_diameter']) and near(float(values(node, 'drill')[0]), source_via['hole_diameter']), 'Raw physical via dimensions differ')
        net = int(values(node, 'net')[0])
        require(net != 0 and net_names[net] == lookup['source_net'][source_via['source_net_id']]['name'], 'Raw physical via source rail differs')
        via_uuids[ident] = ident_uuid
    branches = {item['pcb_trace_id']: item for item in native['retainedHsTerminalLoops'] + native['packageTerminalLoops']}
    matched_nodes = set()
    for ident, trace in lookup['pcb_trace'].items():
        net_name = lookup['source_net'][branches[ident]['source_net_id']]['name']
        matches = []
        for a, b in zip(trace['route'], trace['route'][1:]):
            if a['x'] == b['x'] and a['y'] == b['y']:
                continue
            start, end = transform(a['x'], a['y']), transform(b['x'], b['y'])
            def matching(node):
                if node.start in matched_nodes:
                    return False
                first = [float(value) for value in values(node, 'start')]
                second = [float(value) for value in values(node, 'end')]
                net = int(values(node, 'net')[0])
                return values(node, 'layer') == [LAYER_NAMES[a['layer']]] and near(float(values(node, 'width')[0]), a.get('width', b.get('width'))) and net != 0 and net_names[net] == net_name and ((at(first, start) and at(second, end)) or (at(first, end) and at(second, start)))
            node = one([item for item in raw_segments if matching(item)], 'Unique source/raw exact segment required: ' + ident)
            ident_uuid = one(values(node, 'uuid'), 'Raw segment UUID required')
            require(ident_uuid not in used, 'Raw via/segment UUIDs must be unique')
            used.add(ident_uuid)
            matched_nodes.add(node.start)
            matches.append(ident_uuid)
        segment_uuids[ident] = matches
    require(len(matched_nodes) == len(raw_segments), 'Extra raw segment cannot be silently retained as a qualified source centerline')
    return {'viaUuids': via_uuids, 'segmentUuids': segment_uuids, 'netNames': net_names}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    require(not args.output.exists() and not args.output.is_symlink(),'Fresh exclusive derived-count report required')
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'PREPARED-manifest.json').read_bytes())
    paths={name:Path(manifest[name+'Path']) for name in ('acceptedCore','acceptedNative','actualCadReport','rawBoard','cleanedBoard')}
    before={name:digest(read_regular(path)) for name,path in paths.items()}
    require(all(before[name]==manifest[name+'Sha256'] for name in paths),'Every collected actual source/raw/native file hash must hold')
    source=json.loads(read_regular(paths['acceptedCore']))
    native=json.loads(read_regular(paths['acceptedNative']))
    cad=json.loads(read_regular(paths['actualCadReport']))
    require(native['physicalErrors']==0 and native['checkCount']==18 and native['sourceSha256']==before['acceptedCore'],'Accepted original local165 native proof must hold')
    # Preserve every original outer-runner predicate. The sole superseded
    # assumption is an expected168 literal; the count is derived below.
    expected={'passed':True,'sourceSha256':before['acceptedCore'],'rawBoardSha256':before['rawBoard'],'cleanedBoardSha256':before['cleanedBoard'],'packageConnectedCount':101,'hsConnectedCount':64,'physicalViaCount':129,'sourceContactsVerified':1161,'realFootprints':280,'planesExcludedForLocalConnectivity':True,'sourceMappedCopperLands':1165,'sourceMappedPlatedLands':4,'onlySourceMappedEmptyPlaceholdersRemoved':True,'placeholderCount':129,'allOtherRawBytesHeld':True,'boardSaved':False,'refillRun':False,'routerRun':False,'pcbnewBuildVersion':'10.0.6+dfsg-1'}
    for field,value in expected.items():require(type(cad.get(field))==type(value) and cad[field]==value,'Original required actual CAD predicate differs: '+field)
    require(cad['inputHashesBefore']==cad['inputHashesAfter'],'Actual inspector must have preserved all three original inputs')
    require(cad['inputHashesBefore'][str(paths['acceptedCore'])]==before['acceptedCore'] and cad['inputHashesBefore'][str(paths['acceptedNative'])]==before['acceptedNative'] and cad['inputHashesBefore'][str(paths['rawBoard'])]==before['rawBoard'],'Actual inspector hashes must bind these exact source/receipt/raw files')
    lookup={kind:{row[kind+'_id']:row for row in source if row['type']==kind} for kind in ('source_net','source_trace','pcb_trace','pcb_via')}
    require(len(lookup['pcb_trace'])==165 and len(lookup['pcb_via'])==129,'Original local physical record counts differ')
    expected_branches=native['retainedHsTerminalLoops']+native['packageTerminalLoops']
    scopes={row['pcb_trace_id']:row['scope'] for row in expected_branches}
    require(len(scopes)==165,'Each source trace must retain one actual proved branch scope')
    segments=[];by_scope=collections.Counter();split_traces=[]
    for trace_id,trace in lookup['pcb_trace'].items():
        count=0
        for i,(a,b) in enumerate(zip(trace['route'],trace['route'][1:])):
            require(a['route_type']==b['route_type']=='wire' and a['layer']==b['layer'],'Only exact source straight same-layer wire pairs qualify')
            length=math.hypot(b['x']-a['x'],b['y']-a['y'])
            require(math.isfinite(length) and length>1e-8,'A zero or microscopic source pair is a separate manufacturing concern; never waive it as a count fix')
            # KiCad serializes positions to nanometres. Refuse a pair whose
            # distinct source endpoints collapse to one native coordinate.
            one_nm_a=tuple(round(v*1e6) for v in transform(a['x'],a['y']))
            one_nm_b=tuple(round(v*1e6) for v in transform(b['x'],b['y']))
            require(one_nm_a!=one_nm_b,'Source pair collapses at native nanometre serialization')
            segments.append({'pcb_trace_id':trace_id,'source_trace_id':trace['source_trace_id'],'scope':scopes[trace_id],'pairIndex':i,'layer':a['layer'],'widthMm':a['width'],'lengthMm':length,'start':{'x':a['x'],'y':a['y']},'end':{'x':b['x'],'y':b['y']}})
            by_scope[scopes[trace_id]]+=1;count+=1
        if count>1:split_traces.append({'pcb_trace_id':trace_id,'source_trace_id':trace['source_trace_id'],'sourceTraceName':lookup['source_trace'][trace['source_trace_id']].get('name'),'scope':scopes[trace_id],'segments':count})
    raw_bytes=read_regular(paths['rawBoard']);raw_root=parse_sexpressions(raw_bytes)
    cleaned_bytes=read_regular(paths['cleanedBoard']);cleaned_root=parse_sexpressions(cleaned_bytes)
    raw_zones=children(raw_root,'zone');cleaned_zones=children(cleaned_root,'zone')
    require([raw_bytes[node.start:node.end] for node in raw_zones]==[cleaned_bytes[node.start:node.end] for node in cleaned_zones],'Every actual physical zone expression must remain byte exact')
    raw_mapping=map_raw_copper(raw_root,lookup,native)
    source_count=len(segments);raw_count=len(children(raw_root,'segment'))
    native_branches=cad['branches'];actual_by_trace={row['pcb_trace_id']:row for row in native_branches}
    require(len(native_branches)==len(actual_by_trace)==165 and set(actual_by_trace)==set(lookup['pcb_trace']),'Every actual native branch must map exactly one original source trace')
    native_uuids=[]
    for expected_branch in expected_branches:
        branch=actual_by_trace[expected_branch['pcb_trace_id']]
        for field in ('scope','pcb_port_id','source_port_id','pcb_trace_id','source_trace_id','pcb_via_id'):require(branch[field]==expected_branch[field],'Actual source/raw/native numeric owner identity differs')
        require(branch['zoneFreePhysicalConnected'] is True and branch['nativeViaUuid']==raw_mapping['viaUuids'][branch['pcb_via_id']],'Actual zone-free numeric-to-owned-via graph must hold')
        require(sorted(branch['nativeSegmentUuids'])==sorted(raw_mapping['segmentUuids'][branch['pcb_trace_id']]),'Actual source/raw/native segment UUID ownership differs')
        native_uuids.extend(branch['nativeSegmentUuids'])
    require(len(native_uuids)==len(set(native_uuids)),'Actual native segment UUIDs cannot be duplicated or shared across unrelated branches')
    require(source_count==raw_count==len(native_uuids)==cad['sourceMappedSegmentCount'],'Exact derived source/raw/native segment counts must agree')
    require(by_scope=={'RETAINED_ACTUAL_HS_BOTTOM':65,'NEW_PACKAGE_TOP':104},'Preserved65-HS plus104-package derivation must hold')
    require(any(row['pcb_trace_id']=='pcb_trace_1' and row['source_trace_id']=='source_trace_933' and row['sourceTraceName']=='TI_RAM7_GROUND_BYPASS' and row['segments']==2 for row in split_traces),'Preserved RAM7 two-segment dogleg explains the previous count assumption')
    require(cad['hs8ZoneFreePhysicalJunction']['physicallyConnected'] is True and cad['zoneCountDuringConnectivityProof']==0,'The approved HS8 junction must remain actual zone-free connected')
    require(cad['originalZonesRetainedInCleanedCopy']==len(raw_zones)==len(cleaned_zones) and cad['privateZoneFreeCopyRemoved'] is True,'Report must match actual raw/cleaned zone counts and private proof-copy lifecycle')
    after={name:digest(read_regular(path)) for name,path in paths.items()}
    require(after==before,'Readonly derivation changed bound evidence')
    report={'scope':'READONLY_DERIVED_SOURCE_RAW_NATIVE_CAD_SEGMENT_COUNT_ACCEPTANCE','passed':True,'sourceSha256':before['acceptedCore'],'actualCadReportSha256':before['actualCadReport'],'rawBoardSha256':before['rawBoard'],'cleanedBoardSha256':before['cleanedBoard'],'derivedSourceSegmentCount':source_count,'rawSegmentCount':raw_count,'rawPhysicalZoneCount':len(raw_zones),'cleanedPhysicalZoneCount':len(cleaned_zones),'everyRawZoneExpressionByteExact':True,'actualNativeOwnedSegmentCount':len(native_uuids),'segmentsByScope':dict(by_scope),'multiSegmentSourceTraces':split_traces,'minimumSourceSegmentLengthMm':min(row['lengthMm'] for row in segments),'zeroMicroscopicOrNativeCollapsedPairs':0,'segmentDerivation':segments,'allOriginalCadPredicatesHeldExceptSupersededLiteral168':True,'previousCountLiteralWasMetadataAssumption':True,'actual169PhysicalSegmentsAlreadyCheckedByOriginalInspector':True,'acceptedOriginal101Package64Hs129Via1161Port1165LandCadEvidenceReused':True,'sourceAndEvidenceFilesHeld':True,'newCliExports':0,'newCadImports':0,'newDockerCalls':0,'newCoreBuilds':0,'filledReferencesQualified':False,'customPolygonFullCopperGeometryQualified':False,'accepted49':False,'fabricationReady':False}
    with args.output.open('x') as output:json.dump(report,output,indent=2);output.write('\n')
    args.output.chmod(0o600)
    print(json.dumps({'passed':True,'derivedSourceRawNativeSegments':source_count,'zeroMicroscopicOrNativeCollapsedPairs':0,'newCadCalls':0,'accepted49':False}))


if __name__=='__main__':main()


