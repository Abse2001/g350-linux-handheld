/** Proposed Root-only one direct pinned Core render; unexecuted source. */
import assert from "node:assert/strict"
import { readFileSync, writeFileSync, existsSync } from "node:fs"
import { createHash } from "node:crypto"
import { buildStrict18ManualSource, registerStrict18InnerPorts } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-strict18-manual-source-integration-sourceonly-next/strict18-source-overlay"
import proposal from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-signal96-clock-v11-source-contract-next/clock-fidelity-source-proposal.json"
import signalProposal from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-signal96-joint-native-sourceonly-next/signal-source-proposal.json"
import integrationProposal from "/workspace/g350-linux-handheld/.cloud-tools/ddr-strict18-manual-source-integration-sourceonly-next/strict18-source-proposal.json"
const [output, reportPath, ...extra] = process.argv.slice(2)
assert.equal(process.env.G350_STRICT18_CORE_ROOT_GUARDED, "1")
assert.ok(output && reportPath && extra.length === 0 && !existsSync(output) && !existsSync(reportPath)); assert.equal(process.versions.bun, "1.3.14")
const digest = (p: string) => createHash("sha256").update(readFileSync(p)).digest("hex")
assert.equal(digest("/workspace/g350-linux-handheld/node_modules/@tscircuit/core/dist/index.js"), "97b8a4eb484630c3ce2bfc2d68588801484d85adf94785d8849a1d91c4404905")
assert.equal(digest("/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js"), "1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc")
const baselinePath = "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-core-qualification-source-next/run-core/fresh-core.circuit.json"
assert.equal(digest(baselinePath), "ed33a0a335b1fbf0da9adcdeacaa954b655c3c4964c600efb6ef3c72aef4040e")
const baseline = JSON.parse(readFileSync(baselinePath, "utf8")) as Array<Record<string, any>>
const { Circuit } = await import("/workspace/g350-linux-handheld/node_modules/@tscircuit/core/dist/index.js")
const circuit = new Circuit(); circuit.schematicDisabled = true; circuit.pcbRoutingDisabled = true
const source = buildStrict18ManualSource()
circuit.add(source.element as any)
const matches = registerStrict18InnerPorts(circuit)
await circuit.renderUntilSettled()
const actualRuntimeCore = circuit.getCircuitJson() as Array<Record<string, any>>, raw = `${JSON.stringify(actualRuntimeCore, null, 2)}\n`
// Preserve the entire raw Core before any physical/source assertion.
writeFileSync(output, raw, { flag: "wx", mode: 0o600 })
// Compare the exact preserved serializer output, matching the parsed baseline.
// Runtime objects retain optional undefined-valued schema keys that saved JSON
// omits. Parsing the bytes removes no actual serialized geometry or ownership.
const core = JSON.parse(raw) as Array<Record<string, any>>
const checks: Array<{ label: string; passed: boolean; actual: unknown; expected?: unknown }> = []
const count = (type: string) => core.filter(r => r.type === type).length
for (const [type, expected] of [["source_component",280],["pcb_smtpad",1161],["pcb_via",225],["pcb_hole",2],["pcb_plated_hole",4],["pcb_trace",279],["source_net",98],["source_bus",8],["pcb_port",1639],["source_port",1639]] as const)
  checks.push({ label: type, passed: count(type) === expected, actual: count(type), expected })
const canonical = (value: any): string => Array.isArray(value) ? `[${value.map(canonical).join(",")}]`
  : value && typeof value === "object" ? `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(",")}}`
  : JSON.stringify(value) ?? "undefined"
const shape = (point: Record<string, any>) => Object.fromEntries(Object.entries(point)
  .filter(([key]) => key !== "start_pcb_port_id" && key !== "end_pcb_port_id"))
// IDs may shift when original clock paths render earlier. Match reference
// copper by unchanged logical owner and complete route geometry, once each.
const remainingReferenceTraces = core.filter(r => r.type === "pcb_trace").slice()
const referenceProjection = baseline.filter(r => r.type === "pcb_trace").map(old => {
  const signature = canonical(old.route.map(shape))
  const index = remainingReferenceTraces.findIndex(now => now.source_trace_id === old.source_trace_id && canonical(now.route.map(shape)) === signature)
  const now = index < 0 ? null : remainingReferenceTraces.splice(index, 1)[0]
  return { originalPcbTraceId: old.pcb_trace_id, actualPcbTraceId: now?.pcb_trace_id ?? null, originalSourceTraceId: old.source_trace_id, exactRouteGeometryHeld: now !== null }
})
checks.push({ label: "all165-original-reference-copper-exact-bijection", passed: referenceProjection.length === 165 && referenceProjection.every(r => r.exactRouteGeometryHeld), actual: referenceProjection.filter(r => r.exactRouteGeometryHeld).length, expected: 165 })
const originalLogical49 = baseline.filter(r => r.type === "source_trace" && /^source_trace_\d+$/.test(r.source_trace_id) && Number(r.source_trace_id.slice(13)) < 49)
const sourceLogical = (row: Record<string, any>) => Object.fromEntries(Object.entries(row).filter(([key]) => key !== "subcircuit_connectivity_map_key"))
checks.push({ label: "all49-original-numeric-logical-traces-and-constraints-held", passed: originalLogical49.length === 49 && originalLogical49.every(old => {
  const now = core.find(r => r.type === "source_trace" && r.source_trace_id === old.source_trace_id)
  return now && canonical(sourceLogical(now)) === canonical(sourceLogical(old))
}), actual: originalLogical49.length, expected: 49 })
// Bus and DifferentialPair use different public rendering phases. Generated
// Source bus IDs can change; bind actual rows bijectively by original unique
// name and every constraint/member field. Never rewrite generated identities.
const remainingBuses = core.filter(r=>r.type==="source_bus").slice()
const original8BusProjection = baseline.filter(r=>r.type==="source_bus").map(old=>{
  const semantic = (r:Record<string,any>)=>Object.fromEntries(Object.entries(r).filter(([key])=>key!=="source_bus_id"))
  const index=remainingBuses.findIndex(now=>now.name===old.name&&canonical(semantic(now))===canonical(semantic(old)))
  const now=index<0?null:remainingBuses.splice(index,1)[0]
  return {originalSourceBusId:old.source_bus_id,actualSourceBusId:now?.source_bus_id??null,originalName:old.name,
    actualName:now?.name??null,exactNameOrderedMembershipAndAllConstraintsHeld:now!==null}
})
const busesHeld=remainingBuses.length===0&&original8BusProjection.length===8&&original8BusProjection.every(r=>r.exactNameOrderedMembershipAndAllConstraintsHeld)
checks.push({label:"all8-original-bus-names-ordered-members-and-every-constraint-held",passed:busesHeld,
  actual:{exactBuses:original8BusProjection.filter(r=>r.exactNameOrderedMembershipAndAllConstraintsHeld).length,unmatched:remainingBuses.length},expected:{exactBuses:8,unmatched:0}})
const namedNetProjection = baseline.filter(r => r.type === "source_net").map(old => {
  const now = core.find(r => r.type === "source_net" && r.source_net_id === old.source_net_id)
  return { sourceNetId: old.source_net_id, originalName: old.name, actualName: now?.name ?? null,
    originalNamedNetDefinitionHeld: !!now && canonical(sourceLogical(now)) === canonical(sourceLogical(old)) }
})
checks.push({ label: "all98-original-source-net-identities-names-and-definitions-held", passed: namedNetProjection.length === 98 && namedNetProjection.every(r=>r.originalNamedNetDefinitionHeld), actual: namedNetProjection.filter(r=>r.originalNamedNetDefinitionHeld).length, expected: 98 })
const physicalHoleProjection = ["pcb_hole", "pcb_plated_hole"].flatMap(type => {
  const remaining = core.filter(r => r.type === type).slice()
  const physicalShape = (r: Record<string, any>) => Object.fromEntries(Object.entries(r)
    .filter(([key])=>key!==`${type}_id` && key!=="pcb_port_id"))
  const result = baseline.filter(r=>r.type===type).map(old=>{
    const index = remaining.findIndex(now=>canonical(physicalShape(now))===canonical(physicalShape(old)))
    const now = index<0 ? null : remaining.splice(index,1)[0]
    return { type, originalId: old[`${type}_id`], actualId: now?.[`${type}_id`] ?? null, exactPhysicalGeometryAndComponentHeld: now!==null }
  })
  checks.push({ label: `${type}-original-physical-shape-bijection-no-extra-holes`, passed: remaining.length===0 && result.every(r=>r.exactPhysicalGeometryAndComponentHeld), actual: { exactMatches:result.filter(r=>r.exactPhysicalGeometryAndComponentHeld).length, unmatched:remaining.length }, expected: { exactMatches:type==="pcb_hole"?2:4, unmatched:0 } })
  return result
})
const nearXY = (a: Record<string, any>, b: Record<string, any>) => Math.hypot(a.x-b.x,a.y-b.y) < 1e-9
const viaShape = (row: Record<string, any>) => ({ x: row.x, y: row.y, hole_diameter: row.hole_diameter,
  outer_diameter: row.outer_diameter, layers: row.layers, from_layer: row.from_layer, to_layer: row.to_layer,
  tented_on_top: row.tented_on_top, tented_on_bottom: row.tented_on_bottom })
const remainingVias = core.filter(r => r.type === "pcb_via").slice()
const referenceViaProjection = baseline.filter(r => r.type === "pcb_via").map(old => {
  const index = remainingVias.findIndex(now => canonical(viaShape(now)) === canonical(viaShape(old)))
  const now = index < 0 ? null : remainingVias.splice(index, 1)[0]
  return { originalViaId: old.pcb_via_id, actualViaId: now?.pcb_via_id ?? null, exactPhysicalSpanPositionAndDimensionsHeld: now !== null }
})
checks.push({ label: "all129-original-reference-barrels-exact-bijection", passed: referenceViaProjection.length === 129 && referenceViaProjection.every(r => r.exactPhysicalSpanPositionAndDimensionsHeld), actual: referenceViaProjection.filter(r => r.exactPhysicalSpanPositionAndDimensionsHeld).length, expected: 129 })
const signalViaProjection = signalProposal.owners.map(owner => {
  const index = remainingVias.findIndex(now => nearXY(now,owner.viaXY) && now.hole_diameter === .254 && now.outer_diameter === .4572
    && canonical(now.layers) === canonical(owner.viaLayers) && now.from_layer === "top" && now.to_layer === "bottom")
  const now = index < 0 ? null : remainingVias.splice(index, 1)[0]
  return { sourceViaName: owner.viaName, actualViaId: now?.pcb_via_id ?? null, completePhysicalBarrelHeld: now !== null }
})
checks.push({ label: "all96-signal-barrels-once-and-no-other-holes", passed: signalViaProjection.length === 96 && signalViaProjection.every(r=>r.completePhysicalBarrelHeld) && remainingVias.length === 0,
  actual: { signalBarrels: signalViaProjection.filter(r=>r.completePhysicalBarrelHeld).length, unmatchedHoles: remainingVias.length }, expected: { signalBarrels: 96, unmatchedHoles: 0 } })
const signalTopProjection = signalProposal.owners.map(owner => {
  const candidates = core.filter(r => r.type === "pcb_trace" && r.route.length === 2
    && r.route.every((p: Record<string, any>) => p.route_type === "wire" && p.layer === "top" && p.width === .1016)
    && ((nearXY(r.route[0], owner.topStub[0]) && nearXY(r.route[1], owner.topStub[1]))
      || (nearXY(r.route[1], owner.topStub[0]) && nearXY(r.route[0], owner.topStub[1]))))
  const isDirectOriginal = proposal.clockCarriers.some(c => c.originalSourceTraceId === owner.originalSourceTraceId)
    || integrationProposal.newOriginalSignalChanges.some(c => c.originalSourceTraceId === owner.originalSourceTraceId)
  const owningSource = candidates[0] && core.find(r => r.type === "source_trace" && r.source_trace_id === candidates[0].source_trace_id)
  const sourceOwnershipHeld = isDirectOriginal ? candidates[0]?.source_trace_id === owner.originalSourceTraceId
    : !!owningSource && owningSource.name === owner.traceName && owningSource.connected_source_port_ids.includes(owner.originalSourcePortId)
  return { originalSourceTraceId: owner.originalSourceTraceId, originalNumericSourcePortId: owner.originalSourcePortId,
    actualPcbTraceIds: candidates.map(r => r.pcb_trace_id), actualDirectSourceTraceId: candidates[0]?.source_trace_id ?? null,
    exactlyOneTopStub: candidates.length === 1, sourceOwnershipHeld }
})
checks.push({ label: "all96-signal-top-stubs-single-render-and-numeric-owner", passed: signalTopProjection.length === 96 && signalTopProjection.every(r => r.exactlyOneTopStub && r.sourceOwnershipHeld), actual: signalTopProjection.filter(r => r.exactlyOneTopStub && r.sourceOwnershipHeld).length, expected: 96 })
const clocks = proposal.clockCarriers.map(clock => {
  const source = core.find(r => r.type === "source_trace" && r.source_trace_id === clock.originalSourceTraceId)!
  const traces = core.filter(r => r.type === "pcb_trace" && r.source_trace_id === clock.originalSourceTraceId)
  const inputPins = [clock.cpu.originalSourcePortId, clock.ram.originalSourcePortId]
  checks.push({ label: `${clock.originalSourceTraceId}-original-two-numeric-ports`, passed: !!source && JSON.stringify(source.connected_source_port_ids) === JSON.stringify(inputPins), actual: source?.connected_source_port_ids, expected: inputPins })
  checks.push({ label: `${clock.originalSourceTraceId}-three-physical-paths`, passed: traces.length === 3, actual: traces.length, expected: 3 })
  const inner = traces.filter(t => t.route.every((p: Record<string, any>) => p.route_type === "wire" && p.layer === "inner1"))
  const expectedRoute = clock.expectedInner1PhysicalRoute
  const exactLayerWidthCount = inner.length === 1 && inner[0].route.length === expectedRoute.length
    && inner[0].route.every((p: Record<string, any>, i: number) => p.route_type === "wire" && p.layer === "inner1" && p.width === .1016
      && Math.hypot(p.x-expectedRoute[i].x,p.y-expectedRoute[i].y) < 1e-9)
  const maximumCoordinateDelta = inner.length === 1 && inner[0].route.length === expectedRoute.length
    ? Math.max(...inner[0].route.map((p: Record<string, any>, i: number) => Math.hypot(p.x-expectedRoute[i].x,p.y-expectedRoute[i].y))) : null
  checks.push({ label: `${clock.originalSourceTraceId}-actual-inner1-carrier`, passed: exactLayerWidthCount,
    actual: { carrierCount: inner.length, maximumCoordinateDelta }, expected: { carrierCount: 1, maximumCoordinateDeltaLessThan: 1e-9 },
    })
  const planar = traces.reduce((sum, t) => sum + t.route.slice(1).reduce((length: number, p: Record<string, any>, i: number) => length + Math.hypot(p.x-t.route[i].x,p.y-t.route[i].y), 0), 0)
  checks.push({ label: `${clock.originalSourceTraceId}-full-clock-planar-with-top-stubs`, passed: Math.abs(planar-clock.originalV11WholePlanarLength) < 1e-9, actual: planar, expected: clock.originalV11WholePlanarLength })
  const layerPorts = [clock.cpu, clock.ram].map((owner, endpoint) => {
    const vias = core.filter(r => r.type === "pcb_via" && nearXY(r,owner.viaXY) && r.outer_diameter === .4572 && r.hole_diameter === .254
      && JSON.stringify(r.layers) === JSON.stringify(["top","inner1","inner2","bottom"]) && r.from_layer === "top" && r.to_layer === "bottom")
    const ports = vias.length === 1 ? core.filter(r => r.type === "pcb_port" && vias[0].pcb_port_ids?.includes(r.pcb_port_id)
      && JSON.stringify(r.layers) === JSON.stringify(["inner1"]) && nearXY(r,owner.viaXY)) : []
    const actualInner = inner.length === 1 ? inner[0].route : []
    const referencedPortId = endpoint === 0 ? actualInner[0]?.start_pcb_port_id : actualInner.at(-1)?.end_pcb_port_id
    const sourcePort = ports.length === 1 ? core.find(r => r.type === "source_port" && r.source_port_id === ports[0].source_port_id) : null
    const passed = vias.length === 1 && ports.length === 1 && referencedPortId === ports[0].pcb_port_id && sourcePort?.name === "inner1"
    checks.push({ label: `${clock.originalSourceTraceId}-${endpoint===0?"cpu":"ram"}-actual-owned-inner1-anchor`, passed,
      actual: { viaCount: vias.length, innerPortCount: ports.length, referencedPortId, sourcePortName: sourcePort?.name },
      expected: { viaCount: 1, innerPortCount: 1, sourcePortName: "inner1" } })
    return { viaName: owner.viaName, actualViaId: vias[0]?.pcb_via_id, actualInner1PcbPortId: ports[0]?.pcb_port_id, sourcePort, passed }
  })
  const routeViaPrimitives = traces.flatMap(t=>t.route).filter(p=>p.route_type === "via").length
  checks.push({ label: `${clock.originalSourceTraceId}-no-new-route-via-primitives`, passed: routeViaPrimitives === 0, actual: routeViaPrimitives, expected: 0 })
  return { originalSourceTraceId: clock.originalSourceTraceId, source, pcbTraceIds: traces.map(t=>t.pcb_trace_id), wholePlanarLength: planar, routeViaPrimitives,
    physicalExistingFullSpanBarrels: layerPorts.map(p=>p.actualViaId), actualLayerPortAnchors: layerPorts,
    physicalLayerTransitions: [{ ...clock.cpu.viaXY, fromLayer: "top", toLayer: "inner1" }, { ...clock.ram.viaXY, fromLayer: "inner1", toLayer: "top" }],
    nativeHistoricalViaContributionAutomaticallyRepresentedInTheseRoutes: false }
})
const suppressedLocalClockSourceIds = source.manualPairSourceFork.suppressedLocalClockTraceNames.map(name => {
  const local = core.filter(r=>r.type==="source_trace" && r.name===name)
  const emitted = local.length===1 ? core.filter(r=>r.type==="pcb_trace" && r.source_trace_id===local[0].source_trace_id) : []
  checks.push({ label: `${name}-source-declaration-retained-with-no-duplicate-copper`, passed: local.length===1 && emitted.length===0,
    actual: { sourceRows:local.length, pcbPaths:emitted.length }, expected:{sourceRows:1,pcbPaths:0} })
  return {name, actualLocalSourceTraceId:local[0]?.source_trace_id??null, physicalTraceIds:emitted.map(r=>r.pcb_trace_id)}
})
checks.push({ label: "authoritative49-original-all3-pair-gap-skew-input-held", passed:
  digest(source.manualPairSourceFork.complete49AuthoritativeRoutingInputPath)===source.manualPairSourceFork.complete49AuthoritativeRoutingInputSha256
  && source.manualPairSourceFork.originalDifferentialPairDeclarations.length===3
  && source.manualPairSourceFork.originalDifferentialPairDeclarations.every(p=>p.lengthTolerance===.127&&p.traceGap===.12),
  actual:source.manualPairSourceFork.originalDifferentialPairDeclarations, expected:"all3 original pairs .127mm skew/.12mm gap, ed97 input unchanged" })
// Fresh source names/physical owners are derived from this exact real Core.
// Never copy old alias or PCBtrace IDs: all18 direct originals render earlier.
checks.push({ label: "actual28-genuine-inner-port-matches", passed: matches.unchangedQualifiedClockRegistrations.length === 4 && matches.newStrict18Registrations.length === 24,
  actual: { clock: matches.unchangedQualifiedClockRegistrations.length, new: matches.newStrict18Registrations.length }, expected: { clock: 4, new: 24 } })
const newDirectOriginalSignals = integrationProposal.newOriginalSignalChanges.map(signal => {
  const logical = core.filter(r => r.type === "source_trace" && r.source_trace_id === signal.originalSourceTraceId)
  const traces = core.filter(r => r.type === "pcb_trace" && r.source_trace_id === signal.originalSourceTraceId)
  const expectedPins = [signal.cpu.originalSourcePortId, signal.ram.originalSourcePortId]
  const carrier = traces.filter(t => t.route.length === signal.expectedCarrierPhysicalRoute.length
    && t.route.every((p: Record<string,any>, i:number) => p.route_type === "wire" && p.layer === signal.carrierLayer && p.width === .1016
      && nearXY(p, signal.expectedCarrierPhysicalRoute[i])))
  const expectedWholePlanar = [signal.cpu.topStub, signal.expectedCarrierPhysicalRoute, signal.ram.topStub]
    .reduce((sum, route) => sum + route.slice(1).reduce((length, p, i) => length + Math.hypot(p.x-route[i].x,p.y-route[i].y),0),0)
  const actualWholePlanar = traces.reduce((sum, t) => sum + t.route.slice(1).reduce((length:number,p:Record<string,any>,i:number) => length + Math.hypot(p.x-t.route[i].x,p.y-t.route[i].y),0),0)
  checks.push({ label: `${signal.originalSourceTraceId}-actual-original-three-path-owner-and-planar-geometry`, passed:
    logical.length === 1 && logical[0].name === signal.originalLogicalTraceName
    && canonical(logical[0].connected_source_port_ids) === canonical(expectedPins) && traces.length === 3 && carrier.length === 1
    && Math.abs(actualWholePlanar-expectedWholePlanar) < 1e-8 && traces.every(t => t.route.every((p:Record<string,any>) => p.route_type === "wire")),
    actual: { logicalRows: logical.length, pcbPaths: traces.length, carrierMatches: carrier.length, actualWholePlanar },
    expected: { logicalRows:1, pcbPaths:3, carrierMatches:1, expectedWholePlanar } })
  const layerAnchors = [signal.cpu,signal.ram].map((owner, endpoint) => {
    const via = core.filter(r => r.type === "pcb_via" && nearXY(r,owner.viaXY) && r.outer_diameter === .4572 && r.hole_diameter === .254)
    const ports = via.length === 1 ? core.filter(r => r.type === "pcb_port" && via[0].pcb_port_ids?.includes(r.pcb_port_id)
      && canonical(r.layers) === canonical([signal.carrierLayer]) && nearXY(r,owner.viaXY)) : []
    const sourcePort = ports.length === 1 ? core.find(r => r.type === "source_port" && r.source_port_id === ports[0].source_port_id) : null
    const sourceVia = sourcePort ? core.find(r => r.type === "source_manually_placed_via" && r.source_manually_placed_via_id === sourcePort.source_component_id) : null
    const actualCarrier = carrier.length === 1 ? carrier[0].route : []
    const referencedPortId = endpoint === 0 ? actualCarrier[0]?.start_pcb_port_id : actualCarrier.at(-1)?.end_pcb_port_id
    const placeholder = ports.length === 1 ? core.filter(r => r.type === "pcb_component" && r.pcb_component_id === ports[0].pcb_component_id) : []
    const aliases = via.length === 1 && Array.isArray(via[0].pcb_port_ids) ? via[0].pcb_port_ids.map((id:string) => {
      const actualAlias = core.filter(r => r.type === "pcb_port" && r.pcb_port_id === id)
      const actualSource = actualAlias.length === 1 ? core.filter(r => r.type === "source_port" && r.source_port_id === actualAlias[0].source_port_id) : []
      const actualComponent = actualAlias.length === 1 ? core.filter(r => r.type === "pcb_component" && r.pcb_component_id === actualAlias[0].pcb_component_id) : []
      const sameAuthenticOwner = !!sourceVia && actualAlias.length === 1 && actualSource.length === 1 && actualComponent.length === 1
        && actualSource[0].source_component_id === sourceVia.source_manually_placed_via_id
        && actualComponent[0].source_component_id === sourceVia.source_manually_placed_via_id
        && actualAlias[0].pcb_component_id === ports[0]?.pcb_component_id
        && nearXY(actualAlias[0],via[0]) && nearXY(actualComponent[0].center,via[0])
        && actualComponent[0].width === via[0].outer_diameter && actualComponent[0].height === via[0].outer_diameter
        && actualComponent[0].layer === "top" && actualComponent[0].rotation === 0
        && actualAlias[0].layers.length === 1 && via[0].layers.includes(actualAlias[0].layers[0])
        && actualSource[0].name === actualAlias[0].layers[0]
      return { actualPcbPortId:id, actualSourcePortId:actualSource[0]?.source_port_id??null,
        actualPcbComponentId:actualComponent[0]?.pcb_component_id??null,
        actualSourceViaOwner:actualSource[0]?.source_component_id??null, sameAuthenticOwner }
    }) : []
    const expectedAliasCount = signal.carrierLayer === "inner1" || signal.carrierLayer === "inner2" ? 3 : 2
    const placeholderAndEveryAliasOwned = via.length === 1 && !!sourceVia && placeholder.length === 1
      && placeholder[0].source_component_id === sourceVia.source_manually_placed_via_id
      && nearXY(placeholder[0].center,via[0]) && placeholder[0].width === via[0].outer_diameter && placeholder[0].height === via[0].outer_diameter
      && aliases.length === expectedAliasCount && new Set(aliases.map((a:Record<string,any>)=>a.actualPcbPortId)).size === expectedAliasCount
      && aliases.every((a:Record<string,any>)=>a.sameAuthenticOwner)
      && !core.some(r=>r.type === "source_component" && r.source_component_id === sourceVia.source_manually_placed_via_id)
    const passed = via.length === 1 && ports.length === 1 && sourcePort?.name === signal.carrierLayer && !!sourceVia
      && referencedPortId === ports[0].pcb_port_id && placeholderAndEveryAliasOwned
    checks.push({ label: `${signal.originalSourceTraceId}-${endpoint===0?"cpu":"ram"}-actual-source-owned-${signal.carrierLayer}-anchor`, passed,
      actual: { viaCount:via.length, portCount:ports.length, referencedPortId, sourcePortName:sourcePort?.name, actualSourceViaOwner:sourceVia?.source_manually_placed_via_id,
        actualPlaceholderPcbComponentId:placeholder[0]?.pcb_component_id??null, actualBarrelAliasCount:aliases.length, placeholderAndEveryAliasOwned, aliases },
      expected: { viaCount:1, portCount:1, sourcePortName:signal.carrierLayer } })
    return { viaName:owner.viaName, actualViaId:via[0]?.pcb_via_id??null, actualLayerPcbPortId:ports[0]?.pcb_port_id??null,
      actualLayerSourcePortId:sourcePort?.source_port_id??null, actualSourceViaOwner:sourceVia?.source_manually_placed_via_id??null,
      actualPlaceholderPcbComponentId:placeholder[0]?.pcb_component_id??null, actualBarrelAliases:aliases, placeholderAndEveryAliasOwned, passed }
  })
  return { originalSourceTraceId:signal.originalSourceTraceId, carrierLayer:signal.carrierLayer,
    actualDirectPcbTraceIds:traces.map(t=>t.pcb_trace_id), actualCarrierPcbTraceId:carrier[0]?.pcb_trace_id??null,
    actualOriginalNumericSourcePortIds:logical[0]?.connected_source_port_ids??null, expectedWholePlanar, actualWholePlanar, layerAnchors }
})
const suppressedNewDirectSourceLocalIds = integrationProposal.newOriginalSignalChanges.flatMap(signal => signal.newLocalRenderSuppressions).map(name => {
  const local = core.filter(r => r.type === "source_trace" && r.name === name)
  const emitted = local.length === 1 ? core.filter(r=>r.type === "pcb_trace" && r.source_trace_id === local[0].source_trace_id) : []
  checks.push({ label: `${name}-actual-logical-branch-retained-without-duplicate-copper`, passed:local.length===1&&emitted.length===0,
    actual:{ sourceRows:local.length, pcbPaths:emitted.length }, expected:{ sourceRows:1, pcbPaths:0 } })
  return { name, actualLocalSourceTraceId:local[0]?.source_trace_id??null, actualPcbTraceIds:emitted.map(r=>r.pcb_trace_id) }
})
checks.push({ label:"exact-authorized-all4-input-and-inverse-of-only-allowed-layer-fields", passed:
  digest(integrationProposal.authorizedAllFourLayerFork.routingInputPath) === integrationProposal.authorizedAllFourLayerFork.routingInputSha256
  && integrationProposal.authorizedAllFourLayerFork.sourceBusAllowedLayerChanges.length === 4
  && integrationProposal.authorizedAllFourLayerFork.sourceBusAllowedLayerChanges.every(change=>canonical(change.newAllowedLayers)===canonical(["top","inner1","inner2","bottom"])),
  actual:integrationProposal.authorizedAllFourLayerFork.sourceBusAllowedLayerChanges, expected:"four explicit Source allowed-layer arrays; originalSource full-tree inverse in actual prior capture" })
const report = { scope: "one-fresh-pinned-core-manual-static18-source-control",
  exactPersistedSerializerBytesCompared: true, runtimeOptionalUndefinedFieldsNotFalselyComparedToAbsentSavedJsonFields: true,
  suppressedLocalClockSourceIds, suppressedNewDirectSourceLocalIds, newDirectOriginalSignals, explicitAuthorizedBusAllowedLayerFork: integrationProposal.authorizedAllFourLayerFork,
  original8BusProjection, actualGeneratedSourceBusIdsRetained:true, manualPairSourceFork:source.manualPairSourceFork,
  automaticCoreSrjDifferentialDiscoveryEquivalent:false, automaticCoreSrjForThisForkMustNotBeUsed:true,
  originalCouplingAPIsStillRequiredAgainstActualPhysicalGeometry:true, rawCorePath: output, rawCoreSha256: createHash("sha256").update(raw).digest("hex"),
  sourcePortMatchesActuallyRegistered: { unchangedQualifiedClockRegistrations: matches.unchangedQualifiedClockRegistrations, newStrict18Registrations: matches.newStrict18Registrations }, schematicDisabled: true, pcbRoutingDisabled: true, checks, clocks,
  originalReference165GeometryProjection: referenceProjection, original96TopStubGeometryProjection: signalTopProjection,
  original129ReferenceBarrelProjection: referenceViaProjection, original96SignalBarrelProjection: signalViaProjection,
  original2Npth4PlatedHolePhysicalProjection: physicalHoleProjection, original98NamedNetProjection: namedNetProjection,
  freshCoreControlPassed: checks.every(c=>c.passed), originalFullClockLengthsAssignedDirectSourceIds: clocks.every(c => c.pcbTraceIds.length === 3),
  expectedOnly18OriginalSignalsConnected: true, expectedMissingOriginalSignalCount: 31, complete18Accepted: false,
  nativeManufacturingExplicitlyExecuted: false, nativeClockBusFunctionsExplicitlyExecuted: false, freshCadExecuted: false,
  nativeOriginalClockBusAggregationStillRequired: true, nativeNumericCpuRamConnectivityStillRequired: true,
  physicalThroughBarrelsMustNotBeInferredFromRouteViaPrimitiveCount: true,
  fullCohortTimingQualified: false, electricalDelayModelQualified: false, referenceQualified: false, accepted49: false, fabricationReady: false }
writeFileSync(reportPath, `${JSON.stringify(report,null,2)}\n`, { flag: "wx", mode: 0o600 })
assert.equal(report.freshCoreControlPassed, true, "Raw Core and failing controls retained before assertion")
console.log(JSON.stringify({ scope: report.scope, freshCoreControlPassed: true, output, reportPath, accepted49: false }))
