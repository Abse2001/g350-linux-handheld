/** Primitive-only controller observer. Never retains a replay instance or bank value. */
type CacheRow = {
  id: number
  begins: number
  gets: number
  hits: number
  puts: number
  admissions: number
  clears: number
  contextReady: boolean
  entryCount: number
  peakEntryCount: number
  storedEntryBytes: number
  peakStoredEntryBytes: number
  currentNames: string[]
  admittedNames: string[]
  hitNames: string[]
  allExpectedPresent: boolean
  everAllExpectedPresent: boolean
  peakExpectedPresentCount: number
}
type Prototype = Record<"begin" | "get" | "put" | "clear", Function>
const LIMITS = { cacheRows: 32, knownNames: 49, serializedBytes: 96 * 1024 }

export function installPositiveBankStats(
  prototype: Prototype,
  expectedOrdinaryNames: readonly string[],
  allKnownNames: readonly string[],
  publish?: (snapshot: unknown) => void,
) {
  const knownNames = [...new Set(allKnownNames)]
  const expectedNames = [...new Set(expectedOrdinaryNames)]
  if (knownNames.length > LIMITS.knownNames || knownNames.some(name => typeof name !== "string" || name.length > 80) || expectedNames.some(name => !knownNames.includes(name))) throw Error("Only original bounded connection names are observable")
  const known = new Set(knownNames), expected = new Set(expectedNames)
  const identities = new WeakMap<object, number>()
  const rows: CacheRow[] = []
  let instanceCount = 0, observationErrors = 0, droppedInstances = 0, snapshotOverflows = 0, restored = false
  const totals = { begins: 0, gets: 0, hits: 0, puts: 0, admissions: 0, clears: 0 }
  const originals = new Map<string, PropertyDescriptor>()
  const replacements = new Map<string, Function>()
  const data = (object: unknown, key: string) => object !== null && (typeof object === "object" || typeof object === "function") ? Object.getOwnPropertyDescriptor(object, key)?.value : undefined
  const addName = (names: string[], name: unknown) => { if (typeof name === "string" && known.has(name) && !names.includes(name)) names.push(name) }
  function rowFor(receiver: object): CacheRow | undefined {
    let id = identities.get(receiver)
    if (id === undefined) { id = ++instanceCount; identities.set(receiver, id); if (id > LIMITS.cacheRows) { droppedInstances++; return undefined }; rows.push({ id, begins: 0, gets: 0, hits: 0, puts: 0, admissions: 0, clears: 0, contextReady: false, entryCount: 0, peakEntryCount: 0, storedEntryBytes: 0, peakStoredEntryBytes: 0, currentNames: [], admittedNames: [], hitNames: [], allExpectedPresent: false, everAllExpectedPresent: false, peakExpectedPresentCount: 0 }) }
    return rows[id - 1]
  }
  function project(receiver: object, row: CacheRow) {
    const entries = data(receiver, "entries"), bytes = data(receiver, "bytes")
    if (!(entries instanceof Map) || !Number.isFinite(bytes) || bytes < 0) throw Error("Expected original compiled replay primitive fields")
    const entryCount = Reflect.get(Map.prototype, "size", entries) as number
    if (entryCount > 64) throw Error("Original replay entry bound exceeded")
    const names: string[] = []
    for (const name of Map.prototype.keys.call(entries)) {
      if (typeof name !== "string" || !known.has(name)) throw Error("Unknown original connection owner in replay")
      names.push(name)
    }
    row.contextReady = data(receiver, "context") !== undefined
    row.entryCount = entryCount
    row.peakEntryCount = Math.max(row.peakEntryCount, entryCount)
    row.storedEntryBytes = bytes
    row.peakStoredEntryBytes = Math.max(row.peakStoredEntryBytes, bytes)
    row.currentNames = names
    const count = names.filter(name => expected.has(name)).length
    row.peakExpectedPresentCount = Math.max(row.peakExpectedPresentCount, count)
    row.allExpectedPresent = expectedNames.length > 0 && count === expectedNames.length
    row.everAllExpectedPresent ||= row.allExpectedPresent
  }
  function summary() {
    return { diagnosticOnly: true, accepted49: false, expectedOrdinaryCount: expectedNames.length, knownSignalCount: knownNames.length, limits: { ...LIMITS }, instanceCount, droppedInstances, observationErrors, snapshotOverflows, totals: { ...totals }, allExpectedEverCachedTogether: rows.some(row => row.everAllExpectedPresent), maxExpectedPresentCount: Math.max(0, ...rows.map(row => row.peakExpectedPresentCount)), retainedInstances: false, retainedBankGeometry: false, weakRefUsed: false, storedEntryBytesExcludeContext: true }
  }
  function snapshot() {
    const value = { ...summary(), expectedOrdinaryNames: [...expectedNames], rowsOmittedForByteBound: false, rows: rows.map(row => ({ ...row, currentNames: [...row.currentNames], admittedNames: [...row.admittedNames], hitNames: [...row.hitNames] })) }
    if (new TextEncoder().encode(JSON.stringify(value)).byteLength > LIMITS.serializedBytes) {
      snapshotOverflows++
      return { ...summary(), expectedOrdinaryNames: [...expectedNames], rowsOmittedForByteBound: true, rows: [] }
    }
    return value
  }
  // Validate the complete surface before replacing any descriptor.
  for (const method of ["begin", "get", "put", "clear"] as const) {
    const descriptor = Object.getOwnPropertyDescriptor(prototype, method)
    if (!descriptor || typeof descriptor.value !== "function" || !descriptor.writable || !descriptor.configurable) throw Error("Original writable replay method required")
    originals.set(method, descriptor)
  }
  for (const method of ["begin", "get", "put", "clear"] as const) {
    const descriptor = originals.get(method)!
    const original = descriptor.value
    const replacement = function (this: object, ...args: unknown[]) {
      // Original exceptions propagate unchanged; observations run only after a real return.
      const result = Reflect.apply(original, this, args)
      try {
        totals[method === "begin" ? "begins" : method === "get" ? "gets" : method === "put" ? "puts" : "clears"]++
        const row = rowFor(this)
        if (row) row[method === "begin" ? "begins" : method === "get" ? "gets" : method === "put" ? "puts" : "clears"]++
        if (method === "get" && result !== undefined) { totals.hits++; if (row) { row.hits++; addName(row.hitNames, args[0]) } }
        if (method === "put" && result === true) { totals.admissions++; if (row) { row.admissions++; addName(row.admittedNames, args[0]) } }
        if (row) project(this, row)
        if (publish && (method === "begin" || method === "clear" || (method === "put" && result === true) || (method === "get" && result !== undefined))) publish(snapshot())
      } catch { observationErrors++ }
      return result
    }
    replacements.set(method, replacement)
    Object.defineProperty(prototype, method, { ...descriptor, value: replacement })
  }
  return {
    snapshot,
    summary,
    restore() {
      if (restored) throw Error("Observer restored once")
      for (const [method, descriptor] of originals) {
        if (data(prototype, method) !== replacements.get(method)) throw Error("Replay method changed before restoration")
        Object.defineProperty(prototype, method, descriptor)
      }
      restored = true
    },
  }
}
