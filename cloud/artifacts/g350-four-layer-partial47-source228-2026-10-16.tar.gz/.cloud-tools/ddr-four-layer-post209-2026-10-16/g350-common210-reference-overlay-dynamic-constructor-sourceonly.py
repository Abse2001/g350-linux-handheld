#!/usr/bin/env python3
"""SOURCE ONLY. Author did not execute this file or any geometry/SDK code.

Root runs this stdlib-only data constructor. Original49 rules are immutable;
derived ordinary43 windows intersect them with the exact freshly qualified RAM-cycle rails.
The sole reference exception is the explicitly pinned POWER185/via120 and D7
RAM slot exchange. This builder accepts its exact fresh46 preflight result only.
Availability describes existing working copper and does not create new ports.
"""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path

ANCHOR = Path('/tmp/g350-current210-power-slot-root-planning216.json')
ANCHOR_SHA = 'e41302a52daa8174a7a13d8e9019d3769cd39dbb87818649c56b9ff7c15b5b3e'
PREFLIGHT_WORKER = Path('/tmp/g350-current210-power-reference-slot-all46-preflight-v3-sourceonly.ts')
PREFLIGHT_WORKER_SHA = '2760053bb367a1bbcf201ae044bdf1384090b3137a7f407b424af8a1de695884'
PARENT = Path('/tmp/g350-ramcycle-d1-d7-root-20261016-run210/byte0-result.candidate.json')
PARENT_SHA = '67635f33c309d547adb5e1e925b5c3cd1445a68c7ac3c8a9598ca75f1921b453'
SCREEN = Path('/tmp/g350-current210-power120-ddr32-slot-exchange-screen-report.json')
SCREEN_SHA = '4249510c37b0f329304beca16f6fc2051f93b38675b81faeb0ad3a079897aa27'
BUILDER = Path('/tmp/g350-current210-power120-ddr32-reference-overlay-planning-builder-sourceonly.py')
BUILDER_SHA = '9c066ea0327d80872da4cba7c2fb7d0e2c0b1946493ccb9f643c65568b5bf037'
LAYERS = ['top', 'inner1', 'inner2', 'bottom']
CRITICAL = {'source_trace_' + str(i) for i in (15, 16, 27, 28, 33, 34)}
ALL = {'source_trace_' + str(i) for i in range(49)}
EPS = 1e-8


def require(value, message):
    if not value:
        raise ValueError(message)


def owner(trace):
    return trace.get('connection_name', trace.get('source_trace_id'))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def read_pinned(path, expected):
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    require(digest == expected, 'SHA256 mismatch: ' + str(path))
    packet = json.loads(data)
    canonical(packet)  # reject nonfinite JSON numbers before any arithmetic
    return packet, digest


def near(a, b):
    return math.hypot(a['x'] - b['x'], a['y'] - b['y']) <= EPS


def planar(trace):
    total = 0.0
    route = trace['route']
    for a, b in zip(route, route[1:]):
        if a.get('route_type') == b.get('route_type') == 'wire' and a['layer'] == b['layer']:
            total += math.hypot(a['x'] - b['x'], a['y'] - b['y'])
    require(math.isfinite(total), 'Nonfinite planar length')
    return total


def transitions(packet):
    """Both actual flat branch ledgers and nested native-endpoint ledgers."""
    branch_edges, connection_edges, handoffs = {}, {}, {}
    ledgers = packet.get('releasedWorkingBranchMaterial', [])
    require(isinstance(ledgers, list), 'Released branch ledger must be an array')
    for entry in ledgers:
        name = entry.get('owner', entry.get('connectionName'))
        if 'originalBranch' in entry and 'replacementBranch' in entry:
            before, after = entry['originalBranch'], entry['replacementBranch']
            require(owner(before) == owner(after) == name, 'Branch ledger owner mismatch')
            branch_edges.setdefault(before['pcb_trace_id'], []).append((before, after))
        for branch in entry.get('branches', []):
            before, after = branch['before'], branch['after']
            require(owner(before) == owner(after) == name, 'Nested branch ledger owner mismatch')
            branch_edges.setdefault(before['pcb_trace_id'], []).append((before, after))
        change = entry.get('connection')
        if isinstance(change, dict) and 'before' in change and 'after' in change:
            require(change['before']['name'] == change['after']['name'] == name,
                    'Connection ledger owner mismatch')
            connection_edges.setdefault(name, []).append((change['before'], change['after']))
        if 'oldHandoff' in entry and 'newHandoff' in entry:
            handoffs.setdefault(name, []).append((entry['oldHandoff'], entry['newHandoff']))
    return branch_edges, connection_edges, handoffs


def reachable(before, after, edges):
    goal, seen, stack = canonical(after), set(), [canonical(before)]
    graph = {}
    for a, b in edges:
        graph.setdefault(canonical(a), []).append(canonical(b))
    while stack:
        value = stack.pop()
        if value == goal:
            return True
        if value in seen:
            continue
        seen.add(value)
        stack.extend(graph.get(value, []))
    return False


def endpoint_proof(point, branches):
    native_top, fullspan, matched = False, False, []
    for branch in branches:
        route = branch['route']
        if not route or route[-1].get('route_type') != 'wire' or not near(route[-1], point):
            continue
        matched.append(branch['pcb_trace_id'])
        if point['layer'] == 'top' and all(p.get('route_type') == 'wire' and p['layer'] == 'top' for p in route):
            native_top = True
        if any(p.get('route_type') == 'via' and near(p, point) and p.get('layers') == LAYERS
               and p.get('via_diameter') == .4572 and p.get('via_hole_diameter') == .254 for p in route):
            fullspan = True
    require(matched, 'No owned working branch supports active handoff ' + str(point))
    allowed = list(LAYERS) if fullspan else (['top'] if native_top else [])
    require(point['layer'] in allowed, 'Active layer lacks actual branch material')
    return {'point': copy.deepcopy(point), 'branchIds': matched,
            'nativeTopBranch': native_top, 'explicitFullspanBarrel': fullspan,
            'availableLayers': allowed,
            'TopChoiceRequiresExplicitOwnBranchRetarget': fullspan and not native_top,
            'topChoiceQualifiedBeforeActualEndpointSelection': False,
            'handoffCoordinatesAndIdentityUnchanged': True}


def build(packet, anchor, source_path, source_sha):
    require(hashlib.sha256(PREFLIGHT_WORKER.read_bytes()).hexdigest() == PREFLIGHT_WORKER_SHA,
            'Exact reviewed reference-overlay fresh46 preflight Source required')
    require(hashlib.sha256(BUILDER.read_bytes()).hexdigest() == BUILDER_SHA,
            'Exact reviewed named-reference planning builder required')
    parent, _ = read_pinned(PARENT, PARENT_SHA)
    screen, _ = read_pinned(SCREEN, SCREEN_SHA)
    descriptor = anchor['plannedPowerReferenceSlotExchange']
    require(anchor['planningOnly'] is True and anchor['freshSourceCoreDerived'] is False
            and descriptor['parentPacketSha256'] == PARENT_SHA
            and descriptor['pureScreenSha256'] == SCREEN_SHA,
            'Exact210 named reference-overlay planning anchor')
    for key in ('referenceTraceDelta', 'referenceViaObstacleDelta', 'ddrWorkingBranchDelta',
                'ddrConnectionDelta', 'physicalDrillPlacementOverride', 'authenticNumericAliasOrigin'):
        require(descriptor[key] == screen[key], 'Exact independently pinned screened descriptor: ' + key)
    expected = copy.deepcopy(parent['full49FanoutInput'])
    declarations = (('referenceTraceDelta', 'traces', 83, 'pcb_trace_id', 'pcb_trace_185'),
                    ('referenceViaObstacleDelta', 'obstacles', 1289, 'obstacleId', 'pcb_via_120'),
                    ('ddrWorkingBranchDelta', 'traces', 238, 'pcb_trace_id', 'local_dogbone_source_trace_32_1'),
                    ('ddrConnectionDelta', 'connections', 32, 'name', 'source_trace_32'))
    for key, field, index, identity_field, identity in declarations:
        delta = descriptor[key]
        require(delta['index'] == index and delta['before'][identity_field] == identity
                and delta['after'][identity_field] == identity
                and expected[field][index] == delta['before'],
                'Exact declared before identity/index: ' + key)
        expected[field][index] = copy.deepcopy(delta['after'])
    override = {'pcb_via_120': {'before': {'x': 2, 'y': 6.2}, 'after': {'x': 2, 'y': 5.4},
                              'diameterMm': .254, 'outerDiameterMm': .4572,
                              'layers': list(LAYERS), 'identityAndNetUnchanged': True}}
    require(descriptor['physicalDrillPlacementOverride'] == override
            and anchor['declaredReferenceViaPlacementOverrides'] == override
            and anchor['full49FanoutInput'] == expected
            and screen['plannedFull49FanoutInput'] == expected,
            'Only exact POWER185/via120 and D7 RAM branch/request deltas are allowed')
    reversed_base = copy.deepcopy(expected)
    for key, field, _, _, _ in declarations:
        delta = descriptor[key]
        reversed_base[field][delta['index']] = copy.deepcopy(delta['before'])
    require(reversed_base == parent['full49FanoutInput'], 'Full named reference exchange inverse must equal210')
    require(all(expected['traces'][i] == parent['full49FanoutInput']['traces'][i]
                for i in range(165) if i != 83), 'Other164 reference rows must remain literal210')
    require(anchor['carrierTraces'] == parent['carrierTraces']
            and anchor['ordinaryCarrierTraces'] == parent['ordinaryCarrierTraces']
            and anchor['heldCarrierTraces'] == parent['heldCarrierTraces']
            and len(parent['carrierTraces']) == 46,
            'All46 existing bodies and critical6 must remain exact210 objects')
    require(packet.get('plannedPowerReferenceSlotExchange') == descriptor
            and packet.get('declaredReferenceViaPlacementOverrides') == override
            and packet['full49FanoutInput'] == expected
            and packet['carrierTraces'] == parent['carrierTraces']
            and packet['ordinaryCarrierTraces'] == parent['ordinaryCarrierTraces']
            and packet['heldCarrierTraces'] == parent['heldCarrierTraces']
            and packet.get('newCriticalProfile') == anchor.get('newCriticalProfile'),
            'Fresh input must preserve the exact declared overlay and every210 carrier')
    original_rules = {'buses': expected['buses'], 'differentialPairs': expected['differentialPairs']}
    require(original_rules == {'buses': parent['full49FanoutInput']['buses'],
                               'differentialPairs': parent['full49FanoutInput']['differentialPairs']},
            'Original49 literal rules cannot change in a reference overlay')
    profile = packet.get('newReferenceOverlayProfile', {})
    require(profile == {'kind': 'CURRENT210_DECLARED_POWER_REFERENCE185_VIA120_DDR32_SLOT_EXCHANGE',
                       'parentSha256': PARENT_SHA, 'planningPacketSha256': ANCHOR_SHA,
                       'builderSha256': BUILDER_SHA, 'pureScreenSha256': SCREEN_SHA,
                       'allReferenceAndDdrPhysicalAssertionsFreshlyQualified': True,
                       'allCriticalAssertionsFreshlyQualified': True,
                       'criticalCarrierTraces': anchor['heldCarrierTraces'],
                       'literalOriginalRules': original_rules,
                       'declaredReferenceViaPlacementOverrides': override,
                       'other164ReferenceGeometriesUnchanged': True,
                       'all46ExistingCarrierObjectsUnchanged': True, 'sourceCoreFresh': False},
            'Exact fresh named reference-overlay qualification profile required')
    require(packet.get('planningOnly') is False and packet.get('freshSourceCoreDerived') is False
            and packet.get('freshSource') is False
            and packet.get('allSavedCarriersCurrentSceneQualified') is True,
            'Fresh current-scene qualified routing model; Source/Core boundary explicit')
    fanout_checks = packet.get('referenceAndDdrFanoutPhysicalReports', [])
    require(len(fanout_checks) == 2
            and {r['kind'] for r in fanout_checks} == {'POWER_REFERENCE185_VIA120', 'DDR_D7_RAM_NE'}
            and all(r.get('passed') is True and r.get('allFourLayersChecked') is True
                    and r.get('stubC31', {}).get('solved') is True for r in fanout_checks),
            'Both named moved branches need fresh all-four-layer and C31 physical proof')
    joined_checks = packet.get('joinedNativeGeometryReports', [])
    require(len(joined_checks) == 46 and {r['owner'] for r in joined_checks}
            == {owner(t) for t in parent['carrierTraces']}
            and all(r.get('passed') is True for r in joined_checks),
            'All46 numeric-pad joins need fresh native geometry proof')
    proofs = packet.get('criticalValidationViews', [])
    required_views = {'DQS1_LOWER_U_SHARED_VIEW', 'DQS1_EARLY_MEANDER_SHARED_VIEW'}
    require(len(proofs) == 2 and {p['scope'] for p in proofs} == required_views
            and all(p.get('passed') is True and p.get('c31', {}).get('solved') is True for p in proofs),
            'Fresh critical proofs must use both actual DQS1 shared sections')
    for proof in proofs:
        expected_sections = ({'source_trace_27': [24, 28], 'source_trace_28': [30, 34]}
                             if proof['scope'] == 'DQS1_LOWER_U_SHARED_VIEW'
                             else {'source_trace_27': [5, 12], 'source_trace_28': [3, 10]})
        require(proof['actualDQS1SharedSections'] == expected_sections
                and proof['differentialPairs'] == anchor['full49FanoutInput']['differentialPairs'],
                'Exact truthful section views and original pair rules')
        require(set(proof['reports']) == {'bus', 'pair', 'shared', 'coupling', 'exterior'},
                'All five original critical report APIs required')
        require(all(len(rows) == 3 and all(r.get('matched') is True
                    and r.get('aboveMinimumLength') is not False
                    and r.get('withinLengthLimit') is not False for r in rows)
                    for rows in proof['reports'].values()),
                'All original critical assertions must pass freshly')
    current_checks = packet.get('finalScenePhysicalReports', [])
    require(len(current_checks) == len(packet['carrierTraces'])
            and {p['owner'] for p in current_checks} == {owner(t) for t in packet['carrierTraces']}
            and all(p.get('passed') is True for p in current_checks),
            'Every actually saved current body needs fresh full-scene physical qualification')
    base, original = packet['full49FanoutInput'], anchor['full49FanoutInput']
    require(base['layerCount'] == 4 and base['allowedLayers'] == LAYERS
            and base['allowBlindAndBuriedVias'] is False, 'Actual four-layer through-via scene required')
    require(len(base['connections']) == 49 and len(base['traces']) == 263
            and len(base['obstacles']) == 1298, 'Current49/263/1298 scene required')
    require({c['name'] for c in base['connections']} == ALL, 'Original49 roster required')
    require({k: v for k, v in base.items() if k not in ('connections', 'traces')}
            == {k: v for k, v in original.items() if k not in ('connections', 'traces')},
            'Original rules, references/obstacles, board and physical controls changed')
    require(base['traces'][:165] == original['traces'][:165], 'Exact named-overlay reference165 rows required')
    current_bodies = packet['carrierTraces']
    require(len({owner(t) for t in current_bodies}) == len(current_bodies), 'Duplicate body owner')
    by_owner = {owner(t): t for t in current_bodies}
    held = copy.deepcopy(anchor['heldCarrierTraces'])
    require(len(held) == 6 and {owner(t) for t in held} == CRITICAL, 'ExactnewRAMcycle critical6 required')
    require(all(by_owner.get(owner(t)) == t for t in held), 'NewRAMcycle critical rail object changed/missing')
    supplied_held = packet.get('heldCarrierTraces')
    if supplied_held is not None:
        require(len(supplied_held) == 6 and {owner(t) for t in supplied_held} == CRITICAL
                and all(t == by_owner[owner(t)] for t in supplied_held), 'Current held6 differs from exactnewRAMcycle')
    branch_edges, connection_edges, handoffs = transitions(packet)
    changed_rows, changed_connections = [], []
    for before, after in zip(original['traces'][165:], base['traces'][165:]):
        require(before['pcb_trace_id'] == after['pcb_trace_id'] and owner(before) == owner(after),
                'Working branch order/identity changed')
        name = owner(after)
        require(name in ALL, 'Unknown working branch owner')
        for p in after['route']:
            require(p['route_type'] in ('wire', 'via'), 'Unsupported working primitive')
            if p['route_type'] == 'wire':
                require(p['width'] == .1016 and p['layer'] in LAYERS, 'Working wire width/layer changed')
            else:
                require(p.get('layers') == LAYERS and p.get('via_diameter') == .4572
                        and p.get('via_hole_diameter') == .254, 'Working through-via dimensions/span changed')
        if before != after:
            require(name not in CRITICAL and reachable(before, after, branch_edges.get(before['pcb_trace_id'], [])),
                    'Working branch change lacks exact before/after ledger: ' + before['pcb_trace_id'])
            changed_rows.append(before['pcb_trace_id'])
    original_connections = {c['name']: c for c in original['connections']}
    for after in base['connections']:
        before, name = original_connections[after['name']], after['name']
        require({k: v for k, v in after.items() if k != 'pointsToConnect'}
                == {k: v for k, v in before.items() if k != 'pointsToConnect'}, 'Original connection metadata changed')
        require(len(after['pointsToConnect']) == 2, 'Two actual handoffs required')
        if before != after:
            require(name not in CRITICAL, 'Critical handoff changed')
            exact_connection_ledger = reachable(before, after, connection_edges.get(name, []))
            if not exact_connection_ledger:
                for old_point, new_point in zip(before['pointsToConnect'], after['pointsToConnect']):
                    if old_point != new_point:
                        require(reachable(old_point, new_point, handoffs.get(name, [])),
                                'Handoff change lacks exact connection/handoff ledger: ' + name)
            changed_connections.append(name)
    if changed_rows or changed_connections:
        require(packet.get('allSavedCarriersCurrentSceneQualified') is True,
                'Changed working foundation needs explicit current-scene saved-carrier qualification')
    require(packet.get('dormantWorkingBarrels', []) == [], 'Unresolved dormant working barrels')
    branches = {name: [t for t in base['traces'][165:] if owner(t) == name] for name in ALL}
    availability, availability_proof = {}, {}
    for connection in base['connections']:
        name = connection['name']
        require(len(branches[name]) == 2, 'Exactly two current working branches: ' + name)
        proof = [endpoint_proof(p, branches[name]) for p in connection['pointsToConnect']]
        available = [layer for layer in LAYERS if all(layer in p['availableLayers'] for p in proof)]
        availability[name] = available
        availability_proof[name] = {'endpoints': proof, 'sameLayerCarrierLayers': available,
                                    'requiresMixedCarrier': not bool(available),
                                    'doesNotInventNumericPadIds': True}
    whole_lengths = {owner(t): planar(t) + sum(planar(b) for b in branches[owner(t)]) for t in held}
    windows, search_buses = {}, []
    for bus in base['buses']:
        held_names = [n for n in bus['connectionNames'] if n in CRITICAL]
        mutable_names = [n for n in bus['connectionNames'] if n not in CRITICAL]
        values = [whole_lengths[n] for n in held_names]
        lo, hi = bus.get('minLength'), bus.get('maxLength')
        tolerance = bus.get('maxLengthSkew')
        if values and tolerance is not None:
            require(max(values) - min(values) <= tolerance + 1e-7, 'Held cohort skew fails original bound')
            lo = max(lo if lo is not None else -math.inf, max(values) - tolerance)
            hi = min(hi if hi is not None else math.inf, min(values) + tolerance)
        require(lo is None or hi is None or lo <= hi + 1e-7, 'Empty actual held-cohort window')
        if values:
            require(all((bus.get('minLength') is None or x >= bus['minLength'] - 1e-7)
                        and (bus.get('maxLength') is None or x <= bus['maxLength'] + 1e-7) for x in values),
                    'Held rail violates original absolute bounds')
        windows[bus['busId']] = {'heldOwners': held_names, 'heldWholePlanarMm': {n: whole_lengths[n] for n in held_names},
                                'ordinaryOwners': mutable_names, 'minLengthMm': lo, 'maxLengthMm': hi,
                                'maxLengthSkewMm': tolerance, 'originalMinLengthMm': bus.get('minLength'),
                                'originalMaxLengthMm': bus.get('maxLength'), 'derivedSearchIntersectionOnly': True}
        if mutable_names:
            search = copy.deepcopy(bus)
            search['connectionNames'] = mutable_names
            if lo is not None:
                search['minLength'] = lo
            if hi is not None:
                search['maxLength'] = hi
            search_buses.append(search)
    for pair in base['differentialPairs']:
        names = pair['connectionNames']
        require(len(names) == 2 and all(n in CRITICAL for n in names), 'Original three critical pairs required')
        require(abs(whole_lengths[names[0]] - whole_lengths[names[1]]) <= pair['lengthTolerance'] + 1e-7,
                'Exact repaired held pair fails original tolerance')
    require(abs(windows['DDR_COMMAND_CLOCK']['maxLengthMm'] - 21.82365669636869) <= 1e-10,
            'Current210 critical6 clock window must not fall back to old clock geometry')
    ordinary_input = copy.deepcopy(base)
    ordinary_input['connections'] = [copy.deepcopy(c) for c in base['connections'] if c['name'] not in CRITICAL]
    ordinary_input['traces'] = copy.deepcopy(base['traces']) + copy.deepcopy(held)
    ordinary_input['buses'] = search_buses
    ordinary_input['differentialPairs'] = []
    require(len(ordinary_input['connections']) == 43 and len(ordinary_input['traces']) == 269, 'Ordinary43 scene count')
    return {'full49FanoutInput': copy.deepcopy(base), 'heldCarrierTraces': held, 'input': ordinary_input,
            'declaredReferenceViaPlacementOverrides': copy.deepcopy(override),
            'newReferenceOverlayProfile': copy.deepcopy(profile),
            'availability': availability, 'availabilityProof': availability_proof,
            'originalRules': {'buses': copy.deepcopy(base['buses']), 'differentialPairs': copy.deepcopy(base['differentialPairs'])},
            'cohortWindows': windows,
            'profile': {'kind': 'CURRENT210_DECLARED_POWER_REFERENCE_OVERLAY_DYNAMIC_CONSTRUCTOR', 'anchorSha256': ANCHOR_SHA,
                        'anchorPath': str(ANCHOR), 'sourcePacketSha256': source_sha, 'sourcePacketPath': str(source_path),
                        'referenceOverlayPreflightWorkerSha256': PREFLIGHT_WORKER_SHA,
                        'referenceOverlayParent210Sha256': PARENT_SHA,
                        'referenceOverlayPlanningBuilderSha256': BUILDER_SHA,
                        'referenceOverlayPureScreenSha256': SCREEN_SHA,
                        'clockUpperSearchCapMm': windows['DDR_COMMAND_CLOCK']['maxLengthMm'],
                        'originalRulesPreserved': True, 'workingChangedBranchIds': changed_rows,
                        'workingChangedConnections': changed_connections, 'noOldClockFallback': True,
                        'referenceExchangeOnly': True, 'other164ReferencesLiteral210': True,
                        'all46ExistingCarrierObjectsLiteral210': True,
                        'inverseFullBaseEqualsParent210': True},
            'workingCandidateProvenance': {k: copy.deepcopy(packet[k]) for k in (
                'newCriticalProfile', 'newReferenceOverlayProfile', 'plannedPowerReferenceSlotExchange',
                'referenceAndDdrFanoutPhysicalReports', 'declaredReferenceViaPlacementOverrides',
                'criticalValidationViews', 'atomicRamFanoutPhysicalReports',
                'workingChanges', 'releasedWorkingBranchMaterial', 'dormantWorkingBarrels', 'source21NativeTopRepair',
                'capturedMixedOwners', 'retainedMixedOwners', 'clockPairRepair', 'newViaReports', 'physicalRunReports',
                'finalScenePhysicalReports') if k in packet},
            'qualificationBoundary': {'geometryExecutedByBuilder': False, 'sdkImported': False,
                'newPhysicalQualificationClaim': False, 'originalRuleQualificationStillRequired': True,
                'mixedCarrierRequiresPerRunAndRealBarrelQualification': True, 'all49Accepted': False, 'freshSourceCoreDerived': False}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--input-sha', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source, target = args.input.resolve(), args.output.resolve()
    require(not target.exists() and source != target, 'Output must be fresh and separate')
    require(len(args.input_sha) == 64 and all(c in '0123456789abcdef' for c in args.input_sha), 'Explicit lowercase SHA256 required')
    anchor, _ = read_pinned(ANCHOR, ANCHOR_SHA)
    packet, digest = read_pinned(source, args.input_sha)
    result = build(packet, anchor, source, digest)
    for pinned_path, expected_sha in ((source, digest), (ANCHOR, ANCHOR_SHA), (PARENT, PARENT_SHA),
                                      (SCREEN, SCREEN_SHA), (BUILDER, BUILDER_SHA),
                                      (PREFLIGHT_WORKER, PREFLIGHT_WORKER_SHA)):
        require(hashlib.sha256(pinned_path.read_bytes()).hexdigest() == expected_sha,
                'Pinned input changed while constructing: ' + str(pinned_path))
    data = json.dumps(result, indent=2, allow_nan=False) + '\n'
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('x') as stream:
        stream.write(data)
    print(json.dumps({'output': str(target), 'outputSha256': hashlib.sha256(data.encode()).hexdigest(),
                      'ordinaryConnections': 43, 'heldCarriers': 6,
                      'clockUpperSearchCapMm': result['profile']['clockUpperSearchCapMm'], 'all49Accepted': False, 'freshSourceCoreDerived': False}))


if __name__ == '__main__':
    main()
