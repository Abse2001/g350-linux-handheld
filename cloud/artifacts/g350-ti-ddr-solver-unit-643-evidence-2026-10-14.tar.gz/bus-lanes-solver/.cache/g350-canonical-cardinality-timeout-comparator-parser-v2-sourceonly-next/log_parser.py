from pathlib import Path
import re

def parse_text(text):
    summaries = re.findall(r'^Ran (\d+) tests across (\d+) files?\.', text, re.M)
    passes = re.findall(r'^\s*(\d+) pass\s*$', text, re.M)
    failures = re.findall(r'^\s*(\d+) fail\s*$', text, re.M)
    expectations = re.findall(r'^\s*(\d+) expect\(\) calls\s*$', text, re.M)
    cases = []; filename = None
    for line in text.splitlines():
        # Bun repeats failed rows in a final recap. They remain in the raw log,
        # but are not additional executed cases and have no original file header.
        if re.fullmatch(r'\s*\d+ tests? failed:\s*', line): break
        if line.startswith('tests/') and line.endswith(':'): filename = line[:-1]
        match = re.fullmatch(r'\((pass|fail)\) (.*?) \[([\d.]+)ms\]', line)
        if match:
            cases.append({'file': filename, 'status': match[1], 'name': match[2],
                          'milliseconds': float(match[3]), 'timeoutMilliseconds': None})
        timeout = re.search(r'this test timed out after (\d+)ms', line)
        if timeout and cases: cases[-1]['timeoutMilliseconds'] = int(timeout[1])
    counts = {'pass': int(passes[-1]) if passes else None,
              'fail': int(failures[-1]) if failures else None,
              'tests': int(summaries[-1][0]) if summaries else None,
              'files': int(summaries[-1][1]) if summaries else None,
              'expectCalls': int(expectations[-1]) if expectations else None}
    return counts, cases

def parse_log(path):
    return parse_text(Path(path).read_text(errors='replace'))

def parser_controls(actual_logs):
    passing = ['tests/grid-native-length-bounds.test.ts:']
    failing = ['tests/grid-native-length-bounds.test.ts:']
    for index in range(9):
        if index == 6:
            passing.append('tests/expanded-signal-sites-coarse-first.test.ts:')
            failing.append('tests/expanded-signal-sites-coarse-first.test.ts:')
        passing.append(f'(pass) case {index} [1.25ms]')
        if index in [0, 7]:
            milliseconds, timeout = (7960.87, 5000) if index == 0 else (32022.48, 30000)
            failing.append(f'(fail) case {index} [{milliseconds}ms]')
            failing.append(f'  ^ this test timed out after {timeout}ms.')
        else: failing.append(f'(pass) case {index} [1.25ms]')
    passing += ['', ' 9 pass', ' 0 fail', ' 20 expect() calls', 'Ran 9 tests across 2 files. [2.00s]']
    failing += ['', ' 7 pass', ' 2 fail', ' 20 expect() calls', 'Ran 9 tests across 2 files. [42.00s]',
                '', '2 tests failed:', '(fail) case 0 [7960.87ms]', '(fail) case 7 [32022.48ms]']
    counts, cases = parse_text('\n'.join(passing))
    assert counts == {'pass': 9, 'fail': 0, 'tests': 9, 'files': 2, 'expectCalls': 20}
    assert len(cases) == 9 and all(row['status'] == 'pass' for row in cases)
    counts, cases = parse_text('\n'.join(failing))
    assert counts == {'pass': 7, 'fail': 2, 'tests': 9, 'files': 2, 'expectCalls': 20}
    assert len(cases) == 9 and [row['name'] for row in cases] == [f'case {i}' for i in range(9)]
    assert cases[0] == {'file': 'tests/grid-native-length-bounds.test.ts', 'status': 'fail',
        'name': 'case 0', 'milliseconds': 7960.87, 'timeoutMilliseconds': 5000}
    assert cases[7] == {'file': 'tests/expanded-signal-sites-coarse-first.test.ts', 'status': 'fail',
        'name': 'case 7', 'milliseconds': 32022.48, 'timeoutMilliseconds': 30000}
    report = {'syntheticPassNine': True, 'syntheticFailedRecapNine': True, 'actualLogs': []}
    for item in actual_logs:
        counts, cases = parse_log(item['path'])
        assert {key: counts[key] for key in ['pass', 'fail', 'tests', 'files']} == item['expectedCounters']
        assert len(cases) == counts['tests']
        assert sum(row['status'] == 'fail' for row in cases) == counts['fail']
        report['actualLogs'].append({'path': item['path'], 'actualCounters': counts,
                                    'executedCaseRows': len(cases)})
    return report
