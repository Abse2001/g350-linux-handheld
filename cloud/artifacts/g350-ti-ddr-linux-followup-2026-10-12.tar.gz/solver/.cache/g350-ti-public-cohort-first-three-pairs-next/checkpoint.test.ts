import { expect, test } from "bun:test"
import { readFileSync } from "node:fs"
import { pairedViewFromPublicCheckpoint } from "./checkpoint"
import { installFirstThreeGate } from "./prefix-control"

const data = () => {
  const load = (name: string) =>
    JSON.parse(readFileSync(`${import.meta.dir}/${name}`, "utf8"))
  return {
    input: load("input.json"),
    unrestricted: load("original-unrestricted-input.json"),
    result: load("parent-actual-public-initial-result.json"),
    options: load("parent-actual-public-initial-options.json"),
    report: load("parent-result.json"),
    post: load("parent-postflight.json"),
  }
}
const view = (d: ReturnType<typeof data>) =>
  pairedViewFromPublicCheckpoint(
    d.input,
    d.unrestricted,
    d.result,
    d.options,
    d.report,
    d.post,
  )

test("trusted actual public24-escape checkpoint derives original six-trace pair view and empty alternatives without rerunning initializer", () => {
  const d = data(),
    before = JSON.stringify(d),
    fresh = view(d)
  expect(fresh.escapes).toHaveLength(24)
  expect(fresh.terminalLayers.size).toBe(0)
  expect(fresh.allocation.traces).toHaveLength(6)
  expect(fresh.allocation.traces!.slice(0, 2)).toEqual(d.unrestricted.traces)
  expect(
    fresh.allocation.traces!.slice(2).map((trace) => trace.connection_name),
  ).toEqual([
    "source_trace_15",
    "source_trace_15",
    "source_trace_16",
    "source_trace_16",
  ])
  expect(fresh.actualLayers).toEqual(["bottom", "top", "top"])
  expect(fresh.allocation.obstacles).toHaveLength(856)
  expect(fresh.allocation.connections).toHaveLength(49)
  expect(fresh.allocation.buses).toBe(d.input.buses)
  expect(JSON.stringify(d)).toBe(before)
})

test("changed TIbound, hardware, target declaration or untrusted public report cannot enter paired producer", () => {
  for (const mutate of [
    (d: ReturnType<typeof data>) => {
      d.input.buses[1].maxLength = 14.5
    },
    (d: ReturnType<typeof data>) => {
      d.input.obstacles[0].center.x += 0.001
    },
    (d: ReturnType<typeof data>) => {
      d.options.targetLayers[0][1] = "top"
    },
    (d: ReturnType<typeof data>) => {
      d.post.resultTrustEligible = false
    },
    (d: ReturnType<typeof data>) => {
      d.report.control.surfaceBodyAdvances = 1
    },
  ]) {
    const changed = data()
    mutate(changed)
    expect(() => view(changed)).toThrow()
  }
})

test("original exported priority caller consumes actual policy/checkpoint and only three MOCK native factories", async () => {
  const d = data(),
    fresh = view(d)
  const pair = await import("./source/lib/coupled-pair-routing"),
    original = pair.routeCoupledPair
  let mockCalls = 0
  const gate = installFirstThreeGate(
    pair,
    d.input.differentialPairs.map((p: any) => p.connectionNames),
    () => {},
    function* (...args: any[]) {
      const index = mockCalls++
      expect(args[0].buses).toBe(d.input.buses)
      expect(args[0].obstacles).toBe(d.input.obstacles)
      expect(args[0].traces).toEqual(fresh.allocation.traces!)
      expect(args[1]).toBe(d.input.differentialPairs[index])
      expect(
        args[0].connections
          .filter((c: any) => args[1].connectionNames.includes(c.name))
          .every((c: any) =>
            c.pointsToConnect.every(
              (p: any) => p.layer === fresh.actualLayers[index],
            ),
          ),
      ).toBe(true)
      yield
      return null
    },
  )
  let planner:
    | ReturnType<
        typeof import("./source/lib/route-fresh-surface-buses").priorityPairPlans
      >
    | undefined
  try {
    const source = await import("./source/lib/route-fresh-surface-buses")
    planner = source.priorityPairPlans(fresh.allocation, fresh.terminalLayers)
    expect(() => {
      while (!planner!.next().done) {
        /* mocked carriers only */
      }
    }).toThrow(gate.boundary)
    expect(mockCalls).toBe(3)
    expect(gate.originalFactories).toBe(3)
    expect(gate.factoryAttempts).toBe(4)
  } finally {
    planner?.return(undefined)
    gate.restore()
  }
  expect(pair.routeCoupledPair).toBe(original)
})
