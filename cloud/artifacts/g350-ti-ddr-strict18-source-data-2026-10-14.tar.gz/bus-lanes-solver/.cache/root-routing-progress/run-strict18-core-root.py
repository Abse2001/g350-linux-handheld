import importlib.util,json,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
s=importlib.util.spec_from_file_location('strict18_reviewed_types_library',ROOT/'run-strict18-types-root.py')
t=importlib.util.module_from_spec(s);s.loader.exec_module(t);c=t.c
OUT=t.CORE/'run-core'
POLICY={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
def main():
 assert len(sys.argv)==5
 peerpath=Path(sys.argv[1]);assert c.sha(peerpath)==sys.argv[2]
 typereceipt=Path(sys.argv[3]);assert c.sha(typereceipt)==sys.argv[4]
 peer=c.read(peerpath);cm=c.read(t.CORE/'SOURCE-manifest.json');core_sha=c.sha(t.CORE/'SOURCE-manifest.json')
 assert peer['sourceManifestSha256']==core_sha and peer['decision']=='GO_SOURCE_ONLY_TO_ROOT_OWNED_CORE_AFTER_ACTUAL_SOURCE_AND_TYPES_ZERO'
 for r in cm['ownFiles']+cm['externalFiles']:c.guard.source_guard.binding(r)
 m,packet=c.bindings();_,native_sha,before,sbefore,_=c.guard.checked()
 tr,tp,te=c.guard.collected({'path':str(typereceipt),'sha256':sys.argv[4]},positive=True)
 assert tr['sourceManifestSha256']==packet and tr['coreSourceManifestSha256']==core_sha and tp['typecheckPassed'] and tp['typecheckCommand'][-1]==str(t.CORE/'render-strict18-core.ts')
 receipt=ROOT/'strict18-source-capture-86442-COLLECTED-root.json';cr,cp,ce=c.guard.collected({'path':str(receipt),'sha256':c.sha(receipt)},positive=True)
 assert cr['sourceManifestSha256']==packet and c.read(cp['capturePath'])['fullInverseSourceTreePassed'] and c.sha(cp['capturePath'])==cp['captureSha256']
 rows=c.read(c.PACKET/'run-capture/ROOT_AUTHORITY.json')['actualPriorCollectedRows']+[{'path':str(receipt),'sha256':c.sha(receipt)},{'path':str(typereceipt),'sha256':sys.argv[4]}]
 def closed():
  for r in rows:assert c.guard.process_scope.owned(c.guard.collected(r)[2]['pgid'])==[]
 closed();assert not OUT.exists();OUT.mkdir()
 for name in ('node_modules','.pnp.cjs','.pnp.loader.mjs','.yarn'):
  p=t.CORE/name;assert not p.exists() and not p.is_symlink()
 auth={'authorizedByRoot':True,'sourceManifestSha256':packet,'coreSourceManifestSha256':core_sha,'peerPath':str(peerpath),'peerSha256':sys.argv[2],'actualTypesCollection':{'path':str(typereceipt),'sha256':sys.argv[4]},'actualPriorCollectedRows':rows,'policy':POLICY,'rootFullCoreWorkerReadPassed':True,'noConcurrentRootWorker':True,'accepted49':False,'fabricationReady':False}
 with (OUT/'ROOT_AUTHORITY.json').open('x')as f:json.dump(auth,f,indent=2);f.write('\n')
 ah=c.sha(OUT/'ROOT_AUTHORITY.json')
 raw=OUT/'raw-core.json';controls=OUT/'core-controls.json'
 argv=[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',str(t.CORE/'render-strict18-core.ts'),str(raw),str(controls)]
 def prefork(mem):
  closed();assert mem['current']+POLICY['rssBytes']+1073741824<POLICY['sharedBytes']
 e=c.guard.process_scope.run_guarded(argv,str(c.BOARD),OUT/'owned',POLICY,{'G350_STRICT18_CORE_ROOT_GUARDED':'1'},before_spawn=prefork)
 _,nsha,after,safter,_=c.guard.checked();_,pafter=c.bindings();closed()
 for r in cm['ownFiles']+cm['externalFiles']:c.guard.source_guard.binding(r)
 held=native_sha==nsha and packet==pafter and before==after and sbefore==safter and c.sha(peerpath)==sys.argv[2] and c.sha(t.CORE/'SOURCE-manifest.json')==core_sha and c.sha(typereceipt)==sys.argv[4] and c.sha(OUT/'ROOT_AUTHORITY.json')==ah
 report=c.read(controls)if controls.is_file()else None
 passed=held and e['exitCode']==0 and not e['diagnosticStopped'] and e['cleanupOwnedGroupEmpty'] and not any(e['oomDelta'].values()) and report is not None and report['freshCoreControlPassed'] and all(r['passed']for r in report['checks']) and c.sha(raw)==report['rawCoreSha256'] and len(report['newDirectOriginalSignals'])==16
 outputs=[{'path':str(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':c.sha(p)}for p in sorted(OUT.iterdir())if p.is_file()]
 post={'scope':'ACTUAL_FRESH_STRICT18_MANUAL_CORE279_SOURCE_CONTROL','sourceManifestSha256':packet,'coreSourceManifestSha256':core_sha,'execution':e,'sourceAndDependenciesHeld':held,'dependenciesBefore':before,'dependenciesAfter':after,'solverDependenciesBefore':sbefore,'solverDependenciesAfter':safter,'rawCorePath':str(raw),'rawCoreSha256':c.sha(raw)if raw.is_file()else None,'coreControlsPath':str(controls),'coreControlsSha256':c.sha(controls)if controls.is_file()else None,'outputFiles':outputs,'passed':bool(passed),'coreCalls':1,'nativeExplicitCalls':0,'cadCalls':0,'complete18Accepted':False,'accepted49':False,'fabricationReady':False}
 with (OUT/'POSTAUDIT.json').open('x')as f:json.dump(post,f,indent=2);f.write('\n')
 print(json.dumps({k:post[k]for k in ('passed','sourceAndDependenciesHeld','rawCoreSha256','coreControlsSha256','execution')}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
