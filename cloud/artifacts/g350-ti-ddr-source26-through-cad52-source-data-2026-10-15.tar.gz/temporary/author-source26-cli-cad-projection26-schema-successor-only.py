"""Own stdlib immutable source correction; no worker/guard/helper imports."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,stat
P=Path('/tmp/g350-source26-cli-cad-actual48-minimal-workers-v2-sourceonly-next');PW=Path('/tmp/g350-source26-cad47-actual48-minimal-wrapper-v2-sourceonly-next')
R=Path('/tmp/g350-source26-cli-cad-projection26-schema-successor-sourceonly-next');W=Path('/tmp/g350-source26-cad47-projection26-schema-wrapper-sourceonly-next');R.mkdir(mode=0o700,exist_ok=False);W.mkdir(mode=0o700,exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();return dict(path=str(p),sha256=sha(p),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def write(root,name,s):
 p=root/name
 with p.open('x')as f:f.write(s)
 p.chmod(0o600);return p
def data(root,name,d):return write(root,name,json.dumps(d,indent=2)+'\n')
assert sha(P/'SOURCE-manifest.json')=='a7691ba99cd7648f19b45f13742118187115bba27195ed15c761d91544ced01e'
assert sha(PW/'SOURCE-fragment.json')=='4335c874991f29111db0516433762270a7dd2e59400ef6e9fbb5b6194e474603'
files=['artifact_contract.py','export_fresh_json.py','inspect_source26.py','build_bound_zone_pins.py','zone_contract.py'];records=[]
for name in files:
 old=(P/name).read_text();s=old
 if name=='artifact_contract.py':
  for a,b in [('exactFullInverseToFresh24Parent','exactFullInverseToFresh26Parent'),('future24','future26'),('Native24 source','Native26 source'),('API24 source','API26 source'),('this actual24 Core','this actual26 Core')]:assert a in s;s=s.replace(a,b)
  assert s.replace('exactFullInverseToFresh26Parent','exactFullInverseToFresh24Parent').replace('future26','future24').replace('Native26 source','Native24 source').replace('API26 source','API24 source').replace('this actual26 Core','this actual24 Core')==old
 p=write(R,name,s);ast.parse(s);records.append(dict(parent=pin(P/name),proposed=pin(p),byteIdentical=s==old))
 if s!=old:write(R,name+'.EXACT_SCHEMA_ONLY.delta.patch',''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile=str(P/name),tofile=str(p))))
oldmeta=json.loads((P/'FUTURE_ACTUAL_BINDINGS_NULL_NOT_AUTHORIZATION.json').read_bytes());oldmeta['actualBindings']['actualCoreCollection']=oldmeta['actualBindings']['actualCoreBatchCollection'];data(R,'FUTURE_ACTUAL_BINDINGS_NULL_NOT_AUTHORIZATION.json',oldmeta)
write(R,'README.md',(P/'README.md').read_text()+'\nThis immutable successor additionally corrects the projection proof key to exactFullInverseToFresh26Parent, matching the held e20c01c5 Source26 projector source. Source24 predecessor packets remain unchanged and unrun. Actual48 Core artifacts are concrete; Native/API/projection/export/CAD actual pins remain null.\n')
data(R,'EXACT_PARENT_SCHEMA_CORRECTION_AND_INVERSE.json',dict(scope='SOURCE_ONLY_SOURCE26_PROJECTION_PROOF_KEY_SCHEMA_SUCCESSOR',parentRuntime=pin(P/'SOURCE-manifest.json'),ancestorWorkerRebindings=pin(P/'EXACT_PARENT_LITERAL_REBINDINGS_AND_INVERSE.json'),directFiles=records,onlyOperationalFieldCorrection=['exactFullInverseToFresh24Parent','exactFullInverseToFresh26Parent'],fourOtherWorkerBodiesByteExact=True,physicalPredicatesAndCoreCallsBehaviorUnchanged=True,actualCore48Bound=True,futureNativeApiExportPinsNull=True,workspaceWrites=0,applicationHelperOrSdkCalls=0,accepted49=False,fabricationReady=False))
m=json.loads((P/'SOURCE-manifest.json').read_bytes());m['files']=[pin(p)for p in sorted(R.iterdir())];m['externalFiles'] += [pin(P/'SOURCE-manifest.json'),pin(P/'artifact_contract.py'),pin(P/'EXACT_PARENT_LITERAL_REBINDINGS_AND_INVERSE.json'),pin('/tmp/g350-source26-promoted-pins-native-fresh49-api-partial-runtime-sourceonly-next/derive-fresh26-core49-input.py'),pin(__file__)];m['actualPrerequisites']['actualCoreCollection']=m['actualPrerequisites']['actualCoreBatchCollection'];m['projectionSchemaKey']='exactFullInverseToFresh26Parent';m['unrunParentRuntime']=pin(P/'SOURCE-manifest.json');mp=data(R,'SOURCE-manifest.json',m)
wraprecords=[]
for name in ['run-kicad-offline-with-snapshots.sh','check_cad_snapshots.py','record_cad_resources.py']:
 old=(PW/name).read_text();s=old
 if name=='run-kicad-offline-with-snapshots.sh':s=s.replace(str(PW),str(W))
 if name=='check_cad_snapshots.py':
  assert repr(pin(P/'SOURCE-manifest.json'))in s;s=s.replace(repr(pin(P/'SOURCE-manifest.json')),repr(pin(mp)))
 p=write(W,name,s)
 if p.suffix=='.py':ast.parse(s)
 wraprecords.append(dict(parent=pin(PW/name),proposed=pin(p),byteIdentical=s==old))
 if s!=old:write(W,name+'.EXACT_LOCAL_PATH_AND_RUNTIME_PIN_ONLY.delta.patch',''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile=str(PW/name),tofile=str(p))))
data(W,'EXACT_PARENT_WRAPPER_PATH_PIN_SUCCESSOR.json',dict(parentWrapperFragment=pin(PW/'SOURCE-fragment.json'),directFiles=wraprecords,runtimeSource=pin(mp),tested20e3PolicyAndCleanupBehaviorHeld=True,actualCliCollection=None,actualExport=None,actualSnapshotPlan=None,workspaceWrites=0,applicationHelperOrSdkCalls=0,RootAuthorityCreated=False,accepted49=False,fabricationReady=False))
frag=data(W,'SOURCE-fragment.json',dict(scope='SOURCE_ONLY_SOURCE26_TESTED_CAD47_WRAPPER_RUNTIME_PIN_SUCCESSOR',status='UNEXECUTED_FUTURE_NATIVE_API_CLI_EXPORT_AND_SNAPSHOTS_NULL',files=[pin(p)for p in sorted(W.iterdir())],externalFiles=[pin(PW/'SOURCE-fragment.json'),pin(PW/'EXACT_TESTED20E3_PARENT_REBINDINGS_AND_INVERSE.json'),pin(mp),pin(__file__)],runtimeSource=pin(mp),actualCliCollection=None,actualCliReport=None,actualExport=None,snapshotCopyPlan=None,RootAuthorityCreated=False,accepted49=False,fabricationReady=False))
for label,p in [('runtime',mp),('contract',R/'artifact_contract.py'),('export',R/'export_fresh_json.py'),('inspect',R/'inspect_source26.py'),('wrapper',frag),('shell',W/'run-kicad-offline-with-snapshots.sh')]:print(label,json.dumps(pin(p)))
