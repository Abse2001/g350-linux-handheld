import type { SolverOptions } from "./types"

export type CoupledPairSearchOptions = Pick<
  SolverOptions,
  "precheckEnclosedTerminals" | "originalCorridorTuningCandidates"
>

/** Keep the original argument tail absent unless a caller explicitly opts in.
 * Keep the existing positive finite option domain, without a new ceiling. */
export function coupledPairSearchOptions(options?: CoupledPairSearchOptions) {
  const budget = options?.originalCorridorTuningCandidates
  if (budget !== undefined && (!Number.isFinite(budget) || budget <= 0))
    throw Error("originalCorridorTuningCandidates must be finite and positive")
  if (options?.precheckEnclosedTerminals !== true && budget === undefined)
    return undefined
  return {
    ...(options?.precheckEnclosedTerminals === true
      ? { precheckEnclosedTerminals: true as const }
      : {}),
    ...(budget !== undefined
      ? { originalCorridorTuningCandidates: budget }
      : {}),
  }
}
