/** SOURCE ONLY: declared C_DDR_RAM_12 +X0.79 partial replay overlay.
 * Root owns all execution. This wrapper preserves the frozen v3 route replay,
 * changes exactly one placement and two reference route literals, and requires
 * the unchanged complete presence-aware inverse before returning.
 */
// @ts-ignore Exact managed runtime, identical to the frozen base overlay.
import ReactRuntime from "/workspace/g350-linux-handheld/node_modules/react/index.js"
import type * as ReactTypes from "/workspace/g350-linux-handheld/node_modules/@types/react/index"
import {
  buildAll49SourceReplay as buildBaseReplay,
  snapshotAll49ReplaySource,
  inverseAll49ReplaySnapshot,
  inverseAll49ReplayParentNormalization,
} from "/tmp/g350-source33b-partial-mixed-source-replay-overlay-v3-sourceonly.ts"
import type {
  All49ReplayPlan as BasePlan,
  LiteralSnapshot,
  ReplayAuditPlan as BaseAudit,
} from "/tmp/g350-source33b-partial-mixed-source-replay-overlay-v3-sourceonly.ts"
export {
  snapshotAll49ReplaySource,
  inverseAll49ReplaySnapshot,
  inverseAll49ReplayParentNormalization,
  deriveAll49ReplayExpectedCounts,
  registerAll49SourceReplayInnerPorts,
} from "/tmp/g350-source33b-partial-mixed-source-replay-overlay-v3-sourceonly.ts"
export type { LiteralSnapshot } from "/tmp/g350-source33b-partial-mixed-source-replay-overlay-v3-sourceonly.ts"

const { cloneElement, createElement, isValidElement }: typeof ReactTypes = ReactRuntime
type ReactNode = ReactTypes.ReactNode
type Props = Record<string, any> & { children?: ReactNode }
type XY = { x: number; y: number }
type RouteProps = { pcbPaths: Array<Array<string | XY>>; pcbPathRelativeTo: "U_SOC.pin7" }
type Placement = { pcbX: number; pcbY: number; layer: "bottom"; pcbRotation: 180 }
export interface Cap12HardwareDelta {
  profile: "CAP12_TRANSLATE_X_0P79_ONLY"
  component: { name: "C_DDR_RAM_12"; sourcePlacement: { before: Placement; after: Placement } }
  references: Array<{ name: string; literalTraceName: string; fromSelector: string; toSelector: string;
    beforeRouteProps: { pcbPath: [] }; afterRouteProps: RouteProps; absolutePoints3: XY[]; width: .2 }>
}
export interface All49ReplayPlan extends BasePlan { cap12HardwareDelta: Cap12HardwareDelta }
export interface ReplayAuditPlan extends BaseAudit {
  cap12HardwareDeltaProfile: "CAP12_TRANSLATE_X_0P79_ONLY"
  cap12HardwareDelta: Cap12HardwareDelta
  cap12ChangedLiteralNames: string[]
  cap12HeldHardwareExpectations: Record<string, number | boolean>
}
export const CAP12_BASE_OVERLAY_SOURCE_PIN = {
  path: "/tmp/g350-source33b-partial-mixed-source-replay-overlay-v3-sourceonly.ts",
  sha256: "256bea71cd157fdedb1d58fdc19ec5f48880e1ddcf27644ec2a86f59669d3906",
}
const PROFILE = "CAP12_TRANSLATE_X_0P79_ONLY" as const
const check = (v: unknown, message: string): void => { if (!v) throw new Error(message) }
const canonical = (v: unknown): string => Array.isArray(v) ? `[${v.map(canonical).join(",")}]`
  : v && typeof v === "object" ? `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical((v as Props)[k])}`).join(",")}}`
  : typeof v === "function" ? `function:${v.toString()}` : typeof v === "symbol" ? `symbol:${String(v)}` : JSON.stringify(v) ?? "undefined"
const same = (a: unknown, b: unknown): boolean => canonical(a) === canonical(b)
const own = (v: object, k: string): boolean => Object.prototype.hasOwnProperty.call(v, k)
const SPECS = [
  { id: "source_trace_994", name: "TI_HS_C_DDR_RAM_12_POWER", from: "C_DDR_RAM_12.pin1",
    to: ".V_TI_HS_C_DDR_RAM_12_POWER > port.bottom", points: [
      { x: 6.369884, y: 4.7 }, { x: 5.469884, y: 3.8 }, { x: 5.2, y: 3.8 }],
    oldPoints: [{ x: 5.579884, y: 4.7 }, { x: 5.2, y: 3.8 }] },
  { id: "source_trace_995", name: "TI_HS_C_DDR_RAM_12_GROUND", from: "C_DDR_RAM_12.pin2",
    to: ".V_TI_HS_C_DDR_RAM_12_GROUND > port.bottom", points: [
      { x: 7.210116, y: 4.7 }, { x: 6.8, y: 4.289884 }, { x: 6.8, y: 3.8 }],
    oldPoints: [{ x: 6.420116, y: 4.7 }, { x: 6.8, y: 3.8 }] },
]
function validateDelta(plan: All49ReplayPlan): void {
  const delta = plan.cap12HardwareDelta
  check(delta?.profile === PROFILE && delta.component?.name === "C_DDR_RAM_12",
    "Mandatory named cap12 +X0.79 hardware profile")
  check(same(delta.component.sourcePlacement.before, { pcbX: 6, pcbY: 4.7, layer: "bottom", pcbRotation: 180 })
    && same(delta.component.sourcePlacement.after, { pcbX: 6.79, pcbY: 4.7, layer: "bottom", pcbRotation: 180 }),
    "Exactly one declared cap12 translation; rotation, layer and Y remain held")
  check(delta.references.length === 2 && new Set(delta.references.map(r => r.literalTraceName)).size === 2,
    "Exactly two distinct cap12 reference route edits")
  const frame = plan.pcbPathCoordinateFrame
  check(frame?.kind === "CAPTURED_CPU_COMPONENT_ORIGIN" && frame.componentName === "U_SOC"
    && frame.rotationDegrees === 0 && same(frame.originXY, { x: 0, y: 20 }),
    "Cap12 reference interior XY uses the held CPU component origin, never cap-local rotation")
  for (const spec of SPECS) {
    const r = delta.references.find(row => row.literalTraceName === spec.name)
    check(r && (r.name === spec.id || r.name === spec.name) && r.fromSelector === spec.from
      && r.toSelector === spec.to && r.width === .2 && same(r.beforeRouteProps, { pcbPath: [] })
      && same(r.absolutePoints3, spec.points), "Exact named cap12 reference endpoints, middle and old manual route props")
    check(same(r!.afterRouteProps, { pcbPaths: [[spec.from,
      { x: spec.points[1].x, y: spec.points[1].y - 20 }, spec.to]], pcbPathRelativeTo: "U_SOC.pin7" }),
      "Exact absolute-to-CPU-origin cap12 reference path projection")
  }
}

/** Same contract and base scope as frozen v3, plus the mandatory named delta. */
export function buildAll49SourceReplay(parentElementInput: ReactNode, plan: All49ReplayPlan): {
  parentElement: ReactNode; element: ReactNode; auditPlan: ReplayAuditPlan; expectedCounts: Record<string, any>;
} {
  validateDelta(plan)
  const base = buildBaseReplay(parentElementInput, plan)
  const beforeCap = snapshotAll49ReplaySource(base.element)
  const propertyEdits = [...base.auditPlan.propertyEdits]
  const changed = new Set<string>()
  // Traverse raw children, preserving their array/singleton shape and every
  // existing key. Another Children.toArray pass would change the base inverse.
  function fork(node: ReactNode): ReactNode {
    if (Array.isArray(node)) {
      const rows = node.map(fork)
      return rows.every((r, i) => r === node[i]) ? node : rows
    }
    if (!isValidElement<Props>(node)) return node
    const beforeProps: Props = { ...node.props }; delete beforeProps.children
    const props: Props = { ...beforeProps }, name = String(props.name ?? "")
    const spec = SPECS.find(r => r.name === name)
    const cap = name === "C_DDR_RAM_12", change = cap || !!spec
    if (cap) {
      check(node.type === "capacitor" && !changed.has(name)
        && props.pcbX === 6 && props.pcbY === 4.7 && props.layer === "bottom" && props.pcbRotation === 180,
        "One exact original C_DDR_RAM_12 capacitor literal")
      props.pcbX = 6.79
    } else if (spec) {
      check(node.type === "trace" && !changed.has(name) && same(beforeProps,
        { name: spec.name, from: spec.from, to: spec.to, thickness: .2, pcbPath: [] }),
        "One exact unchanged captured cap12 .2mm reference literal")
      delete props.pcbPath; delete props.pcbPaths; delete props.pcbPathRelativeTo
      Object.assign(props, plan.cap12HardwareDelta.references.find(r => r.literalTraceName === name)!.afterRouteProps)
    }
    const oldChildren = node.props.children, newChildren = fork(oldChildren)
    if (!change && newChildren === oldChildren) return node
    if (!change) return cloneElement(node, { children: newChildren })
    changed.add(name)
    propertyEdits.push({ name, type: String(node.type), beforeProps, afterProps: { ...props } })
    const exactProps: Props & { key?: string } = { ...props }
    if (node.key !== null) exactProps.key = String(node.key)
    if (own(node.props, "children")) exactProps.children = newChildren
    // Recreate instead of clone: deleted pcbPath must be absent, not retained
    // by React.cloneElement's merge of all original properties.
    return createElement(node.type, exactProps)
  }
  const element = fork(base.element), after = snapshotAll49ReplaySource(element)
  check(changed.size === 3, "Exactly one capacitor and two reference literals changed")
  const differences: string[] = []
  function proveOnlyNamedProps(a: LiteralSnapshot, b: LiteralSnapshot): void {
    check(a.kind === b.kind && a.type === b.type && a.key === b.key && same(a.value, b.value)
      && a.children.length === b.children.length, "Cap12 wrapper preserves every node, key and child position")
    if (!same(a.props, b.props)) {
      const edit = propertyEdits.find(e => e.name === a.props.name && e.type === a.type && changed.has(e.name))
      check(edit && same(a.props, edit.beforeProps) && same(b.props, edit.afterProps), "Only three audited exact property changes")
      differences.push(String(a.props.name))
    }
    a.children.forEach((child, i) => proveOnlyNamedProps(child, b.children[i]))
  }
  proveOnlyNamedProps(beforeCap, after)
  check(differences.length === 3 && new Set(differences).size === 3, "All and only three changed literals accounted")
  const hardwareExpectations = { realComponents: 280, heldRealComponents: 279, movedRealComponents: 1,
    originalCopperLands: 1165, heldCopperLands: 1163, movedCopperLands: 2,
    referencePaths: 165, heldReferencePaths: 163, changedReferencePaths: 2,
    referenceVias: 129, heldReferenceVias: 129, numericSignalPadLocationsHeld: true,
    capturedIdsAreComparisonProvenanceOnly: true, freshCoreDerived: false, sourceHardwareNativeQualified: false }
  const auditPlan: ReplayAuditPlan = { ...base.auditPlan, propertyEdits,
    cap12HardwareDeltaProfile: PROFILE, cap12HardwareDelta: plan.cap12HardwareDelta,
    cap12ChangedLiteralNames: [...changed], cap12HeldHardwareExpectations: hardwareExpectations,
    effectiveConstraintBridge: { ...base.auditPlan.effectiveConstraintBridge,
      cap12HardwareDeltaProfile: PROFILE, cap12HardwareDelta: plan.cap12HardwareDelta,
      cap12HeldHardwareExpectations: hardwareExpectations,
      cap12SourceHardwarePlacementApplied: true, cap12SourceNativeClearanceQualified: false,
      fullBoardPassed: false, all49Accepted: false, fabricationReady: false } }
  const parentSnapshot = snapshotAll49ReplaySource(base.parentElement)
  check(same(inverseAll49ReplaySnapshot(after, auditPlan), parentSnapshot),
    "Exact complete cap12 plus route inverse to the held normalized Source33B parent")
  check(same(inverseAll49ReplayParentNormalization(parentSnapshot, auditPlan), snapshotAll49ReplaySource(parentElementInput)),
    "Exact original parent key-normalization inverse remains required")
  return { ...base, element, auditPlan }
}
