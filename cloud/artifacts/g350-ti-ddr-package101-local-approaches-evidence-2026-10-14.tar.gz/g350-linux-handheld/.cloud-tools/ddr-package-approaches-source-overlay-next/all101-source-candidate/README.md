# All101 package source candidate and scoped owner guards

Prepared from the immutable 98-terminal source-data proposal plus the separately selected RAM24/25/26 paths, `FINE_RAM3_PROPOSAL.json` SHA256 `e887bd6090242fd0b08d8e3be9de11ac5634366c00afd977c394d95a9c8cda08`. No board/Core/native/React imports, source evaluation, typecheck, tests, routing, export or worker ran while preparing these files.

The grouped data has 101 package terminals and 72 canonical sites: 65 new vias and seven reused accepted HS vias. RAM24 reuses HS54 at (1.2,9.8); RAM25 uses a new GND via at (0.4,8.975); RAM26 uses a new power via at (-0.4,9.775). These three Top paths are 0.15 mm; the first 98 retain their 0.2 mm widths. The source appends 65 via and 101 trace elements (166 additions) to the immutable accepted HS64 base. Candidate counts are 129 physical vias,165 physical traces,280 real parts and1,161 original pads. All 49 DDR requests remain unchanged. These counts describe an unexecuted source candidate, not a passed Core or physical-routing result.

Every original numeric pad has its own `padXY`; selected sites use `viaXY`. Canonical group names for the initial 63 new sites are preserved; reused groups keep their original accepted source selector. The overlay anchors each trace's relative interior points on the canonical via's unrotated Top alias, reverses interiors toward the package and lets Core supply both actual endpoints. The proof permits exact forward or reverse paths and either exact authored selector direction.

Consumer APIs are:

```js
const proof = proveSharedPackageLoops({ proposal, goldenCore, freshCore })
const errors = checkG350ProvedViaBranchManufacturingClearance(freshCore, proof)
```

The caller must hash-bind accepted golden Core384, its passing native/graph receipt, the grouped source and a fresh actual Core. The proof requires unchanged old64 barrels/stubs, numeric source/PCB/pad identity and rails, exact Top copper widths/centerlines/endpoints, applicable actual path-length limits, canonical aliases/full-through dimensions and actual Circuit JSON graph links. CPU sharing of up to four package terminals is a candidate policy, not a TI exception claim. Special VSS domains and analog/control ground ties retain only the2.54 mm proposal radius; only literal CPU VDDS_DDR/VSS and RAM power/GND terminals carry the applicable TI path-length bounds.

Only the selected RAM25 GND via can receive the explicit oldHS8 contact registrations. The actual old strip must be exactly `pcb_trace_55/source_trace_987/source_net_0` on Bottom; the actual pad must be exactly `pcb_smtpad_729/pcb_port_730/source_port_730/source_component_132`, C_DDR_RAM_8 pin2 on Bottom. Both remain exact original records. The new package pad/Top stub/via graph and old cap/Bottom stub/owned-via graph must already be proved.

The successor computes contact from actual geometry, ignoring raw claimed distance/chord values. It requires the full strip contact chord to lie inside the finite straight segment and be at least0.1016 mm. The actual new drill must remain wholly clear of both old strip and old pad. The actual circle/rectangle and circle/finite-strip intersections then have positive connected contact patches, unchanged by subtracting the disjoint drill disk. The standard annulus retains0.1016 mm radial copper. This source proof does not replace fresh native/CAD, filled references or high-frequency qualification.

Manufacturing consumes only private, branded proof registries bound to the exact unchanged raw Core object/content. It checks the historical via/trace geometry and0.1016 mm rule, exempting only proved source-trace/via pairs. Its additional all-net via-to-pad rule checks every SMT and plated copper land: circles exactly; polygons/pills/rotated rectangles conservatively by actual AABB. Only the privately proved RAM25 via↔pad729 positive contact is exempted. No global same-net exemption, owner-field rewrite or legacy baseline waiver is introduced. Any historical baseline collision remains an explicit failure requiring separate review. Unsupported shapes fail rather than being skipped.

Old helpers, 98-terminal candidate, frozen Core/evidence, native checker patch and hardware sources are preserved. The whole-original-record/BREP forward comparison remains a separate required Root gate. `referenceQualified=false`, `accepted49=false`, `fabricationReady=false`.
