from pathlib import Path
import json,hashlib,stat,copy
old=Path('/tmp/g350-source26-cad52-future-walker-required-status-successor-sourceonly-next');new=Path('/tmp/g350-source26-cad52-concrete-proposal-metadata-successor-sourceonly-next');assert not new.exists();new.mkdir(mode=0o700)
def pin(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def write(p,b):
 with p.open('xb')as f:f.write(b)
 p.chmod(0o600)
m=json.loads((old/'SOURCE-manifest.json').read_text())
for r in m['files']:
 assert pin(r['path'])==r;write(new/Path(r['path']).name,Path(r['path']).read_bytes())
def remap(v):
 if isinstance(v,dict):
  if all(k in v for k in('path','sha256','bytes','mode'))and Path(v['path']).parent==old:
   q=copy.deepcopy(v);q.update(pin(new/Path(v['path']).name));return q
  return{k:remap(x)for k,x in v.items()}
 if isinstance(v,list):return[remap(x)for x in v]
 return v
m=remap(m);del m['exactUnresolvedMetadataRows'];m['historicalUnexecutedEmbeddedIllustrativeNullRowsManifestPin']=pin(old/'SOURCE-manifest.json');m['illustrativeNullRowsExistOnlyInsidePinnedDataAndGuardLiteral']=True;m['externalFiles'] +=[pin(old/'SOURCE-manifest.json'),pin(Path(__file__))];m['externalFileCount']=len(m['externalFiles'])
def walk(v):
 if isinstance(v,dict):
  if all(k in v for k in('path','sha256','bytes','mode')):yield v
  else:
   for x in v.values():yield from walk(x)
 elif isinstance(v,list):
  for x in v:yield from walk(x)
rows=list(walk(m));assert not any(any(r[k]is None for k in('path','sha256','bytes','mode'))for r in rows)
for r in rows:assert pin(r['path'])=={k:r[k]for k in('path','sha256','bytes','mode')}
write(new/'SOURCE-manifest.json',(json.dumps(m,indent=2)+'\n').encode())
s=(new/'run-source26-cad52-root.proposal.py').read_text();assert "assert proposal['status']=="+repr(m['status'])in s
print(json.dumps(dict(manifest=pin(new/'SOURCE-manifest.json'),guard=pin(new/'run-source26-cad52-root.proposal.py'),concreteProposalRowOccurrences=len(rows),allConcreteProposalRowsActuallyBound=True),indent=2))
