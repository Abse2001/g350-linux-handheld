"use strict"

// Pure source-bound JSON projection. No I/O, imports, routing, or top-level calls.
function copyOwnData(value, active = new Set()) {
  if (value === undefined || value === null || typeof value === "boolean" || typeof value === "string") return value
  if (typeof value === "number") { if (!Number.isFinite(value)) throw Error("Finite JSON number required"); return value }
  if (typeof value !== "object") throw Error("Own plain data required")
  const array = Array.isArray(value), prototype = Object.getPrototypeOf(value)
  if (array ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null) throw Error("Plain data required")
  if (active.has(value)) throw Error("Cyclic data refused")
  active.add(value)
  const result = array ? [] : Object.create(null)
  for (const key of Reflect.ownKeys(value)) {
    if (array && key === "length") continue
    if (typeof key !== "string" || key === "__proto__") throw Error("Plain key required")
    const descriptor = Object.getOwnPropertyDescriptor(value, key)
    if (!descriptor || !("value" in descriptor) || !descriptor.enumerable) throw Error("Enumerable own data required")
    if (array && !/^(0|[1-9][0-9]*)$/.test(key)) throw Error("Dense plain array required")
    result[key] = copyOwnData(descriptor.value, active)
  }
  if (array) {
    const descriptor = Object.getOwnPropertyDescriptor(value, "length")
    if (!descriptor || !("value" in descriptor) || result.length !== descriptor.value ||
        Reflect.ownKeys(value).length !== descriptor.value + 1) throw Error("Dense array required")
  }
  active.delete(value)
  return result
}

function deriveClockGroupProjection(freshInput, jointGeometry) {
  const fresh = copyOwnData(freshInput), joint = copyOwnData(jointGeometry)
  if (!Array.isArray(fresh.connections) || fresh.connections.length !== 49 ||
      !Array.isArray(fresh.traces) || fresh.traces.length !== 2 ||
      !Array.isArray(joint.connections) || joint.connections.length !== 49 ||
      !Array.isArray(joint.traces) || joint.traces.length !== 96) throw Error("Exact source-bound49/2/joint49/96 required")
  const originalByName = new Map(fresh.connections.map(connection => [connection.name, connection]))
  if (originalByName.size !== 49 || new Set(joint.connections.map(connection => connection.name)).size !== 49 ||
      joint.connections.some(connection => !originalByName.has(connection.name))) throw Error("Exact original signal ownership required")
  // bus-lanes-pipeline-solver.ts:811-814,859-865. Preserve every unknown
  // trace field and every route point; source_trace_id is the sole added field.
  const escapes = joint.traces.map(trace => {
    if (!originalByName.has(trace.connection_name)) throw Error("Unknown local trace owner")
    return { ...trace, source_trace_id: originalByName.get(trace.connection_name).source_trace_id ?? trace.connection_name }
  })
  const laneInput = { ...fresh, connections: joint.connections, traces: [...fresh.traces, ...escapes] }
  // Mirror independentBusGroups prerequisites and exact Inner1 projection.
  if (!Array.isArray(laneInput.buses) || laneInput.buses.length < 2) throw Error("Independent groups prerequisite required")
  const constrained = new Set([...laneInput.buses.flatMap(bus => bus.connectionNames),
    ...(laneInput.differentialPairs ?? []).flatMap(pair => pair.connectionNames)])
  if (laneInput.connections.some(connection => !constrained.has(connection.name) ||
      connection.pointsToConnect.some(point => point.layer !== connection.pointsToConnect[0].layer)) ||
      new Set(laneInput.connections.map(connection => connection.pointsToConnect[0].layer)).size < 2)
    throw Error("Exact independent-layer prerequisites required")
  const connections = laneInput.connections.filter(connection => connection.pointsToConnect[0].layer === "inner1")
  const names = new Set(connections.map(connection => connection.name))
  const buses = laneInput.buses.filter(bus => bus.connectionNames.some(name => names.has(name)))
  const differentialPairs = (laneInput.differentialPairs ?? []).filter(pair => pair.connectionNames.some(name => names.has(name)))
  if (buses.some(bus => bus.connectionNames.some(name => !names.has(name))) ||
      differentialPairs.some(pair => pair.connectionNames.some(name => !names.has(name))) || differentialPairs.length > 1)
    throw Error("Whole original groups required")
  if (buses.length !== 1 || buses[0].busId !== "DDR_COMMAND_CLOCK" || connections.length !== 26 ||
      differentialPairs.length !== 1 || differentialPairs[0].connectionNames.join("\0") !== "source_trace_33\0source_trace_34")
    throw Error("Exact source-derived command/clock group required")
  return { ...laneInput, connections, buses, differentialPairs }
}

function verifyClockGroupProjection(detachedSceneInput, detachedExpected) {
  // Copy only detached own data. Invalid accessors are refused, never invoked.
  // Values, all unknown fields, key order, array order, and own undefined fields
  // must match. Retain no caller graph after this synchronous comparison.
  try {
    const actual = copyOwnData(detachedSceneInput), expected = copyOwnData(detachedExpected)
    function equal(a, b) {
      if (a === b) return true
      if (!a || !b || typeof a !== "object" || typeof b !== "object" || Array.isArray(a) !== Array.isArray(b)) return false
      const first = Reflect.ownKeys(a), second = Reflect.ownKeys(b)
      return first.length === second.length && first.every((key, index) => key === second[index] && equal(a[key], b[key]))
    }
    return equal(actual, expected)
  } catch { return false }
}

module.exports = { deriveClockGroupProjection, verifyClockGroupProjection }
