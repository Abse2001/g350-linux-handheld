 assert out.parent==Path('/tmp')and out.name.startswith('g350-source29-three-stage-root-')and out.resolve()==out and not out.exists()and not out.is_symlink()
 with(ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  prior=closed52();assert prior['actualClosedScopeCount']==52
  identity_before=guard_identity();_,native_before,board_before,solver_before,_=c.guard.checked();bindings();git_before=git_inventory();assert git_before==base['gitMetadataFiles']
  assert board_before['treeSha256']==stage['boardSdkTreeSha256']and solver_before['treeSha256']==stage['solverSdkTreeSha256']
  workspace_floor=shutil.disk_usage('/workspace').free;out.mkdir(mode=0o700)
  phases=[];prior_outputs=[];capture_pin=None;batch_passed=False;batch_error=None;fresh_history_authenticated_once=True
  for phase in('capture','types','core'):
   phase_dir=out/phase;phase_dir.mkdir(mode=0o700);(phase_dir/'bun-cache').mkdir(mode=0o700);(phase_dir/'tmp').mkdir(mode=0o700);output=phase_dir/'output';output.mkdir(mode=0o700)
   policy=batch29['phasePolicies'][phase];assert policy=={'wallSeconds':{'capture':60,'types':120,'core':180}[phase],'rssBytes':1073741824 if phase=='capture'else 2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
   paths={};environment={'NO_COLOR':'1','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(phase_dir/'bun-cache'),'TMPDIR':str(phase_dir/'tmp')}
   bun=str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe')
   if phase=='capture':
    paths=dict(capture=output/'source-capture.json',diagnostic=output/'source-tree-diagnostic.json');command=[bun,'--smol',proposal['promoted29CapturePin']['path'],str(paths['capture']),str(paths['diagnostic'])];environment['G350_SOURCE29_SOURCE_ROOT_GUARDED']='1'
   elif phase=='types':command=['bash',proposal['promoted29TypesPin']['path']];environment['G350_SOURCE29_TYPES_ROOT_GUARDED']='1'
   else:
    assert capture_pin is not None;paths=dict(raw=output/'raw-core.json',controls=output/'core-controls.json');command=[bun,'--smol',proposal['promoted29CorePin']['path'],str(paths['raw']),str(paths['controls']),capture_pin['path']];environment['G350_SOURCE29_CORE_ROOT_GUARDED']='1'
   execution=None;run_error=post_error=inspection_error=scope_error=None;result=None;empty=None;phase_held=False;phase_passed=False;phase_before=None;phase_after=None
   def invariant_check():
    bindings();no_git_redirects();assert guard_identity()==identity_before and git_inventory()==git_before and shutil.disk_usage('/workspace').free>=workspace_floor
    for row in prior_outputs:binding(row)
    assert all(row['passed']is True and row['ownedGroupEmptyActuallyObserved']is True for row in phases)
    for row in phases:assert c.guard.process_scope.owned(row['execution']['pgid'])==[]
   def prefork(memory):
    invariant_check();assert memory['current']+policy['rssBytes']+1073741824<policy['sharedBytes']and shutil.disk_usage('/tmp').free>=536870912
   try:
    invariant_check();_,n0,b0,s0,_=c.guard.checked();phase_before=dict(native=n0,board=b0,solver=s0);assert n0==native_before and b0==board_before and s0==solver_before
    execution=process_runner.run_guarded(command,str(c.BOARD),phase_dir/'owned',policy,environment,before_spawn=prefork)
   except BaseException as error:
    run_error=type(error).__name__+': '+str(error)
    if(phase_dir/'owned/execution.json').is_file():execution=read(phase_dir/'owned/execution.json')
   try:
    invariant_check();_,n1,b1,s1,_=c.guard.checked();phase_after=dict(native=n1,board=b1,solver=s1);assert phase_before==phase_after and n1==native_before and b1==board_before and s1==solver_before
    phase_held=True
   except BaseException as error:post_error=type(error).__name__+': '+str(error)
   try:
    assert isinstance(execution,dict);empty=c.guard.process_scope.owned(execution['pgid'])==[]
    h.finite(execution,0);assert execution['policy']==policy and execution['command']==command and execution['currentGuardPid']==identity_before['pid']and empty is True and 'guardError'not in execution
    assert guard_identity()==identity_before and run_error is post_error is None and phase_held is True
    if phases:assert phases[-1]['execution']['endedAt']<=execution['startedAt']
    if phase=='capture':
     assert {p.name for p in output.iterdir()}=={'source-capture.json','source-tree-diagnostic.json'};result=inspect29_capture(paths);capture_pin=result['sourceCapturePin']
    elif phase=='types':
     assert capture_pin is not None and not list(output.iterdir());binding(capture_pin);result=dict(strictNoEmitTypecheckNatural0=True,actualPriorCapturePin=capture_pin)
    else:
     assert {p.name for p in output.iterdir()}=={'raw-core.json','core-controls.json'};result=inspect29_core(paths,capture_pin)
    phase_passed=True
   except BaseException as error:inspection_error=type(error).__name__+': '+str(error)
   child_natural=bool(isinstance(execution,dict)and type(execution.get('exitCode'))is int and execution['exitCode']>=0 and execution.get('diagnosticStopped')is False and not execution.get('stopReasons')and execution.get('cleanupOwnedGroupEmpty')is True and isinstance(execution.get('oomDelta'),dict)and bool(execution['oomDelta'])and not any(execution['oomDelta'].values())and empty is True)
   phase_outputs=[]
   for path in sorted(output.iterdir()):
    try:phase_outputs.append(file_row(path))
    except BaseException as error:scope_error=type(error).__name__+': '+str(error);phase_passed=False
   try:identity_after=guard_identity()
   except BaseException as error:identity_after=None;scope_error=type(error).__name__+': '+str(error);phase_passed=False
   row=dict(phase=phase,command=command,execution=execution,runFailure=run_error,postverificationFailure=post_error,resultInspectionFailure=inspection_error,outputBindingFailure=scope_error,guardIdentityBefore=identity_before,guardIdentityAfter=identity_after,sourceAndDependenciesHeld=phase_held,phaseSnapshotsBefore=phase_before,phaseSnapshotsAfter=phase_after,ownedGroupEmptyActuallyObserved=empty,stageNaturallyCompleted=child_natural,ownedChildNatural0=child_natural and execution['exitCode']==0,passed=phase_passed,result=result,outputFiles=phase_outputs,CoreCalls=(1 if phase_passed else None)if phase=='core'else 0,CoreChildInvocations=1 if phase=='core'and isinstance(execution,dict)and type(execution.get('pid'))is int else 0,nativeCalls=0,originalApiCalls=0,cliCalls=0,cadCalls=0,Source29Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingPassed=False,fabricationReady=False)
   pp=phase_dir/'POSTAUDIT.json';write(pp,row);row['postauditPath']=str(pp);row['postauditSha256']=sha(pp);phases.append(row)
   if not phase_passed:batch_error='Phase '+phase+' failed; later phases not attempted';break
   prior_outputs.extend(phase_outputs+[file_row(pp)])
  final_error=None;native_after=board_after=solver_after=None
  try:
   bindings();no_git_redirects();assert guard_identity()==identity_before and git_inventory()==git_before and shutil.disk_usage('/workspace').free>=workspace_floor
   _,native_after,board_after,solver_after,_=c.guard.checked();assert native_before==native_after and board_before==board_after and solver_before==solver_after
   for row in prior_outputs:binding(row)
   for row in phases:assert isinstance(row['execution'],dict)and c.guard.process_scope.owned(row['execution']['pgid'])==[]
   batch_passed=len(phases)==3 and all(row['passed']is True for row in phases)
  except BaseException as error:final_error=type(error).__name__+': '+str(error);batch_passed=False
  post=dict(scope='ROOT_SOURCE26_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH52_AUTHENTIC_PRIOR_CLOSURES',phase='capture-types-core-batch',sourceManifestSha256=proposal['promoted29ManifestPin']['sha256'],rootGuardProposalManifestSha256=source_sha,actualClosedPriorScopes=prior,historyAuthenticatedOnceBeforeBatch=fresh_history_authenticated_once,phases=phases,orderedPhaseNames=[r['phase']for r in phases],expectedPhaseNames=['capture','types','core'],notAttemptedPhaseNames=[p for p in('capture','types','core')if p not in[r['phase']for r in phases]],sameGuardIdentity=identity_before,guardIdentityHeldAcrossChildren=all(r['guardIdentityBefore']==r['guardIdentityAfter']==identity_before for r in phases),allOwnedGroupsIndependentlyObservedEmpty=bool(phases)and all(r['ownedGroupEmptyActuallyObserved']is True for r in phases),eachAttemptedChildNaturallyCompleted=bool(phases)and all(r['stageNaturallyCompleted']is True for r in phases),allThreeChildrenNaturallyCompleted=len(phases)==3 and all(r['stageNaturallyCompleted']is True for r in phases),sourceAndDependenciesHeld=final_error is None and all(r['sourceAndDependenciesHeld']is True for r in phases),dependenciesBefore=board_before,dependenciesAfter=board_after,solverDependenciesBefore=solver_before,solverDependenciesAfter=solver_after,workspaceFreeBytesBefore=workspace_floor,workspaceFreeBytesFloorHeld=final_error is None,gitMetadataHeld=final_error is None,batchFailure=batch_error,finalVerificationFailure=final_error,passed=batch_passed,passedMeansCaptureStrictTypesAndRawCore29Only=True,batchScopeContainsThreeSerialOwnedChildren=True,newRoutesAdopted=0,hardwareAcceptanceCheckpointUnchanged=True,CoreCalls=next((r['CoreCalls']for r in phases if r['phase']=='core'),0),captureChildInvocations=sum(r['phase']=='capture'and isinstance(r['execution'],dict)and type(r['execution'].get('pid'))is int for r in phases),typesChildInvocations=sum(r['phase']=='types'and isinstance(r['execution'],dict)and type(r['execution'].get('pid'))is int for r in phases),CoreChildInvocations=sum(r['CoreChildInvocations']for r in phases),nativeCalls=0,originalApiCalls=0,cliCalls=0,cadCalls=0,Source29Accepted=False,referenceQualified=False,electricalTimingPassed=False,all49Accepted=False,fabricationReady=False,toolSessionCollected=False)
  pp=out/'POSTAUDIT.json';write(pp,post);print(json.dumps(dict(passed=batch_passed,scope=post['scope'],postauditPath=str(pp),postauditSha256=sha(pp),phaseOutcomes=[dict(phase=r['phase'],passed=r['passed'],execution=r['execution'])for r in phases])))
 return 0 if batch_passed else 2

if __name__=='__main__':raise SystemExit(main())
