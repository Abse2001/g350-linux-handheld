import {Children, cloneElement, isValidElement, type ReactElement, type ReactNode} from "react"
import {buildV10Source} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v10-ca-top-bytes-bottom-prefork-successor-next/source/experiments/am3352-g350-ti-top-bottom-ddr-v10-ca-top-bytes-bottom-layout.circuit"
import policy from "./v11-layer-policy.json"

type Props = Record<string, unknown> & {name?: string; children?: ReactNode}
const equal = (a: unknown, b: unknown, label: string) => {
  if (JSON.stringify(a) !== JSON.stringify(b)) throw Error("V11 final authored props mismatch: " + label)
}
/** Source-only final policy overlay: no Circuit/Core/render/router call.
 * V10 has already applied every geometry and final policy wrapper. Only the
 * two final BYTE1 layer-list props change; the element inventory stays intact. */
export function buildV11Source() {
  const base = buildV10Source()
  const groups = new Map<string, Record<string, unknown>>()
  const pairs = new Map<string, Record<string, unknown>>()
  let boardCount = 0
  function apply(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const p = {...node.props}
    const group = policy.groups.find(g => g.nativeBus.busId === p.name)
    const pair = policy.pairs.find(g => g.name === p.name)
    if (group) {
      const spec = group.nativeBus
      if (node.type !== "bus" || groups.has(spec.busId)) throw Error("Exactly four literal original class buses required")
      const before = base.authoredPolicyProof.groups.find(g => g.busId === spec.busId)
      if (!before) throw Error("Missing original V10 final group proof")
      const original: Record<string, unknown> = {busId: spec.busId, connections: p.connections,
        pcbTraceWidth: p.pcbTraceWidth, pcbAllowedLayers: p.pcbAllowedLayers, preferredLayers: p.preferredLayers}
      for (const key of ["maxLengthSkew", "minLength", "maxLength"] as const)
        if (p[key] !== undefined) original[key] = p[key]
      equal(original, before, spec.busId + " original V10 final props")
      if (spec.busId === "DDR_BYTE1") {
        equal(p.pcbAllowedLayers, ["bottom"], "original BYTE1 allowed")
        equal(p.preferredLayers, ["bottom"], "original BYTE1 preferred")
        p.pcbAllowedLayers = ["top"]
        p.preferredLayers = ["top"]
      }
      equal(p.connections, group.logicalConnections, spec.busId + " roster")
      equal(p.pcbAllowedLayers, spec.allowedLayers, spec.busId + " allowed")
      equal(p.preferredLayers, spec.preferredLayers, spec.busId + " preferred")
      equal(p.pcbTraceWidth, spec.traceWidth, spec.busId + " width")
      for (const key of ["maxLengthSkew", "minLength", "maxLength"] as const)
        equal(p[key], (spec as Record<string, unknown>)[key], spec.busId + " " + key)
      groups.set(spec.busId, {...original, pcbAllowedLayers: p.pcbAllowedLayers, preferredLayers: p.preferredLayers})
    }
    if (pair) {
      if (node.type !== "differentialpair" || pairs.has(pair.name)) throw Error("Exactly three original literal pairs required")
      equal([p.positiveConnection, p.negativeConnection], pair.logicalConnections, pair.name + " partners")
      equal(p.maxLengthSkew, pair.nativePair.lengthTolerance, pair.name + " skew")
      equal(p.pcbTraceGap, pair.nativePair.traceGap, pair.name + " gap")
      const snapshot = {name: pair.name, ownerBusId: pair.ownerBusId,
        positiveConnection: p.positiveConnection, negativeConnection: p.negativeConnection,
        maxLengthSkew: p.maxLengthSkew, pcbTraceGap: p.pcbTraceGap}
      equal(snapshot, base.authoredPolicyProof.pairs.find(g => g.name === pair.name), pair.name + " V10 proof")
      pairs.set(pair.name, snapshot)
    }
    if (node.type === "board") {
      boardCount++
      equal(p.layers, 4, "physical layers")
      equal(p.routeRemaining, false, "routing-disabled source")
    }
    return cloneElement(node as ReactElement<Props>, p, ...Children.toArray(node.props.children).map(apply))
  }
  const element = apply(base.element)
  if (groups.size !== 4 || pairs.size !== 3 || boardCount !== 1) throw Error("Original four classes, three pairs and one board required")
  return {element, authoredPolicyProof: {...base.authoredPolicyProof,
    groups: policy.groups.map(g => groups.get(g.nativeBus.busId)!), pairs: policy.pairs.map(g => pairs.get(g.name)!)}}
}
export default () => buildV11Source().element
