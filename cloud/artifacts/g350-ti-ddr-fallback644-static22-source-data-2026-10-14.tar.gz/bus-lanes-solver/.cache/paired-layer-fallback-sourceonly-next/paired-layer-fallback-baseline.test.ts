import { expect, test } from "bun:test"
import { BusLanesSolver } from "/workspace/bus-lanes-solver/lib/bus-lanes-solver"
import { makeFixture, terminalLayers } from "./fixture"

// Root must retain this expected red result. No implementation is patched.
test("a coupled pair falls back from a blocked layer to a clear available layer", () => {
  const solver = new BusLanesSolver(
    makeFixture(),
    { denseSearch: true, maxSearchIterations: 20000 },
    terminalLayers(),
  )
  solver.solve()
  expect(solver.error).toBeNull()
  expect(solver.solved).toBe(true)
  expect(solver.traces).toHaveLength(2)
})
