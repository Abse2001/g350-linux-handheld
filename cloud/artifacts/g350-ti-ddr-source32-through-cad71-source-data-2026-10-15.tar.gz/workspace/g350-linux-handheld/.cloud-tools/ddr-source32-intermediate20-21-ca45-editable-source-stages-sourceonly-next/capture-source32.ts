/** Root-only future32 capture; no Circuit/Core construction or raw-ID edits. */
import { Children,Fragment,cloneElement,isValidElement,type ReactElement,type ReactNode } from "react"
import { readFileSync,writeFileSync,existsSync,lstatSync } from "node:fs"
import { createHash } from "node:crypto"
import assert from "node:assert/strict"
import { buildOwnerMoved29Source } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-source29-joint7-ca6-ca18-reset-editable-source-stages-sourceonly-next/source29.circuit"
import { buildOwnerIntermediate32Source } from "./source32.circuit"
import proposalData from "./source32-proposal.json"
import type { Source32Proposal } from "./source32-types"
const proposal=proposalData as unknown as Source32Proposal
const [output,diagnostic,...extra]=process.argv.slice(2)
assert.equal(process.env.G350_SOURCE32_SOURCE_ROOT_GUARDED,"1");assert.equal(process.versions.bun,"1.3.14")
assert(output&&diagnostic&&extra.length===0&&output!==diagnostic&&!existsSync(output)&&!existsSync(diagnostic))
assert(proposal.actualParent29Qualification!==null&&proposal.actualParent29Capture!==null&&proposal.jointIntermediateViaGeometryPeer!==null&&proposal.source45IndependentGeometryPeer!==null,"Future29 qualification/capture and final21 peer must be authenticated in a new activation successor")
assert(Object.values(proposal.actualParent29Stages).every(pin=>pin!==null))
const sha=(v:string|Buffer)=>createHash("sha256").update(v).digest("hex")
assert.equal(sha(readFileSync(proposal.promotedParent29Source.path)),proposal.promotedParent29Source.sha256)
const parentManifest=JSON.parse(readFileSync(proposal.promotedParent29Source.path,"utf8")),parentBindings=parentManifest.expandedHeldSourceAndControllerClosure as Array<{path:string;sha256:string;bytes:number;mode:number}>
assert.equal(parentBindings.length,186)
for(const row of parentBindings){const s=lstatSync(row.path);assert(s.isFile()&&!s.isSymbolicLink());assert.equal(s.size,row.bytes);assert.equal(s.mode&0o777,row.mode);assert.equal(sha(readFileSync(row.path)),row.sha256)}
for(const pin of [...proposal.sealedIntermediateGeometryPins,proposal.jointIntermediateViaGeometryPeer!,proposal.source45IndependentGeometryPeer!])assert.equal(sha(readFileSync(pin.path)),pin.sha256)
type Props = Record<string, unknown> & { children?: ReactNode }
type Row = { kind: "literal" | "fragment" | "primitive" | "unsupported"; type: string; key: string | null; props: Record<string, unknown>; children: Row[]; value?: unknown }
function identity(node: ReactNode): ReactNode {
  if (!isValidElement<Props>(node)) return node
  return cloneElement(node as ReactElement<Props>, { ...node.props }, ...Children.toArray(node.props.children).map(identity))
}
function snapshot(node: ReactNode): Row {
  if (!isValidElement<Props>(node)) {
    const allowed = node === null || node === undefined || ["boolean", "string", "number"].includes(typeof node)
    return { kind: allowed ? "primitive" : "unsupported", type: typeof node, key: null, value: node, props: {}, children: [] }
  }
  const { children, ...props } = node.props, actualType: unknown = node.type
  const kind = typeof actualType === "string" ? "literal" : actualType === Fragment ? "fragment" : "unsupported"
  return { kind, type: kind === "literal" ? actualType as string : kind === "fragment" ? "React.Fragment" : `${typeof actualType}:${String(actualType)}`, key: node.key, props, children: Children.toArray(children).map(snapshot) }
}
const flatten = (row: Row): Row[] => [row, ...row.children.flatMap(flatten)]
const clone = (row: Row): Row => ({ ...row, props: { ...row.props }, children: row.children.map(clone) })
function canonical(v: unknown): string {
  if (Array.isArray(v)) return `[${v.map(canonical).join(",")}]`
  if (v && typeof v === "object") return `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical((v as Record<string, unknown>)[k])}`).join(",")}}`
  if (typeof v === "function") return `function:${v.toString()}`
  if (typeof v === "symbol") return `symbol:${String(v)}`
  return JSON.stringify(v) ?? "undefined"
}
const replacer = (_key: string, v: unknown) => typeof v === "function" ? { diagnosticFunction: v.name, sourceSha256: sha(v.toString()) }
  : typeof v === "symbol" ? { diagnosticSymbol: String(v), globalSymbolKey: Symbol.keyFor(v) ?? null } : v
const normalizedJson = (v: unknown) => JSON.parse(JSON.stringify(v, replacer))
const counts = (rows: Row[]) => ({ reactElements: rows.filter(r => r.kind === "literal" || r.kind === "fragment").length, literalStrings: rows.filter(r => r.kind === "literal").length, fragments: rows.filter(r => r.kind === "fragment").length, primitiveChildren: rows.filter(r => r.kind === "primitive").length, unsupported: rows.filter(r => r.kind === "unsupported").length })

const parent=buildOwnerMoved29Source(),source=buildOwnerIntermediate32Source()
const actualParent29=snapshot(parent.element),before=snapshot(identity(parent.element)),after=snapshot(source.element)
const oldRows=flatten(before),newRows=flatten(after),plan=proposal.source32Delta
writeFileSync(diagnostic,JSON.stringify({scope:"ACTUAL_SOURCE32_AND_PARENT29_BEFORE_INVERSE_ASSERTIONS",actualParent29Tree:actualParent29,keyNormalizedParent29Tree:before,actualProposedSource32Tree:after,beforeCounts:counts(oldRows),afterCounts:counts(newRows),inverseChecksExecuted:false,circuitConstructed:false,coreRendered:false,all49Accepted:false,fabricationReady:false},replacer)+"\n",{flag:"wx",mode:0o600})
const actualParent29CapturePin=proposal.actualParent29Capture!
assert.equal(sha(readFileSync(actualParent29CapturePin.path)),actualParent29CapturePin.sha256)
const actualParentCapture=JSON.parse(readFileSync(actualParent29CapturePin.path,"utf8"))
assert(actualParentCapture.passed===true&&actualParentCapture.fullInverseSourceTreePassed===true)
assert.equal(canonical(normalizedJson(actualParent29)),canonical(actualParentCapture.actualSourceTree),"Evaluated promoted29 exactly matches genuinely collected parent29 capture")
assert.equal(counts(oldRows).unsupported,0);assert.equal(counts(newRows).unsupported,0)
assert.equal(counts(oldRows).reactElements,2278);assert.equal(counts(newRows).reactElements,2286)
assert.equal(counts(newRows).literalStrings-counts(oldRows).literalStrings,8)
assert.equal(counts(newRows).fragments,counts(oldRows).fragments);assert.equal(counts(newRows).primitiveChildren,counts(oldRows).primitiveChildren)
const one=(rs:Row[],label:string)=>{assert.equal(rs.length,1,label);return rs[0]}
const named=(rs:Row[],name:string)=>one(rs.filter(r=>r.kind==="literal"&&r.props.name===name),name)
const fields=["pcbPath","pcbPaths","pcbPathRelativeTo"]as const
const omit=(p:Record<string,unknown>,keys:readonly string[])=>Object.fromEntries(Object.entries(p).filter(([k])=>!keys.includes(k)))
for(const change of plan.routeChanges){
 const old=named(oldRows,change.logicalName),now=named(newRows,change.logicalName)
 assert.equal(now.type,"trace");assert.deepEqual(omit(now.props,fields),omit(old.props,fields));assert.deepEqual(Object.fromEntries(fields.filter(k=>old.props[k]!==undefined).map(k=>[k,old.props[k]])),change.beforeRouteProps)
 assert.equal(now.props.pcbPath,undefined);assert.deepEqual(now.props.pcbPaths,change.after.newPcbPaths);assert.equal(now.props.pcbPathRelativeTo,change.after.newPcbPathRelativeTo)
}
const extraNames=plan.newIntermediateCarrierVias.map(v=>v.viaName)
for(const v of plan.newIntermediateCarrierVias){
 assert.equal(oldRows.filter(r=>r.props.name===v.viaName).length,0)
 const extraVia=named(newRows,v.viaName);assert.equal(extraVia.type,"via");assert.deepEqual(extraVia.props,{name:v.viaName,pcbX:v.xy.x,pcbY:v.xy.y,fromLayer:"top",toLayer:"bottom",outerDiameter:.4572,holeDiameter:.254,tented:"top_and_bottom_tented"})
 assert.equal(extraVia.children.length,1);assert.equal(extraVia.children[0].type,"port");assert.deepEqual(extraVia.children[0].props,{name:"inner2",layer:"inner2"});assert.deepEqual(extraVia.children[0].children,[])
}
const cpuRequests=plan.newSixInnerPorts.filter(r=>!extraNames.includes(r.viaName))
assert.equal(cpuRequests.length,4)
for(const request of cpuRequests){
 const cpuOld=named(oldRows,request.viaName),cpuNew=named(newRows,request.viaName)
 assert.deepEqual(cpuNew.props,cpuOld.props);assert.equal(cpuOld.children.length,0);assert.equal(cpuNew.children.length,1);assert.equal(cpuNew.children[0].type,"port");assert.deepEqual(cpuNew.children[0].props,{name:"inner2",layer:"inner2"});assert.deepEqual(cpuNew.children[0].children,[])
}
for(const local of plan.localSuppressions){const a=named(oldRows,local.traceName),b=named(newRows,local.traceName);assert.deepEqual(a.props.pcbPath,[]);assert.equal(b.props.pcbPath,undefined);assert.deepEqual(omit(a.props,["pcbPath"]),omit(b.props,["pcbPath"]))}
const restored=clone(after),untouched=canonical(after)
function removeExtra(row:Row){row.children=row.children.filter(c=>!extraNames.includes(String(c.props.name)));row.children.forEach(removeExtra)}
removeExtra(restored);const restoredRows=flatten(restored)
function restoreProps(name:string,keys:readonly string[]){const a=named(restoredRows,name),b=named(oldRows,name);for(const k of keys){delete a.props[k];if(Object.prototype.hasOwnProperty.call(b.props,k))a.props[k]=b.props[k]}}
for(const change of plan.routeChanges)restoreProps(change.logicalName,fields);for(const local of plan.localSuppressions)restoreProps(local.traceName,["pcbPath"])
for(const request of cpuRequests)named(restoredRows,request.viaName).children=named(oldRows,request.viaName).children.map(clone)
assert.equal(canonical(restored),canonical(before),"Full inverse to every parent29 child/key/property: three routes, six local suppressions, four existing Ports and two named vias+Ports only")
assert.equal(canonical(after),untouched)
for(const[type,n]of [["via",229],["port",52],["trace",1195],["bus",8]]as const)assert.equal(newRows.filter(r=>r.kind==="literal"&&r.type===type).length,n)
for(const original of proposal.all49OriginalLogicalTraces as Record<string,any>[]){const n=named(newRows,original.name);assert.equal(n.type,"trace");assert.equal(n.props.from,original.from);assert.equal(n.props.to,original.to)}
writeFileSync(output,JSON.stringify({scope:"ACTUAL_ROOT_SOURCE32_CAPTURE_WITH_PARENT29_FULL_INVERSE",passed:true,fullInverseSourceTreePassed:true,actualParent29CapturePin,source29QualificationInherited:false,proposedReactElementCount:2286,previousReactElementCount:2278,genuineNewInnerPortCount:52,exactNewPortDeclarations:6,exactChangedOriginalRouteDeclarations:3,exactChangedLocalSuppressions:6,exactMovedExistingViaCount:0,exactAddedIntermediateCarrierViaCount:2,newViaRole:"REMOVABLE_CARRIER_NOT_FIXED_FANOUT",expectedPhysicalVias:229,expectedPhysicalTraces:297,expectedCarrierPaths:32,expectedPhysicalCarrierBodyPaths:34,missingOriginal49RequestsExpected:17,all227ExistingViasAnd29PriorRoutesHeld:true,all98NumericBranchesAnd49LogicalOwnersHeld:true,original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse:true,sourceOnlyProposalSha256:sha(readFileSync(new URL("./source32-proposal.json",import.meta.url))),actualSourceTree:after,actualDiagnosticPath:diagnostic,actualDiagnosticSha256:sha(readFileSync(diagnostic)),pureSourceEvaluationExecuted:true,circuitConstructed:false,coreRendered:false,nativeExecuted:false,cadExecuted:false,automaticCoreSrjForThisForkMustNotBeUsed:true,bothDqs1CoupledViewsRequireFreshOriginalApi:true,singleCoupledSectionCoversBoth:false,referenceQualified:false,electricalTimingPassed:false,all49Accepted:false,fabricationReady:false},replacer)+"\n",{flag:"wx",mode:0o600})
console.log(JSON.stringify({scope:"ROOT_SOURCE32_CAPTURE_ONLY",passed:true,output,diagnostic,coreRendered:false,fabricationReady:false}))
