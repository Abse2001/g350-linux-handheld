export type Point = { x: number; y: number }
export type Pin = { path: string; sha256: string; bytes?: number; mode?: number }
export type InnerPort = { viaName: string; layer: "inner1" | "inner2"; viaXY: Point; numericSelector: string }
export type RouteChange = {
  originalSourceTraceId: string; logicalName: string; fromSelector: string; toSelector: string
  beforeRouteProps: Record<string, unknown>
  after: { newPcbPaths: unknown[]; newPcbPathRelativeTo: string }
}
export type Source29Delta = {
  sealedCandidatePins: Pin[]
  movedVia: { name: string; before: Point; after: Point }
  routeChanges: RouteChange[]
  localSuppressions: { traceName: string; numericSelector: string; viaName: string }[]
  newSixInnerPorts: InnerPort[]
}
export type Parent26QualificationBindings = {
  sourceManifest: Pin
  collectionPins: { batch48: Pin; native49: Pin; api50: Pin; cli51: Pin; cad52: Pin | null }
  stagePins: Record<string, Pin | null>
  rawCore: Pin; coreControls: Pin; fresh49Model: Pin; fresh49ProjectionProof: Pin; cliExport: Pin
}
export type Source29Proposal = {
  parent26QualificationBindings: Parent26QualificationBindings
  scope: string; promotedParent26Source: Pin; parent26Proposal: Pin; sealedSource7Geometry: Pin; sealedJoint29Geometry: Pin
  actualParent26Qualification: Pin | null; actualParent26Stages: Record<string, Pin | null>
  source29Delta: Source29Delta
  expectedCounts: { carrierPaths: number; physicalTraces: number; innerLiteralPorts: number; expectedSourcePorts: number; expectedReactElements: number; remainingOriginal49Requests: number }
  all49OriginalLogicalTraces: { originalSourceTraceId: string; name: string; from: string; to: string }[]
  primaryCoupledSectionView: string; secondaryCoupledSectionView: string
  singleCoupledSectionCoversBoth: boolean; bothActualSharedMeandersMustBeChecked: boolean
}
