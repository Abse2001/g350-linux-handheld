"""Prepare an additive inventory of collected evidence only; do not build archives."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib,json,stat
B=Path('/workspace/g350-linux-handheld'); S=Path('/workspace/bus-lanes-solver'); O=B/'.cloud-tools/ti-ddr-v7-followup-report-next'
V7=B/'.cloud-tools/ti-ddr-v7-ram-right-source-next'; R=B/'.cloud-tools/ti-ddr-v7-ram-right-validation-recovery-next'; P=S/'.cache/g350-ti-v6-public-pair-stage-telemetry-next'; F=S/'.cache/g350-enclosed-terminal-precheck-source-next'
FULL=S/'.cache/g350-enclosed-terminal-precheck-full-validation-next'; BENCH=S/'.cache/g350-enclosed-terminal-precheck-benchmark-bootstrap-next'; PKG=S/'.cache/g350-enclosed-terminal-precheck-package-validation-next'; VIS=B/'.cloud-tools/ti-ddr-v7-ratsnest-preview-next'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def row(p):
 assert p.is_absolute() and p.resolve().is_relative_to('/workspace') and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
 return {'bytes':p.stat().st_size,'sha256':digest(p),'mode':stat.S_IMODE(p.stat().st_mode)}
def write(p,x):
 with p.open('x') as f:f.write(json.dumps(x,indent=2)+'\n')
oldmanifest=B/'cloud/artifacts/g350-ti-ddr-linux-followup-2026-10-12.manifest.json'
if not oldmanifest.exists():
 matches=list((B/'cloud/artifacts').glob('*ti-ddr-linux-followup*manifest*.json')); assert len(matches)==1; oldmanifest=matches[0]
old=json.loads(oldmanifest.read_text()); oldarchive=B/old['archive']['path']; assert digest(oldarchive)==old['archive']['sha256']=='e7e3af6354ca757e2c80d651afaa27a7ffb2e1f0fd88f95c8f7a4c4de6cecd7a'
old_by_hash={(r['sha256'],r['bytes'],r['mode']):r['path'] for r in old['files']}
rows={}; maps=[]; externals=[]; exclusions=[]
def member(p):
 if p.is_relative_to(B):return 'board/'+p.relative_to(B).as_posix()
 if p.is_relative_to(S):return 'solver/'+p.relative_to(S).as_posix()
 raise AssertionError(p)
def add(p,role,expected=None):
 actual=row(p)
 if expected:
  for k in ['sha256','bytes','mode']:
   if k in expected:assert actual[k]==expected[k],(str(p),k)
 name=member(p)
 if name in rows: assert rows[name]['sha256']==actual['sha256'];return name
 rows[name]={'sourcePath':str(p),'member':name,**actual,'role':role};return name
def include_tree(root,role,skip=()):
 for p in sorted(root.rglob('*')):
  if p.is_file() and not p.is_symlink():
   rel=p.relative_to(root)
   if any(x in rel.parts for x in ['node_modules','.git','__pycache__','tmp']) or p.name=='memory.jsonl' or any(rel.is_relative_to(x) for x in skip):
    exclusions.append({'path':str(p),'reason':'Non-replay cache, runtime/Git payload, sampled memory stream or duplicate source explicitly excluded'}); continue
   add(p,role)
def include_packet(root,label):
 packet=json.loads((root/'packet-manifest.json').read_text())
 for r in packet['files']:add(root/r['path'],f'Frozen {label} control/source/input member',r)
 for r in packet.get('externalFiles',[]):
  p=Path(r['path']); actual=row(p)
  for k in ['sha256','bytes','mode']:
   if k in r:assert actual[k]==r[k],(str(p),k)
  if 'node_modules' in p.parts or '.git' in p.parts or p.name in ['bun.exe','node'] or not(p.is_relative_to(B) or p.is_relative_to(S)):
   externals.append({**r,'requirement':'Exact external runtime, dependency, Git metadata or host helper; payload excluded'}); continue
  previous=old_by_hash.get((actual['sha256'],actual['bytes'],actual['mode']))
  if previous:
   maps.append({'originalPath':str(p),'bytes':actual['bytes'],'sha256':actual['sha256'],'mode':actual['mode'],'archive':'parent1975','archiveMember':previous});continue
  name=add(p,f'Frozen external helper/source required by {label}',r)
  maps.append({'originalPath':str(p),'bytes':actual['bytes'],'sha256':actual['sha256'],'mode':actual['mode'],'archive':'supplement','archiveMember':name})
 return packet
packets={}
for root,label in [(V7,'original-V7-source-export-and-failed-validator'),(R,'validation-only-recovery'),(P,'passive-V6-pair-stage-prefix')]:
 packets[label]=include_packet(root,label)
 for p in sorted(root.iterdir()):
  if p.is_file() and p.name!='dependency-tree.json':add(p,f'Collected {label} receipt/index/report')
 for sub in ['run','checks','output']:
  if (root/sub).exists():include_tree(root/sub,f'Collected {label} raw output/control check; no accepted route')
# Complete source914 is reconstructed from the required public source913 + this patch.
for name in ['RELEASE.json','base-source-manifest.json','immutable-source-manifest.json','verify-source.py','root-full914-git-metadata-prep.json','root-full914-git-metadata-prep-v2.json']:
 add(F/name,'Uncommitted source914 closure/reconstruction and original Git metadata preparation history')
include_tree(F/'library-v1','Source914 actual library124 manifest/candidate patch/runtime')
source914=json.loads((F/'immutable-source-manifest.json').read_text())
for name in source914['changedPaths']+source914['addedPaths']:add(F/'source'/name,'Exact source914 changed/new source for patch reconstruction')
include_tree(F/'checks','Source914 forwarding mocks, type/format evidence; original failures preserved')
for root,label in [(FULL,'original full914 689-pass/3 environment-launch failures'),(BENCH,'same914 corrected benchmark three-pass run'),(PKG,'same914 type/format/packaged consumer validation')]:
 for p in sorted(root.iterdir()):
  if p.is_file():add(p,'Collected '+label+' authority/report/control')
 for sub in ['run','logs']:
  if (root/sub).exists():include_tree(root/sub,'Collected '+label+' raw results/logs')
# Original package check implementation is exact source914, no packed payload is required for replay.
for name in ['scripts/check-package.ts','package.json','tsup.config.ts','tsconfig.json','tsconfig.build.json','biome.json']:
 add(F/'source'/name,'Exact same914 declaration/build/consumer-check metadata')
include_tree(VIS,'Fresh V7 actual placement PNG/SVG with explicit 49-airwire/uncompleted caption and visual provenance')
for name in ['build-indexed-archive.py','validate-indexed-archive.py']:
 add(B/'.cloud-tools/ti-ddr-followup-report-next'/name,'Previously tested archive helper; this preparation does not run it')
v7=json.loads((R/'validation-report.json').read_text()); pair=json.loads((P/'run/latest-pair-stage-telemetry.json').read_text()); pe=json.loads((P/'run/execution.json').read_text()); snap=pair['snapshot']
summary={'schemaVersion':1,'createdUtc':datetime.now(timezone.utc).isoformat(),'preparationOnly':True,'accepted49':False,'fabricationReady':False,'priorArchive':{'path':str(oldarchive),'sha256':digest(oldarchive),'indexedMemberCount':len(old['files'])},'source914':{'sourceManifestSha256':digest(F/'immutable-source-manifest.json'),'sourceClosureSha256':source914['sourceClosureSha256'],'sourceFiles':source914['sourceFileCount'],'libraryManifestSha256':digest(F/'library-v1/manifest.json'),'patchSha256':digest(F/'library-v1/candidate.patch'),'uncommitted':True,'mainAdopted':False,'old913AllElevenEvidenceRelabeled':False},'v7Validation':v7,'pairStage':{'packetSha256':digest(P/'packet-manifest.json'),'telemetrySha256':digest(P/'run/latest-pair-stage-telemetry.json'),'postflightSha256':digest(P/'run/postflight.json'),'execution':{k:pe[k] for k in ['exitCode','stopReasons','wallSeconds','cleanupOwnedGroupEmpty','peakOwnedRssBytes','peakSharedBytes','oomDelta']},'prefixCounters':{k:v for k,v in snap.items() if k not in ['rows','events','groups']},'coupledJobs':[{k:r[k] for k in ['id','names','variant','allowProvisionalPairTuning','completion','next','offers','traceCount','pointCount']} for r in snap['rows'] if r['kind']=='coupled'],'interpretation':'Two DQS1 natural bodies and four local bounded-cap nulls in a 60-second prefix; naturalBody=4 includes bounded-wrapper duplicates. Zero planner offers, ordinary entries and public traces; whole planner termination remains unknown.'},'explicitExclusions':['All V7 3600-second full-route controller/runtime outputs and other live/unbound jobs','node_modules, dependency archives and KiCad image payloads','Git object stores and writable source914 Git metadata payloads','Nonessential sampled memory.jsonl streams and runtime compiler caches','Complete duplicate source914 docs/full fixtures; reconstruct914 from exact required source913 plus indexed patch'],'packetReplayMaps':maps,'externalFrozenRequirements':externals,'inventoryExclusions':exclusions}
write(O/'collected-summary.json',summary)
write(O/'replay-map.json',{'schemaVersion':1,'sourceMappings':maps,'externalRequirements':externals,'requirement':'Restore supplemental and exact parent1975 archives into isolated roots only; reconstruct immutable packet layouts using mapped paths/modes. Do not overwrite current hardware.'})
text=f'''V7 RAM placement and paired-stage Linux follow-up — collected evidence only

The V7 placement source exported successfully and then passed all 17 native physical checks, the pinned Core projection, and fresh CPU/RAM endpoint/TI input derivation. This does not complete the 49 DDR routes. There is no accepted V7 DDR copper, order release, electrical timing qualification, continuous reference-plane proof or fabrication approval. fabricationReady remains false.

V7 source and validation-only recovery

RAM and its 17 support parts moved rigidly right by 1.2 mm; the CPU, CPU13 capacitor and all other real placements remained fixed. RAM is at (1.2, 6), rotated 270 degrees. All 280 real components, 1,161 original physical contacts, logical inventory and 49 CPU/RAM pin identities are preserved. The existing two RAM7 reference vias, stubs and four alias ports moved with the group, retaining IDs, owners, dimensions and layers. The copied source has 120 files: the exact preceding V6 118-file closure plus the V7 wrapper and translation JSON. No hardware source is adopted by this report.

The original source controller packet {digest(V7/'packet-manifest.json')} ran one routing-disabled fresh CLI export, exit 0. Its validator then exited 1 (outer controller 2) because reversing the translation produced tiny floating-point differences in a legacy exact dictionary comparison. Original failure logs and control bytes are retained. The separate recovery packet {digest(R/'packet-manifest.json')} performed no new export: it read the identical raw source {v7['rawActualSourceSha256']}. Direct fresh geometry, IDs and complete fields were checked before canonicalizing only the nonemitted inverse comparison view to V6 baseline records under the unchanged 1e-7 mm geometry tolerance. The actual 17 checks, Core projection and TI derivation all consumed original fresh bytes; no physical checks or constraints were relaxed. Full-chain controls reject unplanned micrometer movement, changed reference dimensions/layers/owners, unknown fields and extra records.

Recovery exits were 0/0, postflight {v7['postflightSha256']}; all 17 native counts are zero. Minimum moved-group courtyard gap is 0.0974 mm; CPU/RAM courtyard gap is 0.892964 mm. Recovery took {v7['ownedChildWallSeconds']:.3f} seconds, peak owned RSS {v7['peakOwnedRssBytes']} bytes, with no OOM event and an empty owned process group after collection. Complete board dependencies remained {v7['boardDependencyTreeSha256']}; native checker patch remains {v7['nativeChecksPatchSha256']}.

Fresh unrestricted native input: {v7['unrestrictedInputSha256']}. Strong input: {v7['strongInputSha256']}. Both have 49 connections and 856 obstacles (854 original pads plus two real reference-via obstacles), with 132 obstacles translated and 724 fixed. Strong input assigns 22 byte signals to Top and 27 command/reset signals to Bottom; unrestricted allows both outer layers. Physical board remains four layers, with Inner1 GND and Inner2 DDR power reference planes planned but not qualified.

TI bounds come from the fresh pad endpoints and the printed SPRS717L p.186 section 7.7.2.3.6.1 / p.187 Table 7-68 row 13 and note 9. The command/clock maximum placement Manhattan distance is 14.8 mm; CACLM is 22.42 mm, producing a 21.15–23.69 mm total planar range. BYTE0 maximum was tightened to 13.2 mm; BYTE1 retains the stricter 14.4 mm limit despite a fresh derived maximum of 15.6 mm. Bus skew remains 0.635 mm and differential-pair skew 0.127 mm. Actual routing, electrical delay and manufacturer stackup/impedance qualification remain open; these bounds do not prove timing passed.

Completed V6 paired-stage observation

Packet {digest(P/'packet-manifest.json')} used source914/library124 with precheckEnclosedTerminals enabled (options 0/0/true) on the exact V6 strong input dc14a2e24414e66179ae7d8ddc72f8216b1faef2c7d9c8f739cf57de05dd93a1. Passive wrappers observed original iterator behavior and bounded stage completion; they did not retain route bodies, add searches, change acceptance or increase the original 6,000 local yield cap. Before the actual launch, passive iterator/input controls passed 17 tests / 165 expectations, six guard mocks, type checks and formatting; the initial type failure and corrected control bytes are preserved. The actual process stopped on its external 60-second guard after {pe['wallSeconds']:.3f} seconds; child exit -15, owned group empty, peak owned RSS {pe['peakOwnedRssBytes']} bytes, OOM deltas zero. This is unresolved resource-stop evidence, not a natural routing failure.

The retained prefix has 19 factories / 9 coupled jobs, no observation errors, no tuple offers and no ordinary-router factory entry. DQS1 naturally returned the same two-trace, 173-point body twice (provisional mode false/true). DQS0 and the bottom clock hit the original 6,000-yield wrapper cap in each mode: four bounded-cap nulls. The aggregate naturalBody=4 counts each real DQS1 body plus its bounded wrapper; it does not mean four distinct pair routes. Three next-variant jobs were unfinished at the final snapshot. The public progress record still reported zero accepted traces. No complete planner tuple, complete board route or pair/length qualification is claimed. Raw compact telemetry {digest(P/'run/latest-pair-stage-telemetry.json')} and progress records are included.

Uncommitted source914 validation scope

The default-off precheck addition is not adopted into the board runtime or solver main. Enabling the underlying Grid flag also changes alternate terminal-attachment selection; it is not established as a behavior-preserving early rejection alone. The default-off and enabled cases must retain their separate qualification scope. Source914 manifest {digest(F/'immutable-source-manifest.json')}, closure {source914['sourceClosureSha256']}, library124 manifest {digest(F/'library-v1/manifest.json')}, and patch {digest(F/'library-v1/candidate.patch')} bind the candidate. It modifies 14 library files and adds one forwarding test; the remaining 899 source files and filesystem modes are unchanged from the exact source913 parent. Reconstruct it from the required source913 base and indexed patch, then verify the full manifest. The original 20 Git metadata entries supplied the existing test harness; this is not a pristine upstream clone or a committed source revision.

Its forwarding mock passed one Bun test, 5 Bun expectations and 77 nested assertions without constructing Grid/Projector; final type/format checks passed. The full run recorded 689 passes and three benchmark subprocess launch failures because cloud/env.sh had not been sourced. On the unchanged source914, only those three tests were rerun with the environment sourced and all passed (361 expectations). Preserve this two-run scope: it is not a single full-suite 692/0 result. Later exact-source type, formatting and original packaged Node/browser/TypeScript consumers passed; five packed files totaled 2,768,181 unpacked bytes, local offline tar installation only. Terminal report {digest(PKG/'terminal-validation-report.json')} binds the raw checks and dependencies. Earlier source913 all-eleven/all-22 qualifications belong to source913 and are not relabeled as source914 or G350 49-route success.

Placement preview and reuse

The overview, whole-board and CPU/RAM zoom PNG/SVG files derive from the exact raw V7 source and show 49 straight airwires (11 BYTE0, 11 BYTE1, 26 command/clock, one RESETn), zero DDR source copper. Their titles explicitly say routes are not completed; the footer labels the two inner reference planes as planned. Exact source/image hashes and visual inspection records accompany them.

This is an additive archive proposal only. It preserves the existing 1,975-member archive e7e3af6354ca757e2c80d651afaa27a7ffb2e1f0fd88f95c8f7a4c4de6cecd7a and its reports, plus all frozen hardware evidence. It does not build an archive, change saved Install/Start configuration, commit, push, launch a router or alter dependencies. All pending/live V7 3,600-second full-route outputs are excluded; collect and independently qualify a terminal outcome before adding them. Source/scripts should be reconstructed in isolated ignored directories after sourcing cloud/env.sh. The supplemental archive still requires the parent indexed evidence, original 25,814 files, exact board locks/native patch, exact solver dependency tree/archive and verified KiCad image; dependency or image payloads are not duplicated.
'''
with (O/'TI_DDR_V7_LINUX_FOLLOWUP_2026-10-12.md').open('x') as f:f.write(text)
for p in [O/'collected-summary.json',O/'replay-map.json',O/'TI_DDR_V7_LINUX_FOLLOWUP_2026-10-12.md',O/'prepare.py']:add(p,'Supplemental report/provenance/reconstruction inventory preparation')
requirements=[{'requirement':'Unchanged parent1975 diagnostic archive','path':old['archive']['path'],'sha256':old['archive']['sha256'],'indexedFilesIncludingIndex':len(old['files']),'note':'Parent may contain older unpushed913 wording; current public review branch 1bc1db89ae048902d56918fe82a25aba47896b19 retains exact913 code and adds documentation.'},{'requirement':'Exact source913 reconstruction','publicBase':'c1151212be7b9de4b34b07436d135d874e6c0466','parentPatchSha256':'bcb458f994a60ce2fe79d2dae0089ebd982e3644b4736b95afca066275d02c34','sourceManifestSha256':'309339cf2fa863055aace476e35ee68d8504f604eb9e7f85297b1d37924df003'},{'requirement':'Source914 reconstruction from source913','patchSha256':digest(F/'library-v1/candidate.patch'),'sourceManifestSha256':digest(F/'immutable-source-manifest.json'),'libraryManifestSha256':digest(F/'library-v1/manifest.json'),'uncommitted':True,'mainAdopted':False},{'requirement':'Runtime/dependencies and original hardware','boardDependencyTreeSha256':v7['boardDependencyTreeSha256'],'nativeChecksPatchSha256':v7['nativeChecksPatchSha256'],'solverDependencyTreeSha256':'47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6','solverArchiveSha256':'a5122317cc21862873121f8ddefa2ec605cf36c67ec9b688fd5d866391ea43ec','note':'Original25,814 evidence and182-file TI reference parent, pinned Node/Bun and verified KiCad10 image remain external requirements.'},{'requirement':'Frozen external packet members and replay map','mapMember':member(O/'replay-map.json'),'note':'Restore into isolated replay roots, preserve exact bytes/modes and external pins; do not overwrite board hardware or use upstreamHEAD.'}]
proposal={'schemaVersion':1,'createdUtc':datetime.now(timezone.utc).isoformat(),'scope':'Additive collected V7 source-only qualification, failed original validator, uncommitted source914 validation and completed passive V6 paired-stage prefix plus airwire previews; no accepted49 or fabrication release. Live V7 full-route outputs excluded.','members':sorted(rows.values(),key=lambda r:r['member']),'externalReplayRequirements':requirements,'memberCount':len(rows),'bytes':sum(r['bytes'] for r in rows.values()),'accepted49':False,'fabricationReady':False,'preparationOnly':True}
write(O/'proposed-members.json',proposal)
write(O/'proposal-proof.json',{'schemaVersion':1,'preparationOnly':True,'memberCount':proposal['memberCount'],'bytes':proposal['bytes'],'proposalSha256':digest(O/'proposed-members.json'),'reportSha256':digest(O/'TI_DDR_V7_LINUX_FOLLOWUP_2026-10-12.md'),'summarySha256':digest(O/'collected-summary.json'),'replayMapSha256':digest(O/'replay-map.json'),'existingArchiveUnchanged':digest(oldarchive)==old['archive']['sha256'],'parentManifestSha256':digest(oldmanifest),'liveOutputsIncluded':False,'archiveBuilt':False,'sourceChanged':False,'setupUiChanged':False,'committed':False,'accepted49':False,'fabricationReady':False})
print(json.dumps({'members':len(rows),'bytes':proposal['bytes'],'proposalSha256':digest(O/'proposed-members.json'),'reportSha256':digest(O/'TI_DDR_V7_LINUX_FOLLOWUP_2026-10-12.md'),'summarySha256':digest(O/'collected-summary.json'),'externalMembers':len(externals),'parentReuseMappings':sum(m['archive']=='parent1975' for m in maps),'excludedFiles':len(exclusions)},indent=2))
