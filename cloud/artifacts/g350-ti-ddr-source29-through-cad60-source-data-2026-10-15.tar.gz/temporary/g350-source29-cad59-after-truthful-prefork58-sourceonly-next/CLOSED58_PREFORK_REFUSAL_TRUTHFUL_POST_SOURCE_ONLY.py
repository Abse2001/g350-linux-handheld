def closed58():
 prior=closed57();assert prior['actualClosedScopeCount']==57
 for key in('actual58FailedCollectionPin','actual58PostauditPin','actual58ZoneExecutionPin','actual58UnspawnedCadExecutionPin','actual58ZonePinsPin','actual58GuardManifestPin'):binding(proposal[key])
 r=read(proposal['actual58FailedCollectionPin']['path']);p=read(proposal['actual58PostauditPin']['path']);zone=read(proposal['actual58ZoneExecutionPin']['path']);attempt=read(proposal['actual58UnspawnedCadExecutionPin']['path'])
 assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==59882 and r['toolWrapperExitCode']==r['toolExitCode']==2 and r['passed']is False
 assert r['scope']==p['scope']=='ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH57_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
 assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual58GuardManifestPin']['sha256']
 assert r['postauditPath']==proposal['actual58PostauditPin']['path']and r['postauditSha256']==proposal['actual58PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior
 assert r['execution']==p['execution']==r['cadExecution']==p['cadExecution']==attempt and r['zonePinsExecution']==p['zonePinsExecution']==zone
 h.finite(zone,0);assert zone['policy']==cad29_contract['zonePinsPolicy']and zone['pid']==zone['pgid']==507769 and zone['currentGuardPid']==507764 and c.guard.process_scope.owned(507769)==[]and not Path('/proc/507764').exists()
 assert 'pid'not in attempt and 'pgid'not in attempt and attempt['exitCode']is None and attempt['cleanupOwnedGroupEmpty']is None and attempt['diagnosticStopped']is True and attempt['guardError']=='AssertionError'and attempt['stopReasons']==[]
 assert attempt['policy']==cad29_contract['cadPolicy']and attempt['currentGuardPid']==507764 and not any(attempt['oomDelta'].values())and attempt['signalErrors']==[]and attempt['diskFreeGuard']['sampleCount']==0
 for doc in(r,p):
  for key in('sourceAndDependenciesHeld','zonePinsOwnedGroupEmptyActuallyObserved','zonePinsChildNatural0','actualCadApplicationCompletionUnknown','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
  for key in('passed','resultPassed','stageNaturallyCompleted','cadChildNatural0','zoneBeforeCadSeriallyEnforced','cadOwnedGroupEmptyActuallyObserved','bothOwnedGroupsIndependentlyObservedEmpty','ownedGroupEmptyActuallyObserved','Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
  assert doc['ownedContainerActuallyEmpty']is doc['containerResourceObservations']is doc['containerResourceObservationsBinding']is doc['reportSha256']is doc['cadCalls']is None
  assert doc['postverificationFailure']is None and doc['runFailure']=='AssertionError: 'and doc['resultInspectionFailure']=='AssertionError: 'and doc['zonePinsChildInvocations']==1
  assert doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['newRoutesAdopted']==doc['workspaceDataCopiesPerformed']==0
 assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
 assert r['cadWrapperSpawned']is r['cadApplicationInvoked']is r['containerInvocationPerformed']is False and r['resourceReceiptAbsent']is r['outputDirectoryEmpty']is True
 assert r['independentlyObservedAllActuallySpawnedOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentlyObservedOwnedGroupMembers']=={'507769':[]}and r['independentProcReadErrors']==[]
 assert attempt['memoryBefore']['current']==27967787008 and r['memoryAdmissionExcessAtObservedBeforeSnapshotBytes']==50499584 and attempt['memoryBefore']['current']+4294967296-attempt['policy']['sharedBytes']==50499584
 assert not Path(p['reportPath']).exists()and not Path(proposal['original58RunRoot'],'cad-resource-observations.json').exists()and not any(Path(proposal['original58RunRoot'],'output').iterdir())
 z=read(proposal['actual58ZonePinsPin']['path']);assert z['actualCoreRawSha256']==proposal['actual53CoreRawPin']['sha256']and z['actualExportSha256']==proposal['actual56ExportPin']['sha256']and z['actualSourceKeepoutCount']==2
 prior['actual58ZoneOnlyCadPreforkRefusalTruthfulPostCollectionPin']={k:proposal['actual58FailedCollectionPin'][k]for k in('path','sha256')};prior['actual58CadNeverSpawnedExitCleanupUnknownFullSdkPostHeld']=True;prior['actualClosedScopeCount']=58
 return prior
