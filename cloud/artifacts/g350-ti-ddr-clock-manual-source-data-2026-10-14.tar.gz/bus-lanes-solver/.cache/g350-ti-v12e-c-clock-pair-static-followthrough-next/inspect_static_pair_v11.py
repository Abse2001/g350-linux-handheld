import pathlib,json,math,hashlib,time
D=pathlib.Path('/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-clock-pair-static-followthrough-next')
# Load only authored stdlib geometric definitions; source contains no package/app imports.
s=(D/'finite_fully_paired_v8.py').read_text();exec(compile(s[:s.index('ramCenter=')],str(D/'finite_fully_paired_v8.py'), 'exec'))
p=D/'finite-fully-paired-result-v11.json';a=json.loads(p.read_text());paths=[a[n]['path'] for n in ('source_trace_33','source_trace_34')];names=['source_trace_33','source_trace_34']
def selfcheck(path,required=.2032):
 cumulative=[0];turning=[0];unsafe=[0]
 for i in range(1,len(path)-1):
  u=P(path[i]['x']-path[i-1]['x'],path[i]['y']-path[i-1]['y']);v=P(path[i+1]['x']-path[i]['x'],path[i+1]['y']-path[i]['y']);cross=abs(u['x']*v['y']-u['y']*v['x']);angle=abs(math.atan2(u['x']*v['y']-u['y']*v['x'],u['x']*v['x']+u['y']*v['y']));radius=math.inf if cross<1e-12 else math.hypot(u['x'],u['y'])*math.hypot(v['x'],v['y'])*dst(path[i-1],path[i+1])/(2*cross);turning.append(turning[-1]+angle);unsafe.append(unsafe[-1]+int(angle>math.pi/8+1e-8 or radius<required/2-1e-8))
 for u,v in zip(path,path[1:]):cumulative.append(cumulative[-1]+dst(u,v))
 checks=0
 for i in range(len(path)-1):
  for j in range(i+2,len(path)-1):
   u,v,c,e=path[i],path[i+1],path[j],path[j+1];sep=seg(u,v,c,e);checks+=1
   if sep<1e-9 and cumulative[j]-cumulative[i+1]>1e-8:return {'clear':False,'reason':'self-intersection','segments':[i,j],'separation':sep}
   if cumulative[j]-cumulative[i+1]<=math.pi*required+1e-8 and (turning[j]-turning[i]<=math.pi/2+1e-8 or (turning[j]-turning[i]<=math.pi+1e-8 and unsafe[j]==unsafe[i])):continue
   if sep>=required-1e-8:continue
   sx=sy=0
   for k in range(i,j+1):
    dx=path[k+1]['x']-path[k]['x'];dy=path[k+1]['y']-path[k]['y']
    if abs(dx)>1e-8:
     sign=1 if dx>0 else -1
     if sx and sx!=sign:return {'clear':False,'reason':'returning-x-arm','segments':[i,j],'separation':sep}
     sx=sign
    if abs(dy)>1e-8:
     sign=1 if dy>0 else -1
     if sy and sy!=sign:return {'clear':False,'reason':'returning-y-arm','segments':[i,j],'separation':sep}
     sy=sign
 return {'clear':True,'checkedSegmentPairs':checks}
# Reproduce scalarpackage region bounds and existing native-dogbone enlargement, then conservative exterior sampling.
ipt=json.loads(pathlib.Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-plus96-signals-combined-sourceonly-next/combined-ca-carrier-input.json').read_text());reg={}
def include(box,p,x,y=None):
 y=x if y is None else y;box[0]=min(box[0],p['x']-x);box[1]=max(box[1],p['x']+x);box[2]=min(box[2],p['y']-y);box[3]=max(box[3],p['y']+y)
pads=[o for o in ipt['obstacles'] if o.get('componentId')]
for o in pads:
 box=reg.setdefault(o['componentId'],[math.inf,-math.inf,math.inf,-math.inf]);angle=o.get('ccwRotationDegrees',0)*math.pi/180;include(box,o['center'],(abs(math.cos(angle))*o['width']+abs(math.sin(angle))*o['height'])/2,(abs(math.sin(angle))*o['width']+abs(math.cos(angle))*o['height'])/2)
for t in ipt['traces']:
 vs=[p for p in t['route'] if p['route_type']=='via']
 if len(vs)!=1:continue
 first=t['route'][0];owners=[o for o in pads if dst(o['center'],first)<1e-4]
 if not owners:continue
 o=owners[0];v=vs[0];radius=v['via_diameter']/2;angle=o.get('ccwRotationDegrees',0)*math.pi/180;reachX=(abs(math.cos(angle))*o['width']+abs(math.sin(angle))*o['height'])/2+radius+.1016;reachY=(abs(math.sin(angle))*o['width']+abs(math.cos(angle))*o['height'])/2+radius+.1016
 if abs(v['x']-first['x'])>reachX+.001+1e-4 or abs(v['y']-first['y'])>reachY+.001+1e-4:continue
 include(reg[o['componentId']],v,radius)
fields=[]
for k in ('pcb_component_0','pcb_component_1'):
 b=reg[k];fields.append([b[0]-.2632,b[1]+.2632,b[2]-.2632,b[3]+.2632])
def intervals(u,v,fields):
 inside=[]
 for b in fields:
  lo=0;hi=1
  for key,mi,ma in [('x',b[0],b[1]),('y',b[2],b[3])]:
   delta=v[key]-u[key]
   if abs(delta)<1e-15:
    if u[key]<mi or u[key]>ma:lo=1;hi=0;break
   else:
    p=(mi-u[key])/delta;q=(ma-u[key])/delta;lo=max(lo,min(p,q));hi=min(hi,max(p,q))
  if lo<hi:inside.append([lo,hi])
 inside.sort();out=[];end=0
 for lo,hi in inside:
  if lo>end:out.append([end,lo])
  end=max(end,hi)
 if end<1:out.append([end,1])
 return out
allowed=(.1016+.12)/math.cos(math.pi/8)-.1016+.002
report={'scope':'stdlib-static-translation-of-original-self-shared-and-exterior-pair-geometry','candidate':{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},'nativeOrOriginalTsExecuted':False,'accepted49':False,'fabricationReady':False,'margin':margin,'fullPathsSelf':{},'shared':{},'exterior':{},'nativePackageApproachBoxes':fields,'maxAllowedEdgeGap':allowed}
for i,name in enumerate(names):
 report['fullPathsSelf'][name]=selfcheck(paths[i]);lo,hi=a['coupledSections'][name];shared=paths[i][lo:hi+1];mate=list(zip(paths[1-i],paths[1-i][1:]));maxgap=-math.inf;mingap=math.inf;error=0;length=0;countall=0
 for u,v in zip(shared,shared[1:]):
  length+=dst(u,v);count=max(1,math.ceil(dst(u,v)/.002));error=max(error,dst(u,v)/(2*count));countall+=count
  for j in range(count):
   t=(j+.5)/count;q=P(u['x']+(v['x']-u['x'])*t,u['y']+(v['y']-u['y'])*t);gap=min(pt(q,c,e) for c,e in mate)-.1016;maxgap=max(maxgap,gap);mingap=min(mingap,gap)
 report['shared'][name]={'length':length,'minGap':mingap,'maxGap':maxgap,'samplingError':error,'matched':maxgap+error<=allowed,'samples':countall}
 maxgap=-math.inf;error=0;separated=0;exteriorlength=0
 for u,v in zip(paths[i],paths[i][1:]):
  span=dst(u,v)
  for lo,hi in intervals(u,v,fields):
   count=max(1,math.ceil((hi-lo)*span/.002));step=(hi-lo)*span/count;error=max(error,step/2);exteriorlength+=(hi-lo)*span
   for j in range(count):
    t=lo+(hi-lo)*(j+.5)/count;q=P(u['x']+(v['x']-u['x'])*t,u['y']+(v['y']-u['y'])*t);gap=min(pt(q,c,e) for c,e in mate)-.1016;maxgap=max(maxgap,gap)
    if gap+step/2>allowed:separated+=step
 report['exterior'][name]={'length':exteriorlength,'maxGap':maxgap,'samplingError':error,'separatedLength':separated,'matched':separated==0}
report['allStaticSelfSharedExteriorPassed']=all(x['clear'] for x in report['fullPathsSelf'].values()) and all(x['matched'] for x in report['shared'].values()) and all(x['matched'] for x in report['exterior'].values())
q=D/'inspect-static-pair-result-v11.json';q.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
