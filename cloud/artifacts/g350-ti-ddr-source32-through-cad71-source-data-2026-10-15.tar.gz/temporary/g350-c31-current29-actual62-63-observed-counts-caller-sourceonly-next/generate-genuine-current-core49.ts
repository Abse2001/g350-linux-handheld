/** One actual55-current-Core29 unseeded full49 C31 diagnostic; no static carrier seeds or private routing APIs. */
import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { createHash } from "node:crypto"
const HERE=import.meta.dirname
const hash=(bytes:Buffer|string)=>createHash("sha256").update(bytes).digest("hex")
const read=(p:string,expected:string)=>{assert.equal(typeof p,"string");assert.match(expected,/^[0-9a-f]{64}$/);const bytes=fs.readFileSync(p);assert.equal(hash(bytes),expected,`Changed sealed input ${p}`);return JSON.parse(bytes.toString())}
const manifestBytes=fs.readFileSync(path.join(HERE,"SOURCE-manifest.json")),manifest=JSON.parse(manifestBytes.toString())
const authority=JSON.parse(fs.readFileSync(process.argv[2]!,"utf8"))
assert.equal(authority.authorizedByRoot,true)
assert.equal(authority.scope,"ROOT_C31_ACTUAL55_UNSEEDED_FRESH49_PUBLIC_DIAGNOSTIC")
assert.equal(authority.sourceManifestSha256,hash(manifestBytes))
for(const field of ["rootOwns90s2GiBFiniteGuardFullSdkAnd120SourceBeforeAfter","rootOwnsGenuineSource29All186BindingsBeforeAfter","rootAllEarlierActualAppScopesCollectedAndIndependentlyClosed","rootFocusedC31AndFull647CollectionsActuallyPassedAndClosed","rootOwnsExclusiveTmpOutput","rootActual55TwoSerialChildrenAndFresh49DataReviewed","peerSourceOnlyGoReviewedByRoot"])assert.equal(authority[field],true,field)
for(const field of ["originalAll11AcceptanceClaimed","fixReleaseQualificationPassed","all49Accepted","fabricationReady"])assert.equal(authority[field],false,field)
assert.equal(authority.diagnosticOnlyNotReleaseQualification,true)
assert.equal(authority.outputDirectory,path.resolve(authority.outputDirectory))
assert.match(authority.outputDirectory,/^\/tmp\/g350-focused-stage17-[A-Za-z0-9_-]+\/output$/)
const outputParent=path.dirname(authority.outputDirectory)
assert.equal(fs.realpathSync(outputParent),outputParent)
assert.equal(fs.lstatSync(outputParent).isSymbolicLink(),false)
assert.equal(fs.lstatSync(outputParent).isDirectory(),true)
for(const row of [...manifest.files,...manifest.externalFiles,...manifest.solverSourceFiles,...manifest.originalSolverSourceFiles,...manifest.parentSolverSourceFiles,...manifest.runtimeSolverSourceFiles,...manifest.genuineSourceFiles186]){const st=fs.lstatSync(row.path);assert(st.isFile()&&!st.isSymbolicLink());assert.equal(st.size,row.bytes);assert.equal(st.mode&0o777,row.mode);assert.equal(hash(fs.readFileSync(row.path)),row.sha256,`Changed source ${row.path}`)}
const genuineSource=read(manifest.genuineSourcePin.path,manifest.genuineSourcePin.sha256)
assert.equal(genuineSource.expandedHeldSourceAndControllerClosure.length,186)
assert.equal(manifest.boardSdkTreeSha256,"ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2")
assert.equal(manifest.solverDependenciesTreeSha256,"47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6")
// A focused RED/GREEN batch has two real children; full647 is one standalone child.
const boundCollection=(pin:any)=>{
 assert(pin&&typeof pin.path==="string"&&typeof pin.sha256==="string","Future authentic C31 collection remains unbound")
 const r=read(pin.path,pin.sha256),p=read(r.postauditPath,r.postauditSha256)
 assert.equal(r.authorizedByRoot,true);assert.equal(r.toolSessionCollected,true);assert.equal(r.toolWrapperExitCode,0);assert.equal(r.toolExitCode,0)
 for(const d of [r,p])for(const k of ["passed","sourceAndDependenciesHeld","workspaceFreeBytesFloorHeld","gitMetadataHeld"])assert.equal(d[k],true,k)
 assert.equal(r.independentlyObservedGuardAbsent,true)
 return {r,p}
}
const naturalOwnedChild=(e:any,exit:number)=>{
 assert.equal(e.exitCode,exit);assert.equal(e.pid,e.pgid);assert(Number.isInteger(e.pgid)&&e.pgid>0)
 assert.equal(e.diagnosticStopped,false);assert.deepEqual(e.stopReasons,[]);assert.equal(e.cleanupOwnedGroupEmpty,true)
 assert(Object.values(e.oomDelta).every(v=>v===0));assert.equal(e.signalErrorCount,0)
}
const focusedBatch=(pin:any)=>{
 const {r,p}=boundCollection(pin)
 for(const d of [r,p]){
  assert.equal(d.phase,"focused-red-green-batch");assert.equal(d.sourceManifestSha256,manifest.currentCompactSourcePin.sha256)
  assert.deepEqual(d.orderedPhaseNames,["baseline","proposed"]);assert.deepEqual(d.expectedPhaseNames,["baseline","proposed"]);assert.deepEqual(d.notAttemptedPhaseNames,[])
  for(const k of ["allOwnedGroupsIndependentlyObservedEmpty","redOwnedGroupEmptyBeforeGreen","passedMeansRegressionReproducedAndProposedGreenOnly","greenTestSuitePassed"])assert.equal(d[k],true,k)
  assert.equal(d.baselineTestSuitePassed,false);assert.equal(d.batchFailure,null);assert.equal(d.finalVerificationFailure,null)
 }
 assert.equal(r.independentlyObservedAllOwnedGroupsEmpty,true);assert.deepEqual(r.independentProcReadErrors,[]);assert.deepEqual(r.phases,p.phases)
 assert.equal(p.phases.length,2);assert(Number.isInteger(p.sameGuardPid)&&p.sameGuardPid>0);assert.equal(r.sameGuardPid,p.sameGuardPid)
 const names=["a failed first package prevents needless second-package Grid construction","skipping doomed end work preserves the same naturally failed geometry","legacy first success retains exact geometry and yields in both negotiation modes"]
 const phaseNames=["baseline","proposed"],sourceRoots=[manifest.expectedFocusedBaselineSourceRoot,manifest.solverSourceRoot]
 for(const [i,row]of p.phases.entries()){
  const baseline=i===0,expectedExit=baseline?1:0,counts=baseline?{pass:2,fail:1}:{pass:3,fail:0}
  assert.equal(row.phase,phaseNames[i]);assert.equal(row.selectedSourceRoot,sourceRoots[i]);assert.equal(row.sameGuardPid,p.sameGuardPid)
  for(const k of ["passed","sourceAndDependenciesHeld","ownedGroupEmptyActuallyObserved","stageNaturallyCompleted","passedMeansFocusedRedOrGreenProtocolOnly"])assert.equal(row[k],true,k)
  for(const k of ["runFailure","postverificationFailure","resultInspectionFailure"])assert.equal(row[k],null,k)
  assert.equal(row.testSuitePassed,!baseline);assert.equal(row.expectedBaselineFailureVerified,baseline);assert.equal(row.expectedOwnedChildExitCode,expectedExit)
  assert.equal(row.externalRootToolCollectionClaimedForIndividualPhase,false);assert.deepEqual(row.observedCounts,counts)
  assert.deepEqual(read(row.postauditPath,row.postauditSha256),Object.fromEntries(Object.entries(row).filter(([k])=>!['postauditPath','postauditSha256'].includes(k))))
  naturalOwnedChild(row.execution,expectedExit);assert.equal(row.execution.currentGuardPid,p.sameGuardPid)
  assert.deepEqual(row.phaseSnapshotsBefore,row.phaseSnapshotsAfter);assert.equal(row.phaseSnapshotsAfter.board.treeSha256,manifest.boardSdkTreeSha256);assert.equal(row.phaseSnapshotsAfter.solver.treeSha256,manifest.solverDependenciesTreeSha256)
  const log=fs.readFileSync(row.childLogPath);assert(log.length>0&&log.length<=262144);assert.equal(hash(log),row.childLogSha256)
  const ins=row.focusedLogInspection;assert.equal(ins.sourceManifestSha256,manifest.currentCompactSourcePin.sha256);assert.equal(ins.testSourceSha256,manifest.focusedTestSourcePin.sha256)
  assert.equal(ins.phase,phaseNames[i]);assert.equal(ins.selectedSourceRoot,sourceRoots[i]);assert.equal(ins.logSha256,row.childLogSha256);assert.equal(ins.logBytes,log.length)
  assert.equal(ins.expectedChildExitCode,expectedExit);assert.deepEqual(ins.counts,counts);assert.equal(ins.passCount,counts.pass);assert.equal(ins.failCount,counts.fail);assert.deepEqual(ins.testNames,names)
  assert.equal(ins.contentMatchesExpectedFocusedOutcome,true);assert.equal(ins.expectedBaselineFailureVerified,baseline);assert.equal(ins.testSuitePassed,!baseline)
  assert.equal(ins.actualChildSourceAndResourceReceiptAuthenticatedByParser,false);assert.equal(ins.hardwareQualified,false)
  const text=log.toString('utf8').replace(/\x1b\[[0-9;]*m/g,''),controls=text.split(/\r?\n/).filter(l=>l.startsWith('{')).map(l=>JSON.parse(l))
  assert.match(text,/^bun test v1\.3\.14 /);assert.match(text,/Ran 3 tests across 1 file\. \[[^\]]+\]\s*$/)
  const statuses=[...text.matchAll(/^\((pass|fail)\) (.+) \[[^\]]+\]$/gm)];assert.deepEqual(statuses.map(m=>m[2]),names);assert.deepEqual(statuses.map(m=>m[1]),baseline?["fail","pass","pass"]:["pass","pass","pass"])
  assert.deepEqual(controls,ins.rawControls);assert.deepEqual(controls,ins.controlRows);assert.equal(controls.length,2);assert.deepEqual(controls.map((c:any)=>c.negotiationDefined),[false,true])
  for(const c of controls){
   assert.equal(c.scope,"FOCUSED_DOOMED_ESCAPE_END_CONTROL");assert.equal(c.sourceRoot,sourceRoots[i]);assert.equal(c.hardwareQualified,false)
   for(const v of [c.baseline,c.selected]){assert.equal(v.natural,true);assert.equal(v.traces,null);for(const k of ["yields","firstEndGrids","secondEndGrids","failedFirstEndGrids","doomedSecondEndGrids","unexpectedStarts"])assert(Number.isInteger(v[k])&&v[k]>=0);assert(v.yields<40000);assert(v.firstEndGrids>0);assert.equal(v.failedFirstEndGrids,v.firstEndGrids);assert.equal(v.unexpectedStarts,0)}
   assert(c.baseline.doomedSecondEndGrids>0);assert.equal(c.baseline.secondEndGrids,c.baseline.doomedSecondEndGrids)
   if(baseline)assert.deepEqual(c.selected,c.baseline)
   else{assert.equal(c.selected.secondEndGrids,0);assert.equal(c.selected.doomedSecondEndGrids,0);assert.equal(c.selected.firstEndGrids,c.baseline.firstEndGrids);assert(c.selected.yields<=c.baseline.yields)}
  }
 }
 const [red,green]=p.phases;assert(red.execution.endedAt<=green.execution.startedAt);assert.notEqual(red.execution.pgid,green.execution.pgid)
 assert.deepEqual(red.focusedLogInspection.rawControls.map((c:any)=>c.baseline),green.focusedLogInspection.rawControls.map((c:any)=>c.baseline))
 const cross=p.crossRunLogInspection;assert.deepEqual(r.crossRunLogInspection,cross)
 assert.equal(cross.scope,"FOCUSED_DOOMED_ESCAPE_END_RED_GREEN_CONTENT_INSPECTION_ONLY");assert.equal(cross.originalVectorsEqualAcrossBothLogs,true);assert.equal(cross.contentMatchesExpectedFocusedOutcome,true);assert.equal(cross.actualChildSourceAndResourceReceiptAuthenticatedByParser,false);assert.equal(cross.hardwareQualified,false)
 for(const [i,key]of ["baseline","proposed"].entries()){const x=cross[key],y=p.phases[i].focusedLogInspection;assert.equal(x.logSha256,y.logSha256);assert.equal(x.sourceManifestSha256,manifest.currentCompactSourcePin.sha256);assert.equal(x.childExitCodeProvidedByCaller,i===0?1:0);assert.deepEqual(x.controlRows,y.controlRows);assert.equal(x.passCount,y.passCount);assert.equal(x.failCount,y.failCount)}
 return r
}
const full647Standalone=(pin:any)=>{
 const {r,p}=boundCollection(pin)
 for(const d of [r,p]){assert.equal(d.phase,"full647");assert.equal(d.candidateSourceManifestSha256,manifest.currentCompactSourcePin.sha256);assert.equal(d.full647ProjectManifestSha256,manifest.full647IsolatedProjectPin.sha256);assert.equal(d.stageNaturallyCompleted,true);assert.equal(d.full647Requalified,true);assert.deepEqual(d.observedCounts,{pass:647,fail:0});for(const k of ["runFailure","postverificationFailure","resultInspectionFailure"])assert.equal(d[k],null,k)}
 assert.equal(r.testSuiteCompleted,true);assert.equal(r.observedCounts.pass,647);assert.equal(r.observedCounts.fail,0);assert.equal(r.observedTestFileCount,190);assert.equal(p.observedTestFileCount,190)
 assert.deepEqual(r.execution,p.execution);naturalOwnedChild(p.execution,0);assert.equal(r.independentlyObservedOwnedGroupEmpty,true)
 assert.equal(r.childLogPath,p.childLogPath);assert.equal(r.childLogSha256,p.childLogSha256);const log=fs.readFileSync(p.childLogPath);assert.equal(hash(log),p.childLogSha256)
 const text=log.toString('utf8').replace(/\x1b\[[0-9;]*m/g,'');assert.match(text,/Ran 647 tests across 190 files\. \[[^\]]+\]\s*$/)
 return r
}
const focusedC31=focusedBatch(manifest.futureActualFocused62CollectionPin)
const full647=full647Standalone(manifest.futureActualFull64763CollectionPin)
const apiCollection=read(manifest.actual55CollectionPin.path,manifest.actual55CollectionPin.sha256),apiPost=read(apiCollection.postauditPath,apiCollection.postauditSha256)
assert.equal(apiCollection.toolSessionId,20574);assert.equal(apiCollection.authorizedByRoot,true);assert.equal(apiCollection.toolSessionCollected,true);assert.equal(apiCollection.toolWrapperExitCode,0);assert.equal(apiCollection.toolExitCode,0)
assert.equal(apiCollection.sourceManifestSha256,manifest.nativeSourcePin.sha256);assert.equal(apiCollection.coreSourceManifestSha256,manifest.genuineSourcePin.sha256)
assert.equal(apiCollection.passed,true);assert.equal(apiPost.passed,true);assert.deepEqual(apiCollection.phases,apiPost.phases);assert.deepEqual(apiPost.orderedPhaseNames,["projection","api"]);assert.deepEqual(apiPost.expectedPhaseNames,["projection","api"]);assert.deepEqual(apiPost.notAttemptedPhaseNames,[])
for(const obj of [apiCollection,apiPost])for(const field of ["guardIdentityHeldAcrossChildren","allOwnedGroupsIndependentlyObservedEmpty","eachAttemptedChildNaturallyCompleted","bothChildrenNaturallyCompleted","sourceAndDependenciesHeld","workspaceFreeBytesFloorHeld","gitMetadataHeld","projectionPassed","apiPassed","projectionBeforeApiSeriallyEnforced"])assert.equal(obj[field],true,field)
assert.equal(apiCollection.independentlyObservedAllOwnedGroupsEmpty,true);assert.equal(apiCollection.independentlyObservedGuardAbsent,true);assert.deepEqual(apiCollection.independentProcReadErrors,[])
const [projectionPhase,apiPhase]=apiPost.phases
for(const [i,phase]of apiPost.phases.entries()){
 assert.equal(phase.phase,["projection","api"][i]);assert.equal(phase.passed,true);assert.equal(phase.ownedGroupEmptyActuallyObserved,true);assert.equal(phase.stageNaturallyCompleted,true);assert.equal(phase.ownedChildNatural0,true)
 const separate=read(phase.postauditPath,phase.postauditSha256);assert.deepEqual(separate,Object.fromEntries(Object.entries(phase).filter(([k])=>!["postauditPath","postauditSha256"].includes(k))))
 const e=phase.execution;assert.equal(e.exitCode,0);assert.equal(e.pid,e.pgid);assert.equal(e.diagnosticStopped,false);assert.deepEqual(e.stopReasons,[]);assert.equal(e.cleanupOwnedGroupEmpty,true);assert(Object.values(e.oomDelta).every(v=>v===0))
 assert.deepEqual(phase.phaseSnapshotsBefore,phase.phaseSnapshotsAfter);assert.equal(phase.phaseSnapshotsAfter.board.treeSha256,manifest.boardSdkTreeSha256);assert.equal(phase.phaseSnapshotsAfter.solver.treeSha256,manifest.solverDependenciesTreeSha256)
 assert.deepEqual(phase.guardIdentityBefore,apiPost.sameGuardIdentity);assert.deepEqual(phase.guardIdentityAfter,apiPost.sameGuardIdentity)
}
assert(projectionPhase.execution.endedAt<=apiPhase.execution.startedAt);assert.notEqual(projectionPhase.execution.pgid,apiPhase.execution.pgid)
assert.deepEqual(apiPost.projectionExecution,projectionPhase.execution);assert.deepEqual(apiPost.apiExecution,apiPhase.execution)
const produced=(phase:any,pin:any)=>assert(phase.outputFiles.some((r:any)=>r.path===pin.path&&r.sha256===pin.sha256),`Actual55 output missing: ${pin.path}`)
for(const pin of [manifest.initialLayerOnlyInputPin,manifest.constructorProjectionProofPin,manifest.cleanCarrierViewPin,manifest.numericInputPin,manifest.materialProjectionProofPin])produced(projectionPhase,pin)
produced(apiPhase,manifest.actualApiReportPin)
assert.deepEqual(apiCollection.actualFresh49Model,manifest.initialLayerOnlyInputPin);assert.deepEqual(apiCollection.actualFresh49ProjectionProof,manifest.constructorProjectionProofPin)
assert.deepEqual(apiCollection.actualOriginalApiReportPin,manifest.actualApiReportPin)
const raw=read(manifest.actualCorePin.path,manifest.actualCorePin.sha256),controls=read(manifest.actualCoreControlsPin.path,manifest.actualCoreControlsPin.sha256),native=read(manifest.actualNativeReportPin.path,manifest.actualNativeReportPin.sha256),api=read(manifest.actualApiReportPin.path,manifest.actualApiReportPin.sha256)
assert.equal(native.actualCoreSha256,manifest.actualCorePin.sha256);assert.equal(native.actualCoreControlsSha256,manifest.actualCoreControlsPin.sha256);assert.equal(native.physicalErrors,0);assert.equal(native.physicalCpuRamConnectedCarrierCount,29)
assert.equal(api.allOriginalApiLoaded26ChecksPassed,true);assert.equal(api.actualCompleteOriginalSignalCount,29);assert.equal(api.actualCoreSha256,manifest.actualCorePin.sha256);assert.equal(api.actualNativeReportSha256,manifest.actualNativeReportPin.sha256)
assert.equal(controls.freshCoreControlPassed,true);assert.equal(controls.checks.length,29);assert(controls.checks.every((c:any)=>c.passed===true));assert.equal(controls.circuitJsonGeometryEdited,false);assert.equal(controls.automaticCoreSrjForThisForkMustNotBeUsed,true)
assert.equal(apiCollection.actualCoreSha256,manifest.actualCorePin.sha256);assert.deepEqual(apiCollection.actualNativeReport,manifest.actualNativeReportPin)
const numericPacket=read(manifest.numericInputPin.path,manifest.numericInputPin.sha256),numeric=numericPacket.numericFull49Input
const original=read(manifest.cleanCarrierViewPin.path,manifest.cleanCarrierViewPin.sha256),input=read(manifest.initialLayerOnlyInputPin.path,manifest.initialLayerOnlyInputPin.sha256),projection=read(manifest.constructorProjectionProofPin.path,manifest.constructorProjectionProofPin.sha256),materialProjection=read(manifest.materialProjectionProofPin.path,manifest.materialProjectionProofPin.sha256)
assert.equal(materialProjection.inputBinding.sha256,manifest.cleanCarrierViewPin.sha256);assert.equal(materialProjection.numericBinding.sha256,manifest.numericInputPin.sha256)
for(const proof of [projection,materialProjection]){assert.equal(proof.sourceManifestSha256,manifest.genuineSourcePin.sha256);assert.equal(proof.actualCoreSha256,manifest.actualCorePin.sha256);assert.equal(proof.actualNativeReportSha256,manifest.actualNativeReportPin.sha256)}
assert.equal(projection.constructorInputSha256,manifest.initialLayerOnlyInputPin.sha256);assert.equal(projection.parentInputSha256,manifest.cleanCarrierViewPin.sha256);assert.equal(projection.exactFullInverseToFresh29Parent,true)
assert.equal(input.connections.length,49);assert.equal(input.traces.length,263);assert.equal(input.obstacles.length,1298);assert.equal(input.layerCount,4);assert.deepEqual(input.allowedLayers,["top","inner1","inner2","bottom"])
for(const key of Object.keys(original))if(!["connections","traces","obstacles"].includes(key))assert.deepEqual(input[key],original[key])
const actualByType=(type:string)=>raw.filter((r:any)=>r.type===type)
assert.equal(actualByType("source_component").length,280);assert.equal(actualByType("pcb_component").length,507);assert.equal(actualByType("pcb_via").length,227);assert.equal(actualByType("pcb_trace").length,292)
const actualTraces=new Map<string,any>(actualByType("pcb_trace").map((r:any)=>[r.pcb_trace_id,r])),actualVias=new Map<string,any>(actualByType("pcb_via").map((r:any)=>[r.pcb_via_id,r]))
const ownership=native.actualOwnershipProof;assert.equal(ownership.signalMappings.length,98);assert.equal(ownership.referenceMappings.length,165);assert.equal(ownership.carriers.length,29)
const bodyIds=new Set(ownership.carriers.map((c:any)=>c.actualCarrierPcbTraceId)),fixedIds=new Set([...ownership.signalMappings,...ownership.referenceMappings].map((m:any)=>m.actualPcbTraceId))
assert.equal(fixedIds.size,263);assert.equal(bodyIds.size,29);assert(input.traces.every((t:any)=>fixedIds.has(t.pcb_trace_id)&&!bodyIds.has(t.pcb_trace_id)))
const inverse=structuredClone(input)
for(const c of inverse.connections)for(const p of c.pointsToConnect)p.layers=["top","inner1","inner2","bottom"]
for(const ch of projection.viaEvents98){const t=inverse.traces.find((t:any)=>t.pcb_trace_id===ch.actualPcbTraceId);assert.deepEqual(ch.rawWireRoute,actualTraces.get(ch.actualPcbTraceId).route);assert.deepEqual(input.traces.find((t:any)=>t.pcb_trace_id===ch.actualPcbTraceId).route,ch.projectedRoute);const v=actualVias.get(ch.actualViaId);assert.equal(v.outer_diameter,.4572);assert.equal(v.hole_diameter,.254);assert.deepEqual(v.layers,["top","inner1","inner2","bottom"]);const event=ch.projectedRoute.find((p:any)=>p.route_type==="via");assert.equal(event.pcb_via_id,v.pcb_via_id);assert.equal(event.x,v.x);assert.equal(event.y,v.y);assert.equal(event.from_layer,v.from_layer);assert.equal(event.to_layer,v.to_layer);assert.equal(event.via_diameter,v.outer_diameter);assert.equal(event.via_hole_diameter,v.hole_diameter);assert.deepEqual(event.layers,v.layers);assert.equal(ch.originalPlanarLengthMm,ch.projectedPlanarLengthMm);t.route=ch.rawWireRoute}
assert.equal(projection.viaEvents98.length,98);assert.equal(input.traces.flatMap((t:any)=>t.route.filter((p:any)=>p.route_type==="via")).length,98)
assert.equal(input.traces.filter((t:any)=>ownership.signalMappings.some((m:any)=>m.actualPcbTraceId===t.pcb_trace_id)).reduce((n:number,t:any)=>n+t.route.length,0),414)
for(const m of ownership.referenceMappings){const t=input.traces.find((t:any)=>t.pcb_trace_id===m.actualPcbTraceId),actual=actualTraces.get(m.actualPcbTraceId);assert.deepEqual(t.route,actual.route);assert.equal(t.source_trace_id,actual.source_trace_id)}
const obstacleById=new Map<string,any>(inverse.obstacles.map((o:any)=>[o.obstacleId,o]))
for(const o of projection.removedDuplicateSignalViaObstacles98)obstacleById.set(o.obstacleId,o)
for(const h of projection.npthConservativeMarginProjection){obstacleById.set(h.actualHoleId,h.beforeObstacle);assert.equal(h.conservativeRadiusAdditionMm,.2-.1016);assert.equal(h.implementedGenericClearanceMm,.2);assert.equal(h.rawPhysicalHoleEdited,false)}
inverse.obstacles=original.obstacles.map((o:any)=>obstacleById.get(o.obstacleId));assert.deepEqual(inverse,original)
const terminalLayers=new Map<string,string[]>(),endpointProof:any[]=[],physical=["top","inner1","inner2","bottom"]
for(const c of input.connections){const logical=numeric.connections.find((n:any)=>n.name===c.name);assert(logical);assert.equal(c.source_trace_id,logical.source_trace_id);const contacts=numericPacket.contacts.filter((p:any)=>p.originalSourceTraceId===c.name).sort((a:any,b:any)=>a.side-b.side);assert.equal(contacts.length,2);for(const [side,p]of c.pointsToConnect.entries()){const contact=contacts[side],via=actualVias.get(contact.actualBarrel.pcb_via_id);assert.equal(p.layers,undefined);assert.equal(p.pointId,via.pcb_via_id);assert.equal(p.x,via.x);assert.equal(p.y,via.y);assert.deepEqual(via.layers,physical);assert.deepEqual(Object.fromEntries(Object.entries(c).filter(([k])=>k!=="pointsToConnect")),Object.fromEntries(Object.entries(original.connections.find((o:any)=>o.name===c.name)).filter(([k])=>k!=="pointsToConnect")))}assert.equal(c.pointsToConnect[0].layer,c.pointsToConnect[1].layer);const allowed=physical.filter(layer=>contacts.every((p:any)=>p.actualBarrel.layers.includes(layer))&&input.allowedLayers.includes(layer)&&input.buses.every((b:any)=>!b.connectionNames.includes(c.name)||!b.allowedLayers||b.allowedLayers.includes(layer)));assert.deepEqual(allowed,physical);terminalLayers.set(c.name,allowed);endpointProof.push({name:c.name,actualNumericContacts:logical.pointsToConnect,authenticOwnedFullSpanBarrels:contacts.map((p:any)=>p.actualBarrel),availableLayers:allowed})}
assert.equal(terminalLayers.size,49);assert.equal(endpointProof.length,49);assert.equal(endpointProof.reduce((n:number,p:any)=>n+p.authenticOwnedFullSpanBarrels.length,0),98)
assert.deepEqual(input.buses,numeric.buses);assert.deepEqual(input.differentialPairs,numeric.differentialPairs)
const immutableConstructorInput=structuredClone(input)
const output=authority.outputDirectory;fs.mkdirSync(output,{recursive:false})
const save=(name:string,obj:unknown)=>fs.writeFileSync(path.join(output,name),JSON.stringify(obj,null,2)+"\n",{flag:"wx"})
save("ACTUAL_CONSTRUCTOR_INPUT.json",input)
save("AUTHENTIC_INPUT_AND_TERMINAL_MAP.json",{genuineCurrentCore29RawSha256:manifest.actualCorePin.sha256,genuineNumeric49ContactsAnd98Barrels:true,endpointProof,terminalLayers:[...terminalLayers],fixed263RowsHeld:true,signalViaEvents98NotNewHoles:true,uniquePhysicalBarrels227:true,hardObstacles1298RepresentCurrent1396Rows:true,currentNpthMarginCompensationExact:true,existing29BodyIdsExcluded:[...bodyIds],noSeededCompletedRoutes:true,referenceQualified:false,electricalTimingQualified:false,fabricationReady:false})
const verifyRuntimeAlias=()=>{const r=manifest.runtimeNodeModulesAlias;assert.equal(fs.lstatSync(r.path).isSymbolicLink(),true);assert.equal(fs.readlinkSync(r.path),r.target);assert.equal(fs.realpathSync(r.path),r.target)}
verifyRuntimeAlias()
const {BusLanesSolver}=await import("/tmp/g350-c31-full647-isolated-project-sourceonly-next/project/lib/bus-lanes-solver.ts")
const options={smoothTuning:true,denseSearch:true,maxSearchIterations:40000}
const solver=new BusLanesSolver(input,options,terminalLayers)
assert.equal(solver.MAX_ITERATIONS,40000)
const started=Date.now();let checkpoints=0;let lastCheckpointIteration=-1;let checkpointBytes=0
const CHECKPOINT_LIMIT=41
const CHECKPOINT_TOTAL_BYTE_LIMIT=40000000
const CHECKPOINT_SINGLE_BYTE_LIMIT=960000
const capture=(value:any,byteLimit:number)=>{
  const encoded=JSON.stringify(value)
  if(encoded===undefined)return {value:undefined,complete:true,bytes:0}
  const bytes=Buffer.byteLength(encoded)
  return bytes<=byteLimit?{value,complete:true,bytes}:{value:{omittedForDiagnosticByteCap:true,encodedJsonBytes:bytes,encodedJsonSha256:hash(encoded),arrayLength:Array.isArray(value)?value.length:undefined},complete:false,bytes}
}
const inputMaterialHash=(value:any)=>hash(JSON.stringify(Object.fromEntries(Object.entries(value).filter(([key])=>key!=="connections"))))
const originalMaterialHash=inputMaterialHash(input)
const rawState=(reason:string,checkpointOnly=false)=>{
  const best=capture((solver as any).bestPartial,checkpointOnly?64000:1048576)
  const paired=capture((solver as any).pairedTraces,checkpointOnly?64000:1048576)
  const publicTraces=checkpointOnly?capture(solver.traces,720000):{value:solver.traces,complete:true,bytes:0}
  return {reason,elapsedMs:Date.now()-started,iterations:solver.iterations,MAX_ITERATIONS:solver.MAX_ITERATIONS,phase:solver.phase,solved:solver.solved,failed:solver.failed,error:solver.error,failureCode:solver.failureCode,stats:solver.stats,traces:publicTraces.value,completePublicGeometry:publicTraces.complete,actualPublicTraceCount:solver.traces.length,originalPrivateDiagnosticOnly:true,originalPrivateBestPartial:best.value,originalPrivateBestPartialComplete:best.complete,originalPrivatePairedTraces:paired.value,originalPrivatePairedTracesComplete:paired.complete,...(checkpointOnly?{actualCurrentConnections:solver.input.connections,inputOtherFieldsSha256:inputMaterialHash(solver.input),inputOtherFieldsMatchOriginal:inputMaterialHash(solver.input)===originalMaterialHash,reconstructCurrentInputFromImmutablePinAndActualConnections:true}:{actualCurrentInput:solver.input}),constructorCalls:1,publicStepCalls:solver.iterations,outerRootGuardOwnsResourceStopAndCleanup:true,noSignalOrSdkCancellationHooksInstalled:true,sourceCoreNativeCadCalls:0,sourceOnlyHypothesis:true,referenceQualified:false,electricalTimingPassed:false,all49Accepted:false,fabricationReady:false}
}
const checkpoint=(reason:string)=>{
  if(checkpoints>=CHECKPOINT_LIMIT||lastCheckpointIteration===solver.iterations)return
  const state:any=rawState(reason,true)
  let encoded=JSON.stringify(state,null,2)+"\n"
  if(Buffer.byteLength(encoded)>CHECKPOINT_SINGLE_BYTE_LIMIT){
    state.traces=capture(solver.traces,0).value;state.completePublicGeometry=false
    state.stats=capture(solver.stats,0).value
    encoded=JSON.stringify(state,null,2)+"\n"
  }
  assert.ok(Buffer.byteLength(encoded)<=CHECKPOINT_SINGLE_BYTE_LIMIT,"Bounded checkpoint exceeded byte contract")
  assert.ok(checkpointBytes+Buffer.byteLength(encoded)<=CHECKPOINT_TOTAL_BYTE_LIMIT)
  fs.writeFileSync(path.join(output,`CHECKPOINT-${String(solver.iterations).padStart(5,"0")}.json`),encoded,{flag:"wx"})
  checkpointBytes+=Buffer.byteLength(encoded)
  checkpoints++;lastCheckpointIteration=solver.iterations
}
// No signal listeners or SDK cancellation/failure hooks: Root owns resource stops.
let thrown:string|null=null
try{
  checkpoint("Before first original step")
  while(!solver.solved&&!solver.failed){
    solver.step()
    if(solver.iterations%1000===0)checkpoint("After original step returned")
  }
}catch(error){thrown=String(error)}
// Full failing/partial geometry and phase precede every result/postcondition assertion.
save("RAW_FINAL_STATE.json",{...rawState("Natural SDK completion or thrown original step"),thrown})
if(solver.solved&&!thrown)save("SOLVED_OUTPUT.json",solver.getOutput())
for(const pin of [manifest.numericInputPin,manifest.cleanCarrierViewPin,manifest.initialLayerOnlyInputPin])read(pin.path,pin.sha256)
assert.equal(inputMaterialHash(solver.input),originalMaterialHash)
assert.equal(solver.input.connections.length,49)
for(const [index,c] of solver.input.connections.entries()){
  const prior=input.connections[index]
  assert.deepEqual(Object.fromEntries(Object.entries(c).filter(([key])=>key!=="pointsToConnect")),Object.fromEntries(Object.entries(prior).filter(([key])=>key!=="pointsToConnect")))
  assert.equal(c.pointsToConnect.length,2)
  for(const [side,point] of c.pointsToConnect.entries()){
    assert.deepEqual(Object.fromEntries(Object.entries(point).filter(([key])=>key!=="layer")),Object.fromEntries(Object.entries(prior.pointsToConnect[side]).filter(([key])=>key!=="layer")))
    assert.ok(terminalLayers.get(c.name)!.includes(point.layer))
  }
  assert.equal(c.pointsToConnect[0].layer,c.pointsToConnect[1].layer)
}
// Separate immutable pre-constructor clone rejects any mutation except original49 scalar layer choices.
const mutatedInverse=structuredClone(solver.input)
for(const [index,c]of mutatedInverse.connections.entries())for(const [side,p]of c.pointsToConnect.entries())p.layer=immutableConstructorInput.connections[index].pointsToConnect[side].layer
assert.deepEqual(mutatedInverse,immutableConstructorInput)
verifyRuntimeAlias()
const names=solver.traces.map(t=>t.connection_name??t.source_trace_id)
save("DIAGNOSTIC_RESULT.json",{scope:authority.scope,diagnosticOnlyNotReleaseQualification:true,originalAll11AcceptanceClaimed:false,fixReleaseQualificationPassed:false,publicConstructorCalls:1,originalStepCalls:solver.iterations,naturalSdkSolved:solver.solved,naturalSdkFailed:solver.failed,thrown,phase:solver.phase,error:solver.error,failureCode:solver.failureCode,actualGeneratedCarrierCount:names.length,actualUniqueGeneratedCarrierCount:new Set(names).size,missingOriginal49:input.connections.map((c:any)=>c.name).filter((n:string)=>!names.includes(n)),getOutputCalledOnlyWhenSolved:solver.solved&&!thrown,allCurrent263FixedRowsAnd49NumericContactsHeld:true,actualConstructorInputOtherFieldsAndOwnedEndpointsHeld:true,onlyOriginal49ScalarLayerChoicesMayChange:true,genuine98FixedViaEventsRepresentExisting227Material:true,current1396MaterialRowsRepresentedBy1298ObstaclesAnd98Events:true,independentActualOutputGeometryPairsFullRulesAndNativeDrillChecksRequired:true,verifiedPairedFallbackSource:true,verifiedPairedFallbackSourceRefersToHistoricalF940Only:true,currentC31FocusedTestsPassed:true,currentC31Full647TestsPassed:true,currentC31Full49RoutingQualificationPassed:false,max40000Rationale:"Previous same public constructor budget is retained as a bounded current-placement diagnostic; completeness is not guaranteed",checkpointCount:checkpoints,checkpointBytes,checkpointByteLimit:CHECKPOINT_TOTAL_BYTE_LIMIT,maximumCheckpointCount:CHECKPOINT_LIMIT,all4LayerAuthorityDerivedFrom98ActualCurrentFullSpanBarrels:true,newGeneratedCarriersRequireEditableSourceAdoptionAndFreshCoreNativeApiCadQualification:true,uncoupledLengthDiagnosticsNeverImplyAbsentWholeCouplingLimitPass:true,sourceCoreNativeCliCadCalls:0,referenceQualified:false,electricalTimingPassed:false,all49Accepted:false,fabricationReady:false})
process.exitCode=solver.solved&&!thrown?0:1
