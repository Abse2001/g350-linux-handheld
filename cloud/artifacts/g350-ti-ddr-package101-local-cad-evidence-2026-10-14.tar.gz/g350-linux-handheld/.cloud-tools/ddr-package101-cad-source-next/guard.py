"""Root-only staged leader guard; source-only until explicitly launched."""
import argparse,hashlib,json,re,stat,sys,subprocess
from pathlib import Path
import inventory,process_scope,python_inventory
ROOT=Path(__file__).resolve().parent
BOARD=Path('/workspace/g350-linux-handheld')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def require(v,s):
 if not v:raise ValueError(s)
def checked():
 m=read(ROOT/'PREPARED-manifest.json')
 for key,base in [('files',ROOT),('externalFiles',None)]:
  for row in m[key]:
   p=base/row['path'] if base else Path(row['path'])
   require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Frozen member changed: '+str(p))
 resolver=ROOT/'source/node_modules';require(resolver.is_symlink() and str(resolver.readlink())==str(BOARD/'node_modules'),'Exact pinned resolver required')
 listed={r['path'] for r in m['files']}
 for name in ('.pnp.cjs','.pnp.loader.mjs','.yarn','node_modules'):
  child=Path(m['all101SourceDirectory'])/name
  require(not child.exists() and not child.is_symlink(),'Unexpected package101 resolver shadow')
 for p in (ROOT/'source').rglob('*'):
  if p.is_symlink():require(p==resolver,'Unexpected source symlink');continue
  if p.is_file():require(p.relative_to(ROOT).as_posix() in listed,'Unexpected source mutation/artifact')
 for base in (ROOT,ROOT.parent,ROOT/'source'):
  for name in ('.pnp.cjs','.pnp.loader.mjs','.yarn'):require(not(base/name).exists() and not(base/name).is_symlink(),'Unexpected resolver shadow')
 require(not(ROOT/'node_modules').exists() and not(ROOT/'node_modules').is_symlink(),'Unexpected local resolver')
 deps=inventory.tree(BOARD/'node_modules');small={k:deps[k] for k in ('treeSha256','regularFiles','regularBytes','symlinks','directories')}
 require(small==m['boardDependencyInventory'],'Complete pinned dependency tree changed')
 numerical=python_inventory.snapshot(m['pythonTarget']);require(numerical==m['pinnedPythonInventory'],'Existing pinned numerical/geometry trees changed')
 return m,sha(ROOT/'PREPARED-manifest.json'),small,numerical
def main():
 p=argparse.ArgumentParser();p.add_argument('--stage',dest='phase',choices=['export','cad'],required=True);p.add_argument('--preflight',action='store_true');p.add_argument('--root-receipt',type=Path);p.add_argument('--root-receipt-sha256');args=p.parse_args()
 require(args.preflight!=bool(args.root_receipt),'Select preflight or exact Root authority')
 m,packet_sha,before,python_before=checked();phase=args.phase;policy=m['stages'][phase]['policy']
 if args.preflight:print(json.dumps({'preflightOnly':True,'phase':phase,'packetSha256':packet_sha,'runtimeCalls':0}));return 0
 require(re.fullmatch('[0-9a-f]{64}',args.root_receipt_sha256 or '') and sha(args.root_receipt)==args.root_receipt_sha256,'Exact Root authority hash required')
 a=read(args.root_receipt)
 require(a.get('authorizedByRoot') is True and a.get('phase')==phase and a.get('scope')==m['stages'][phase]['scope'] and a.get('packetSha256')==packet_sha and a.get('policy')==policy and a.get('allPreviousRootWorkersCollected') is True and a.get('noConcurrentRootWorker') is True and re.fullmatch('[0-9a-f]{32,128}',a.get('approvalToken','')),'Root scope/policy/exclusive collection authority differs')
 closed=a.get('previousClosedPostaudits',[]);require(closed,'At least latest actual closed Root scope required')
 for r in closed:
  require(re.fullmatch('[0-9a-f]{64}',r.get('sha256','')) and sha(r['path'])==r['sha256'],'Previous closed postaudit hash differs')
  old=read(r['path']);e=old['execution'];require(e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()),'Previous owned group not cleanly empty')
 # Require the actual accepted package101 readonly stage, not just a netlist.
 require(sha(m['acceptedRootCollectionPath'])==m['acceptedRootCollectionSha256'],'Accepted native101 collection changed')
 c=read(m['acceptedRootCollectionPath']);require(c['authorizedByRoot'] is True and c['phase']=='readonly' and c['packetSha256']==m['acceptedReadonlyPacketSha256'] and c['toolSessionCollected'] is True and c['toolWrapperExitCode']==0,'Require actual collected native101+64 pass')
 require(sha(c['postauditPath'])==c['postauditSha256'],'Accepted native101 postaudit changed')
 prior=read(c['postauditPath']);e=prior['execution'];require(prior['sourceAndDependenciesHeld'] is True and prior['passed'] is True and e['exitCode']==0 and e['cleanupOwnedGroupEmpty'] is True and e['diagnosticStopped'] is False and not any(e['oomDelta'].values()),'Accepted local native graph scope was not cleanly passed')
 require(sha(m['acceptedCorePath'])==m['acceptedCoreSha256'] and sha(m['acceptedNativePath'])==m['acceptedNativeSha256'],'Actual accepted source/local-native receipt changed')
 if phase=='cad':
  collection_path=Path(a.get('exportRootCollectionPath',''));require(re.fullmatch('[0-9a-f]{64}',a.get('exportRootCollectionSha256','')) and sha(collection_path)==a['exportRootCollectionSha256'],'Actual Root export collection hash required')
  exported=read(collection_path);post=ROOT/'run-export/POSTAUDIT.json'
  require(exported.get('authorizedByRoot') is True and exported.get('phase')=='export' and exported.get('packetSha256')==packet_sha and exported.get('toolSessionCollected') is True and exported.get('toolWrapperExitCode')==0 and exported.get('postauditPath')==str(post) and exported.get('postauditSha256')==sha(post),'Require actual naturally passed/collected export before native CAD')
  prior=read(post);e=prior['execution'];require(prior['passed'] is True and prior['sourceAndDependenciesHeld'] is True and e['exitCode']==0 and e['cleanupOwnedGroupEmpty'] is True and e['diagnosticStopped'] is False and not any(e['oomDelta'].values()),'Actual export source/deps/group state invalid')
 run=ROOT/('run-'+phase);require(not run.exists(),'One fresh staged run only')
 def before_spawn(mem):require(mem['current']+policy['rssBytes']+m['stages'][phase].get('containerMemoryBytes',0)+m['stages'][phase]['preforkReserveBytes']<policy['sharedBytes'],'Exact host/container/shared byte prefork reserve fails')
 docker_before=None;container_name=None
 if phase=='cad':
  def docker_read(argv):
   result=subprocess.run(['bash',m['managedDockerScript']]+argv,cwd=BOARD,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,check=False,timeout=15)
   require(result.returncode==0,'Managed local Docker metadata command failed: '+argv[0]);return result.stdout.strip()
  def docker_state():
   image=docker_read(['image','inspect',m['kicadImageId'],'--format','{{.Id}}']);require(image==m['kicadImageId'],'Require existing exact checksum-bound KiCad10 image')
   return {'imageId':image,'storageDriver':docker_read(['info','--format','{{.Driver}}']),'sameImageContainerIds':docker_read(['ps','--all','--quiet','--filter','ancestor='+image]).splitlines()}
  docker_before=docker_state();require(not docker_before['sameImageContainerIds'],'Collect prior same-image containers before serial KiCad stage')
  container_name='g350-package101-cad-'+packet_sha[:16]+'-'+args.root_receipt_sha256[:16]
 execution=process_scope.run_guarded([sys.executable,'-B',str(ROOT/'run_stage.py'),phase],str(ROOT),run,policy,{'G350_PACKAGE_CAD_STAGE':phase,'G350_PACKAGE_CAD_PACKET_SHA':packet_sha,'G350_PACKAGE_CAD_ROOT_RECEIPT':str(args.root_receipt.resolve()),'G350_PACKAGE_CAD_ROOT_RECEIPT_SHA':args.root_receipt_sha256},before_spawn=before_spawn)
 docker_after=None
 if phase=='cad':
  # Remove only this exact authority-bound owned container if the host client
  # was stopped before its EXIT trap; never remove another task's container.
  owned=docker_read(['ps','--all','--quiet','--filter','name=^/'+container_name+'$']).splitlines()
  if owned:docker_read(['rm','--force',container_name])
  docker_after=docker_state()
 after_m,after_sha,after,python_after=checked();result_path=run/'result.json';r=read(result_path) if result_path.is_file() else None
 clean=execution['exitCode']==0 and execution['diagnosticStopped'] is False and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values())
 held=packet_sha==after_sha and before==after and python_before==python_after
 docker_clean=phase!='cad' or (docker_before==docker_after and not docker_after['sameImageContainerIds'])
 passed=clean and held and docker_clean and r is not None and r['passed'] is True and r['phase']==phase and r['packetSha256']==packet_sha and r['coreBuildCount']==0 and r['routingCalls']==0 and r['cliCalls']==(1 if phase=='export' else 0) and r['cadCalls']==(1 if phase=='cad' else 0)
 post={'phase':phase,'packetSha256Before':packet_sha,'packetSha256After':after_sha,'rootReceiptSha256':args.root_receipt_sha256,'execution':execution,'dependenciesBefore':before,'dependenciesAfter':after,'pinnedPythonBefore':python_before,'pinnedPythonAfter':python_after,'sourceAndDependenciesHeld':held,'dockerBefore':docker_before,'dockerAfter':docker_after,'dockerImageAndContainerLifecycleHeld':docker_clean,'containerMemorySeparatelyBounded':phase=='cad','containerNetwork':'none' if phase=='cad' else None,'resultSha256':sha(result_path) if result_path.is_file() else None,'passed':passed,'localHs64AndPackage101Only':True,'referenceQualified':False,'accepted49':False,'fabricationReady':False}
 with (run/'POSTAUDIT.json').open('x') as f:json.dump(post,f,indent=2);f.write('\n')
 print(json.dumps({'phase':phase,'passed':passed,'actualCoreCalls':0,'accepted49':False}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
