"""Joint22 actual proposed geometry audit on owner-closed hypothesis; stdlib only."""
from pathlib import Path
import importlib.util,json,math,hashlib,sys,copy,stat,time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
 p=Path(p).resolve();return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)}
def load(p):return json.loads(Path(p).read_text())
def mod(name,p):
 sp=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
MP=HERE/'material-owner-move.py';assert sha(MP)=='1e71fd0a03c0f61867c59af9e7406eb3682cceb742c10ee5b8b74714098785d6';h=mod('joint22_owned_material',MP);q=h.q
u=mod('joint22_intrinsic_checks',BASE/'ddr-cpu19-cap-and-owned32-corner-sourceonly-next/material-context-cap19-owned32-owned4.py')
CA=BASE/'ddr-ca20-early31-and-cpu15-16-corner-followthrough-sourceonly-next/NORMALIZED_MOVED_CPU15_16_SOURCE12_TARGET14_05_ALL20_03.json';assert sha(CA)=='c80864b62256f2f11c00856ede51caa411433a75c11f95d523b93b034f368352'
PROOF=CA.parent/'FINITE_SOURCE12_BOTTOM_MOVED_CPU15_16_HEADER_AND_RAM_SHRINK_PROOF03.json';assert sha(PROOF)=='fdcc0924568303b34541cd4994744c3521e4622b99f3159d844af4e919394208'
hard,rawHard=h.normalize(load(CA));assert len(hard)==20
R=HERE/'FINITE_MOVED_CPU_PAIR_HEAD_REPORT01.json';assert sha(R)=='ec7e34100594c45cb494811e867c8653df4f2f657b54585b84fd09a3dc49b9bd';attempt=load(R);good=[t for t in attempt['trials']if t.get('specializedPairAndOwnMeterPass')];assert len(good)==2
def write(name,d):
 p=HERE/name
 with p.open('x')as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n')
 p.chmod(0o600);return p
# Native context is a transparent planning derivative. It must never count as
# fresh Core/Source/native proof, and the previous original225-preserved flag
# cannot survive a genuine two-owner relocation.
native=copy.deepcopy(q.native)
for i,t in enumerate(native['signalDogbones']):
 if t['pcb_trace_id']in h.oldIds.values():native['signalDogbones'][i]=copy.deepcopy(next(x for x in h.full['traces']if x['pcb_trace_id']==t['pcb_trace_id']))
native['scope']='SOURCE_ONLY_PLANNING_CONTEXT_TWO_AUTHENTIC_CPU_BARRELS_MOVED_NOT_FRESH_CORE'
native['originalPhysical225Preserved']=False;native['held225OtherPhysicalBarrelsAndExactlyTwoRelocatedOwnedCpuBarrels']=True
native['proposedOwnedCpuRelocations']=h.changes;native['actualNewSourceOrPcbViaIds']=None
native['canonicalCoreWithSignalsRendered']=False;native['nativeExecuted']=False;native['cadExecuted']=False
native['referenceQualified']=False;native['accepted49']=False;native['fabricationReady']=False
NP=write('PLANNING_NUMERIC_FULL49_TWO_OWNED_CPU_BARRELS_MOVED.json',h.full)
NV=write('PLANNING_NATIVE_CONTEXT_TWO_OWNED_CPU_BARRELS_MOVED_NOT_CORE.json',native)
assert len(native['signalDogbones'])==98 and len(native['referenceVias'])==129
assert native['allOriginalCopperLands']==q.native['allOriginalCopperLands']and native['original49NumericConnections']==q.native['original49NumericConnections']
results=[];started=time.monotonic()
for i,t in enumerate(good,1):
 rr,raw=h.normalize(t);joined={**hard,**rr};assert len(joined)==22
 checks={}
 for n,r in joined.items():
  scene=h.Scene(r['layer'],joined,n);cert=scene.certificate(r['path'],n);selftest=u.ns['selfcheck']([u.P(*p)for p in r['path']]);angles=u.angles(r['path']);meter=scene.exposure(r['path'],n);whole=q.g.length(r['path'])+h.fixed[n]
  checks[n]={'physical':cert,'self':selftest,'angles':angles,'wholePlanarLengthMm':whole,'reciprocalWholeConductorExposure':meter,'passed':cert['violationCount']==0 and selftest['clear']and angles['allOriginalDirectionDotsPass']and meter['absoluteTICapPass']and meter['noResetOrIntrinsicPairSpacingException']}
 assert all(c['passed']for c in checks.values())
 buses={}
 for b in h.full['buses']:
  values={n:checks[n]['wholePlanarLengthMm']for n in b['connectionNames']if n in checks}
  if not values:continue
  skew=max(values.values())-min(values.values());passed=skew<=b.get('maxLengthSkew',math.inf)+1e-8 and all(b.get('minLength',0)-1e-8<=x<=b.get('maxLength',math.inf)+1e-8 for x in values.values());assert passed
  buses[b['busId']]={'loadedConductorCount':len(values),'expectedConductorCount':len(b['connectionNames']),'allExpectedPresent':len(values)==len(b['connectionNames']),'wholePlanarLengthsMm':values,'loadedSubsetSkewMm':skew,'originalLengthAndLoadedSubsetSkewPass':passed,'electricalTimingAcceptance':False}
 pairskew=abs(checks['source_trace_15']['wholePlanarLengthMm']-checks['source_trace_16']['wholePlanarLengthMm']);assert pairskew<=.127+1e-9
 proof=write(f'JOINT22_ATOMIC_MOVED_PAIR_VARIANT{i:02d}_FULL_STATIC_PROOF.json',{'scope':'SOURCE_ONLY_OWNER_CLOSED_MOVED_CPU_PAIR_SOURCE12_REPAIR_FULL_JOINT22_STATIC','ownerSourceManifestPin':pin(HERE/'OWNER_SOURCE-manifest.json'),'numericPlanningInputPin':pin(NP),'nativePlanningContextPin':pin(NV),'materialHelperPin':pin(MP),'source12NewAll20Pin':pin(CA),'source12FullProofPin':pin(PROOF),'pairFiniteAttemptPin':pin(R),'all22ReciprocalPhysicalSelfAnglesMeters':checks,'originalBusPlanarChecks':buses,'originalDerivedDqs0SharedExteriorCoupling':t['coupling'],'originalPairSkewMm':pairskew,'physicalTotal227WithTwoCpuSitesMovedAnd225Held':True,'twoOwnedUsedBarrelsPerDqs0Signal':True,'onlyNewCpuHeadsWithFrozenE7SharedRamSuffix':True,'allOther20PathsLiteralHeld':True,'freshSourceNativeCoreCadProvenanceNotClaimed':True,'originalCpuBranchesAndAllFrozenMaterialUnmodified':True,'remaining27OriginalRequestsNotRouted':True,'referenceAndElectricalHold':True,'SourceCoreNativeApiCadSdkExecuted':False,'all49Accepted':False,'referenceQualified':False,'electricalTimingPassed':False,'fabricationReady':False})
 allrows=[{k:v for k,v in r.items()if k in ['sourceTraceId','role','class','layer','path','coupledSection','genuineCurvedArcPointRanges']}for r in list(rawHard.values())+list(raw.values())]
 for r in allrows:r['wholePlanarLengthMm']=checks[r['sourceTraceId']]['wholePlanarLengthMm']
 norm=write(f'NORMALIZED_OWNER_MOVED_CPU_DQS0_AND_SOURCE12_JOINT22_VARIANT{i:02d}.json',{'scope':'SOURCE_ONLY_NEW_OWNER_CLOSED_CPU15_16_SITES_SOURCE12_REPAIR_COMPLETE_ATOMIC_DQS0_JOINT22','records':allrows,'strictUniqueCarrierCount':22,'materialEpoch':'ISOLATED227_TWO_OWNED_CPU_BARRELS_MOVED_NOT_FROZEN227','ownerSourceManifestPin':pin(HERE/'OWNER_SOURCE-manifest.json'),'numericPlanningInputPin':pin(NP),'nativePlanningContextPin':pin(NV),'actualStaticReportPin':pin(proof),'all22ReciprocalStaticAndPlanarSubsetLimitsPassed':True,'freshSourceNativeCoreCadNotRun':True,'referenceQualified':False,'electricalTimingPassed':False,'all49Accepted':False,'fabricationReady':False})
 solver=copy.deepcopy(h.carrier);layerdeltas=[]
 for c in solver['connections']:
  if c['name']not in joined:continue
  for side,p in enumerate(c['pointsToConnect']):
   if p['layer']!=joined[c['name']]['layer']:layerdeltas.append({'sourceTraceId':c['name'],'side':side,'before':p['layer'],'after':joined[c['name']]['layer']});p['layer']=joined[c['name']]['layer']
 sv=write(f'PLANNING_SOLVER_VIEW_MOVED_CPU_AND_JOINT22_SELECTED_LAYER_HINTS_VARIANT{i:02d}.json',solver)
 results.append({'normalizedJoint22Pin':pin(norm),'fullProofPin':pin(proof),'numericInputPin':pin(NP),'nativeContextPin':pin(NV),'solverViewPin':pin(sv),'selectedLayerHintDeltasOnlyNotPhysicalChanges':layerdeltas,'wholePairLengthsMm':{n:checks[n]['wholePlanarLengthMm']for n in ['source_trace_15','source_trace_16']},'dqs0PairSkewMm':pairskew,'byte1All11LoadedPlanarSkewMm':buses['DDR_BYTE1']['loadedSubsetSkewMm'],'byte0Loaded3PlanarSkewMm':buses['DDR_BYTE0']['loadedSubsetSkewMm']})
summary=write('RESULT.json',{'scope':'SOURCE_ONLY_FINITE_NEW_CPU_OWNER_SITES_SOURCE12_REPAIR_JOINT22_DONE','outcomes':results,'hypothesisMaterialNotAdopted':True,'newSourceViaPcbViaPcbPortSourceNetIdsCreated':0,'actualCoreNativeApiCadCalls':0,'remainingOriginalSignalCount':27,'all49Accepted':False,'referenceQualified':False,'electricalTimingPassed':False,'fabricationReady':False,'elapsedSeconds':time.monotonic()-started})
external={str(CA),str(PROOF),str(MP),str(h.EP),str(h.CLEAN),str(h.ec.CONTROLLER),str(h.ec.POOL),str(h.q.CONTEXT),attempt['shortE7SharedRamGeometryPin']['path'],str(Path(h.q.context['full49NumericInputPin']['path'])),str(Path(h.q.context['full49CarrierInputPin']['path'])),str(Path(h.q.context['fullNativeContextPin']['path']))}
for module in list(sys.modules.values()):
 f=getattr(module,'__file__',None)
 if f and str(f).startswith('/workspace/g350-linux-handheld/.cloud-tools/')and Path(f).suffix=='.py':external.add(str(Path(f).resolve()))
manifest=write('SOURCE-manifest.json',{'scope':'SOURCE_ONLY_COMPLETE_ATOMIC_MOVED_DQS0_PLUS_REAL_SOURCE12_REPAIR_22_PATH_PROPOSAL','status':'AUTHOR_DONE_STATIC_JOINT22_PASS_REAL_SOURCE_INTEGRATION_UNRUN','files':[pin(p)for p in sorted(HERE.iterdir())if p.is_file()and p.name!='SOURCE-manifest.json'],'externalFiles':[pin(Path(p))for p in sorted(external)],'resultPin':pin(summary),'ownerClosedCpuSites':h.moves,'referenceQualified':False,'electricalTimingPassed':False,'all49Accepted':False,'fabricationReady':False})
print(json.dumps({'manifest':pin(manifest),'outcomes':results,'elapsedSeconds':time.monotonic()-started}))
