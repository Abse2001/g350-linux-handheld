def closed51():
 prior=closed50();assert prior['actualClosedScopeCount']==50
 for key in('actual51CollectionPin','actual51PostauditPin','actual51ReportPin','actual51ExportPin','actual51AuthorityPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
 r=read(proposal['actual51CollectionPin']['path']);p=read(proposal['actual51PostauditPin']['path']);v=read(proposal['actual51ReportPin']['path']);e=r['execution']
 assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==14495 and r['toolWrapperExitCode']==r['toolExitCode']==0
 assert r['scope']==p['scope']=='ROOT_SOURCE26_FRESH_PINNED_CLI_WITH50_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cli'
 assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli26PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual51GuardManifestPin']['sha256']
 assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual51PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['execution']==e
 for doc in(r,p):
  for key in('passed','resultPassed','stageNaturallyCompleted','ownedChildNatural0','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
  for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
  for key in('Source26Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
  assert doc['cliCalls']==1 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
 assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
 h.finite(e,0);assert e['policy']==cli26_policy and e['pid']==e['pgid']==496025 and e['currentGuardPid']==495807 and c.guard.process_scope.owned(496025)==[]and not Path('/proc/495807').exists()
 assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
 assert e['command']==[cli26_contract['pythonInterpreterPin']['path'],'-B',cli26_contract['cliWorkerPin']['path'],'--root-receipt',proposal['actual51AuthorityPin']['path'],'--root-receipt-sha256',proposal['actual51AuthorityPin']['sha256'],'--output-directory',str(Path(proposal['actual51ExportPin']['path']).parent)]
 assert r['reportPath']==p['reportPath']==proposal['actual51ReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual51ReportPin']['sha256']and r['exportPath']==p['exportPath']==proposal['actual51ExportPin']['path']and sha(r['exportPath'])==r['exportSha256']==p['exportSha256']==proposal['actual51ExportPin']['sha256']
 assert r['actualCoreSha256']==p['actualCoreSha256']==v['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==v['coreControlsSha256']==proposal['actual48CoreControlsPin']['sha256']
 assert v['scope']==cli26_preparation['scope']and v['sourceManifestSha256']==proposal['cli26PreparationPin']['sha256']and v['exportPassed']is v['byteIdenticalCopyOnly']is v['nativeAndOriginalApiStagesPassed']is True and v['cliExitCode']==0
 assert v['recognizedCircuitJsonSha256']==proposal['actual48CoreRawPin']['sha256']and v['outputPath']==proposal['actual51ExportPin']['path']and v['outputSha256']==proposal['actual51ExportPin']['sha256']and v['actualSourceSegmentCount']==1001 and v['actualSourceOwnedCarrierCount']==26 and v['actualPhysicalViaCount']==227 and v['actualPhysicalTraceCount']==289 and v['sourceOnlyMissingRoutes']==23
 assert v['actualNativeReport']==proposal['actual49ReportPin']and v['actualOriginalApiReport']==proposal['actual50ApiReportPin']
 assert v['argv']==[cli26_preparation['bun'],'--smol',cli26_preparation['cliMainPath'],'export',str(Path(proposal['actual51ExportPin']['path']).parent/'fresh-source26.circuit.json'),'--format','kicad_pcb','--output',proposal['actual51ExportPin']['path'],'--disable-parts-engine']
 for key in('originalRawEdited','sourceModuleEvaluated','sourcePortHookReplayedByCli','automaticCoreSrjUsed','complete26Accepted','referenceQualified','electricalTimingQualified','accepted49','fabricationReady'):assert v[key]is False
 for row in p['outputFiles']:binding(row)
 prior['actual51Source26CliSuccessCollectionPin']={'path':proposal['actual51CollectionPin']['path'],'sha256':proposal['actual51CollectionPin']['sha256']};prior['actualClosedScopeCount']=51;prior['actual51CliDoesNotQualifyFreshCadOrFull49']=True
 return prior
