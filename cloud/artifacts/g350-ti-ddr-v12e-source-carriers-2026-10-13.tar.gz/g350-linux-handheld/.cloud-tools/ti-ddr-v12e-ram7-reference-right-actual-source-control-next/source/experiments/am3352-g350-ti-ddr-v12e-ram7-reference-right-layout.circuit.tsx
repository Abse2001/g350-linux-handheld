import {buildV12eSource} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-ram7-reference-right-source-proposal-next/v12e-ram7-reference-right-overlay"
export default()=>buildV12eSource().element
