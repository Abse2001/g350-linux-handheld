"""Execute exactly one Root-authorized stage; never CLI/export/routing."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 phase=sys.argv[1] if len(sys.argv)==2 else None
 if phase not in ('capture','types','core') or os.environ.get('G350_HS_ROOT_STAGE')!=phase:raise ValueError('Exact Root stage env required')
 manifest=ROOT/'PREPARED-manifest.json';m=json.loads(manifest.read_bytes())
 if os.environ.get('G350_HS_PACKET_SHA')!=sha(manifest):raise ValueError('Packet changed')
 authority=Path(os.environ['G350_HS_ROOT_RECEIPT']);a=json.loads(authority.read_bytes())
 if sha(authority)!=os.environ['G350_HS_ROOT_RECEIPT_SHA'] or a.get('authorizedByRoot') is not True or a.get('phase')!=phase or a.get('packetSha256')!=sha(manifest):raise ValueError('Root receipt changed')
 run=ROOT/('run-'+phase);report={'phase':phase,'packetSha256':sha(manifest),'commands':[],'passed':False,'coreBuildCount':0,'cliCalls':0,'routingCalls':0,'cadCalls':0,'accepted49':False,'fabricationReady':False}
 def save(): (run/'result.json').write_text(json.dumps(report,indent=2)+'\n')
 def command(name,argv,cwd):
  started=time.monotonic()
  with (run/(name+'.log')).open('xb') as out:r=subprocess.run(argv,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,check=False)
  report['commands'].append({'name':name,'argv':argv,'cwd':str(cwd),'exitCode':r.returncode,'seconds':time.monotonic()-started});save()
  if r.returncode:raise ValueError('Stage command failed: '+name)
 try:
  if phase=='capture':
   capture=run/'actual-source-additions.json'
   command('pure-exact124-additions',[m['bun'],'--smol',str(ROOT/'source/capture-exact-additions.ts'),str(capture)],ROOT/'source')
   c=json.loads(capture.read_bytes())
   if not(c['actualSourceTreeEvaluated'] is True and c['originalElementsCompared']==1746 and c['addedLiteralViaTraceElements']==124 and c['allOriginalPropsTypesKeysChildrenHeld'] is True and c['ram7OriginalElementsHeld'] is True):raise ValueError('Exact actual pure addition capture failed')
   report.update(captureSha256=sha(capture),pureOriginalPropsHeld=True)
  elif phase=='types':
   command('syntax-check-manufacturing-graph-helper',[m['node'],'--check',str(ROOT/'check-fresh-native-and-hs-loops.mjs')],ROOT)
   command('typecheck-actual-new-source',m['typecheckCommand'],ROOT/'source')
   report.update(typecheckPassed=True,nativeHelperSyntaxPassed=True)
  else:
   actual=run/'fresh-core.circuit.json';report['coreBuildCount']=1
   command('direct-pinned-core',[m['bun'],'--smol',str(ROOT/'source/render-direct-core.ts'),str(actual)],Path(m['coreWorkingDirectory']))
   actual_sha=sha(actual);report['actualCoreSha256']=actual_sha;save()
   command('strict-original-and-additions',[sys.executable,'-B',str(ROOT/'verify-original-core-and-additions.py'),str(actual),actual_sha,str(run/'actual-source-forward.json')],ROOT)
   command('native17-loop64-manufacturing',[m['bun'],'--smol',str(ROOT/'check-fresh-native-and-hs-loops.mjs'),str(actual),actual_sha,str(run/'native-loop-report.json')],ROOT)
   forward=json.loads((run/'actual-source-forward.json').read_bytes());native=json.loads((run/'native-loop-report.json').read_bytes())
   if not(forward['sourceForwardPassed'] is True and forward['original280Parts1161ContactsHeld'] is True and forward['ram7CorePhysicalRecordsExact'] is True and native['sourceSha256']==actual_sha and native['checkCount']==18 and native['physicalErrors']==0 and len(native['hsTerminalLoops'])==64 and native['rawNative17InputUnmodified'] is True and native['allManufacturingProjectionGeometryAndNetsHeld'] is True):raise ValueError('Actual Core/known graph/native/manufacturing result failed')
   report.update(actualSourceForwardSha256=sha(run/'actual-source-forward.json'),nativeLoopReportSha256=sha(run/'native-loop-report.json'),native17Passed=True,local64CapStubViaGraphsPassed=True,manufacturingPassed=True,original217Links280Parts1161ContactsHeld=True)
  report['passed']=True;save();print(json.dumps({'phase':phase,'passed':True,'coreBuildCount':report['coreBuildCount'],'accepted49':False}));return 0
 except BaseException as error:
  report['failure']=str(error);save();raise
if __name__=='__main__':raise SystemExit(main())
