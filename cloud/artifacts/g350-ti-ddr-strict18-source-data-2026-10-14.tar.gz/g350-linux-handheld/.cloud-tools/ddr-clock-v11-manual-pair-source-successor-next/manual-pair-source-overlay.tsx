/** Explicit manual-only Source successor. No SDK or frozen source is edited.
 * This module does not provide automatic Core SRJ differential discovery.
 * The complete immutable 49-signal routing input supplies all original pair
 * gap/coupling rules and must be used for routing and independent qualification.
 */
import { Children, cloneElement, createElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { buildCombinedClockV11FidelitySource, registerClockInnerPorts } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-signal96-clock-v11-source-contract-next/clock-fidelity-source-overlay"
import clockProposal from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-signal96-clock-v11-source-contract-next/clock-fidelity-source-proposal.json"
import input49 from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-plus96-signals-combined-sourceonly-next/combined-input.json"
type Props = Record<string, unknown> & { name?: string; children?: ReactNode }
const pairDefinitions = [
  { name: "DDR_DQS0_PAIR", positiveConnection: "DDR_DQS0", negativeConnection: "DDR_DQSn0", sourceTraceIds: ["source_trace_15", "source_trace_16"] },
  { name: "DDR_DQS1_PAIR", positiveConnection: "DDR_DQS1", negativeConnection: "DDR_DQSn1", sourceTraceIds: ["source_trace_28", "source_trace_27"] },
  { name: "DDR_CK_PAIR", positiveConnection: "DDR_CK", negativeConnection: "DDR_CKn", sourceTraceIds: ["source_trace_33", "source_trace_34"] },
]
export function buildManualPairClockV11Source() {
  const base = buildCombinedClockV11FidelitySource()
  const localNames = clockProposal.clockCarriers.flatMap(c => [c.cpu.traceName,c.ram.traceName])
  const suppressed = new Set<string>(), represented = new Set<string>()
  const pairChanges: Array<{ name: string; originalType: "differentialpair"; originalProps: Record<string,unknown>; replacementType: "bus"; replacementProps: Record<string,unknown> }> = []
  if (input49.connections.length !== 49 || input49.differentialPairs.length !== 3) throw Error("Complete original 49-signal routing input required")
  for (const pair of pairDefinitions) {
    const declaration = input49.differentialPairs.find(p => JSON.stringify(p.connectionNames) === JSON.stringify(pair.sourceTraceIds))
    if (!declaration || declaration.lengthTolerance !== .127 || declaration.traceGap !== .12)
      throw Error("Original pair skew/gap assertions cannot be weakened")
  }
  function fork(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const props = { ...node.props }, children = Children.toArray(props.children).map(fork)
    if (props.name && localNames.includes(props.name)) {
      if (node.type !== "trace" || !Array.isArray(props.pcbPath) || props.pcbPath.length !== 0 || suppressed.has(props.name))
        throw Error("Exactly four failed predecessor local-clock pcbPath arrays required")
      // cloneElement merges old props. Omission/delete leaves pcbPath=[];
      // explicitly overriding with undefined disables manual PCB rendering.
      props.pcbPath = undefined
      suppressed.add(props.name)
    }
    const pair = pairDefinitions.find(p => p.name === props.name)
    if (pair) {
      const { children: _children, ...originalProps } = props
      if (node.type !== "differentialpair" || represented.has(pair.name) || children.length !== 0
        || props.positiveConnection !== pair.positiveConnection || props.negativeConnection !== pair.negativeConnection
        || props.maxLengthSkew !== .127 || props.pcbTraceGap !== .12
        || Object.keys(originalProps).sort().join(",") !== "maxLengthSkew,name,negativeConnection,pcbTraceGap,positiveConnection")
        throw Error("Exact original three differential declarations/types/props required")
      const replacementProps = { name: pair.name, connections: [pair.positiveConnection,pair.negativeConnection], maxLengthSkew: .127 }
      pairChanges.push({ name: pair.name, originalType: "differentialpair", originalProps, replacementType: "bus", replacementProps })
      represented.add(pair.name)
      // Public Bus resolves exactly two original named Source traces. It keeps
      // original serialized pair rows/skew without expanding local aliases.
      return createElement("bus", { ...replacementProps, key: node.key }, ...children)
    }
    if (node.type === "board" && (props.layers !== 4 || props.routeRemaining !== false)) throw Error("Manual four-layer board contract required")
    return cloneElement(node as ReactElement<Props>, props, ...children)
  }
  const element = fork(base.element)
  if (suppressed.size !== 4 || represented.size !== 3 || pairChanges.length !== 3) throw Error("Exact finite manual Source fork required")
  return { ...base, element, manualPairSourceFork: {
    scope: "EXPLICIT_MANUAL_ROUTING_SOURCE_ONLY_PAIR_BUS_REPRESENTATION",
    pairChanges, suppressedLocalClockTraceNames: [...suppressed],
    complete49AuthoritativeRoutingInputPath: "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-plus96-signals-combined-sourceonly-next/combined-input.json",
    complete49AuthoritativeRoutingInputSha256: "ed97be5fae82111e8e08247ba97f2a4a5977d33bd1b901a0428a1cf155af59fc",
    originalDifferentialPairDeclarations: input49.differentialPairs,
    originalSkewToleranceMm: .127, originalTraceGapMm: .12,
    originalCouplingAPIsStillRequiredAgainstActualPhysicalGeometry: true,
    automaticCoreSrjDifferentialDiscoveryEquivalent: false,
    automaticCoreSrjForThisForkMustNotBeUsed: true,
    manualRoutingRequired: true, sourceExecuted: false, coreRendered: false, nativeExecuted: false,
    accepted49: false, fabricationReady: false,
  } }
}
export { registerClockInnerPorts }
export default () => buildManualPairClockV11Source().element
