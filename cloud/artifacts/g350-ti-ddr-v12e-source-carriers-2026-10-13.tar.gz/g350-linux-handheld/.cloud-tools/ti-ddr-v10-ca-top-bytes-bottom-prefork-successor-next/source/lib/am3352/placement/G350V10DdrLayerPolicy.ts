import policy from "./g350-ti-ddr-v10-layer-policy.json"

export type NativeBusPolicy = {
  busId: string; connectionNames: string[]; traceWidth: number
  allowedLayers: ("top" | "bottom")[]; preferredLayers: ("top" | "bottom")[]
  maxLengthSkew?: number; minLength?: number; maxLength?: number
}
export type GroupPolicy = {nativeBus: NativeBusPolicy; logicalConnections: string[]}
export type PairPolicy = {name: string; ownerBusId: string; nativePair: {
  connectionNames: string[]; lengthTolerance: number; traceGap: number
}; logicalConnections: string[]}
export const v10LayerPolicy = policy
export const v10Groups = policy.groups as GroupPolicy[]
export const v10Pairs = policy.pairs as PairPolicy[]
export const groupPolicyByName = new Map(v10Groups.map(group => [group.nativeBus.busId, group]))
export const pairPolicyByName = new Map(v10Pairs.map(pair => [pair.name, pair]))
