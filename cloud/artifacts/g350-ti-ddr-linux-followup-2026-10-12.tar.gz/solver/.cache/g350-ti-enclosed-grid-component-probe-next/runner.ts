import { strict as assert } from "node:assert"
import { createHash } from "node:crypto"
import { readFileSync, writeFileSync } from "node:fs"
import { join } from "node:path"
import { runCapturedGridProbe, fingerprint } from "./grid-probe"
assert.deepEqual(process.argv.slice(2), ["--run-one-approved"])
assert.equal(process.env.G350_ENCLOSED_GRID_PROBE_APPROVED, "1")
const root = import.meta.dir,
  sha = (raw: string | Uint8Array) =>
    createHash("sha256").update(raw).digest("hex"),
  raw = readFileSync(join(root, "packet-manifest.json")),
  packet = JSON.parse(raw.toString())
const bound = (name: string) => {
  const bytes = readFileSync(join(root, name))
  assert.equal(sha(bytes), packet.inputBindings[name].sha256)
  return JSON.parse(bytes.toString())
}
const capture = bound("capture.json"),
  parent = bound("parent-result.json"),
  post = bound("parent-postflight.json"),
  phase = bound("parent-connectors-result.json")
assert.equal(post.resultTrustEligible, true)
assert.equal(
  post.resultSha256,
  packet.inputBindings["parent-result.json"].sha256,
)
assert.equal(parent.captureSha256, packet.inputBindings["capture.json"].sha256)
assert.equal(parent.originalBoundaryClosed, true)
const phasePost = bound("parent-connectors-postflight.json")
assert.ok(
  phasePost.execution.exitCode === 0 &&
    !phasePost.execution.diagnosticStopped &&
    phasePost.execution.cleanupOwnedGroupEmpty === true &&
    phasePost.sceneResultSha256 ===
      packet.inputBindings["parent-connectors-result.json"].sha256,
  "Prior connector phase must be collected unchanged",
)
assert.ok(
  phase.inputSha256 === packet.inputBindings["capture.json"].sha256 &&
    phase.sceneInputHash === fingerprint(capture.input) &&
    phase.sceneCopperHash === fingerprint(capture.copper) &&
    phase.sceneOwnersHash === fingerprint(capture.owners) &&
    phase.sceneWidth === capture.width &&
    phase.sceneMargin === capture.margin,
  "Bound actual connector phase Scene parity changed",
)
assert.ok(
  phase.candidates.length === 5 &&
    phase.candidates.every((candidate: any) => candidate.visible === false) &&
    phase.gridConstructed === false,
  "All five original connectors must be blocked before optionalGrid diagnostic",
)
const [scene, grid] = await Promise.all([
  import("./source/lib/vector-scene"),
  import("./source/lib/grid-visibility"),
])
const probe = runCapturedGridProbe(capture, {
  Scene: scene.VectorScene,
  Grid: grid.GridVisibilitySearch,
})
const result = {
  ...probe,
  packetSha256: sha(raw),
  sourceCommit: packet.sourceRevision,
  libTree: packet.libTree,
  parentBoundaryTrusted: true,
  parentConnectorsAllBlocked: true,
  parentCaptureSha256: packet.inputBindings["capture.json"].sha256,
  diagnosticQualified: probe.sceneParityHeld && probe.inputAndCopperHeld,
}
const output = JSON.stringify(result, null, 2) + "\n"
assert.ok(Buffer.byteLength(output) <= 4 * 1024 ** 2)
writeFileSync(join(root, "run/result.json"), output, { flag: "wx" })
console.log(
  JSON.stringify({
    status: result.status,
    beforeCancel: result.beforeCancel,
    accepted49: false,
  }),
)
