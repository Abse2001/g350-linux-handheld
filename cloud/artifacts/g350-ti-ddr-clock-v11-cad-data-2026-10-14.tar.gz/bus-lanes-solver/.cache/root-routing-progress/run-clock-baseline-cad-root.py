import hashlib, importlib.util, json, os, secrets, stat, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
BOARD = Path('/workspace/g350-linux-handheld')
PACKET = BOARD / '.cloud-tools/ddr-clock-v11-fresh-kicad-baseline-diagnostic-sourceonly-next'
OUT = PACKET / 'run-cad'
POLICY = {'wallSeconds': 90, 'rssBytes': 1073741824, 'sharedBytes': 32212254720, 'sampleSeconds': .05, 'termGraceSeconds': 5}
def read(p): return json.loads(Path(p).read_bytes())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n,p):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
guard=load('clock_cad_guard_library',BOARD/'.cloud-tools/ddr-clock-v11-fresh-core-native-sourceonly-next/guard.py')
worker=load('clock_cad_source_library',PACKET/'inspect-baseline.py')
def bindings():
    m=read(PACKET/'SOURCE-manifest.json')
    for row in m['ownFiles']:
        p=Path(row['path']); assert p.is_file() and not p.is_symlink()
        assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'] and oct(stat.S_IMODE(p.stat().st_mode))==row['mode']
    for p,h in worker.INPUTS.items(): assert sha(p)==h and p.is_file() and not p.is_symlink()
    return sha(PACKET/'SOURCE-manifest.json')
def main():
    assert len(sys.argv)==3
    peer_path=Path(sys.argv[1]); assert sha(peer_path)==sys.argv[2]
    peer=read(peer_path); packet=bindings()
    assert peer['sourceManifestSha256']==packet and peer['decision']=='GO_SOURCE_ONLY_TO_ROOT_OWNED_NEGATIVE_BASELINE_DIAGNOSTIC'
    _,native_sha,board_before,solver_before,_=guard.checked()
    a=read(ROOT/'clock-v11-fresh-native-root.json')
    rows=[a['requiredActual42982Collection'],*a['additionalPreviousRootCollections'],*a['successfulPriorStages'].values(),a['successfulCoreCollection']]
    rows += [{'path':str(ROOT/f),'sha256':sha(ROOT/f)} for f in ['clock-v11-fresh-native-42626-COLLECTED-root.json','clock-v11-fresh-cli-87907-COLLECTED-root.json']]
    def closed():
        for row in rows: assert guard.process_scope.owned(guard.collected(row)[2]['pgid'])==[]
    closed(); assert not OUT.exists()
    OUT.mkdir(); output=OUT/'output'; output.mkdir()
    name='g350-clock-v11-baseline-cad-'+secrets.token_hex(8)+'-'+secrets.token_hex(8)
    docker=['bash',str(BOARD/'scripts/cloud-docker.sh')]
    def container_empty():
        p=subprocess.run(docker+['ps','--all','--quiet','--filter','name=^/'+name+'$'],capture_output=True,text=True,timeout=20)
        assert p.returncode==0; return not p.stdout.strip()
    assert container_empty()
    authority={'authorizedByRoot':True,'sourceManifestSha256':packet,'rootFullWorkerReadPassed':True,'noConcurrentRootWorker':True,'priorCollectedRows':rows,'peerPath':str(peer_path),'peerSha256':sha(peer_path),'containerName':name,'policy':POLICY,'containerMemoryBytes':2147483648,'accepted49':False,'fabricationReady':False}
    with (OUT/'ROOT_AUTHORITY.json').open('x') as f: json.dump(authority,f,indent=2);f.write('\n')
    authority_sha=sha(OUT/'ROOT_AUTHORITY.json')
    def prefork(mem):
        closed(); assert mem['current']+POLICY['rssBytes']+2147483648+1073741824<POLICY['sharedBytes']
    argv=['bash',str(PACKET/'run-kicad-offline.sh'),str(output),name,str(PACKET/'inspect-baseline.py'),'--output-directory',str(output)]
    execution=guard.process_scope.run_guarded(argv,str(BOARD),OUT/'owned',POLICY,{},before_spawn=prefork)
    if not container_empty():
        p=subprocess.run(docker+['rm','--force',name],capture_output=True,text=True,timeout=20); assert p.returncode==0
    empty=container_empty()
    _,native_after,board_after,solver_after,_=guard.checked()
    held=bindings()==packet and native_after==native_sha and board_before==board_after and solver_before==solver_after and sha(peer_path)==sys.argv[2] and sha(OUT/'ROOT_AUTHORITY.json')==authority_sha
    closed()
    report_path=output/'baseline-report.json'; report=read(report_path) if report_path.is_file() else None
    complete=held and empty and execution['cleanupOwnedGroupEmpty'] and not execution['diagnosticStopped'] and not any(execution['oomDelta'].values()) and report is not None and report.get('diagnosticCompleted') is True and report.get('allInputBytesHeld') is True
    diagnostic_expected=complete and execution['exitCode']==2 and report.get('passed') is False and report.get('signalViaNetZeroCount')==96 and report.get('signalViaNetMismatchCount')==96 and report.get('numericPadTopstubAgreementCount')==96
    outputs=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)} for p in sorted(output.iterdir()) if p.is_file()]
    post={'scope':'ACTUAL_FRESH_CLOCK_V11_BASELINE_KICAD10_DIAGNOSTIC','sourceManifestSha256':packet,'execution':execution,'sourceAndDependenciesHeld':held,'dependenciesBefore':board_before,'dependenciesAfter':board_after,'solverDependenciesBefore':solver_before,'solverDependenciesAfter':solver_after,'ownedContainerRemoved':empty,'containerName':name,'reportPath':str(report_path),'reportSha256':sha(report_path) if report_path.is_file() else None,'outputFiles':outputs,'diagnosticCompleted':complete,'expectedNet0FailureObserved':diagnostic_expected,'passed':False,'cadCalls':1,'accepted49':False,'fabricationReady':False}
    with (OUT/'POSTAUDIT.json').open('x') as f: json.dump(post,f,indent=2);f.write('\n')
    print(json.dumps({k:post[k] for k in ['diagnosticCompleted','expectedNet0FailureObserved','sourceAndDependenciesHeld','ownedContainerRemoved','passed','reportPath','execution']}))
    return 0 if diagnostic_expected else 2
if __name__=='__main__': raise SystemExit(main())
