"""Root-only readonly reuse of saved actual Core; no rebuild, CLI, CAD, routing."""
from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(value,message):
 if not value:raise ValueError(message)
def main():
 m=json.loads((ROOT/'PREPARED-manifest.json').read_bytes());packet=sha(ROOT/'PREPARED-manifest.json')
 require(os.environ.get('G350_HS_READONLY_STAGE')=='readonly' and os.environ.get('G350_HS_PACKET_SHA')==packet,'Exact Root readonly environment required')
 authority=Path(os.environ['G350_HS_ROOT_RECEIPT']);a=json.loads(authority.read_bytes())
 require(sha(authority)==os.environ['G350_HS_ROOT_RECEIPT_SHA'] and a.get('authorizedByRoot') is True and a.get('phase')=='readonly' and a.get('packetSha256')==packet,'Exact Root receipt required')
 run=ROOT/'run-readonly';actual=Path(m['reusedActualCorePath']);actual_sha=m['reusedActualCoreSha256']
 require(sha(actual)==actual_sha,'Saved actual Core changed')
 report={'phase':'readonly','packetSha256':packet,'commands':[],'passed':False,'reusedActualCoreSha256':actual_sha,'coreBuildCount':0,'cliCalls':0,'routingCalls':0,'cadCalls':0,'referenceQualified':False,'accepted49':False,'fabricationReady':False}
 def save():(run/'result.json').write_text(json.dumps(report,indent=2)+'\n')
 def command(name,argv):
  started=time.monotonic()
  with (run/(name+'.log')).open('xb') as out:r=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=False)
  report['commands'].append({'name':name,'argv':argv,'cwd':str(ROOT),'exitCode':r.returncode,'seconds':time.monotonic()-started});save()
  require(r.returncode==0,'Readonly command failed: '+name)
 try:
  command('strict-original-and-additions-pinned-target',[m['pythonExecutable'],'-B',str(ROOT/'pinned-python-verify.py'),str(actual),actual_sha,str(run/'actual-source-forward.json'),str(run/'python-gate.json')])
  command('native17-loop64-manufacturing',[m['bun'],'--smol',str(ROOT/'check-fresh-native-and-hs-loops.mjs'),str(actual),actual_sha,str(run/'native-loop-report.json')])
  forward=json.loads((run/'actual-source-forward.json').read_bytes());native=json.loads((run/'native-loop-report.json').read_bytes());gate=json.loads((run/'python-gate.json').read_bytes())
  require(forward['sourceForwardPassed'] is True and forward['actualCoreSha256']==actual_sha and forward['original280Parts1161ContactsHeld'] is True and forward['original217LogicalLinksHeldByOriginal119TwoPortTracesAnd98Nets'] is True and forward['ram7CorePhysicalRecordsExact'] is True,'Strict actual source parity failed')
  require(len(forward['retainedReferenceCutProofs'])==2 and all(p['newForeignViaCuts']==31 and p['outerRingExact'] is True and p['originalCopperMinusOnlyOwnedAntipads'] is True for p in forward['retainedReferenceCutProofs']),'Strict31-cut retained-reference proof failed')
  require(native['sourceSha256']==actual_sha and native['checkCount']==18 and native['physicalErrors']==0 and len(native['hsTerminalLoops'])==64 and native['rawNative17InputUnmodified'] is True and native['allManufacturingProjectionGeometryAndNetsHeld'] is True and gate['tinyGeometryPassed'] is True,'Native/known64-loop/manufacturing/gate failed')
  report.update(actualSourceForwardSha256=sha(run/'actual-source-forward.json'),nativeLoopReportSha256=sha(run/'native-loop-report.json'),pythonGateSha256=sha(run/'python-gate.json'),native17Passed=True,local64CapStubViaGraphsPassed=True,manufacturingPassed=True,original217Links280Parts1161ContactsHeld=True,strict31ForeignCutProofPassed=True,passed=True);save()
  print(json.dumps({'phase':'readonly','passed':True,'reusedActualCoreSha256':actual_sha,'coreBuildCount':0,'accepted49':False}));return 0
 except BaseException as error:report['failure']=str(error);save();raise
if __name__=='__main__':raise SystemExit(main())
