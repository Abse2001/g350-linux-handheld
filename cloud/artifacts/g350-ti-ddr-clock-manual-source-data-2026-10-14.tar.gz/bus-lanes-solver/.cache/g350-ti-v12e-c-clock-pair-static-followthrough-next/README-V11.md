# Manual four-layer clock successor — source only

V11 contains two complete Inner1 CPU-to-RAM clock carriers for the current RAM
(1.2,6.2),270-degree placement. It retains every captured signal fanout and all129
accepted package-reference vias. It does not route the other47 DDR signals.

The actual static construction replaces the obstructing originalCPU33 approach,
keeps a common0.2216mm-pitch offset trunk through the RAM field, and compensates
length in the open left corridor. CPU33 uses a0.389mm-radius tangent approach
around the unchanged CPU34 barrel; CPU34 uses a0.105mm-radius smooth package
bend. Endpoint IDs, Top stubs, both full-span barrel dimensions and all original
width/clearance/length/coupling limits remain unchanged.

Planar lengths including the original two Top stubs are21.17470019353158mm and
21.08792356852441mm; skew0.08677662500717mm passes the authored0.127mm pair limit.
Both remain inside the original20.95–23.49mm command/clock PLANAR window. The
historical native1.6mm-per-transition number adds3.2mm to each, producing
24.37470019353158mm and24.28792356852441mm. That separate nominal model is not
an electrical delay result and must not silently replace the solver's planar
length interpretation.

Stdlib-only capsule checks include all129 new reference disks, the captured
foreign signal material and the mate. Minimum clearance slacks are+0.0031747468mm
and+0.0098233992mm. Translations of the original self/shared/exterior checks pass:
self7381/2556 segment pairs; shared maximum edge gap0.1378846446mm plus at most
0.001mm sampling uncertainty is below0.1402581116mm; exterior separated length0.
All ordinary turn angles remain at most45degrees. These are static geometric
calculations. No solver package, native checker, Core or CAD ran here.

Earlierfailedmaterial remains separate: V1 CPU bend clearance, V6 RAM return,
V7 skew, V8 sharp ordinary corners, V9 small-bevel self-clear, and V10 tiny
returning-arm spacing. No failure is relabeled as an accepted result.

Root must run the original APIs against the full combined scene before reuse:

```bash
source /workspace/g350-linux-handheld/cloud/env.sh
/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe \
  /workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-clock-pair-static-followthrough-next/check-original-api.ts \
  /workspace/g350-linux-handheld/.cloud-tools/ddr-package101-plus96-signals-combined-sourceonly-next/combined-ca-carrier-input.json \
  /workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-clock-pair-static-followthrough-next/finite-fully-paired-result-v11.json \
  EXCLUSIVE_NEW_REPORT_JSON
```

Suggested limit:60seconds/512MiB owned RSS, using Root's current serial owned
process guard and exact source/dependency inventories. The checker preserves the
raw report before failing; it never routes or changes the material. It imports
original128-runtime continuous visibility, self-clear, conventional angles,
shared/exterior/total coupling and planar window/pair-length functions. Its
two-clock length view leaves all26 original CA requests untouched and makes no
full-cohort pass claim.

Native continuation must register both actualclock carriers against original
numeric CPU/RAM pins and their96-source fanout aliases, with the full225-barrel,
261-local-trace material. The existing jointNative prelude only qualifies the
local fanouts. Fresh literalSource/Core must reproduce the numeric Top stubs,
registered standard through-vias and every Inner1 carrier point. Selecting a
Top via port and merely describing an Inner1 wire is not an established Core
serializer contract; inspect and verify the real layer/port handling rather
than fabricating ownership or inserting duplicate barrels. Fresh KiCad10
connectivity is required before accepting the clocks as hardware routes.

Full26-CA/49-DDR timing,3x/4x class spacing, references/PDN/impedance/electrical
models, all other board nets and shell fit remain unqualified.
`accepted49=false`; `fabricationReady=false`.
