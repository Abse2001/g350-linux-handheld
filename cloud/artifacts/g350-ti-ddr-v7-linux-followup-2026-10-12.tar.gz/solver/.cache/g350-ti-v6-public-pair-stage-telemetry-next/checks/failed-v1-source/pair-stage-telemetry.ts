type ModuleKey = "planner" | "coupled" | "bounded" | "sites"
type Modules = Record<ModuleKey, Record<string, any>>
type Method = "next" | "throw" | "return"
type Counts = {
  factories: number
  next: number
  throw: number
  return: number
  errors: number
  offers: number
  naturalBody: number
  naturalNull: number
  capNull: number
}
type Row = {
  id: number
  kind: ModuleKey
  caller: string
  names: string
  layers: string
  preferPackageOnlyTuning: boolean | null
  allowProvisionalPairTuning: boolean | null
  argumentCount: number
  precheckEnclosedTerminals: boolean | null
  variant: number | null
  maxTopologyVariants: number | null
  limit: number | null
  linkedChildId: number | null
  next: number
  throw: number
  return: number
  yielded: number
  errors: number
  offers: number
  cleanupRequested: boolean
  completion: string | null
  traceCount: number | null
  pointCount: number | null
  shapeHash: string | null
}
type Tracking = {
  id: number
  kind: ModuleKey
  group: string
  row?: Row
  next: number
  throw: number
  return: number
  yielded: number
  cleanupRequested: boolean
  lastNextDone?: boolean
  naturalKind?: string
  child?: Tracking
  childNextStart: number
  childReturnStart: number
  childThrowStart: number
  limit?: number
}
const freshCounts = (): Counts => ({
  factories: 0,
  next: 0,
  throw: 0,
  return: 0,
  errors: 0,
  offers: 0,
  naturalBody: 0,
  naturalNull: 0,
  capNull: 0,
})

/** Passive exported-factory/iterator observer. Arguments, feedback, receivers,
 * results and thrown values pass through. Only bounded scalar records survive;
 * wrapped iterator identities are held exclusively through WeakMaps. */
export function installPairStageTelemetry(
  modules: Modules,
  publish: (snapshot: unknown) => void,
  replaceModuleExports?: (key: ModuleKey, exports: Record<string, any>) => void,
  hashTuple?: (tuple: unknown[]) => string,
) {
  const names: Record<ModuleKey, string> = {
    planner: "planSharedPairCorridors",
    coupled: "routeCoupledPair",
    bounded: "runBoundedRouting",
    sites: "negotiateSignalSites",
  }
  const keys = Object.keys(names) as ModuleKey[]
  const originalExports = Object.fromEntries(
    keys.map((key) => [key, { ...modules[key] }]),
  ) as Modules
  const descriptors = Object.fromEntries(
    keys.map((key) => [
      key,
      Object.getOwnPropertyDescriptor(modules[key], names[key])!,
    ]),
  ) as Record<ModuleKey, PropertyDescriptor>
  const replace =
    replaceModuleExports ??
    ((key: ModuleKey, exports: Record<string, any>) =>
      Object.defineProperty(modules[key], names[key], {
        ...descriptors[key],
        value: exports[names[key]],
      }))
  const totals = freshCounts(),
    overflow = freshCounts()
  const groups = new Map<string, Counts>()
  const rows: Row[] = [],
    events: Record<string, string | number | boolean | null>[] = []
  const rawToTracking = new WeakMap<object, Tracking>()
  const proxyToRaw = new WeakMap<object, object>()
  const rawToProxy = new WeakMap<object, object>()
  let observationErrors = 0,
    droppedEvents = 0,
    restored = false
  const observe = (work: () => void) => {
    try {
      work()
    } catch {
      observationErrors++
    }
  }
  const groupCounts = (group: string) => {
    const existing = groups.get(group)
    if (existing) return existing
    if (groups.size === 128) return overflow
    const created = freshCounts()
    groups.set(group, created)
    return created
  }
  const scalar = (value: unknown) =>
    typeof value === "number" && Number.isFinite(value) ? value : null
  const caller = () =>
    (
      new Error().stack
        ?.split("\n")
        .map((line) => line.match(/\/lib\/([^\s)]+\.ts):(\d+)(?::\d+)?/))
        .find((match) => match)
        ?.slice(1)
        .join(":") ?? "unknown"
    ).slice(0, 96)
  const snapshot = () => ({
    ...totals,
    observationErrors,
    maxFactoryRows: 64,
    rowLimit: 64,
    eventLimit: 128,
    groupLimit: 128,
    droppedRows: Math.max(0, totals.factories - rows.length),
    droppedEvents,
    rows: rows.map((row) => ({ ...row })),
    events: events.map((event) => ({ ...event })),
    groups: Object.fromEntries(
      [...groups].map(([key, value]) => [key, { ...value }]),
    ),
    overflow: { ...overflow },
  })
  const emit = () => observe(() => publish(snapshot()))
  const event = (value: Record<string, string | number | boolean | null>) => {
    if (events.length < 128) events.push(value)
    else droppedEvents++
  }
  const rawReceiver = (value: any) =>
    value !== null && (typeof value === "object" || typeof value === "function")
      ? (proxyToRaw.get(value) ?? value)
      : value
  const bodyScalars = (tracking: Tracking, value: unknown[]) => {
    const pointCount = value.reduce(
      (sum: number, trace: any) =>
        sum + (Array.isArray(trace?.route) ? trace.route.length : 0),
      0,
    )
    const hash = hashTuple?.(value)
    const scalars = {
      traceCount: value.length,
      pointCount,
      shapeHash: typeof hash === "string" ? hash.slice(0, 96) : null,
    }
    if (tracking.row) {
      tracking.row.traceCount = value.length
      tracking.row.pointCount = pointCount
      tracking.row.shapeHash = scalars.shapeHash
    }
    return scalars
  }
  const instrumentResult = (
    tracking: Tracking,
    method: Method,
    result: any,
  ) => {
    if (method !== "next") return
    tracking.lastNextDone = result?.done === true
    if (!tracking.lastNextDone) {
      tracking.yielded++
      if (tracking.row) tracking.row.yielded++
      if (
        tracking.kind === "planner" &&
        !tracking.cleanupRequested &&
        Array.isArray(result?.value)
      ) {
        totals.offers++
        groupCounts(tracking.group).offers++
        if (tracking.row) tracking.row.offers++
        const scalars = bodyScalars(tracking, result.value)
        event({ kind: "planner-tuple-offer", id: tracking.id, ...scalars })
      }
      return
    }
    if (tracking.cleanupRequested || tracking.naturalKind !== undefined) return
    const kind = Array.isArray(result.value)
      ? "body"
      : result.value === null
        ? "null"
        : result.value === undefined
          ? "undefined"
          : "other"
    tracking.naturalKind = kind
    let completion = `natural-next-${kind}`
    if (tracking.kind === "bounded" && kind === "null") {
      const child = tracking.child
      if (child?.naturalKind === "null") completion = "child-natural-null"
      else if (
        child?.lastNextDone === false &&
        tracking.limit === 6000 &&
        tracking.yielded === 6000 &&
        child.next - tracking.childNextStart === 6001 &&
        child.return - tracking.childReturnStart === 1 &&
        child.throw - tracking.childThrowStart === 0
      ) {
        completion = "bounded-6000-cap-null"
        totals.capNull++
        groupCounts(tracking.group).capNull++
      } else completion = "bounded-null-unknown"
    }
    if (kind === "body") {
      totals.naturalBody++
      groupCounts(tracking.group).naturalBody++
      if (tracking.kind === "coupled" || tracking.kind === "planner")
        bodyScalars(tracking, result.value)
    }
    if (kind === "null") {
      totals.naturalNull++
      groupCounts(tracking.group).naturalNull++
    }
    if (tracking.row) tracking.row.completion = completion
    event({ kind: "next-done", id: tracking.id, completion })
  }
  const wrapIterator = (raw: any, tracking: Tracking) => {
    if (raw === null || (typeof raw !== "object" && typeof raw !== "function"))
      return raw
    const prior = rawToProxy.get(raw)
    if (prior) return prior
    const methods = new Map<
      PropertyKey,
      { original: Function; wrapped: Function }
    >()
    const proxy = new Proxy(raw, {
      get(target, key) {
        const original = Reflect.get(target, key, target)
        if (
          (key !== "next" &&
            key !== "throw" &&
            key !== "return" &&
            key !== Symbol.iterator) ||
          typeof original !== "function"
        )
          return original
        const previous = methods.get(key)
        if (previous?.original === original) return previous.wrapped
        const wrapped = function (this: any, ...args: any[]) {
          const receiver = rawReceiver(this)
          if (key === Symbol.iterator) {
            const result = Reflect.apply(original, receiver, args)
            return result === receiver &&
              result !== null &&
              (typeof result === "object" || typeof result === "function")
              ? (rawToProxy.get(result) ?? result)
              : result
          }
          const actual =
            receiver !== null &&
            (typeof receiver === "object" || typeof receiver === "function")
              ? rawToTracking.get(receiver)
              : undefined
          const method = key as Method
          observe(() => {
            totals[method]++
            groupCounts(actual?.group ?? "untracked-receiver")[method]++
            if (actual) {
              actual[method]++
              if (actual.row) actual.row[method]++
              if (method === "return") {
                actual.cleanupRequested = true
                if (actual.row) {
                  actual.row.cleanupRequested = true
                  if (actual.naturalKind === undefined)
                    actual.row.completion = "caller-close-unknown"
                }
                event({ kind: "return-request", id: actual.id })
              }
            }
          })
          try {
            const result = Reflect.apply(original, receiver, args)
            observe(() => {
              if (actual) instrumentResult(actual, method, result)
            })
            return result
          } catch (error) {
            observe(() => {
              totals.errors++
              groupCounts(actual?.group ?? "untracked-receiver").errors++
              if (actual?.row) actual.row.errors++
              event({
                kind: "iterator-method-error",
                id: actual?.id ?? null,
                method,
              })
            })
            throw error
          } finally {
            if (
              method !== "next" ||
              actual?.lastNextDone ||
              totals.next % 1000 === 0
            )
              emit()
          }
        }
        methods.set(key, { original, wrapped })
        return wrapped
      },
    })
    rawToTracking.set(raw, tracking)
    proxyToRaw.set(proxy, raw)
    rawToProxy.set(raw, proxy)
    return proxy
  }
  const replacements = {} as Modules
  for (const key of keys) {
    const original = originalExports[key][names[key]]
    const factory = new Proxy(original, {
      apply(target, receiver, args) {
        totals.factories++
        const tracking: Tracking = {
          id: totals.factories,
          kind: key,
          group: "unknown",
          next: 0,
          throw: 0,
          return: 0,
          yielded: 0,
          cleanupRequested: false,
          childNextStart: 0,
          childReturnStart: 0,
          childThrowStart: 0,
        }
        observe(() => {
          const location = caller(),
            input = args[0]
          const pairNames =
            key === "coupled"
              ? args[1]?.connectionNames
              : input?.differentialPairs?.flatMap(
                  (pair: any) => pair.connectionNames,
                )
          const connectionNames = (Array.isArray(pairNames) ? pairNames : [])
            .filter((name) => typeof name === "string")
            .slice(0, 8)
          const named = connectionNames.join(",").slice(0, 96)
          const layers = (
            Array.isArray(input?.connections) ? input.connections : []
          )
            .filter(
              (connection: any) =>
                !connectionNames.length ||
                connectionNames.includes(connection.name),
            )
            .flatMap(
              (connection: any) =>
                connection.pointsToConnect?.map((point: any) => point.layer) ??
                [],
            )
          const layerNames = [
            ...new Set(
              layers.filter((layer: unknown) => typeof layer === "string"),
            ),
          ]
            .slice(0, 8)
            .join(",")
            .slice(0, 96)
          const options = args[3]
          const searchOptions =
            key === "coupled"
              ? args[4]
              : key === "planner"
                ? args[3]
                : undefined
          if (key === "bounded") {
            tracking.child = rawToTracking.get(rawReceiver(args[0]))
            tracking.limit = typeof args[1] === "number" ? args[1] : undefined
            tracking.childNextStart = tracking.child?.next ?? 0
            tracking.childReturnStart = tracking.child?.return ?? 0
            tracking.childThrowStart = tracking.child?.throw ?? 0
          }
          tracking.group = JSON.stringify([key, location, named, layerNames])
          groupCounts(tracking.group).factories++
          if (rows.length < 64) {
            tracking.row = {
              id: tracking.id,
              kind: key,
              caller: location,
              names: named,
              layers: layerNames,
              argumentCount: args.length,
              preferPackageOnlyTuning:
                typeof options?.preferPackageOnlyTuning === "boolean"
                  ? options.preferPackageOnlyTuning
                  : null,
              allowProvisionalPairTuning:
                typeof options?.allowProvisionalPairTuning === "boolean"
                  ? options.allowProvisionalPairTuning
                  : null,
              precheckEnclosedTerminals:
                typeof searchOptions?.precheckEnclosedTerminals === "boolean"
                  ? searchOptions.precheckEnclosedTerminals
                  : null,
              variant: scalar(options?.variant),
              maxTopologyVariants: scalar(options?.maxTopologyVariants),
              limit: scalar(tracking.limit),
              linkedChildId: tracking.child?.id ?? null,
              next: 0,
              throw: 0,
              return: 0,
              yielded: 0,
              errors: 0,
              offers: 0,
              cleanupRequested: false,
              completion: null,
              traceCount: null,
              pointCount: null,
              shapeHash: null,
            }
            rows.push(tracking.row)
          }
          event({
            kind: "factory-entry",
            id: tracking.id,
            factory: key,
            caller: location,
          })
          emit()
        })
        try {
          const result = Reflect.apply(target, receiver, args)
          // Site telemetry observes entry only; its original iterator is exact.
          return key === "sites" ? result : wrapIterator(result, tracking)
        } catch (error) {
          observe(() => {
            totals.errors++
            groupCounts(tracking.group).errors++
            if (tracking.row) tracking.row.errors++
            event({ kind: "factory-error", id: tracking.id, factory: key })
          })
          throw error
        }
      },
    })
    replacements[key] = { ...originalExports[key], [names[key]]: factory }
  }
  const restore = () => {
    if (restored) return
    let failed = false,
      firstError: unknown
    for (const key of keys) {
      try {
        replace(key, originalExports[key])
      } catch (error) {
        if (!failed) firstError = error
        failed = true
      }
    }
    if (failed) throw firstError
    restored = true
  }
  try {
    for (const key of keys) replace(key, replacements[key])
  } catch (error) {
    try {
      restore()
    } catch {
      /* Preserve the original installation error. */
    }
    throw error
  }
  return { snapshot, restore }
}
