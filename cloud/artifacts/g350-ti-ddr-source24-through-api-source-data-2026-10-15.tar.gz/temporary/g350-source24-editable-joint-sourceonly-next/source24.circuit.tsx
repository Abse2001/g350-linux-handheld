// Source declarations only. This module never injects Circuit JSON or assigns fresh IDs.
// Absolute imports resolve the existing pinned React singleton even from this /tmp packet.
import { Children, cloneElement, createElement, isValidElement } from "/workspace/g350-linux-handheld/node_modules/react/index.js"
import type { ReactElement, ReactNode } from "/workspace/g350-linux-handheld/node_modules/@types/react/index.d.ts"
import { buildOwnerMoved23Source, registerOwnerMoved23InnerPorts } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-owner23-display-offset-compact-source-successor-next/source23.circuit"
import data from "./source24-proposal.json"
import type { Source24Proposal } from "./source24-types"
const proposal = data as unknown as Source24Proposal
const plan = proposal.source24Delta
const fields = ["pcbPath", "pcbPaths", "pcbPathRelativeTo"] as const
type Props = Record<string, unknown> & { name?: string; children?: ReactNode }
const canonical = (v: unknown): string => Array.isArray(v) ? `[${v.map(canonical).join(",")}]`
  : v && typeof v === "object" ? `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical((v as Record<string, unknown>)[k])}`).join(",")}}` : JSON.stringify(v) ?? "undefined"
const mm = (v: unknown): number => {
  if (typeof v === "number" && Number.isFinite(v)) return v
  if (typeof v === "string" && /^-?\d+(?:\.\d+)?mm$/.test(v)) return Number(v.slice(0, -2))
  throw Error("A finite genuine millimeter value is required")
}
const routeProps = (p: Props) => Object.fromEntries(fields.filter(k => p[k] !== undefined).map(k => [k, p[k]]))
function requireSealedShape() {
  if (proposal.scope !== "UNEXECUTED_EDITABLE_SOURCE24_JOINT_SUCCESSOR_OF_AUTHENTIC_SOURCE687"
    || proposal.parent23Source.sha256 !== "68798e7d9132d01d15cd2b67db31fdfe5d18bc745c86defd39de9e598129d565"
    || proposal.sealedJointGeometry.sha256 !== "179defe748275a3928912f3c57e4a10bfe27dd36b467d4ac70b5fc9cfb6ca25b"
    || plan.sealedCandidatePin.sha256 !== proposal.sealedJointGeometry.sha256
    || plan.movedVia.name !== "V_TI_SIGNAL_source_trace_14_1"
    || canonical(plan.routeChanges.map(r => r.originalSourceTraceId).sort()) !== canonical(["source_trace_14", "source_trace_27", "source_trace_28"])
    || canonical(plan.newTwoInnerPorts.map(p => `${p.viaName}:${p.layer}`).sort()) !== canonical(["V_TI_SIGNAL_source_trace_14_0:inner1", "V_TI_SIGNAL_source_trace_14_1:inner1"])
    || plan.localSuppressions.length !== 2 || proposal.all49OriginalLogicalTraces.length !== 49
    || proposal.expectedCounts.carrierPaths !== 24 || proposal.expectedCounts.physicalTraces !== 287
    || proposal.expectedCounts.innerLiteralPorts !== 38 || proposal.expectedCounts.expectedSourcePorts !== 1653
    || proposal.expectedCounts.expectedReactElements !== 2270 || proposal.expectedCounts.remainingOriginal49Requests !== 25
    || proposal.primaryCoupledSectionView !== "lower_coupled_U" || proposal.secondaryCoupledSectionView !== "early_reflected_meander"
    || proposal.singleCoupledSectionCoversBoth !== false || proposal.bothActualSharedMeandersMustBeChecked !== true)
    throw Error("The exact reviewed Source687/joint24 declaration contract is required")
}
/** One existing RAM barrel move, three original logical route declarations,
 * two local path suppressions and two real inner Port children; all else held. */
export function buildOwnerMoved24Source() {
  requireSealedShape()
  const base = buildOwnerMoved23Source()
  const moved = new Set<string>(), changed = new Set<string>(), locals = new Set<string>(), ports = new Set<string>(), logical = new Set<string>()
  let boards = 0
  function fork(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const props: Props = { ...node.props }
    const children = Children.toArray(props.children).map(fork)
    if (props.name === plan.movedVia.name) {
      if (node.type !== "via" || mm(props.pcbX) !== plan.movedVia.before.x || mm(props.pcbY) !== plan.movedVia.before.y
        || props.fromLayer !== "top" || props.toLayer !== "bottom" || mm(props.outerDiameter) !== .4572 || mm(props.holeDiameter) !== .254
        || moved.has(props.name)) throw Error("Exact parent existing full-span RAM owner required")
      props.pcbX = plan.movedVia.after.x; props.pcbY = plan.movedVia.after.y; moved.add(props.name)
    }
    const requested = plan.newTwoInnerPorts.find(p => p.viaName === props.name)
    if (requested) {
      if (node.type !== "via" || children.length !== 0 || props.fromLayer !== "top" || props.toLayer !== "bottom"
        || mm(props.outerDiameter) !== .4572 || mm(props.holeDiameter) !== .254
        || mm(props.pcbX) !== requested.viaXY.x || mm(props.pcbY) !== requested.viaXY.y || ports.has(requested.viaName))
        throw Error("An existing exact full-span owner must receive one genuine Inner1 Port")
      children.push(createElement("port", { name: requested.layer, layer: requested.layer })); ports.add(requested.viaName)
    }
    const change = plan.routeChanges.find(c => c.logicalName === props.name)
    if (change) {
      if (node.type !== "trace" || props.from !== change.fromSelector || props.to !== change.toSelector || props.path !== undefined
        || canonical(routeProps(props)) !== canonical(change.beforeRouteProps) || changed.has(change.originalSourceTraceId))
        throw Error("Exact parent original numeric route declaration required")
      for (const field of fields) props[field] = undefined
      props.pcbPaths = change.after.newPcbPaths; props.pcbPathRelativeTo = change.after.newPcbPathRelativeTo
      changed.add(change.originalSourceTraceId)
    }
    const local = plan.localSuppressions.find(c => c.traceName === props.name)
    if (local) {
      if (node.type !== "trace" || props.from !== local.numericSelector || props.to !== `.${local.viaName} > port.top`
        || mm(props.thickness) !== .1016 || props.pcbPathRelativeTo !== `.${local.viaName} > port.top`
        || props.pcbPaths !== undefined || canonical(props.pcbPath) !== "[]" || locals.has(local.traceName))
        throw Error("Exact parent Source14 Top local declaration required")
      props.pcbPath = undefined; locals.add(local.traceName)
    }
    const original = proposal.all49OriginalLogicalTraces.find(row => row.name === props.name)
    if (original) {
      if (node.type !== "trace" || props.from !== original.from || props.to !== original.to || logical.has(original.originalSourceTraceId))
        throw Error("Every original49 numeric pad-to-pad logical owner must remain exact")
      logical.add(original.originalSourceTraceId)
    }
    if (node.type === "board") {
      boards++
      if (props.layers !== 4 || props.routeRemaining !== false || (props.pcbX ?? 0) !== 0 || (props.pcbY ?? 0) !== 0 || (props.pcbRotation ?? 0) !== 0)
        throw Error("Existing manual unrotated four-layer board required")
    }
    return cloneElement(node as ReactElement<Props>, props, ...children)
  }
  const element = fork(base.element)
  if (boards !== 1 || moved.size !== 1 || changed.size !== 3 || locals.size !== 2 || ports.size !== 2 || logical.size !== 49)
    throw Error("Exact narrow Source24 declaration delta required")
  return { ...base, element, ownerMoved24Proposal: data, ownerMoved24SourceIntegration: {
    scope: "UNQUALIFIED_SOURCE24_EDITABLE_DECLARATIONS", changedViaNames: [...moved], changedOriginalSourceTraceIds: [...changed],
    changedLocalTraceNames: [...locals], newRealPortParents: [...ports], expectedCounts: proposal.expectedCounts,
    newBarrelsAdded: false, circuitJsonInjectionOrIdAssignment: false, source24ActualCoreQualified: false,
    bothDqs1CoupledViewsRequireFreshOriginalApi: true, singleCoupledSectionCoversBoth: false,
    automaticCoreSrjForManualPairBusForkMustNotBeUsed: true, all49Accepted: false, referenceQualified: false, electricalTimingPassed: false, fabricationReady: false,
  } }
}
type Via = { componentName: string; props: Props; pcb_via_id?: string | null; source_manually_placed_via_id?: string | null }
type Port = { componentName: string; props: Props; parent: unknown; matchedComponents: unknown[]; source_port_id?: string | null; pcb_port_id?: string | null; registerMatch(component: unknown): void; getAvailablePcbLayers(): string[] }
type Circuit = { _hasRenderedAtleastOnce?: boolean; schematicDisabled?: boolean; selectOne(selector: string, options?: { type?: string }): unknown }
/** Public matches only, before first render. Core must allocate fresh IDs. */
export function registerOwnerMoved24InnerPorts(circuitUnknown: unknown) {
  requireSealedShape()
  const circuit = circuitUnknown as Circuit
  if (circuit._hasRenderedAtleastOnce || circuit.schematicDisabled !== true) throw Error("Unrendered actual PCB-only Circuit required")
  const prior = registerOwnerMoved23InnerPorts(circuitUnknown)
  if (prior.registrations.length !== 36) throw Error("Exactly36 held real parent registrations required")
  const registrations = [...prior.registrations]
  for (const requested of plan.newTwoInnerPorts) {
    const via = circuit.selectOne(`.${requested.viaName}`) as Via | null
    const port = circuit.selectOne(`.${requested.viaName} > port.${requested.layer}`, { type: "port" }) as Port | null
    if (!via || via.componentName !== "Via" || via.props.name !== requested.viaName || via.props.fromLayer !== "top" || via.props.toLayer !== "bottom"
      || mm(via.props.outerDiameter) !== .4572 || mm(via.props.holeDiameter) !== .254
      || mm(via.props.pcbX) !== requested.viaXY.x || mm(via.props.pcbY) !== requested.viaXY.y
      || !port || port.componentName !== "Port" || port.parent !== via || port.props.name !== requested.layer || port.props.layer !== requested.layer
      || port.source_port_id || port.pcb_port_id || via.pcb_via_id || via.source_manually_placed_via_id
      || port.getAvailablePcbLayers().join(",") !== requested.layer || port.matchedComponents.some(owner => owner !== via))
      throw Error("One genuine unrendered Inner1 Port and its exact existing full-span Via required")
    if (!port.matchedComponents.includes(via)) port.registerMatch(via)
    if (port.matchedComponents.length !== 1 || port.matchedComponents[0] !== via) throw Error("Exact public owner registration required")
    registrations.push({ viaName: requested.viaName, layer: requested.layer, xy: requested.viaXY, numericSelector: requested.numericSelector })
  }
  if (registrations.length !== 38 || new Set(registrations.map(row => `${row.viaName}:${row.layer}`)).size !== 38)
    throw Error("Exactly38 unique real inner registrations required")
  return { registrations, extraPhysicalViaFromPortRegistration: false, coreRendered: false, nativeExecuted: false }
}
export default () => buildOwnerMoved24Source().element
