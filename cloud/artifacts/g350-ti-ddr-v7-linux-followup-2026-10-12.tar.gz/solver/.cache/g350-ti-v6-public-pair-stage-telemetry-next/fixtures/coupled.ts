export const coupledExtra = Symbol("coupled original export")
export function* routeCoupledPair(
  input: any,
  pair: any,
  _fixed: unknown,
  _options?: unknown,
) {
  yield input.feedback
  return pair.connectionNames.map((connection_name: string) => ({
    connection_name,
    route: [
      { x: 0, y: 0 },
      { x: 1, y: 1 },
    ],
  }))
}
