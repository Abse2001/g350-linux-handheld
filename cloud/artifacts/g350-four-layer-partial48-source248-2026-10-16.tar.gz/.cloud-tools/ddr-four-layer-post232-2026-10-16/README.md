Resume routing from latestSourceVerifiedCheckpoint in PROGRESS.json: actual
SOURCE248 has48/49 numeric-connected DDR routes. Only DDR_D12/source_trace_26
is pending. Its editable Source capture/full inverse, all35 Core248 controls,
critical244 both actual DQS1 views/all five APIs, focused native249 physical10
and other requested geometry checks, authenticated229-via track checks250, and
all14 literal-pour foreign-margin comparisons passed their stated scopes.

Current routing candidate after restoration:
/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json
SHA256 cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720
Saved payload: CAP12_TOPOLOGY243_MODEL48_byte0-result.candidate.json
Actual raw Source248: /tmp/g350-cap12-48-core248-raw.json
Controls: /tmp/g350-cap12-48-core-diagnostic-root-20261016-run248/byte0-result.json
Exact plan: /tmp/g350-cap12-48-projector-root-20261016-run245/byte0-result.json
These paths and mode/hash restore rows are in WORKSPACE_RESTORE_MANIFEST.json.
The named cap12 moves+X0.79 with exactly two pads/ports and two0.2mm Bottom
reference reroutes; its complete inverse and all held hardware remain explicit.

The all14-pour aggregate checks actual229 fullspan vias and957 routed-signal wire
segments against the exact fresh BREP regions, at0.1016mm foreign edge margin.
It excludes reference-wire geometry and does not prove reference continuity or
own-net reentry. No Source23615-pour result is inherited. Only focused16 native
checks were rerun; other16 are historical/not retested. All3 bus-skew checks FAIL;
this branch has only3/26 CA owners at the retained20.95mm minimum. Full timing,
TI/reference continuity, electrical readiness, CAD, default-board promotion,
all49 acceptance and fabrication readiness remain FALSE.

The primaryCandidate field intentionally remains the INDEPENDENT Source233 /
Source23647-route, CA13 timing fallback for archive-schema and dependency
continuity. It is not the preferred routing resume point. Its candidate and
Source23615-pour aggregate are unchanged and must not be combined with this48
branch's qualification. latestSourceVerifiedCheckpoint unambiguously names48.

Closed251/252 are negative bounded alternatives: all48 pre-search paths, fixed
head and critical views passed, but neither found a qualified D12 in that model.
Their proposed42 bodies, two proofs and independent static report are diagnostic
only and do not replace Source248. They do not prove board-wide infeasibility.
Core247's OBJ loader exception remains recorded; Core248's unchanged-behavior
diagnostic retry passed. No loader fix is asserted.

SOURCE248_CAP12_PARTIAL48_FOUR_LAYER_MILESTONE.png and.svg are the actual Root-
rendered/reviewed four-layer views with only D12 highlighted pending. Plot Source
and exact image hashes are indexed. The7 earlier TI analysis files retain their
reference-material gap witnesses and stricter original Source CA minimum; no
TI/reference/electrical claim is made by this snapshot.

Restore Source209, then Source228, then this Source248 archive/saved directory.
Exact prior archive/manifest dependencies are recorded; this collector does not
copy or rewrite either prior archive. The compatible saved-workspace verifier is:
python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post232-2026-10-16
Use its --restore flag only after prior dependencies are restored; it refuses
different existing bytes/modes. This collector ran no SDK/application import,
archive creation or commit, and did not execute that supplied restore helper.

FROZEN at closed252 + scoped all14-pour pass + reviewed plot. All later Source2,
lower-bank or other routing diagnostics MUST use a NEW saved directory. Exact
earlier metadata remains in HISTORY_THROUGH* files. Older Source209/post209
payloads/metadata and all independent fallback geometry remain frozen unchanged.
