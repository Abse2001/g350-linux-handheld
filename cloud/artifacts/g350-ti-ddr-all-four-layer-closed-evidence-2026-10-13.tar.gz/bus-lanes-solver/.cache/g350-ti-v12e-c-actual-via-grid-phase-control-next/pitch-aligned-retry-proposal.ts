import type { Point, SimpleRouteJson } from "/workspace/bus-lanes-solver/lib/types"

/** Unadopted, default-off retry proposal. The caller must first establish the
 * relevant physical via-field pitch and phase. It does not replace an existing
 * coarse search or its fine fallback, and has no production call site. */
export function pitchAlignedRetryGrid(options: {
  enabled?: boolean
  pitch: number
  phase: Point
  coarseStep: number
  fineStep: number
  bounds: SimpleRouteJson["bounds"]
  boardBounds: SimpleRouteJson["bounds"]
}): { step: number; bounds: SimpleRouteJson["bounds"] } | undefined {
  if (options.enabled !== true) return
  const { pitch, phase, coarseStep, fineStep, bounds, boardBounds } = options
  if (![pitch, phase.x, phase.y, coarseStep, fineStep,
    ...Object.values(bounds), ...Object.values(boardBounds)].every(Number.isFinite)
    || pitch <= 0 || fineStep <= 0 || coarseStep <= fineStep
    || bounds.minX >= bounds.maxX || bounds.minY >= bounds.maxY
    || boardBounds.minX >= boardBounds.maxX || boardBounds.minY >= boardBounds.maxY) return
  const step = pitch / Math.ceil(pitch / coarseStep)
  // GridVisibilitySearch clamps smaller values to 0.01, which would destroy
  // this phase. Duplicate/finer-than-fallback attempts bring no useful retry.
  if (step < .01 || step <= fineStep || step > coarseStep) return
  const lo = (value: number, origin: number) => origin + Math.floor((value - origin) / step) * step
  const hi = (value: number, origin: number) => origin + Math.ceil((value - origin) / step) * step
  const aligned = {
    minX: lo(bounds.minX, phase.x), maxX: hi(bounds.maxX, phase.x),
    minY: lo(bounds.minY, phase.y), maxY: hi(bounds.maxY, phase.y),
  }
  // Refuse an expansion outside the unchanged physical board bounds. Clamping
  // the origin would discard the intended phase; the original fallback remains.
  if (aligned.minX < boardBounds.minX || aligned.maxX > boardBounds.maxX
    || aligned.minY < boardBounds.minY || aligned.maxY > boardBounds.maxY) return
  return { step, bounds: aligned }
}
