/** Visibility only: deliberately no original source function is invoked. */
import { strict as assert } from "node:assert"
import { joinSignalEscapes } from "./source/lib/join-signal-escapes"
import { validateG350PathIntegrity } from "./source/scripts/g350-path-integrity"
import { nativeSignalGeometryIsValid } from "./source/lib/native-signal-geometry"
import { pairLengthReports } from "./source/lib/route-lengths"
import { pairCouplingReports } from "./source/lib/pair-coupling"
import { exteriorPairSpacingReports } from "./source/lib/exterior-pair-spacing"
import { boardOutlineViolations } from "./source/lib/board-outline"
import { generatedEscapeHolesConflict } from "./source/lib/expanded-signal-sites"
import { validateRoutedCopperDrc } from "@tscircuit/fanout-solver"
for (const fn of [
  joinSignalEscapes,
  validateG350PathIntegrity,
  nativeSignalGeometryIsValid,
  pairLengthReports,
  pairCouplingReports,
  exteriorPairSpacingReports,
  boardOutlineViolations,
  generatedEscapeHolesConflict,
  validateRoutedCopperDrc,
])
  assert.equal(typeof fn, "function")
console.log(
  JSON.stringify({
    visibilityOnly: true,
    sourceCalls: 0,
    checkerCalls: 0,
    routingCalls: 0,
  }),
)
