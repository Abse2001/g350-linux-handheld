"""Tiny pure geometry-policy controls. Never execute Circuit/export/checker/router."""
from pathlib import Path
import copy,json,unittest
from validate_v7 import validate_delta,courtyard_metrics,synthetic_control
ROOT=Path(__file__).resolve().parent
V6=json.loads((ROOT/'inputs/v6-layout.circuit.json').read_bytes());POSES=json.loads((ROOT/'source/lib/am3352/placement/g350-ti-top-bottom-ddr-v7-translation.json').read_bytes())
class Tests(unittest.TestCase):
 def test_exact_rigid_translation_positive_and_inverse(self):
  model=synthetic_control(V6);normalized,changes=validate_delta(V6,model,POSES);self.assertTrue(len(changes)>100);self.assertTrue(all(r['declaredRigidMovement'] for r in changes));self.assertTrue(courtyard_metrics(model)['all18MovedPartMarginsQualified'])
 def test_unplanned_cpu_move_rejected(self):
  model=synthetic_control(V6);cpu=next(e for e in model if e['type']=='pcb_component' and e['pcb_component_id']=='pcb_component_0');cpu['center']['x']+=.02
  with self.assertRaisesRegex(ValueError,'freshRigidDelta'):validate_delta(V6,model,POSES)
 def test_reference_route_or_barrel_not_rigid_rejected(self):
  for kind in ['pcb_via','pcb_trace']:
   model=synthetic_control(V6);row=next(e for e in model if e['type']==kind)
   if kind=='pcb_via':row['x']-=.02
   else:row['route'][0]['x']-=.02
   with self.assertRaisesRegex(ValueError,'rigidReference'):validate_delta(V6,model,POSES)
if __name__=='__main__':unittest.main()
