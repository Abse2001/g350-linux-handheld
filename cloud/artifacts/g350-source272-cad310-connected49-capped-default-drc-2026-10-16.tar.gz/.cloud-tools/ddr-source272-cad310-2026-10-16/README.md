Source272 CAD310:49 numeric signal graphs and exact geometry PASS.
Default KiCad DRC returned2102 violations+499 opens under per-code caps; five checks ignored by defaults.
All returned findings and failed304 are retained. No fullboard/TI/timing/fabrication pass.
The304 receipt records exit0, but its incomplete checker report records TypeError; exit0 is not semantic qualification.
Restore exact209→228→248→257→272-v2→289 archives first. This is a separate data increment.
Workspace CAD copies are data-only and are never restored by the legacy helper.
The huge rootfs/image is excluded; runtime recreation and any new CAD execution require a separate Root operation.
