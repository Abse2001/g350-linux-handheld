"""Finite stdlib future24 actual-artifact contract. No SDK/CAD imports.
The Root fills actual prerequisite hashes only after authentic collected0.
"""
import hashlib,json,math,re,stat
from pathlib import Path
BOARD=Path('/workspace/g350-linux-handheld');HERE=Path(__file__).parent
SOURCE_SHA='126266323739fb916b0ba1180b61265f23078a32af5938de61a24318bc57dbba'
NATIVE_SOURCE_SHA=None
API_SOURCE_SHA=None
SIGNAL_PROPOSAL=BOARD/'.cloud-tools/ddr-source26-reset-source3-editable-source-stages-sourceonly-next/source26-proposal.json'
SIGNAL_SHA='c6f7d64f945f64a8fe746685760e5d996bad8850faef4d03a831edcd403c5fff'
RAW=CONTROLS=RAW_SHA=CONTROLS_SHA=ACTUAL_NATIVE_COLLECTION=ACTUAL_NATIVE_REPORT=ACTUAL_API_COLLECTION=ACTUAL_API=None
STATE=None
ACTUAL_CORE_BATCH_COLLECTION={'path': '/workspace/bus-lanes-solver/.cache/root-routing-progress/source26-three-stage-60108-PASS-COLLECTED-root.json', 'sha256': '3fef1110d53c6228dab11e6d758947dfa2181b3dbb5d5f520129793dfdc861ce', 'bytes': 48370, 'mode': 384}
def require(v,label):
 if not v:raise ValueError(label)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def regular(p):
 p=Path(p);require(p.is_absolute()and p.is_file()and not p.is_symlink(),'Absolute regular artifact');return p
def load(row):
 require(isinstance(row,dict)and isinstance(row.get('path'),str)and isinstance(row.get('sha256'),str)and re.fullmatch('[0-9a-f]{64}',row['sha256']),'Concrete actual binding, no placeholder')
 p=regular(row['path']);require(p.stat().st_size<=32*1024*1024 and sha(p)==row['sha256'],'Exact finite actual artifact');return json.loads(p.read_bytes())
def binding(row):
 p=regular(row['path']);require(p.stat().st_size==row['bytes']and stat.S_IMODE(p.stat().st_mode)==row['mode']and sha(p)==row['sha256'],'Exact Source binding')
def one(rows,label):
 require(len(rows)==1,label+'; matches='+str(len(rows)));return rows[0]
def near(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])<1e-8
def index(raw,kind):
 rows=[r for r in raw if r['type']==kind];out={r[kind+'_id']:r for r in rows};require(len(rows)==len(out),'Unique actual '+kind);return out
def collected(row):
 c=load(row);require(c.get('authorizedByRoot')is True and c.get('toolSessionCollected')is True and c.get('passed')is True and c.get('toolExitCode')==c.get('toolWrapperExitCode')==0 and isinstance(c.get('toolSessionId'),int),'Actual successful collected Root natural0')
 post=load({'path':c['postauditPath'],'sha256':c['postauditSha256']});e=post['execution'];require(c['execution']==e and e['exitCode']==0 and e['diagnosticStopped']is False and e['cleanupOwnedGroupEmpty']is True and not any(e['oomDelta'].values()),'Actual natural child0/closed/OOM0')
 require(c['sourceAndDependenciesHeld']is True and post['sourceAndDependenciesHeld']is True and post['passed']is True,'Source/SDK held0')
 for prefix,digest in [('dependencies','ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'),('solverDependencies','47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6')]:require(post[prefix+'Before']==post[prefix+'After']and post[prefix+'After']['treeSha256']==digest,'Complete ce3/476 held')
 require(any(k in post for k in ('accepted49','all49Accepted'))and all(post[k]is False for k in ('accepted49','all49Accepted')if k in post)and post['fabricationReady']is False,'Partial acceptance remains explicit')
 if post.get('scope')=='ROOT_SOURCE26_FRESH49_PROJECTION_AND_API119_WITH_AUTHENTIC_PRIOR_CLOSURES':
  pe=post['projectionExecution'];require(post['apiExecution']==e and pe['exitCode']==0 and pe['cleanupOwnedGroupEmpty']is True and pe['diagnosticStopped']is False and not pe['stopReasons']and not any(pe['oomDelta'].values()),'Actual serial projection child0/closed/OOM0')
  require(post['projectionOwnedChildWaitReturned']is post['projectionOwnedGroupEmptyActuallyObserved']is post['apiOwnedGroupEmptyActuallyObserved']is post['bothOwnedGroupsIndependentlyObservedEmpty']is post['projectionBeforeApiSeriallyEnforced']is True and pe['pgid']!=e['pgid']and pe['endedAt']<=e['startedAt'],'Both distinct owned children closed serially')
 return c,post
def produced(post,row):
 key='outputFiles';require(isinstance(post.get(key),list),'Current actual Core/Native/API outputFiles schema')
 require(any(r['path']==row['path']and r['sha256']==row['sha256']for r in post[key]),'Actual collected output required');return load(row)
def authority(row,manifest_sha,scope):
 global STATE,RAW,CONTROLS,RAW_SHA,CONTROLS_SHA,ACTUAL_NATIVE_COLLECTION,ACTUAL_NATIVE_REPORT,ACTUAL_API_COLLECTION,ACTUAL_API
 a=load(row);require(a.get('authorizedByRoot')is True and a.get('scope')==scope and a.get('sourceManifestSha256')==manifest_sha and a.get('actualPreviousScopesCollectedAndEmpty')is True and a.get('noConcurrentRootWorker')is True and a.get('rootFullWorkerReadPassed')is True,'Fresh Root serial/full-read authority')
 require(isinstance(NATIVE_SOURCE_SHA,str)and re.fullmatch('[0-9a-f]{64}',NATIVE_SOURCE_SHA)and isinstance(API_SOURCE_SHA,str)and re.fullmatch('[0-9a-f]{64}',API_SOURCE_SHA),'Future Native/API source pins remain unbound')
 require(a['genuineSourceManifestSha256']==SOURCE_SHA and a['actualNativeSourceManifestSha256']==NATIVE_SOURCE_SHA and a['actualApiSourceManifestSha256']==API_SOURCE_SHA,'Exact fresh26 Source and reviewed separate Native/API source')
 for key in ['actualCoreCollection','actualCoreRaw','actualCoreControls','actualNativeCollection','actualNativeReport','actualApiCollection','actualOriginalApiReport','actualFresh49Model','actualFresh49ProjectionProof']:load(a[key])
 STATE=a;RAW=Path(a['actualCoreRaw']['path']);RAW_SHA=a['actualCoreRaw']['sha256'];CONTROLS=Path(a['actualCoreControls']['path']);CONTROLS_SHA=a['actualCoreControls']['sha256'];ACTUAL_NATIVE_COLLECTION=a['actualNativeCollection'];ACTUAL_NATIVE_REPORT=a['actualNativeReport'];ACTUAL_API_COLLECTION=a['actualApiCollection'];ACTUAL_API=a['actualOriginalApiReport'];return a
def core_batch48():
 # Actual48 is a collected batch with three per-phase POSTs; never invent execution.
 c=load(STATE['actualCoreCollection'])
 require({k:STATE['actualCoreCollection'][k]for k in ('path','sha256')}=={k:ACTUAL_CORE_BATCH_COLLECTION[k]for k in ('path','sha256')},'Exact genuine actual48 collected batch')
 require(c['authorizedByRoot']is c['toolSessionCollected']is c['passed']is True and c['toolSessionId']==60108 and c['toolExitCode']==c['toolWrapperExitCode']==0,'Actual48 Root collection natural0')
 post=load({'path':c['postauditPath'],'sha256':c['postauditSha256']})
 require(c['sourceManifestSha256']==post['sourceManifestSha256']==SOURCE_SHA and c['phase']==post['phase']=='capture-types-core-batch'and c['scope']==post['scope']=='ROOT_SOURCE26_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH47_AUTHENTIC_PRIOR_CLOSURES','Actual48 Source26 batch scope')
 require(c['phases']==post['phases']and c['orderedPhaseNames']==post['orderedPhaseNames']==['capture','types','core']and c['expectedPhaseNames']==post['expectedPhaseNames']==['capture','types','core']and c['notAttemptedPhaseNames']==post['notAttemptedPhaseNames']==[],'All three attempted in exact order')
 for obj in (c,post):
  require(all(obj[k]is True for k in ['historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','allThreeChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passedMeansCaptureStrictTypesAndRawCore29Only','batchScopeContainsThreeSerialOwnedChildren']),'Actual48 complete held serial batch')
  require(obj['batchFailure']is obj['finalVerificationFailure']is None and obj['CoreCalls']==obj['CoreChildInvocations']==obj['captureChildInvocations']==obj['typesChildInvocations']==1,'One real Core invocation and each prerequisite child')
  require(all(obj[k]==0 for k in ['nativeCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'])and all(obj[k]is False for k in ['Source26Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady']),'Batch only, all broader qualification withheld')
  for prefix,digest in [('dependencies','ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'),('solverDependencies','47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6')]:require(obj[prefix+'Before']==obj[prefix+'After']and obj[prefix+'After']['treeSha256']==digest,'Actual48 full SDK holdings')
 require(c['independentlyObservedAllOwnedGroupsEmpty']is c['independentlyObservedGuardAbsent']is True and c['independentProcReadErrors']==[]and c['independentlyObservedOwnedGroupMembers']=={'492843':[],'492917':[],'493197':[]},'Root actual48 independent closure observations')
 phases=post['phases'];require(len(phases)==3 and len({r['execution']['pgid']for r in phases})==3,'Three distinct owned children')
 prior_end=None
 for number,phase in enumerate(phases):
  require(phase['phase']==['capture','types','core'][number]and all(phase[k]is True for k in ['passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0']),'Actual48 per-phase success and owned closure')
  require(all(phase[k]is None for k in ['runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure']),'No phase failure')
  actual_post=load({'path':phase['postauditPath'],'sha256':phase['postauditSha256']});require(actual_post=={k:v for k,v in phase.items()if k not in ('postauditPath','postauditSha256')},'Every actual separate phase POST matches its final batch row')
  e=phase['execution'];require(e['exitCode']==0 and e['diagnosticStopped']is False and e['stopReasons']==[]and e['cleanupOwnedGroupEmpty']is True and not any(e['oomDelta'].values())and e['signalErrors']==[],'Every child natural0/no resource stop/OOM0/groupempty')
  require(e['command']==phase['command']and e['pgid']==e['pid']==[492843,492917,493197][number]and (prior_end is None or prior_end<=e['startedAt']),'Genuine exact commands and serial lifetimes');prior_end=e['endedAt']
  require(phase['guardIdentityBefore']==phase['guardIdentityAfter']==post['sameGuardIdentity']and e['currentGuardPid']==post['sameGuardIdentity']['pid'],'Same authenticated guard across all three children')
  require(phase['CoreCalls']==phase['CoreChildInvocations']==(1 if number==2 else 0)and all(phase[k]==0 for k in ['nativeCalls','originalApiCalls','cliCalls','cadCalls']),'Uppercase per-phase CoreCalls accounting')
  before=phase['phaseSnapshotsBefore'];after=phase['phaseSnapshotsAfter'];require(before==after and after['board']['treeSha256']=='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'and after['solver']['treeSha256']=='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6','Each phase SDK holdings exact')
 capture,types,core=phases
 require(capture['result']['fullSourceInversePassed']is True and capture['result']['CoreExecuted']is False and types['result']['strictNoEmitTypecheckNatural0']is True and types['result']['actualPriorCapturePin']==capture['result']['sourceCapturePin'],'Genuine capture inverse and strict types precede Core')
 for key in ['sourceCapturePin','sourceDiagnosticPin']:produced(capture,capture['result'][key])
 require(core['CoreCalls']==1 and core['result']['all29CorePredicatesPassed']is True and core['result']['actualCandidateCarrierCount']==26 and core['result']['nativeQualificationPerformed']is False,'Actual48 Core29/26 only')
 require(core['result']['rawCorePin']==STATE['actualCoreRaw']and core['result']['coreControlsPin']==STATE['actualCoreControls'],'Exact actual48 produced Core/control bindings')
 return c,post,core

def actual_core():
 require(STATE is not None,'Actual Root bindings required first');c,post,core=core_batch48();require(c['CoreCalls']==core['CoreCalls']==1,'Actual uppercase CoreCalls==1 for genuine48 Core child')
 raw=produced(core,STATE['actualCoreRaw']);controls=produced(core,STATE['actualCoreControls']);require(controls['rawCorePath']==str(RAW)and controls['rawCoreSha256']==RAW_SHA and controls['freshCoreControlPassed']is True and len(controls['checks'])==29 and all(c['passed']is True for c in controls['checks']),'Actual all29 fresh Core controls')
 require(controls['sourceNumericAndPhysicalIdsDerivedWithoutAssignment']is True and controls['circuitJsonGeometryEdited']is False and controls['automaticCoreSrjForThisForkMustNotBeUsed']is True and controls['expectedOriginalCarrierCount']==26 and controls['expectedMissingOriginalSignalCount']==23,'Genuine26/manual fork/23 missing')
 return raw,controls
def native_outputs():
 # Native18 and API119 are separate actual Root scopes; never force them to share a packetsha.
 nc,np=collected(ACTUAL_NATIVE_COLLECTION);report=produced(np,ACTUAL_NATIVE_REPORT)
 ac,ap=collected(ACTUAL_API_COLLECTION);api=produced(ap,ACTUAL_API)
 require(nc['sourceManifestSha256']==np['sourceManifestSha256']==report['sourceManifestSha256']==NATIVE_SOURCE_SHA,'Actual reviewed Native24 source')
 require(ac['sourceManifestSha256']==ap['sourceManifestSha256']==API_SOURCE_SHA,'Actual reviewed API24 source')
 require(nc['packetSha256']==np['packetSha256']==report['packetSha256'] and ac['packetSha256']==ap['packetSha256']==api['packetSha256'],'Each report belongs to its own authentic collected packet')
 require(report['actualCoreSha256']==api['actualCoreSha256']==RAW_SHA and report['actualCoreControlsSha256']==CONTROLS_SHA,'Same actual fresh26 raw/control hashes')
 require(api['actualNativeReportPath']==ACTUAL_NATIVE_REPORT['path'] and api['actualNativeReportSha256']==ACTUAL_NATIVE_REPORT['sha256'],'API binds actual prior Native report')
 require(api['original49Input']=={k:STATE['actualFresh49Model'][k]for k in ('path','sha256')} and api['fresh49ProjectionProof']['path']==STATE['actualFresh49ProjectionProof']['path'] and api['fresh49ProjectionProof']['sha256']==STATE['actualFresh49ProjectionProof']['sha256'],'Fresh49 model/projection bindings')
 projection=load(STATE['actualFresh49ProjectionProof']);require(projection['actualCoreSha256']==RAW_SHA and projection['actualNativeReportSha256']==ACTUAL_NATIVE_REPORT['sha256'] and projection['constructorInputSha256']==STATE['actualFresh49Model']['sha256'],'Fresh49 derived from this actual24 Core and Native')
 require(projection['sourceManifestSha256']==SOURCE_SHA and projection['originalSource26ProposalSha256']==SIGNAL_SHA and projection['exactFullInverseToFresh24Parent']is True,'Exact same Source26 fresh49 inverse provenance')
 require(report['checkCount']==len(report['counts'])==18 and not any(report['counts'].values())and report['physicalErrors']==0 and report['actualNativePairFindings']==[]and report['physicalCpuRamConnectedCarrierCount']==26,'Native18/all3pair findings0/26 graphs')
 require(api['allOriginalApiLoaded26ChecksPassed']is True and api['exactMaterialHeld']is True and api['actualCompleteOriginalSignalCount']==26 and api['expectedMissingOriginalSignalCount']==23,'All actual original API predicates passed on26')
 require(api['fullOriginalBusRostersAndConstraintsHeld']is True and api['originalFullDifferentialPairArrayUnchanged']is True and api['originalPrivateContinuousApiImplementationsUnchanged']is True,'All original49 rules held')
 for key in ['shared','exterior','coupling','pairLengths']:require(len(api[key])==3 and all(r['matched']is True for r in api[key]),'All3 original '+key+' predicates')
 require(len(api['continuity'])==26 and all(r['pathVisible']and r['selfClear']and r['conventionalAngles']and r['segmentsVisible']and all(r['segmentsVisible'])for r in api['continuity']),'All26 continuous/self/angle predicates')
 second=api['secondaryDqs1View'];require(second['name']=='early_reflected_meander'and second['geometryAndEndpointsUnchanged']is True and second['passed']is True,'Both real DQS1 shared meanders checked')
 for key in ['shared','exterior','coupling']:require(len(second[key])==1 and all(r['matched']is True for r in second[key]),'Second actual DQS1 '+key)
 require(api['checkInventory']['primaryBooleanPredicates']==116 and api['checkInventory']['secondaryDqs1BooleanPredicates']==3 and api['checkInventory']['primaryPlusSecondaryBooleanPredicates']==119,'All primary116 plus secondary3 preserved')
 require(len(api['loadedCohortBusReports'])==3 and all(r['aboveMinimumLength']and r['withinLengthLimit']and r['matched']for r in api['loadedCohortBusReports']),'All original loaded-cohort bounds')
 for obj in [report,api]:require(obj['accepted49']is False and obj['fabricationReady']is False and obj['referenceQualified']is False,'No broader qualification')
 return report,np
def derive_owned(raw,controls,proposal):
 report,_=native_outputs();proof=report['actualOwnershipProof'];kinds=['pcb_via','pcb_trace','pcb_port','source_port','pcb_component','source_component','source_trace','source_manually_placed_via'];ix={k:index(raw,k)for k in kinds}
 require([len(ix[k])for k in ['pcb_via','pcb_trace','pcb_component','source_component','pcb_port']]==[227,289,507,280,1655],'Exact fresh227/289/507/280/1655')
 signals=proof['signalMappings'];carriers=proof['carriers'];require(len(signals)==98 and len(carriers)==26 and len(proof['referenceMappings'])==165,'Native authentic98/26/165 proofs')
 require(len({s['actualViaId']for s in signals})==98 and len({s['actualPcbTraceId']for s in signals})==98,'Unique actual signal barrels/stubs')
 for s in signals:
  owner=one([o for o in proposal['all98NumericOwnedSignalBranches']if o['viaName']==s['sourceViaName']],'Actual Source named via branch')
  numeric=ix['pcb_port'][s['actualNumericPcbPortId']];sp=ix['source_port'][numeric['source_port_id']];part=ix['source_component'][sp['source_component_id']]
  require(part['name']+'.pin'+str(sp['pin_number'])==owner['numericSelector']and near(numeric,owner['padXY']),'Real numeric package/pad')
  via=ix['pcb_via'][s['actualViaId']];top=ix['pcb_port'][s['actualTopPcbPortId']];trace=ix['pcb_trace'][s['actualPcbTraceId']]
  require(near(via,owner['viaXY'])and via['layers']==['top','inner1','inner2','bottom']and via['outer_diameter']==.4572 and via['hole_diameter']==.254 and via['from_layer']=='top'and via['to_layer']=='bottom','Real fullspan barrel')
  require(top['pcb_port_id']in via['pcb_port_ids']and top['layers']==['top']and near(top,via)and ix['source_port'][top['source_port_id']]['source_component_id']==s['sourceViaOwnerId'],'Actual same-owner alias')
  expected=owner['topStub'];wire=trace['route'];long=s['originalSourceTraceId']=='source_trace_14'and s['side']==1;moved_cpu3=s['originalSourceTraceId']=='source_trace_3'and s['side']==0
  require(len(expected)==(11 if long else 4 if moved_cpu3 else 2)and len(wire)==len(expected),'Only actual moved14 RAM has11 and moved3 CPU has4 wirepoints; other96 have2')
  same=lambda points:all(near(p,q)for p,q in zip(points,expected))
  require(trace['source_trace_id']==s['actualPhysicalSourceTraceId']and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in wire)and(same(wire)or same(wire[::-1]))and {wire[0].get('start_pcb_port_id'),wire[-1].get('end_pcb_port_id')}=={numeric['pcb_port_id'],top['pcb_port_id']},'Actual full Topstub polyline/numeric ownership/geometry')
 for c in carriers:
  paths=[t for t in ix['pcb_trace'].values()if t['source_trace_id']==c['originalSourceTraceId']];require(len(paths)==3 and set(c['actualDirectPcbTraceIds'])=={t['pcb_trace_id']for t in paths},'Exactly3 actual Source-owned paths')
  d=one([d for d in proposal['selected26OriginalCarriers']if d['originalSourceTraceId']==c['originalSourceTraceId']],'Original selected Source carrier')
  body=ix['pcb_trace'][c['actualCarrierPcbTraceId']];require(c['carrierLayer']==d['carrierLayer']and len(body['route'])==len(d['expectedCarrierPath'])and all(p['route_type']=='wire'and p['layer']==c['carrierLayer']and p['width']==.1016 and near(p,q)for p,q in zip(body['route'],d['expectedCarrierPath'])),'Authentic complete carrier')
  require(body['route'][0].get('start_pcb_port_id')==c['actualCpuCarrierLayerPcbPortId']and body['route'][-1].get('end_pcb_port_id')==c['actualRamCarrierLayerPcbPortId'],'Genuine actual carrier endpoints')
  require(c['actualSourceOwnedPhysicalGraph']['physicallyConnected']is True and c['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is True,'Native proved real numeric physical graph')
  whole=sum(math.hypot(b['x']-a['x'],b['y']-a['y'])for t in paths for a,b in zip(t['route'],t['route'][1:]));require(abs(whole-c['wholePlanarLengthMm'])<1e-8 and abs(whole-d['expectedWholePlanarMm'])<1e-8,'Actual all3-path planar length')
 require(len({c['originalSourceTraceId']for c in carriers})==26,'26 distinct original signals')
 segments=sum(a['x']!=b['x']or a['y']!=b['y']for t in ix['pcb_trace'].values()for a,b in zip(t['route'],t['route'][1:]));require(segments==1001,'Exact Source26 current1001 nonzero segments');return ix,signals,carriers,segments
def native_prerequisite(authority,carriers):
 require(authority['actualNativeCollection']==ACTUAL_NATIVE_COLLECTION and authority['actualNativeReport']==ACTUAL_NATIVE_REPORT,'Same Root-bound Native prerequisite')
 report,post=native_outputs();require({c['originalSourceTraceId']for c in carriers}=={c['originalSourceTraceId']for c in report['actualOwnershipProof']['carriers']},'Same authentic26 proof');return report,post
