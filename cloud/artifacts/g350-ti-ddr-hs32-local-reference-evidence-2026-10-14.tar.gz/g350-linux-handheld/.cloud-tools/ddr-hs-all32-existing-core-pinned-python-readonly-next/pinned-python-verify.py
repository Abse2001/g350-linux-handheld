"""Root-only existing CPython3.12 target-path repair; strict verifier unchanged."""
from pathlib import Path
import json,os,runpy,sys

ROOT=Path(__file__).resolve().parent

def require(value,message):
    if not value:raise ValueError(message)

def main():
    require(len(sys.argv)==5,'Actual Core/hash/fresh forward/fresh gate required')
    require(os.environ.get('G350_HS_READONLY_STAGE')=='readonly','Exact Root readonly stage required')
    actual,expected,forward,gate=sys.argv[1:]
    m=json.loads((ROOT/'PREPARED-manifest.json').read_bytes())
    require(Path(sys.executable).resolve()==Path(m['pythonExecutable']),'Pinned compatible Python executable required')
    require(sys.version_info[:3]==(3,12,14),'Pinned CPython3.12.14 ABI required')
    target=Path(m['pythonTarget'])
    require(not any(name in sys.modules for name in ('numpy','shapely')),'No preloaded numerical/geometry package allowed')
    sys.dont_write_bytecode=True
    sys.path.insert(0,str(target))
    import numpy
    import shapely
    from shapely.geometry import Point
    require(numpy.__version__=='2.3.5' and shapely.__version__=='2.1.2' and shapely.geos_version_string=='3.13.1','Existing exact numerical/geometry pins required')
    require(Path(numpy.__file__).resolve()==target/'numpy/__init__.py' and Path(shapely.__file__).resolve()==target/'shapely/__init__.py','Exact installed target modules required')
    import numpy._core._multiarray_umath as numpy_extension
    import shapely.lib as shapely_extension
    require((target/'numpy') in Path(numpy_extension.__file__).resolve().parents and (target/'shapely') in Path(shapely_extension.__file__).resolve().parents,'Extensions must load from exact pinned CPython3.12 trees')
    require(Point(0,0).distance(Point(3,4))==5.0,'Tiny pinned GEOS gate failed')
    report={'pythonExecutable':str(Path(sys.executable).resolve()),'pythonVersion':'3.12.14','pythonTarget':str(target),'numpyVersion':numpy.__version__,'shapelyVersion':shapely.__version__,'geosVersion':shapely.geos_version_string,'numpyModule':str(Path(numpy.__file__).resolve()),'shapelyModule':str(Path(shapely.__file__).resolve()),'numpyExtension':str(Path(numpy_extension.__file__).resolve()),'shapelyExtension':str(Path(shapely_extension.__file__).resolve()),'tinyGeometryPassed':True,'installedPackagesModified':False,'strictForwardVerifierUnchanged':True}
    with Path(gate).open('x') as f:json.dump(report,f,indent=2);f.write('\n')
    # The old verifier and every ownership/cut/geometry assertion are byte exact.
    sys.argv=[str(ROOT/'verify-original-core-and-additions.py'),actual,expected,forward]
    runpy.run_path(sys.argv[0],run_name='__main__')

if __name__=='__main__':main()
