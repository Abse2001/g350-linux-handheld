#!/usr/bin/env python3
"""Render the exact223 partial geometry with closed Source228/230/231 evidence.

No SDK, native, Core or CAD execution. Frozen predecessor outputs stay intact.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', '/tmp/g350-plot228-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Circle, Rectangle
from matplotlib.transforms import Affine2D

CANDIDATE = Path('/tmp/g350-deterministic-manual47-root-20261016-run223/byte0-result.candidate.json')
CANDIDATE_SHA = 'ddaa4efd8d20f16cefca89b9166e834a956113194beed6f0f13903e346e36ea0'
CRITICAL_REPORT = Path('/tmp/g350-manual47-critical-root-20261016-run225/byte0-result.json')
CRITICAL_SHA = '0b4027452b0acdfca4f2009a57fbff7d47700c233fa7476b840f6a1946106a60'
RAW_CORE = Path('/tmp/g350-manual47-core228-raw.json')
RAW_CORE_SHA = 'c284bb3819f70292a311fdbe2bfd7013ef38545c02891cde90a3391a2a47b78b'
CONTROLS = Path('/tmp/g350-manual47-core-root-20261016-run228/byte0-result.json')
CONTROLS_SHA = 'ac3850112e1b2ac8e4ce478825f62cab658416a01c8a3e9f0cf228749352f59c'
NATIVE = Path('/tmp/g350-manual47-native-root-20261016-run230/byte0-result.json')
NATIVE_SHA = '1f7e3d6207d9e07a49aa865432e95db86cc2a80b89d2e475d6ed6588544c5252'
AUTH = Path('/tmp/g350-manual47-via-track-root-20261016-run231/byte0-result.json')
AUTH_SHA = '39c9b828b22ba47ca4b372fee6e54b985292428b612b31b83aa5502fe5210d7d'
POURS = Path('/tmp/g350-source228-all14-literal-pour-margin-root-20261016.json')
POURS_SHA = 'fba9a7f96af8acb94b2fc023e0401e452c56412318ec584a54eacbd616c4483f'
OUTPUT_DIR = Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-four-layer-post209-2026-10-16')
LAYERS = ['top', 'inner1', 'inner2', 'bottom']
COLORS = {'ordinary': '#16856d', 'source_trace_15': '#1170aa', 'source_trace_16': '#1170aa',
          'source_trace_27': '#dd761c', 'source_trace_28': '#dd761c',
          'source_trace_33': '#8b43b3', 'source_trace_34': '#8b43b3'}


def owner(trace):
    return trace.get('connection_name', trace.get('source_trace_id'))


def wire_segments(trace, layer):
    return [[(a['x'], a['y']), (b['x'], b['y'])] for a, b in zip(trace['route'], trace['route'][1:])
            if a['route_type'] == b['route_type'] == 'wire' and a['layer'] == b['layer'] == layer]


def pinned_json(location, expected_sha):
    data = location.read_bytes()
    if hashlib.sha256(data).hexdigest() != expected_sha:
        raise ValueError('Closed evidence hash mismatch: ' + str(location))
    return json.loads(data)


def verify_closed_evidence():
    controls = pinned_json(CONTROLS, CONTROLS_SHA)
    if hashlib.sha256(RAW_CORE.read_bytes()).hexdigest() != RAW_CORE_SHA:
        raise ValueError('Expected exact Source228 raw geometry')
    if controls['rawCoreSha256'] != RAW_CORE_SHA or controls['freshCoreDerived'] is not True or controls['partialDiagnosticReplayControlsPassed'] is not True:
        raise ValueError('Source228 partial replay controls must bind exact raw')
    if len(controls['checks']) != 35 or not all(c['passed'] for c in controls['checks']):
        raise ValueError('Expected actual Source228 35/35 controls passed')
    if controls['sourceRuleBridge']['candidatePin']['sha256'] != CANDIDATE_SHA or controls['referenceQualified'] is not False:
        raise ValueError('Expected exact candidate223 binding and reference qualification pending')
    if set(controls['pendingOwnerIds']) != {'source_trace_26', 'source_trace_30'} or len(controls['routedOwnerIds']) != 47:
        raise ValueError('Source228 must preserve exact47 routed/two pending roster')
    native = pinned_json(NATIVE, NATIVE_SHA)
    if native['completed'] is not True or native['finished'] is not True or native['completedCheckCount'] != 16 or native['exceptionCount'] != 0:
        raise ValueError('Expected closed focused16 native230 diagnostic')
    if native['inputBindings']['raw']['sha256'] != RAW_CORE_SHA or native['inputBindings']['controls']['sha256'] != CONTROLS_SHA:
        raise ValueError('Native230 evidence must bind exact Source228 geometry and controls')
    results = {r['name']: r for r in native['results']}
    if len(native['physical10']) != 10 or not all(results[n]['findingCount'] == 0 for n in native['physical10']):
        raise ValueError('Expected zero findings in all10 focused physical native checks')
    if results['checkPcbBusLengthSkew']['findingCount'] != 3 or native['all32FreshNativeChecksExecuted'] is not False:
        raise ValueError('Expected three bus-skew failures and focused scope retained')
    auth = pinned_json(AUTH, AUTH_SHA)
    if auth['complete'] is not True or auth['executed'] is not True or auth['actualViaCount'] != 227 or auth['completedViaCount'] != 227 or auth['foreignViaTrackCopperClearancePassed'] is not True:
        raise ValueError('Expected actual231 complete227-via foreign clearance diagnostic')
    if any(auth[k] for k in ['identityFailures', 'ambiguousVias', 'violations', 'invalidSegments', 'unresolvedSegmentOwners']):
        raise ValueError('Auth231 identity/foreign clearance findings must remain zero')
    if auth['inputBindings']['raw']['sha256'] != RAW_CORE_SHA or auth['inputBindings']['controls']['sha256'] != CONTROLS_SHA:
        raise ValueError('Auth231 must bind Source228 geometry and controls')
    pours = pinned_json(POURS, POURS_SHA)
    if pours['completed'] is not True or pours['allActualPoursCompleted'] is not True or len(pours['actualRawPourIds']) != 14 or pours['wireSegmentCount'] != 937 or pours['actualViaCount'] != 227 or pours['literalForeignPourMarginClear'] is not True:
        raise ValueError('Expected all14 literal pours and937 actual wire segments completed')
    if any(pours[k] for k in ['violations', 'globalIdentityFailures', 'viaIdentityFailures', 'unsupportedGeometry']):
        raise ValueError('Literal pour identity/geometry/foreign margin findings must remain zero')
    if pours['inputBindings']['raw']['sha256'] != RAW_CORE_SHA or pours['inputBindings']['controls']['sha256'] != CONTROLS_SHA or pours['inputBindings']['current227Ownership']['sha256'] != AUTH_SHA:
        raise ValueError('Literal pour evidence must bind exact raw/controls/ownership')
    for report in [controls, native, auth, pours]:
        if report['fullBoardPassed'] is not False or report['all49Accepted'] is not False or report['fabricationReady'] is not False:
            raise ValueError('All whole-board and fabrication acceptance flags must remain false')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path, default=CANDIDATE)
    parser.add_argument('--output-dir', type=Path, default=OUTPUT_DIR)
    args = parser.parse_args()
    data = args.candidate.read_bytes()
    if hashlib.sha256(data).hexdigest() != CANDIDATE_SHA:
        raise ValueError('Expected exact frozen run223 candidate')
    candidate = json.loads(data)
    scene, bodies = candidate['full49FanoutInput'], candidate['carrierTraces']
    routed = {owner(t) for t in bodies}
    pending = [c for c in scene['connections'] if c['name'] not in routed]
    if len(bodies) != 47 or len(routed) != 47 or {c['name'] for c in pending} != {'source_trace_26', 'source_trace_30'}:
        raise ValueError('Expected 47 routed owners and only D12/DQM0 pending')
    if scene['allowedLayers'] != LAYERS or scene['layerCount'] != 4 or candidate['all49Accepted'] is not False or candidate['fabricationReady'] is not False:
        raise ValueError('Expected partial four-layer candidate with fabricationReady=false')
    verify_closed_evidence()
    physical = candidate['finalScenePhysicalReports']
    if candidate['allSavedCarriersCurrentSceneQualified'] is not True or len(physical) != 47 or not all(r['passed'] for r in physical):
        raise ValueError('Expected actual223 all47 physical checks passed')
    critical_data = CRITICAL_REPORT.read_bytes()
    if hashlib.sha256(critical_data).hexdigest() != CRITICAL_SHA:
        raise ValueError('Expected exact actual225 critical report')
    critical = json.loads(critical_data)
    views = critical['criticalValidationViews']
    if critical['inputSha256'] != CANDIDATE_SHA or critical['currentSceneCriticalAssertionsFreshlyQualified'] is not True or critical['criticalProfileQualified'] is not True:
        raise ValueError('Critical evidence must bind this exact223 model')
    if len(critical['criticalPhysicalReports']) != 6 or not all(r['passed'] for r in critical['criticalPhysicalReports']):
        raise ValueError('Expected six actual225 physical reports passed')
    if len(views) != 2 or {v['scope'] for v in views} != {'DQS1_LOWER_U_SHARED_VIEW', 'DQS1_EARLY_MEANDER_SHARED_VIEW'}:
        raise ValueError('Both actual DQS1 shared-section views required')
    for view in views:
        if view['passed'] is not True or view['c31']['solved'] is not True or set(view['reports']) != {'bus', 'pair', 'shared', 'coupling', 'exterior'}:
            raise ValueError('Actual225 five APIs and planar validation must pass')
        if not all(len(rows) == 3 and all(r['matched'] for r in rows) for rows in view['reports'].values()):
            raise ValueError('Expected three original pairs in every API report')
    if args.output_dir.resolve() != OUTPUT_DIR.resolve():
        raise ValueError('Only the new post209 visualization directory is authorized')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    outputs = [args.output_dir / ('SOURCE228_PARTIAL47_FOUR_LAYER_MILESTONE.' + extension) for extension in ('png', 'svg')]
    if any(p.exists() for p in outputs):
        raise FileExistsError('Fresh Source228 milestone outputs required')
    fig, axes = plt.subplots(1, 4, figsize=(18, 9.5), sharex=True, sharey=True)
    for ax, layer in zip(axes, LAYERS):
        for obstacle in scene['obstacles']:
            if layer not in obstacle['layers']:
                continue
            x, y = obstacle['center']['x'], obstacle['center']['y']
            if x < -11 or x > 10 or y < 2 or y > 29:
                continue
            if obstacle.get('shape', obstacle.get('type')) == 'circle':
                patch = Circle((x, y), obstacle['width'] / 2)
            else:
                patch = Rectangle((x - obstacle['width'] / 2, y - obstacle['height'] / 2), obstacle['width'], obstacle['height'])
                patch.set_transform(Affine2D().rotate_deg_around(x, y, obstacle.get('ccwRotationDegrees', 0)) + ax.transData)
            patch.set(facecolor='#d5d9de', edgecolor='none', alpha=.55, zorder=1)
            ax.add_patch(patch)
        fixed = [segment for t in scene['traces'] for segment in wire_segments(t, layer)]
        ax.add_collection(LineCollection(fixed, colors='#aab2bb', linewidths=.5, zorder=2))
        for trace in scene['traces']:
            for p in trace['route']:
                if p['route_type'] == 'via' and layer in p.get('layers', []):
                    ax.add_patch(Circle((p['x'], p['y']), p.get('via_diameter', .4572) / 2, fill=False, edgecolor='#a5adb6', linewidth=.45, zorder=2))
        for trace in bodies:
            color = COLORS.get(owner(trace), COLORS['ordinary'])
            ax.add_collection(LineCollection(wire_segments(trace, layer), colors=color, linewidths=1.15, zorder=4))
            for p in trace['route']:
                if p['route_type'] == 'via' and layer in p.get('layers', []):
                    ax.add_patch(Circle((p['x'], p['y']), p['via_diameter'] / 2, fill=False, edgecolor=color, linewidth=.9, zorder=5))
        for connection in pending:
            a, b = connection['pointsToConnect']
            ax.plot([a['x'], b['x']], [a['y'], b['y']], color='#d9a21b', linewidth=.85, alpha=.9, linestyle=(0, (4, 3)), zorder=3)
            label = {'source_trace_26': 'D12 pending', 'source_trace_30': 'DQM0 pending'}[connection['name']]
            ax.text((a['x'] + b['x']) / 2 + .12, (a['y'] + b['y']) / 2, label,
                    color='#9b6d03', fontsize=6, rotation=75, zorder=6,
                    bbox={'facecolor': 'white', 'edgecolor': 'none', 'alpha': .72, 'pad': .6})
        ax.add_patch(Rectangle((-7, 13), 14, 14, fill=False, edgecolor='#697386', linestyle='--', linewidth=.7))
        ax.add_patch(Rectangle((-5.01, 3.99), 12.42, 6.82, fill=False, edgecolor='#697386', linestyle='--', linewidth=.7))
        ax.text(-6.9, 26.35, 'AM3352', fontsize=8, color='#475467')
        ax.text(-4.9, 4.25, 'DDR3L', fontsize=8, color='#475467')
        ax.set(title={'top': 'Top', 'inner1': 'Inner1', 'inner2': 'Inner2', 'bottom': 'Bottom'}[layer],
               xlim=(-10.2, 9), ylim=(2.8, 28), aspect='equal', xlabel='X (mm)')
        ax.grid(alpha=.12)
    axes[0].set_ylabel('Y (mm)')
    fig.suptitle('G350 · Source228 partial milestone · 47 of 49 DDR paths', fontsize=15, weight='bold', y=.965)
    fig.text(.5, .099, 'Green: ordinary routes   |   Blue: DQS0   |   Orange: DQS1   |   Purple: CK   |   Yellow dashed: D12 / DQM0 pending',
             ha='center', fontsize=10)
    fig.text(.5, .042, 'Fresh editable Source228: 35/35 replay controls PASS. Native230: 10 physical checks zero; 3 bus-skew failures.\nAuth231: 227 vias, zero foreign via-track violations. Literal 14 pours / 937 segments: zero foreign-margin violations.\nPartial47/49; timing / TI / reference / independent CAD / fabrication qualification open; default unchanged; fabricationReady=false.',
             ha='center', fontsize=9, color='#475467')
    fig.subplots_adjust(top=.92, bottom=.15, wspace=.13)
    description = ('Exact223 geometry ' + CANDIDATE_SHA + '; partial47; Source228 raw ' + RAW_CORE_SHA + '; controls ' + CONTROLS_SHA + '; native230 ' + NATIVE_SHA + '; auth231 ' + AUTH_SHA + '; literal14pours ' + POURS_SHA + '; 35/35 Source replay controls; focused10 physical checks zero; three bus-skew failures; all49Accepted=false; fabricationReady=false; default unchanged.')
    fig.savefig(outputs[0], dpi=180, metadata={'Description': description})
    fig.savefig(outputs[1], metadata={'Date': None, 'Description': description})
    plt.close(fig)
    for output in outputs:
        print(str(output) + ' ' + hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
