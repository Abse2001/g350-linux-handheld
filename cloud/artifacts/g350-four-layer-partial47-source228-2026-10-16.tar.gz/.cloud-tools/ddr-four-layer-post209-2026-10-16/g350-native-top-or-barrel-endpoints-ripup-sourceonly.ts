/** SOURCE ONLY. Import-free endpoint choices; no routing, native, or timing
 * qualification. Top selects the genuine numeric pad and explicitly replaces
 * only its owned fanout by one Top wire vertex. A previously selected authentic
 * Top-only branch has NO non-Top terminal support. The Top choice
 * explicitly removes that owner's old working stub with an inverse ledger. Other layers retain the actual
 * manufactured fullspan barrel. Callers retain/inspect the returned inverse.
 */
type Row = Record<string, any>
export interface NativeTopEndpointHelpers {
  retargetGeneratedEscape: (branch: Row, layer: string) => Row
  fixedRouteLength?: (input: Row, name: string) => number
}
export interface NativeTopEndpointMenus {
  byLayer: Record<string, { pointsToConnect: Row[]; fanoutMm: number[]; supportedEndpoints: boolean[] }>
  branches: Row[]
  branchIndices: number[]
  connectionName: string
  sourceTraceId: string
  originalConnection: Row
  provenance: Row[]
}
const LAYERS = ['top', 'inner1', 'inner2', 'bottom']
const EPS = 1e-8
const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v))
const equal = (a: any, b: any) => JSON.stringify(a) === JSON.stringify(b)
const near = (a: Row, b: Row) => !!a && !!b && Number.isFinite(a.x) && Number.isFinite(a.y) && Number.isFinite(b.x) && Number.isFinite(b.y) && Math.hypot(a.x - b.x, a.y - b.y) <= EPS
const fail = (message: string): never => { throw Error('Native Top endpoint: ' + message) }
const owned = (t: Row, c: Row) => t.connection_name === c.name || t.source_trace_id === (c.source_trace_id ?? c.name)
const planarLength = (t: Row) => (t.route ?? []).slice(1).reduce((sum: number, p: Row, i: number) => sum + Math.hypot(p.x - t.route[i].x, p.y - t.route[i].y), 0)
function assertBase(base: Row, c: Row) {
  if (!Array.isArray(base.connections) || base.connections.length !== 49 || !Array.isArray(base.traces) || base.traces.length !== 263 || !Array.isArray(base.obstacles) || base.obstacles.length !== 1298) fail('requires the actual 49-request / 263-trace / 1298-obstacle foundation')
  if (!c?.name || !Array.isArray(c.pointsToConnect) || c.pointsToConnect.length !== 2) fail('requires the original two-ended connection')
  const found = base.connections.filter((p: Row) => p.name === c.name)
  if (found.length !== 1 || !equal(found[0], c)) fail('connection is not the exact foundation request')
  const requestOwners = new Set(base.connections.flatMap((p: Row) => [p.name, p.source_trace_id].filter(Boolean)))
  const refs = base.traces.filter((t: Row) => !requestOwners.has(t.connection_name) && !requestOwners.has(t.source_trace_id))
  if (refs.length !== 165) fail('foundation does not contain exactly 165 untouched reference traces')
  return refs
}
function fullspan(branch: Row) {
  const vias = (branch.route ?? []).filter((p: Row) => p.route_type === 'via')
  if (vias.length !== 1) fail('each non-Top choice needs its original single actual fullspan barrel: ' + branch.pcb_trace_id)
  const v = vias[0]
  if (!Number.isFinite(v.x) || !Number.isFinite(v.y) || v.from_layer !== 'top' || !Array.isArray(v.layers) || v.layers.length !== 4 || new Set(v.layers).size !== 4 || LAYERS.some(l => !v.layers.includes(l)) || !Number.isFinite(v.via_diameter) || Math.abs(v.via_diameter - .4572) > EPS || !Number.isFinite(v.via_hole_diameter) || Math.abs(v.via_hole_diameter - .254) > EPS) fail('missing authentic explicit .4572/.254 all-four-layer barrel: ' + branch.pcb_trace_id)
  const tail = branch.route.at(-1)
  if (tail?.route_type !== 'wire' || !near(tail, v)) fail('branch does not finish at its actual barrel handoff')
  return v
}
function physicalGeometry(branch: Row) {
  const route = branch.route ?? [], segments: Row[] = [], barrels: Row[] = []
  for (let i = 0; i < route.length; i++) {
    const p = route[i], q = route[i + 1]
    if (p.route_type === 'via') barrels.push({ x: p.x, y: p.y, layers: p.layers, via_diameter: p.via_diameter, via_hole_diameter: p.via_hole_diameter })
    if (q && !near(p, q)) {
      if (p.route_type !== 'wire' || q.route_type !== 'wire' || p.layer !== q.layer) fail('noncoincident transition in authentic fanout')
      segments.push({ ax: p.x, ay: p.y, bx: q.x, by: q.y, layer: p.layer, width: p.width })
    }
  }
  return { segments, barrels }
}
export function createEndpointMenus(base: Row, connection: Row, helpers: NativeTopEndpointHelpers): NativeTopEndpointMenus {
  assertBase(base, connection)
  if (typeof helpers?.retargetGeneratedEscape !== 'function') fail('caller must supply the genuine retargetGeneratedEscape helper')
  const candidates = base.traces.map((branch: Row, index: number) => ({ branch, index })).filter((q: Row) => owned(q.branch, connection))
  if (candidates.length !== 2) fail('requires exactly two authentic owner branches')
  for (const { branch } of candidates) {
    if (branch.source_trace_id && branch.source_trace_id !== (connection.source_trace_id ?? connection.name)) fail('branch source owner mismatch')
    if (branch.connection_name && branch.connection_name !== connection.name) fail('branch connection owner mismatch')
    const first = branch.route?.[0]
    if (first?.route_type !== 'wire' || first.layer !== 'top' || !Number.isFinite(first.width) || Math.abs(first.width - .1016) > EPS) fail('authentic approach must start at a numeric Top wire vertex')
  }
  const supports = (q: Row, p: Row) => near(q.branch.route[0], p) || q.branch.route.some((v: Row) => v.route_type === 'via' && near(v, p)) || (q.branch.route.every((v: Row) => v.route_type === 'wire' && v.layer === 'top') && near(q.branch.route.at(-1), p))
  const assignments = [candidates, [...candidates].reverse()].filter((pair: Row[]) => pair.every((q: Row, side: number) => supports(q, connection.pointsToConnect[side])))
  if (assignments.length !== 1) fail('cannot uniquely associate authentic CPU/RAM branches with original terminal order')
  const selected = assignments[0], branches = selected.map((q: Row) => clone(q.branch)), barrel = branches.map((branch: Row) => {
    const vias = branch.route.filter((p: Row) => p.route_type === 'via')
    if (vias.length) return fullspan(branch)
    if (!branch.route.length || branch.route.some((p: Row) => p.route_type !== 'wire' || p.layer !== 'top' || !Number.isFinite(p.x) || !Number.isFinite(p.y) || !Number.isFinite(p.width) || Math.abs(p.width - .1016) > EPS)) fail('barrel-free branch must be an authentic numeric-pad-origin Top-only wire approach')
    return undefined
  })
  const pads = branches.map((branch: Row, side: number) => {
    const first = branch.route[0], firstPortIds = [first.start_pcb_port_id, first.end_pcb_port_id].filter(Boolean)
    const matches = base.obstacles.filter((o: Row) => near(o.center, first) && o.layers?.includes('top') && !!o.circuitJsonMetadata?.pcb_port_id && o.connectedTo?.includes(o.circuitJsonMetadata.pcb_port_id) && (!firstPortIds.length || firstPortIds.includes(o.circuitJsonMetadata.pcb_port_id)))
    if (matches.length !== 1) fail('numeric Top pad is not uniquely backed by its actual obstacle/pcb_port_id, side ' + side)
    const o = matches[0], id = o.circuitJsonMetadata.pcb_port_id
    return { point: { x: first.x, y: first.y, layer: 'top', pointId: id, pcb_port_id: id }, obstacleId: o.obstacleId, pcb_port_id: id }
  })
  const costs = branches.map((branch: Row) => {
    const actual = planarLength(branch)
    if (!Number.isFinite(actual)) fail('nonfinite authentic branch length')
    if (helpers.fixedRouteLength) {
      const supplied = helpers.fixedRouteLength({ ...base, connections: [connection], traces: [clone(branch)] }, connection.name)
      if (!Number.isFinite(supplied) || Math.abs(supplied - actual) > EPS) fail('fixedRouteLength does not match the actual single branch')
      return supplied
    }
    return actual
  })
  const byLayer: NativeTopEndpointMenus['byLayer'] = {}
  // Unsupported coordinates are grid anchors only. supportedEndpoints MUST
  // suppress that side's roots/goals. They never authorize a terminal contact.
  for (const layer of LAYERS) byLayer[layer] = layer === 'top'
    ? { pointsToConnect: pads.map(p => clone(p.point)), fanoutMm: [0, 0], supportedEndpoints: [true, true] }
    : { pointsToConnect: barrel.map((v, side) => v ? ({ x: v.x, y: v.y, layer, ...(v.pcb_via_id ? { pointId: v.pcb_via_id } : {}) }) : ({ x: pads[side].point.x, y: pads[side].point.y, layer })), fanoutMm: barrel.map((v, side) => v ? costs[side] : 0), supportedEndpoints: barrel.map(Boolean) }
  return { byLayer, branches, branchIndices: selected.map((q: Row) => q.index), connectionName: connection.name, sourceTraceId: connection.source_trace_id ?? connection.name, originalConnection: clone(connection), provenance: pads.map((pad, side) => ({ side, branchId: branches[side].pcb_trace_id, ...pad, fullspanBarrel: barrel[side] ? clone(barrel[side]) : null, nonTopFanoutMm: costs[side] })) }
}
export function applyEndpointSelection(base: Row, connection: Row, carrier: Row, menus: NativeTopEndpointMenus, helpers: NativeTopEndpointHelpers): { foundation: Row; inverse: Row } {
  const originalRefs = assertBase(base, connection)
  if (menus.connectionName !== connection.name || menus.sourceTraceId !== (connection.source_trace_id ?? connection.name) || !equal(menus.originalConnection, connection)) fail('menus belong to another foundation connection')
  // Re-derive all authority from this actual base, rather than trusting a stale
  // or caller-edited menu to release copper or manufacture terminal access.
  const actual = createEndpointMenus(base, connection, helpers)
  if (!equal(actual, menus)) fail('menus are stale or altered')
  if (!Array.isArray(carrier?.route) || carrier.route.length < 2 || !owned(carrier, connection)) fail('carrier must contain the original owner and real endpoint wires')
  if ((carrier.source_trace_id && carrier.source_trace_id !== menus.sourceTraceId) || (carrier.connection_name && carrier.connection_name !== connection.name)) fail('carrier owner mismatch')
  const ends = [carrier.route[0], carrier.route.at(-1)], after: Row[] = [], points: Row[] = []
  for (let side = 0; side < 2; side++) {
    const end = ends[side], layer = end?.layer, menu = actual.byLayer[layer], original = actual.branches[side]
    if (end?.route_type !== 'wire' || !menu || !menu.supportedEndpoints[side] || !near(end, menu.pointsToConnect[side])) fail('carrier endpoint does not match its actual selected menu, side ' + side)
    points.push(clone(menu.pointsToConnect[side]))
    if (layer === 'top') {
      const first = clone(original.route[0]), pad = points[side]
      delete first.start_pcb_port_id; delete first.end_pcb_port_id
      first.start_pcb_port_id = pad.pcb_port_id
      after.push({ ...clone(original), route: [{ ...first, x: pad.x, y: pad.y, route_type: 'wire', layer: 'top' }], trace_length: 0 })
    } else {
      const retargeted = helpers.retargetGeneratedEscape(clone(original), layer)
      if (!equal(physicalGeometry(original), physicalGeometry(retargeted))) fail('non-Top retarget changed actual copper or barrel geometry')
      const v = fullspan(retargeted), tail = retargeted.route.at(-1)
      if (v.to_layer !== layer || tail.layer !== layer || !near(tail, end)) fail('retarget helper did not preserve the selected real handoff')
      after.push(clone(retargeted))
    }
  }
  const foundation = clone(base), connectionIndex = base.connections.findIndex((c: Row) => c.name === connection.name)
  for (let side = 0; side < 2; side++) foundation.traces[actual.branchIndices[side]] = after[side]
  foundation.connections[connectionIndex] = { ...clone(connection), pointsToConnect: points }
  const refs = assertBase(foundation, foundation.connections[connectionIndex])
  if (!equal(base.obstacles, foundation.obstacles) || !equal(originalRefs, refs)) fail('obstacles or reference traces changed')
  const changed = new Set(actual.branchIndices)
  if (base.traces.some((t: Row, i: number) => !changed.has(i) && !equal(t, foundation.traces[i])) || base.connections.some((c: Row, i: number) => i !== connectionIndex && !equal(c, foundation.connections[i]))) fail('foreign branch/request material changed')
  return { foundation, inverse: { connectionName: connection.name, sourceTraceId: menus.sourceTraceId, selections: ends.map((p: Row, side: number) => ({ side, layer: p.layer, point: clone(points[side]), fanoutMm: actual.byLayer[p.layer].fanoutMm[side] })), connection: { index: connectionIndex, before: clone(connection), after: clone(foundation.connections[connectionIndex]) }, branches: actual.branchIndices.map((index: number, side: number) => ({ index, before: clone(base.traces[index]), after: clone(foundation.traces[index]) })), invariants: { obstacleCount: 1298, obstacleMaterialUnchanged: true, referenceTraceCount: 165, referenceMaterialUnchanged: true, foreignMaterialUnchanged: true } } }
}
