"""Import-only process ownership helpers; only run_guarded can start a child.
No routing imports. Same-PGID/SID descendants only; current guard never signaled.
Sampled thresholds are not kernel hard caps. Runner must never detach work.
"""
import ctypes, datetime, errno, json, os, signal, subprocess, time
from contextlib import contextmanager
from pathlib import Path

OOM_KEYS = ('oom','oom_kill','oom_group_kill')
_launching = False
_pending = None
SIGNAL_ERRORS = []
SIGNAL_ERROR_COUNT = 0

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def memory():
    return {'current':int(Path('/sys/fs/cgroup/memory.current').read_text()),
            'events':{k:int(v) for k,v in (line.split() for line in Path('/sys/fs/cgroup/memory.events').read_text().splitlines())}}
def process(pid):
    try:
        fields=Path(f'/proc/{pid}/stat').read_text().rsplit(') ',1)[1].split()
        status=dict(line.split(':',1) for line in Path(f'/proc/{pid}/status').read_text().splitlines() if ':' in line)
        return {'pid':pid,'pgid':int(fields[2]),'sid':int(fields[3]),'start':int(fields[19]),'state':fields[0],
                'rss':int(status.get('VmRSS','0 kB').split()[0])*1024,
                'argv':[x.decode() for x in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0') if x]}
    except (OSError,ValueError,IndexError,UnicodeDecodeError): return None
def owned(group):
    if group<=0 or group==os.getpid(): return []
    rows=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdigit() or int(path.name)==os.getpid(): continue
        try:
            fields=(path/'stat').read_text().rsplit(') ',1)[1].split()
            if int(fields[2])!=group or int(fields[3])!=group: continue
        except (OSError,ValueError,IndexError): continue
        row=process(int(path.name))
        if row is not None and row['pgid']==group and row['sid']==group: rows.append(row)
    return sorted(rows,key=lambda row:row['pid'])
def identity(current, expected, group):
    return bool(current is not None and expected['pid']!=os.getpid() and group!=os.getpid()
        and current['pid']==expected['pid'] and current['pgid']==group and current['sid']==group
        and current['start']==expected['start'] and current['argv']==expected['argv'])
def scoped_signal(row, group, number):
    global SIGNAL_ERROR_COUNT
    if not identity(process(row['pid']),row,group): return False
    descriptor=None
    try:
        descriptor=os.pidfd_open(row['pid'],0)
        if not identity(process(row['pid']),row,group): return False
        signal.pidfd_send_signal(descriptor,number); return True
    except OSError as error:
        if error.errno not in (errno.ESRCH,errno.ENOENT):
            SIGNAL_ERROR_COUNT += 1
            if len(SIGNAL_ERRORS) < 16:
                SIGNAL_ERRORS.append({'pid':row['pid'],'errno':error.errno,'signal':number,'utc':utc()})
        return False
    finally:
        if descriptor is not None: os.close(descriptor)
def capability():
    if not all(hasattr(os,k) for k in ['pidfd_open','waitid','WNOWAIT']) or not hasattr(signal,'pidfd_send_signal'): raise RuntimeError('Linux pidfd/WNOWAIT required')
    fd=os.pidfd_open(os.getpid(),0)
    try: signal.pidfd_send_signal(fd,0)
    finally: os.close(fd)
def subreaper():
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(36,1,0,0,0)!=0: raise OSError(ctypes.get_errno(),'Subreaper unavailable')
class Interrupted(BaseException): pass
@contextmanager
def handlers():
    previous={s:signal.getsignal(s) for s in [signal.SIGTERM,signal.SIGHUP,signal.SIGINT]}; seen=False
    def handle(number,_frame):
        nonlocal seen
        global _pending
        if seen: return
        seen=True
        if _launching: _pending=number
        else: raise Interrupted(number)
    try:
        for number in previous: signal.signal(number,handle)
        yield
    finally:
        for number,handler in previous.items(): signal.signal(number,handler)
@contextmanager
def defer_launch():
    global _launching,_pending
    _launching=True
    try: yield
    finally:
        _launching=False; pending,_pending=_pending,None
        if pending is not None: raise Interrupted(pending)
def ignore_cleanup_signals():
    for s in [signal.SIGTERM,signal.SIGHUP,signal.SIGINT]: signal.signal(s,signal.SIG_IGN)
def exit_status(child):
    row=os.waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
    return None if row is None else row.si_status if row.si_code==os.CLD_EXITED else -row.si_status
def reap_zombies(group, leader):
    for row in owned(group):
        if row['pid']==leader or row['state']!='Z' or not identity(process(row['pid']),row,group): continue
        try: os.waitpid(row['pid'],os.WNOHANG)
        except ChildProcessError: pass
def reasons(elapsed, rows, current, baseline, policy):
    return (["OWNED_RSS_STOP"] if sum(row['rss'] for row in rows)>=policy['rssBytes'] else []) + (["SHARED_MEMORY_STOP"] if current['current']>=policy['sharedBytes'] else []) + (["NEW_OOM_STOP"] if any(current['events'][key]>baseline['events'][key] for key in OOM_KEYS) else []) + (["WALL_STOP"] if elapsed>=policy['wallSeconds'] else [])
# BEGIN OPTIONAL_DISK_GUARD_HELPERS

def _disk_guard_policy(policy):
    if 'diskFreeGuard' not in policy: return None
    legacy={'wallSeconds','rssBytes','sharedBytes','sampleSeconds','termGraceSeconds'}
    if set(policy)!=legacy|{'diskFreeGuard'}: raise ValueError('Unknown disk-guard policy options')
    value=policy['diskFreeGuard']
    if not isinstance(value,dict) or set(value)!={'path','minimumFreeBytes'}: raise ValueError('Exact disk guard path/minimumFreeBytes required')
    path=value['path'];floor=value['minimumFreeBytes']
    if not isinstance(path,str) or '\0' in path or not Path(path).is_absolute() or str(Path(path))!=path or '..' in Path(path).parts: raise ValueError('Canonical absolute disk guard path required')
    if type(floor)is not int or floor<=0: raise ValueError('Positive integer disk guard floor required')
    return {'path':path,'minimumFreeBytes':floor}

def _disk_guard_flags(available,spec):
    if type(available)is not int: raise ValueError('Integer available disk bytes required')
    return ['OWNED_DISK_FREE_STOP'] if available<spec['minimumFreeBytes'] else []

def _disk_guard_sample(spec,stats):
    try:
        sample=os.statvfs(spec['path']);blocks=sample.f_bavail;fragment=sample.f_frsize
        if type(blocks)is not int or type(fragment)is not int or fragment<=0: raise ValueError('Valid statvfs available blocks/fragment required')
        available=blocks*fragment
    except (OSError,ValueError) as error:
        stats['readErrorCount']+=1;stats['lastReadErrorType']=type(error).__name__;raise
    stats['sampleCount']+=1;stats['lastAvailableBytes']=available
    if stats['beforeAvailableBytes']is None: stats['beforeAvailableBytes']=available
    if stats['minimumAvailableBytesObserved']is None or available<stats['minimumAvailableBytesObserved']: stats['minimumAvailableBytesObserved']=available
    return available
# END OPTIONAL_DISK_GUARD_HELPERS
def cleanup(child, grace=5):
    if child.returncode is not None: return # Already reaped only after group gone.
    ignore_cleanup_signals(); started=time.monotonic()
    while True:
        reap_zombies(child.pid,child.pid); rows=owned(child.pid); result=exit_status(child)
        descendants=[row for row in rows if row['pid']!=child.pid]
        if result is not None and not descendants: child.wait(); return
        for row in reversed(rows):
            if row['state']!='Z': scoped_signal(row,child.pid,signal.SIGKILL if time.monotonic()-started>=grace else signal.SIGTERM)
        time.sleep(.05)
def run_guarded(command,cwd,record_directory,policy,environment=None,before_spawn=None):
    global SIGNAL_ERROR_COUNT
    if policy['sampleSeconds']<=0 or policy['termGraceSeconds']!=5: raise ValueError('Explicit sampled policy/grace required')
    # BEGIN OPTIONAL_DISK_GUARD_POLICY
    _disk_spec=_disk_guard_policy(policy)
    # END OPTIONAL_DISK_GUARD_POLICY
    capability(); subreaper(); record=Path(record_directory);record.mkdir()
    SIGNAL_ERRORS.clear()
    SIGNAL_ERROR_COUNT = 0
    baseline=memory(); execution={'startedAt':utc(),'command':command,'policy':policy,'memoryBefore':baseline,'exitCode':None,'diagnosticStopped':False,'stopReasons':[],'accepted':False,'currentGuardPid':os.getpid()};child=None
    # BEGIN OPTIONAL_DISK_GUARD_SCALARS
    _disk_stats=None
    if _disk_spec is not None:
        _disk_stats={'path':_disk_spec['path'],'minimumFreeBytes':_disk_spec['minimumFreeBytes'],'beforeAvailableBytes':None,'minimumAvailableBytesObserved':None,'lastAvailableBytes':None,'sampleCount':0,'readErrorCount':0,'lastReadErrorType':None}
        execution['diskFreeGuard']=_disk_stats
    # END OPTIONAL_DISK_GUARD_SCALARS
    write=lambda:(record/'execution.json').write_text(json.dumps(execution,indent=2)+'\n')
    write();started=time.monotonic(); stopped=None;peakown=0;peakshared=baseline['current']
    with handlers():
        try:
            with (record/'child.log').open('wb') as log,(record/'memory.jsonl').open('w') as samples:
                with defer_launch():
                    if before_spawn is not None: before_spawn(memory())
                    # BEGIN OPTIONAL_DISK_GUARD_BEFORE_FORK
                    if _disk_spec is not None:
                        available=_disk_guard_sample(_disk_spec,_disk_stats);write()
                        disk_flags=_disk_guard_flags(available,_disk_spec)
                        if disk_flags:
                            execution.update(diagnosticStopped=True,stopReasons=disk_flags,stoppedAt=utc(),stopElapsedSeconds=time.monotonic()-started);write()
                            raise RuntimeError('Disk free guard refused before owned child launch')
                    # END OPTIONAL_DISK_GUARD_BEFORE_FORK
                    child=subprocess.Popen(command,cwd=cwd,env={**os.environ,**(environment or {})},stdout=log,stderr=subprocess.STDOUT,start_new_session=True,shell=False)
                execution.update(pid=child.pid,pgid=child.pid);write()
                leader=process(child.pid)
                execution['freshLeaderIdentity']=leader;write()
                if leader is not None and (leader['pgid']!=child.pid or leader['sid']!=child.pid or (leader['state'] not in ('Z','X') and leader['argv']!=command) or child.pid==os.getpid()): raise RuntimeError('Fresh owned leader command/session differs')
                while True:
                    elapsed=time.monotonic()-started;reap_zombies(child.pid,child.pid);rows=owned(child.pid);current=memory();result=exit_status(child)
                    peakown=max(peakown,sum(row['rss'] for row in rows));peakshared=max(peakshared,current['current'])
                    flags=reasons(elapsed,rows,current,baseline,policy)
                    # BEGIN OPTIONAL_DISK_GUARD_SAMPLE
                    if _disk_spec is not None:
                        flags.extend(_disk_guard_flags(_disk_guard_sample(_disk_spec,_disk_stats),_disk_spec))
                    # END OPTIONAL_DISK_GUARD_SAMPLE
                    if result is not None and any(row['pid']!=child.pid for row in rows): flags.append('DESCENDANTS_AFTER_LEADER_EXIT')
                    samples.write(json.dumps({'utc':utc(),'elapsedSeconds':elapsed,'owned':rows,'memory':current,'runnerExit':result})+'\n');samples.flush()
                    if flags and stopped is None: stopped=time.monotonic();execution.update(diagnosticStopped=True,stopReasons=flags,stoppedAt=utc(),stopElapsedSeconds=elapsed);write()
                    if stopped is not None:
                        for row in reversed(rows):
                            if row['state']!='Z': scoped_signal(row,child.pid,signal.SIGKILL if time.monotonic()-stopped>=policy['termGraceSeconds'] else signal.SIGTERM)
                        execution['signalErrors']=list(SIGNAL_ERRORS);execution['signalErrorCount']=SIGNAL_ERROR_COUNT;write()
                    reap_zombies(child.pid,child.pid)
                    if result is not None and not any(row['pid']!=child.pid for row in owned(child.pid)): break
                    time.sleep(policy['sampleSeconds'])
                execution.update(exitCode=child.wait(),endedAt=utc(),wallSeconds=time.monotonic()-started,cleanupOwnedGroupEmpty=True,peakOwnedRssBytes=peakown,peakSharedBytes=peakshared,memoryAfter=memory())
                execution['oomDelta']={key:execution['memoryAfter']['events'][key]-baseline['events'][key] for key in OOM_KEYS}
                execution.update(signalErrors=list(SIGNAL_ERRORS),signalErrorCount=SIGNAL_ERROR_COUNT)
                write();return execution
        except BaseException as error:
            if child is not None: cleanup(child,policy['termGraceSeconds'])
            execution.update(exitCode=child.returncode if child is not None else None,endedAt=utc(),wallSeconds=time.monotonic()-started,cleanupOwnedGroupEmpty=owned(child.pid)==[] if child is not None else None,memoryAfter=memory())
            execution['oomDelta']={key:execution['memoryAfter']['events'][key]-baseline['events'][key] for key in OOM_KEYS}
            execution.update(signalErrors=list(SIGNAL_ERRORS),signalErrorCount=SIGNAL_ERROR_COUNT)
            execution.update(diagnosticStopped=True,guardError=type(error).__name__,accepted=False);write();raise
