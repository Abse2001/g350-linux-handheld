// Isolated V6 uses the exact V5 wrapper with only CPU13's copied placement shifted20um.
// Routing stays disabled; all source constraints and both reference stubs remain.
export { default } from './am3352-g350-ti-top-bottom-ddr-v5-layout.circuit'
