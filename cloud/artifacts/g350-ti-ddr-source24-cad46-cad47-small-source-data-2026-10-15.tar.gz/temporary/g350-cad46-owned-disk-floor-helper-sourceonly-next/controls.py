"""SOURCE ONLY CONTROLS. Root may run in one owned qualification scope.
No real filesystem pressure, child/solver/application/native/container operation.
Only pure policy/threshold tests, source inverse/AST, and fake readonly statvfs data.
"""
import ast,errno,hashlib,importlib.util,json,re
from pathlib import Path
from types import SimpleNamespace
BASE_PATH='/workspace/bus-lanes-solver/.cache/paired-compact-front-identity-capture30-root-runner-sourceonly-next/process_scope_diagnostic.proposal.py'
FORK_PATH='/tmp/g350-cad46-owned-disk-floor-helper-sourceonly-next/process_scope_disk_guard.py'
FORK_SHA='cd60a6078b0a7f951b4743cf2ceb7e9267e463b652ca02fb67e6c9408945b58b'
INVALID=[('explicit_null_guard', None), ('list_guard', []), ('string_guard', 'x'), ('missing_path', {'minimumFreeBytes': 1}), ('missing_floor', {'path': '/var/lib/docker'}), ('unknown_guard_key', {'path': '/var/lib/docker', 'minimumFreeBytes': 1, 'x': 1}), ('boolean_floor', {'path': '/var/lib/docker', 'minimumFreeBytes': True}), ('zero_floor', {'path': '/var/lib/docker', 'minimumFreeBytes': 0}), ('negative_floor', {'path': '/var/lib/docker', 'minimumFreeBytes': -1}), ('float_floor', {'path': '/var/lib/docker', 'minimumFreeBytes': 1.5}), ('string_floor', {'path': '/var/lib/docker', 'minimumFreeBytes': '1'}), ('relative_path', {'path': 'var/lib/docker', 'minimumFreeBytes': 1}), ('empty_path', {'path': '', 'minimumFreeBytes': 1}), ('nul_path', {'path': '/var/lib/docker\x00bad', 'minimumFreeBytes': 1}), ('parent_path', {'path': '/var/lib/../lib/docker', 'minimumFreeBytes': 1}), ('dot_path', {'path': '/var/./lib/docker', 'minimumFreeBytes': 1})]
NAMES=['five_block_inverse_exact_91b1', 'all_original_function_bodies_held_except_insertion_sites', 'absent_guard_returns_none', 'absent_guard_legacy_extra_unchanged', 'configured_policy_copy_independent', 'configured_top_unknown_refused', 'floor_minus_one_stops', 'exact_floor_does_not_stop', 'floor_plus_one_does_not_stop', 'zero_available_stops', 'huge_available_does_not_stop', 'legacy_reason_order_held', 'sample_minimum_and_counts', 'sample_zero_available_recorded', 'statvfs_error_identity_and_scalar_failure', 'invalid_statvfs_fragment_refused', 'explicit_null_guard', 'list_guard', 'string_guard', 'missing_path', 'missing_floor', 'unknown_guard_key', 'boolean_floor', 'zero_floor', 'negative_floor', 'float_floor', 'string_floor', 'relative_path', 'empty_path', 'nul_path', 'parent_path', 'dot_path']

def main():
 results=[]
 def mark(name):
  assert name in NAMES and name not in results;results.append(name)
 base=Path(BASE_PATH).read_text();source=Path(FORK_PATH).read_text()
 assert hashlib.sha256(base.encode()).hexdigest()=='91b1a5ef2327bffc3b45783621a73403c6d29635c7129bf6a157c8b3d49ff1f9'
 assert hashlib.sha256(source.encode()).hexdigest()==FORK_SHA
 stripped=re.sub(r'(?m)^[ \t]*# BEGIN OPTIONAL_DISK_GUARD_[A-Z_]+\n.*?^[ \t]*# END OPTIONAL_DISK_GUARD_[A-Z_]+\n','',source,flags=re.S|re.M)
 assert stripped==base;mark('five_block_inverse_exact_91b1')
 old={n.name:n for n in ast.parse(base).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};new={n.name:n for n in ast.parse(source).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 for name,node in old.items():
  if name!='run_guarded':assert ast.dump(node,include_attributes=False)==ast.dump(new[name],include_attributes=False)
 mark('all_original_function_bodies_held_except_insertion_sites')
 spec=importlib.util.spec_from_file_location('qualified_disk_floor_pure_controls',FORK_PATH);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 policy={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 assert module._disk_guard_policy(policy)is None;mark('absent_guard_returns_none')
 assert module._disk_guard_policy({**policy,'legacyUnknown':True})is None;mark('absent_guard_legacy_extra_unchanged')
 configured={**policy,'diskFreeGuard':{'path':'/var/lib/docker','minimumFreeBytes':134217728}}
 guard=module._disk_guard_policy(configured);assert guard==configured['diskFreeGuard']and guard is not configured['diskFreeGuard'];mark('configured_policy_copy_independent')
 try:module._disk_guard_policy({**configured,'unknown':1})
 except ValueError:mark('configured_top_unknown_refused')
 else:raise AssertionError('Unknown configured policy accepted')
 for name,value in INVALID:
  try:module._disk_guard_policy({**policy,'diskFreeGuard':value})
  except ValueError:mark(name)
  else:raise AssertionError(name+' accepted')
 for name,available,expected in [('floor_minus_one_stops',134217727,['OWNED_DISK_FREE_STOP']),('exact_floor_does_not_stop',134217728,[]),('floor_plus_one_does_not_stop',134217729,[]),('zero_available_stops',0,['OWNED_DISK_FREE_STOP']),('huge_available_does_not_stop',2**70,[])]:
  assert module._disk_guard_flags(available,guard)==expected;mark(name)
 assert module.reasons(90,[{'rss':1073741824}],{'current':32212254720,'events':{'oom':1,'oom_kill':0,'oom_group_kill':0}},{'events':{'oom':0,'oom_kill':0,'oom_group_kill':0}},policy)==['OWNED_RSS_STOP','SHARED_MEMORY_STOP','NEW_OOM_STOP','WALL_STOP'];mark('legacy_reason_order_held')
 def stats():return {'path':guard['path'],'minimumFreeBytes':guard['minimumFreeBytes'],'beforeAvailableBytes':None,'minimumAvailableBytesObserved':None,'lastAvailableBytes':None,'sampleCount':0,'readErrorCount':0,'lastReadErrorType':None}
 original=module.os.statvfs
 try:
  calls=[];values=iter([SimpleNamespace(f_bavail=12,f_frsize=4096),SimpleNamespace(f_bavail=5,f_frsize=4096)])
  def fake(path):calls.append(path);return next(values)
  module.os.statvfs=fake;state=stats();assert module._disk_guard_sample(guard,state)==49152;assert module._disk_guard_sample(guard,state)==20480
  assert state['beforeAvailableBytes']==49152 and state['minimumAvailableBytesObserved']==state['lastAvailableBytes']==20480 and state['sampleCount']==2 and state['readErrorCount']==0 and calls==['/var/lib/docker']*2;mark('sample_minimum_and_counts')
  module.os.statvfs=lambda _:SimpleNamespace(f_bavail=0,f_frsize=4096);state=stats();assert module._disk_guard_sample(guard,state)==0 and state['minimumAvailableBytesObserved']==0;mark('sample_zero_available_recorded')
  failure=OSError(errno.EIO,'synthetic unavailable statvfs')
  def broken(_):raise failure
  module.os.statvfs=broken;state=stats()
  try:module._disk_guard_sample(guard,state)
  except OSError as caught:assert caught is failure
  else:raise AssertionError('statvfs read error hidden')
  assert state['readErrorCount']==1 and state['lastReadErrorType']=='OSError'and state['sampleCount']==0 and state['beforeAvailableBytes']is None;mark('statvfs_error_identity_and_scalar_failure')
  module.os.statvfs=lambda _:SimpleNamespace(f_bavail=1,f_frsize=0);state=stats()
  try:module._disk_guard_sample(guard,state)
  except ValueError:pass
  else:raise AssertionError('Invalid fragment accepted')
  assert state['sampleCount']==0 and state['readErrorCount']==1;mark('invalid_statvfs_fragment_refused')
 finally:module.os.statvfs=original
 assert module.os.statvfs is original and len(results)==len(NAMES)and set(results)==set(NAMES)
 print(json.dumps({'passed':True,'controls':NAMES,'controlCount':len(NAMES),'processLaunches':0,'solverImports':0,'actualDiskPressureExercised':False,'actualOwnedDiskStopExercised':False,'actualFilesystemStatvfsCalls':0,'accepted49':False,'fabricationReady':False}))

if __name__=='__main__':main()
