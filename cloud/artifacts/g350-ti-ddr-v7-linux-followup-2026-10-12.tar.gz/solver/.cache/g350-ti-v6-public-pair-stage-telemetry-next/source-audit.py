"""Read-only frozen source914 SHA/mode audit. Explicitly not a published Git commit.
Own template .git metadata20 and full-suite outputs are excluded from source914,
not imported by this runtime; no Git/status/index writes are performed here.
"""
from pathlib import Path
import hashlib,json,stat
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/bus-lanes-solver')
FROZEN=REPO/'.cache/g350-enclosed-terminal-precheck-source-next'
SOURCE=FROZEN/'source'
MANIFEST_SHA='9670e70cc80a6633e13dd2f3f5a1c601abf78da7d73ded01d12fcc3c0e1bd9ff'
CLOSURE='de8dbdf40a3134f1f29ada810c355ff8a8a4e2ac93ad2a0c7064165875ad46bb'
LIBRARY_SHA='e0a35a46b5d090b129eecee06dceb5139d240e61a328598449abd018b675ccf3'
RELEASE_SHA='262b4397f77f7806869ef530f3e751b1101688f743fce99cee03b5b77d75c128'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def verify():
 raw=(FROZEN/'immutable-source-manifest.json').read_bytes()
 if hashlib.sha256(raw).hexdigest()!=MANIFEST_SHA:raise ValueError('Frozen source914 manifest differs')
 m=json.loads(raw);records=m['sourceFiles'];closure=hashlib.sha256(json.dumps(records,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 if len(records)!=914 or closure!=CLOSURE or m['sourceClosureSha256']!=CLOSURE:raise ValueError('Full914 source closure differs')
 if sha(FROZEN/'RELEASE.json')!=RELEASE_SHA or sha(FROZEN/'library-v1/manifest.json')!=LIBRARY_SHA:raise ValueError('Release/library identity differs')
 release=json.loads((FROZEN/'RELEASE.json').read_bytes())
 if release['sourceManifestSha256']!=MANIFEST_SHA or release['sourceClosureSha256']!=CLOSURE or release['libraryManifestSha256']!=LIBRARY_SHA:raise ValueError('Release source linkage differs')
 for record in records:
  p=SOURCE/record['path'];s=p.lstat()
  if not stat.S_ISREG(s.st_mode) or p.is_symlink() or stat.S_IMODE(s.st_mode)!=m['filesystemModes'][record['path']] or p.stat().st_size!=record['bytes'] or sha(p)!=record['sha256']:raise ValueError('Frozen914 source bytes/mode differ: '+record['path'])
 library=json.loads((FROZEN/'library-v1/manifest.json').read_bytes())['files']
 if len(library)!=124:raise ValueError('Runtime124 closure differs')
 for record in library:
  p=ROOT/'source'/record['path'];s=p.lstat()
  if not stat.S_ISREG(s.st_mode) or p.is_symlink() or stat.S_IMODE(s.st_mode)!=record['mode'] or p.stat().st_size!=record['bytes'] or sha(p)!=record['sha256'] or p.read_bytes()!=(SOURCE/record['path']).read_bytes():raise ValueError('Copied runtime124 differs: '+record['path'])
 for link in [SOURCE/'node_modules',ROOT/'source/node_modules',ROOT/'node_modules']:
  if not link.is_symlink() or link.resolve()!=REPO/'node_modules':raise ValueError('Trusted dependency resolver differs')
 return {'verified':True,'nonmutating':True,'sourceFiles':914,'sourceManifestSha256':MANIFEST_SHA,'sourceClosureSha256':CLOSURE,'libraryManifestSha256':LIBRARY_SHA,'releaseSha256':RELEASE_SHA,'copiedRuntimeMembers':124,'sourceRevisionLabel':'FROZEN_UNCOMMITTED_SOURCE914_9670e70c','candidateCommit':None,'candidateLibTree':None,'publishedGitCommitVerified':False,'all914BytesAndFilesystemModesEqual':True,'excludedOwnTemplateGitMetadataEntries':20,'solverConstructed':False,'runtimeImported':False,'indexWritesPerformed':False}
if __name__=='__main__':print(json.dumps(verify(),sort_keys=True))
