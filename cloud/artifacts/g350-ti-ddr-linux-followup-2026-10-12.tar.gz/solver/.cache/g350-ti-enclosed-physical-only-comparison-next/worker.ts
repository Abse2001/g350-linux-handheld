/** Exactly one parent-authorized physical-only comparison; no route publication. */
import { strict as assert } from "node:assert"
import { createHash } from "node:crypto"
import { readFileSync,writeFileSync } from "node:fs"
import { join } from "node:path"
import { VectorScene } from "../g350-ti-enclosed-grid-component-probe-next/source/lib/vector-scene"
import { GridVisibilitySearch } from "../g350-ti-enclosed-grid-component-probe-next/source/lib/grid-visibility"
const root=import.meta.dir,origin=join(root,"../g350-ti-top-clock-enclosed-boundary-v2-next/run/first-enclosed-grid-constructor.json"),raw=readFileSync(origin),sha=(v:string|Uint8Array)=>createHash("sha256").update(v).digest("hex"),fingerprint=(v:unknown)=>sha(JSON.stringify(v))
assert.equal(sha(raw),"798e435705fb5d47bb47b08043a78a90c8837436d2bada425be0f9c058857418")
const capture=JSON.parse(raw.toString()),before=fingerprint(capture),physical=capture.filteredPhysicalCopper
assert.ok(capture.originalPhysicalCopper.length===893&&physical.length===616&&capture.clockCandidateCopper.length===169&&capture.copper.length===785,"Exact physical versus provisional inventory changed")
assert.ok(fingerprint(capture.copper.slice(0,616))===fingerprint(physical)&&fingerprint(capture.copper.slice(616))===fingerprint(capture.clockCandidateCopper),"Only captured clock suffix may be removed")
assert.ok(capture.clockCandidateCopper.every((c:any)=>c.owners.some((owner:string)=>["source_trace_33","source_trace_34"].includes(owner))),"Removal must target only provisionalclock owners")
const scene=new VectorScene(capture.input,capture.connection,capture.width,physical)
assert.ok(fingerprint(scene.input)===fingerprint(capture.input)&&fingerprint(scene.connection)===fingerprint(capture.connection)&&scene.width===capture.width&&scene.margin===capture.margin&&fingerprint([...scene.owners])===fingerprint(capture.owners)&&fingerprint(scene.copper)===fingerprint(physical),"Original physical-only Scene parity changed")
const constructorStart=performance.now(),check=new GridVisibilitySearch(scene,capture.start,capture.end,[],4,undefined,{checkReachability:true}),constructorSeconds=(performance.now()-constructorStart)/1000
let steps=0,snapshot:any,cancelCalls=0
try{while(!check.solved&&!check.failed&&check.expanded<500000){check.step();steps++}
 snapshot={solved:check.solved,failed:check.failed,expanded:check.expanded,steps,nx:check.nx,ny:check.ny,cellCount:check.cellCount,result:check.solved?structuredClone(check.result):null}
 if(snapshot.solved)assert.ok(scene.pathVisible(snapshot.result),"Physical-only solved witness must retain exact visibility")
}finally{check.cancel();cancelCalls++}
assert.ok(fingerprint(capture)===before,"Original capture input/Cu mutated")
const result={scope:"ONE_PARENT_AUTHORIZED_PHYSICAL_ONLY_GRID_COMPARISON",captureSha256:sha(raw),sourceCommit:"c1151212be7b9de4b34b07436d135d874e6c0466",removedCopperOwners:["source_trace_33","source_trace_34"],removedProvisionalClockCopperCount:169,originalAllPhysicalCopperCount:893,filteredPhysicalCopperCount:616,sceneInputHash:fingerprint(scene.input),sceneCopperHash:fingerprint(scene.copper),sceneOwnersHash:fingerprint([...scene.owners]),sceneWidth:scene.width,sceneMargin:scene.margin,originalGridCalls:1,constructorSeconds,gridOnlyOptionalFlag:"checkReachability:true",gridCapExpanded:500000,defaultGridStep:.0508,beforeCancel:snapshot,cancelCalls,afterCancel:{solved:check.solved,failed:check.failed,expanded:check.expanded},status:snapshot.solved?"PHYSICAL_ONLY_POSITIVE_WITNESS":snapshot.failed?"PHYSICAL_ONLY_FINITE_GRID_FAILURE":"PHYSICAL_ONLY_BOUNDED_UNKNOWN",inputAndAllOriginalPhysicalCopperHeld:true,onlyClockSuffixRemoved:true,globalPhysicalInfeasibilityProven:false,acceptedClock:false,accepted49:false,fabricationReady:false}
const output=JSON.stringify(result,null,2)+"\n";assert.ok(Buffer.byteLength(output)<=4*1024**2);writeFileSync(join(root,"run/result.json"),output,{flag:"wx"});console.log(JSON.stringify({status:result.status,beforeCancel:{...snapshot,result:snapshot.result?.length??null},accepted49:false}))
