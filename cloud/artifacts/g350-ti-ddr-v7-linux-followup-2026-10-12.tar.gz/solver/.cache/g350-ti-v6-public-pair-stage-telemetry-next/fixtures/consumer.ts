import { planSharedPairCorridors } from "./planner"
import { routeCoupledPair } from "./coupled"
import { runBoundedRouting } from "./bounded"
import { negotiateSignalSites } from "./sites"
export function consume(input: any) {
  return planSharedPairCorridors(input, new Map(), true, {
    preferPackageOnlyTuning: true,
    variant: 3,
  })
}
export function siteEntry(input: any) {
  return negotiateSignalSites(input)
}
export function currentBindings() {
  return {
    planSharedPairCorridors,
    routeCoupledPair,
    runBoundedRouting,
    negotiateSignalSites,
  }
}
