import fcntl,hashlib,importlib.util,json,sys
from pathlib import Path
board=Path('/workspace/g350-linux-handheld'); cache=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
helper=Path('/tmp/g350-process-scope-empty-argv-bounded-startup-retry-sourceonly-next/process_scope_empty_argv_retry.proposal.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(helper)=='3756c2f9bfc8284135954669c0a1cbe0e5e966796b0743c6f462af703e17a361'
spec=importlib.util.spec_from_file_location('root_pr_owned_scope',helper);owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
run=Path(sys.argv[1]);cwd=Path(sys.argv[2]);command=sys.argv[3:];run.mkdir(exist_ok=False)
protected=[board/p for p in ['AGENTS.md','cloud/CONTINUE_BOARD.md','scripts/prepare-g350-ram90-four-layer.mjs','scripts/tune-g350-ram90-native-lengths.mjs','node_modules/@tscircuit/checks/dist/index.js','node_modules/@tscircuit/core/dist/index.js']]
solver_manifest=Path('/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/SOURCE-manifest.json');assert sha(solver_manifest)=='b9700a9a44c9be5f661fd38c37ca9ff6c2f012983e49a750fecea3c8d75e19e0'
solver_pins=json.loads(solver_manifest.read_text())['solverSourceFiles'];pins={str(p):sha(p) for p in protected+[helper,solver_manifest]}
def verify():
 for p,h in pins.items():assert sha(Path(p))==h,p
 for row in solver_pins:assert sha(Path(row['path']))==row['sha256'],row['path']
verify();policy={'wallSeconds':180,'rssBytes':1024**3,'sharedBytes':30*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
def admit(m):assert m['current']+policy['rssBytes']+1024**3<policy['sharedBytes']
journal=cache/'LATEST_CONTINUATION_2026-10-14.json'
with (cache/'strict18-root-serial.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);state=json.loads(journal.read_text());assert not state.get('rootSdkInvocationOpen');scope=state['requiresCurrentClosedScopes']+1
 state.update(rootSdkInvocationOpen=True,activeRootScope=scope,nextOperation='Clean upstream G350 reproduction validation',currentRouteRun=str(run));journal.write_text(json.dumps(state,indent=2)+'\n')
 execution=None
 try:execution=owned.run_guarded(command,str(cwd),run/'owned',policy,before_spawn=admit)
 finally:
  verify();assert execution is None or owned.owned(execution['pgid'])==[]
  receipt={'scope':scope,'execution':execution,'protectedFilesUnchanged':True,'solverSourceFilesUnchanged':True,'fabricationReady':False};(run/'COLLECTED.json').write_text(json.dumps(receipt,indent=2)+'\n')
  state.update(rootSdkInvocationOpen=False,activeRootScope=None,requiresCurrentClosedScopes=scope,lastRouteCollection=str(run/'COLLECTED.json'));journal.write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps({'scope':scope,'run':str(run),'exitCode':execution['exitCode'],'stopReasons':execution['stopReasons'],'ownedGroupEmpty':execution['cleanupOwnedGroupEmpty']}))
sys.exit(execution['exitCode'] if execution['exitCode'] and execution['exitCode']>0 else 1 if execution['diagnosticStopped'] or execution['exitCode'] else 0)
