/** Proposed Root-only one direct pinned Core render; unexecuted source. */
import assert from "node:assert/strict"
import { readFileSync, writeFileSync, existsSync } from "node:fs"
import { createHash } from "node:crypto"
import { buildCombinedClockV11FidelitySource, registerClockInnerPorts } from "./clock-fidelity-source-overlay"
import proposal from "./clock-fidelity-source-proposal.json"
import signalProposal from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-signal96-joint-native-sourceonly-next/signal-source-proposal.json"
const [output, reportPath, ...extra] = process.argv.slice(2)
assert.equal(process.env.G350_CLOCK_FIDELITY_CORE_APPROVED, "1")
assert.ok(output && reportPath && extra.length === 0 && !existsSync(output) && !existsSync(reportPath)); assert.equal(process.versions.bun, "1.3.14")
const digest = (p: string) => createHash("sha256").update(readFileSync(p)).digest("hex")
assert.equal(digest("/workspace/g350-linux-handheld/node_modules/@tscircuit/core/dist/index.js"), "97b8a4eb484630c3ce2bfc2d68588801484d85adf94785d8849a1d91c4404905")
assert.equal(digest("/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js"), "1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc")
const baselinePath = "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-core-qualification-source-next/run-core/fresh-core.circuit.json"
assert.equal(digest(baselinePath), "ed33a0a335b1fbf0da9adcdeacaa954b655c3c4964c600efb6ef3c72aef4040e")
const baseline = JSON.parse(readFileSync(baselinePath, "utf8")) as Array<Record<string, any>>
const { Circuit } = await import("/workspace/g350-linux-handheld/node_modules/@tscircuit/core/dist/index.js")
const circuit = new Circuit(); circuit.schematicDisabled = true; circuit.pcbRoutingDisabled = true
circuit.add(buildCombinedClockV11FidelitySource().element as any)
const matches = registerClockInnerPorts(circuit)
await circuit.renderUntilSettled()
const core = circuit.getCircuitJson() as Array<Record<string, any>>, raw = `${JSON.stringify(core, null, 2)}\n`
// Preserve the entire raw Core before any physical/source assertion.
writeFileSync(output, raw, { flag: "wx", mode: 0o600 })
const checks: Array<{ label: string; passed: boolean; actual: unknown; expected?: unknown }> = []
const count = (type: string) => core.filter(r => r.type === type).length
for (const [type, expected] of [["source_component",280],["pcb_smtpad",1161],["pcb_via",225],["pcb_hole",2],["pcb_plated_hole",4],["pcb_trace",263],["source_net",98],["source_bus",8],["pcb_port",1615]] as const)
  checks.push({ label: type, passed: count(type) === expected, actual: count(type), expected })
const canonical = (value: any): string => Array.isArray(value) ? `[${value.map(canonical).join(",")}]`
  : value && typeof value === "object" ? `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(",")}}`
  : JSON.stringify(value) ?? "undefined"
const shape = (point: Record<string, any>) => Object.fromEntries(Object.entries(point)
  .filter(([key]) => key !== "start_pcb_port_id" && key !== "end_pcb_port_id"))
// IDs may shift when original clock paths render earlier. Match reference
// copper by unchanged logical owner and complete route geometry, once each.
const remainingReferenceTraces = core.filter(r => r.type === "pcb_trace").slice()
const referenceProjection = baseline.filter(r => r.type === "pcb_trace").map(old => {
  const signature = canonical(old.route.map(shape))
  const index = remainingReferenceTraces.findIndex(now => now.source_trace_id === old.source_trace_id && canonical(now.route.map(shape)) === signature)
  const now = index < 0 ? null : remainingReferenceTraces.splice(index, 1)[0]
  return { originalPcbTraceId: old.pcb_trace_id, actualPcbTraceId: now?.pcb_trace_id ?? null, originalSourceTraceId: old.source_trace_id, exactRouteGeometryHeld: now !== null }
})
checks.push({ label: "all165-original-reference-copper-exact-bijection", passed: referenceProjection.length === 165 && referenceProjection.every(r => r.exactRouteGeometryHeld), actual: referenceProjection.filter(r => r.exactRouteGeometryHeld).length, expected: 165 })
const originalLogical49 = baseline.filter(r => r.type === "source_trace" && /^source_trace_\d+$/.test(r.source_trace_id) && Number(r.source_trace_id.slice(13)) < 49)
const sourceLogical = (row: Record<string, any>) => Object.fromEntries(Object.entries(row).filter(([key]) => key !== "subcircuit_connectivity_map_key"))
checks.push({ label: "all49-original-numeric-logical-traces-and-constraints-held", passed: originalLogical49.length === 49 && originalLogical49.every(old => {
  const now = core.find(r => r.type === "source_trace" && r.source_trace_id === old.source_trace_id)
  return now && canonical(sourceLogical(now)) === canonical(sourceLogical(old))
}), actual: originalLogical49.length, expected: 49 })
const busesHeld = canonical(core.filter(r => r.type === "source_bus")) === canonical(baseline.filter(r => r.type === "source_bus"))
checks.push({ label: "all8-source-bus-rows-and-original-membership-held", passed: busesHeld, actual: busesHeld, expected: true })
const namedNetProjection = baseline.filter(r => r.type === "source_net").map(old => {
  const now = core.find(r => r.type === "source_net" && r.source_net_id === old.source_net_id)
  return { sourceNetId: old.source_net_id, originalName: old.name, actualName: now?.name ?? null,
    originalNamedNetDefinitionHeld: !!now && canonical(sourceLogical(now)) === canonical(sourceLogical(old)) }
})
checks.push({ label: "all98-original-source-net-identities-names-and-definitions-held", passed: namedNetProjection.length === 98 && namedNetProjection.every(r=>r.originalNamedNetDefinitionHeld), actual: namedNetProjection.filter(r=>r.originalNamedNetDefinitionHeld).length, expected: 98 })
const physicalHoleProjection = ["pcb_hole", "pcb_plated_hole"].flatMap(type => {
  const remaining = core.filter(r => r.type === type).slice()
  const physicalShape = (r: Record<string, any>) => Object.fromEntries(Object.entries(r)
    .filter(([key])=>key!==`${type}_id` && key!=="pcb_port_id"))
  const result = baseline.filter(r=>r.type===type).map(old=>{
    const index = remaining.findIndex(now=>canonical(physicalShape(now))===canonical(physicalShape(old)))
    const now = index<0 ? null : remaining.splice(index,1)[0]
    return { type, originalId: old[`${type}_id`], actualId: now?.[`${type}_id`] ?? null, exactPhysicalGeometryAndComponentHeld: now!==null }
  })
  checks.push({ label: `${type}-original-physical-shape-bijection-no-extra-holes`, passed: remaining.length===0 && result.every(r=>r.exactPhysicalGeometryAndComponentHeld), actual: { exactMatches:result.filter(r=>r.exactPhysicalGeometryAndComponentHeld).length, unmatched:remaining.length }, expected: { exactMatches:type==="pcb_hole"?2:4, unmatched:0 } })
  return result
})
const nearXY = (a: Record<string, any>, b: Record<string, any>) => Math.hypot(a.x-b.x,a.y-b.y) < 1e-9
const viaShape = (row: Record<string, any>) => ({ x: row.x, y: row.y, hole_diameter: row.hole_diameter,
  outer_diameter: row.outer_diameter, layers: row.layers, from_layer: row.from_layer, to_layer: row.to_layer,
  tented_on_top: row.tented_on_top, tented_on_bottom: row.tented_on_bottom })
const remainingVias = core.filter(r => r.type === "pcb_via").slice()
const referenceViaProjection = baseline.filter(r => r.type === "pcb_via").map(old => {
  const index = remainingVias.findIndex(now => canonical(viaShape(now)) === canonical(viaShape(old)))
  const now = index < 0 ? null : remainingVias.splice(index, 1)[0]
  return { originalViaId: old.pcb_via_id, actualViaId: now?.pcb_via_id ?? null, exactPhysicalSpanPositionAndDimensionsHeld: now !== null }
})
checks.push({ label: "all129-original-reference-barrels-exact-bijection", passed: referenceViaProjection.length === 129 && referenceViaProjection.every(r => r.exactPhysicalSpanPositionAndDimensionsHeld), actual: referenceViaProjection.filter(r => r.exactPhysicalSpanPositionAndDimensionsHeld).length, expected: 129 })
const signalViaProjection = signalProposal.owners.map(owner => {
  const index = remainingVias.findIndex(now => nearXY(now,owner.viaXY) && now.hole_diameter === .254 && now.outer_diameter === .4572
    && canonical(now.layers) === canonical(owner.viaLayers) && now.from_layer === "top" && now.to_layer === "bottom")
  const now = index < 0 ? null : remainingVias.splice(index, 1)[0]
  return { sourceViaName: owner.viaName, actualViaId: now?.pcb_via_id ?? null, completePhysicalBarrelHeld: now !== null }
})
checks.push({ label: "all96-signal-barrels-once-and-no-other-holes", passed: signalViaProjection.length === 96 && signalViaProjection.every(r=>r.completePhysicalBarrelHeld) && remainingVias.length === 0,
  actual: { signalBarrels: signalViaProjection.filter(r=>r.completePhysicalBarrelHeld).length, unmatchedHoles: remainingVias.length }, expected: { signalBarrels: 96, unmatchedHoles: 0 } })
const signalTopProjection = signalProposal.owners.map(owner => {
  const candidates = core.filter(r => r.type === "pcb_trace" && r.route.length === 2
    && r.route.every((p: Record<string, any>) => p.route_type === "wire" && p.layer === "top" && p.width === .1016)
    && ((nearXY(r.route[0], owner.topStub[0]) && nearXY(r.route[1], owner.topStub[1]))
      || (nearXY(r.route[1], owner.topStub[0]) && nearXY(r.route[0], owner.topStub[1]))))
  const isClock = proposal.clockCarriers.some(c => c.originalSourceTraceId === owner.originalSourceTraceId)
  const owningSource = candidates[0] && core.find(r => r.type === "source_trace" && r.source_trace_id === candidates[0].source_trace_id)
  const sourceOwnershipHeld = isClock ? candidates[0]?.source_trace_id === owner.originalSourceTraceId
    : !!owningSource && owningSource.name === owner.traceName && owningSource.connected_source_port_ids.includes(owner.originalSourcePortId)
  return { originalSourceTraceId: owner.originalSourceTraceId, originalNumericSourcePortId: owner.originalSourcePortId,
    actualPcbTraceIds: candidates.map(r => r.pcb_trace_id), actualDirectSourceTraceId: candidates[0]?.source_trace_id ?? null,
    exactlyOneTopStub: candidates.length === 1, sourceOwnershipHeld }
})
checks.push({ label: "all96-signal-top-stubs-single-render-and-numeric-owner", passed: signalTopProjection.length === 96 && signalTopProjection.every(r => r.exactlyOneTopStub && r.sourceOwnershipHeld), actual: signalTopProjection.filter(r => r.exactlyOneTopStub && r.sourceOwnershipHeld).length, expected: 96 })
const clocks = proposal.clockCarriers.map(clock => {
  const source = core.find(r => r.type === "source_trace" && r.source_trace_id === clock.originalSourceTraceId)!
  const traces = core.filter(r => r.type === "pcb_trace" && r.source_trace_id === clock.originalSourceTraceId)
  const inputPins = [clock.cpu.originalSourcePortId, clock.ram.originalSourcePortId]
  checks.push({ label: `${clock.originalSourceTraceId}-original-two-numeric-ports`, passed: !!source && JSON.stringify(source.connected_source_port_ids) === JSON.stringify(inputPins), actual: source?.connected_source_port_ids, expected: inputPins })
  checks.push({ label: `${clock.originalSourceTraceId}-three-physical-paths`, passed: traces.length === 3, actual: traces.length, expected: 3 })
  const inner = traces.filter(t => t.route.every((p: Record<string, any>) => p.route_type === "wire" && p.layer === "inner1"))
  const expectedRoute = clock.expectedInner1PhysicalRoute
  const exactLayerWidthCount = inner.length === 1 && inner[0].route.length === expectedRoute.length
    && inner[0].route.every((p: Record<string, any>, i: number) => p.route_type === "wire" && p.layer === "inner1" && p.width === .1016
      && Math.hypot(p.x-expectedRoute[i].x,p.y-expectedRoute[i].y) < 1e-9)
  const maximumCoordinateDelta = inner.length === 1 && inner[0].route.length === expectedRoute.length
    ? Math.max(...inner[0].route.map((p: Record<string, any>, i: number) => Math.hypot(p.x-expectedRoute[i].x,p.y-expectedRoute[i].y))) : null
  checks.push({ label: `${clock.originalSourceTraceId}-actual-inner1-carrier`, passed: exactLayerWidthCount,
    actual: { carrierCount: inner.length, maximumCoordinateDelta }, expected: { carrierCount: 1, maximumCoordinateDeltaLessThan: 1e-9 },
    })
  const planar = traces.reduce((sum, t) => sum + t.route.slice(1).reduce((length: number, p: Record<string, any>, i: number) => length + Math.hypot(p.x-t.route[i].x,p.y-t.route[i].y), 0), 0)
  checks.push({ label: `${clock.originalSourceTraceId}-full-clock-planar-with-top-stubs`, passed: Math.abs(planar-clock.originalV11WholePlanarLength) < 1e-9, actual: planar, expected: clock.originalV11WholePlanarLength })
  const layerPorts = [clock.cpu, clock.ram].map((owner, endpoint) => {
    const vias = core.filter(r => r.type === "pcb_via" && nearXY(r,owner.viaXY) && r.outer_diameter === .4572 && r.hole_diameter === .254
      && JSON.stringify(r.layers) === JSON.stringify(["top","inner1","inner2","bottom"]) && r.from_layer === "top" && r.to_layer === "bottom")
    const ports = vias.length === 1 ? core.filter(r => r.type === "pcb_port" && vias[0].pcb_port_ids?.includes(r.pcb_port_id)
      && JSON.stringify(r.layers) === JSON.stringify(["inner1"]) && nearXY(r,owner.viaXY)) : []
    const actualInner = inner.length === 1 ? inner[0].route : []
    const referencedPortId = endpoint === 0 ? actualInner[0]?.start_pcb_port_id : actualInner.at(-1)?.end_pcb_port_id
    const sourcePort = ports.length === 1 ? core.find(r => r.type === "source_port" && r.source_port_id === ports[0].source_port_id) : null
    const passed = vias.length === 1 && ports.length === 1 && referencedPortId === ports[0].pcb_port_id && sourcePort?.name === "inner1"
    checks.push({ label: `${clock.originalSourceTraceId}-${endpoint===0?"cpu":"ram"}-actual-owned-inner1-anchor`, passed,
      actual: { viaCount: vias.length, innerPortCount: ports.length, referencedPortId, sourcePortName: sourcePort?.name },
      expected: { viaCount: 1, innerPortCount: 1, sourcePortName: "inner1" } })
    return { viaName: owner.viaName, actualViaId: vias[0]?.pcb_via_id, actualInner1PcbPortId: ports[0]?.pcb_port_id, sourcePort, passed }
  })
  const routeViaPrimitives = traces.flatMap(t=>t.route).filter(p=>p.route_type === "via").length
  checks.push({ label: `${clock.originalSourceTraceId}-no-new-route-via-primitives`, passed: routeViaPrimitives === 0, actual: routeViaPrimitives, expected: 0 })
  return { originalSourceTraceId: clock.originalSourceTraceId, source, pcbTraceIds: traces.map(t=>t.pcb_trace_id), wholePlanarLength: planar, routeViaPrimitives,
    physicalExistingFullSpanBarrels: layerPorts.map(p=>p.actualViaId), actualLayerPortAnchors: layerPorts,
    physicalLayerTransitions: [{ ...clock.cpu.viaXY, fromLayer: "top", toLayer: "inner1" }, { ...clock.ram.viaXY, fromLayer: "inner1", toLayer: "top" }],
    nativeHistoricalViaContributionAutomaticallyRepresentedInTheseRoutes: false }
})
const report = { scope: "one-fresh-pinned-core-clock-fidelity-render-control", rawCorePath: output, rawCoreSha256: createHash("sha256").update(raw).digest("hex"),
  sourcePortMatchesActuallyRegistered: matches.registrations, schematicDisabled: true, pcbRoutingDisabled: true, checks, clocks,
  originalReference165GeometryProjection: referenceProjection, original96TopStubGeometryProjection: signalTopProjection,
  original129ReferenceBarrelProjection: referenceViaProjection, original96SignalBarrelProjection: signalViaProjection,
  original2Npth4PlatedHolePhysicalProjection: physicalHoleProjection, original98NamedNetProjection: namedNetProjection,
  freshCoreControlPassed: checks.every(c=>c.passed), originalFullClockLengthsAssignedDirectSourceIds: clocks.every(c => c.pcbTraceIds.length === 3),
  nativeManufacturingExplicitlyExecuted: false, nativeClockBusFunctionsExplicitlyExecuted: false, freshCadExecuted: false,
  nativeOriginalClockBusAggregationStillRequired: true, nativeNumericCpuRamConnectivityStillRequired: true,
  physicalThroughBarrelsMustNotBeInferredFromRouteViaPrimitiveCount: true,
  fullCohortTimingQualified: false, electricalDelayModelQualified: false, referenceQualified: false, accepted49: false, fabricationReady: false }
writeFileSync(reportPath, `${JSON.stringify(report,null,2)}\n`, { flag: "wx", mode: 0o600 })
assert.equal(report.freshCoreControlPassed, true, "Raw Core and failing controls retained before assertion")
console.log(JSON.stringify({ scope: report.scope, freshCoreControlPassed: true, output, reportPath, accepted49: false }))
