/** Passive public API driver. No constructor/step runs at import time. */
export type PipelineState = {
  iterations: number
  MAX_ITERATIONS: number
  solved: boolean
  failed: boolean
  phase?: string
  error?: unknown
  traces: unknown[]
  step(): void
}

export type ScalarProgress = {
  publicSteps: number
  iterations: number
  defaultCap: number
  phase: string | null
  solved: boolean
  failed: boolean
  actualTraceCount: number
}

export function createPublicPipeline<I, S extends PipelineState>(
  Ctor: new (
    input: I,
    options: {
      maxBusViaCountSkew: number
      maxPairViaCountSkew: number
      precheckEnclosedTerminals: boolean
    },
  ) => S,
  input: I,
): S {
  return new Ctor(input, {
    maxBusViaCountSkew: 0,
    maxPairViaCountSkew: 0,
    precheckEnclosedTerminals: true,
  })
}

export function runPublicSteps<S extends PipelineState>(
  solver: S,
  observe: (progress: ScalarProgress, actualState: S) => void,
) {
  const defaultCap = solver.MAX_ITERATIONS
  if (!Number.isSafeInteger(defaultCap) || defaultCap <= 0)
    throw Error("Invalid original public iteration cap")
  let publicSteps = 0
  const emit = () => {
    // Observation failure must never alter the original step result/error.
    try {
      observe(
        {
          publicSteps,
          iterations: solver.iterations,
          defaultCap,
          phase: typeof solver.phase === "string" ? solver.phase : null,
          solved: solver.solved,
          failed: solver.failed,
          actualTraceCount: solver.traces.length,
        },
        solver,
      )
    } catch {}
  }
  emit()
  while (
    !solver.solved &&
    !solver.failed &&
    solver.iterations < defaultCap &&
    publicSteps < defaultCap
  ) {
    publicSteps++
    // Original receiver and zero-argument public step. No custom acceptance.
    try {
      solver.step()
    } catch (error) {
      emit()
      throw error
    }
    emit()
  }
  return {
    publicSteps,
    defaultCap,
    termination: solver.solved
      ? ("NATURAL_SOLVED" as const)
      : solver.failed
        ? ("NATURAL_FAILED" as const)
        : ("ORIGINAL_CAP_REACHED_UNRESOLVED" as const),
  }
}
