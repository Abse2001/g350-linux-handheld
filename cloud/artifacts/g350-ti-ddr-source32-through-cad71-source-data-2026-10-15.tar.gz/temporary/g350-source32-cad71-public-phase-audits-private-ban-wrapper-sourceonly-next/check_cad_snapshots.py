"""SOURCE-ONLY DRAFT. Root performs copies and creates fresh CAD authority.
This stdlib checker verifies sparse copied bytes and emits readonly Docker mounts.
It performs no file writes, subprocess calls, authority creation or SDK imports.
"""
import hashlib,json,re,stat,sys
from pathlib import Path

CAD_PARENT_PREFIX='g350-source32-cad-root-'
FLAT_TMP_FILE_BINDINGS={'/tmp/g350-source32-native-projector-api-functional-independent-peer.json': {'path': '/tmp/g350-source32-native-projector-api-functional-independent-peer.json', 'sha256': '42ef8aa7a3c5d42b4de73e8efdcf4d99cd6b4a0546ed2b64542bda71c260d939', 'bytes': 2104, 'mode': 384}, '/tmp/g350-source32-declaration-capture-core-independent-peer.json': {'path': '/tmp/g350-source32-declaration-capture-core-independent-peer.json', 'sha256': '090d41ec7c23094c3a2e9a8d438ffeeeeb04814678867e3dbe941ee6e96e8973', 'bytes': 2161, 'mode': 384}, '/tmp/g350-source32-retry67-independent-peer.json': {'path': '/tmp/g350-source32-retry67-independent-peer.json', 'sha256': 'f17b64551be4f562f4d90ce1212191dd2907465578c2dc8ecca3439c3651a491', 'bytes': 932, 'mode': 384}}
# Frozen Source32 runtime reopens all three67 and both69 public per-phase POSTs.
ACTUAL67_PHASE_POST_BINDINGS=[{'path': '/tmp/g350-source32-three-stage-root-20261015-after66/capture/POSTAUDIT.json', 'sha256': '3a9307a132a5b243f60a1c19dfa8fc7af0362246ce7e3bba6e32256324124a3c', 'bytes': 7735, 'mode': 384}, {'path': '/tmp/g350-source32-three-stage-root-20261015-after66/types/POSTAUDIT.json', 'sha256': '189c20bfa5b9ff6c064360ba2c5b846363280a3fe6f1232fa1dc4372a269c171', 'bytes': 6080, 'mode': 384}, {'path': '/tmp/g350-source32-three-stage-root-20261015-after66/core/POSTAUDIT.json', 'sha256': 'ce1117a8b3b39f95f5169239454025be3c68150ab78787b791d91448d702865e', 'bytes': 8049, 'mode': 384}]
ACTUAL69_PHASE_POST_BINDINGS=[{'path': '/tmp/g350-source32-api-root-20261015-after68/projection/POSTAUDIT.json', 'sha256': 'd5f92df539b28e373088ea5ec048bb21a29bc929d1b6c4bc9d5b70a33644f506', 'bytes': 9914, 'mode': 384}, {'path': '/tmp/g350-source32-api-root-20261015-after68/api/POSTAUDIT.json', 'sha256': 'cdefba0dd764ec1d6b4c025670eea6da9922282eb91002806cf56f8c756f6f0c', 'bytes': 8993, 'mode': 384}]

def require(value,message):
    if not value:raise ValueError(message)

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def checked(row,path=None):
    original=Path(row['path']);p=Path(path) if path is not None else original
    require(p.is_absolute()and p.resolve()==p,'Exact absolute path without symlink ancestors')
    q=p.lstat();require(stat.S_ISREG(q.st_mode)and not p.is_symlink(),'Regular nonsymlink snapshot file')
    require(q.st_size==row['bytes']and stat.S_IMODE(q.st_mode)==row['mode']and digest(p)==row['sha256'],'Byte/size/mode-identical original or snapshot')
    return p

def load(row):return json.loads(checked(row).read_bytes())

def tmp_root(path):
    p=Path(path);require(len(p.parts)>=3 and p.parts[1]=='tmp','Finite /tmp child path')
    if len(p.parts)==3:
        require(str(p)in FLAT_TMP_FILE_BINDINGS,'Only exact pinned direct-/tmp regular files may be mount roots')
    return Path('/tmp')/p.parts[2]

def validate_snapshot_plan(plan):
    CAD_PARENT=Path(plan['newCadAuthority']['path']).parent
    require(CAD_PARENT.parent==Path('/tmp')and re.fullmatch(CAD_PARENT_PREFIX+'[A-Za-z0-9_-]+',CAD_PARENT.name)is not None and CAD_PARENT.resolve()==CAD_PARENT,'Exact owned temporary CAD run parent')
    source=plan['runtimeSourceManifest']
    require(source=={'path': '/tmp/g350-source32-cli70-no-historical-private-prerequisites-runtime-successor-sourceonly-next/SOURCE-manifest.json', 'sha256': '66ab647ebed4f4c754afbfdcd2da87c02b21e7aef34a474840ccfb6022c15764', 'bytes': 29373, 'mode': 384},'Exact reviewed final CoreCalls-corrected runtime manifest')
    runtime=load(source)
    require(re.fullmatch('[0-9a-f]{64}',source['sha256'])is not None,'Reviewed exact runtime source pin')
    require(source['path'].startswith('/tmp/g350-source32-')and Path(source['path']).name=='SOURCE-manifest.json','Explicit Source32 runtime manifest')
    cli=load(plan['actualClosedCliCollection']);require(cli['authorizedByRoot']is True and cli['toolSessionCollected']is True and cli['passed']is True and cli['toolExitCode']==cli['toolWrapperExitCode']==0,'Actual collected CLI43 prerequisite')
    post=load(plan['actualCliPostaudit']);require(cli['postauditPath']==plan['actualCliPostaudit']['path']and cli['postauditSha256']==plan['actualCliPostaudit']['sha256']and cli['execution']==post['execution'],'Exact collected CLI postaudit')
    e=post['execution'];require(e['exitCode']==0 and e['cleanupOwnedGroupEmpty']is True and e['diagnosticStopped']is False and not any(e['oomDelta'].values())and cli['sourceAndDependenciesHeld']is post['sourceAndDependenciesHeld']is True,'Actual CLI natural0/groupempty/OOM0/sourceheld')
    require(cli['sourceManifestSha256']==post['sourceManifestSha256']==source['sha256'],'Same reviewed runtime packet')
    cli_root=tmp_root(plan['actualCliPostaudit']['path']);require(cli_root.name.startswith('g350-source32-cli-root-'),'Only actual collected CLI root may be mounted')
    report=load(plan['actualCliReport']);require(report['exportPassed']is True and report['cliExitCode']==0 and report['sourceManifestSha256']==source['sha256'],'Actual pinned CLI export')
    require(report['outputPath']==plan['actualExport']['path']and report['outputSha256']==plan['actualExport']['sha256'],'Exact actual export binding')
    for row in (plan['actualCliReport'],plan['actualExport']):
        checked(row);require(tmp_root(row['path'])==cli_root and any(r['path']==row['path']and r['sha256']==row['sha256']for r in post['outputFiles']),'Only actually produced CLI artifacts')
    for key,name in [('newCadAuthority','ROOT_CAD_AUTHORITY.json'),('actualSourceZonePins','SOURCE_ZONE_PINS.json')]:
        checked(plan[key]);require(Path(plan[key]['path'])==CAD_PARENT/name,'Fresh CAD-only owned temporary authority/zone pins; never copy old authority/BOUND')
    snapshot_root=Path(plan['snapshotRoot']);require(snapshot_root.parent==CAD_PARENT/'snapshots'and re.fullmatch('[0-9a-f]{32}',snapshot_root.name)is not None and snapshot_root.resolve()==snapshot_root,'Owned finite temporary snapshot root')
    required=[*runtime['files'],*runtime['externalFiles'],source,plan['actualCliPostaudit'],plan['actualCliReport'],plan['actualExport'],*ACTUAL67_PHASE_POST_BINDINGS,*ACTUAL69_PHASE_POST_BINDINGS]
    rows={}
    for row in required:
        if not row['path'].startswith('/tmp/'):continue
        require(row['path']not in rows or rows[row['path']]==row,'No conflicting original bindings')
        rows[row['path']]=row
    forbidden={'ROOT_AUTHORITY.json', 'API-BOUND.json', 'BOUND_MANIFEST.json', 'BOUND.json', 'BOUND-manifest.json', 'PROJECTION-BOUND.json', 'ROOT_CAD_AUTHORITY.json', 'API_ROOT_AUTHORITY.json'}
    require(not any(Path(p).name in forbidden for p in rows),'Historical authority and BOUND files excluded from snapshots')
    declared=plan['snapshots'];require(len(declared)==len(rows),'Exact sparse allowlist, no unbound copied files')
    original_paths={r['originalPath']for r in declared};require(len(original_paths)==len(declared)and original_paths==set(rows),'Every required original /tmp file exactly once')
    roots={};copies=set()
    for mapping in declared:
        original=Path(mapping['originalPath']);root=tmp_root(original);target=snapshot_root/root.name;copy=target/original.relative_to(root)
        if original==root:
            require(rows[str(original)]==FLAT_TMP_FILE_BINDINGS[str(original)],'Exact direct-/tmp runtime file binding required')
        require(mapping['snapshotPath']==str(copy),'Preserved exact relative artifact path')
        checked(rows[str(original)]);checked(rows[str(original)],copy);copies.add(copy);roots[root]=target
    observed=set()
    for original,target in roots.items():
        if str(original)in FLAT_TMP_FILE_BINDINGS:
            checked(FLAT_TMP_FILE_BINDINGS[str(original)],target)
            observed.add(target)
            continue
        require(target.is_dir()and target.resolve()==target,'Exact snapshot mount source')
        for p in target.rglob('*'):
            require(not p.is_symlink(),'No snapshot symlinks')
            if p.is_file():observed.add(p)
            else:require(p.is_dir(),'No special snapshot entries')
    require(observed==copies,'Sparse snapshot directory contains only exact allowlisted files')
    mounts=[]
    for original,target in sorted(roots.items(),key=lambda item:str(item[0])):
        require(all(re.fullmatch('[A-Za-z0-9_./-]+',str(p))is not None for p in (original,target)),'Safe exact Docker mount paths')
        mounts += ['--mount','type=bind,source='+str(target)+',target='+str(original)+',readonly']
    for key in ('newCadAuthority','actualSourceZonePins'):
        current=checked(plan[key])
        require(all(re.fullmatch('[A-Za-z0-9_./-]+',str(p))is not None for p in (current,)),'Safe exact current CAD file mount')
        mounts += ['--mount','type=bind,source='+str(current)+',target='+str(current)+',readonly']
    return mounts

def main():
    require(len(sys.argv)==3,'Bound snapshot-plan path and sha required')
    p=Path(sys.argv[1]);require(p.is_absolute()and p.resolve()==p and re.fullmatch('[0-9a-f]{64}',sys.argv[2])is not None and digest(p)==sys.argv[2],'Exact Root-reviewed snapshot plan')
    args=validate_snapshot_plan(json.loads(p.read_bytes()))
    sys.stdout.buffer.write(b'\0'.join(a.encode()for a in args)+b'\0')

if __name__=='__main__':main()
