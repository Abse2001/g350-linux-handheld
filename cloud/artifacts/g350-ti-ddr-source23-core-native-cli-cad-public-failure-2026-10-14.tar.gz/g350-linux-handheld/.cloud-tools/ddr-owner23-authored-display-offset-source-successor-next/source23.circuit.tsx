import { Children, cloneElement, createElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { buildOwnerMoved22Source, registerOwnerMoved22InnerPorts } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-owner22-child-clear-source-successor-next/source22.circuit"
import proposal from "./source23-proposal.json"
type Props = Record<string, unknown> & { name?: string; children?: ReactNode }
const routeFields = ["pcbPath", "pcbPaths", "pcbPathRelativeTo"] as const
const canonical = (value: unknown): string => Array.isArray(value) ? `[${value.map(canonical).join(",")}]`
  : value && typeof value === "object" ? `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonical((value as Record<string,unknown>)[key])}`).join(",")}}` : JSON.stringify(value) ?? "undefined"
const mm = (value: unknown): number => {
  if (typeof value === "number" && Number.isFinite(value)) return value
  if (typeof value === "string" && /^-?\d+(?:\.\d+)?mm$/.test(value)) return Number(value.slice(0,-2))
  throw Error("A finite genuine millimeter placement is required")
}

/** Source22 stays immutable. Only two original route declarations, two local
 * suppressions and four real Port children differ in this Source23 fork. */
export function buildOwnerMoved23Source() {
  const base = buildOwnerMoved22Source()
  const originals = new Set<string>(), locals = new Set<string>(), ports = new Set<string>()
  let boards = 0
  function fork(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const props: Props = { ...node.props }
    let children = Children.toArray(props.children).map(fork)
    const requestedPort = proposal.newFourInnerLayerPorts.find(row => row.viaName === props.name)
    if (requestedPort) {
      if (node.type !== "via" || children.length !== 0 || props.fromLayer !== "top" || props.toLayer !== "bottom"
        || mm(props.outerDiameter) !== .4572 || mm(props.holeDiameter) !== .254
        || Math.abs(mm(props.pcbX)-requestedPort.viaXY.x)>1e-9 || Math.abs(mm(props.pcbY)-requestedPort.viaXY.y)>1e-9
        || ports.has(requestedPort.viaName)) throw Error("One existing full-span owner must receive its genuine inner Port")
      children.push(createElement("port",{name:requestedPort.layer,layer:requestedPort.layer}))
      ports.add(requestedPort.viaName)
    }
    const change = proposal.twoOriginalCarrierChanges.find(row => row.logicalName === props.name)
    if (change) {
      const carrier=change.afterCarrier, old=change.beforeCarrier
      if (node.type!=="trace" || originals.has(carrier.originalSourceTraceId) || props.from!==carrier.from || props.to!==carrier.to
        || props.path!==undefined || props.pcbPath!==undefined
        || canonical(props.pcbPaths)!==canonical(old?.newPcbPaths) || props.pcbPathRelativeTo!==old?.newPcbPathRelativeTo)
        throw Error("Exact parent22 original numeric route declaration required")
      for (const field of routeFields) props[field]=undefined
      props.pcbPaths=carrier.newPcbPaths;props.pcbPathRelativeTo=carrier.newPcbPathRelativeTo
      originals.add(carrier.originalSourceTraceId)
    }
    const local=proposal.all98NumericOwnedSignalBranches.find(row=>row.originalSourceTraceId==="source_trace_4"&&row.traceName===props.name)
    if(local){
      if(node.type!=="trace" || locals.has(local.traceName) || props.from!==local.numericSelector || props.to!==`.${local.viaName} > port.top`
        || mm(props.thickness)!==.1016 || props.pcbPathRelativeTo!==`.${local.viaName} > port.top`
        || props.pcbPaths!==undefined || canonical(props.pcbPath)!=="[]") throw Error("Exact original Source4 Top local declaration required")
      props.pcbPath=undefined;locals.add(local.traceName)
    }
    if(node.type==="board"){
      boards++
      if(props.layers!==4 || props.routeRemaining!==false || (props.pcbX??0)!==0 || (props.pcbY??0)!==0 || (props.pcbRotation??0)!==0)
        throw Error("Existing manual unrotated four-layer board required")
    }
    return cloneElement(node as ReactElement<Props>,props,...children)
  }
  const element=fork(base.element)
  if(boards!==1 || originals.size!==2 || locals.size!==2 || ports.size!==4)throw Error("Exact narrow Source23 declaration delta required")
  return {...base,element,ownerMoved23Proposal:proposal,ownerMoved23SourceIntegration:{
    scope:"UNEXECUTED_SOURCE23_SUCCESSOR_OF_UNRUN_SOURCE22",parent22ActualAcceptanceInherited:false,
    changedOriginalTraces:[...originals],changedLocalTraces:[...locals],newRealPortParents:[...ports],
    expectedCounts:proposal.expectedCounts,newBarrelsAdded:false,newResetDeclarationsAppended:false,
    circuitJsonInjectionOrIdAssignment:false,sourceExecuted:false,coreRendered:false,nativeExecuted:false,cadExecuted:false,
    automaticCoreSrjForManualPairBusForkMustNotBeUsed:true,all49Accepted:false,referenceQualified:false,electricalTimingPassed:false,fabricationReady:false,
  }}
}

type Via={componentName:string;props:Props;pcb_via_id?:string|null;source_manually_placed_via_id?:string|null}
type Port={componentName:string;props:Props;parent:unknown;matchedComponents:unknown[];source_port_id?:string|null;pcb_port_id?:string|null;registerMatch(component:unknown):void;getAvailablePcbLayers():string[]}
type Circuit={_hasRenderedAtleastOnce?:boolean;schematicDisabled?:boolean;selectOne(selector:string,options?:{type?:string}):unknown}
/** All36 actual public Port/Via matches happen before the first real render.
 * The immutable Source22 hook handles its32 held ports; four are new here. */
export function registerOwnerMoved23InnerPorts(circuitUnknown:unknown){
  const circuit=circuitUnknown as Circuit
  if(circuit._hasRenderedAtleastOnce || circuit.schematicDisabled!==true)throw Error("Unrendered actual PCB-only Circuit required")
  const prior=registerOwnerMoved22InnerPorts(circuitUnknown)
  if(prior.registrations.length!==32)throw Error("Exact held32 actual parent ports required")
  const registrations=[...prior.registrations]
  for(const requested of proposal.newFourInnerLayerPorts){
    const via=circuit.selectOne(`.${requested.viaName}`) as Via|null
    const port=circuit.selectOne(`.${requested.viaName} > port.${requested.layer}`,{type:"port"}) as Port|null
    if(!via || via.componentName!=="Via" || via.props.name!==requested.viaName || via.props.fromLayer!=="top" || via.props.toLayer!=="bottom"
      || mm(via.props.outerDiameter)!==.4572 || mm(via.props.holeDiameter)!==.254
      || Math.abs(mm(via.props.pcbX)-requested.viaXY.x)>1e-9 || Math.abs(mm(via.props.pcbY)-requested.viaXY.y)>1e-9
      || !port || port.componentName!=="Port" || port.parent!==via || port.props.name!==requested.layer || port.props.layer!==requested.layer
      || port.source_port_id || port.pcb_port_id || via.pcb_via_id || via.source_manually_placed_via_id
      || port.getAvailablePcbLayers().join(",")!==requested.layer || port.matchedComponents.some(owner=>owner!==via))
      throw Error("One genuine unrendered inner Port and its existing declared full-span Via required")
    if(!port.matchedComponents.includes(via))port.registerMatch(via)
    if(port.matchedComponents.length!==1 || port.matchedComponents[0]!==via)throw Error("Exact public owner registration required")
    registrations.push({viaName:requested.viaName,layer:requested.layer,xy:requested.viaXY,numericSelector:requested.numericSelector})
  }
  if(registrations.length!==36 || new Set(registrations.map(row=>`${row.viaName}:${row.layer}`)).size!==36)
    throw Error("Exactly36 unique actual inner registrations required")
  return {registrations,extraPhysicalViaFromPortRegistration:false,coreRendered:false,nativeExecuted:false}
}
export default()=>buildOwnerMoved23Source().element
