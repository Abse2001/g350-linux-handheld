from pathlib import Path
import argparse, hashlib, importlib.util, json, re, stat, sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
STRICT = ROOT.parent/'g350-ti-v12e-c-clock-native-port-corrective-sourceonly-next'
POLICY = {'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
RESERVE = 2*1024**3
BUN = '/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path); loaded=importlib.util.module_from_spec(spec); spec.loader.exec_module(loaded); return loaded
def verify():
    raw=(ROOT/'SOURCE-manifest.json').read_bytes(); packet=json.loads(raw)
    for row in packet['files']+packet['externalFiles']:
        path=Path(row['path']); assert path.is_file() and not path.is_symlink()
        assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes'] and stat.S_IMODE(path.stat().st_mode)==row['mode'],str(path)
    strict=module('immutable_strict_native_source_verifier',STRICT/'guard.py')
    held,held_sha,prior,scope=strict.verify()
    assert held_sha==packet['strictGatePacketSha256']=='ddb8666b063c07cfe1b924931841202ee6c79c960d9b529c98e5a59d6a6ba165'
    assert held['frozenSourcePacketSha256']==packet['frozenSourcePacketSha256']=='502fef728b73688547f98b3455fc91fab2d068bf15d0d3730b246c3c055cd184'
    assert held['inputSha256']==packet['inputSha256'] and held['coreSha256']==packet['coreSha256']
    assert held['jointGeometrySha256']==packet['jointGeometrySha256'] and held['clockResultSha256']==packet['clockResultSha256']
    return packet,hashlib.sha256(raw).hexdigest(),prior,scope
def strict_failure(auth,packet,scope):
    assert auth['strictGateExpectedFailureCollected'] is True
    for name,path in [('strictGateResult',packet['strictGateResultPath']),('strictGatePostaudit',packet['strictGatePostauditPath']),('strictGateRootCollected',auth['strictGateRootCollectedPath'])]:
        assert sha(path)==auth[name+'Sha256']
    result=json.loads(Path(packet['strictGateResultPath']).read_bytes())
    post=json.loads(Path(packet['strictGatePostauditPath']).read_bytes())
    collected=json.loads(Path(auth['strictGateRootCollectedPath']).read_bytes())
    assert collected['sessionId']==auth['strictGateToolSessionId'] and collected['toolExitCode']==2
    assert collected['sourceAndDependenciesHeld'] is True and collected['postauditSha256']==auth['strictGatePostauditSha256']
    assert post['packetSha256']==packet['strictGatePacketSha256'] and post['resultSha256']==auth['strictGateResultSha256']
    assert post['strictFailureRecorded'] is True and post['nativeStrictZeroPassed'] is False
    assert post['sourceAndArtifactsHeld'] is True and post['dependenciesBefore']==post['dependenciesAfter']
    execution=post['execution']; assert execution==collected['execution']
    assert execution['exitCode']==1 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty']
    assert not any(execution['oomDelta'].values()) and not scope.owned(execution['pgid'])
    assert result['qualified'] is False and result['strictZeroPassed'] is False and result['variantAComparisonHeld'] is True
    assert result['noGridImportsOrCalls'] is True and result['sourceAndPhysicalGeometryHeld'] is True
    positive=[row for row in result['reports'] if row['variant']=='native-49-plus-two-owned-references']
    assert len(positive)==3
    for row in positive:
        assert len(row['report']['issues'])==2 and all(issue['code']=='via-at-endpoint' for issue in row['report']['issues'])
    return result
def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--preflight-only',action='store_true'); parser.add_argument('--run',action='store_true'); parser.add_argument('--root-receipt'); parser.add_argument('--root-receipt-sha256'); args=parser.parse_args()
    packet,packet_sha,prior,scope=verify()
    if args.preflight_only:
        print(json.dumps({'preflightPassed':True,'packetSha256':packet_sha,'workerStarted':False,'futureStrictFailureReceiptStillRequiredForRun':True})); return 0
    assert args.run and args.root_receipt and args.root_receipt_sha256
    auth=json.loads(Path(args.root_receipt).read_bytes())
    assert sha(args.root_receipt)==args.root_receipt_sha256 and auth['authorizedByRoot'] is True
    assert auth['scope']==packet['scope'] and auth['packetSha256']==packet_sha and auth['policy']==POLICY
    assert auth['interveningWorkersClosed'] is True and re.fullmatch('[0-9a-f]{32,128}',auth['approvalToken'])
    strict_failure(auth,packet,scope)
    out=ROOT/'run'; assert not out.exists()
    before=prior.dependencies(); baseline=scope.memory()
    def gate(now):
        assert now['current']+POLICY['rssBytes']+RESERVE<POLICY['sharedBytes'],'Strict prefork reserve required'
        assert all(now['events'][key]==baseline['events'][key] for key in scope.OOM_KEYS)
    execution=scope.run_guarded([BUN,'--smol',str(ROOT/'qualify.ts')],ROOT,out,POLICY,
        {'G350_OWNED_VIA_NATIVE_APPROVED':'1','G350_OWNED_VIA_NATIVE_AUTH_PATH':str(Path(args.root_receipt).resolve()),'G350_OWNED_VIA_NATIVE_AUTH_SHA':args.root_receipt_sha256},before_spawn=gate)
    verify(); strict_failure(auth,packet,scope); after=prior.dependencies(); assert before==after
    result_path=out/'result.json'; result=json.loads(result_path.read_bytes()) if result_path.is_file() else None
    stage1_path=out/'stage1-controls.json'
    clean=execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values())
    valid=bool(clean and result and result['qualified'] is True and result['nativeStrictZeroPassed'] is True
        and result['stage1NativeCalls']==15 and result['stage2NativeCalls']==3 and result['nativeCalls']==18
        and result['stage1Qualified'] is True and result['noGridImportsOrCalls'] is True
        and result['sourceAndPhysicalGeometryHeld'] is True and stage1_path.is_file()
        and result['stage1ControlsSha256']==sha(stage1_path))
    if result:
        for row in result['reports']: assert json.loads((out/(row['label']+'.native.json')).read_bytes())==row
        if valid: assert len(result['reports'])==3 and all(row['report']['valid'] and not row['report']['issues'] for row in result['reports'])
    receipt={'execution':execution,'dependenciesBefore':before,'dependenciesAfter':after,'sourceAndArtifactsHeld':True,
        'packetSha256':packet_sha,'resultSha256':sha(result_path) if result else None,
        'stage1ControlsSha256':sha(stage1_path) if stage1_path.is_file() else None,
        'diagnosticTrustEligible':valid,'nativeStrictZeroPassed':valid,'strictFailurePreserved':True,
        'accepted49':False,'fabricationReady':False}
    (ROOT/'EXECUTION-postaudit.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'nativeStrictZeroPassed':valid,'resultSha256':receipt['resultSha256'],'accepted49':False})); return 0 if valid else 2
if __name__=='__main__': raise SystemExit(main())
