#!/usr/bin/env python3
"""Prepare a NEW post252 model49 evidence checkpoint using own stdlib only.

Source-only handoff: author has not run this collector. Root must review it and
wait for the separate fresh Source/Core qualification before authorizing its
execution. This initial version saves CLOSED253 only. It deliberately cannot
freeze or claim the forthcoming Source254+ or native/auth/pour outcomes.
Frozen post232 and every prior saved directory/archive are read-only inputs.
"""
import argparse
import copy
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import stat

ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post252-2026-10-16'
BASE = ROOT / '.cloud-tools/ddr-four-layer-post232-2026-10-16'
BASE_PINS = {
    'PROGRESS.json': '72f8c492337c2c4097aff00a1db03738c385a765b908b69c523111ef87ec0a5e',
    'WORKSPACE_HASH_INDEX.json': '7ef3325aa7cfa1a82c4e80f760c0a06b6d5790d5f7fcf232f7831b198e75c601',
    'WORKSPACE_RESTORE_MANIFEST.json': '54513dea6b5fea2d4cada7187f115ba10ce8ff43f3afd7f20b506fb9cb5614ef',
    'README.md': 'a7e9ed921e0d682d2aa7ffea82902788922f9b1597173a9548959be69fcbef5e',
}
BASE_MANIFEST = ROOT / 'cloud/artifacts/g350-four-layer-partial48-source248-2026-10-16.manifest.json'
BASE_MANIFEST_SHA = 'a30bfbd25e88a0aa19269c6946a2f33b7683ab4421d99046a85bb8e7cb49e600'
BASE_ARCHIVE_SHA = 'e5d10d729ee0fc7fed74fdafbcb169a4f78083645d81064130dc30c2809d9e24'
RUN = Path('/tmp/g350-cpu-cycle-manual49-root-20261016-run253')
CURRENT = RUN / 'byte0-result.candidate.json'
CURRENT_SHA = 'f76709a0c4cf1a19920b1e9361e7d5f994ee1671f975836f88d775e17651df87'
REPORT = RUN / 'byte0-result.json'
REPORT_SHA = 'ec0018e7b103a91639e67fa6938c875b58942845b41f93c35a35cc1384736348'
WORKER = Path('/tmp/g350-current243-cpu-cycle-manual49-cap8-two-planned-PDN-v4-sourceonly.ts')
WORKER_SHA = 'fd5f61a5593e77a3e669248c1266063c3113f3c427694023a953995ab6e05290'
DESCRIPTOR = Path('/tmp/g350-current243-cap8-two-declared-pdn-nodes-Vdd72-descriptor-v2-sourceonly.json')
DESCRIPTOR_SHA = '20e698e6225f7aa0759aa4acf70103c5f90f3894ae94726336e098598b3f3976'
ANCHOR = Path('/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json')
ANCHOR_SHA = 'cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
PINS = {
    str(CURRENT): CURRENT_SHA, str(REPORT): REPORT_SHA,
    str(WORKER): WORKER_SHA, str(DESCRIPTOR): DESCRIPTOR_SHA,
    str(ANCHOR): ANCHOR_SHA,
    str(RUN / 'COLLECTED.json'): 'd6c97ed14f32d0acc5167339aad3b0efd90afabfbb1f705394805de1b500eaa4',
    str(RUN / 'owned/execution.json'): '24f87512c4d912b1022346de9a78dc22c010b89e967985e7b78531b4db5f9974',
    str(RUN / 'owned/child.log'): '6f89d1f4155b7777ddc1550b154a801c223b0d2400723482dfc24effc5cbefa3',
    str(RUN / 'owned/memory.jsonl'): '4ff46023d2d8e67eb5f82eda8cff629dc826a6a786bf2a2bcbb0d562ad501e78',
}
DENIED = ('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT', 'AUTHORITY_PACKET')
FALSE_FLAGS = ('matched', 'timingPassed', 'electricalTimingQualified', 'freshSource',
               'freshSourceCoreDerived', 'nativeExecuted', 'cadExecuted', 'all49Accepted', 'fabricationReady')
EXPECTED_OWNERS = {'source_trace_' + str(i) for i in range(49)}


def require(value, message):
    if not value:
        raise ValueError(message)


def drop(fd):
    if hasattr(os, 'posix_fadvise'):
        os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
        drop(stream.fileno())
    return h.hexdigest()


def read(p):
    with p.open('rb') as stream:
        value = json.load(stream)
        drop(stream.fileno())
    return value


def regular(p):
    return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)


def safe_public(p):
    return (p.is_absolute() and str(p).startswith('/tmp/g350-')
            and p.resolve().is_relative_to('/tmp')
            and not any(term in str(p).upper() for term in DENIED))


def metadata(p):
    s = p.stat()
    return {'bytes': s.st_size, 'sha256': digest(p), 'mode': stat.S_IMODE(s.st_mode)}


def verify_rows(folder, rows):
    seen = set()
    for row in rows:
        relative = Path(row['path'])
        p = folder / relative
        require(row['path'] not in seen and not relative.is_absolute() and '..' not in relative.parts
                and p.resolve().is_relative_to(folder.resolve()) and regular(p)
                and metadata(p) == {k: row[k] for k in ('bytes', 'sha256', 'mode')},
                'Frozen payload bytes/mode changed: ' + str(p))
        seen.add(row['path'])


def verify_base():
    require(BASE.is_dir() and not BASE.is_symlink(), 'Read-only frozen Source248 dependency')
    for name, pin in BASE_PINS.items():
        require(regular(BASE / name) and digest(BASE / name) == pin, 'Frozen post232 metadata changed')
    index = read(BASE / 'WORKSPACE_HASH_INDEX.json')
    require(index['frozenCheckpoint'] is True and len(index['files']) == 193,
            'Exact frozen closed252+all14+plot Source248 inventory')
    verify_rows(BASE, index['files'])
    require(regular(BASE_MANIFEST) and digest(BASE_MANIFEST) == BASE_MANIFEST_SHA,
            'Exact frozen Source248 archive manifest')
    archive = read(BASE_MANIFEST)['archive']
    ap = ROOT / archive['path']
    require(not Path(archive['path']).is_absolute() and '..' not in Path(archive['path']).parts
            and ap.resolve().is_relative_to(ROOT.resolve()) and regular(ap)
            and archive['sha256'] == BASE_ARCHIVE_SHA and archive['bytes'] == 11222356
            and ap.stat().st_size == archive['bytes'] and digest(ap) == BASE_ARCHIVE_SHA,
            'Frozen Source248 archive bytes unchanged; never copied by collector')


def owner(t):
    return t.get('connection_name') or t.get('source_trace_id')


def exact_roster(rows, expected, message):
    actual = [owner(t) for t in rows]
    require(len(actual) == len(expected) and len(set(actual)) == len(actual) and set(actual) == expected, message)


def verify_model():
    c, r, d, anchor = read(CURRENT), read(REPORT), read(DESCRIPTOR), read(ANCHOR)
    closed, execution = read(RUN / 'COLLECTED.json'), read(RUN / 'owned/execution.json')
    require(closed['scope'] == 253 and closed.get('closedAt') and closed['execution'] == execution
            and closed['sourcePinsUnchanged'] is True and closed['protectedFilesUnchanged'] is True
            and execution['exitCode'] == 0 and execution['cleanupOwnedGroupEmpty'] is True
            and execution['diagnosticStopped'] is False and not execution['stopReasons']
            and execution['command'][1] == str(WORKER) and closed['all49Accepted'] is False,
            'Exact CLOSED253 physical-only receipt')
    for packet in (r, c):
        require(packet['all49Connected'] is True and packet['allSavedCarriersCurrentSceneQualified'] is True
                and packet['beforeCurrent48Qualified'] is True
                and all(packet[k] is False for k in FALSE_FLAGS), '49 connected model, all qualification boundaries retained')
        exact_roster(packet['finalScenePhysicalReports'], EXPECTED_OWNERS, 'All49 unique current-scene physical reports')
        require(all(q['passed'] is True for q in packet['finalScenePhysicalReports'])
                and len(packet['changedJoinedSignalPhysicalReports']) == 4
                and all(q['passed'] is True for q in packet['changedJoinedSignalPhysicalReports'])
                and len(packet['criticalValidationViews']) == 2
                and all(q['passed'] is True and q['c31']['solved'] is True
                        and set(q['reports']) == {'bus', 'pair', 'shared', 'coupling', 'exterior'}
                        and all(len(rows) == 3 and all(v['matched'] is True for v in rows)
                                for rows in q['reports'].values()) for q in packet['criticalValidationViews'])
                and all(len(packet[key]) == 2 and all(v['passed'] is True for v in packet[key])
                        for key in ('powerReferencePhysicalReports', 'movedCap8PadFixedCopperPreflight',
                                    'plannedPdnViaPhysicalReports')),
                'Fresh49/4joins/2criticalviews/2references/2pads/2plannedPDN gates')
    require(r['connectedCount'] == 49 and r['remaining'] == [] and c['missingOwnerIds'] == []
            and c['planningOnly'] is False and c['sourceCapPlacementStillPending'] is True
            and c['actualPdnPlaneGraphQualificationPending'] is True and c['futureNewPdnFreshIds'] is None
            and c['dormantWorkingBarrels'] == [] and c['workingBarrelPhysicalJoinAudit']['passed'] is True,
            'Complete model only; fresh Source placement/PDN graph explicitly pending')
    exact_roster(c['carrierTraces'], EXPECTED_OWNERS, 'Literal49 carrier roster')
    exact_roster(c['joinedNumericPadTraces'], EXPECTED_OWNERS, 'Literal49 numeric joined roster')
    require(len(c['heldCarrierTraces']) == 6 and len(c['ordinaryCarrierTraces']) == 43
            and c['heldCarrierTraces'] == anchor['heldCarrierTraces']
            and len(c['full49FanoutInput']['connections']) == 49
            and len(c['full49FanoutInput']['traces']) == 263
            and len(c['full49FanoutInput']['obstacles']) == 1300
            and all(c['full49FanoutInput'][k] == anchor['full49FanoutInput'][k]
                    for k in ('buses', 'differentialPairs')), 'Exact original49 rules, six held bodies and declared263/1300 foundation')
    require(c['inputBindings'] == r['inputBindings'] and c['cap8PlacementInverse'] == r['cap8PlacementInverse'] == d
            and c['requiredSourceHardwarePlacementDeltas'] == [anchor['cap12PlacementInverse'], d]
            and c['cap8PdnInsertions'] == d['cap8PdnInsertions'] and len(d['cap8PdnInsertions']) == 2
            and c['sourceReferenceTargetInverses'] == d['sourceReferenceTargetInverses']
            and len(c['sourceReferenceTargetInverses']) == 2, 'Complete cap12+cap8/PDN plural descriptor and reference targets')
    delta = r['constructorFoundationDelta']
    require(delta['sourcePacketSha256'] == ANCHOR_SHA and delta['exactExpectedEqualityPassed'] is True
            and delta['finalPhysicalObstacles'] == 1300 and delta['plannedNewFullspanPdnNodes'] == 2
            and delta['futureNewPdnFreshIds'] is None and delta['cpuBranchesChanged'] == ['source_trace_2', 'source_trace_11']
            and delta['bodyOwnersChanged'] == ['source_trace_2', 'source_trace_11', 'source_trace_35', 'source_trace_42']
            and delta['referenceTracesChanged'] == ['pcb_trace_156', 'pcb_trace_157']
            and delta['other163ReferencesLiteral'] is True and delta['critical169SixLiteral'] is True,
            'Latest253 delta comes from exact report, not candidate inherited stale constructorFoundationDelta')
    require(c['workingChanges'][-1]['cpuFanoutInverses'] == r['cpuFanoutInverses']
            and c['workingChanges'][-1]['d12EndpointInverses'] == r['d12EndpointInverses']
            and c['workingChanges'][-1]['bodyInverses'] == r['bodyInverses'], 'Latest CPU/D12/body inverse ledger exact')
    observations = r['originalBusConstraintObservations']
    require([o['originalRule'] for o in observations] == c['full49FanoutInput']['buses']
            and all(o['allMembersPresent'] is True and o['missingOwners'] == [] for o in observations)
            and sum(any(v['kind'] == 'ORIGINAL_MAX_LENGTH_SKEW' for v in o['violations']) for o in observations) == 3,
            'All49 literal constraints measured; exactly three failing bus skews retained')
    wanted = {'DDR_BYTE0': 6.655202281574553, 'DDR_BYTE1': 2.4000719198310776,
              'DDR_COMMAND_CLOCK': 17.43870093419864}
    for o in observations:
        bus = o['originalRule']['busId']
        if bus in wanted:
            require(math.isfinite(o['observedSkewMm']) and abs(o['observedSkewMm'] - wanted[bus]) <= 1e-10,
                    'Exact253 original bus skew observation')
    require(len(r['originalPairConstraintObservations']) == 3
            and all(o['lengthToleranceSatisfied'] is True and o['missingOwners'] == []
                    for o in r['originalPairConstraintObservations']), 'Original three pair length observations pass independently')
    return c, r, d, closed, execution


def write_json(p, value):
    with p.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        os.fchmod(stream.fileno(), 0o600)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile', default='/tmp/g350-post252-run253-checkpoint-profile-sourceonly.json')
    parser.add_argument('--profile-sha', required=True)
    args = parser.parse_args()
    profile_path = Path(args.profile)
    require(safe_public(profile_path) and regular(profile_path)
            and re.fullmatch('[0-9a-f]{64}', args.profile_sha) and digest(profile_path) == args.profile_sha,
            'Explicit reviewed profile path and exact byte SHA required')
    profile = read(profile_path)
    require(profile['scope'] == 'POST252_RUN253_MODEL49_PHYSICAL_ONLY_SOURCE_PROFILE'
            and profile['candidateSha256'] == CURRENT_SHA and profile['reportSha256'] == REPORT_SHA
            and profile['freshSourceCorePending'] is True and profile['nativePending'] is True
            and profile['authenticatedViaTrackPending'] is True and profile['literalPoursPending'] is True,
            'Initial profile is model-only; fresh qualification belongs to later reviewed collector')
    require(not SAVED.exists(), 'New post252 folder must be absent; later append needs separate reviewed Source')
    verify_base()
    all_pins = dict(PINS)
    for row in profile['artifacts']:
        p, pin = Path(row['path']), row['sha256']
        require(safe_public(p) and regular(p) and re.fullmatch('[0-9a-f]{64}', pin)
                and (str(p) not in all_pins or all_pins[str(p)] == pin)
                and metadata(p) == {k: row[k] for k in ('bytes', 'sha256', 'mode')},
                'Explicit public profile artifact byte/hash/mode pin')
        all_pins[str(p)] = pin
    for name, pin in all_pins.items():
        require(safe_public(Path(name)) and regular(Path(name)) and digest(Path(name)) == pin,
                'Exact public model253 artifact: ' + name)
    candidate, report, descriptor, closure, execution = verify_model()
    base_progress, base_restore = read(BASE / 'PROGRESS.json'), read(BASE / 'WORKSPACE_RESTORE_MANIFEST.json')
    require(base_progress['frozenCheckpoint'] is True and base_progress['latestClosedScopeIncluded'] == 252
            and base_progress['latestSourceVerifiedCheckpoint']['routedOwners'] == 48,
            'Frozen Source24848 fallback preserved, including failed247 closure')
    catalog = {r['restorePath']: copy.deepcopy(r) for r in base_restore['baseDependencyRestoreFiles']}
    for r in base_restore['files']:
        catalog[r['restorePath']] = {'baseSavedDirectory': BASE.relative_to(ROOT).as_posix(), **copy.deepcopy(r)}
    targets, bases, inputs, sources = {}, {}, {}, set()
    SAVED.mkdir(parents=True, exist_ok=False)

    def save(p, name=None, force=False):
        p = Path(p)
        require(safe_public(p) and regular(p), 'Only regular public /tmp inputs')
        before, data = p.stat(), metadata(p)
        inputs[str(p)] = data
        if str(p) in targets:
            require(data == {k: targets[str(p)][k] for k in data}, 'Collected restore target changed')
            return targets[str(p)]
        base_row = catalog.get(str(p))
        if not force and base_row and data == {k: base_row[k] for k in data}:
            bases[str(p)] = copy.deepcopy(base_row)
            return {'baseDependencyOnly': True, **copy.deepcopy(base_row)}
        dest = SAVED / (name or p.name)
        require(dest.parent == SAVED, 'Safe flat saved filename')
        if dest.exists() and metadata(dest) != data:
            dest = dest.with_name(dest.stem + '__' + data['sha256'][:16] + dest.suffix)
        if not dest.exists():
            with p.open('rb') as reader, dest.open('xb') as writer:
                shutil.copyfileobj(reader, writer, 1024 * 1024)
                os.fchmod(writer.fileno(), data['mode'])
                drop(reader.fileno())
        after = p.stat()
        require((before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
                (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
                and metadata(dest) == data, 'Stable source copy with exact mode/hash')
        row = {'savedPath': dest.name, 'restorePath': str(p), **data}
        targets[str(p)] = row
        bases.pop(str(p), None)
        return row

    for name in all_pins:
        p = Path(name)
        force = str(p).startswith(str(RUN) + '/') or p in (WORKER, DESCRIPTOR)
        save(p, 'MODEL253_' + p.name if p.parent == RUN else None, force)
        if p.suffix in ('.py', '.ts', '.tsx', '.mjs') and p != Path(__file__):
            sources.add(p)
    save(profile_path, force=True)
    save(Path(__file__), force=True)
    excluded = set()
    visited = set()
    for _ in range(3):
        following = set()
        for p in sorted(sources - visited):
            visited.add(p)
            for literal in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]", p.read_text()):
                q = Path(literal)
                if not safe_public(q):
                    excluded.add(str(q))
                    continue
                if regular(q):
                    save(q)
                    if q.suffix in ('.py', '.ts', '.tsx', '.mjs'):
                        following.add(q)
        sources |= following
    # New output aliases refer to the complete MODEL253, never to old248/233.
    aliases = {}
    for alias, source in [('byte0-result.candidate.json', CURRENT), ('byte0-result.json', REPORT)]:
        row = targets[str(source)]
        dest = SAVED / alias
        with (SAVED / row['savedPath']).open('rb') as reader, dest.open('xb') as writer:
            shutil.copyfileobj(reader, writer, 1024 * 1024)
            os.fchmod(writer.fileno(), row['mode'])
        require(metadata(dest) == {k: row[k] for k in ('bytes', 'sha256', 'mode')}, 'Exact candidate/report alias')
        aliases[alias] = {'canonicalSavedPath': row['savedPath'], 'restorePath': str(source),
                          **{k: row[k] for k in ('bytes', 'sha256', 'mode')}}
    archive = read(BASE_MANIFEST)['archive']
    dependency = {**copy.deepcopy(archive), 'manifest': BASE_MANIFEST.relative_to(ROOT).as_posix(),
                  'manifestSha256': BASE_MANIFEST_SHA, 'mustBeRestoredFirst': True,
                  'payloadCopiedByThisCollector': False, 'priorDependencies': copy.deepcopy(base_progress['baseArchiveDependenciesInRestoreOrder'])}
    archives = copy.deepcopy(base_progress['baseArchiveDependenciesInRestoreOrder']) + [dependency]
    primary = {'scope': report['scope'], 'candidateSha256': CURRENT_SHA,
               'savedCandidate': 'byte0-result.candidate.json', 'routedOwners': 49, 'pendingOwnerIds': [],
               'modelAll49PhysicalPassed': True, 'bothCriticalViewsPassed': True,
               'changedJoinedChecksPassed': 4, 'powerReferencesPassed': 2, 'cap8PadsPassed': 2,
               'plannedPdnPhysicalNodesPassed': 2, 'freshSourceCorePending': True,
               'nativePending': True, 'authenticatedViaTrackPending': True, 'literalPoursPending': True,
               'actualPdnPlaneGraphQualificationPending': True, 'busSkewFailureCount': 3,
               'fullTimingPassed': False, 'electricalTimingQualified': False, 'tiQualified': False,
               'referenceContinuityQualified': False, 'cadQualified': False,
               'defaultBoardPromoted': False, 'all49Accepted': False, 'fabricationReady': False}
    latest = {**copy.deepcopy(primary), 'candidate': copy.deepcopy(targets[str(CURRENT)]),
              'report': copy.deepcopy(targets[str(REPORT)]), 'resumeModelRoutingFromThisCandidate': True,
              'freshSourceDerived': False, 'futureFreshIds': None,
              'originalBusConstraintObservations': copy.deepcopy(report['originalBusConstraintObservations']),
              'originalPairConstraintObservations': copy.deepcopy(report['originalPairConstraintObservations']),
              'latestConstructorFoundationDeltaFromReport': copy.deepcopy(report['constructorFoundationDelta']),
              'inheritedCandidateConstructorFoundationDeltaIsNotCurrent253Authority': True,
              'cap8PlacementInverse': copy.deepcopy(descriptor),
              'requiredSourceHardwarePlacementDeltas': copy.deepcopy(candidate['requiredSourceHardwarePlacementDeltas'])}
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    boundaries = {'frozenCheckpoint': False, 'finalFreezePendingFreshSourceNativeAuthAndPours': True,
                  'all49Accepted': False, 'fabricationReady': False}
    restore = {'scope': 'POST252 CLOSED253 MODEL49 PHYSICAL_ONLY FRESH_SOURCE_PENDING',
               'updatedAt': now, 'solverSourceRoot': '/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib',
               'files': sorted(targets.values(), key=lambda r: r['restorePath']),
               'baseDependencyRestoreFiles': sorted(bases.values(), key=lambda r: r['restorePath']),
               'baseArchiveDependency': dependency, 'baseArchiveDependenciesInRestoreOrder': archives,
               'aliases': aliases, 'primaryCandidate': primary, 'latestModelCheckpoint': latest,
               'independentFallbacks': {'source24848': copy.deepcopy(base_progress['latestSourceVerifiedCheckpoint']),
                                        'source23347TimingFallback': copy.deepcopy(base_progress['primaryCandidate']),
                                        'savedDirectory': BASE.relative_to(ROOT).as_posix(), 'independentNotInherited': True},
               **boundaries}
    progress = {'scope': restore['scope'], 'updatedAt': now, 'latestClosedScopeIncluded': 253,
                'primaryCandidate': primary, 'latestModelCheckpoint': latest,
                'latestSourceVerifiedCheckpoint': {'pendingForCurrentModel': True,
                    'independentPriorCheckpoint': {'savedDirectory': BASE.relative_to(ROOT).as_posix(),
                        'candidateSha256': ANCHOR_SHA, 'coreScope': 248, 'routedOwners': 48,
                        'pendingOwnerIds': ['source_trace_26'], 'qualificationNotInherited': True}},
                'independentFallbacks': copy.deepcopy(restore['independentFallbacks']),
                'closedExperiments': [{'scope': 253, 'closedAt': closure['closedAt'], 'exitCode': 0,
                    'terminalOutcome': report['terminalOutcome'], 'modelPhysical49Passed': True,
                    'report': copy.deepcopy(targets[str(REPORT)]), 'candidate': copy.deepcopy(targets[str(CURRENT)]),
                    'all49Accepted': False, 'fabricationReady': False}],
                'aliases': aliases, 'baseArchiveDependenciesInRestoreOrder': archives,
                'publicBaseRestoreDependencies': restore['baseDependencyRestoreFiles'],
                'frozenPost232MetadataPins': BASE_PINS, 'profileSha256': args.profile_sha,
                'collectorSource': str(Path(__file__)), 'collectorUsesOnlyOwnPythonStdlib': True,
                'privateAuthorityAndContextBodiesExcluded': True, 'excludedPrivateNamedLiterals': sorted(excluded),
                'baseDependenciesCopied': False, 'failed247RetainedInFrozenBase': True,
                'sdkExecutedByCollector': False, 'existingRestoreHelperExecutedByCollector': False,
                'archiveCreated': False, 'commitCreated': False, 'cloudDocumentEdited': False, **boundaries}
    for name, data in inputs.items():
        require(metadata(Path(name)) == data, 'Public source changed before metadata publication')
    for name, pin in all_pins.items():
        require(digest(Path(name)) == pin, 'Explicit253 source pin changed')
    require(digest(profile_path) == args.profile_sha, 'Profile unchanged')
    verify_base()
    write_json(SAVED / 'WORKSPACE_RESTORE_MANIFEST.json', restore)
    readme = f"""MODEL253: all49 DDR paths are physically connected in the qualified routing
model, including D12. Root253 freshly passed all49 carrier checks, two actual
critical shared views/all five APIs, four changed joined checks, both changed
0.2mm power references, two cap8 pads and two declared planned PDN nodes.

Candidate after dependency restore: {CURRENT}
SHA256 {CURRENT_SHA}
Saved current candidate: byte0-result.candidate.json
Report: {REPORT}
This initial collection is NOT a frozen final Source checkpoint. Fresh editable
Source/Core, native-board, authenticated via-track, literal pours and actual PDN
plane graph checks are PENDING. It does not inherit Source248 or Source236 pass.
All3 original cohort skew checks still FAIL: 6.655202281574553,
2.4000719198310776 and17.43870093419864mm. Full timing, electrical readiness,
TI/reference continuity, CAD, default promotion, all49 acceptance and fabrication
readiness remain FALSE.

The CPU2NE/CPU11SW branches, four body replacements, manual26 endpoint changes,
cap8 move and two planned PDN declarations each have exact inverse/proof records.
The planned PDN Source names are not authentic new raw IDs. No new ID is claimed
until fresh Core produces it. Latest253 foundation authority is the REPORT's
constructorFoundationDelta; the candidate's same-named inherited cap12 field is
preserved only as provenance. The plural requiredSourceHardwarePlacementDeltas
contains both actual cap12 and cap8 descriptors.

The frozen post232 Source24848 checkpoint (all scoped checks+all14 pours) and its
INDEPENDENT Source233/23647-route CA13 timing fallback remain base dependencies.
No fallback geometry or qualification is combined with this MODEL253. Failed
Core247's loader exception remains preserved in that frozen dependency. Restore
Source209 -> Source228 -> Source248 before this new saved workspace; hashes and
exact byte/mode restore rows are recorded in WORKSPACE_RESTORE_MANIFEST.json.
The compatible helper is scripts/restore-g350-four-layer-routing-workspace.py
--saved-directory .cloud-tools/ddr-four-layer-post252-2026-10-16; --restore refuses
different existing bytes/modes. This collector does not run the supplied helper.

No older saved folder, archive, tracked application Source, cloud document or
commit is modified. Only this NEW post252 directory is written, using own stdlib.
Final freezing waits for separate reviewed append Source and actual fresh checks.
"""
    with (SAVED / 'README.md').open('x') as stream:
        stream.write(readme)
        os.fchmod(stream.fileno(), 0o600)
    excluded_metadata = {'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
    progress['artifacts'] = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir())
                             if regular(p) and p.name not in excluded_metadata]
    write_json(SAVED / 'PROGRESS.json', progress)
    rows = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir())
            if regular(p) and p.name != 'WORKSPACE_HASH_INDEX.json']
    write_json(SAVED / 'WORKSPACE_HASH_INDEX.json', {'scope': restore['scope'], 'updatedAt': now,
               'files': rows, 'selfExcluded': True, **boundaries})
    verify_rows(SAVED, rows)
    for row in restore['files']:
        expected = {k: row[k] for k in ('bytes', 'sha256', 'mode')}
        require(metadata(SAVED / row['savedPath']) == expected
                and metadata(Path(row['restorePath'])) == expected, 'Saved and current restore targets exact')
    verify_base()
    print(json.dumps({'savedDirectory': str(SAVED), 'fileCount': len(rows) + 1,
        'indexRows': len(rows), 'restoreTargets': len(targets), 'baseRestoreDependencies': len(bases),
        'metadataSha256': {name: digest(SAVED / name) for name in
            ('PROGRESS.json', 'WORKSPACE_HASH_INDEX.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'README.md')},
        'frozenCheckpoint': False, 'freshSourceCorePending': True,
        'sdkExecuted': False, 'all49Accepted': False, 'fabricationReady': False}, indent=2))


if __name__ == '__main__':
    main()
