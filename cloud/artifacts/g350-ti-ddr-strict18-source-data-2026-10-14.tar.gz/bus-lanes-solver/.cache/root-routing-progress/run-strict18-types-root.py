import importlib.util,json,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
spec=importlib.util.spec_from_file_location('strict18_reviewed_capture_library',ROOT/'run-strict18-source-capture-root.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
CORE=c.BOARD/'.cloud-tools/ddr-strict18-manual-core-owned-alias-successor-next'
OUT=c.PACKET/'run-types'
POLICY={'wallSeconds':90,'rssBytes':3221225472,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
def main():
 assert len(sys.argv)==3
 peerpath=Path(sys.argv[1]);assert c.sha(peerpath)==sys.argv[2]
 peer=c.read(peerpath);core_manifest=CORE/'SOURCE-manifest.json';core_sha=c.sha(core_manifest)
 assert peer['sourceManifestSha256']==core_sha and peer['decision']=='GO_SOURCE_ONLY_TO_ROOT_OWNED_CORE_AFTER_ACTUAL_SOURCE_AND_TYPES_ZERO'
 cm=c.read(core_manifest)
 for r in cm['ownFiles']+cm['externalFiles']:c.guard.source_guard.binding(r)
 m,packet=c.bindings();_,native_sha,before,sbefore,_=c.guard.checked()
 receipt=ROOT/'strict18-source-capture-86442-COLLECTED-root.json'
 cr,cp,ce=c.guard.collected({'path':str(receipt),'sha256':c.sha(receipt)},positive=True)
 assert cr['sourceManifestSha256']==packet and c.sha(cp['capturePath'])==cp['captureSha256'] and c.read(cp['capturePath'])['fullInverseSourceTreePassed']
 rows=c.read(c.PACKET/'run-capture/ROOT_AUTHORITY.json')['actualPriorCollectedRows']+[{'path':str(receipt),'sha256':c.sha(receipt)}]
 def closed():
  for r in rows:assert c.guard.process_scope.owned(c.guard.collected(r)[2]['pgid'])==[]
 closed();assert not OUT.exists();OUT.mkdir()
 parent=c.read(c.BOARD/'.cloud-tools/ddr-clock-v11-manual-pair-source-successor-next/PREPARED-manifest.json')
 argv=parent['typecheckCommand'][:-3]+[str(c.PACKET/'strict18-source-overlay.tsx'),str(c.PACKET/'capture-strict18-source.ts'),str(CORE/'render-strict18-core.ts')]
 def prefork(mem):
  closed();assert mem['current']+POLICY['rssBytes']+1073741824<POLICY['sharedBytes']
 e=c.guard.process_scope.run_guarded(argv,str(c.BOARD),OUT/'owned',POLICY,{},before_spawn=prefork)
 _,nsha,after,safter,_=c.guard.checked();_,pafter=c.bindings();closed()
 for r in cm['ownFiles']+cm['externalFiles']:c.guard.source_guard.binding(r)
 held=native_sha==nsha and packet==pafter and before==after and sbefore==safter and c.sha(peerpath)==sys.argv[2] and c.sha(core_manifest)==core_sha
 passed=held and e['exitCode']==0 and not e['diagnosticStopped'] and e['cleanupOwnedGroupEmpty'] and not any(e['oomDelta'].values())
 post={'scope':'ACTUAL_STRICT18_FUNCTIONAL_STRICT_TYPECHECK','sourceManifestSha256':packet,'coreSourceManifestSha256':core_sha,'execution':e,'sourceAndDependenciesHeld':held,'dependenciesBefore':before,'dependenciesAfter':after,'solverDependenciesBefore':sbefore,'solverDependenciesAfter':safter,'actualCaptureCollectionSha256':c.sha(receipt),'typecheckCommand':argv,'passed':bool(passed),'typecheckPassed':bool(passed),'coreCalls':0,'nativeCalls':0,'cadCalls':0,'accepted49':False,'fabricationReady':False}
 with (OUT/'POSTAUDIT.json').open('x')as f:json.dump(post,f,indent=2);f.write('\n')
 print(json.dumps({k:post[k]for k in ('passed','sourceAndDependenciesHeld','coreSourceManifestSha256','execution')}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
