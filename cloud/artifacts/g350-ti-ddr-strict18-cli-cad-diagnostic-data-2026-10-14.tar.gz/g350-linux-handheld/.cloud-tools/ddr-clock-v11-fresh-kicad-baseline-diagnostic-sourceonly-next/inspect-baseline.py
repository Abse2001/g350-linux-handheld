"""Finite fresh-export diagnostic. Root alone runs the offline KiCad10 wrapper.

No SaveBoard, refill, routing, source generation, net repair, or promotion.
All actual net/connectivity observations are saved before qualification fails.
"""
import argparse
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True

BOARD = Path('/workspace/g350-linux-handheld')
BUS = Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
OUT = BOARD / '.cloud-tools/ddr-clock-v11-fresh-kicad-baseline-diagnostic-sourceonly-next/run-cad/output'
INPUTS = {
    BOARD / '.cloud-tools/ddr-clock-v11-manual-pair-source-successor-next/run-core/raw-core.json': '7793a13abbc457569cb15c1a9bc549ce585dbd75ac85acd6e384441557075c06',
    BOARD / '.cloud-tools/ddr-clock-v11-manual-pair-source-successor-next/run-core/core-controls.json': '661c4ae8def5022f06a51ffdb1dbbee7ab9de7cbc12c2086bbe57c6911aa1138',
    BOARD / '.cloud-tools/ddr-clock-v11-fresh-core-native-sourceonly-next/run-native/native18-report.json': '55f3b2a9629532e24d74ad3527e155d9491a921b7a6253a6e51d192597a2a159',
    BUS / 'clock-v11-fresh-native-42626-COLLECTED-root.json': '183bae7743f91000a4b2e528415e47680ea23a675f69c6504ede13e3a792c15d',
    BUS / 'clock-v11-fresh-cli-87907-COLLECTED-root.json': '5855d8f6a8fc20dcd1a8cc6f0f1f1ab5532bd98df77b66db18bec8297fa9b084',
    BUS / 'clock-v11-fresh-cli-owned-next/exports/clock-v11.kicad_pcb': '540b9d2c5259a06e18f0be3706fe818fd86db444ed431ef7997c772998aa36d7',
    BOARD / '.cloud-tools/ddr-package101-cad-source-next/child/inspect-local101-hs64.py': 'a14ef195d87e8c8ca77bcb8b851e78333649bcff7c54712884d06f6e9ccd60f6',
}

def require(value, message):
    if not value:
        raise ValueError(message)

def read(path):
    require(path.is_file() and not path.is_symlink(), 'Regular immutable input required: ' + str(path))
    data = path.read_bytes()
    require(len(data) <= 32 * 1024 * 1024, 'Finite input required')
    return data

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, obj):
    with path.open('x') as output:
        json.dump(obj, output, indent=2)
        output.write('\n')
    path.chmod(0o600)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-directory', required=True, type=Path)
    args = parser.parse_args()
    require(args.output_directory.resolve() == OUT and OUT.is_dir() and not OUT.is_symlink(), 'Exact Root-owned output directory required')
    require(not any(OUT.iterdir()), 'Exclusive fresh output directory required')
    report = {'scope': 'FRESH_CLOCK_V11_BASELINE_KICAD10_NET_AND_CONNECTIVITY_DIAGNOSTIC', 'passed': False,
              'diagnosticCompleted': False, 'accepted49': False, 'referenceQualified': False,
              'electricalTimingQualified': False, 'fabricationReady': False,
              'sourceRawOrSdkEdited': False, 'netRepairPerformed': False, 'saveBoardPerformed': False,
              'allRuleDrcPerformed': False, 'globalDdrRoutesStillMissing': 47}
    before = {}
    try:
        for path, expected in INPUTS.items():
            before[str(path)] = sha(read(path))
            require(before[str(path)] == expected, 'Immutable input hash differs: ' + str(path))
        report['inputHashesBefore'] = before
        paths = list(INPUTS)
        raw = json.loads(read(paths[0]))
        controls = json.loads(read(paths[1]))
        native = json.loads(read(paths[2]))
        require(controls.get('freshCoreControlPassed') is True, 'Actual Core controls must pass')
        for path in paths[3:5]:
            receipt = json.loads(read(path))
            require(receipt.get('passed') is True and receipt.get('toolSessionCollected') is True and
                    receipt.get('toolExitCode') == receipt.get('toolWrapperExitCode') == 0 and
                    receipt.get('sourceAndDependenciesHeld') is True and
                    receipt['execution']['exitCode'] == 0 and receipt['execution']['cleanupOwnedGroupEmpty'] is True,
                    'Actual collected Native/CLI success required')
        proof = native['actualOwnershipProof']
        signals = proof['signalMappings']
        require(len(signals) == len({row['actualViaId'] for row in signals}) == 96 and len(proof['clocks']) == 2, 'Exact actual96 signal barrels and two clocks required')
        spec = importlib.util.spec_from_file_location('preserved_cad_stdlib', paths[6])
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        kinds = ['pcb_via', 'pcb_trace', 'pcb_port', 'source_port', 'pcb_component', 'source_component', 'pcb_smtpad', 'source_trace', 'source_manually_placed_via']
        lookup = {kind: helper.unique_source(raw, kind) for kind in kinds}
        require([len(lookup[kind]) for kind in ['pcb_via', 'pcb_trace', 'pcb_component', 'source_component', 'pcb_smtpad']] == [225, 263, 505, 280, 1161], 'Exact fresh Core inventory required')
        source_segments = sum(a['x'] != b['x'] or a['y'] != b['y'] for trace in lookup['pcb_trace'].values() for a, b in zip(trace['route'], trace['route'][1:]))
        require(source_segments == 461, 'Actual nonzero Source segment inventory required')
        pcb_bytes = read(paths[5])
        root = helper.parse_sexpressions(pcb_bytes)
        raw_items = {kind: helper.children(root, kind) for kind in ['footprint', 'via', 'segment', 'zone']}
        require([len(raw_items[kind]) for kind in ['footprint', 'via', 'segment', 'zone']] == [505, 225, 461, 4], 'Actual fresh exporter inventory required')
        zonefree = helper.drop_spans(pcb_bytes, raw_items['zone'])
        zonefree_root = helper.parse_sexpressions(zonefree)
        for kind in ['footprint', 'via', 'segment']:
            require([zonefree[node.start:node.end] for node in helper.children(zonefree_root, kind)] ==
                    [pcb_bytes[node.start:node.end] for node in raw_items[kind]], 'Zone-free diagnostic must hold all raw hardware/copper bytes')
        zonefree_path = OUT / 'baseline-zone-free.kicad_pcb'
        with zonefree_path.open('xb') as output:
            output.write(zonefree)
        zonefree_path.chmod(0o600)
        report['zoneFreeDiagnosticCopy'] = {'path': str(zonefree_path), 'sha256': sha(zonefree), 'removedZones': 4, 'allFootprintViaSegmentBytesHeld': True}
        import wx
        wx.Log.SetLogLevel(wx.LOG_Error)
        application = wx.App(False)
        import pcbnew
        version = pcbnew.GetBuildVersion()
        require(version.startswith('10.0.6'), 'Retained tested KiCad10.0.6 required')
        board = pcbnew.LoadBoard(str(zonefree_path))
        require(board is not None and board.GetCopperLayerCount() == 4, 'Actual four-layer export must load')
        board.BuildConnectivity()
        uid = lambda item: item.m_Uuid.AsString()
        xy = lambda point: [pcbnew.ToMM(point.x), pcbnew.ToMM(point.y)]
        footprints = list(board.GetFootprints())
        tracks = list(board.GetTracks())
        vias = [item for item in tracks if isinstance(item, pcbnew.PCB_VIA)]
        segments = [item for item in tracks if not isinstance(item, pcbnew.PCB_VIA)]
        require([len(footprints), len(vias), len(segments), len(list(board.Zones()))] == [505, 225, 461, 0], 'Actual parser/native geometry inventory required')
        require(not any(hasattr(pcbnew, 'PCB_ARC') and isinstance(item, pcbnew.PCB_ARC) for item in segments), 'No unmodeled arcs allowed')
        report['actualNativeInventory'] = {'version': version, 'footprintsIncluding225EmptyViaPlaceholders': len(footprints), 'physicalVias': len(vias), 'segments': len(segments), 'zoneFreeZones': len(list(board.Zones())), 'layers': [board.GetLayerName(layer) for layer in [pcbnew.F_Cu, pcbnew.In1_Cu, pcbnew.In2_Cu, pcbnew.B_Cu]]}
        native_footprints = {uid(item): item for item in footprints}
        require(len(native_footprints) == 505, 'Unique actual footprint UUIDs required')
        mapped_components = {}
        for component_id in {lookup['pcb_port'][row['actualNumericPcbPortId']]['pcb_component_id'] for row in signals}:
            component = lookup['pcb_component'][component_id]
            matching = []
            for node in raw_items['footprint']:
                pos = helper.values(node, 'at')
                if helper.at([float(v) for v in pos[:2]], helper.transform(component['center']['x'], component['center']['y'])):
                    identity = helper.values(node, 'uuid')[0]
                    if helper.converter_uuid('footprint:' + component_id + ':' + pos[0] + ',' + pos[1]) == identity:
                        matching.append(native_footprints[identity])
            mapped_components[component_id] = helper.one(matching, 'Authentic Source numeric-owner footprint required')
        trace_items = {}
        def actual_trace(trace_id):
            if trace_id in trace_items:
                return trace_items[trace_id]
            trace = lookup['pcb_trace'][trace_id]
            matches = []
            for a, b in zip(trace['route'], trace['route'][1:]):
                if a['x'] == b['x'] and a['y'] == b['y']:
                    continue
                require(a['route_type'] == b['route_type'] == 'wire' and a['layer'] == b['layer'], 'Same-layer real Source wire required')
                first, second = helper.transform(a['x'], a['y']), helper.transform(b['x'], b['y'])
                found = helper.one([item for item in segments if board.GetLayerName(item.GetLayer()) == helper.LAYER_NAMES[a['layer']] and helper.near(pcbnew.ToMM(item.GetWidth()), a.get('width', b.get('width'))) and ((helper.at(xy(item.GetStart()), first) and helper.at(xy(item.GetEnd()), second)) or (helper.at(xy(item.GetStart()), second) and helper.at(xy(item.GetEnd()), first)))], 'Unique actual source-owned segment geometry required: ' + trace_id)
                matches.append(found)
            require(matches, 'Nonempty actual Source trace required')
            trace_items[trace_id] = matches
            return matches
        via_items = {}
        for via_id, source_via in lookup['pcb_via'].items():
            via = helper.one([item for item in vias if helper.at(xy(item.GetPosition()), helper.transform(source_via['x'], source_via['y']))], 'Unique actual Source barrel required')
            require(via.GetViaType() == pcbnew.VIATYPE_THROUGH and via.TopLayer() == pcbnew.F_Cu and via.BottomLayer() == pcbnew.B_Cu and helper.near(pcbnew.ToMM(via.GetWidth(pcbnew.F_Cu)), source_via['outer_diameter']) and helper.near(pcbnew.ToMM(via.GetDrillValue()), source_via['hole_diameter']), 'Actual physical barrel dimensions/span required')
            via_items[via_id] = via
        connectivity = board.GetConnectivity()
        linked = lambda item: {uid(value) for value in connectivity.GetConnectedItems(item)} | {uid(item)}
        observations = []
        for row in signals:
            via_source = lookup['pcb_via'][row['actualViaId']]
            numeric = lookup['pcb_port'][row['actualNumericPcbPortId']]
            port = lookup['source_port'][numeric['source_port_id']]
            top = lookup['pcb_port'][row['actualTopPcbPortId']]
            top_source = lookup['source_port'][top['source_port_id']]
            source_trace = lookup['source_trace'][row['actualPhysicalSourceTraceId']]
            local_source_trace = lookup['source_trace'][row['actualLocalSourceTraceId']]
            trace = lookup['pcb_trace'][row['actualPcbTraceId']]
            require(numeric['source_port_id'] == row['originalNumericSourcePortId'] and top['pcb_port_id'] in via_source['pcb_port_ids'] and top['layers'] == ['top'] and top_source['source_component_id'] == row['sourceViaOwnerId'] and trace['source_trace_id'] == row['actualPhysicalSourceTraceId'] and {numeric['source_port_id'], top['source_port_id']} == set(local_source_trace['connected_source_port_ids']) and source_trace['subcircuit_connectivity_map_key'] == local_source_trace['subcircuit_connectivity_map_key'] == port['subcircuit_connectivity_map_key'] == top_source['subcircuit_connectivity_map_key'], 'Authentic numeric/alias/Source-owned Topstub agreement required')
            pad = helper.one([pad for pad in mapped_components[numeric['pcb_component_id']].Pads() if pad.GetNumber() == str(port['pin_number']) and helper.at(xy(pad.GetPosition()), helper.transform(numeric['x'], numeric['y']))], 'Actual Source numeric pad identity and anchor required')
            barrel = via_items[row['actualViaId']]
            stub = actual_trace(row['actualPcbTraceId'])
            pad_linked = linked(pad)
            expected = pad.GetNetCode()
            same_net = expected != 0 and all(item.GetNetCode() == expected and item.GetNetname() == pad.GetNetname() for item in stub) and barrel.GetNetCode() == expected and barrel.GetNetname() == pad.GetNetname()
            observations.append({**row, 'numericPin': port['pin_number'], 'numericSourceOwnerName': lookup['source_component'][port['source_component_id']]['name'], 'nativePadUuid': uid(pad), 'nativeViaUuid': uid(barrel), 'nativeTopstubSegmentUuids': [uid(item) for item in stub], 'actualNumericPadNetCode': expected, 'actualNumericPadNetName': pad.GetNetname(), 'actualTopstubNetCodes': [item.GetNetCode() for item in stub], 'actualTopstubNetNames': [item.GetNetname() for item in stub], 'actualViaNetCode': barrel.GetNetCode(), 'actualViaNetName': barrel.GetNetname(), 'numericPadTopstubNetAgreement': expected != 0 and all(item.GetNetCode() == expected and item.GetNetname() == pad.GetNetname() for item in stub), 'viaNetMatchesActualNumericPadAndTopstub': same_net, 'nativePadConnectedToVia': uid(barrel) in pad_linked, 'nativePadConnectedToAllTopstubSegments': all(uid(item) in pad_linked for item in stub)})
        clocks = []
        for clock in proof['clocks']:
            rows = [row for row in observations if row['actualViaId'] in [clock['actualCpuViaId'], clock['actualRamViaId']]]
            require(len(rows) == 2, 'Both actual clock barrel owners required')
            cpu_row = helper.one([row for row in rows if row['actualNumericPcbPortId'] == clock['actualCpuNumericPcbPortId']], 'Actual clock CPU numeric owner required')
            cpu_pad_uuid = cpu_row['nativePadUuid']
            cpu_pad = helper.one([pad for footprint in footprints for pad in footprint.Pads() if uid(pad) == cpu_pad_uuid], 'Actual CPU clock pad UUID required')
            connected = linked(cpu_pad)
            owned_items = [item for trace_id in clock['actualDirectPcbTraceIds'] for item in actual_trace(trace_id)] + [via_items[clock['actualCpuViaId']], via_items[clock['actualRamViaId']]]
            ram_row = helper.one([row for row in rows if row['actualNumericPcbPortId'] == clock['actualRamNumericPcbPortId']], 'Actual clock RAM numeric owner required')
            clocks.append({**clock, 'actualCpuPin': cpu_row['numericPin'], 'actualRamPin': ram_row['numericPin'], 'actualCpuPadNet': cpu_row['actualNumericPadNetCode'], 'actualRamPadNet': ram_row['actualNumericPadNetCode'], 'actualPathSegmentNetCodes': [[item.GetNetCode() for item in actual_trace(trace_id)] for trace_id in clock['actualDirectPcbTraceIds']], 'actualBarrelNetCodes': [via_items[clock['actualCpuViaId']].GetNetCode(), via_items[clock['actualRamViaId']].GetNetCode()], 'allOwnedClockCopperConnectedFromCpuPad': all(uid(item) in connected for item in owned_items), 'actualRamPadConnectedFromCpuPad': ram_row['nativePadUuid'] in connected})
        report.update(diagnosticCompleted=True, signalObservations=observations, actualClockObservations=clocks,
                      signalViaNetMismatchCount=sum(not row['viaNetMatchesActualNumericPadAndTopstub'] for row in observations),
                      signalViaNetZeroCount=sum(row['actualViaNetCode'] == 0 for row in observations),
                      numericPadTopstubAgreementCount=sum(row['numericPadTopstubNetAgreement'] for row in observations),
                      physicalClockConnectedCount=sum(row['allOwnedClockCopperConnectedFromCpuPad'] and row['actualRamPadConnectedFromCpuPad'] for row in clocks),
                      referenceViaNetZeroCount=sum(via.GetNetCode() == 0 for via_id, via in via_items.items() if via_id not in {row['actualViaId'] for row in signals}))
        # Save complete actual observations before the strict qualification assertion.
        save(OUT / 'actual-net-connectivity-observations.json', report)
        require(report['signalViaNetMismatchCount'] == 0 and report['numericPadTopstubAgreementCount'] == 96 and report['physicalClockConnectedCount'] == 2, 'Unresolved fresh export net/physical connectivity mismatch')
        report.update(passed=True, status='NARROW_FRESH_CLOCK_KICAD_NET_CONNECTIVITY_PASS')
    except Exception as error:
        report.update(status='UNRESOLVED_FRESH_EXPORT_KICAD_NET_OR_CONNECTIVITY', failure=str(error))
    report['inputHashesAfter'] = {str(path): sha(read(path)) for path in INPUTS}
    report['allInputBytesHeld'] = report['inputHashesAfter'] == before
    if not report['allInputBytesHeld']:
        report.update(passed=False, failure='Immutable input changed during diagnostic')
    save(OUT / 'baseline-report.json', report)
    print(json.dumps({key: report.get(key) for key in ['passed', 'diagnosticCompleted', 'status', 'failure', 'signalViaNetMismatchCount', 'signalViaNetZeroCount', 'numericPadTopstubAgreementCount', 'physicalClockConnectedCount', 'allInputBytesHeld', 'accepted49', 'fabricationReady']}))
    return 0 if report['passed'] else 2

if __name__ == '__main__':
    raise SystemExit(main())
