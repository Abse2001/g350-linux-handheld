import { plugin } from "bun"
import { appendFileSync, readFileSync } from "node:fs"
import { createHash } from "node:crypto"

if (process.env.G350_NATIVE_PREFIX_OBSERVER_APPROVED !== "1")
  throw new Error("Root-owned native-prefix observation required")
const root = import.meta.dir
const packet = JSON.parse(readFileSync(`${root}/PREPARED.json`, "utf8"))
const digest = (contents: Buffer) =>
  createHash("sha256").update(contents).digest("hex")
plugin({
  name: "qualification-only-native-test-phase-observer",
  setup(builder) {
    builder.onLoad(
      { filter: /\/tests\/grid-native-length-bounds\.test\.ts$/ },
      (args) => {
        if (args.path !== packet.originalTestPath)
          throw new Error("Native observer resolved an unexpected source path")
        const original = readFileSync(args.path)
        const observed = readFileSync(packet.observedTestPath)
        if (digest(original) !== packet.originalTestSha256 ||
            digest(observed) !== packet.observedTestSha256)
          throw new Error("Native observer source binding changed")
        appendFileSync(`${root}/run/native-phases.jsonl`, JSON.stringify({
          kind: "module-load", originalPath: args.path,
          originalSha256: digest(original), observedSha256: digest(observed),
          gridRuntimeUnchanged: true,
        }) + "\n")
        return { contents: observed.toString("utf8"), loader: "ts" }
      },
    )
  },
})
