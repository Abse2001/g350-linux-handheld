#!/usr/bin/env python3
"""Freeze the closed232/Source228 milestone data, not a board release."""
import datetime, hashlib, json, os, re, shutil, stat
from pathlib import Path
ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post209-2026-10-16'
BASE = ROOT / '.cloud-tools/ddr-four-layer-manual-2026-10-16'
POUR = Path('/tmp/g350-source228-all14-literal-pour-margin-root-20261016.json')
POUR_SHA = 'fba9a7f96af8acb94b2fc023e0401e452c56412318ec584a54eacbd616c4483f'
PROTECTED = {'AGENTS.md': 'd3086d9ff8887bd296ed0d480fcbef732686bf45e075ae766a0a292518086723',
    'cloud/CONTINUE_BOARD.md': 'bb9a879c5c68c3718d24c82a77326f5b175d47899f101407b1e1ee106c8b19ef',
    'scripts/prepare-g350-ram90-four-layer.mjs': 'ec6b56c59d2c8f72f969934076dd3597014833e8b2e8e4387c1045f03eaadda0',
    'scripts/tune-g350-ram90-native-lengths.mjs': '5bfe731744159cf9f65ddde71b513cb1a0d2384574e740cd11bc087ce69b4b40'}
def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        while b := f.read(1024 * 1024): h.update(b)
        os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return h.hexdigest()
def read(p):
    with p.open('rb') as f:
        x = json.load(f); os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return x
def write(p, x):
    t = p.with_name(p.name + '.freeze232')
    with t.open('x') as f: json.dump(x, f, indent=2, allow_nan=False); f.write('\n')
    os.replace(t, p)
def main():
    mfile, pfile, ifile = [SAVED / n for n in ('WORKSPACE_RESTORE_MANIFEST.json', 'PROGRESS.json', 'WORKSPACE_HASH_INDEX.json')]
    m, p = read(mfile), read(pfile); targets = {v['restorePath']: v for v in m['files']}
    assert len(targets) == len(m['files'])
    for n, h in p['baseArchiveDependency']['originalBaseSavedMetadataPins'].items(): assert sha(BASE / n) == h
    for n, h in PROTECTED.items(): assert sha(ROOT / n) == h
    for f in (mfile, pfile, ifile, SAVED / 'README.md'):
        t = SAVED / 'history' / (f.stem + '.before-freeze232.' + sha(f)[:16] + f.suffix)
        with f.open('rb') as a, t.open('xb') as b: shutil.copyfileobj(a, b); os.fchmod(b.fileno(), stat.S_IMODE(f.stat().st_mode))
    def save(source, name=None, restore=True):
        source = Path(source); assert source.is_file() and not source.is_symlink()
        h, mode = sha(source), stat.S_IMODE(source.stat().st_mode)
        if restore:
            assert str(source).startswith('/tmp/g350-')
            if str(source) in targets:
                old = targets[str(source)]; assert old['sha256'] == h and old['bytes'] == source.stat().st_size and old['mode'] == mode
                return old
        dest = SAVED / (name or source.name)
        if dest.exists() and sha(dest) != h: dest = dest.with_name(dest.stem + '__' + h[:16] + dest.suffix)
        if not dest.exists():
            with source.open('rb') as a, dest.open('xb') as b:
                shutil.copyfileobj(a, b, 1024 * 1024); os.fchmod(b.fileno(), mode); os.posix_fadvise(a.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
        assert sha(dest) == h and stat.S_IMODE(dest.stat().st_mode) == mode
        row = {'savedPath': dest.name, 'restorePath': str(source), 'bytes': source.stat().st_size, 'sha256': h, 'mode': mode}
        if restore: targets[str(source)] = row; m['files'].append(row)
        return row
    folder = Path('/tmp/g350-d12-top-portal-root-20261016-run232')
    collection = read(folder / 'COLLECTED.json'); assert collection['closedAt'] and collection['scope'] == 232 and collection['execution']['exitCode'] == 0
    label = 'D12_TOP_PORTAL232_NO_ADOPTION'
    save(folder / 'COLLECTED.json', label + '_COLLECTED.json')
    for f in sorted(folder.glob('byte0-result*.json')): save(f, label + '_' + f.name)
    for name in ('child.log', 'memory.jsonl', 'execution.json'):
        f = folder / 'owned' / name
        if f.is_file(): save(f, label + '_owned_' + name)
    worker = Path(collection['execution']['command'][1]); save(worker)
    with worker.open('r') as f:
        text = f.read(); os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    for literal in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]", text):
        q = Path(literal)
        if q.is_file() and not q.is_symlink() and not any(v.upper().startswith(('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT')) for v in q.parts): save(q)
    assert sha(POUR) == POUR_SHA
    audit = read(POUR)
    assert audit['completed'] and audit['allActualPoursCompleted'] and audit['literalForeignPourMarginClear'] and audit['inputFilesUnchanged']
    assert len(audit['actualRawPourIds']) == len(audit['pourReports']) == 14 and all(v['state'] == 'COMPLETED' for v in audit['pourReports'])
    assert audit['actualViaCount'] == 227 and audit['wireSegmentCount'] == 937 and len(audit['wireOriginalOwners']) == 47
    assert all(audit[k] == [] for k in ('violations', 'globalIdentityFailures', 'viaIdentityFailures', 'unsupportedGeometry', 'unknownPourIdentities'))
    save(POUR)
    for name in ('g350-partial47-literal-selected-pour-clearance-audit-sourceonly.py',
                 'g350-post209-evidence-archive-builder-sourceonly.py',
                 'g350-plot-source228-manual47-root.py', 'g350-freeze-post209-through232-sourceonly.py'):
        save('/tmp/' + name)
    assert sha(Path('/tmp/g350-partial47-literal-selected-pour-clearance-audit-sourceonly.py')) == 'fd1930362566d7726ac672bc99a67ed62368dedae6b6ef116892f50e45ebacae'
    assert sha(Path('/tmp/g350-post209-evidence-archive-builder-sourceonly.py')) == 'fad3d65b9a55e4f03e960ddb46d27ba59e0a38b0d0b69c02cd11a4ac7b05bf8c'
    visualization = {'png': 'SOURCE228_PARTIAL47_FOUR_LAYER_MILESTONE.png',
        'svg': 'SOURCE228_PARTIAL47_FOUR_LAYER_MILESTONE.svg', 'source': 'g350-plot-source228-manual47-root.py',
        'pendingOwners': [26, 30], 'allFourSignalLayers': True, 'xMinimum': -10.2,
        'all49Accepted': False, 'fabricationReady': False}
    for key in ('png', 'svg', 'source'):
        q = SAVED / visualization[key]; assert q.is_file(); visualization[key + 'Sha256'] = sha(q)
    literal = {'report': POUR.name, 'sha256': POUR_SHA, 'actualPoursCompleted': 14, 'authenticatedVias': 227,
        'routedWireSegments': 937, 'routedOwners': 47, 'violations': 0,
        'minimumForeignEdgeGapMm': 0.11832052949719676, 'requiredForeignEdgeGapMm': .1016,
        'referenceQualified': False, 'all49Accepted': False, 'fabricationReady': False}
    p['latestClosedScopeIncluded'] = 232
    p['closedExperiments'].append({'scope': 232, 'label': label, 'closedAt': collection['closedAt'],
        'executionOccurred': True, 'exitCode': 0, 'reportProduced': True, 'candidateProduced': False,
        'adopted': False, 'original223Retained': True, 'defaultBoardPromoted': False, 'all49Accepted': False})
    p['freshLiteralPour228'] = literal; p['freshNative230Authenticated231']['literalPourAuditPending'] = False
    for primary in (p['primaryCandidate'], m['primaryCandidate']):
        primary['freshLiteralPour228'] = literal; primary['freshEditableSource228']['literalPourAuditPending'] = False
        primary['freshNative230Authenticated231']['literalPourAuditPending'] = False
    p['freshEditableSource228']['literalPourAuditPending'] = False
    p['latestSource228MilestoneVisualization'] = visualization
    p['archiveSnapshotBoundary'] = {'closedSdkScopes': list(range(215, 233)), 'freshSourceCore': 228,
        'focusedNative': 230, 'authenticatedViaTrack': 231, 'literalAudit': POUR.name,
        'laterSdk233AndCaMergeExcluded': True, 'baseArchiveUnchanged': True,
        'awaitingRootArchiveBuildAndReview': True, 'archiveCreatedByThisCollector': False}
    now = datetime.datetime.now(datetime.timezone.utc).isoformat(); p['updatedAt'] = m['updatedAt'] = now
    text = (SAVED / 'README.md').read_text().replace('through closed231.', 'through closed232 plus the completed Source228 literal-pour audit.')
    text = text.replace('The14 actual\nfresh literal pours still require their own audit.',
        'All14 actual fresh literal pours now pass the exact audit against227 authenticated\nvias and937 routed wire segments: zero foreign-margin violations, minimum gap\n0.11832052949719676mm against0.1016mm. This is not reference-plane/TI qualification.')
    text += ('\nSnapshot boundary: closed SDK215–232, Source228/native230/auth231 and its completed\n14-pour audit. Later233/CA-merge experiments are excluded and belong in a fresh\npost232 folder. Source209 remains an independent timing fallback; its CA204\nminimum-window improvements have not been combined with this47-path candidate.\n')
    (SAVED / 'README.md').write_text(text)
    save(ROOT / 'cloud/DDR_FOUR_LAYER_MANUAL_ROUTING_2026-10-16.md', 'DDR_FOUR_LAYER_MANUAL_ROUTING_2026-10-16.md', False)
    m['files'].sort(key=lambda v: v['restorePath']); write(mfile, m); write(pfile, p)
    excluded = {'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
    artifacts = [{'path': f.relative_to(SAVED).as_posix(), 'bytes': f.stat().st_size, 'sha256': sha(f), 'mode': stat.S_IMODE(f.stat().st_mode)}
        for f in sorted(SAVED.rglob('*')) if f.is_file() and not f.is_symlink() and f.relative_to(SAVED).as_posix() not in excluded]
    p['artifacts'] = artifacts; write(pfile, p)
    rows = artifacts + [{'path': f.name, 'bytes': f.stat().st_size, 'sha256': sha(f), 'mode': stat.S_IMODE(f.stat().st_mode)} for f in (mfile, pfile)]
    write(ifile, {'scope': 'Frozen post209 Source228 partial47 evidence through closed232; no board acceptance',
        'updatedAt': now, 'files': sorted(rows, key=lambda v: v['path']), 'selfExcluded': True, 'all49Accepted': False, 'fabricationReady': False})
    for n, h in p['baseArchiveDependency']['originalBaseSavedMetadataPins'].items(): assert sha(BASE / n) == h
    for n, h in PROTECTED.items(): assert sha(ROOT / n) == h
    print(json.dumps({'restoreTargets': len(m['files']), 'indexedFiles': len(rows), 'snapshotThroughSdk': 232,
        'currentPrimary': p['primaryCandidate']['savedPath'], 'primarySha256': p['primaryCandidate']['sha256'],
        'indexSha256': sha(ifile), 'restoreManifestSha256': sha(mfile), 'progressSha256': sha(pfile),
        'source228All14PoursPassed': True, 'oldBaseAndProtectedFourUnchanged': True,
        'sdkExecuted': False, 'archiveCreated': False, 'all49Accepted': False, 'fabricationReady': False}))

if __name__ == '__main__': main()
