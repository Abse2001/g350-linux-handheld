from pathlib import Path
import json,hashlib,stat,ast,copy,re,difflib
PARENT=Path('/tmp/g350-source26-cad52-concrete-proposal-metadata-successor-sourceonly-next')
OLD48=Path('/tmp/g350-source26-three-stage-batch-phase-post-held-successor-sourceonly-next')
PREP=Path('/tmp/g350-source29-parent26-qualified-activation-template-sourceonly-next')
OUT=Path('/tmp/g350-source29-three-stage-batch-future52-promotion-parsed-template-sourceonly-next')
assert not OUT.exists();OUT.mkdir(mode=0o700)
def pin(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def put(p,b):
 with p.open('xb')as f:f.write(b)
 p.chmod(0o600)
def js(p,v):put(p,(json.dumps(v,indent=2)+'\n').encode())
def nested_source(source,name):
 tree=ast.parse(source);main=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='main');node=next(n for n in main.body if isinstance(n,ast.FunctionDef)and n.name==name);return '\n'.join(source.splitlines()[node.lineno-1:node.end_lineno])+'\n'
parent=(PARENT/'run-source26-cad52-root.proposal.py').read_text();old48=(OLD48/'run-source26-capture-types-core-batch-root.proposal.py').read_text()
prefix=parent[:parent.index(" binding(proposal['cad26MainTailPin'])")]
prefix='"""Root-only Source29 serial capture/types/Core template; NULL future52/promotion gates refuse before operational imports."""\n'+prefix
prefix=prefix.replace("assert proposal['status']=='AUTHOR_DONE_SOURCE26_FRESH_CAD_AFTER_AUTHENTIC51_AND_FLAT_WRAPPER_ROOT_REVIEW_REQUIRED_UNRUN'","assert proposal['status']=='AUTHOR_DONE_SOURCE29_SERIAL_BATCH_ROOT_REVIEW_REQUIRED_UNRUN'")
gate=""" assert proposal['actual52AndSource29PromotionSealed']is True
 for key in('actual52CollectionPin','actual52PostauditPin','actual52ResultPin','actual52ResourcePin','actual52ZonePinsPin','actual52GuardManifestPin','prepared29ActivationManifestPin','promoted29ManifestPin','promoted29ModulePin','promoted29ProposalPin','promoted29CapturePin','promoted29TypesPin','promoted29CorePin'):assert isinstance(proposal[key],dict)
 for key in('actual52ToolSessionId','actual52ZonePgid','actual52CadPgid','actual52GuardPid'):assert type(proposal[key])is int
 assert isinstance(proposal['actual52ContainerName'],str)
"""
needle=" proposal=read(PACKET/'SOURCE-manifest.json')\n";assert prefix.count(needle)==1;prefix=prefix.replace(needle,needle+gate)
read29=""" prepared29=read(proposal['prepared29ActivationManifestPin']['path']);promoted29=read(proposal['promoted29ManifestPin']['path']);data29=read(proposal['promoted29ProposalPin']['path']);batch29=read(proposal['source29BatchContractPin']['path'])
 assert batch29['requiredPriorScopeCount']==52 and batch29['orderedPhases']==['capture','types','core']and batch29['sharedReserveBytes']==1073741824
"""
needle=' no_git_redirects()\n';assert prefix.count(needle)==1;prefix=prefix.replace(needle,read29+needle)
needle='cad26_contract,cad26_wrapper,cad26_concrete_copies,read(gm[';assert prefix.count(needle)==1;prefix=prefix.replace(needle,'cad26_contract,cad26_wrapper,cad26_concrete_copies,prepared29,promoted29,data29,batch29,read(gm[')
needle="  for row in base['symlinkContracts']:\n";assert prefix.count(needle)==1
bind29="""  assert promoted29['parent181HeldSourceBindings']==prepared29['parent181HeldSourceBindings']==promoted26['expandedHeldSourceAndControllerClosure']
  closure29=promoted29['expandedHeldSourceAndControllerClosure'];assert len(closure29)==promoted29['expandedHeldSourceAndControllerClosureCount']==186
  held29={r['path']:r for r in closure29};assert len(held29)==186 and all(held29[r['path']]==r for r in promoted26['expandedHeldSourceAndControllerClosure'])
  target29=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-source29-joint7-ca6-ca18-reset-editable-source-stages-sourceonly-next')
  prior29_paths={r['path']for r in promoted26['expandedHeldSourceAndControllerClosure']};additions29=[r for r in closure29 if r['path']not in prior29_paths];prepared29_by_name={Path(r['path']).name:r for r in prepared29['files']}
  assert len(additions29)==5 and {Path(r['path']).name for r in additions29}=={'source29.circuit.tsx','source29-proposal.json','source29-types.ts','capture-source29.ts','render-source29-core.ts'}
  for row in additions29:assert Path(row['path']).parent==target29 and {k:row[k]for k in('sha256','bytes','mode')}=={k:prepared29_by_name[Path(row['path']).name][k]for k in('sha256','bytes','mode')}
  for key,name in(('promoted29ModulePin','source29.circuit.tsx'),('promoted29ProposalPin','source29-proposal.json'),('promoted29CapturePin','capture-source29.ts'),('promoted29CorePin','render-source29-core.ts')):assert proposal[key]in additions29 and Path(proposal[key]['path']).name==name
  assert Path(proposal['promoted29TypesPin']['path'])==target29/'typecheck-source29.sh'and {k:proposal['promoted29TypesPin'][k]for k in('sha256','bytes','mode')}=={k:prepared29_by_name['typecheck-source29.sh'][k]for k in('sha256','bytes','mode')}
  assert promoted29['source29ProposalPin']==proposal['promoted29ProposalPin']and promoted29['source29ModulePin']==proposal['promoted29ModulePin']and promoted29['captureWorkerPin']==proposal['promoted29CapturePin']and promoted29['coreWorkerPin']==proposal['promoted29CorePin']and promoted29['typecheckWorkerPin']==proposal['promoted29TypesPin']
  assert data29['promotedParent26Source']==proposal['promoted26ManifestPin']and data29['actualParent26Qualification']==proposal['actual52CollectionPin']and data29['actualParent26Stages']['cad']==proposal['actual52ResultPin']
  assert data29['parent26QualificationBindings']['collectionPins']['cad52']==proposal['actual52CollectionPin']and data29['parent26QualificationBindings']['stagePins']['cad']==proposal['actual52ResultPin']and data29['parent26QualificationBindings']['cad52Postaudit']==proposal['actual52PostauditPin']
  assert promoted29['actualParent26QualificationPin']==proposal['actual52CollectionPin']and batch29['actualParent26CadCollectionPin']==proposal['actual52CollectionPin']and batch29['promotedSource29ManifestPin']==proposal['promoted29ManifestPin']
"""
prefix=prefix.replace(needle,bind29+needle)
needle="peer['sourceManifestSha256']==proposal['cli26PreparationPin']['sha256']and peer['guardProposalManifestSha256']==source_sha and peer['decision']==cad26_contract['expectedPeerDecision']";assert prefix.count(needle)==1;prefix=prefix.replace(needle,"peer['sourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and peer['guardProposalManifestSha256']==source_sha and peer['decision']==batch29['expectedPeerDecision']")
# Keep all historical Source26 inspectors unchanged. Add separate exact-schema Source29 inspectors.
cap=nested_source(old48,'inspect_capture')
for a,b in [('def inspect_capture','def inspect29_capture'),('ACTUAL_ROOT_SOURCE26_CAPTURE_WITH_PARENT24_FULL_INVERSE','ACTUAL_ROOT_SOURCE29_CAPTURE_WITH_PARENT26_FULL_INVERSE'),('ACTUAL_SOURCE26_AND_PARENT24_BEFORE_INVERSE_ASSERTIONS','ACTUAL_SOURCE29_AND_PARENT26_BEFORE_INVERSE_ASSERTIONS'),('actualParent24DeclarationsHeld','actualParent26DeclarationsHeld'),('actualProposedSource26Tree','actualProposedSource29Tree'),('actualParent24Tree','actualParent26Tree'),("proposal['promoted26ProposalPin']","proposal['promoted29ProposalPin']"),('proposedReactElementCount=2272,previousReactElementCount=2270,genuineNewInnerPortCount=40,exactNewPortDeclarations=2,exactChangedOriginalRouteDeclarations=2,exactChangedLocalSuppressions=4','proposedReactElementCount=2278,previousReactElementCount=2272,genuineNewInnerPortCount=46,exactNewPortDeclarations=6,exactChangedOriginalRouteDeclarations=4,exactChangedLocalSuppressions=6'),('expectedPhysicalTraces=289,expectedCarrierPaths=26,missingOriginal49RequestsExpected=23','expectedPhysicalTraces=292,expectedCarrierPaths=29,missingOriginal49RequestsExpected=20'),("r['movedViaName']=='V_TI_SIGNAL_source_trace_3_0'and r['movedViaCapturedPriorIdProvenanceOnly']=='pcb_via_135'","r['movedViaName']=='V_TI_SIGNAL_source_trace_7_1'and r['movedViaCapturedPriorIdProvenanceOnly']is None "),("read(data26['inputBindings']['actualParent24Capture']['path'])","read(proposal['actual48CapturePin']['path'])"),("d['beforeCounts']['reactElements']==2270 and d['afterCounts']['reactElements']==2272","d['beforeCounts']['reactElements']==2272 and d['afterCounts']['reactElements']==2278"),('source24QualificationInherited','source26QualificationInherited')]:
 assert a in cap,a;cap=cap.replace(a,b)
cap=cap.replace("  assert d['actualParent26Tree']==", "  assert r['actualParent26CapturePin']=={k:proposal['actual48CapturePin'][k]for k in('path','sha256')}\n  assert d['actualParent26Tree']==")
cor=nested_source(old48,'inspect_core')
for a,b in [('def inspect_core','def inspect29_core'),('ROOT_FRESH_EDITABLE_SOURCE_CORE_OWNER_MOVED_227_RESET_SOURCE3_26','ROOT_FRESH_EDITABLE_SOURCE_CORE_OWNER_MOVED_227_SOURCE7_SOURCE6_SOURCE18_RESET_REPAIR_29'),("'pcb_trace':289,'source_port':1655,'pcb_port':1655","'pcb_trace':292,'source_port':1661,'pcb_port':1661"),("len(r['carriers'])==26","len(r['carriers'])==29"),("len(r['actualSourcePortMatches']['registrations'])==40 and r['expectedOriginalCarrierCount']==26 and r['expectedMissingOriginalSignalCount']==23 and r['actualNonzeroWireSegmentCount']==1001","len(r['actualSourcePortMatches']['registrations'])==46 and r['expectedOriginalCarrierCount']==29 and r['expectedMissingOriginalSignalCount']==20 and r['actualNonzeroWireSegmentCount']==1053"),('parent24ActualQualificationInherited','parent26ActualQualificationInherited'),('actualCandidateCarrierCount=26','actualCandidateCarrierCount=29')]:
 assert a in cor,a;cor=cor.replace(a,b)
extra7="""  moved7=[x for x in r['viaProjection']if x['sourceViaName']=='V_TI_SIGNAL_source_trace_7_1'];stub7=[x for x in r['signalTopProjection']if x['originalSourceTraceId']=='source_trace_7'and x['side']==1];assert len(moved7)==len(stub7)==1 and moved7[0]['passed']is stub7[0]['passed']is True
  via7=[x for x in core if x['type']=='pcb_via'and x['pcb_via_id']==moved7[0]['actualViaId']];assert len(via7)==1 and abs(via7[0]['x']+7.4)<1e-8 and abs(via7[0]['y']-7.8)<1e-8 and via7[0]['layers']==['top','inner1','inner2','bottom']and via7[0]['outer_diameter']==.4572 and via7[0]['hole_diameter']==.254
  top7=[x for x in core if x['type']=='pcb_trace'and x['pcb_trace_id']==stub7[0]['actualPcbTraceId']];assert len(top7)==1 and len(top7[0]['route'])==13 and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in top7[0]['route'])
"""
needle="  for key in('sourceNumericAndPhysicalIdsDerivedWithoutAssignment'";assert cor.count(needle)==1;cor=cor.replace(needle,extra7+needle)
consumer=Path('/tmp/source29-batch53-closed52-consumer.TEMPLATE.py').read_text()
put(OUT/'CLOSED52_PARENT26_CAD_SOURCE_ONLY_TEMPLATE.py',consumer.encode());put(OUT/'SOURCE29_CAPTURE_CORE_RESULT_INSPECTORS.py',(cap+'\n'+cor).encode())
start=old48.index(" assert out.parent==Path('/tmp')")
tail=old48[start:];tail=tail.replace('source26','source29').replace('Source26','Source29').replace('promoted26','promoted29')
tail=re.sub(r'\bbatch\b','batch29',tail)
tail=tail.replace('prior=closed47();assert prior[\'actualClosedScopeCount\']==47',"prior=closed52();assert prior['actualClosedScopeCount']==52")
tail=tail.replace('WITH47_AUTHENTIC_PRIOR_CLOSURES','WITH52_AUTHENTIC_PRIOR_CLOSURES')
tail=tail.replace("environment['G350_RESET_SOURCE3_26_SOURCE_ROOT_GUARDED']","environment['G350_SOURCE29_SOURCE_ROOT_GUARDED']").replace("environment['G350_RESET_SOURCE3_26_TYPES_ROOT_GUARDED']","environment['G350_SOURCE29_TYPES_ROOT_GUARDED']").replace("environment['G350_RESET_SOURCE3_26_CORE_ROOT_GUARDED']","environment['G350_SOURCE29_CORE_ROOT_GUARDED']")
tail=tail.replace('result=inspect_capture(paths)','result=inspect29_capture(paths)').replace('result=inspect_core(paths,capture_pin)','result=inspect29_core(paths,capture_pin)')
# Keep real batch scope string; only variable token batch is renamed above.
tail=tail.replace("phase='capture-types-core-batch29'","phase='capture-types-core-batch'")
put(OUT/'SOURCE29_SERIAL_MAIN_TAIL.py',tail.encode())
guard=prefix+consumer+'\n'+cap+'\n'+cor+'\n'+tail
ast.parse(guard);put(OUT/'run-source29-capture-types-core-batch-root.proposal.py',guard.encode())
contract=json.loads((Path(json.loads((OLD48/'SOURCE-manifest.json').read_text())['batchContractPin']['path'])).read_text())
contract.update(scope='SOURCE_ONLY_SOURCE29_CAPTURE_TYPES_CORE_SERIAL_BATCH_FUTURE52_PROMOTED186_ROOT_REVIEW_REQUIRED',requiredPriorScopeCount=52,expectedPeerDecision='GO_SOURCE_ONLY_TO_ROOT_OWNED_SOURCE29_SERIAL_CAPTURE_TYPES_CORE_AFTER_AUTHENTIC52_AND_PROMOTION',actualParent26CadCollectionPin=None,promotedSource29ManifestPin=None,actualSource29BatchCollectionPin=None,expectedActualNonzeroWireSegmentCount=1053,expectedActualCounts=dict(carrierPaths=29,physicalTraces=292,sourceAndPcbPorts=1661,innerLiteralPorts=46,ReactElements=2278,missingOriginalSignals=20),Source29Accepted=False)
for k in('actualParent24CadCollectionPin','actualParent24CadResultPin','promotedSource26ManifestPin','actualSource26BatchCollectionPin','Source26Accepted'):contract.pop(k,None)
js(OUT/'SERIAL_BATCH29_CONTRACT.json',contract)
manifest=json.loads((PARENT/'SOURCE-manifest.json').read_text())
# All inherited file references remain concrete historical bindings; this packet owns only new files.
parent_own=manifest['files'];parent_external=manifest['externalFiles']
manifest.update(scope='SOURCE_ONLY_SOURCE29_CAPTURE_TYPES_CORE_SERIAL_BATCH53_FUTURE52_AND_PROMOTION_TEMPLATE',status='AUTHOR_DONE_SOURCE29_SERIAL_BATCH_ROOT_REVIEW_REQUIRED_UNRUN',requiredPriorScopeCount=52,actual52AndSource29PromotionSealed=False,source29BatchContractPin=pin(OUT/'SERIAL_BATCH29_CONTRACT.json'),historicalCad52WalkerGuardManifestPin=pin(PARENT/'SOURCE-manifest.json'),historicalCad52WalkerGuardPin=pin(PARENT/'run-source26-cad52-root.proposal.py'),source29ActivationTemplateReferencePin=pin(PREP/'SOURCE-manifest.json'),source29Closed52ConsumerTemplatePin=pin(OUT/'CLOSED52_PARENT26_CAD_SOURCE_ONLY_TEMPLATE.py'),source29InspectorsPin=pin(OUT/'SOURCE29_CAPTURE_CORE_RESULT_INSPECTORS.py'),source29SerialMainTailPin=pin(OUT/'SOURCE29_SERIAL_MAIN_TAIL.py'),source29SegmentCountProofPin=pin('/tmp/source29-nonzero-wire-segment-source-only-proof.json'),actual52GuardManifestPin=None,actual52CollectionPin=None,actual52PostauditPin=None,actual52ResultPin=None,actual52ResourcePin=None,actual52ZonePinsPin=None,actual52ToolSessionId=None,actual52ZonePgid=None,actual52CadPgid=None,actual52GuardPid=None,actual52ContainerName=None,prepared29ActivationManifestPin=None,promoted29ManifestPin=None,promoted29ModulePin=None,promoted29ProposalPin=None,promoted29CapturePin=None,promoted29TypesPin=None,promoted29CorePin=None,cadOnly=False,captureTypesCoreOnly=True,actualSource29BatchCollectionPin=None,Source29Accepted=False,actualClosedSdkScopeCountRemains=51,plannedFirstActualSdkScopeRemains=52,RootAuthorityCreated=False,guardHelperSdkProcessOrWorkerExecutedByAuthor=False)
manifest['guardPin']=pin(OUT/'run-source29-capture-types-core-batch-root.proposal.py')
# Preserve inherited current status claims only as history: new runtime flags stay explicitly false/null.
manifest['actualCad52RootReceipt']=None;manifest['actualCad52Report']=None
put(OUT/'README.md',b'Source-only, unexecuted Source29 serial capture/types/Core batch53 template. It refuses before operational imports while actual52AndSource29PromotionSealed is false or any future authentic CAD52/activated/promoted29 pin is unset. Historical through51 consumers and Source26 inspectors are retained. Three serial children reuse successful48 policies and failure handling. New Source29 inspectors enforce the full source inverse, all29 original Core controls,1053 derived nonzero segments, and true fresh via135/Source7 owner geometry. Parent26 partial geometry qualification never implies full49, reference, electrical, or fabrication qualification. No runtime authority is created. A newly sealed concrete successor and independent peer are required after Root actual52 collection and Source29 promotion.\n')
proof=dict(scope='SOURCE_ONLY_SERIAL48_TO_SOURCE29_BATCH53_TEMPLATE_PROOF',parentCad52GuardPin=pin(PARENT/'run-source26-cad52-root.proposal.py'),serial48GuardPin=pin(OLD48/'run-source26-capture-types-core-batch-root.proposal.py'),prepared29ActivationTemplatePin=pin(PREP/'SOURCE-manifest.json'),allInheritedHistoryFunctionsAndSource26InspectorsByteExact=True,onlyMainBindingsAndNew52ConsumerNew29InspectorsAndSerial48TailAdapted=True,guardAstParsed=True,expectedNonzeroWireSegments=1053,countsSourceOnlyProofPin=pin('/tmp/source29-nonzero-wire-segment-source-only-proof.json'),actual52AllPinsUnset=True,actualPromoted29AllPinsUnset=True,guardRefusesBeforeOperationalImports=True,guardOrSdkOrHelperImportedOrEvaluated=False,workspaceWrites=False,runtimeAuthorityCreated=False,Source29Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingPassed=False,fabricationReady=False)
# Verify every inherited nested function other than current binding closure is literally unchanged.
pn=next(n for n in ast.parse(parent).body if isinstance(n,ast.FunctionDef)and n.name=='main');gn=next(n for n in ast.parse(guard).body if isinstance(n,ast.FunctionDef)and n.name=='main');gd={n.name:n for n in gn.body if isinstance(n,ast.FunctionDef)};held=[]
for n in pn.body:
 if isinstance(n,ast.FunctionDef)and n.name!='bindings':
  assert ast.get_source_segment(parent,n)==ast.get_source_segment(guard,gd[n.name]);held.append(n.name)
proof['inheritedNestedFunctionsByteExact']=held
js(OUT/'SOURCE_ONLY_BATCH53_TEMPLATE_PROOF.json',proof)
put(OUT/'EXACT_CAD52_TO_BATCH53_SOURCE_DELTA.patch',''.join(difflib.unified_diff(parent.splitlines(True),guard.splitlines(True),fromfile='d91b-cad52-parent',tofile='source29-batch53-future-template')).encode())
manifest['files']=[pin(p)for p in sorted(OUT.iterdir())if p.is_file()]
extras=[*parent_own,*parent_external,pin(PARENT/'SOURCE-manifest.json'),pin(PREP/'SOURCE-manifest.json'),pin(OLD48/'SOURCE-manifest.json'),pin(OLD48/'run-source26-capture-types-core-batch-root.proposal.py'),pin('/tmp/source29-batch53-closed52-consumer.TEMPLATE.py'),pin('/tmp/source29-nonzero-wire-segment-source-only-proof.json'),pin(Path(__file__))]
by={}
for r in extras:
 assert r['path']not in by or by[r['path']]==r;by[r['path']]=r
manifest['externalFiles']=list(by.values());manifest['ownFileCountExcludingManifest']=len(manifest['files']);manifest['externalFileCount']=len(manifest['externalFiles'])
js(OUT/'SOURCE-manifest.json',manifest)
print(json.dumps(dict(manifest=pin(OUT/'SOURCE-manifest.json'),guard=pin(OUT/'run-source29-capture-types-core-batch-root.proposal.py'),consumer=pin(OUT/'CLOSED52_PARENT26_CAD_SOURCE_ONLY_TEMPLATE.py'),inspectors=pin(OUT/'SOURCE29_CAPTURE_CORE_RESULT_INSPECTORS.py'),tail=pin(OUT/'SOURCE29_SERIAL_MAIN_TAIL.py'),contract=pin(OUT/'SERIAL_BATCH29_CONTRACT.json'),inheritedFunctions=len(held),own=len(manifest['files']),external=len(manifest['externalFiles'])),indent=2))
