import { finishSurfaceTiming } from "./finish-surface-timing"
import { insertNativeSurfaceSignal } from "./insert-native-surface-signal"
import { surfaceBusShortcutCandidates } from "./surface-bus-shortcuts"
import { insertSurfaceSignal } from "./insert-surface-signal"
import { surfaceBridgeEligible } from "./route-surface-bridge"
import { routeAlternateSignalDogbones } from "./alternate-signal-dogbones"
import { CopperConflictIndex } from "./copper-conflict-index"
import { generatedEscapeHolesConflict } from "./expanded-signal-sites"
import {
  expandSignalSitePocket,
  findViaAwareSignalPocket,
} from "./find-signal-site-pocket"
import { signalLayers, type FlexibleSignalState } from "./flexible-signal-state"
import {
  negotiateSignalSites,
  type DeferredCarrierExpansion,
  type SignalSiteDomainFailure,
} from "./negotiate-signal-sites"
import {
  deriveSelectiveNativeApproachGuide,
  type NativeApproachGuide,
} from "./selective-native-approach-guidance"
import { negotiateSurfaceRoutes } from "./negotiate-surface-routes"
import { pairCouplingReports } from "./pair-coupling"
import { prepareSurfaceTimingBanks } from "./prepare-surface-timing-banks"
import {
  isProvisionalPairPlan,
  planSharedPairCorridors,
} from "./plan-shared-pair-corridors"
import { retargetGeneratedEscape } from "./retarget-generated-escape"
import {
  ownedSignalEscapes,
  signalDogboneOptions,
  type RepairedBusDogbones,
} from "./repair-bus-dogbones"
import { runBoundedRouting } from "./run-bounded-routing"
import { fixedCopper } from "./vector-scene"
import { viaCountConstraintsEnabled } from "./via-count-constraints"
import type { SimpleRouteJson, SolverOptions, Trace, Wire } from "./types"

export interface SurfaceRoutingSeed {
  phase: "timing" | "controls"
  state: FlexibleSignalState
  controlOrdersComplete?: boolean
}
export interface SurfaceSeedOptions {
  maxControlAttempts?: number
  maxControlIterations?: number
}

export const MAX_SELECTIVE_NATIVE_APPROACH_GUIDE_EVENTS = 24

/** Validate the producer's completed finite AC certificate and its full causal
 * closure. This describes offered sites, never native physical infeasibility. */
function certifiedNativeSiteCore(
  failure: SignalSiteDomainFailure | undefined,
): Set<string> | undefined {
  if (
    !failure ||
    failure.viaCountConstraints !== undefined ||
    failure.kind !== "incompatible-offered-native-site-domains" ||
    failure.searchComplete !== true ||
    failure.budgetUnknown !== false ||
    !Array.isArray(failure.domains) ||
    !failure.domains.length ||
    !Array.isArray(failure.names) ||
    !failure.names.length ||
    failure.proof?.kind !== "arc-consistency"
  )
    return undefined
  const domains = failure.domains
  if (
    domains.some(
      (domain) =>
        !domain ||
        typeof domain.name !== "string" ||
        !domain.name ||
        !Array.isArray(domain.options) ||
        !domain.options.length ||
        domain.options.some(
          (option) =>
            !option ||
            !Array.isArray(option.escapes) ||
            !option.escapes.length ||
            !Array.isArray(option.escapeCopper),
        ),
    )
  )
    return undefined
  const domainNames = new Set(domains.map((domain) => domain.name))
  if (domainNames.size !== domains.length) return undefined
  const { removals, implicatedRemovals, emptyDomain, unsupportedBy } =
    failure.proof
  const validDomain = (index: number) =>
    Number.isInteger(index) && index >= 0 && index < domains.length
  if (
    !Array.isArray(removals) ||
    !removals.length ||
    !Array.isArray(implicatedRemovals) ||
    !implicatedRemovals.length ||
    !validDomain(emptyDomain) ||
    !validDomain(unsupportedBy)
  )
    return undefined
  const remaining = domains.map((domain) =>
    domain.options.map((_, index) => index),
  )
  for (let index = 0; index < removals.length; index++) {
    const removal = removals[index]
    if (
      !removal ||
      !validDomain(removal.first) ||
      !validDomain(removal.second) ||
      removal.first === removal.second ||
      !Array.isArray(removal.removed) ||
      !removal.removed.length ||
      !Array.isArray(removal.support) ||
      !removal.support.length ||
      JSON.stringify(removal.support) !==
        JSON.stringify(remaining[removal.second]) ||
      new Set(removal.removed).size !== removal.removed.length ||
      removal.removed.some(
        (option) =>
          !Number.isInteger(option) ||
          !remaining[removal.first].includes(option),
      )
    )
      return undefined
    remaining[removal.first] = remaining[removal.first].filter(
      (option) => !removal.removed.includes(option),
    )
    const last = index === removals.length - 1
    if (
      last
        ? removal.first !== emptyDomain ||
          removal.second !== unsupportedBy ||
          remaining[removal.first].length !== 0
        : remaining[removal.first].length === 0
    )
      return undefined
  }
  // Match the producer's conservative closure, including every earlier
  // elimination of a variable or of its supporting variable. The last arc
  // alone can omit the deferred variable that caused support to disappear.
  const implicated = new Set<number>()
  const visit = (index: number) => {
    if (implicated.has(index)) return
    implicated.add(index)
    const removal = removals[index]
    for (let earlier = 0; earlier < index; earlier++)
      if (
        removals[earlier].first === removal.first ||
        removals[earlier].first === removal.second
      )
        visit(earlier)
  }
  visit(removals.length - 1)
  const closure = [...implicated]
    .sort((a, b) => a - b)
    .map((index) => removals[index])
  if (JSON.stringify(closure) !== JSON.stringify(implicatedRemovals))
    return undefined
  const coreNames = new Set(
    closure.flatMap((removal) => [
      domains[removal.first].name,
      domains[removal.second].name,
    ]),
  )
  if (
    new Set(failure.names).size !== failure.names.length ||
    coreNames.size !== failure.names.length ||
    failure.names.some((name) => !coreNames.has(name))
  )
    return undefined
  return coreNames
}

/** An unchanged contradictory native-site core cannot be repaired by widening
 * unrelated domains. Incomplete metadata or a partial certificate keeps the
 * existing expanded retry; this is never a native infeasibility assertion. */
export function shouldRetryDeferredCarrierExpansion(
  failure: SignalSiteDomainFailure | undefined,
  deferred: readonly DeferredCarrierExpansion[] | undefined,
): boolean {
  const coreNames = certifiedNativeSiteCore(failure)
  if (!coreNames || !Array.isArray(deferred) || !deferred.length) return true
  if (failure?.kind !== "incompatible-offered-native-site-domains") return true
  const domainNames = new Set(failure.domains.map((domain) => domain.name))
  if (
    deferred.some(
      (entry) =>
        !entry ||
        typeof entry.connectionName !== "string" ||
        !domainNames.has(entry.connectionName) ||
        typeof entry.layer !== "string" ||
        !entry.layer,
    )
  )
    return true
  return deferred.some((entry) => coreNames.has(entry.connectionName))
}

/** Cheap reachability is unary. After a completed joint contradiction, wider
 * sites are tried only for eligible carrier banks in the validated causal core. */
export function reachableSiteExpansionRetryTargets(
  failure: SignalSiteDomainFailure | undefined,
): readonly DeferredCarrierExpansion[] {
  const coreNames = certifiedNativeSiteCore(failure)
  if (
    !coreNames ||
    failure?.kind !== "incompatible-offered-native-site-domains"
  )
    return []
  const deferred = failure.deferredReachableSiteExpansions
  if (!Array.isArray(deferred)) return []
  const domains = new Map(
    failure.domains.map((domain) => [domain.name, domain]),
  )
  if (
    deferred.some(
      (entry) =>
        !entry ||
        typeof entry.connectionName !== "string" ||
        !domains.has(entry.connectionName) ||
        typeof entry.layer !== "string" ||
        !entry.layer ||
        !domains
          .get(entry.connectionName)!
          .options.some((option) =>
            option.escapes.every(
              (escape) =>
                Array.isArray(escape?.route) &&
                escape.route.at(-1)?.route_type === "wire" &&
                (escape.route.at(-1) as Wire).layer === entry.layer,
            ),
          ),
    )
  )
    return []
  return deferred.filter((entry) => coreNames.has(entry.connectionName))
}

/** Choose fresh surface sites before committing independent control dogbones.
 * Complete results still pass matching and physical coupling; partial computed
 * seeds expose compatible copper to a later joint surface negotiation. */
export function* routeFreshSurfaceBuses(
  native: SimpleRouteJson,
  allocation: SimpleRouteJson,
  originalEscapes: Trace[],
  terminalLayers: ReadonlyMap<string, string[]>,
  options: SolverOptions,
): Generator<void, RepairedBusDogbones | null> {
  const seeds = routeFreshSurfaceSeeds(
    native,
    allocation,
    originalEscapes,
    terminalLayers,
    options,
  )
  let next = seeds.next()
  let matchedTiming: FlexibleSignalState | undefined
  try {
    while (!next.done) {
      const candidate = next.value
      if (candidate?.phase === "timing") {
        matchedTiming = candidate.state
      }
      if (
        candidate &&
        carrierCount(candidate.state) === native.connections.length
      ) {
        const finished = yield* finishSurfaceTiming(candidate.state, options, {
          preserveTiming: true,
        })
        if (finished)
          return {
            input: finished.pending,
            traces: [...finished.retained, ...finished.traces],
            escapes: finished.escapes,
          }
      }
      if (candidate?.controlOrdersComplete) {
        if (matchedTiming) {
          const timing = yield* prepareSurfaceTimingBanks(
            native,
            candidate.state,
            matchedTiming,
            { solverOptions: options },
          )
          if (timing) {
            const joint = yield* negotiateSurfaceRoutes(
              native,
              mergeTimingCheckpoint(native, candidate.state, timing),
              {
                frozenConnectionNames: new Set(
                  native.buses?.flatMap((bus) => bus.connectionNames),
                ),
              },
            )
            if (joint) {
              const finished = yield* finishSurfaceTiming(joint, options, {
                preserveTiming: true,
              })
              if (finished)
                return {
                  input: finished.pending,
                  traces: [...finished.retained, ...finished.traces],
                  escapes: finished.escapes,
                }
            }
          }
        }
        const joint = yield* negotiateSurfaceRoutes(native, candidate.state)
        if (joint) {
          const finished = yield* finishSurfaceTiming(joint, options, {
            preserveTiming: true,
          })
          if (finished)
            return {
              input: finished.pending,
              traces: [...finished.retained, ...finished.traces],
              escapes: finished.escapes,
            }
        }
      }
      yield
      next = seeds.next()
    }
  } finally {
    if (!next.done) seeds.return(null)
  }
  return null
}

/** Keep computed untimed choices as candidates while replacing complete owned
 * timing tuples. The joint negotiator rechecks those controls against the new
 * timing copper before admitting them to its candidate pool. */
function mergeTimingCheckpoint(
  native: SimpleRouteJson,
  previous: FlexibleSignalState,
  timing: FlexibleSignalState,
): FlexibleSignalState {
  const timingNames = new Set(
    timing.native.connections.map((connection) => connection.name),
  )
  const untimed = [...previous.retained, ...previous.traces].filter(
    (trace) => !timingNames.has(trace.connection_name!),
  )
  const carriers = [...timing.retained, ...timing.traces, ...untimed]
  const escapes = [
    ...timing.escapes,
    ...previous.escapes.filter(
      (trace) => !timingNames.has(trace.connection_name!),
    ),
  ]
  return {
    native,
    pending: carrierInput(native, carriers, escapes),
    escapes,
    retained: timing.retained,
    traces: [...timing.traces, ...untimed],
  }
}

/** Emit a strictly matched timing checkpoint before controls, then compatible
 * control prefixes after each ordering pass. Preserve the greatest computed
 * partial so a failed insertion does not discard its physical route choices. */
export function* routeFreshSurfaceSeeds(
  native: SimpleRouteJson,
  allocation: SimpleRouteJson,
  originalEscapes: Trace[],
  terminalLayers: ReadonlyMap<string, string[]>,
  options: SolverOptions,
  seedOptions: SurfaceSeedOptions = {},
): Generator<void | SurfaceRoutingSeed, FlexibleSignalState | null> {
  const busNames = new Set(native.buses?.flatMap((bus) => bus.connectionNames))
  const pairNames = new Set(
    native.differentialPairs?.flatMap((pair) => pair.connectionNames),
  )
  const timingNames = new Set(busNames)
  for (const pair of native.differentialPairs ?? [])
    if (pair.connectionNames.some((name) => busNames.has(name)))
      for (const name of pair.connectionNames) timingNames.add(name)
  const timing = scopeInput(native, timingNames)
  const timingPairs = new Set(
    timing.differentialPairs?.flatMap((pair) => pair.connectionNames),
  )
  const controls = native.connections.filter(
    (connection) =>
      !timingNames.has(connection.name) && !pairNames.has(connection.name),
  )
  const firstNativeControl = controls.find((connection) =>
    surfaceBridgeEligible(native, connection),
  )
  const pairEscapes = originalEscapes.filter((trace) =>
    timingPairs.has(trace.connection_name!),
  )
  const ordinaryNames = new Set(
    timing.connections
      .filter((connection) => !timingPairs.has(connection.name))
      .map((connection) => connection.name),
  )
  const timingAllocation: SimpleRouteJson = {
    ...timing,
    connections: allocation.connections.filter((connection) =>
      timingNames.has(connection.name),
    ),
    traces: [...(native.traces ?? []), ...pairEscapes],
  }
  const plans = priorityPairPlans(
    timingAllocation,
    terminalLayers,
    ...((options.precheckEnclosedTerminals === true ? [[], options] : []) as [
      Trace[]?,
      Pick<SolverOptions, "precheckEnclosedTerminals">?,
    ]),
  )
  const guides: NativeApproachGuide[] = []
  let guideEvents = 0
  let plan = plans.next()
  let greatest: FlexibleSignalState | null = null
  try {
    while (!plan.done) {
      if (!plan.value) {
        yield
        plan = plans.next()
        continue
      }
      const paired: Trace[] = plan.value
      const selectedEscapes = pairEscapes.map((escape) => {
        const carrier = paired.find(
          (trace) => trace.connection_name === escape.connection_name,
        )!
        return retargetGeneratedEscape(escape, (carrier.route[0] as Wire).layer)
      })
      let state: FlexibleSignalState | null = {
        native: timing,
        pending: {
          ...timingAllocation,
          connections: timingAllocation.connections.filter((connection) =>
            ordinaryNames.has(connection.name),
          ),
          traces: [...(native.traces ?? []), ...selectedEscapes, ...paired],
        },
        escapes: selectedEscapes,
        retained: paired,
        traces: [],
      }
      const guidanceState = state
      let domainFailure: SignalSiteDomainFailure | undefined
      let deferredCarrierExpansion = false
      let deferredCarrierExpansions:
        | readonly DeferredCarrierExpansion[]
        | undefined
      let deferredFineNativeApproachRetry = false
      if (ordinaryNames.size) {
        const siteOptions = {
          ...(options.maxBusViaCountSkew !== undefined
            ? { maxBusViaCountSkew: options.maxBusViaCountSkew }
            : {}),
          ...(options.maxPairViaCountSkew !== undefined
            ? { maxPairViaCountSkew: options.maxPairViaCountSkew }
            : {}),
          allowExpandedSites: true,
          expandOnlyWhenBlocked: true,
          maxCandidateSearchNodes: 12000,
          onSiteDomainFailure: (failure: SignalSiteDomainFailure) => {
            domainFailure = failure
          },
        }
        const attemptLimit =
          paired.length && !isProvisionalPairPlan(paired) ? 250000 : 1500000
        function* attempt(
          allowFineNativeApproachRetry: boolean,
          deferAlternateCarrierExpansion: boolean,
          retryReachableSiteExpansions?: readonly DeferredCarrierExpansion[],
        ): Generator<void, FlexibleSignalState | null> {
          domainFailure = undefined
          deferredCarrierExpansion = false
          deferredCarrierExpansions = undefined
          deferredFineNativeApproachRetry = false
          return yield* runBoundedRouting(
            negotiateSignalSites(guidanceState, ordinaryNames, false, false, {
              ...siteOptions,
              allowFineNativeApproachRetry,
              ...(retryReachableSiteExpansions?.length
                ? { retryReachableSiteExpansions }
                : {}),
              ...(deferAlternateCarrierExpansion
                ? { deferAlternateCarrierExpansion: true }
                : {}),
              onDeferredCarrierExpansion: (deferred) => {
                deferredCarrierExpansion = true
                deferredCarrierExpansions = deferred
              },
              onDeferredFineNativeApproachRetry: () => {
                deferredFineNativeApproachRetry = true
              },
            }),
            attemptLimit,
          )
        }
        let fineAllowed = false
        state = yield* attempt(false, true)
        if (!state && deferredFineNativeApproachRetry) {
          fineAllowed = true
          state = yield* attempt(true, true)
        }
        const reachableSiteTargets = !state
          ? reachableSiteExpansionRetryTargets(domainFailure)
          : []
        const retryDeferredCarrier =
          !state &&
          deferredCarrierExpansion &&
          shouldRetryDeferredCarrierExpansion(
            domainFailure,
            deferredCarrierExpansions,
          )
        if (!state && (retryDeferredCarrier || reachableSiteTargets.length)) {
          // Keep the cheap successful path and the existing bounded retry
          // stages. Unary reachability may still need wider same-carrier sites
          // after a complete joint contradiction; unrelated carriers retain
          // the certified disjoint-core skip and the blocked-only policy.
          state = yield* attempt(
            fineAllowed,
            !retryDeferredCarrier,
            reachableSiteTargets,
          )
          if (!state && deferredFineNativeApproachRetry)
            state = yield* attempt(
              true,
              !retryDeferredCarrier,
              reachableSiteTargets,
            )
        }
      }
      if (!state) {
        const derived =
          domainFailure &&
          !viaCountConstraintsEnabled(
            domainFailure.viaCountConstraints ?? {},
          ) &&
          guideEvents < MAX_SELECTIVE_NATIVE_APPROACH_GUIDE_EVENTS
            ? deriveSelectiveNativeApproachGuide(
                guidanceState,
                domainFailure,
                originalEscapes,
                guides,
                { physicalInput: native },
              )
            : undefined
        if (derived?.guide) {
          const existing = guides.findIndex(
            (guide) => guide.key === derived.guide!.key,
          )
          if (existing < 0) guides.push(derived.guide)
          else guides[existing] = derived.guide
          guideEvents++
          plan = plans.next({
            kind: "native-approach-guidance",
            guides: guides.map((guide) => guide.trace),
          })
        } else plan = plans.next()
        continue
      }
      if (firstNativeControl) {
        state =
          native.allowedLayers?.length === 1
            ? yield* insertOrdinarySignal(
                native,
                allocation,
                state,
                firstNativeControl.name,
                false,
              )
            : yield* insertNativeSurfaceSignal(
                native,
                state,
                firstNativeControl.name,
              )
        if (!state) {
          plan = plans.next()
          continue
        }
      }
      for (const pair of native.differentialPairs ?? []) {
        if (pair.connectionNames.every((name) => timingNames.has(name)))
          continue
        state = yield* insertFreshPair(
          native,
          state,
          pair,
          ...(options.precheckEnclosedTerminals === true
            ? ([options] as const)
            : ([] as const)),
        )
        if (!state) break
      }
      if (!state) {
        plan = plans.next()
        continue
      }
      const shortcuts = yield* surfaceBusShortcutCandidates(state)
      // A shorter candidate may consume its own tuning corridor. Each actual
      // checkpoint is finished independently before controls occupy that space.
      for (const checkpoint of shortcuts.toReversed()) {
        const finished = yield* finishSurfaceTiming(checkpoint, options)
        if (!finished) continue
        if (!greatest || carrierCount(finished) > carrierCount(greatest))
          greatest = finished
        yield { phase: "timing", state: finished }
        const controlWork = insertSurfaceControlCandidates(
          native,
          allocation,
          finished,
          controls.map((connection) => connection.name),
          {
            maxAttempts: seedOptions.maxControlAttempts ?? 3,
            maxIterations: seedOptions.maxControlIterations,
            allowPocketRepair: false,
          },
        )
        let control = controlWork.next()
        try {
          while (!control.done) {
            if (control.value) {
              const candidate = control.value.state
              if (!greatest || carrierCount(candidate) > carrierCount(greatest))
                greatest = candidate
              if (
                control.value.completedOrder ||
                carrierCount(candidate) === native.connections.length
              )
                yield { phase: "controls", state: candidate }
            } else yield
            control = controlWork.next()
          }
          if (control.value) {
            if (
              !greatest ||
              carrierCount(control.value) > carrierCount(greatest)
            )
              greatest = control.value
            yield {
              phase: "controls",
              state: control.value,
              controlOrdersComplete: true,
            }
          }
          if (
            control.value &&
            carrierCount(control.value) === native.connections.length
          )
            return control.value
        } finally {
          if (!control.done) controlWork.return(finished)
        }
      }
      plan = plans.next()
    }
  } finally {
    if (!plan.done) plans.return(undefined)
  }
  return greatest
}

function carrierCount(state: FlexibleSignalState) {
  return state.retained.length + state.traces.length
}

export type PairPlanFeedback =
  | boolean
  | { kind: "native-approach-guidance"; guides: readonly Trace[] }

export function* priorityPairPlans(
  allocation: SimpleRouteJson,
  terminalLayers: ReadonlyMap<string, string[]>,
  nativeApproachGuides: Trace[] = [],
  searchOptions?: Pick<SolverOptions, "precheckEnclosedTerminals">,
): Generator<Trace[] | undefined, void, PairPlanFeedback | undefined> {
  const layers = new Map(
    allocation.connections.map((connection) => {
      const preferred = connection.pointsToConnect[0].layer
      const available = terminalLayers.get(connection.name) ?? [preferred]
      return [
        connection.name,
        [...new Set([preferred, ...available])].filter((layer) =>
          available.includes(layer),
        ),
      ] as const
    }),
  )
  const preferredLayers = new Map(
    allocation.connections.map((connection) => {
      const preferred = connection.pointsToConnect[0].layer
      return [
        connection.name,
        (layers.get(connection.name) ?? []).filter(
          (layer) =>
            layer === preferred &&
            (!allocation.allowedLayers ||
              allocation.allowedLayers.includes(layer)),
        ),
      ] as const
    }),
  )
  const pairs = allocation.differentialPairs ?? []
  const commonPreferred =
    pairs.length > 0 &&
    pairs.every((pair) => {
      const [first, ...others] = pair.connectionNames
      return preferredLayers
        .get(first)
        ?.some((layer) =>
          others.every((name) => preferredLayers.get(name)?.includes(layer)),
        )
    })
  // Probe the first reserved and ordinary preferred topologies before a faster
  // alternate can commit ordinary lanes. A blocked preference must not exhaust
  // the topology bank: every compatible carrier follows cooperatively.
  const original = (function* () {
    if (commonPreferred)
      yield* planSharedPairCorridors(allocation, preferredLayers, true, {
        preferPackageOnlyTuning: true,
        maxTopologyVariants: 2,
        ...(searchOptions?.precheckEnclosedTerminals === true
          ? { precheckEnclosedTerminals: true }
          : {}),
      })
    yield* planSharedPairCorridors(allocation, layers, true, {
      preferPackageOnlyTuning: true,
      ...(searchOptions?.precheckEnclosedTerminals === true
        ? { precheckEnclosedTerminals: true }
        : {}),
    })
  })()
  let active: Generator<Trace[] | undefined, void> = original
  let next = active.next()
  let guidedTried = false
  let selectiveAttempts = 0
  const offered = new Set<string>()
  try {
    while (true) {
      if (next.done) {
        if (active === original) break
        active = original
        next = active.next()
        continue
      }
      if (next.value && active === original) {
        const key = JSON.stringify([
          isProvisionalPairPlan(next.value),
          next.value,
        ])
        if (offered.has(key)) {
          next = active.next()
          continue
        }
        offered.add(key)
      }
      const ordinaryFailed = yield next.value
      const selective =
        typeof ordinaryFailed === "object" &&
        ordinaryFailed.kind === "native-approach-guidance"
          ? ordinaryFailed.guides
          : undefined
      const legacy =
        ordinaryFailed === true && !guidedTried && nativeApproachGuides.length
      if (
        (selective?.length &&
          selectiveAttempts < MAX_SELECTIVE_NATIVE_APPROACH_GUIDE_EVENTS) ||
        legacy
      ) {
        if (selective) selectiveAttempts++
        else guidedTried = true
        if (active !== original) active.return(undefined)
        // Selective feedback searches the existing topology bank with the
        // accumulated guides. A two-variant prefix can exhaust while a later
        // family still clears the protected approaches. The original stream
        // resumes after exhaustion; selected escapes and output never inherit
        // this transient hard copper. Existing boolean callers keep one probe.
        active = planSharedPairCorridors(
          {
            ...allocation,
            traces: [
              ...(allocation.traces ?? []),
              ...(selective ?? nativeApproachGuides),
            ],
          },
          layers,
          true,
          {
            preferPackageOnlyTuning: true,
            maxTopologyVariants: selective ? undefined : 1,
            ...(searchOptions?.precheckEnclosedTerminals === true
              ? { precheckEnclosedTerminals: true }
              : {}),
          },
        )
        next = active.next()
        continue
      }
      next = active.next()
    }
  } finally {
    if (!next.done) active.return(undefined)
    if (active !== original) original.return(undefined)
  }
}

/** Derive transient guidance exclusively from solver-owned ordinary native
 * approaches. Supplied copper, paired approaches, via lands and carrier wires
 * are never part of this additional search preference. */
export function ordinaryNativeApproachGuides(
  native: SimpleRouteJson,
  originalEscapes: Trace[],
  ordinaryNames: ReadonlySet<string>,
): Trace[] {
  const suppliedIds = new Set(native.traces?.map((trace) => trace.pcb_trace_id))
  const pairedNames = new Set(
    native.differentialPairs?.flatMap((pair) => pair.connectionNames),
  )
  return originalEscapes.flatMap((escape) => {
    const name = escape.connection_name
    const viaIndex = escape.route.findIndex(
      (point) => point.route_type === "via",
    )
    const first = escape.route[0]
    if (
      !name ||
      !ordinaryNames.has(name) ||
      pairedNames.has(name) ||
      suppliedIds.has(escape.pcb_trace_id) ||
      viaIndex < 1 ||
      first?.route_type !== "wire"
    )
      return []
    const connection = native.connections.find(
      (candidate) => candidate.name === name,
    )
    if (
      !connection?.pointsToConnect.some(
        (point) =>
          point.layer === first.layer &&
          Math.hypot(point.x - first.x, point.y - first.y) < 1e-8,
      )
    )
      return []
    const prefix = escape.route.slice(0, viaIndex)
    if (
      prefix.some(
        (point) => point.route_type !== "wire" || point.layer !== first.layer,
      )
    )
      return []
    return [
      {
        ...escape,
        route: prefix.map((point) => ({ ...point })),
        curvedSegments: undefined,
        coupledSection: undefined,
      },
    ]
  })
}

function scopeInput(
  input: SimpleRouteJson,
  names: ReadonlySet<string>,
): SimpleRouteJson {
  return {
    ...input,
    connections: input.connections.filter((connection) =>
      names.has(connection.name),
    ),
    buses: input.buses?.filter((bus) =>
      bus.connectionNames.every((name) => names.has(name)),
    ),
    differentialPairs: input.differentialPairs?.filter((pair) =>
      pair.connectionNames.every((name) => names.has(name)),
    ),
  }
}

function carrierInput(
  native: SimpleRouteJson,
  traces: Trace[],
  escapes: Trace[],
): SimpleRouteJson {
  const byName = new Map(traces.map((trace) => [trace.connection_name, trace]))
  return {
    ...native,
    connections: native.connections.map((connection) => {
      const trace = byName.get(connection.name)
      return trace
        ? {
            ...connection,
            pointsToConnect: [trace.route[0], trace.route.at(-1)!] as Wire[],
          }
        : connection
    }),
    traces: [...(native.traces ?? []), ...escapes],
  }
}

export interface SurfaceControlCandidate {
  state: FlexibleSignalState
  completedOrder: boolean
}

/** Preserve compatible partial progress under an explicit insertion budget.
 * Each ordering attempt still starts from the unchanged timing checkpoint. */
export function* insertSurfaceControlCandidates(
  full: SimpleRouteJson,
  allocation: SimpleRouteJson,
  previous: FlexibleSignalState,
  names: string[],
  options: {
    maxAttempts?: number
    maxIterations?: number
    allowPocketRepair?: boolean
  } = {},
): Generator<void | SurfaceControlCandidate, FlexibleSignalState> {
  const work = surfaceControlCandidates(
    full,
    allocation,
    previous,
    names,
    options.maxAttempts ?? 5,
    options.allowPocketRepair ?? true,
  )
  let next = work.next()
  let greatest = previous
  let iterations = 0
  try {
    while (!next.done && iterations++ < (options.maxIterations ?? Infinity)) {
      if (next.value && carrierCount(next.value.state) > carrierCount(greatest))
        greatest = next.value.state
      yield next.value
      next = work.next()
    }
    if (next.done && carrierCount(next.value) > carrierCount(greatest))
      greatest = next.value
    return greatest
  } finally {
    if (!next.done) work.return(greatest)
  }
}

/** Complete-only compatibility wrapper for callers that do not consume seeds. */
export function* insertSurfaceControls(
  full: SimpleRouteJson,
  allocation: SimpleRouteJson,
  previous: FlexibleSignalState,
  names: string[],
): Generator<void, FlexibleSignalState | null> {
  const work = insertSurfaceControlCandidates(full, allocation, previous, names)
  let next = work.next()
  try {
    while (!next.done) {
      yield
      next = work.next()
    }
    const expected = new Set([
      ...previous.retained.map((trace) => trace.connection_name!),
      ...previous.traces.map((trace) => trace.connection_name!),
      ...names,
    ])
    return carrierCount(next.value) === expected.size ? next.value : null
  } finally {
    if (!next.done) work.return(previous)
  }
}

function* surfaceControlCandidates(
  full: SimpleRouteJson,
  allocation: SimpleRouteJson,
  previous: FlexibleSignalState,
  names: string[],
  maxAttempts: number,
  allowPocketRepair: boolean,
): Generator<void | SurfaceControlCandidate, FlexibleSignalState> {
  const original = names.filter(
      (name) =>
        ![...previous.retained, ...previous.traces].some(
          (trace) => trace.connection_name === name,
        ),
    ),
    visited = new Set<string>()
  let order = original
  let greatest = previous
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    let state = previous
    const pending = new Set(order)
    for (let round = 0; pending.size && round <= names.length; round++) {
      const fingerprint = JSON.stringify([
        order,
        [...pending],
        [...state.retained, ...state.traces]
          .sort((a, b) => a.connection_name!.localeCompare(b.connection_name!))
          .map((trace) => [
            trace.connection_name,
            trace.route,
            state.escapes
              .filter(
                (escape) => escape.connection_name === trace.connection_name,
              )
              .map((escape) => escape.route),
          ]),
      ])
      if (visited.has(fingerprint)) break
      visited.add(fingerprint)
      let progress = false
      for (const name of [...pending]) {
        const result = yield* insertOrdinarySignal(
          full,
          allocation,
          state,
          name,
          false,
        )
        if (!result) continue
        state = result
        if (carrierCount(state) > carrierCount(greatest)) greatest = state
        yield { state, completedOrder: false }
        pending.delete(name)
        progress = true
        yield
      }
      if (!pending.size) return state
      if (progress) continue
      if (attempt + 1 < maxAttempts || !allowPocketRepair) break
      for (const name of pending) {
        const result = yield* insertOrdinarySignal(
          full,
          allocation,
          state,
          name,
          true,
        )
        if (!result) continue
        state = result
        if (carrierCount(state) > carrierCount(greatest)) greatest = state
        yield { state, completedOrder: false }
        pending.delete(name)
        progress = true
        yield
        break
      }
      if (!progress) break
    }
    yield { state, completedOrder: true }
    const failed = [...pending].reverse(),
      failedNames = new Set(failed)
    order = [...failed, ...original.filter((name) => !failedNames.has(name))]
    yield
  }
  return greatest
}

function* insertOrdinarySignal(
  full: SimpleRouteJson,
  allocation: SimpleRouteJson,
  previous: FlexibleSignalState,
  name: string,
  allowPocketRepair = true,
): Generator<void, FlexibleSignalState | null> {
  const carriers = [...previous.retained, ...previous.traces]
  const names = new Set([
    ...carriers.map((trace) => trace.connection_name!),
    name,
  ])
  const native = scopeInput(full, names)
  const pairs = new Set(
    native.differentialPairs?.flatMap((pair) => pair.connectionNames),
  )
  const input = carrierInput(native, carriers, previous.escapes)
  const state: FlexibleSignalState = {
    native,
    pending: {
      ...input,
      connections: input.connections.map((connection) =>
        connection.name === name
          ? (allocation.connections.find((item) => item.name === name) ??
            connection)
          : connection,
      ),
      traces: [
        ...(native.traces ?? []),
        ...previous.escapes,
        ...carriers.filter((trace) => pairs.has(trace.connection_name!)),
      ],
    },
    escapes: previous.escapes,
    retained: carriers.filter((trace) => pairs.has(trace.connection_name!)),
    traces: carriers.filter((trace) => !pairs.has(trace.connection_name!)),
  }
  const direct = yield* negotiateSignalSites(state, new Set([name]))
  if (direct) return direct
  const bridge = yield* insertSurfaceSignal(state, name)
  if (bridge) return bridge
  return allowPocketRepair
    ? yield* repairOrdinaryPocket(state, new Set([name]))
    : null
}

function* repairOrdinaryPocket(
  state: FlexibleSignalState,
  initialClosure: ReadonlySet<string>,
): Generator<void, FlexibleSignalState | null> {
  const pairs = new Set(
    state.native.differentialPairs?.flatMap((pair) => pair.connectionNames),
  )
  let current = state
  const closure = new Set(initialClosure)
  const visited = new Set<string>()
  for (let round = 0; round < 6; round++) {
    const viaPocket = yield* findViaAwareSignalPocket(current, closure)
    const carrierPocket = yield* expandSignalSitePocket(current)
    for (const released of [...viaPocket, ...carrierPocket])
      if (!pairs.has(released)) closure.add(released)
    const expanded = round > 0
    const fingerprint = JSON.stringify([
      expanded,
      [...closure]
        .sort()
        .map((released) => [
          released,
          [...current.retained, ...current.traces].find(
            (trace) => trace.connection_name === released,
          )?.route,
          current.escapes
            .filter((escape) => escape.connection_name === released)
            .map((escape) => escape.route),
        ]),
    ])
    // A changed partial assignment can open another handoff even when its
    // member set repeats. Stop only when the same physical state and domain
    // breadth recur; the separate round bound keeps this repair finite.
    if (visited.has(fingerprint)) break
    visited.add(fingerprint)
    const repaired = yield* runBoundedRouting(
      negotiateSignalSites(current, closure, false, expanded, {
        retainExistingRoutes: true,
      }),
      150000,
    )
    if (repaired) return repaired
    const partial = yield* runBoundedRouting(
      negotiateSignalSites(current, closure, true, true, {
        retainExistingRoutes: true,
      }),
      150000,
    )
    if (!partial) continue
    const partialCount = partial.retained.length + partial.traces.length
    if (partialCount === state.native.connections.length) return partial
    current = partial
  }
  return null
}

function* insertFreshPair(
  full: SimpleRouteJson,
  previous: FlexibleSignalState,
  pair: NonNullable<SimpleRouteJson["differentialPairs"]>[number],
  searchOptions?: Pick<SolverOptions, "precheckEnclosedTerminals">,
): Generator<void, FlexibleSignalState | null> {
  const carriers = [...previous.retained, ...previous.traces]
  const members = full.connections.filter((connection) =>
    pair.connectionNames.includes(connection.name),
  )
  if (members.length !== 2) return null
  const layers = signalLayers(full, members[0]).filter((layer) =>
    members.every((member) => signalLayers(full, member).includes(layer)),
  )
  const oldPairNames = new Set(
    previous.native.differentialPairs?.flatMap(
      (existing) => existing.connectionNames,
    ),
  )
  const clearance =
    full.minTraceToPadEdgeClearance ?? full.defaultObstacleMargin ?? 0.075
  const conflicts = new CopperConflictIndex()
  layers.sort(
    (first, second) =>
      Number(
        !members.every((member) =>
          member.pointsToConnect.every((point) => point.layer === first),
        ),
      ) -
      Number(
        !members.every((member) =>
          member.pointsToConnect.every((point) => point.layer === second),
        ),
      ),
  )
  const nativeLayers = layers.filter((layer) =>
    members.every((member) =>
      member.pointsToConnect.every((point) => point.layer === layer),
    ),
  )
  const alternateLayers = layers.filter(
    (layer) => !nativeLayers.includes(layer),
  )
  const phase = (
    layer: string,
    releaseOrdinary: boolean,
    firstSoft = false,
  ) => ({
    layer,
    releaseOrdinary,
    firstSoft,
  })
  // Give a native surface repair an early, finite opportunity. Trying every
  // native repair before a clear alternate plane can consume the whole request.
  const phases = [
    ...nativeLayers.map((layer) => phase(layer, false)),
    ...nativeLayers.map((layer) => phase(layer, true, true)),
    ...alternateLayers.map((layer) => phase(layer, false)),
    ...nativeLayers.map((layer) => phase(layer, true)),
    ...alternateLayers.map((layer) => phase(layer, true)),
  ]
  const triedSoft = new Set<string>()
  for (const { layer, releaseOrdinary, firstSoft } of phases) {
    let attemptedFirstSoft = false

    const nativeLayer = members.every((member) =>
      member.pointsToConnect.every((point) => point.layer === layer),
    )
    for (
      let orientation = 0;
      orientation < (nativeLayer ? 1 : 4);
      orientation++
    ) {
      const local: SimpleRouteJson = {
        ...full,
        connections: members,
        buses: [],
        differentialPairs: [pair],
        traces: [
          ...(full.traces ?? []),
          ...previous.escapes.filter(
            (trace) =>
              !releaseOrdinary || oldPairNames.has(trace.connection_name!),
          ),
          ...carriers.filter(
            (trace) =>
              !releaseOrdinary || oldPairNames.has(trace.connection_name!),
          ),
        ],
      }
      let escapes: Trace[] = []
      if (!nativeLayer) {
        try {
          const generated = routeAlternateSignalDogbones(
            local,
            signalDogboneOptions(
              local,
              new Map(members.map((member) => [member.name, layer])),
            ),
            orientation,
          )
          local.connections =
            generated.connections as SimpleRouteJson["connections"]
          escapes = ownedSignalEscapes(full, generated.traces)
          if (
            generatedEscapeHolesConflict(full, escapes, local.traces ?? []) ||
            escapes.some((owned, index) =>
              generatedEscapeHolesConflict(
                full,
                [owned],
                escapes.slice(index + 1),
              ),
            )
          )
            continue
          local.traces = [...local.traces!, ...escapes]
        } catch {
          yield
          continue
        }
      }
      const plans = planSharedPairCorridors(
        local,
        new Map(members.map((member) => [member.name, [layer]])),
        true,
        {
          preferPackageOnlyTuning: true,
          ...(searchOptions?.precheckEnclosedTerminals === true
            ? { precheckEnclosedTerminals: true }
            : {}),
        },
      )
      let planned = plans.next()
      try {
        while (!planned.done) {
          if (
            planned.value &&
            pairCouplingReports(local, planned.value).every(
              (report) => report.matched,
            )
          ) {
            const key = JSON.stringify([
              escapes.map((escape) => escape.route),
              planned.value.map((trace) => trace.route),
            ])
            if (releaseOrdinary && triedSoft.has(key)) {
              yield
              planned = plans.next()
              continue
            }
            if (releaseOrdinary) {
              triedSoft.add(key)
              attemptedFirstSoft = true
            }
            const joined = [...carriers, ...planned.value]
            const native = scopeInput(
              full,
              new Set(joined.map((trace) => trace.connection_name!)),
            )
            const allEscapes = [...previous.escapes, ...escapes]
            const pairNames = new Set(
              native.differentialPairs?.flatMap((item) => item.connectionNames),
            )
            const state: FlexibleSignalState = {
              native,
              pending: carrierInput(native, joined, allEscapes),
              escapes: allEscapes,
              retained: joined.filter((trace) =>
                pairNames.has(trace.connection_name!),
              ),
              traces: joined.filter(
                (trace) => !pairNames.has(trace.connection_name!),
              ),
            }
            if (!releaseOrdinary) return state
            const pairCopper = fixedCopper({
              ...full,
              obstacles: [],
              traces: [...escapes, ...planned.value],
            })
            const blockers = new Set(
              carriers
                .filter((trace) => !oldPairNames.has(trace.connection_name!))
                .filter(
                  (trace) =>
                    conflicts.firstConflict(
                      pairCopper,
                      fixedCopper({
                        ...full,
                        obstacles: [],
                        traces: [
                          trace,
                          ...previous.escapes.filter(
                            (escape) =>
                              escape.connection_name === trace.connection_name,
                          ),
                        ],
                      }),
                      clearance - 1e-8,
                    ) ||
                    generatedEscapeHolesConflict(
                      full,
                      escapes,
                      previous.escapes.filter(
                        (owned) =>
                          owned.connection_name === trace.connection_name,
                      ),
                    ),
                )
                .map((trace) => trace.connection_name!),
            )
            if (!blockers.size) return state
            const repair = repairOrdinaryPocket(state, blockers)
            const repaired = firstSoft
              ? yield* runBoundedRouting(repair, 150000)
              : yield* repair
            if (repaired) return repaired
          }
          if (firstSoft && attemptedFirstSoft) break
          yield
          planned = plans.next()
        }
      } finally {
        if (!planned.done) plans.return(undefined)
      }
    }
  }
  return null
}
