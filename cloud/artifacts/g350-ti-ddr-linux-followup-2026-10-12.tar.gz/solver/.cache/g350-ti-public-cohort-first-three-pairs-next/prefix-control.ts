import { spyOn } from "bun:test"

type Work = Generator<unknown, unknown, unknown>
type Method = "next" | "return" | "throw"
export interface Job {
  jobId: number
  arguments: unknown
  terminal: boolean
  terminalMethod: Method | null
  nextCalls: number
  returnCalls: number
  throwCalls: number
  result: unknown
}

export function hasCompleteNaturalPair(capture: any): boolean {
  return (
    capture.terminalMethod === "next" &&
    capture.output?.projectionComplete === true &&
    capture.output?.count === 2 &&
    Array.isArray(capture.result) &&
    capture.result.length === 2 &&
    capture.result.every(
      (trace: any) =>
        typeof trace.connection_name === "string" &&
        Array.isArray(trace.route) &&
        trace.route.length >= 2 &&
        trace.route.every(
          (point: any) => Number.isFinite(point.x) && Number.isFinite(point.y),
        ),
    )
  )
}

/** Only the fourth-factory boundary changes execution. Observation cannot throw. */
export function installFirstThreeGate(
  module: Record<string, any>,
  expectedNames: readonly string[][],
  capture: (job: Job) => void,
  testOriginalOverride?: (...args: any[]) => Work,
) {
  const original = testOriginalOverride ?? module.routeCoupledPair
  const boundary = new Error("DECLARED_FIRST_THREE_FACTORY_BOUNDARY")
  const jobs: Job[] = []
  const errors: string[] = []
  let factoryAttempts = 0
  let originalFactories = 0
  const observe = (job: Job) => {
    try {
      capture(job)
    } catch (error) {
      if (errors.length < 16)
        errors.push(
          error instanceof Error
            ? error.message.slice(0, 256)
            : "capture error",
        )
    }
  }
  const spy = spyOn(module, "routeCoupledPair").mockImplementation(function (
    this: unknown,
    ...args: any[]
  ) {
    factoryAttempts++
    if (factoryAttempts === 4) {
      if (jobs.length !== 3 || jobs.some((job) => !job.terminal))
        throw Error(
          "Fourth factory attempted before first three terminal results",
        )
      throw boundary
    }
    if (factoryAttempts > 4)
      throw Error("Original factory advanced past boundary")
    const options = args[3]
    if (
      JSON.stringify(args[1]?.connectionNames) !==
        JSON.stringify(expectedNames[factoryAttempts - 1]) ||
      options?.variant !== 0 ||
      options?.allowProvisionalPairTuning !== false ||
      options?.preferPackageOnlyTuning !== true ||
      !Array.isArray(options?.copper) ||
      options.copper.length !== 0 ||
      options?.penalty !== 0 ||
      options?.history !== undefined ||
      options?.handoffOffsets !== undefined
    )
      throw Error("Original first normal reserved family arguments differ")
    const job: Job = {
      jobId: factoryAttempts,
      arguments: args,
      terminal: false,
      terminalMethod: null,
      nextCalls: 0,
      returnCalls: 0,
      throwCalls: 0,
      result: undefined,
    }
    jobs.push(job)
    originalFactories++
    const work = Reflect.apply(original, this, args) as Work
    const advance = (method: Method, values: unknown[]) => {
      if (method === "next") job.nextCalls++
      else if (method === "return") job.returnCalls++
      else job.throwCalls++
      const state = Reflect.apply(work[method], work, values)
      if (state.done && !job.terminal) {
        job.terminal = true
        job.terminalMethod = method
        job.result = state.value
        observe(job)
      }
      return state
    }
    const wrapped: any = {
      next: (...values: unknown[]) => advance("next", values),
      return: (...values: unknown[]) => advance("return", values),
      throw: (...values: unknown[]) => advance("throw", values),
      [Symbol.iterator]() {
        const value = Reflect.apply(work[Symbol.iterator], work, [])
        return value === work ? wrapped : value
      },
    }
    const dispose = (Symbol as any).dispose
    if (dispose && typeof (work as any)[dispose] === "function")
      wrapped[dispose] = (...values: unknown[]) =>
        Reflect.apply((work as any)[dispose], work, values)
    return wrapped
  })
  return {
    boundary,
    jobs,
    errors,
    get factoryAttempts() {
      return factoryAttempts
    },
    get originalFactories() {
      return originalFactories
    },
    restore: () => spy.mockRestore(),
  }
}
