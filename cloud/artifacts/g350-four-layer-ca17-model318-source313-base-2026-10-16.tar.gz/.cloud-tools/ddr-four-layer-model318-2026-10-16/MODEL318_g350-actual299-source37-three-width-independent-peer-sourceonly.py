"""Independent own stdlib JSON/geometry peer of37; no SDK/imported app execution."""
ns={'__name__':'own_actual299_helper'};exec(open('/tmp/g350-actual299-source22-finite-helper-sourceonly.py').read(),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
def pinj(p,h):
 d=Path(p).read_bytes();assert hashlib.sha256(d).hexdigest()==h;return json.loads(d)
p='/tmp/g350-actual299-source37-matched21p2-three-width-full49-own-audit-report.json';ph='3a1e219b8608cb68e2e4cd121cc267936f53e1f9ae6c723755651338f38dbfa4';r=pinj(p,ph);pj=pinj(r['proposalPath'],'c70a69a2c9e1eb13bf470fed9e0cde30574fc4c82ce8faf50890458e37cd531c');hpath='/tmp/g350-actual299-source37-three-width-heading-companion-report.json';hp=pinj(hpath,'f43b37199ca33ffb8f2fc2ce83ff3c8c6af77639d69464e31d7bb65c628c99e4');iv=r['bodyInverse'];old=B['source_trace_37'];new=iv['after'];assert iv['before']==old and iv==pj['bodyInverse'];assert json.dumps(old['route'][0])==json.dumps(new['route'][0]) and json.dumps(old['route'][-1])==json.dumps(new['route'][-1]);assert not new.get('curvedSegments')
AF={**B,'source_trace_37':new};ss=makeScene({'source_trace_37':new});foreign=[]
for n,t in AF.items():
 cs=ss.contacts(t);foreign.append({'owner':n,'contacts':cs});assert not cs,(n,cs)
reverse=[]
for t in f['traces']:
 if owner(t)=='source_trace_37':continue
 cs=[z for z in ss.contacts(t)if z['otherOwner']=='source_trace_37'];assert not cs;reverse.append({'id':t['pcb_trace_id'],'contactsWith37':cs})
runs=[];run=[];events=[]
for i,v in enumerate(new['route']):
 if v['route_type']=='wire':assert v['width']==.1016;run.append(v)
 else:runs.append(run);run=[];events.append((i,v,len(runs)-1,len(runs)))
if run:runs.append(run)
assert len(runs)==3 and len(events)==2
beforeVias=[v for v in old['route']if v['route_type']=='via'];assert json.dumps(events[1][1])==json.dumps(beforeVias[1]);assert all(events[0][1][k]==beforeVias[0][k]for k in beforeVias[0]if k not in ['x','y']);assert math.isclose(events[0][1]['x']-beforeVias[0]['x'],-.1,abs_tol=1e-10)and math.isclose(events[0][1]['y']-beforeVias[0]['y'],-.1,abs_tol=1e-10)
selfs=[];angles=[];allMin=[]
for ri,run in enumerate(runs):
 sm=self_math(run,.3048);assert sm['passedPureMath'];selfs.append({'run':ri,'layer':run[0]['layer'],'passed3WSelf':True,'allowedLocalPairs':len(sm['allowedCloseLocalCornerPairs'])});al={tuple(x['segments'])for x in sm['allowedCloseLocalCornerPairs']};ds=[(sd(run[i],run[i+1],run[j],run[j+1]),i,j)for i in range(len(run)-1)for j in range(i+2,len(run)-1)if (i,j)not in al]
 if ds:allMin.append({'run':ri,'distanceMm':min(ds)[0],'segments':list(min(ds)[1:])})
 hs=[math.degrees(math.atan2(b['y']-a['y'],b['x']-a['x']))for a,b in zip(run,run[1:])];assert all(math.dist((a['x'],a['y']),(b['x'],b['y']))>1e-10 for a,b in zip(run,run[1:]));err=max([abs(h-round(h/45)*45)for h in hs]or[0]);turn=max([abs((b-a+180)%360-180)for a,b in zip(hs,hs[1:])]or[0]);assert err<1e-8 and turn<=45+1e-8;angles.append({'run':ri,'pointCount':len(run),'maximumOctilinearErrorDegrees':err,'maximumTurnDegrees':turn})
own=[]
for ix,v,rb,ra in events:
 assert v['layers']==L and v['via_diameter']==.4572 and v['via_hole_diameter']==.254;rr=[]
 for j,run in enumerate(runs):
  incident=j in [rb,ra];pts=list(reversed(run))if j==rb else run;exited=False;minimumAfter=None
  if incident:assert math.dist((pts[0]['x'],pts[0]['y']),(v['x'],v['y']))<1e-8
  for si,(a,b) in enumerate(zip(pts,pts[1:])):
   d=pd(v,a,b)
   if exited or not incident:
    assert d>=.381-1e-8,(ix,j,si,d);minimumAfter=d if minimumAfter is None else min(minimumAfter,d)
   if math.hypot(b['x']-v['x'],b['y']-v['y'])>.381+1e-8:exited=True
  rr.append({'run':j,'incident':incident,'minimumAfterFirstExitMm':minimumAfter,'passed':True})
 own.append({'routeIndex':ix,'runReports':rr,'passed':True})
classes={n:b['busId']for b in f['buses']for n in b['connectionNames']};bad=[];checked=0
for run in runs:
 for a,b in zip(run,run[1:]):
  for t in [*f['traces'],*AF.values()]:
   n=owner(t)
   if n=='source_trace_37' or n not in classes:continue
   need=.3048 if classes[n]=='DDR_COMMAND_CLOCK'else.4064
   for j,(u,v)in enumerate(zip(t['route'],t['route'][1:])):
    if u['route_type']==v['route_type']=='wire'and u['layer']==v['layer']==a['layer']:
     checked+=1;d=sd(a,b,u,v)
     if d<need-1e-8:bad.append({'owner':n,'id':t['pcb_trace_id'],'segment':j,'actualMm':d,'requiredMm':need})
assert not bad
w=whole(new);assert abs(w-21.2)<1e-8;ca=next(b for b in f['buses']if b['busId']=='DDR_COMMAND_CLOCK');vals=[whole(AF[n])for n in ca['connectionNames']];matched=[v for v in vals if v>=20.95-1e-8];assert len(matched)==17 and max(matched)-min(matched)<=.635+1e-8 and max(vals)-min(vals)>.635
R={'scope':'INDEPENDENT_OWN_STDLIB_ONLY37_CA17_PEER_NOT_SDK','inputPath':P299,'inputSha256':S299,'reviewedFullProof':{'path':p,'sha256':ph},'reviewedHeadingCompanion':{'path':hpath,'sha256':'f43b37199ca33ffb8f2fc2ce83ff3c8c6af77639d69464e31d7bb65c628c99e4'},'sameLiteralEndpointKeyOrder':True,'only37BodyChangesAll48AndEntireFoundationHeld':True,'all49ReciprocalForeignRows':foreign,'allForeignWorkingReferenceReverseRows':reverse,'wholeLengthMm':w,'allThreeRuns3WSelf':selfs,'minimumNonlocalPairs':allMin,'allThreeRunsHeadingReports':angles,'ownInlineViaAfterFirstExitIndependentRows':own,'allForeignDdrWirePairComparisons':checked,'foreignSub3W4WPairs':bad,'caMinimumPassingCount':len(matched),'caMatchedSubcohortSkewMm':max(matched)-min(matched),'bothCompleteByteCohortsLiteral':True,'fullCaSkewStillFailed':True,'passedIndependentPurePeer':True,'nativeExecuted':False,'sdkExecuted':False,'all49Accepted':False,'wholeTiRoutingQualified':False,'electricalTimingQualified':False,'fabricationReady':False};out=Path('/tmp/g350-actual299-source37-three-width-independent-peer-report.json');out.open('x').write(json.dumps(R,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'whole':w,'caMin':17,'pairComparisons':checked,'all49foreignZero':True,'allOwnInlinePass':True,'minima':allMin},indent=2))
