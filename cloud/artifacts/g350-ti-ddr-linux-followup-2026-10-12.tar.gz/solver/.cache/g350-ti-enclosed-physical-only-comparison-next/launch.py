"""ONE specific diagnostic explicitly authorized by parent/root; no prep tests."""
from pathlib import Path
import json,hashlib,importlib.util,stat
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/bus-lanes-solver')
SOURCE=REPO/'.cache/g350-ti-enclosed-grid-component-probe-next'
POLICY={'wallSeconds':30,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def source():
 m=SOURCE/'packet-manifest.json';assert sha(m)=='422676e278a0917a41f3e23d8adf742658636c53ab67ce956bfd7d585c1b6412';data=json.loads(m.read_bytes());selected=[v for v in data['files']if v['path'].startswith('source/')];assert len(selected)==177
 for v in selected:
  p=SOURCE/v['path'];assert sha(p)==v['sha256']and stat.S_IMODE(p.stat().st_mode)==v['mode']
 verifier=module('verify_deps',SOURCE/'verify-installed-dependencies.py');deps=verifier.verify(SOURCE/'dependencies/archive-receipt.json',data['dependencyReceiptSha256'],SOURCE/'audit-installed-dependencies.py');assert deps['treeSha256']==data['dependencyTreeSha256']and deps['archiveSha256']==data['dependencyArchiveSha256']
 return{'packetSha256':sha(m),'sourceMemberCount':len(selected),'dependencyAudit':deps,'workerSha256':sha(ROOT/'worker.ts'),'launcherSha256':sha(ROOT/'launch.py')}
assert not(ROOT/'run').exists()
before=source();scope=module('owned_scope',SOURCE/'process_scope.py');baseline=scope.memory();assert baseline['current']+3*1024**3<POLICY['sharedBytes']
(ROOT/'authority.json').write_text(json.dumps({'authorizedByRoot':True,'authorization':'Parent/root explicitly authorized this one physical-only originalGrid comparison in current agent task; no synthetic approval nonce claimed.','captureSha256':'798e435705fb5d47bb47b08043a78a90c8837436d2bada425be0f9c058857418','removedCu':'Only169provisionalclockCu; all893physical/filter616held','policy':POLICY,'oneActualGridOnly':True,'noOtherRoutingOrChecker':True},indent=2)+'\n')
def fresh(memory):
 assert memory['current']+3*1024**3<POLICY['sharedBytes'];assert all(memory['events'][key]==baseline['events'][key]for key in ['oom','oom_kill','oom_group_kill'])
execution=scope.run_guarded(['/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe','--smol',str(ROOT/'worker.ts')],ROOT,ROOT/'run',POLICY,before_spawn=fresh)
after=source();assert before==after
p=ROOT/'run/result.json';result=json.loads(p.read_bytes())if p.exists()else None
trusted=execution['exitCode']==0 and not execution['diagnosticStopped']and execution['cleanupOwnedGroupEmpty']is True and result is not None and result['originalGridCalls']==1 and result['cancelCalls']==1 and result['inputAndAllOriginalPhysicalCopperHeld']is True and result['onlyClockSuffixRemoved']is True and all(v==0 for v in execution['oomDelta'].values())
report={'sourceBefore':before,'sourceAfter':after,'execution':execution,'sourceAndDepsHeld':True,'resultSha256':sha(p)if p.exists()else None,'authoritySha256':sha(ROOT/'authority.json'),'trustedDiagnostic':trusted,'accepted49':False,'fabricationReady':False}
(ROOT/'run/postflight.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'actualExitCode':execution['exitCode'],'trusted':trusted,'resultSha256':report['resultSha256'],'postSha256':sha(ROOT/'run/postflight.json'),'execution':execution}))
raise SystemExit(0 if trusted else 2)
