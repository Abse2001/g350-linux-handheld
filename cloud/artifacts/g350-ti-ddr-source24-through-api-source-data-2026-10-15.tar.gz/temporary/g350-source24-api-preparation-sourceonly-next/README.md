Source-only API24 successor. No solver, library, Native, Core, CLI or CAD was executed.

The original13 private API implementation files remain unchanged. The147-line worker preserves every prior23predicate, extends continuity to24 genuine carriers, and evaluates the early reflected DQS1 meander in a second geometry-identical metadata view after the primary lower_U view. It asserts108 primary boolean predicates plus3 secondary predicates; loadedbus and immutability gates remain additional.

ActualCore24 and Native18 must be collected first. A separate Root-owned stdlib projection must build fresh49/263fixed/1298obstacle/98via-event material from that Core and its Native ownership proof. The actualCore/native/projection paths and hashes remain null. OldB262/631 material is not accepted. Native and API use separate Root packets; the actual Native packetsha is pinned separately. Dynamic original API imports occur only after Root authority, source bindings, native report, Core and freshprojectionproof checks.

This is preparation, not a Rootguard or authority. Future CLI/CAD, electrical/reference/fabrication and full49 acceptance remain false.
