"""Pure Python static geometry diagnostic; no solver/native/runtime imports."""
import json,math,hashlib,collections
PATH='/tmp/g350-manual45-clock-merge-root-20261016-run171/byte0-result.candidate.json'
OLD='/tmp/g350-d15-manual-common15-root-20261016-run133/byte0-result.json'
def load(p,pin):
 b=open(p,'rb').read(); assert hashlib.sha256(b).hexdigest()==pin;return json.loads(b)
p=load(PATH,'9930eb5a0de0183432d3dc283d3c58d1002fb08a9217e13fa05ff6a4cae3c6a8');old=load(OLD,'818116b979991ea4473e4f793f2d58de3d6a37969056ed499efd5a9b5e352d28')
f=p['full49FanoutInput'];L=['top','inner1','inner2','bottom'];W=.1016;G=.1016
owner=lambda t:t.get('connection_name',t.get('source_trace_id'))
def pd(p,a,b):
 dx=b['x']-a['x'];dy=b['y']-a['y'];dd=dx*dx+dy*dy;t=max(0,min(1,((p['x']-a['x'])*dx+(p['y']-a['y'])*dy)/dd)) if dd else 0
 return math.hypot(p['x']-a['x']-t*dx,p['y']-a['y']-t*dy)
def cross(a,b,c):return (b['x']-a['x'])*(c['y']-a['y'])-(b['y']-a['y'])*(c['x']-a['x'])
def sd(a,b,c,d):
 q,r,s,t=cross(a,b,c),cross(a,b,d),cross(c,d,a),cross(c,d,b)
 if q*r<0 and s*t<0:return 0
 return min(pd(a,c,d),pd(b,c,d),pd(c,a,b),pd(d,a,b))
def mats(t):
 out=[]
 for i,a in enumerate(t['route']):
  if a['route_type']=='via':out.append({'kind':'via','p':a,'radius':a['via_diameter']/2,'holeRadius':a['via_hole_diameter']/2,'layers':L,'index':i})
  if i+1<len(t['route']):
   b=t['route'][i+1]
   if a['route_type']==b['route_type']=='wire' and a['layer']==b['layer'] and math.hypot(a['x']-b['x'],a['y']-b['y'])>1e-9:out.append({'kind':'wire','a':a,'b':b,'radius':max(a['width'],b['width'])/2,'layers':[a['layer']],'index':i})
 return out

def contacts(t,bodies):
 A=mats(t);out=[]
 for body in bodies:
  if owner(body)==owner(t):continue
  B=mats(body);cons=[]
  for a in A:
   for b in B:
    if not set(a['layers'])&set(b['layers']):continue
    if a['kind']=='wire' and b['kind']=='wire':d=sd(a['a'],a['b'],b['a'],b['b']);need=a['radius']+b['radius']+G
    elif a['kind']=='wire':d=pd(b['p'],a['a'],a['b']);need=a['radius']+max(b['radius']+G,b['holeRadius']+.2)
    elif b['kind']=='wire':d=pd(a['p'],b['a'],b['b']);need=b['radius']+max(a['radius']+G,a['holeRadius']+.2)
    else:d=math.hypot(a['p']['x']-b['p']['x'],a['p']['y']-b['p']['y']);need=max(a['radius']+b['radius']+.15,a['holeRadius']+b['holeRadius']+.254)
    if d<need-1e-8:cons.append({'candidateIndex':a['index'],'otherIndex':b['index'],'layer':sorted(set(a['layers'])&set(b['layers'])),'kind':a['kind']+'_'+b['kind'],'actual':d,'required':need,'shortfall':need-d})
  if cons:out.append({'owner':owner(body),'id':body['pcb_trace_id'],'contacts':cons})
 return out
T=next(t for t in old['carrierTraces'] if owner(t)=='source_trace_26')
variants=[]
for name,start in [('old_original',(.8,15.2)),('old_adapt_cpuSW',(0,15.2))]:
 t=json.loads(json.dumps(T));t['route'][0]['x'],t['route'][0]['y']=start
 variants.append({'name':name,'carrier':t,'carrierPlanarLength':sum(math.hypot(b['x']-a['x'],b['y']-a['y']) for a,b in zip(t['route'],t['route'][1:])),'foundationContacts':contacts(t,f['traces']),'carrierContacts':contacts(t,p['carrierTraces'])})
R={'scope':'SOURCE_ONLY_STATIC_D12_OLD_PATH_CONFLICT_DIAGNOSTIC_NOT_PHYSICAL_ACCEPTANCE','inputSha256':'9930eb5a0de0183432d3dc283d3c58d1002fb08a9217e13fa05ff6a4cae3c6a8','variants':variants,'padsOutlineOwnTerminalChecksExecuted':False,'nativeExecuted':False,'fabricationReady':False}
json.dump(R,open('/tmp/g350-d12-old26-conflicts-current171-static.json','w'),indent=2)
for v in variants:
 print(v['name'],'length',v['carrierPlanarLength'],'foundation',[(r['owner'],r['id'],len(r['contacts'])) for r in v['foundationContacts']],'carriers',[(r['owner'],len(r['contacts'])) for r in v['carrierContacts']])
