import { strict as assert } from "node:assert"
import { readFileSync } from "node:fs"
import { test } from "bun:test"
import {
  qualifyPartialNative,
  referenceOwners,
  type PartialNativeApis,
} from "./partial-native"
import type { SimpleRouteJson, Trace } from "./source/lib/types"
import type { OriginalCapture } from "./identity-order"
const load = <T>(name: string): T =>
  JSON.parse(readFileSync(`${import.meta.dir}/${name}`, "utf8"))
const fixture = () => ({
  native: load<SimpleRouteJson>("native-input.json"),
  escapes: load<Trace[]>("all-owned-approaches.json"),
  captures: [2, 1, 3].map((id) => load<OriginalCapture>(`job-${id}.json`)),
  registry: load<any>("physical-reference-registry.json"),
})
function mockApis(native: SimpleRouteJson) {
  const calls: any = {
    joins: [],
    paths: [],
    geometry: [],
    drc: [],
    pairs: [],
    coupling: [],
    exterior: [],
    outline: [],
    drill: [],
  }
  const api: PartialNativeApis = {
    // Deliberately not a physical join algorithm: preserve actual barrel inventory,
    // endpoint data and owner forwarding so preparation cannot assert physical pass.
    joinSignalEscapes(lane, escapes) {
      calls.joins.push({ lane, escapes })
      const c = native.connections.find((c) => c.name === lane.connection_name)!
      return {
        ...lane,
        route: [
          { ...c.pointsToConnect[0], route_type: "wire", width: 0.1016 },
          ...escapes.flatMap((e) => e.route),
          ...lane.route,
          { ...c.pointsToConnect[1], route_type: "wire", width: 0.1016 },
        ],
      } as Trace
    },
    validateG350PathIntegrity(input, traces) {
      calls.paths.push({ input, traces })
      return { valid: true, structurallyValid: true, issues: [] }
    },
    nativeSignalGeometryIsValid(trace) {
      calls.geometry.push(trace)
      return true
    },
    validateRoutedCopperDrc(params) {
      calls.drc.push(params)
      return {
        valid: true,
        checkedTraceCount: params.routedSrj.traces.length,
        checkedViaCount: params.routedSrj.traces.flatMap((t: Trace) =>
          t.route.filter((p) => p.route_type === "via"),
        ).length,
        issues: [],
      }
    },
    pairLengthReports(input, traces) {
      calls.pairs.push({ input, traces })
      return []
    },
    pairCouplingReports(input, traces) {
      calls.coupling.push({ input, traces })
      return []
    },
    exteriorPairSpacingReports(input, traces) {
      calls.exterior.push({ input, traces })
      return []
    },
    boardOutlineViolations(input, traces) {
      calls.outline.push({ input, traces })
      return []
    },
    generatedEscapeHolesConflict(input, first, second) {
      calls.drill.push({ input, first, second })
      return false
    },
  }
  return { api, calls }
}
test("full physical scope and per-owner forwarding survive every completion permutation; mock success never accepts49", () => {
  for (const order of [
    [1, 2, 3],
    [1, 3, 2],
    [2, 1, 3],
    [2, 3, 1],
    [3, 1, 2],
    [3, 2, 1],
  ]) {
    const f = fixture(),
      { api, calls } = mockApis(f.native)
    f.captures = order.map((id) => f.captures.find((c) => c.jobId === id)!)
    const before = JSON.stringify(f),
      r = qualifyPartialNative(f.native, f.escapes, f.captures, f.registry, api)
    assert.equal(JSON.stringify(f), before)
    assert.deepEqual(r.naturalJobIds, [1, 2])
    assert.deepEqual(r.cancelledOrNullJobIds, [3])
    assert.equal(calls.joins.length, 4)
    assert.deepEqual(
      calls.joins.map((c: any) => c.escapes.length),
      [2, 2, 0, 0],
    )
    assert.ok(
      calls.joins.every((c: any) =>
        c.escapes.every(
          (e: Trace) => e.connection_name === c.lane.connection_name,
        ),
      ),
    )
    assert.equal(calls.drc.length, 1)
    const d = calls.drc[0]
    assert.equal(d.inputSrj.connections.length, 51)
    assert.deepEqual(d.inputSrj.connections.slice(0, 49), f.native.connections)
    assert.deepEqual(d.inputSrj.obstacles, f.native.obstacles)
    assert.equal(d.routedSrj.traces.length, 26)
    assert.deepEqual(d.routedSrj.traces.slice(0, 2), f.native.traces)
    assert.equal(r.retainedApproachCount, 20)
    assert.equal(r.consumedApproachCount, 4)
    assert.equal(r.fullspanViaCount, 26)
    assert.equal(r.nativeDrcActuallyIngestedAllPhysicalTraces, true)
    assert.equal(calls.paths.length, 2)
    assert.equal(calls.paths[0].traces.length, 24)
    assert.deepEqual(calls.paths[0].input, f.native)
    assert.deepEqual(calls.paths[1].traces, f.native.traces)
    assert.deepEqual(calls.paths[1].input.traces, [])
    assert.equal(calls.geometry.length, 26)
    assert.equal(calls.drill.length, 325)
    assert.equal(calls.outline[0].traces.length, 26)
    for (const name of ["pairs", "coupling", "exterior"]) {
      assert.equal(calls[name].length, 1)
      assert.equal(calls[name][0].traces.length, 4)
      assert.equal(calls[name][0].input.traces.length, 22)
      assert.deepEqual(calls[name][0].input.obstacles, f.native.obstacles)
    }
    assert.equal(r.nativeConnectedSignals, 4)
    assert.equal(r.missingNativeSignals.length, 45)
    assert.equal(r.complete49, false)
    assert.equal(r.busMatchingQualified, false)
    assert.equal(r.full49TimingQualified, false)
    assert.equal(r.electricalTimingQualified, false)
    assert.equal(r.accepted49, false)
    assert.equal(r.fabricationReady, false)
    assert.equal(r.newRoutingCalls, 0)
  }
})
test("two physical source/alias/net owners require exact existing geometry, not synthetic nets", () => {
  const f = fixture()
  const owners = referenceOwners(f.native, f.registry)
  assert.deepEqual(
    owners.map((o: any) => [o.name, o.netConnectionName]),
    [
      ["source_trace_932", "source_net_5"],
      ["source_trace_933", "source_net_0"],
    ],
  )
  for (const mutate of [
    (r: any) =>
      (r.sourceTraces[0].connected_source_net_ids[0] = "source_net_0"),
    (r: any) => (r.pcbPorts[0].x += 0.1),
    (r: any) => r.sourceTraces.pop(),
    (r: any) => (r.physicalVias[0].outer_diameter = 0.5),
    (r: any) => (r.physicalStubs[0].route[1].width = 0.1),
  ]) {
    const r = structuredClone(f.registry)
    mutate(r)
    assert.throws(() => referenceOwners(f.native, r))
  }
})
test("a skipped barrel or mismatched job declaration fails closed", () => {
  const f = fixture(),
    { api } = mockApis(f.native)
  api.joinSignalEscapes = (lane) => lane
  assert.throws(
    () =>
      qualifyPartialNative(f.native, f.escapes, f.captures, f.registry, api),
    /preserve every actual/,
  )
  const bad = structuredClone(f.captures)
  bad[0].arguments[1] = { connectionNames: ["foreign", "foreign"] }
  assert.throws(
    () =>
      qualifyPartialNative(
        f.native,
        f.escapes,
        bad,
        f.registry,
        mockApis(f.native).api,
      ),
    /pair declaration/,
  )
})
test("DRC physical failure remains a truthful diagnostic; missed ingestion is separately visible", () => {
  const f = fixture(),
    { api } = mockApis(f.native)
  api.validateRoutedCopperDrc = () => ({
    valid: false,
    checkedTraceCount: 26,
    checkedViaCount: 26,
    issues: [{ code: "real-clearance-failure" }],
  })
  const r = qualifyPartialNative(
    f.native,
    f.escapes,
    f.captures,
    f.registry,
    api,
  )
  assert.equal(r.drc.valid, false)
  assert.equal(r.nativeDrcActuallyIngestedAllPhysicalTraces, true)
  assert.equal(r.accepted49, false)
  api.validateRoutedCopperDrc = () => ({
    valid: true,
    checkedTraceCount: 26,
    checkedViaCount: 24,
    issues: [],
  })
  assert.equal(
    qualifyPartialNative(f.native, f.escapes, f.captures, f.registry, api)
      .nativeDrcActuallyIngestedAllPhysicalTraces,
    false,
  )
})
