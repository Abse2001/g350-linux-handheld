// SOURCE ONLY. Import-free bounded search over genuine C31 routing access.
// The caller supplies actual material, endpoint menus, fixed-prefix cost and
// its real initial fullspan portal. This function never qualifies geometry.
type R=Record<string,any>
const L=['top','inner1','inner2','bottom'],W=.1016,VD=.4572,HD=.254
const near=(a:R,b:R)=>Math.hypot(a.x-b.x,a.y-b.y)<1e-8
const clone=<T>(x:T):T=>structuredClone(x)
const req=(v:any,m:string)=>{if(!v)throw Error('Fixed portal suffix: '+m)}
const own=(t:R)=>t.connection_name??t.source_trace_id
export function searchFixedPortalFourLayerSuffix(o:R,H:R):R {
 const {GridVisibilitySearch,GridHeap,BoundedSparseStateStore,VectorScene,fixedCopper,length}=H
 req(typeof GridVisibilitySearch==='function'&&typeof BoundedSparseStateStore==='function','Real C31 grid and reviewed bounded storage required')
 req(o.start&&o.ends&&o.initialViaCount===1&&o.maxVias>=1&&o.maxVias<=4,'Actual fixed portal and finite new-via count')
 const maps:any[]=[],access:any[]=[],fixed=fixedCopper(o.input),startTime=performance.now(),record:R={expanded:0,qualified:false,all49Accepted:false},viaMemo=new Map<number,boolean>()
 try{
  const minimumEndFanout=Math.min(...L.filter(l=>o.ends[l].supported).map(l=>o.ends[l].fanoutMm)),localCap=o.maximumWholeMm-o.prefixWholeMm-minimumEndFanout
  req(Number.isFinite(localCap)&&localCap>0,'Positive residual true length budget')
  for(const layer of L){const c={...clone(o.connection),pointsToConnect:[{x:o.start.x,y:o.start.y,layer},clone(o.ends[layer].point)]},scene=new VectorScene(o.input,c,W,fixed),grid=new GridVisibilitySearch(scene,c.pointsToConnect[0],c.pointsToConnect[1],[],0,undefined,{step:o.step,bounds:o.bounds,maxLength:localCap,allTerminalAttachments:true,checkReachability:false,paretoLength:false});maps.push(grid);access.push(grid.getRoutingAccess())}
  const N=access[0].cellCount,nx=access[0].nx,ny=access[0].ny
  req(N<=2000000&&access.every(a=>a.cellCount===N&&a.nx===nx&&a.ny===ny&&near(a.point(0),access[0].point(0))&&near(a.point(N-1),access[0].point(N-1))),'Identical finite four-layer XY grids')
  record.actualCellsPerLayer=N;record.attachments=access.map((a,i)=>({layer:L[i],starts:a.starts.length,ends:a.ends.length,rootEnabled:o.startLayers.includes(L[i]),goalEnabled:o.ends[L[i]].supported}));o.progress?.(clone(record))
  const store=new BoundedSparseStateStore(o.maxLabels),heap=new GridHeap(o.maxLabels),roots=new Map<number,R>(),goals=access.map((a,i)=>new Map<number,R[]>((o.ends[L[i]].supported?a.ends:[]).map((p:R)=>[p.id,p.path.toReversed()])))
  const heuristic=(p:R)=>Math.min(...L.filter(l=>o.ends[l].supported).map(l=>Math.hypot(p.x-o.ends[l].point.x,p.y-o.ends[l].point.y)+o.ends[l].fanoutMm))
  const push=(state:number,g:number,parent:number)=>{const old=store.get(state);if(old>=0&&g>=store.cost(old)-1e-10)return -1;const p=access[0].point(state%N);if(g+heuristic(p)>o.maximumWholeMm+1e-8)return -1;const label=store.relax(state,g,parent);if(label>=0)heap.push(label,g,g+heuristic(p)+Math.floor(state/(4*N))*.15);return label}
  for(let l=0;l<4;l++)if(o.startLayers.includes(L[l]))for(const p of access[l].starts){const state=p.id+N*(l+4*o.initialViaCount),label=push(state,o.prefixWholeMm+length(p.path),-1);if(label>=0)roots.set(label,{path:p.path,layer:L[l]})}
  const foreignViaSites=[...o.input.traces.flatMap((t:R)=>t.route.filter((p:R)=>p.route_type==='via').map((p:R)=>({x:p.x,y:p.y,diameter:p.via_diameter,physicalId:t.pcb_trace_id,owner:own(t)}))),...o.input.obstacles.filter((p:R)=>p.circuitJsonMetadata?.pcb_via_id).map((p:R)=>({x:p.center.x,y:p.center.y,diameter:Math.max(p.width,p.height),physicalId:p.circuitJsonMetadata.pcb_via_id})),{x:o.start.x,y:o.start.y,diameter:VD,physicalId:'ACTUAL_INITIAL_D12_BODY_PORTAL'}]
  const fixedHoles=[...o.extraPhysicalHoles,{x:o.start.x,y:o.start.y,diameter:HD,physicalId:'ACTUAL_INITIAL_D12_BODY_PORTAL'}],viaScenes=L.map(layer=>new VectorScene(o.input,{name:'__NEW_D12_BODY_BARREL_CLEARANCE__',pointsToConnect:[{x:o.start.x,y:o.start.y,layer},{x:o.start.x,y:o.start.y,layer}]},VD,fixed)),holeGap=Math.max(o.input.minViaHoleEdgeToViaHoleEdgeClearance??0,o.input.minPlatedHoleDrillEdgeToDrillEdgeClearance??0)
  const viaClear=(cell:number)=>{const cached=viaMemo.get(cell);if(cached!==undefined)return cached;const p=access[0].point(cell),clear=viaScenes.every(s=>s.visible(p,p))&&foreignViaSites.every(v=>Number.isFinite(v.diameter)&&Math.hypot(p.x-v.x,p.y-v.y)>=VD/2+v.diameter/2+.15-1e-8)&&fixedHoles.every((h:R)=>Number.isFinite(h.diameter)&&Math.hypot(p.x-h.x,p.y-h.y)>=HD/2+h.diameter/2+holeGap-1e-8);viaMemo.set(cell,clear);return clear}
  let expanded=0
  while(heap.length&&expanded<o.maxExpanded&&performance.now()-startTime<o.caseMs&&performance.now()<o.deadlineAt){
   heap.pop();const label=heap.id,g=heap.g;if(g!==store.cost(label))continue;const state=store.state(label),cell=state%N,l=Math.floor(state/N)%4,k=Math.floor(state/(4*N)),a=access[l],goal=goals[l].get(cell);expanded++
   if(goal&&g+length(goal)+o.ends[L[l]].fanoutMm<=o.maximumWholeMm+1e-8){
    const chain:number[]=[];let v=label;while(v>=0){chain.push(v);v=store.parent(v)}chain.reverse();const root=roots.get(chain[0]);req(root,'Exact real initial attachment provenance');const route:R[]=root.path.map((p:R)=>({...p,route_type:'wire',layer:root.layer,width:W}))
    for(let i=1;i<chain.length;i++){const previous=store.state(chain[i-1]),current=store.state(chain[i]),pl=Math.floor(previous/N)%4,cl=Math.floor(current/N)%4,p=access[0].point(current%N);if(pl!==cl)route.push({route_type:'via',x:p.x,y:p.y,from_layer:L[pl],to_layer:L[cl],layers:clone(L),via_diameter:VD,via_hole_diameter:HD});route.push({...p,route_type:'wire',layer:L[cl],width:W})}
    route.push(...goal.slice(1).map((p:R)=>({...p,route_type:'wire',layer:L[l],width:W})));req(near(route[0],o.start)&&near(route.at(-1)!,o.ends[L[l]].point),'Actual portal and real RAM endpoint retained')
    record.expanded=expanded;record.sparseLabels=store.count;record.startLayer=root.layer;record.endLayer=L[l];record.ramFanoutMm=o.ends[L[l]].fanoutMm;record.rawWholeLengthMm=g+length(goal)+record.ramFanoutMm;record.outcome='RAW_FOUR_LAYER_SUFFIX_REQUIRES_INDEPENDENT_FULL_CARRIER_QUALIFICATION';return {record,trace:{type:'pcb_trace',pcb_trace_id:'raw_fixed_d12_four_layer_suffix',connection_name:o.connection.name,source_trace_id:o.connection.source_trace_id??o.connection.name,route}}
   }
   const x=cell%nx,y=Math.floor(cell/nx)
   for(const n of a.neighbors){if(x+n.dx<0||x+n.dx>=nx||y+n.dy<0||y+n.dy>=ny)continue;const next=cell+n.offset;if(a.isBlocked(next)||!a.hardEdgeIsClear(cell,n))continue;push(next+N*(l+4*k),g+n.cost*o.step,label)}
   if(k<o.maxVias&&viaClear(cell))for(let target=0;target<4;target++)if(target!==l&&!access[target].isBlocked(cell))push(cell+N*(target+4*(k+1)),g,label)
   if((expanded&65535)===0){record.expanded=expanded;record.sparseLabels=store.count;record.openStates=heap.length;record.sparseLabelLimitReached=store.limitReached;o.progress?.(clone(record))}
  }
  record.expanded=expanded;record.sparseLabels=store.count;record.sparseLabelLimitReached=store.limitReached;record.outcome=store.limitReached?'FINITE_SPARSE_LABEL_BUDGET_NO_INFEASIBILITY_CLAIM':heap.length?'FINITE_STATE_OR_TIME_BUDGET_NO_INFEASIBILITY_CLAIM':'EXHAUSTED_THIS_BOUNDED_FOUR_LAYER_MODEL';return {record}
 }finally{for(const grid of maps)grid.cancel()}
}
