from pathlib import Path
import json,hashlib,stat,copy,ast,difflib
OLD=Path('/tmp/g350-source29-native54-future53-root-guard-template-sourceonly-next');NEW=Path('/tmp/g350-source29-native54-authentic53-root-guard-sourceonly-next');R=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress/source29-three-stage-36688-PASS-COLLECTED-root.json');assert not NEW.exists();NEW.mkdir(mode=0o700)
def pin(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def put(p,b):
 with p.open('xb')as f:f.write(b)
 p.chmod(0o600)
def js(p,v):put(p,(json.dumps(v,indent=2)+'\n').encode())
m0=json.loads((OLD/'SOURCE-manifest.json').read_text());r=json.loads(R.read_text());p=json.loads(Path(r['postauditPath']).read_text());assert pin(R)['sha256']=='8495deacf6f81fc567f0bdb2616faba51b79caa4b529bb39451ac1fcdc5c143c'and r['toolSessionId']==36688 and r['toolSessionCollected']is r['authorizedByRoot']is r['passed']is True and r['toolWrapperExitCode']==r['toolExitCode']==0
assert r['scope']=='ROOT_SOURCE29_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH52_AUTHENTIC_PRIOR_CLOSURES'and r['phases']==p['phases']and r['sameGuardIdentity']['pid']==500295 and [x['execution']['pgid']for x in r['phases']]==[500361,500419,500510]
assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]and r['postauditSha256']==pin(r['postauditPath'])['sha256']
capture,types,core=r['phases'];params=dict(actual53CollectionPin=pin(R),actual53PostauditPin=pin(r['postauditPath']),actual53CapturePin=capture['result']['sourceCapturePin'],actual53DiagnosticPin=capture['result']['sourceDiagnosticPin'],actual53CoreRawPin=core['result']['rawCorePin'],actual53CoreControlsPin=core['result']['coreControlsPin'],actual53GuardManifestPin=pin('/tmp/g350-source29-three-stage-batch-source29-scope-literal-successor-sourceonly-next/SOURCE-manifest.json'),actual53ToolSessionId=36688,actual53PhasePostauditPins=[pin(row['postauditPath'])for row in r['phases']])
for name in('actual53CapturePin','actual53DiagnosticPin','actual53CoreRawPin','actual53CoreControlsPin'):assert pin(params[name]['path'])==params[name]
for index,row in enumerate(r['phases']):assert row['passed']is row['sourceAndDependenciesHeld']is row['ownedGroupEmptyActuallyObserved']is row['ownedChildNatural0']is True and row['execution']['exitCode']==0 and row['postauditSha256']==params['actual53PhasePostauditPins'][index]['sha256']
consumer=(OLD/'CLOSED53_THREE_SERIAL_SOURCE29_CHILDREN_SOURCE_ONLY_TEMPLATE.py').read_text();needle="  assert len(proposal['actual53PhasePostauditPins'])==3\n";assert consumer.count(needle)==1;consumer=consumer.replace(needle,needle+"  assert proposal['actual53ToolSessionId']==36688\n")
needle="  identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()\n";assert consumer.count(needle)==1;consumer=consumer.replace(needle,needle+"  assert identity['pid']==500295 and [row['execution']['pgid']for row in p['phases']]==[500361,500419,500510]\n")
guard0=(OLD/'run-source29-native-after53-root.proposal.py').read_text();old_consumer=(OLD/'CLOSED53_THREE_SERIAL_SOURCE29_CHILDREN_SOURCE_ONLY_TEMPLATE.py').read_text();assert guard0.count(old_consumer)==1;guard=guard0.replace(old_consumer,consumer)
needle=" assert native29_template['coreSourceManifestSha256']==";assert guard.count(needle)==1;guard=guard.replace(needle," assert native29_contract['expectedPhysicalTraceCount']==292 and native29_contract['expectedInnerAliasCount']==46 and native29_contract['expectedPhysicalPortCount']==1661\n"+needle)
ast.parse(guard)
for row in m0['files']:
 name=Path(row['path']).name
 if name=='run-source29-native-after53-root.proposal.py':raw=guard.encode()
 elif name=='CLOSED53_THREE_SERIAL_SOURCE29_CHILDREN_SOURCE_ONLY_TEMPLATE.py':raw=consumer.encode()
 elif name in('NATIVE29_STAGE_CONTRACT.json','README.md','SOURCE_ONLY_NATIVE54_TEMPLATE_PROOF.json'):continue
 else:raw=Path(row['path']).read_bytes()
 put(NEW/name,raw)
contract=json.loads((OLD/'NATIVE29_STAGE_CONTRACT.json').read_text());contract.update(actual53CollectionPin=params['actual53CollectionPin'],actual53PostauditPin=params['actual53PostauditPin'],actualCoreRawPin=params['actual53CoreRawPin'],actualCoreControlsPin=params['actual53CoreControlsPin']);js(NEW/'NATIVE29_STAGE_CONTRACT.json',contract)
def remap(v):
 if isinstance(v,dict):
  if all(k in v for k in('path','sha256','bytes','mode'))and Path(v['path']).parent==OLD:
   q=copy.deepcopy(v);q.update(pin(NEW/Path(v['path']).name));return q
  return{k:remap(x)for k,x in v.items()}
 if isinstance(v,list):return[remap(x)for x in v]
 return v
# Remove only metadata fields whose unexecuted template proof/readme are replaced here.
m=copy.deepcopy(m0);m.pop('files');old_external=m.pop('externalFiles');m=remap(m)
m.update(params);m.update(scope='SOURCE_ONLY_SOURCE29_NATIVE54_AFTER_AUTHENTIC53_THREE_SERIAL_CHILDREN',actual53Sealed=True,actual53CollectedByRoot=True,actual53ThreeSeparateChildrenHeld=True,historicalRefusingNative54TemplateManifestPin=pin(OLD/'SOURCE-manifest.json'),historicalRefusingNative54TemplateGuardPin=pin(OLD/'run-source29-native-after53-root.proposal.py'),actualClosedSdkScopeCountRemains=53,plannedFirstActualSdkScopeRemains=54,actualNative54RootReceipt=None,actualNative54Report=None,RootAuthorityCreated=False,guardHelperSdkProcessOrWorkerExecutedByAuthor=False,Source29Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingPassed=False,fabricationReady=False)
put(NEW/'EXACT_AUTHENTIC53_LITERAL_AND_CURRENT_COUNT_GATES_DELTA.patch',''.join(difflib.unified_diff(guard0.splitlines(True),guard.splitlines(True),fromfile='ba86-future53-template',tofile='native54-authentic53-source-guard')).encode())
js(NEW/'EXACT_AUTHENTIC53_DATA_BINDINGS.json',params)
# The shared Native/projector/API source manifest remains6865: no worker changes here.
proof=dict(scope='SOURCE_ONLY_AUTHENTIC53_BINDING_TO_SOURCE29_NATIVE54_GUARD',templateManifestPin=pin(OLD/'SOURCE-manifest.json'),actual53Parameters=params,stableRuntimeSourcePin=m['native29PreparationPin'],allThreeFunctionalWorkerPromotedConstantsAlreadyBound=True,guardAstParsed=True,actual53HonestThreeSeparatePhasePostauditsHeld=True,actualSource29CorePredicates29AndNonzeroSegments1053Passed=True,currentNativePolicyUnchanged90Seconds1GiB=True,expectedNativePhysicalChecks18=True,expectedPhysicalOwnerGraphs29=True,expectedTracePortAliasMissingCounts=dict(traces=292,ports=1661,aliases=46,missing=20),operationalHelperGuardSdkAppOrProcessEvaluated=False,workspaceWrites=False,RootAuthorityCreated=False,Source29Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingPassed=False,fabricationReady=False)
js(NEW/'SOURCE_ONLY_AUTHENTIC53_NATIVE54_BINDING_PROOF.json',proof)
put(NEW/'README.md',b'Source-only Native54 guard after genuine Root-collected Source29 batch53. Native child90s1GiB/shared30GiB+1GiB reserve; all18 physical/manufacturing checks,29 numeric physical graphs,all3 native pair findings and all49 logical metadata are required. Current Raw Core source29 has292 traces/1661 ports/46 inner aliases/20missing; original Core29 predicates and1053 actual segments are reauthenticated through three independent serial phase POSTs. Shared stable6865 worker source is identical for future Native/projector/API provenance. No Root authority or Native54 execution by author. Source29 remains unaccepted pending fresh Native/API/CLI/CAD; all49/reference/electrical/fabrication remain false.\n')
m['files']=[pin(p)for p in sorted(NEW.iterdir())if p.is_file()];by={}
for row in[*old_external,*m0['files'],pin(OLD/'SOURCE-manifest.json'),pin(Path(__file__))]:assert row['path']not in by or by[row['path']]==row;by[row['path']]=row
m['externalFiles']=list(by.values());m['ownFileCountExcludingManifest']=len(m['files']);m['externalFileCount']=len(m['externalFiles'])
def rows(v):
 if isinstance(v,dict):
  if all(k in v for k in('path','sha256','bytes','mode')):yield v
  else:
   for x in v.values():yield from rows(x)
 elif isinstance(v,list):
  for x in v:yield from rows(x)
allrows=list(rows(m));assert not any(any(x[k]is None for k in('path','sha256','bytes','mode'))for x in allrows)
for row in allrows:assert pin(row['path'])=={k:row[k]for k in('path','sha256','bytes','mode')}
assert "assert proposal['status']=="+repr(m['status'])in guard
js(NEW/'SOURCE-manifest.json',m)
print(json.dumps(dict(manifest=pin(NEW/'SOURCE-manifest.json'),guard=pin(NEW/'run-source29-native-after53-root.proposal.py'),consumer=pin(NEW/'CLOSED53_THREE_SERIAL_SOURCE29_CHILDREN_SOURCE_ONLY_TEMPLATE.py'),tail=pin(NEW/'NATIVE29_RUNTIME_TAIL_SOURCE_ONLY_TEMPLATE.py'),contract=pin(NEW/'NATIVE29_STAGE_CONTRACT.json'),exactDelta=pin(NEW/'EXACT_AUTHENTIC53_LITERAL_AND_CURRENT_COUNT_GATES_DELTA.patch'),concreteProposalRows=len(allrows)),indent=2))
