/** Controller-only original-method observation. No search or bank is retained. */
type MethodPrototype = object
type PrimitiveMeta = { id: number; stepCalls: number; canceled: boolean }
type GridRow = {
  id: number
  connectionName: string
  layer: string
  startX: number
  startY: number
  endX: number
  endY: number
  width: number
  margin: number
  penalty: number
  historyPresent: boolean
  lengthFrontierPresent: boolean
  maxLength: number | "Infinity"
  expanded: number
  solved: boolean
  failed: boolean
  stepCalls: number
  canceled: boolean
  stateBeforeCancel: "solved" | "naturally-failed" | "unfinished" | "already-canceled" | null
  sourceShape: "penalty-zero-no-history" | "negotiated-penalty-with-history" | "other"
}
type LastGet = {
  serial: number
  connectionName: string
  hit: boolean
  yieldedSteps: number | null
}
const LIMITS = { knownNames: 49, nameCharacters: 80, serializedBytes: 32 * 1024 }

/** Never invokes a user getter. A malformed observation must leave routing alone. */
function ownData(object: unknown, key: string): unknown {
  if (object === null || (typeof object !== "object" && typeof object !== "function"))
    throw Error("Original object required for primitive projection")
  const descriptor = Object.getOwnPropertyDescriptor(object, key)
  if (!descriptor || !Object.hasOwn(descriptor, "value"))
    throw Error(`Original own data field required: ${key}`)
  return descriptor.value
}
function optionalOwnData(object: unknown, key: string): unknown {
  if (object === null || (typeof object !== "object" && typeof object !== "function"))
    throw Error("Original object required for primitive projection")
  const descriptor = Object.getOwnPropertyDescriptor(object, key)
  if (!descriptor) return undefined
  if (!Object.hasOwn(descriptor, "value"))
    throw Error(`Original own data field required: ${key}`)
  return descriptor.value
}
function finiteNumber(value: unknown): number {
  if (typeof value !== "number" || !Number.isFinite(value))
    throw Error("Finite original scalar required")
  return value
}
function count(value: unknown): number {
  const result = finiteNumber(value)
  if (!Number.isSafeInteger(result) || result < 0)
    throw Error("Nonnegative safe original count required")
  return result
}
function boolean(value: unknown): boolean {
  if (typeof value !== "boolean") throw Error("Original boolean required")
  return value
}
function layer(value: unknown): string {
  if (typeof value !== "string" || !["top", "inner1", "inner2", "bottom"].includes(value))
    throw Error("Original four-layer name required")
  return value
}

export function installStagePrimitives(
  gridPrototype: MethodPrototype,
  replayPrototype: MethodPrototype,
  allKnownNames: readonly string[],
) {
  const names = [...new Set(allKnownNames)]
  if (
    names.length > LIMITS.knownNames ||
    names.some(name => typeof name !== "string" || name.length > LIMITS.nameCharacters)
  ) throw Error("Only bounded original names are observable")
  const known = new Set(names)
  const identities = new WeakMap<object, PrimitiveMeta>()
  const originals: Array<{ prototype: MethodPrototype; name: string; descriptor: PropertyDescriptor; replacement?: Function }> = []
  let gridInstanceCount = 0
  let originalStepCalls = 0
  let originalCancelCalls = 0
  let originalGetCalls = 0
  let observationErrors = 0
  let snapshotOverflows = 0
  let restored = false
  let lastGrid: GridRow | null = null
  let lastGet: LastGet | null = null
  let lastGridEvent: "projected" | "skipped-synthetic-pair-corridor" | null = null
  const totals = {
    steppedInstances: 0,
    canceledInstances: 0,
    cancelSolved: 0,
    cancelNaturallyFailed: 0,
    cancelUnfinished: 0,
    cancelAlreadyCanceled: 0,
    skippedSyntheticPairCorridorStepCalls: 0,
    skippedSyntheticPairCorridorCancelCalls: 0,
    penaltyZeroNoHistorySteps: 0,
    negotiatedPenaltyWithHistorySteps: 0,
    otherShapeSteps: 0,
  }
  function metadata(receiver: object) {
    let value = identities.get(receiver)
    if (!value) {
      value = { id: ++gridInstanceCount, stepCalls: 0, canceled: false }
      identities.set(receiver, value)
    }
    return value
  }
  function projectGrid(receiver: object, meta: PrimitiveMeta): GridRow {
    const scene = ownData(receiver, "scene")
    const connection = ownData(scene, "connection")
    const connectionName = ownData(connection, "name")
    if (typeof connectionName !== "string" || !known.has(connectionName))
      throw Error("Unknown original connection owner")
    const start = ownData(receiver, "start")
    const end = ownData(receiver, "end")
    const history = optionalOwnData(receiver, "history")
    if (history !== undefined && !(history instanceof Float32Array))
      throw Error("Original history type required")
    const historyPresent = history !== undefined
    const frontier = optionalOwnData(receiver, "lengthFrontier")
    const penalty = finiteNumber(ownData(receiver, "penalty"))
    const maxLengthValue = ownData(receiver, "maxLength")
    const maxLength = maxLengthValue === Infinity ? "Infinity" : finiteNumber(maxLengthValue)
    // Grid's Point arguments may omit layer (expanded native approach targets do).
    // The original local connection is the authoritative layer owner.
    const terminals = ownData(connection, "pointsToConnect")
    const startLayer = layer(ownData(ownData(terminals, "0"), "layer"))
    if (layer(ownData(ownData(terminals, "1"), "layer")) !== startLayer)
      throw Error("Original Grid carrier must be on one layer")
    return {
      id: meta.id,
      connectionName,
      layer: startLayer,
      startX: finiteNumber(ownData(start, "x")),
      startY: finiteNumber(ownData(start, "y")),
      endX: finiteNumber(ownData(end, "x")),
      endY: finiteNumber(ownData(end, "y")),
      width: finiteNumber(ownData(scene, "width")),
      margin: finiteNumber(ownData(scene, "margin")),
      penalty,
      historyPresent,
      lengthFrontierPresent: frontier !== undefined,
      maxLength,
      expanded: count(ownData(receiver, "expanded")),
      solved: boolean(ownData(receiver, "solved")),
      failed: boolean(ownData(receiver, "failed")),
      stepCalls: meta.stepCalls,
      canceled: meta.canceled,
      stateBeforeCancel: null,
      sourceShape: penalty === 0 && !historyPresent
        ? "penalty-zero-no-history"
        : penalty >= 10 && historyPresent
          ? "negotiated-penalty-with-history"
          : "other",
    }
  }
  function snapshot() {
    const value = {
      diagnosticOnly: true,
      accepted49: false,
      limits: { ...LIMITS },
      gridInstanceCount,
      originalStepCalls,
      originalCancelCalls,
      originalGetCalls,
      observationErrors,
      snapshotOverflows,
      totals: { ...totals },
      lastGrid: lastGrid ? { ...lastGrid } : null,
      lastGridEvent,
      lastGet: lastGet ? { ...lastGet } : null,
      retainedInstances: false,
      retainedGeometry: false,
      retainedGeometryObjects: false,
      retainedCoordinateScalars: true,
      retainedBankValues: false,
      weakRefUsed: false,
      additionalGridCalls: 0,
      constructorReplacementInstalled: false,
      sourceShapesAreRawFlagsNotProvenCallSiteLabels: true,
      constructorOnlyAndSkippedSyntheticInstanceCountsUnmeasured: true,
    }
    if (new TextEncoder().encode(JSON.stringify(value)).byteLength > LIMITS.serializedBytes) {
      snapshotOverflows++
      return { ...value, lastGrid: null, lastGet: null, snapshotOverflows }
    }
    return value
  }
  // Validate all original descriptors before replacing any of them.
  for (const [prototype, name] of [[gridPrototype, "step"], [gridPrototype, "cancel"], [replayPrototype, "get"]] as const) {
    const descriptor = Object.getOwnPropertyDescriptor(prototype, name)
    if (!descriptor || typeof descriptor.value !== "function" || !descriptor.writable || !descriptor.configurable)
      throw Error("Original writable Grid/replay method required")
    originals.push({ prototype, name, descriptor })
  }
  for (const binding of originals) {
    const original = binding.descriptor.value
    const replacement = function(this: object, ...args: unknown[]) {
      let beforeCancel: GridRow["stateBeforeCancel"] = null
      if (binding.name === "cancel") {
        // cancel marks an unfinished search failed; only the pre-call state distinguishes it.
        try {
          beforeCancel = identities.get(this)?.canceled
            ? "already-canceled"
            : boolean(ownData(this, "solved"))
              ? "solved"
              : boolean(ownData(this, "failed")) ? "naturally-failed" : "unfinished"
        } catch { observationErrors++ }
      }
      // Original exceptions propagate by identity. Failed original calls are not counted as returns.
      const result = Reflect.apply(original, this, args)
      try {
        if (binding.name === "get") {
          originalGetCalls++
          const name = args[0]
          if (typeof name !== "string" || !known.has(name)) throw Error("Unknown original replay owner")
          lastGet = {
            serial: originalGetCalls,
            connectionName: name,
            hit: result !== undefined,
            yieldedSteps: result === undefined ? null : count(ownData(result, "yieldedSteps")),
          }
        } else {
          if (binding.name === "step") originalStepCalls++
          else originalCancelCalls++
          const scene = ownData(this, "scene")
          const connectionName = ownData(ownData(scene, "connection"), "name")
          // The frozen coupled-pair router creates this virtual carrier owner.
          // It is not one of the 49 signal names and receives no identity/row.
          if (connectionName === "pair_corridor" && !known.has(connectionName)) {
            if (binding.name === "step") totals.skippedSyntheticPairCorridorStepCalls++
            else totals.skippedSyntheticPairCorridorCancelCalls++
            lastGrid = null
            lastGridEvent = "skipped-synthetic-pair-corridor"
            return result
          }
          const meta = metadata(this)
          if (binding.name === "step") {
            if (meta.stepCalls === 0) totals.steppedInstances++
            meta.stepCalls++
            lastGrid = projectGrid(this, meta)
            if (lastGrid.sourceShape === "penalty-zero-no-history") totals.penaltyZeroNoHistorySteps++
            else if (lastGrid.sourceShape === "negotiated-penalty-with-history") totals.negotiatedPenaltyWithHistorySteps++
            else totals.otherShapeSteps++
          } else {
            if (!meta.canceled) totals.canceledInstances++
            meta.canceled = true
            lastGrid = projectGrid(this, meta)
            lastGrid.stateBeforeCancel = beforeCancel
            if (beforeCancel === "solved") totals.cancelSolved++
            else if (beforeCancel === "naturally-failed") totals.cancelNaturallyFailed++
            else if (beforeCancel === "unfinished") totals.cancelUnfinished++
            else if (beforeCancel === "already-canceled") totals.cancelAlreadyCanceled++
          }
          lastGridEvent = "projected"
        }
      } catch { observationErrors++ }
      return result
    }
    binding.replacement = replacement
    Object.defineProperty(binding.prototype, binding.name, { ...binding.descriptor, value: replacement })
  }
  return {
    snapshot,
    restore() {
      if (restored) throw Error("Primitive stage observer restored once")
      // Validate every wrapper before restoring any descriptor.
      for (const binding of originals)
        if (optionalOwnData(binding.prototype, binding.name) !== binding.replacement)
          throw Error("Original observed method changed before restoration")
      for (const binding of originals)
        Object.defineProperty(binding.prototype, binding.name, binding.descriptor)
      restored = true
    },
  }
}
