"""Unexecuted Root-only serial capture/types/Core guard; stdlib imports only."""
import argparse,fcntl,hashlib,importlib.util,json,os,re,stat,sys
sys.dont_write_bytecode=True
from pathlib import Path
import inventory,process_scope
ROOT=Path(__file__).resolve().parent
BOARD=Path('/workspace/g350-linux-handheld')
SOURCE=ROOT
def sha(path):return inventory.sha(Path(path))
def read(path):return json.loads(Path(path).read_bytes())
def require(value,message):
 if not value:raise ValueError(message)
def binding(row):
 path=Path(row['path']);s=path.lstat()
 require(stat.S_ISREG(s.st_mode) and not path.is_symlink() and s.st_size==row['bytes'] and stat.S_IMODE(s.st_mode)==row['mode'] and sha(path)==row['sha256'],'Exact immutable file changed: '+str(path))
def verifyrows(rows):
 for row in rows:binding(row)
def verifier():
 spec=importlib.util.spec_from_file_location('exact_solver_inventory_verifier',ROOT/'verify-installed-dependencies.py')
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def checked():
 packet=ROOT/'PREPARED-manifest.json';m=read(packet)
 verifyrows(m['files']);verifyrows(m['externalFiles'])
 require(sha(SOURCE/'SOURCE-manifest.json')==m['clockSourceManifestSha256'],'Manual-only Source successor packet changed')
 source=read(SOURCE/'SOURCE-manifest.json')
 for key in ('files','lexicalLocalSourceImportClosure','runtimeAndOriginFiles','preservedPrePeerUnexecutedControlDraftFiles'):verifyrows(source[key])
 require(len(source['lexicalLocalSourceImportClosure'])==144,'Preserved original141 plus3 Source successor files required')
 for directory in m['sourceResolverDirectories']:
  directory=Path(directory)
  for name in ('.pnp.cjs','.pnp.loader.mjs','.yarn'):
   path=directory/name;require(not path.exists() and not path.is_symlink(),'Unexpected Source resolver: '+str(path))
  path=directory/'node_modules'
  if path==BOARD/'node_modules':require(path.is_dir() and not path.is_symlink(),'Actual canonical board dependency root required')
  elif str(path) in m['expectedBoardResolverBridges']:
   expected=m['expectedBoardResolverBridges'][str(path)]
   require(path.is_symlink() and os.readlink(path)==expected['target'] and stat.S_IMODE(path.lstat().st_mode)==expected['mode'] and path.resolve()==BOARD/'node_modules','Existing exact board resolver bridge changed')
  else:require(not path.exists() and not path.is_symlink(),'New shadow dependency root forbidden: '+str(path))
 deps=inventory.tree(BOARD/'node_modules');small={k:deps[k] for k in ('treeSha256','regularFiles','regularBytes','symlinks','directories')}
 require(small==m['boardDependencyInventory'],'Complete board SDK Ce3 inventory changed')
 solver=verifier().verify(Path(m['solverReceiptPath']),m['solverReceiptSha256'],ROOT/'audit-installed-dependencies.py')
 require(solver['treeSha256']==m['solverDependencyTreeSha256'] and solver['verified'] is True,'Complete solver SDK47633 inventory changed')
 # Preserve the actual successful old command and collection without inventing
 # a toolExitCode field that old47841 did not record.
 proof=read(m['passingTypeResultPath']);commands=[c for c in proof['commands'] if c['name']=='typecheck-actual-new-source']
 require(proof['passed'] is True and proof['typecheckPassed'] is True and len(commands)==1 and commands[0]['exitCode']==0,'Actual47841 compiler command was not successful')
 require(commands[0]['argv']==m['passingOriginalTypeCommand'] and m['typecheckCommand'][:-3]==commands[0]['argv'][:-3],'Original successful strict compiler flags changed')
 old=read(m['passingTypeRootCollectionPath']);post=read(m['passingTypePostauditPath'])
 require(old['toolSessionId']==47841 and old['authorizedByRoot'] is True and old['toolSessionCollected'] is True and old['toolWrapperExitCode']==0 and old['execution']==post['execution'] and post['execution']['exitCode']==0 and post['passed'] is True,'Actual47841 Root functional type proof changed')
 return m,sha(packet),small,solver
def exact_json(binding_row):
 require(re.fullmatch('[0-9a-f]{64}',binding_row.get('sha256','')) and sha(binding_row['path'])==binding_row['sha256'],'Exact actual receipt binding required')
 return read(binding_row['path'])
def collected(binding_row,tool=None,positive=False):
 c=exact_json(binding_row)
 require(c.get('authorizedByRoot') is True and c.get('toolSessionCollected') is True and isinstance(c.get('toolSessionId'),int),'Actual collected Root tool required')
 if tool is not None:require(c['toolSessionId']==tool,'Wrong required Root tool collection')
 require(isinstance(c.get('toolWrapperExitCode'),int),'Actual observed tool wrapper exit required')
 if tool==42982:require('toolExitCode' in c and c['toolExitCode']==c['toolWrapperExitCode'],'Actual42982 observed tool exits must agree')
 elif 'toolExitCode' in c:require(c['toolExitCode']==c['toolWrapperExitCode'],'Recorded observed tool exits disagree')
 p=exact_json({'path':c['postauditPath'],'sha256':c['postauditSha256']});e=p['execution']
 require(c.get('execution')==e and e.get('cleanupOwnedGroupEmpty') is True and not any(e['oomDelta'].values()),'Actual exact prior execution must be closed and OOM-free')
 require(any(p.get(k) is True for k in ('sourceAndDependenciesHeld','sourceAndArtifactsHeld','sourceAndArtifactHeld')),'Actual prior Source/dependencies must be held')
 require('dependenciesBefore' in p and 'dependenciesAfter' in p and p['dependenciesBefore']==p['dependenciesAfter'],'Actual prior complete dependency inventories must agree')
 if 'solverDependenciesBefore' in p or 'solverDependenciesAfter' in p:require(p.get('solverDependenciesBefore')==p.get('solverDependenciesAfter') and p.get('solverDependenciesBefore') is not None,'Actual prior solver dependency inventories differ')
 if positive:require(c['toolWrapperExitCode']==0 and e['exitCode']==0 and e['diagnosticStopped'] is False and p['passed'] is True,'Actual successful collected prior stage required')
 return c,p,e
def successful_stage(binding_row,phase,packet,m):
 c,p,e=collected(binding_row,positive=True)
 require(c.get('phase')==phase and c.get('packetSha256')==packet and p.get('phase')==phase and p.get('packetSha256Before')==packet and p.get('packetSha256After')==packet,'Prior stage belongs to another packet/phase')
 require(p['clockSourceManifestSha256']==m['clockSourceManifestSha256'],'Prior actual Source scope differs')
 result=exact_json({'path':p['resultPath'],'sha256':p['resultSha256']})
 require(result['passed'] is True and result['phase']==phase and result['packetSha256']==packet and result['clockSourceManifestSha256']==m['clockSourceManifestSha256'],'Actual prior stage result does not pass this Source')
 verifyrows(p['outputFiles'])
 if phase=='capture':
  capture=exact_json({'path':result['capturePath'],'sha256':result['captureSha256']})
  require(capture['actualTreeDiagnosticPath']==result['diagnosticPath'] and capture['actualTreeDiagnosticSha256']==result['diagnosticSha256'] and sha(result['diagnosticPath'])==result['diagnosticSha256'],'Actual preassertion Source tree diagnostic changed')
  require(capture['actualPureReactEvaluated'] is True and capture['exactInverseSourceProjectionPassed'] is True and capture['originalReactElementCount']==2228 and capture['proposedReactElementCount']==2232 and capture['proposedLiteralCount']-capture['originalLiteralCount']==4 and capture['originalLiteralCount']+capture['originalFragmentContainerCount']==2228 and capture['proposedLiteralCount']+capture['proposedFragmentContainerCount']==2232 and capture['originalFragmentContainerCount']==capture['proposedFragmentContainerCount'] and capture['allOriginalFragmentTypesKeysPropsAndChildOrderCompared'] is True and capture['onlyActualReactFragmentIdentityAllowed'] is True and capture['unknownElementSymbolsFunctionsRejected'] is True and capture['originalLiteralTypesKeysPropsAndChildOrderCompared'] is True and capture['allOriginalReturnedSourceMetadataCompared'] is True and capture['addedRealLayerPorts']==4 and capture['changedPCBOnlyElements']==6 and capture['changedPCBProperties']==8 and capture['changedSourcePairRepresentationElements']==3 and capture['allOriginalPairTypesPropsKeysAndChildOrderInverselyRestored'] is True and capture['actualForwardFourLocalClockPcbRenderPropsSuppressed'] is True and capture['authoritative49InputSha256']==m['authoritative49InputSha256'] and capture['originalAll3PairSkewGapDeclarationsHeld'] is True and capture['manualCoreRoutingRequired'] is True and capture['automaticCoreSrjDifferentialDiscoveryEquivalent'] is False and capture['automaticCoreSrjForThisForkMustNotBeUsed'] is True and capture['coreRendered'] is False and capture['circuitConstructedByThisWorker'] is False and capture['transitiveFrozenSourceImportsCoreDefinitions'] is True,'Actual Source inverse capture failed or import labeling changed')
 else:require(result['typecheckPassed'] is True and result['commands'][0]['argv']==m['typecheckCommand'] and result['commands'][0]['exitCode']==0,'Actual new strict types command required before Core')
 return e['pgid']
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true',required=True);parser.add_argument('--phase',choices=['capture','types','core'],required=True);parser.add_argument('--root-receipt',type=Path,required=True);parser.add_argument('--root-receipt-sha256',required=True);args=parser.parse_args()
 m,packet,before,solver_before=checked();phase=args.phase;policy=m['policies'][phase]
 a=exact_json({'path':str(args.root_receipt),'sha256':args.root_receipt_sha256})
 require(a.get('authorizedByRoot') is True and a.get('scope')==m['scope'] and a.get('phase')==phase and a.get('packetSha256')==packet and a.get('clockSourceManifestSha256')==m['clockSourceManifestSha256'] and a.get('policy')==policy and a.get('allPreviousRootWorkersCollected') is True and a.get('noConcurrentRootWorker') is True and a.get('rootFullGuardReadPassed') is True and re.fullmatch('[0-9a-f]{32,128}',a.get('approvalToken','')),'Exact Root scope/phase/serial policy/read authority required')
 initial,initial_post,initial_execution=collected(a['requiredActual42982Collection'],tool=42982)
 require(initial.get('packetSha256')==m['required42982PacketSha256'] and initial_post.get('packetSha256')==m['required42982PacketSha256'] and initial_post.get('stage')=='candidate','42982 must bind its actual9f candidate packet, not an earlier baseline ancestor')
 groups=[initial_execution['pgid']]
 additional=a.get('additionalPreviousRootCollections',[])
 for required in m['requiredAdditionalClosedRootCollections']:
  require(required in additional,'Required actual prior Root collection omitted')
 for row in additional:groups.append(collected(row)[2]['pgid'])
 prior=a.get('successfulPriorStages',{})
 require(set(prior)==({'capture'} if phase=='types' else {'capture','types'} if phase=='core' else set()),'Exactly the real successful prior stage bindings required')
 for previous in ('capture','types'):
  if previous in prior:groups.append(successful_stage(prior[previous],previous,packet,m))
 def closed_now():
  for group in groups:require(isinstance(group,int) and group>0 and group!=os.getpid() and process_scope.owned(group)==[],'Actual prior owned PGID/SID is not currently empty')
 closed_now()
 peer=exact_json(a['manualPairSourceAndGuardPeerReview']);require(peer['sourceManifestSha256']==m['clockSourceManifestSha256'] and peer['preparedManifestSha256']==packet and peer['decision']=='GO_SOURCE_ONLY_TO_ROOT_READ_AND_SERIAL_CAPTURE_TYPES_CORE','Finite manual Source and guard peer GO changed')
 run=ROOT/('run-'+phase);require(not run.exists() and not run.is_symlink(),'Exactly one fresh exclusive stage output only')
 def before_spawn(mem):
  closed_now();require(mem['current']+policy['rssBytes']+m['preforkReserveBytes']<policy['sharedBytes'],'30GiB shared budget plus1GiB reserve failed')
 with (ROOT/'serial-root.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  execution=None;run_error=None
  try:
   execution=process_scope.run_guarded([sys.executable,'-B',str(ROOT/'run_stage.py'),phase],str(BOARD),run,policy,{'G350_CLOCK_SERIAL_STAGE':phase,'G350_CLOCK_SERIAL_PACKET_SHA':packet,'G350_CLOCK_SERIAL_ROOT_RECEIPT':str(args.root_receipt.resolve()),'G350_CLOCK_SERIAL_ROOT_RECEIPT_SHA':args.root_receipt_sha256},before_spawn=before_spawn)
  except BaseException as error:
   run_error=type(error).__name__+': '+str(error)
   if (run/'execution.json').is_file():execution=read(run/'execution.json')
  post_error=None;after=None;solver_after=None;after_packet=None
  try:
   _,after_packet,after,solver_after=checked()
   require(sha(args.root_receipt)==args.root_receipt_sha256,'Root authority changed during stage')
   closed_now()
  except BaseException as error:post_error=type(error).__name__+': '+str(error)
  outputFiles=[{'path':str(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':sha(p)} for p in sorted(run.iterdir()) if p.is_file() and not p.is_symlink()] if run.is_dir() else []
  result_path=run/'result.json';result=read(result_path) if result_path.is_file() else None
  held=post_error is None and packet==after_packet and before==after and solver_before==solver_after
  clean=execution is not None and execution.get('exitCode')==0 and execution.get('diagnosticStopped') is False and execution.get('cleanupOwnedGroupEmpty') is True and not any(execution.get('oomDelta',{}).values())
  passed=run_error is None and clean and held and result is not None and result['passed'] is True and result['packetSha256']==packet and result['phase']==phase
  post={'scope':m['scope'],'phase':phase,'packetSha256Before':packet,'packetSha256After':after_packet,'clockSourceManifestSha256':m['clockSourceManifestSha256'],'rootReceiptSha256':args.root_receipt_sha256,'execution':execution,'dependenciesBefore':before,'dependenciesAfter':after,'solverDependenciesBefore':solver_before,'solverDependenciesAfter':solver_after,'sourceAndDependenciesHeld':held,'runFailure':run_error,'postverificationFailure':post_error,'resultPath':str(result_path),'resultSha256':sha(result_path) if result_path.is_file() else None,'outputFiles':outputFiles,'passed':passed,'nativeExplicitlyExecuted':False,'cadExecuted':False,'full49Qualified':False,'accepted49':False,'fabricationReady':False}
  with (ROOT/('POSTAUDIT-'+phase+'.json')).open('x') as output:json.dump(post,output,indent=2);output.write('\n')
  print(json.dumps({'phase':phase,'passed':passed,'rawAndFailureOutputsPreserved':True,'sourceAndDependenciesHeld':held,'accepted49':False,'fabricationReady':False}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
