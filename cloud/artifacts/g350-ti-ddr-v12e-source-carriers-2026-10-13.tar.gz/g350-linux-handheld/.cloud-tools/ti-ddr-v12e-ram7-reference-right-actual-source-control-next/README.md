Fresh actual pinned Core/native control for V12e.

This performs one routing-disabled build of the actual V12e React source, one unchanged public Core geometry capture with an explicit final authored bus/pair policy bridge, a pure whole-board forward comparison, and all 17 unchanged reviewed native placement/reference checks. Exactly one RAM decoupler and its two owned full-through reference aliases/stubs move +1.4 mm X; all49 CPU/RAM pads stay fixed. Original source logic, numeric pads, dimensions, clearances, lockfiles, reviewed checks patch, layers and timings remain.

The proposed-input JSON serves only as a forward expectation. The emitted routing input is copied byte-for-byte from the fresh actual Core projection after qualification. The old full Core board serves only as an independent forward expectation: every unchanged row remains compared, and exactly the capacitor, two aliases, associated artwork/CAD positions and two manual stubs move rigidly. Only new generated filesystem MD5 metadata is exempted.

Source wrapper has three files; the unchanged dependency resolver is a board node_modules symlink. The external original hardware source chain, actual V12d policy, tested pure V12e capture and native checks are bound. No DDR routing/CAD export/reference qualification/timing/fabrication is performed.

Original process_scope.py, 120-second / 3-GiB owned-RSS / 24-GiB shared / 2-GiB prefork-reserve scope remains. No lower/higher cap variant is adopted. Root must issue an exact packet-bound receipt.
