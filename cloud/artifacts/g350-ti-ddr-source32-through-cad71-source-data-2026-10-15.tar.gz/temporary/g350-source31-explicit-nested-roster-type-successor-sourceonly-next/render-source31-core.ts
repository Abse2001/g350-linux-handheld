/** Root-only fresh pinned Core render. No circuit-JSON edits or copied IDs. */
import assert from "node:assert/strict"
import { readFileSync, writeFileSync, existsSync } from "node:fs"
import { createHash } from "node:crypto"
import { buildOwnerIntermediate31Source, registerOwnerIntermediate31InnerPorts } from "./source31.circuit"
import proposalData from "./source31-proposal.json"
import type { Source31Proposal } from "./source31-types"
const proposal=proposalData as unknown as Source31Proposal
import material from "/workspace/g350-linux-handheld/.cloud-tools/ddr-source24-joint-editable-source-stages-sourceonly-next/material-controller-plan.json"
type Row = Record<string, any>
const [output, reportPath, actualCapturePath, ...extra] = process.argv.slice(2)
assert.equal(process.env.G350_SOURCE31_CORE_ROOT_GUARDED, "1")
assert.equal(process.versions.bun, "1.3.14")
assert(proposal.actualParent29Qualification !== null && proposal.actualParent29Capture !== null && proposal.jointIntermediateViaGeometryPeer !== null, "Preparation only: genuine fully qualified29 parent evidence must be bound")
assert(Object.values(proposal.actualParent29Stages).every(pin => pin !== null), "All actual parent29 stages must be bound")
assert.ok(output && reportPath && actualCapturePath && extra.length === 0 && output !== reportPath && !existsSync(output) && !existsSync(reportPath))
const sha = (p: string) => createHash("sha256").update(readFileSync(p)).digest("hex")
for (const binding of Object.values(proposal.inputBindings as Record<string,{path:string;sha256:string}>)) assert.equal(sha(binding.path), binding.sha256)
assert.equal(sha(material.sourceProposal.path), material.sourceProposal.sha256)
assert.equal(sha(material.independentSourcePlacementAndReferenceFormulaProof.path), material.independentSourcePlacementAndReferenceFormulaProof.sha256)
assert.equal(sha("/workspace/g350-linux-handheld/node_modules/@tscircuit/core/dist/index.js"), "97b8a4eb484630c3ce2bfc2d68588801484d85adf94785d8849a1d91c4404905")
assert.equal(sha("/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js"), "1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc")
const capture = JSON.parse(readFileSync(actualCapturePath, "utf8"))
assert.equal(capture.passed, true); assert.equal(capture.fullInverseSourceTreePassed, true)
assert.equal(capture.sourceOnlyProposalSha256, sha(new URL("./source31-proposal.json", import.meta.url).pathname))
assert.equal(capture.proposedReactElementCount, proposal.expectedCounts.expectedReactElements); assert.equal(capture.coreRendered, false)
const baseline = JSON.parse(readFileSync(proposal.inputBindings.actualSmooth18CoreRaw.path, "utf8")) as Row[]
const native = JSON.parse(readFileSync(proposal.inputBindings.ownerMoved22NativeHypothesis.path, "utf8")) as Row
const independent = JSON.parse(readFileSync(material.independentSourcePlacementAndReferenceFormulaProof.path, "utf8")) as Row
const { Circuit } = await import("/workspace/g350-linux-handheld/node_modules/@tscircuit/core/dist/index.js")
const circuit = new Circuit(); circuit.schematicDisabled = true; circuit.pcbRoutingDisabled = true
const source = buildOwnerIntermediate31Source(); circuit.add(source.element as any)
const matches = registerOwnerIntermediate31InnerPorts(circuit)
await circuit.renderUntilSettled()
const serialized = `${JSON.stringify(circuit.getCircuitJson(), null, 2)}\n`
writeFileSync(output, serialized, { flag: "wx", mode: 0o600 })
// Inspect exactly the retained serializer bytes, avoiding undefined/absent noise.
const core = JSON.parse(serialized) as Row[]
const checks: Row[] = [], check = (label: string, passed: boolean, actual: unknown, expected?: unknown) => checks.push({ label, passed, actual, expected })
const rows = (type: string) => core.filter(row => row.type === type)
const canonical = (value: any): string => Array.isArray(value) ? `[${value.map(canonical).join(",")}]`
  : value && typeof value === "object" ? `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}` : JSON.stringify(value) ?? "undefined"
const omit = (row: Row, fields: string[]) => Object.fromEntries(Object.entries(row).filter(([key]) => !fields.includes(key)))
const near = (a: Row, b: Row) => !!a && !!b && Math.hypot(a.x - b.x, a.y - b.y) < 1e-8
const geometrySame = (a: any, b: any): boolean => {
  if (typeof a === "number" && typeof b === "number") return Number.isFinite(a) && Number.isFinite(b) && Math.abs(a-b) < 1e-8
  if (Array.isArray(a) || Array.isArray(b)) return Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((v,i) => geometrySame(v,b[i]))
  if (a && b && typeof a === "object" && typeof b === "object") return canonical(Object.keys(a).sort()) === canonical(Object.keys(b).sort()) && Object.keys(a).every(key => geometrySame(a[key],b[key]))
  return a === b
}
const oldSource = new Map(baseline.filter(row => row.type === "source_component").map(row => [row.source_component_id,row]))
const sourceComponents = rows("source_component"), sourcePorts = rows("source_port"), pcbPorts = rows("pcb_port")
const componentByName = (name: string) => sourceComponents.filter(row => row.name === name)
const sourcePortBySelector = (selector: string) => {
  const match = /^(.*)\.pin(\d+)$/.exec(selector), component = match ? componentByName(match[1]) : []
  return component.length === 1 ? sourcePorts.filter(row => row.source_component_id === component[0].source_component_id && row.pin_number === Number(match![2])) : []
}
for (const [type, expected] of [["source_component",280],["source_trace",1195],["pcb_component",509],["pcb_smtpad",1161],["pcb_plated_hole",4],["pcb_hole",2],
  ["pcb_via",229],["source_manually_placed_via",229],["pcb_trace",proposal.expectedCounts.physicalTraces],["source_port",proposal.expectedCounts.expectedSourcePorts],["pcb_port",proposal.expectedCounts.expectedSourcePorts],["source_net",98],["source_bus",8],["pcb_keepout",2]] as const)
  check(`exact-${type}-count`,rows(type).length === expected,rows(type).length,expected)
check("public-genuine-inner-port-matches",matches.registrations.length === proposal.expectedCounts.innerLiteralPorts,matches.registrations.length,proposal.expectedCounts.innerLiteralPorts)
const componentProjection = material.realPartTargets280.map(target => {
  const sc = componentByName(target.sourceComponentName), physical = sc.length === 1 ? rows("pcb_component").filter(row => row.source_component_id === sc[0].source_component_id) : []
  const expected = omit(target.expectedPcbComponent,["pcb_component_id","source_component_id"])
  const passed = physical.length === 1 && geometrySame(omit(physical[0],["pcb_component_id","source_component_id"]),expected)
    && canonical(sc[0]) === canonical(oldSource.get(target.actualOldSourceComponentId))
  return { name:target.sourceComponentName,actualSourceComponentId:sc[0]?.source_component_id??null,actualPcbComponentId:physical[0]?.pcb_component_id??null,passed }
})
check("all280-real-parts-metadata-footprint-shape-and-explicit-placement",componentProjection.every(row=>row.passed),componentProjection.filter(row=>row.passed).length,280)
const priorOwnership = independent.actual225ViaLiteralAliasOwnership as Row[]
const oldViaNameByOwner = new Map(priorOwnership.map(row=>[row.actualSourceManuallyPlacedViaOwnerId,row.capturedSourceLiteralName]))
const actualViaNameByOwner = new Map<string,string>(), remainingVias = rows("pcb_via").slice()
const physicalViaTargets: Row[] = [
  ...material.referenceViaTargets129.map(target=>({name:target.sourceViaName,xy:target.expectedPhysical,reference:true})),
  ...proposal.all98NumericOwnedSignalBranches.map((owner:Row)=>({name:owner.viaName,xy:owner.viaXY,reference:false})),
  ...proposal.intermediateCarrierVias.map(owner=>({name:owner.viaName,xy:owner.xy,reference:false,carrierOwned:true,ownerOriginalSourceTraceId:owner.originalSourceTraceId})),
]
const viaProjection = physicalViaTargets.map(target => {
  const instance = circuit.selectOne(`.${target.name}`) as any
  const found = remainingVias.filter(row=>near(row,target.xy)&&row.outer_diameter===.4572&&row.hole_diameter===.254)
  const via = found.length === 1 ? found[0] : null
  const aliases = via?.pcb_port_ids?.map((id:string)=>{
    const port = pcbPorts.filter(row=>row.pcb_port_id===id), sp = port.length===1 ? sourcePorts.filter(row=>row.source_port_id===port[0].source_port_id) : []
    const component = port.length===1 ? rows("pcb_component").filter(row=>row.pcb_component_id===port[0].pcb_component_id) : []
    const owner = sp[0]?.source_component_id, authentic = !!via&&port.length===1&&sp.length===1&&component.length===1
      && owner===instance?.source_manually_placed_via_id&&component[0].source_component_id===owner
      && rows("source_manually_placed_via").filter(row=>row.source_manually_placed_via_id===owner).length===1
      && sourceComponents.every(row=>row.source_component_id!==owner)&&near(port[0],via)&&near(component[0].center,via)
      && component[0].width===.4572&&component[0].height===.4572&&component[0].layer==="top"&&component[0].rotation===0
      && port[0].layers.length===1&&sp[0].name===port[0].layers[0]
    return {actualPcbPortId:id,actualSourcePortId:sp[0]?.source_port_id??null,actualSourceViaOwner:owner??null,layer:port[0]?.layers[0]??null,authentic}
  })??[]
  const expectedLayers = ["top","bottom",...proposal.added50RealInnerLayerPorts.filter(row=>row.viaName===target.name).map(row=>row.layer)].sort()
  const passed = !!via&&instance?.componentName==="Via"&&instance.props.name===target.name&&instance.pcb_via_id===via.pcb_via_id
    && canonical(via.layers)===canonical(["top","inner1","inner2","bottom"])&&via.from_layer==="top"&&via.to_layer==="bottom"
    && via.tented_on_top===true&&via.tented_on_bottom===true&&aliases.every((row:Row)=>row.authentic)
    && (!target.carrierOwned || (instance.props.connectsTo===undefined&&via.source_net_id===undefined&&via.source_trace_id===undefined))
    && aliases.length===expectedLayers.length&&canonical(aliases.map((row:Row)=>row.layer).sort())===canonical(expectedLayers)
    && new Set(aliases.map((row:Row)=>row.actualPcbPortId)).size===aliases.length
  if (passed) { remainingVias.splice(remainingVias.indexOf(via!),1); actualViaNameByOwner.set(instance.source_manually_placed_via_id,target.name) }
  return {sourceViaName:target.name,reference:target.reference,carrierOwned:target.carrierOwned===true,ownerOriginalSourceTraceId:target.ownerOriginalSourceTraceId??null,actualViaId:via?.pcb_via_id??null,actualSourceViaOwner:instance?.source_manually_placed_via_id??null,aliases,passed}
})
check("all229-real-declared-barrels-129reference-98endpoints-2carrier-and-every-alias-once",viaProjection.every(row=>row.passed)&&remainingVias.length===0,{matched:viaProjection.filter(row=>row.passed).length,unmatched:remainingVias.length},{matched:229,unmatched:0})
const portSemantic = (id: string, records: Row[], viaNames: Map<string,string>) => {
  const ports=records.filter(row=>row.type==="source_port"&&row.source_port_id===id)
  if (ports.length!==1) return null
  const p=ports[0], components=records.filter(row=>row.type==="source_component"&&row.source_component_id===p.source_component_id)
  return components.length===1 ? {componentName:components[0].name,pinNumber:p.pin_number,name:p.name}
    : viaNames.has(p.source_component_id) ? {viaName:viaNames.get(p.source_component_id),layer:p.name} : null
}
const routeShape = (route: Row[])=>route.map(point=>omit(point,["start_pcb_port_id","end_pcb_port_id"]))
const routesSame = (a:Row[],b:Row[])=>geometrySame(routeShape(a),routeShape(b))||geometrySame(routeShape(a),routeShape(b).reverse())
const remainingTraces=rows("pcb_trace").slice()
const references=material.referencePathTargets165.map(target=>{
  const old=baseline.find(row=>row.type==="source_trace"&&row.source_trace_id===target.actualBeforeSourceTraceId)
  const logical=rows("source_trace").filter(row=>row.name===target.literalTraceName)
  const candidates=logical.length===1?remainingTraces.filter(row=>row.source_trace_id===logical[0].source_trace_id&&routesSame(row.route,target.expectedTargetRoute)):[]
  const semanticOwnerHeld=!!old&&logical.length===1&&canonical(old.connected_source_port_ids.map((id:string)=>portSemantic(id,baseline,oldViaNameByOwner)))
    ===canonical(logical[0].connected_source_port_ids.map((id:string)=>portSemantic(id,core,actualViaNameByOwner)))
    && canonical(omit(old,["source_trace_id","connected_source_port_ids","subcircuit_connectivity_map_key"]))
      ===canonical(omit(logical[0],["source_trace_id","connected_source_port_ids","subcircuit_connectivity_map_key"]))
  const passed=candidates.length===1&&semanticOwnerHeld
  if(passed)remainingTraces.splice(remainingTraces.indexOf(candidates[0]),1)
  return {literalTraceName:target.literalTraceName,actualSourceTraceId:logical[0]?.source_trace_id??null,actualPcbTraceId:candidates[0]?.pcb_trace_id??null,passed,semanticOwnerHeld}
})
check("all165-reference-paths-owner-and-source-generated-planning-geometry",references.every(row=>row.passed),references.filter(row=>row.passed).length,165)
const oldPcbPorts=new Map(baseline.filter(row=>row.type==="pcb_port").map(row=>[row.pcb_port_id,row]))
const stripLand=(row:Row)=>omit(row,["pcb_smtpad_id","pcb_plated_hole_id","pcb_component_id","pcb_port_id"])
const remainingLands=[...rows("pcb_smtpad"),...rows("pcb_plated_hole")]
const lands=(native.allOriginalCopperLands as Row[]).map(target=>{
  const oldPort=oldPcbPorts.get(target.pcb_port_id), expectedOwner=oldPort?portSemantic(oldPort.source_port_id,baseline,oldViaNameByOwner):null
  const candidates=remainingLands.filter(row=>geometrySame(stripLand(row),stripLand(target))&&(()=>{
    const port=pcbPorts.find(p=>p.pcb_port_id===row.pcb_port_id)
    return expectedOwner!==null&&!!port&&canonical(portSemantic(port.source_port_id,core,actualViaNameByOwner))===canonical(expectedOwner)
  })())
  if(candidates.length===1)remainingLands.splice(remainingLands.indexOf(candidates[0]),1)
  return {originLandIdOnly:target.pcb_smtpad_id??target.pcb_plated_hole_id,actualLandId:candidates[0]?.pcb_smtpad_id??candidates[0]?.pcb_plated_hole_id??null,passed:candidates.length===1}
})
check("all1165-physical-lands-and-genuine-numeric-owners",lands.every(row=>row.passed)&&remainingLands.length===0,{matched:lands.filter(row=>row.passed).length,unmatched:remainingLands.length},{matched:1165,unmatched:0})
const original49:Row[]=proposal.all49OriginalLogicalTraces.map((target:Row)=>{
  const old=baseline.find(row=>row.type==="source_trace"&&row.source_trace_id===target.originalSourceTraceId), actual=rows("source_trace").filter(row=>row.name===target.name)
  const cpu=sourcePortBySelector(target.from),ram=sourcePortBySelector(target.to),pins=cpu.length===1&&ram.length===1?[cpu[0].source_port_id,ram[0].source_port_id]:[]
  const passed=!!old&&actual.length===1&&actual[0].source_trace_id===target.originalSourceTraceId
    && canonical(actual[0].connected_source_port_ids)===canonical(pins)
    && canonical(omit(actual[0],["subcircuit_connectivity_map_key"]))===canonical(omit(old,["subcircuit_connectivity_map_key"]))
  return {originalSourceTraceId:target.originalSourceTraceId,actualSourceTraceId:actual[0]?.source_trace_id??null,numericPins:pins,passed}
})
check("all49-original-numeric-traces-and-every-logical-constraint",original49.every(row=>row.passed),original49.filter(row=>row.passed).length,49)
const selected=new Map<string,Row>(proposal.selected31OriginalCarriers.map(row=>[row.originalSourceTraceId,row]))
const stubs:Row[]=proposal.all98NumericOwnedSignalBranches.map((owner:Row)=>{
  const target=owner.topStub, candidates=remainingTraces.filter(row=>routesSame(row.route,target))
  const local=rows("source_trace").filter(row=>row.name===owner.traceName),numeric=sourcePortBySelector(owner.numericSelector)
  const alias=viaProjection.find(row=>row.sourceViaName===owner.viaName)?.aliases.find((row:Row)=>row.layer==="top")
  const direct=selected.has(owner.originalSourceTraceId), expectedSource=direct?owner.originalSourceTraceId:local[0]?.source_trace_id
  const localOwner=local.length===1&&numeric.length===1&&alias&&canonical(local[0].connected_source_port_ids)===canonical([numeric[0].source_port_id,alias.actualSourcePortId])
  const localPcb=local.length===1?rows("pcb_trace").filter(row=>row.source_trace_id===local[0].source_trace_id):[]
  const passed=candidates.length===1&&candidates[0].source_trace_id===expectedSource&&localOwner&&localPcb.length===(direct?0:1)
  if(passed)remainingTraces.splice(remainingTraces.indexOf(candidates[0]),1)
  return {originalSourceTraceId:owner.originalSourceTraceId,side:owner.side,viaName:owner.viaName,actualPcbTraceId:candidates[0]?.pcb_trace_id??null,actualLocalSourceTraceId:local[0]?.source_trace_id??null,passed}
})
check("all98-numeric-owned-Topstubs-no-duplicate-render",stubs.every(row=>row.passed),stubs.filter(row=>row.passed).length,98)
const carriers=proposal.selected31OriginalCarriers.map(target=>{
  // Only the exact Source20+Source21 roster has the declared four-path/two-layer architecture.
  // The existing29 one-body/three-path checks below remain unchanged.
  if(["source_trace_20","source_trace_21"].includes(target.originalSourceTraceId)){
    const id=target.originalSourceTraceId
    const paths=rows("pcb_trace").filter(row=>row.source_trace_id===id)
    const specific=target.carrierArchitecture==="TWO_LAYER_ONE_OWNED_INTERMEDIATE_VIA"&&target.expectedPhysicalPathCount===4&&target.carrierPieces.length===2&&target.ownedIntermediateCarrierVias.length===1
    const ownedVia=proposal.intermediateCarrierVias.find(v=>v.originalSourceTraceId===id)!,carrierVia=viaProjection.find(row=>row.sourceViaName===ownedVia.viaName)
    const cpuVia=viaProjection.find(row=>row.sourceViaName===target.cpu.viaName),ramVia=viaProjection.find(row=>row.sourceViaName===target.ram.viaName)
    const alias=(via:Row|undefined,layer:string)=>via?.aliases.find((row:Row)=>row.layer===layer&&row.authentic)
    const pairs=[[alias(cpuVia,"inner2"),alias(carrierVia,"inner2")],[alias(carrierVia,"top"),alias(ramVia,"top")]]
    const pieces=target.carrierPieces.map((piece:Row,index:number)=>{
      const expected=piece.expectedPath.map((p:Row)=>({...p,route_type:"wire",layer:piece.layer,width:.1016}))
      const found=remainingTraces.filter(row=>row.source_trace_id===id&&routesSame(row.route,expected)),body=found.length===1?found[0]:null
      const [a,b]=pairs[index],route=body?.route??[]
      const passed=!!body&&!!a&&!!b&&route[0]?.start_pcb_port_id===a.actualPcbPortId&&route[route.length-1]?.end_pcb_port_id===b.actualPcbPortId
        &&body.route.every((p:Row)=>p.route_type==="wire"&&p.layer===piece.layer&&p.width===.1016)
      return {role:piece.role,layer:piece.layer,actualPcbTraceId:body?.pcb_trace_id??null,startActualPcbPortId:a?.actualPcbPortId??null,endActualPcbPortId:b?.actualPcbPortId??null,passed}
    })
    const topStubs=[target.cpu,target.ram].map((owner:Row,side:number)=>stubs.find(row=>row.originalSourceTraceId===id&&row.side===side))
    const numeric=[target.cpu,target.ram].map((owner:Row)=>{const sp=sourcePortBySelector(owner.numericSelector);return sp.length===1?pcbPorts.filter(p=>p.source_port_id===sp[0].source_port_id):[]})
    const graph=new Map<string,Set<string>>(),edges:Row[]=[]
    const join=(a:string,b:string,basis:Row)=>{for(const n of [a,b])if(!graph.has(n))graph.set(n,new Set());graph.get(a)!.add(b);graph.get(b)!.add(a);edges.push({fromActualId:a,toActualId:b,...basis})}
    let graphValid=paths.length===4&&paths.every(t=>t.route.length>=2&&t.route.every((p:Row)=>p.route_type==="wire"))
    if(graphValid)for(const t of paths){const a=t.route[0],b=t.route.at(-1),start=pcbPorts.find(p=>p.pcb_port_id===a.start_pcb_port_id),end=pcbPorts.find(p=>p.pcb_port_id===b.end_pcb_port_id);if(!start||!end||!near(start,a)||!near(end,b)||!start.layers.includes(a.layer)||!end.layers.includes(b.layer)){graphValid=false;break}join(start.pcb_port_id,end.pcb_port_id,{basis:"ACTUAL_EXPLICIT20_OR21_OWNED_WIRE_PATH",actualPcbTraceId:t.pcb_trace_id,actualSourceTraceId:t.source_trace_id})}
    if(graphValid)for(const mapping of [cpuVia,carrierVia,ramVia]){const v=mapping?rows("pcb_via").find(v=>v.pcb_via_id===mapping.actualViaId):null;if(!v||!mapping?.passed){graphValid=false;break}for(const id of v.pcb_port_ids){const p=pcbPorts.find(p=>p.pcb_port_id===id);if(!p||!near(p,v)||!p.layers.every((l:string)=>v.layers.includes(l))){graphValid=false;break}join(id,v.pcb_via_id,{basis:"ACTUAL_FULLSPAN_BARREL_OWNED_ALIAS",actualSourceViaOwner:mapping.actualSourceViaOwner})}}
    const begin=numeric[0].length===1?numeric[0][0].pcb_port_id:null,end=numeric[1].length===1?numeric[1][0].pcb_port_id:null,queue:string[]=begin?[begin]:[],previous=new Map<string,string|null>(begin?[[begin,null]]:[])
    if(graphValid)for(let i=0;i<queue.length;i++)for(const n of graph.get(queue[i])??[])if(!previous.has(n)){previous.set(n,queue[i]);queue.push(n)}
    const connected=!!end&&previous.has(end),idPath:string[]=[];if(connected)for(let n:string|null=end;n!==null;n=previous.get(n)??null)idPath.unshift(n)
    const whole=paths.reduce((sum,t)=>sum+t.route.slice(1).reduce((s:number,p:Row,i:number)=>s+Math.hypot(p.x-t.route[i].x,p.y-t.route[i].y),0),0)
    const expectedIds=[...pieces.map((p:Row)=>p.actualPcbTraceId),...topStubs.map(p=>p?.actualPcbTraceId)]
    const exactRoster=expectedIds.length===4&&new Set(expectedIds).size===4&&canonical(expectedIds.slice().sort())===canonical(paths.map(t=>t.pcb_trace_id).sort())
    const passed=specific&&pieces.every((p:Row)=>p.passed)&&topStubs.every(p=>p?.passed)&&!!carrierVia?.carrierOwned&&carrierVia.ownerOriginalSourceTraceId===id&&carrierVia.passed&&graphValid&&connected&&exactRoster&&Math.abs(whole-target.expectedWholePlanarMm)<1e-8
    if(passed)for(const p of pieces){const body=remainingTraces.find(t=>t.pcb_trace_id===p.actualPcbTraceId);if(body)remainingTraces.splice(remainingTraces.indexOf(body),1)}
    return {originalSourceTraceId:id,carrierArchitecture:target.carrierArchitecture,carrierLayer:null,actualCarrierPcbTraceId:null,actualCarrierPcbTraceIds:pieces.map((p:Row)=>p.actualPcbTraceId),actualDirectPcbTraceIds:paths.map(t=>t.pcb_trace_id),carrierPieces:pieces,actualWholePlanarMm:whole,expectedWholePlanarMm:target.expectedWholePlanarMm,physicalFullThroughBarrels:3,actualRemovableCarrierViaIds:[carrierVia?.actualViaId??null],actualCpuCarrierLayerPcbPortId:pairs[0][0]?.actualPcbPortId??null,actualRamCarrierLayerPcbPortId:pairs[1][1]?.actualPcbPortId??null,actualActiveLayerTransitions:[{x:target.cpu.viaXY.x,y:target.cpu.viaXY.y,fromLayer:"top",toLayer:"inner2"},{x:ownedVia.xy.x,y:ownedVia.xy.y,fromLayer:"inner2",toLayer:"top"}],actualSourceOwnedPhysicalGraph:{actualEdges:edges,actualNumericCpuToRamIdPath:idPath,physicallyConnected:connected&&graphValid,logicalMapAloneNotUsed:true},intermediateViaIsNotFixedFanout:true,passed}
  }
  const paths=rows("pcb_trace").filter(row=>row.source_trace_id===target.originalSourceTraceId)
  const expected=target.expectedCarrierPath.map((point:Row)=>({...point,route_type:"wire",layer:target.carrierLayer,width:.1016}))
  const candidates=remainingTraces.filter(row=>row.source_trace_id===target.originalSourceTraceId&&routesSame(row.route,expected))
  const actualCarrier=candidates.length===1?candidates[0]:null
  const anchors=[target.cpu,target.ram].map((owner:Row,side:number)=>{
    const via=viaProjection.find(row=>row.sourceViaName===owner.viaName),alias=via?.aliases.find((row:Row)=>row.layer===target.carrierLayer)
    const path=actualCarrier?.route??[],endpoint=side===0?path[0]?.start_pcb_port_id:path[path.length-1]?.end_pcb_port_id
    const numeric=sourcePortBySelector(owner.numericSelector),actualNumeric=numeric.length===1?pcbPorts.filter(row=>row.source_port_id===numeric[0].source_port_id):[]
    const stub=stubs.find(row=>row.originalSourceTraceId===target.originalSourceTraceId&&row.side===side)
    const passed=!!via?.passed&&!!alias?.authentic&&endpoint===alias.actualPcbPortId&&actualNumeric.length===1&&near(actualNumeric[0],owner.padXY)&&!!stub?.passed
    return {viaName:owner.viaName,actualViaId:via?.actualViaId??null,actualCarrierLayerPcbPortId:alias?.actualPcbPortId??null,actualNumericSourcePortId:numeric[0]?.source_port_id??null,actualNumericPcbPortId:actualNumeric[0]?.pcb_port_id??null,passed}
  })
  const whole=paths.reduce((sum,row)=>sum+row.route.slice(1).reduce((length:number,point:Row,i:number)=>length+Math.hypot(point.x-row.route[i].x,point.y-row.route[i].y),0),0)
  const passed=paths.length===3&&!!actualCarrier&&anchors.every(row=>row.passed)&&Math.abs(whole-target.expectedWholePlanarMm)<1e-8&&paths.every(row=>row.route.every((point:Row)=>point.route_type==="wire"))
  if(passed)remainingTraces.splice(remainingTraces.indexOf(actualCarrier!),1)
  return {originalSourceTraceId:target.originalSourceTraceId,carrierLayer:target.carrierLayer,actualDirectPcbTraceIds:paths.map(row=>row.pcb_trace_id),actualCarrierPcbTraceId:actualCarrier?.pcb_trace_id??null,actualWholePlanarMm:whole,expectedWholePlanarMm:target.expectedWholePlanarMm,anchors,passed}
})
check("all29-original-three-path-carriers-plus-exact-source20-source21-four-path-two-layer-graphs",carriers.every(row=>row.passed)&&remainingTraces.length===0,{matched:carriers.filter(row=>row.passed).length,unmatched:remainingTraces.map(row=>row.pcb_trace_id)},{matched:proposal.expectedCounts.carrierPaths,unmatched:[]})
for(const type of ["source_bus","source_net","pcb_hole","pcb_plated_hole","pcb_keepout","pcb_board"]){
  const old=baseline.filter(row=>row.type===type),actual=rows(type)
  const shape=(row:Row)=>type==="source_bus"?omit(row,["source_bus_id"]):row
  check(`${type}-full-original-serialized-semantic-bijection`,old.length===actual.length&&old.every(row=>actual.filter(now=>canonical(shape(row))===canonical(shape(now))).length===1),actual.length,old.length)
}
const unselected=proposal.all49OriginalLogicalTraces.filter((row:Row)=>!selected.has(row.originalSourceTraceId))
check("remaining-original-carriers-remain-explicitly-unrouted",unselected.length===proposal.expectedCounts.remainingOriginal49Requests&&unselected.every((row:Row)=>rows("pcb_trace").every(trace=>trace.source_trace_id!==row.originalSourceTraceId)),unselected.length,proposal.expectedCounts.remainingOriginal49Requests)
const report={scope:"ROOT_FRESH_EDITABLE_SOURCE_CORE_229_SOURCE20_SOURCE21_INTERMEDIATE_VIAS_31",rawCorePath:output,rawCoreSha256:createHash("sha256").update(serialized).digest("hex"),actualCapturePath,actualCaptureSha256:sha(actualCapturePath),
 source3OwnerEvent: { sourceViaName: "V_TI_SIGNAL_source_trace_3_0", capturedPriorViaIdProvenanceOnly: "pcb_via_135", actualViaProjection: viaProjection.find(row=>row.sourceViaName==="V_TI_SIGNAL_source_trace_3_0"), actualTopStubProjection: stubs.find(row=>row.originalSourceTraceId==="source_trace_3"&&row.side===0), actualCarrierProjection: carriers.find(row=>row.originalSourceTraceId==="source_trace_3"), freshIdsDerivedFromActualCore: true, capturedIdAssignedToFreshCore: false },
 explicitIntermediateCarrierViaProjection:viaProjection.filter(row=>row.carrierOwned),all29PriorCarrierGeometryHeldByExactSourceInverse:true,source20And21ExactFourPathArchitectureOnly:true,checks,freshCoreControlPassed:checks.every(row=>row.passed),componentProjection,viaProjection,referenceProjection:references,landProjection:lands,original49Projection:original49,signalTopProjection:stubs,carriers,
 actualNonzeroWireSegmentCount:rows("pcb_trace").reduce((sum,row)=>sum+row.route.slice(1).filter((point:Row,i:number)=>point.route_type==="wire"&&row.route[i].route_type==="wire"&&Math.hypot(point.x-row.route[i].x,point.y-row.route[i].y)>0).length,0),
 actualSourceDerivedCopperPours:rows("pcb_copper_pour"),actualHardwareKeepouts:rows("pcb_keepout"),
 authoredPourLiteralsHeldByActualSourceInverse:true,sourcePourClipAndIslandOutputNotAssertedFromStaleOld18:true,
 actualSourcePortMatches:matches,sourceNumericAndPhysicalIdsDerivedWithoutAssignment:true,circuitJsonGeometryEdited:false,pcbRoutingDisabled:true,
 parent29ActualQualificationInherited:false,expectedOriginalCarrierCount:proposal.expectedCounts.carrierPaths,expectedMissingOriginalSignalCount:proposal.expectedCounts.remainingOriginal49Requests,nativeExecuted:false,cadExecuted:false,
 manualPairSourceBusForkHeld:true,automaticCoreSrjForThisForkMustNotBeUsed:true,originalCouplingApisRequiredAgainstFreshActualGeometry:true,
 referenceQualified:false,electricalTimingPassed:false,all49Accepted:false,fabricationReady:false}
writeFileSync(reportPath,`${JSON.stringify(report,null,2)}\n`,{flag:"wx",mode:0o600})
assert.equal(report.freshCoreControlPassed,true,"Complete raw Core and failure controls are retained before asserting")
console.log(JSON.stringify({scope:report.scope,freshCoreControlPassed:true,output,reportPath,all49Accepted:false}))
