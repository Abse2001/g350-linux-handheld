/** Root-owned isolated fresh original Grid diagnostic. No observers or pipeline. */
import assert from "node:assert/strict"
import crypto from "node:crypto"
import fs from "node:fs"
import path from "node:path"
import { fileURLToPath } from "node:url"
import { GridVisibilitySearch } from "../g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/grid-visibility"
import { VectorScene } from "../g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/vector-scene"
import { length } from "../g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/geometry"

const ROOT = path.dirname(fileURLToPath(import.meta.url)), OUT = path.join(ROOT, "run")
const CAPTURE = "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/run/latest-clock-hard-scene.json"
const CAPTURE_SHA = "6bca749985625ab2fc0de67563aa4031e7527f7951b35b4725f1bb5b33eeb0c8"
const EXPANSION_CAP = 500000, REPORT_LIMIT = 256 * 1024, PATH_LIMIT = 1024 * 1024
const hash = (raw: string | Uint8Array) => crypto.createHash("sha256").update(raw).digest("hex")
function own(object: any, key: string, optional = false): any {
  assert.ok(object !== null && typeof object === "object", "Own data object required")
  const descriptor = Object.getOwnPropertyDescriptor(object, key)
  if (!descriptor && optional) return undefined
  assert.ok(descriptor && "value" in descriptor, "Own data property required: " + key)
  return descriptor.value
}
function materialSha(value: any): string {
  const digest = crypto.createHash("sha256"), active = new Set<object>()
  let nodes = 0
  function visit(value: any, depth = 0) {
    assert.ok(++nodes <= 100000 && depth <= 48, "Own-data fingerprint bound")
    if (value === undefined) { digest.update("undefined;"); return }
    if (value === null) { digest.update("null;"); return }
    if (typeof value === "number") { assert.ok(Number.isFinite(value));digest.update("number:" + String(value) + ";");return }
    if (typeof value === "string" || typeof value === "boolean") { digest.update(typeof value + ":" + JSON.stringify(value) + ";");return }
    assert.equal(typeof value, "object")
    const array = Array.isArray(value), prototype = Object.getPrototypeOf(value)
    assert.ok(array ? prototype === Array.prototype : prototype === Object.prototype || prototype === null)
    assert.ok(!active.has(value), "Acyclic own data required");active.add(value)
    digest.update(array ? "array{" : "object{")
    for (const key of Reflect.ownKeys(value)) {
      assert.equal(typeof key, "string");assert.notEqual(key, "__proto__")
      const descriptor = Object.getOwnPropertyDescriptor(value, key)!
      assert.ok("value" in descriptor)
      digest.update(JSON.stringify(key) + ":" + [descriptor.enumerable, descriptor.configurable, descriptor.writable].map(Number).join("") + ":")
      visit(descriptor.value, depth + 1)
    }
    digest.update("};");active.delete(value)
  }
  visit(value);return digest.digest("hex")
}
function scalars(grid: any) {
  const expanded = own(grid, "expanded"), solved = own(grid, "solved"), failed = own(grid, "failed")
  assert.ok(Number.isSafeInteger(expanded) && expanded >= 0)
  assert.equal(typeof solved, "boolean");assert.equal(typeof failed, "boolean")
  return { expanded, solved, failed }
}
function writeReport(report: any) {
  const raw = JSON.stringify(report, null, 2) + "\n"
  assert.ok(Buffer.byteLength(raw) <= REPORT_LIMIT, "Scalar report bound")
  fs.writeFileSync(path.join(OUT, "replay-result.json"), raw, { flag: "wx", mode: 0o600 })
}
function main() {
  assert.equal(Bun.version, "1.3.14")
  assert.equal(process.env.G350_ORIGINAL_CPU34_GRID_REPLAY_APPROVED, "1")
  assert.deepEqual(process.argv.slice(2), ["--run-one-approved"])
  assert.equal(process.cwd(), ROOT);assert.ok(fs.statSync(OUT).isDirectory())
  const packetRaw = fs.readFileSync(path.join(ROOT, "SOURCE-manifest.json"))
  assert.equal(hash(packetRaw), process.env.G350_ORIGINAL_CPU34_GRID_REPLAY_PACKET_SHA)
  const packet = JSON.parse(packetRaw.toString())
  assert.equal(packet.actualCapturePath, CAPTURE);assert.equal(packet.actualCaptureSha256, CAPTURE_SHA)
  const capturedRaw = fs.readFileSync(CAPTURE);assert.equal(capturedRaw.length, 442908);assert.equal(hash(capturedRaw), CAPTURE_SHA)
  const captured = JSON.parse(capturedRaw.toString());assert.equal(captured.records.length, 1)
  const record = captured.records[0], data = record.data, expected = data.stateAfterOriginalStep
  assert.equal(record.kind, "original-fine");assert.equal(record.startTerminalIndex, 0)
  assert.equal(record.captureAt, "after-original-step-return-at-active-cpu-threshold")
  assert.equal(record.outcome.kind, "ACTIVE_DIAGNOSTIC");assert.equal(record.outcome.expanded, 100000)
  assert.equal(record.outcome.solved, false);assert.equal(record.outcome.failed, false)
  assert.equal(record.frontierCaptured, false);assert.equal(record.fullFrontierReplayClaimed, false)
  assert.deepEqual(record.undefinedPaths, [["hardCopper", "0", "rect"], ["hardCopper", "1", "rect"]])
  for (const entry of record.undefinedPaths) {
    let target = data
    for (const key of entry.slice(0, -1)) target = own(target, key)
    const key = entry.at(-1)!;assert.equal(own(target, key), null)
    Object.defineProperty(target, key, { value: undefined, enumerable: true, configurable: true, writable: true })
  }
  const undefinedDescriptors = () => record.undefinedPaths.map((entry: string[]) => {
    let target = data
    for (const key of entry.slice(0, -1)) target = own(target, key)
    const descriptor = Object.getOwnPropertyDescriptor(target, entry.at(-1)!)!
    assert.ok("value" in descriptor && descriptor.value === undefined)
    return { path: entry, enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, valueIsUndefined: true }
  })
  const materialBefore = materialSha(data), undefinedBefore = undefinedDescriptors()
  const inputBefore = materialSha(data.input), connectionBefore = materialSha(data.connection), copperBefore = materialSha(data.hardCopper)
  assert.equal(data.input.layerCount, 4);assert.equal(data.input.connections.length, 26)
  assert.equal(data.connection.name, "source_trace_34");assert.equal(data.hardCopper.length, 167)
  assert.deepEqual([data.start.x, data.start.y], [data.connection.pointsToConnect[0].x, data.connection.pointsToConnect[0].y])
  assert.ok(data.hardCopper.every((c: any) => c.layer === "inner1" && !c.owners.includes("source_trace_34")))
  assert.equal(data.hardCopper.filter((c: any) => c.owners.includes("reserved_pair_tail")).length, 8)
  assert.equal(data.width, 0.1016)
  assert.equal(data.margin, data.width / 2 + (data.input.minTraceToPadEdgeClearance ?? data.input.defaultObstacleMargin ?? .075))
  assert.deepEqual(Object.keys(data.grid), ["step", "bounds", "checkReachability"])
  assert.equal(data.grid.step, data.width / 10);assert.equal(data.grid.checkReachability, true)
  assert.equal(expected.nx, 641);assert.equal(expected.ny, 891);assert.equal(expected.goal, 192640)
  assert.equal(expected.startAttachments.length, 8);assert.equal(expected.endAttachments.length, 8)
  assert.equal(expected.alternateAttachments, false)
  // A separate manual candidate is evidence only. Clone all material so its
  // visibility/index/outline work cannot prime the original replay scene/input.
  const manualPath = path.join(ROOT, "manual-candidate.json")
  const MANUAL_SHA = "c2bc06609fa6698918b2ae872178becf9f0ec0c381e129214a46aaceb0ceb99c"
  assert.equal(packet.manualCandidatePath, manualPath);assert.equal(packet.manualCandidateSha256, MANUAL_SHA)
  const manualRaw = fs.readFileSync(manualPath);assert.equal(manualRaw.length, 1367);assert.equal(hash(manualRaw), MANUAL_SHA)
  const manual = JSON.parse(manualRaw.toString())
  assert.equal(manual.sourceCapturePath, CAPTURE);assert.equal(manual.sourceCaptureSha256, CAPTURE_SHA)
  assert.equal(manual.connectionName, data.connection.name);assert.equal(manual.layer, "inner1")
  assert.equal(manual.traceWidth, data.width);assert.equal(manual.originalRouteOrGridResult, false)
  assert.equal(manual.accepted49, false);assert.equal(manual.fabricationReady, false)
  assert.ok(Array.isArray(manual.points) && manual.points.length === 6)
  assert.equal(materialSha(manual.points[0]), materialSha(data.start))
  assert.equal(materialSha(manual.points.at(-1)), materialSha(data.end))
  const manualLengthMm = length(manual.points)
  assert.ok(Number.isFinite(manualLengthMm) && Math.abs(manualLengthMm - manual.expectedLength) <= 1e-12, "Manual source length mismatch")
  const manualData = structuredClone(data)
  assert.notEqual(manualData.input, data.input);assert.notEqual(manualData.hardCopper, data.hardCopper)
  const manualMaterialBefore = materialSha(manualData);assert.equal(manualMaterialBefore, materialBefore)
  const manualScene = new VectorScene(manualData.input, manualData.connection, manualData.width, manualData.hardCopper)
  assert.equal(manualScene.margin, data.margin);assert.equal(materialSha(manualScene.copper), copperBefore)
  const manualSegments: Array<{ index: number; visible: boolean }> = []
  for (let i = 0; i < manual.points.length - 1; i++)
    manualSegments.push({ index: i, visible: manualScene.pathVisible([manual.points[i], manual.points[i + 1]]) })
  const manualWholePathVisible = manualScene.pathVisible(manual.points)
  const manualAllSegmentsVisible = manualSegments.every(row => row.visible)
  assert.equal(materialSha(manualData), manualMaterialBefore);assert.equal(materialSha(data), materialBefore)
  assert.equal(hash(fs.readFileSync(manualPath)), MANUAL_SHA)
  const separateManualCandidateValidation = {
    sourceCandidatePath: manualPath, sourceCandidateSha256: MANUAL_SHA, sourceCaptureSha256: CAPTURE_SHA,
    nonOriginalManualCandidate: true, originalRouteOrGridResult: false,
    candidateSchemaAndExpectedLengthMatched: true, originalGeometryLengthMm: manualLengthMm,
    sourceExpectedLengthMm: manual.expectedLength, segmentCount: 5, originalPathVisibleCalls: 6,
    segments: manualSegments, allSegmentsVisible: manualAllSegmentsVisible, wholePathVisible: manualWholePathVisible,
    manualCandidateValidated: manualAllSegmentsVisible && manualWholePathVisible,
    originalBoardBoundsAndOutlineGateIncluded: true, originalAll167CopperUsed: true,
    separateSceneAndInputFromOriginalGridReplay: true, clonedManualMaterialHeld: true,
    originalReplayMaterialHeldBeforeGrid: true, manualVisibilityDoesNotControlOriginalGridReplay: true,
    endpointIsCapturedVirtualHandoffGoal: true, nativeCalls: 0, nativeCandidateValidated: false,
    pairTimingMatchingQualified: false, busTotalLengthQualified: false, full49RoutingQualified: false,
    accepted49: false, fabricationReady: false,
  }
  const scene = new VectorScene(data.input, data.connection, data.width, data.hardCopper)
  assert.equal(scene.margin, data.margin);assert.equal(scene.copper.length, 167)
  assert.equal(materialSha(scene.copper), copperBefore);assert.deepEqual([...scene.owners], ["source_trace_34"])
  let constructionCount = 0, cancelCalls = 0, stepCalls = 0, terminal: any = null
  let constructorStateMatchedCapture = false, visible: boolean | null = null, pathLengthMm: number | null = null
  let pathSha256: string | null = null, pathBytes: number | null = null, pathNodes: number | null = null
  let pathFile: string | null = null, pathFullyRetained = false
  const started = performance.now()
  constructionCount++
  const grid = new GridVisibilitySearch(scene, data.start, data.end, [], 0, undefined, data.grid)
  const constructedMs = performance.now() - started
  try {
    assert.deepEqual(scalars(grid), { expanded: 0, solved: false, failed: false })
    for (const key of ["nx", "ny", "origin", "alternateAttachments", "startAttachments", "endAttachments", "startPath", "endPath", "goal"])
      assert.equal(materialSha(own(grid, key)), materialSha(expected[key]), "Fresh constructor differs: " + key)
    assert.equal(own(grid, "maxLength"), Infinity);assert.equal(own(grid, "lengthFrontier", true), undefined)
    assert.equal(own(grid, "history", true), undefined);assert.equal(own(grid, "penalty"), 0)
    assert.equal(own(grid, "hasSoftCopper"), false);assert.equal(own(grid, "softBuckets", true), undefined)
    assert.equal(own(grid, "gridOffsetX"), 0);assert.equal(own(grid, "gridOffsetY"), 0)
    assert.equal(own(grid, "stepSize"), data.grid.step)
    assert.equal(materialSha(own(grid, "gridBounds")), materialSha(data.grid.bounds))
    constructorStateMatchedCapture = true
    while (!grid.solved && !grid.failed && grid.expanded < EXPANSION_CAP) {
      grid.step();stepCalls++
    }
    const beforeCancel = scalars(grid)
    const termination = beforeCancel.solved ? "NATURAL_SOLVED" : beforeCancel.failed ? "NATURAL_FAILED" : "ORIGINAL_EXPANSION_CAP"
    if (termination === "ORIGINAL_EXPANSION_CAP") assert.ok(beforeCancel.expanded >= EXPANSION_CAP)
    terminal = { termination, beforeOriginalCancel: beforeCancel }
    if (beforeCancel.solved) {
      const result = own(grid, "result");assert.ok(Array.isArray(result) && result.length >= 2)
      visible = scene.pathVisible(result);assert.equal(visible, true, "Original continuous path gate")
      pathLengthMm = length(result);assert.ok(Number.isFinite(pathLengthMm))
      pathNodes = result.length
      const digest = crypto.createHash("sha256");digest.update("[")
      let parts: string[] | null = ["["], size = 1
      for (let i = 0; i < result.length; i++) {
        materialSha(result[i])
        const fragment = (i ? "," : "") + JSON.stringify(result[i]);digest.update(fragment);size += Buffer.byteLength(fragment)
        if (parts && size <= PATH_LIMIT) parts.push(fragment);else parts = null
      }
      digest.update("]\n");size += 2;pathSha256 = digest.digest("hex");pathBytes = size
      if (parts && size <= PATH_LIMIT) {
        parts.push("]\n");const raw = parts.join("");assert.equal(hash(raw), pathSha256)
        pathFile = "replay-solved-path.json";fs.writeFileSync(path.join(OUT, pathFile), raw, { flag: "wx", mode: 0o600 });pathFullyRetained = true
      }
    }
  } finally {
    // Preserve original cleanup exactly once; classify from the state above,
    // never from failed=true that cancel assigns to an unfinished search.
    cancelCalls++;grid.cancel()
  }
  assert.ok(terminal && constructorStateMatchedCapture)
  assert.equal(materialSha(data), materialBefore);assert.equal(materialSha(data.input), inputBefore)
  assert.equal(materialSha(data.connection), connectionBefore);assert.equal(materialSha(data.hardCopper), copperBefore)
  assert.deepEqual(undefinedDescriptors(), undefinedBefore);assert.equal(hash(fs.readFileSync(CAPTURE)), CAPTURE_SHA)
  const report = {
    diagnosticQualified: true, constructorStateMatchedCapture, materialHeld: true,
    separateManualCandidateValidation, manualCandidateValidated: separateManualCandidateValidation.manualCandidateValidated,
    originalVectorSceneConstructionCount: 2, originalGridSceneConstructionCount: 1, manualOnlySceneConstructionCount: 1,
    originalGridConstructionCount: constructionCount, originalCancelCalls: cancelCalls, originalStepCalls: stepCalls,
    observerHooksInstalled: 0, nativeCalls: 0, originalExpansionCap: EXPANSION_CAP,
    originalCapCheckedBeforeEachStep: true, extraAttachmentRetriesInvoked: false,
    termination: terminal.termination, terminalBeforeOriginalCancel: terminal.beforeOriginalCancel,
    stateAfterOriginalCancel: scalars(grid), capturedOriginalExpanded: 100000, freshInitialExpanded: 0,
    sourceCaptureSha256: CAPTURE_SHA, ownDataMaterialSha256Before: materialBefore, ownDataMaterialSha256After: materialSha(data),
    inputSha256Held: inputBefore, connectionSha256Held: connectionBefore, copperSha256Held: copperBefore,
    undefinedDescriptorsHeld: true, originalCopperOrderCount: 167, originalGridNx: 641, originalGridNy: 891,
    originalGoalId: 192640, originalStartAttachmentCount: 8, originalEndAttachmentCount: 8,
    observedModeConstructorNotRawArgumentReplay: true, rawOriginalArgumentListRetained: false,
    frontierCheckpointReplayed: false, coldFreshModuleDefaultCaches: true, cacheDisableOrReplacementPerformed: false,
    engine: "Bun1.3.14", directOriginalTypeScriptImports: true, noTimingComparisonAgainstNodePublic: true,
    constructorMs: constructedMs, totalWorkerMs: performance.now() - started,
    solvedOriginalContinuousPathVisible: visible, solvedPathLengthMm: pathLengthMm, solvedPathNodes: pathNodes,
    solvedPathSha256: pathSha256, solvedPathBytes: pathBytes, solvedPathFile: pathFile,
    solvedPathFullyRetained: pathFullyRetained, pathGeometryReusableDiagnosticOnly: pathFullyRetained && visible === true,
    oversizedPathScalarOnlyNotGeometryProof: pathBytes !== null && !pathFullyRetained,
    nativeCandidateValidated: false, naturalOutput49Produced: false,
    fullRegressionQualificationIncomplete: true, accepted49: false, fabricationReady: false,
  }
  writeReport(report)
  console.log(JSON.stringify({ diagnosticQualified: true, termination: report.termination,
    expanded: report.terminalBeforeOriginalCancel.expanded, resultSha256: hash(fs.readFileSync(path.join(OUT, "replay-result.json"))),
    nativeCandidateValidated: false, accepted49: false, fabricationReady: false }))
}
try { main() }
catch (error) {
  console.error(JSON.stringify({ diagnosticQualified: false, errorName: error instanceof Error ? error.name : "UnknownError",
    errorMessage: error instanceof Error ? error.message.slice(0, 2000) : "Non-Error failure",
    nativeCandidateValidated: false, accepted49: false, fabricationReady: false }))
  process.exitCode = 2
}
