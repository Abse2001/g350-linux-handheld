#!/usr/bin/env python3
"""Sequential bounded job list; does not run any board/router/native checker."""
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in {"nominal", "sensitivity"}
jobs = []
for stack in ["3313", "1080"]:
    for pair in [False, True]:
        if mode == "nominal":
            jobs.extend((stack, pair, step, 1, "offset") for step in [4, 2, 1])
        else:
            jobs.append((stack, pair, 1, 2, "offset"))
            jobs.extend((stack, pair, step, 1, "stepped") for step in [2, 1])
for stack, pair, step, box, mask in jobs:
    key = f"{stack}-{'pair' if pair else 'single'}-{mask}-{step}um-box{box}"
    args = [sys.executable, str(HERE / "run-job.py"), str(HERE / "raw" / f"{key}-execution.json"),
            "--stack", stack, "--step-um", str(step), "--box-scale", str(box),
            "--mask", mask, "--output", str(HERE / "raw" / f"{key}.json")]
    if pair:
        args.append("--pair")
    print("START " + key, flush=True)
    result = subprocess.run(args)
    print(f"END {key} exit={result.returncode}", flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
