"""Stdlib-only authentic material, declared layer inverse, and terminal ownership controls.

No SDK, Bun, Node, Source, Core or CAD imports. Optional argv[1] is an exclusive
control report path for independent peer reproduction.
"""
import copy
import hashlib
import json
import math
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
BASE = HERE.parent / "ddr-reset10-context12-two-owned-breakout-227-sourceonly-next"
NUMERIC = BASE / "FULL49_NUMERIC_INPUT_CONTEXT12_PLUS_RESET2_227.json"
CLEAN = BASE / "FULL49_SOLVER_VIEW_RESET_BARREL_IDENTITY_CLEAN_PROJECTION03.json"
CONTEXT = BASE / "EMPTY49_CONTEXT12_PLUS_RESET2_227_MATERIAL_CONTEXT02.json"
NATIVE = BASE / "NATIVE_CONTEXT_CONTEXT12_PLUS_RESET2_227_HYPOTHESIS.json"
PREPARED = HERE / "GENERATION_INPUT_BYTE0_INNER1_LAYER_ONLY.json"
PHYSICAL = ["top", "inner1", "inner2", "bottom"]

def load(p):
    return json.loads(p.read_text())

numeric, original, context, prepared = map(load, [NUMERIC, CLEAN, CONTEXT, PREPARED])
native = load(NATIVE)
byte0 = set(next(b["connectionNames"] for b in numeric["buses"] if b["busId"] == "DDR_BYTE0"))

def verify(candidate):
    # All real physical arrays, global/bus/pair constraints and object fields are
    # held against authentic frozen inputs; only the declared 22 layer fields vary.
    assert set(candidate) == set(original) == set(numeric)
    for key in original:
        if key != "connections":
            assert candidate[key] == original[key] == numeric[key], key
    assert len(candidate["connections"]) == len(numeric["connections"]) == 49
    assert len(candidate["traces"]) == 263
    assert len(byte0) == 11
    inverse = copy.deepcopy(candidate)
    changes, mapping = [], []
    names = set()
    for i, (c, old, logical) in enumerate(zip(candidate["connections"], original["connections"], numeric["connections"])):
        assert c["name"] == old["name"] == logical["name"] == c["source_trace_id"]
        assert c["name"] not in names
        names.add(c["name"])
        assert set(c) == set(old)
        for key in c:
            if key != "pointsToConnect":
                assert c[key] == old[key]
        assert len(c["pointsToConnect"]) == len(old["pointsToConnect"]) == 2
        branches = [t for t in numeric["traces"] if t.get("source_trace_id") == c["name"]]
        assert len(branches) == 2
        aliases = []
        for side, (point, prior, branch) in enumerate(zip(c["pointsToConnect"], old["pointsToConnect"], branches)):
            assert set(point) == set(prior)
            assert "layers" not in point
            for key in prior:
                if key != "layer":
                    assert point[key] == prior[key]
            if c["name"] in byte0:
                assert prior["layer"] == "bottom" and point["layer"] == "inner1"
                changes.append((i, side))
            else:
                assert point["layer"] == prior["layer"]
            inverse["connections"][i]["pointsToConnect"][side]["layer"] = prior["layer"]
            vias = [p for p in branch["route"] if p["route_type"] == "via"]
            assert len(vias) == 1
            v = vias[0]
            assert set(v["layers"]) == set(PHYSICAL)
            assert v["via_diameter"] == .4572 and v["via_hole_diameter"] == .254
            assert math.hypot(v["x"] - point["x"], v["y"] - point["y"]) < 1e-8
            pad = logical["pointsToConnect"][side]
            first = branch["route"][0]
            assert first["layer"] == "top"
            assert math.hypot(first["x"] - pad["x"], first["y"] - pad["y"]) < 1e-8
            if c["name"] == "source_trace_10":
                owner = context["proposedVias"][side]
                assert set(point) == {"x", "y", "layer", "proposed_owned_via_id"}
                assert point["proposed_owned_via_id"] == owner["proposedViaId"]
                assert owner["sourceTraceId"] == c["name"]
                assert (v["x"], v["y"]) == (owner["x"], owner["y"])
                assert branch["source_only_proposed"] is True
                assert branch["proposed_owned_via_id"] == owner["proposedViaId"]
            aliases.append({"sourceOnlyFixedBranchId": branch["pcb_trace_id"], "sourceOnlyHypothesis": True, "x": v["x"], "y": v["y"]})
        assert c["pointsToConnect"][0]["layer"] == c["pointsToConnect"][1]["layer"]
        allowed = [layer for layer in PHYSICAL if layer in candidate["allowedLayers"] and all(layer in b.get("allowedLayers", PHYSICAL) for b in candidate["buses"] if c["name"] in b["connectionNames"])]
        assert allowed == PHYSICAL
        mapping.append({"name": c["name"], "barrels": aliases, "terminalLayers": allowed})
    assert len(changes) == 22 and inverse == original
    all_vias = [v for t in numeric["traces"] for v in t["route"] if v["route_type"] == "via"]
    assert len(all_vias) == 98
    assert len({(v["x"], v["y"]) for v in all_vias}) == 98
    assert len(native["referenceVias"]) == 129
    assert len(native["signalDogbones"]) == 98
    assert len(native["allOriginalCopperLands"]) == 1165
    assert native["physicalViaCountIncludingProposals"] == 227
    assert sum(len(m["barrels"]) for m in mapping) == 98
    assert len(all_vias) + len(native["referenceVias"]) == 227
    return {"connectionCount": 49, "fixedTraceCount": 263, "physicalViaCount": 227, "ownedSignalBarrels": 98, "referenceBarrels": 129, "layerFieldsChanged": len(changes), "exactInverseHeld": True, "terminalLayers": mapping}

positive = verify(prepared)
reset_index = next(i for i, c in enumerate(prepared["connections"]) if c["name"] == "source_trace_10")
b0_index = next(i for i, c in enumerate(prepared["connections"]) if c["name"] in byte0)

def changed(mutator):
    obj = copy.deepcopy(prepared)
    mutator(obj)
    return obj

tests = [
    ("ghost_numeric_pad_id_on_new_reset_barrel", lambda x: x["connections"][reset_index]["pointsToConnect"][0].update(pcb_port_id="pcb_port_24")),
    ("foreign_reset_barrel_owner", lambda x: x["connections"][reset_index]["pointsToConnect"][0].update(proposed_owned_via_id=context["proposedVias"][1]["proposedViaId"])),
    ("move_carrier_endpoint", lambda x: x["connections"][0]["pointsToConnect"][0].update(x=123)),
    ("unplanned_nonbyte0_layer_change", lambda x: x["connections"][reset_index]["pointsToConnect"][0].update(layer="top")),
    ("missing_one_of_22_initial_layer_changes", lambda x: x["connections"][b0_index]["pointsToConnect"][0].update(layer="bottom")),
    ("unsupported_terminal_layers_array", lambda x: x["connections"][0]["pointsToConnect"][0].update(layers=PHYSICAL)),
    ("changed_original_fixed_width", lambda x: x["traces"][0]["route"][0].update(width=.5)),
    ("drop_real_fixed_branch", lambda x: x["traces"].pop()),
    ("retag_real_branch_source_owner", lambda x: x["traces"][-1].update(source_trace_id="source_trace_15")),
    ("relax_original_bus_skew", lambda x: next(b for b in x["buses"] if b["busId"] == "DDR_BYTE0").update(maxLengthSkew=99)),
    ("relax_actual_byte0_max_length", lambda x: next(b for b in x["buses"] if b["busId"] == "DDR_BYTE0").update(maxLength=99)),
    ("relax_actual_differential_pair_skew", lambda x: x["differentialPairs"][0].update(lengthTolerance=99)),
    ("relax_actual_differential_pair_gap", lambda x: x["differentialPairs"][0].update(traceGap=.01)),
    ("drop_original_differential_pairs", lambda x: x.update(differentialPairs=[])),
    ("alter_real_land_geometry", lambda x: x["obstacles"][0]["center"].update(x=123)),
    ("allow_fictitious_layer", lambda x: x.update(allowedLayers=PHYSICAL+["inner3"])),
    ("drop_authentic_numeric_owner_connection", lambda x: x["connections"].pop()),
]
refusals = []
for name, mutate in tests:
    try:
        verify(changed(mutate))
    except (AssertionError, KeyError, IndexError, TypeError, ValueError):
        refusals.append({"name": name, "rejected": True})
    else:
        raise AssertionError("Accepted adverse control " + name)
report = {"scope": "STDLIB_ONLY_AUTHENTIC227_PUBLIC_GENERATION_INPUT_CONTRACT", "positive": positive, "negativeControls": refusals, "negativeControlCount": len(refusals), "passed": True, "SDKExecuted": False, "SourceCoreNativeCliCadExecuted": False, "all49Accepted": False, "referenceQualified": False, "electricalTimingPassed": False, "fabricationReady": False}
target = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "STDLIB_CONTROLS.json"
with target.open("x") as f:
    json.dump(report, f, indent=2)
    f.write("\n")
print(json.dumps({"report": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "positiveConnections": 49, "negativeControls": len(refusals)}))
