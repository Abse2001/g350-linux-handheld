/** Source-only proposal. Root owns the eventual pure React evaluation. */
import assert from "node:assert/strict"
import {Children,cloneElement,isValidElement,type ReactElement,type ReactNode} from "react"
import {readFileSync,writeFileSync,existsSync} from "node:fs"
import {createHash} from "node:crypto"
import {buildJointHsReferenceSource} from "/workspace/g350-linux-handheld/.cloud-tools/ddr-hs-all32-capture-first-type4096-root-successor-next/source/hs-reference-overlay"
import {buildPackageApproachSource} from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/package-approaches-overlay"
import proposal from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/grouped-proposal.json"

const [output,...extra]=process.argv.slice(2)
assert(output&&extra.length===0&&!existsSync(output))
assert.equal(process.versions.bun,"1.3.14")
const groups=proposal.viaGroups as Array<Record<string,any>>,owners=proposal.owners as Array<Record<string,any>>
assert.equal(owners.length,101);assert.equal(groups.length,72)
const newGroups=groups.filter(g=>g.reuseAcceptedHsViaId===null),byGroup=new Map(groups.map(g=>[g.key,g]))
assert.equal(newGroups.length,65);assert.equal(groups.length-newGroups.length,7)
const rawBefore=buildJointHsReferenceSource(),after=buildPackageApproachSource()
function identity(node:ReactNode):ReactNode{
 if(!isValidElement<Record<string,unknown>>(node))return node
 return cloneElement(node as ReactElement<Record<string,unknown>>,{...node.props},...Children.toArray(node.props.children as ReactNode).map(identity))
}
const before={...rawBefore,element:identity(rawBefore.element)}
let originalElements=0,boards=0,addedElements=0
function props(node:ReactNode){assert(isValidElement<Record<string,unknown>>(node));const result={...node.props};delete result.children;return result}
function compare(a:ReactNode,b:ReactNode,path:string){
 if(!isValidElement<Record<string,unknown>>(a)||!isValidElement<Record<string,unknown>>(b)){assert.equal(JSON.stringify(a),JSON.stringify(b),path);return}
 originalElements++;assert.equal(a.type,b.type,path);assert.equal(a.key,b.key,path)
 assert.equal(JSON.stringify(props(a)),JSON.stringify(props(b)),"Original props: "+path)
 const ca=Children.toArray(a.props.children as ReactNode),cb=Children.toArray(b.props.children as ReactNode)
 if(a.type!=="board")assert.equal(ca.length,cb.length,"Original child inventory: "+path)
 else{
  boards++;assert.equal(cb.length,ca.length+166,"Exactly65 new canonical vias plus101 Top branches")
  newGroups.forEach((g,i)=>{
   const node=cb[ca.length+i];assert(isValidElement(node)&&node.type==="via")
   assert.deepEqual(props(node),{name:g.viaName,pcbX:g.x,pcbY:g.y,fromLayer:"top",toLayer:"bottom",outerDiameter:.4572,holeDiameter:.254,connectsTo:`net.${g.referenceNet}`,tented:"top_and_bottom_tented"})
   addedElements++
  })
  owners.forEach((o,i)=>{
   const g=byGroup.get(o.viaGroupKey);assert(g)
   const node=cb[ca.length+65+i];assert(isValidElement(node)&&node.type==="trace")
   const viaTop=`.${g.viaName} > port.top`
   assert.deepEqual(props(node),{name:o.traceName,from:`${o.package}.pin${o.numericPin}`,to:viaTop,thickness:o.topStub[0].width,pcbPathRelativeTo:viaTop,pcbPath:o.topStub.slice(1,-1).reverse().map((p:Record<string,number>)=>({x:p.x-g.x,y:p.y-g.y}))})
   addedElements++
  })
 }
 ca.forEach((child,i)=>compare(child,cb[i],path+"/"+i))
}
compare(before.element,after.element,"board")
assert.equal(boards,1);assert.equal(originalElements,1870);assert.equal(addedElements,166)
for(const key of Object.keys(before).filter(k=>k!=="element"))assert.equal(JSON.stringify((after as Record<string,unknown>)[key]),JSON.stringify((before as Record<string,unknown>)[key]),"Original source metadata: "+key)
const proposalRaw=readFileSync(new URL('../ddr-package-approaches-source-overlay-next/all101-source-candidate/grouped-proposal.json',import.meta.url))
writeFileSync(output,JSON.stringify({scope:"PURE_ACTUAL_REACT_PACKAGE101_APPEND_ONLY_CAPTURE",actualSourceTreeEvaluated:true,acceptedHsBaseElementsCompared:1870,original1746AndAccepted124HsPropsHeld:true,addedLiteralViaElements:65,addedLiteralTopTraceElements:101,addedLiteralElements:166,proposalSha256:createHash('sha256').update(proposalRaw).digest('hex'),allOriginalPropsTypesKeysChildrenHeld:true,registeredGroundContactStillRequiresActualCoreAndPhysicalProof:true,newCoreBuildPerformed:false,newNativeCheckPerformed:false,referenceQualified:false,accepted49:false,fabricationReady:false},null,2)+"\n",{flag:"wx",mode:0o600})
