"""One guarded fresh CAD export of verified V5 source; no routing."""
import hashlib,importlib.util,json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BOARD=Path('/workspace/g350-linux-handheld')
PACKET=BOARD/'.cloud-tools/ti-ddr-v5-reference-export-next'
INPUT=PACKET/'run/fresh-layout.circuit.json'
OUTPUT=ROOT/'g350-ti-v5.kicad_pcb'
EXPECTED='98a50b122e6a550c3020c935886d6832dbae34e333ea135e28e9bc555c973d5e'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(INPUT)==EXPECTED and not OUTPUT.exists() and not (ROOT/'export-run').exists()
assert not os.environ.get('G350_EXPORT_WITHOUT_POURS')
spec=importlib.util.spec_from_file_location('v5_scope',PACKET/'process_scope.py')
scope=importlib.util.module_from_spec(spec);spec.loader.exec_module(scope)
sys.path.insert(0,str(PACKET))
import guard
before,pkt,deps=guard.checked()
assert pkt=='60e056fe3d6bcee5d8bd1baa7558b65420c093e128a0a799bee42f2ee36a88bb'
script=ROOT/'export-kicad.mjs';script_before=sha(script)
policy={'wallSeconds':180,'rssBytes':4*1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
command=[str(BOARD/'.cloud-tools/node/bin/node'),str(script),str(INPUT),str(OUTPUT)]
assert scope.memory()['current']+policy['rssBytes']+2*1024**3<policy['sharedBytes']
execution=scope.run_guarded(command,BOARD,ROOT/'export-run',policy)
_,after,deps_after=guard.checked()
assert pkt==after and deps==deps_after and sha(INPUT)==EXPECTED and sha(script)==script_before
trusted=execution['exitCode']==0 and not execution['diagnosticStopped'] and not any(execution['oomDelta'].values()) and execution['cleanupOwnedGroupEmpty'] and OUTPUT.is_file()
report={'sourceSha256':EXPECTED,'sourcePacketSha256':pkt,'exportAdapterSha256':script_before,'command':command,'execution':execution,'exportQualified':bool(trusted),'rawCadSha256':sha(OUTPUT) if OUTPUT.exists() else None,'planeConnectivityQualified':False,'fullBoardDrcQualified':False,'fabricationReady':False}
(ROOT/'export-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='execution'}))
raise SystemExit(0 if trusted else 2)
