/** Pure hardware comparison; imports only erased public types, never a solver. */
import type { SimpleRouteJson } from "./source/lib"

export function sameHardware(
  input: SimpleRouteJson,
  unrestricted: SimpleRouteJson,
) {
  const normalized = structuredClone(input)
  if ((normalized.buses?.length ?? 0) !== (unrestricted.buses?.length ?? 0))
    return false
  for (let index = 0; index < (normalized.buses?.length ?? 0); index++) {
    const bus = normalized.buses![index]!
    const original = unrestricted.buses![index]!
    if (Object.hasOwn(original, "allowedLayers"))
      bus.allowedLayers = structuredClone(original.allowedLayers)
    else delete bus.allowedLayers
    if (Object.hasOwn(original, "preferredLayers"))
      bus.preferredLayers = structuredClone(original.preferredLayers)
    else delete bus.preferredLayers
  }
  return JSON.stringify(normalized) === JSON.stringify(unrestricted)
}
