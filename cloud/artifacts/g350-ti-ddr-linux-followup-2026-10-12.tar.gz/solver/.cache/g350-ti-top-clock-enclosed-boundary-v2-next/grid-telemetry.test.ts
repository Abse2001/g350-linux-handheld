import { expect, test, mock } from "bun:test"
import { installGridProfile } from "./grid-telemetry"
import { captureOneOriginalJob } from "./control"
class FakeGrid {
  #brand = 7
  expanded = 0
  solved = false
  failed = false
  nx = 2
  ny = 3
  cellCount = 6
  target: unknown
  constructor(..._args: any[]) {
    this.target = new.target
  }
  step(...args: any[]) {
    if (this.#brand !== 7) throw Error("private brand")
    this.expanded++
    if (args[0] instanceof Error) throw args[0]
    return args[0]
  }
  cancel(...args: any[]) {
    if (this.#brand !== 7) throw Error("private brand")
    if (!this.solved) this.failed = true
    return args[0]
  }
}
const members = [
  {
    name: "ckp",
    pointsToConnect: [
      { x: 0, y: 0 },
      { x: 1, y: 1 },
    ],
  },
  {
    name: "ckn",
    pointsToConnect: [
      { x: 0, y: 1 },
      { x: 1, y: 2 },
    ],
  },
]
const args = (name: string, start = { x: 0, y: 0 }) => [
  { connection: { name, pointsToConnect: [{ ...start, layer: "top" }] } },
  start,
  { x: 2, y: 2 },
]

test("real instance/private/newTarget and step/cancel values/errors/descriptors survive observation", () => {
  const module = { GridVisibilitySearch: FakeGrid },
    step = FakeGrid.prototype.step,
    cancel = FakeGrid.prototype.cancel
  const profile = installGridProfile(module, () => {}, 32, undefined, members)
  try {
    const grid = new module.GridVisibilitySearch(...args("ckp"))
    expect(grid instanceof FakeGrid).toBe(true)
    expect(grid.target).toBe(FakeGrid)
    class Derived extends module.GridVisibilitySearch {}
    const derived = new Derived(...args("pair_corridor"))
    expect(derived.target).toBe(Derived)
    const value = Symbol("returned")
    expect(grid.step(value)).toBe(value)
    expect(grid.cancel(value)).toBe(value)
    const error = new Error("unchanged")
    let caught: unknown
    try {
      derived.step(error)
    } catch (e) {
      caught = e
    }
    expect(caught).toBe(error)
    const snapshot = profile.snapshot()
    expect(snapshot.stages.package_cpu.steps).toBe(1)
    expect(snapshot.stages.center.steps).toBe(1)
    expect(snapshot.rows.length).toBe(2)
  } finally {
    profile.restore()
  }
  expect(module.GridVisibilitySearch).toBe(FakeGrid)
  expect(FakeGrid.prototype.step).toBe(step)
  expect(FakeGrid.prototype.cancel).toBe(cancel)
})
test("original-style cancel failure flag remains separate from prior natural terminal states", () => {
  const module = { GridVisibilitySearch: FakeGrid }
  const profile = installGridProfile(module, () => {}, 32, undefined, members)
  try {
    const unfinished = new module.GridVisibilitySearch(...args("pair_corridor"))
    unfinished.step(null)
    unfinished.cancel(null)
    unfinished.cancel(null)
    unfinished.step(null)
    const failed = new module.GridVisibilitySearch(...args("pair_corridor"))
    failed.failed = true
    failed.step(null)
    failed.cancel(null)
    const solved = new module.GridVisibilitySearch(...args("pair_corridor"))
    solved.solved = true
    solved.step(null)
    solved.cancel(null)
    const snapshot = profile.snapshot()
    expect(unfinished.failed).toBe(true)
    expect(snapshot.stages.center.failed).toBe(1)
    expect(snapshot.stages.center.solved).toBe(1)
    expect(snapshot.stages.center.unfinishedCancelled).toBe(1)
    expect(snapshot.stages.center.cancels).toBe(4)
    expect(snapshot.observationErrors).toBe(0)
  } finally {
    profile.restore()
  }
})
test("all stage aggregates continue after32 tiny rows without retained mock histories", () => {
  const module = { GridVisibilitySearch: FakeGrid }
  const profile = installGridProfile(module, () => {}, 32, undefined, members)
  try {
    for (let i = 0; i < 40; i++) {
      const grid = new module.GridVisibilitySearch(...args("foreign"))
      grid.step(null)
      grid.cancel(null)
    }
    const s = profile.snapshot()
    expect(s.rows.length).toBe(32)
    expect(s.constructors).toBe(40)
    expect(s.steps).toBe(40)
    expect(s.stages.enclosed_terminal.steps).toBe(40)
    expect(s.droppedRows).toBe(8)
    expect(profile.constructorHistorySizes()).toEqual({
      calls: 0,
      results: 0,
      instances: 0,
      contexts: 0,
    })
  } finally {
    profile.restore()
  }
})
test("telemetry/throwing writer preserves original6000 cap including6001st-lookahead accounting", () => {
  const module = { GridVisibilitySearch: FakeGrid }
  const profile = installGridProfile(
    module,
    () => {
      throw Error("observer-only")
    },
    32,
    undefined,
    members,
  )
  try {
    const producer = {
      routeCoupledPair: function* () {
        const g = new module.GridVisibilitySearch(
          ...args("ckp", { x: 1, y: 1 }),
        )
        try {
          while (true) {
            g.step(null)
            yield
          }
        } finally {
          g.cancel(null)
        }
      },
    }
    const lifecycle = captureOneOriginalJob(producer, [])
    const s = profile.snapshot()
    expect(lifecycle.chargedYields).toBe(6000)
    expect(lifecycle.originalNextCalls).toBe(6001)
    expect(lifecycle.originalReturnCalls).toBe(1)
    expect(lifecycle.naturalCompletion).toBe(false)
    expect(lifecycle.rawResult).toBe(null)
    expect(s.steps).toBe(6001)
    expect(s.stages.package_ram.steps).toBe(6001)
    expect(s.cancels).toBe(1)
    expect(s.observationErrors > 0).toBe(true)
  } finally {
    profile.restore()
  }
})
test("original module ABI value is installed/restored without constructing a real Grid", async () => {
  const path = new URL("./source/lib/grid-visibility.ts", import.meta.url)
    .pathname
  const namespace = await import("./source/lib/grid-visibility")
  const captured = { ...namespace }
  const original = namespace.GridVisibilitySearch
  const profile = installGridProfile(
    namespace,
    () => {},
    32,
    (value) =>
      mock.module(path, () => ({ ...captured, GridVisibilitySearch: value })),
    members,
  )
  try {
    const active = await import("./source/lib/grid-visibility")
    expect(active.GridVisibilitySearch === original).toBe(false)
    expect(active.GridVisibilitySearch.prototype).toBe(original.prototype)
  } finally {
    profile.restore()
  }
  const restored = await import("./source/lib/grid-visibility")
  expect(restored.GridVisibilitySearch).toBe(original)
  expect(profile.snapshot().constructors).toBe(0)
})
