from pathlib import Path
import hashlib,json,stat
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
config=json.loads((ROOT/'commands.json').read_bytes())
manifest=Path(config['sourceManifest'])
assert sha(manifest)=='9670e70cc80a6633e13dd2f3f5a1c601abf78da7d73ded01d12fcc3c0e1bd9ff','source manifest differs'
m=json.loads(manifest.read_bytes())
assert len(m['sourceFiles'])==914,'source count differs'
assert hashlib.sha256(json.dumps(m['sourceFiles'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==m['sourceClosureSha256'],'source closure differs'
library=Path(config['libraryManifest'])
assert sha(library)=='e0a35a46b5d090b129eecee06dceb5139d240e61a328598449abd018b675ccf3','library manifest differs'
lib=json.loads(library.read_bytes());assert len(lib['files'])==124,'library count differs'
git=json.loads(Path(config['gitMetadataReceipt']).read_bytes())
preparation=json.loads((ROOT/'preparation.json').read_bytes())
for record in preparation['controllerFiles']:
 path=ROOT/record['path'];assert sha(path)==record['sha256'] and stat.S_IMODE(path.stat().st_mode)==record['mode'],'controller changed: '+record['path']
for source in [Path(config['originalSourceDirectory']),Path(config['sourceDirectory'])]:
 for record in m['sourceFiles']:
  path=source/record['path'];metadata=path.lstat();assert stat.S_ISREG(metadata.st_mode),'source type changed: '+record['path']
  assert metadata.st_size==record['bytes'] and sha(path)==record['sha256'],'source changed: '+record['path']
  assert stat.S_IMODE(metadata.st_mode)==m['filesystemModes'][record['path']],'source mode changed: '+record['path']
 for record in lib['files']:
  path=source/record['path'];assert sha(path)==record['sha256'] and path.stat().st_size==record['bytes'] and stat.S_IMODE(path.stat().st_mode)==record['mode'],'library changed: '+record['path']
 for record in preparation['gitMetadata']:
  path=source/'.git'/record['path'];assert sha(path)==record['sha256'] and stat.S_IMODE(path.stat().st_mode)==record['mode'],'git metadata changed: '+record['path']
 assert (source/'node_modules').is_symlink() and (source/'node_modules').resolve()==Path('/workspace/bus-lanes-solver/node_modules').resolve(),'trusted node_modules symlink differs'
print(json.dumps({'verified':True,'sourceManifestSha256':sha(manifest),'sourceClosureSha256':m['sourceClosureSha256'],'sourceFilesPerTree':914,'sourceTrees':2,'libraryFilesPerTree':124,'libraryManifestSha256':sha(library),'gitMetadataFilesPerTree':20,'controllerFiles':len(preparation['controllerFiles']),'runtimeImported':False,'solverExecuted':False},sort_keys=True))
