#!/usr/bin/env python3
"""SOURCE ONLY. Root-owned single-rootfs PRoot KiCad stages, no author execution.
PRoot translates paths; it is NOT kernel RO, UID, or network isolation. Only
reviewed trusted read-only-board commands are used. All actual descendants stay
in the caller's owned PGID. Image file/link material is verified before/end.
"""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import time

BOARD=Path('/workspace/g350-linux-handheld')
STAGE=BOARD/'dist/g350-source272-kicad49-root-20261016'
IMAGE_SHA='70a47643a9a6d89cca64579b5ef6bab5a290803ccc94ed9b9e170fb14c70b6bb'
LAYER='blobs/sha256/dc6bd6081d010129ac314430968e4a36f2c066bcda19468fc1c1fbc9fc80f938'
CHUNK=1024*1024

def need(ok,message):
 if not ok:raise ValueError(message)
def regular(p):return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(CHUNK),b''):h.update(b)
  if hasattr(os,'posix_fadvise'):os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 return h.hexdigest()
def read(p):return json.loads(p.read_bytes())
def save(p,d):
 tmp=p.with_name(p.name+'.next')
 with tmp.open('x') as f:os.fchmod(f.fileno(),0o600);json.dump(d,f,indent=2,allow_nan=False);f.write('\n')
 os.replace(tmp,p)
def relative(v):
 p=PurePosixPath(v);need(not p.is_absolute() and p.parts and '..' not in p.parts and str(p)==v,'Canonical rootfs path')
 return Path(*p.parts)
def inventory(folder):
 rows={}
 for p in sorted(folder.rglob('*')):
  need(not p.is_symlink(),'No output/config symlinks')
  if p.is_dir():continue
  need(regular(p),'Only regular mirrored files')
  rows[p.relative_to(folder).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)}
 return rows

def verify_rootfs(path,pin):
 need(regular(path) and re.fullmatch('[0-9a-f]{64}',pin) is not None and sha(path)==pin,'Exact completed Root rootfs manifest')
 m=read(path);root=Path(m['rootfs'])
 need(m['scope']=='EXACT_KICAD10_IMAGE_SINGLE_COPY_PROOT_ROOTFS_PREPARATION_NOT_CAD' and m['complete'] is True
      and m['layer']==LAYER and m['rootfsOnTmpfs'] is False and m['kicadExecuted'] is False,'Exact image single-copy preparation')
 need(root.name=='rootfs' and root.parent.parent==BOARD/'.cloud-tools' and root.parent.name.startswith('kicad10-single-rootfs-')
      and root.is_dir() and root.resolve()==root and path.resolve()==root.parent/'ROOTFS.json','Owned workspace-backed rootfs')
 archive=Path(m['imageArchive']['path'])
 need(archive==BOARD/'.cloud-tools/kicad10-debian.tar' and m['imageArchive']['sha256']==IMAGE_SHA and regular(archive) and sha(archive)==IMAGE_SHA,'Unchanged exact KiCad10 archive')
 proof=Path(m['probe']['path']);need(regular(proof) and sha(proof)==m['probe']['sha256'],'Exact successful PRoot prerequisite')
 probe=read(proof)
 need(probe['scope']=='OFFICIAL_DEBIAN_PROOT_OWNED_TRUE_PREREQUISITE_PROBE_NOT_CAD' and probe['passed'] is True
      and probe['exitCode']==0 and probe['kicadExecuted'] is False,'Actual successful plain-child tracing prerequisite')
 need(m['prootExecutable']==probe['prootExecutable'] and m['runtimeLibraries']==probe['runtimeLibraries']
      and m['prootLibraryDirectory']==probe['prootLibraryDirectory'],'Exact retained executable/libraries')
 executable=Path(m['prootExecutable']['path']);library=Path(m['prootLibraryDirectory'])
 need(regular(executable) and sha(executable)==m['prootExecutable']['sha256'] and executable.stat().st_mode&0o111,'Exact executable')
 pinned_libraries={}
 for r in m['runtimeLibraries']:
  p=Path(r['path']);need(p.resolve().is_relative_to(library.resolve()) and regular(p) and p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],'Exact PRoot library')
  pinned_libraries[p.resolve()]=r
 need(pinned_libraries,'Nonempty actual library inventory')
 for p in library.rglob('*'):
  if p.is_dir():continue
  need((p.is_symlink() and p.resolve() in pinned_libraries) or (regular(p) and p.resolve() in pinned_libraries),'No unpinned library or alias target')
 entries={r['path']:r for r in m['entries']};need(len(entries)==len(m['entries'])==m['regularFiles'],'Unique regular image files')
 expected=set(entries);links={r['path']:r for r in m['links']};need(len(links)==len(m['links'])==m['linkCount'],'Unique exact image links')
 need(not(set(entries)&set(links)),'No duplicate file/link identity')
 for name,r in entries.items():
  p=root/relative(name)
  need(p.parent.resolve().is_relative_to(root) and regular(p) and p.stat().st_size==r['bytes']
       and stat.S_IMODE(p.stat().st_mode)==r['mode'] and sha(p)==r['sha256'],'Exact image file '+name)
 for name,r in links.items():
  p=root/relative(name);need(p.parent.resolve().is_relative_to(root),'Contained link parent')
  if r['symbolic']:need(p.is_symlink() and os.readlink(p)==r['target'],'Exact image symlink '+name)
  else:
   q=root/relative(r['target']);need(regular(p) and regular(q) and p.stat().st_ino==q.stat().st_ino and p.stat().st_dev==q.stat().st_dev,'Exact image hardlink '+name)
 actual=set()
 for current,dirs,files in os.walk(root,followlinks=False):
  for n in dirs+files:
   p=Path(current)/n
   if p.is_symlink() or not p.is_dir():
    need(p.is_symlink() or regular(p),'No added special image file')
    actual.add(p.relative_to(root).as_posix())
 need(actual==set(entries)|set(links),'No missing/added image file or link')
 return m

def mountpoints(root,guests):
 created=[]
 for guest in guests:
  need(guest.startswith('/') and '..' not in Path(guest).parts,'Exact absolute guest mountpoint')
  current=root
  for part in Path(guest).parts[1:]:
   current=current/part
   need(not current.is_symlink(),'No mountpoint symlink parent')
   if current.exists():need(current.is_dir(),'Mountpoint collides with image file')
   else:current.mkdir(mode=0o755);created.append(current)
 return created

def publish(job):
 run=Path(job['run']);initial=read(run/'original-output-inventory.json');mirror=run/'runtime/output'
 need(inventory(STAGE)==initial,'Concurrent actual output-stage edits')
 current=inventory(mirror);need(all(current.get(k)==v for k,v in initial.items()),'Trusted command changed an input; preserve mirror')
 added=set(current)-set(initial);need(added<=set(job['allowedOutputs']),'Unplanned mirror outputs')
 out=[]
 for n in sorted(added):
  source,target=mirror/n,STAGE/n
  need('/' not in n and not target.exists() and not target.is_symlink(),'Fresh flat report only')
  with source.open('rb') as reader,target.open('xb') as writer:shutil.copyfileobj(reader,writer,CHUNK);os.fchmod(writer.fileno(),current[n]['mode'])
  need(inventory(STAGE)[n]==current[n],'Copy-back exact bytes/mode')
  out.append({'path':str(target),**current[n]})
 need(inventory(STAGE)==current,'Exact original plus new output equality')
 return out

def main():
 need(len(sys.argv)==5 and sys.argv[1]=='--job' and sys.argv[3]=='--job-sha','Pinned Root job only')
 jp=Path(sys.argv[2]);need(regular(jp) and sha(jp)==sys.argv[4],'Exact Root-created job SHA')
 job=read(jp);run=Path(job['run'])
 need(run.is_dir() and run.resolve()==run and str(run).startswith('/tmp/g350-') and job['stage']==str(STAGE),'Owned Root run/fixed Source272 stage')
 report={'scope':job['scope'],'mode':job['mode'],'stage':'PREFLIGHT','kernelReadOnlyFilesystemEnforced':False,
  'networkNamespaceIsolationEnforced':False,'prootIsPathTranslationOnly':True,'trustedReviewedCommandsOnly':True,
  'boardSaveOrRefillRequested':False,'rootfsImageFileAndLinkMaterialUnchanged':False,'all49Accepted':False,'fabricationReady':False}
 save(run/'proot-runtime.json',report);created=[];child=None;code=1;started=time.monotonic()
 manifest=Path(job['rootfsManifest']);manifest_sha=job['rootfsManifestSha256'];m=None
 try:
  m=verify_rootfs(manifest,manifest_sha);root=Path(m['rootfs'])
  need(inventory(STAGE)==job['stageInventory'],'Exact guard-bound original stage snapshot')
  save(run/'original-output-inventory.json',job['stageInventory'])
  runtime=run/'runtime';runtime.mkdir();shutil.copytree(STAGE,runtime/'output')
  for area in ('home','tmp','xdg-config','xdg-cache','xdg-data'):(runtime/area).mkdir()
  os.chmod(runtime/'tmp',0o1777)
  # Fontconfig writes its system cache even for a read-only board query. Keep
  # the exact initial image cache as private working data; the image directory
  # itself remains under the unchanged full before/end file/link verification.
  cache_source=root/'var/cache/fontconfig'
  need(cache_source.is_dir() and cache_source.resolve()==cache_source,'Genuine image fontconfig cache directory')
  cache_inventory=inventory(cache_source)
  shutil.copytree(cache_source,runtime/'fontconfig')
  need(inventory(runtime/'fontconfig')==cache_inventory,'Exact original fontconfig cache mirror')
  report['privateFontconfigCache']={'guestPath':'/var/cache/fontconfig','sourcePath':str(cache_source),
   'initialFiles':cache_inventory,'privatePath':str(runtime/'fontconfig'),'imageCacheRemainsInput':True}
  if job.get('auxiliaryScriptPath'):
   script=Path(job['auxiliaryScriptPath']);need(regular(script) and sha(script)==job['auxiliaryScriptSha256'],'Exact reviewed guest auxiliary Source')
   shutil.copyfile(script,runtime/'stage-script.py')
  compat=BOARD/'.cloud-tools/python-compat';need(compat.is_dir() and compat.resolve()==compat,'Existing compatibility directory')
  report['compatibilityFiles']=inventory(compat)
  guests=[str(STAGE),str(compat),'/g350-runtime','/tmp','/proc','/dev','/var/cache/fontconfig'];created=mountpoints(root,guests)
  report['newEmptyGuestMountpointDirectories']=[str(p.relative_to(root)) for p in created]
  hostenv={'PATH':'/usr/bin:/bin','LD_LIBRARY_PATH':m['prootLibraryDirectory'],'PROOT_NO_SECCOMP':'1',
           'TMPDIR':str(runtime/'tmp'),'LC_ALL':'C'}
  argv=[m['prootExecutable']['path'],'-r',str(root),'-w',str(STAGE),
   '-b',str(runtime/'output')+':'+str(STAGE),'-b',str(runtime)+':/g350-runtime',
   '-b',str(runtime/'tmp')+':/tmp','-b',str(compat)+':'+str(compat),
   '-b',str(runtime/'fontconfig')+':/var/cache/fontconfig','-b','/proc:/proc','-b','/dev:/dev',
   '/usr/bin/env','-i','PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','HOME=/g350-runtime/home',
   'TMPDIR=/tmp','LC_ALL=C','PYTHONPATH='+str(compat),'PYTHONDONTWRITEBYTECODE=1',
   'XDG_CONFIG_HOME=/g350-runtime/xdg-config','XDG_CACHE_HOME=/g350-runtime/xdg-cache','XDG_DATA_HOME=/g350-runtime/xdg-data',
   'DBUS_SESSION_BUS_ADDRESS=disabled:','NO_AT_BRIDGE=1',*job['trustedCommand']]
  report.update(stage='RUNNING',argv=argv,rootfsManifestSha256=manifest_sha);save(run/'proot-runtime.json',report)
  child=subprocess.Popen(argv,env=hostenv,stdin=subprocess.DEVNULL)  # Inherit outer owned PGID/SID.
  try:code=child.wait(timeout=max(.1,155-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:
   child.terminate()
   try:child.wait(timeout=3)
   except subprocess.TimeoutExpired:child.kill();child.wait(timeout=2)
   raise ValueError('Trusted KiCad stage deadline; outer PGID cleanup required')
  report.update(stage='CHILD_EXITED',actualKiCadExitCode=code)
 except BaseException as exc:
  report.update(stage='REFUSED_OR_FAILED',error={'type':type(exc).__name__,'message':str(exc)})
  raise
 finally:
  # The outer guard independently repeats image-material verification after all
  # descendants are gone; this block never broad-deletes a runtime/rootfs tree.
  for p in reversed(created):
   if p.exists():p.rmdir()
  if m is not None:
   verify_rootfs(manifest,manifest_sha);report['rootfsImageFileAndLinkMaterialUnchanged']=True
   need(inventory(BOARD/'.cloud-tools/python-compat')==report.get('compatibilityFiles',inventory(BOARD/'.cloud-tools/python-compat')),'Compatibility inputs unchanged')
  report['elapsedSeconds']=time.monotonic()-started;save(run/'proot-runtime.json',report)
 return code if 0<=code<=125 else 1

if __name__=='__main__':raise SystemExit(main())
