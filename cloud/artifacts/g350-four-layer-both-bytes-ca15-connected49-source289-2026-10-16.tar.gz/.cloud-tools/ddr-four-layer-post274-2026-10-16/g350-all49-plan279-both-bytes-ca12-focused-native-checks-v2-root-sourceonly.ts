/** SOURCE ONLY. Root alone executes under an external180s/2GB guard.
 * Exact278 both-byte-matched routes -> reviewed combined279 Source plan /280 capture /fresh Core281 controls.
 * Focused16 native findings remain unfiltered; all32 historical185 findings retained.
 * No custom ownership/manufacturing, timing, reference-plane, CAD or fab acceptance.
 */
import * as fs from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { pathToFileURL } from 'node:url'
import { resolve } from 'node:path'
type R=Record<string,any>
const CHECKS='/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js',CHECKS_SHA='1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc'
const PLAN_SHA='27d2c6c788737e36d2b93f4ac404e52f9799805f6b386e3df04f972538176a9e'
const CANDIDATE='/tmp/g350-ca12-retimed49-curves-finite1g-root-20261016-run278/byte0-result.candidate.json',CANDIDATE_SHA='eb55e0ec57b922d083e1f255f4b24e369cf9dfb7f9f64e9cd95579e993e4c3ed'
const CAPTURE='/tmp/g350-both-bytes-ca12-matched49-capture-root-20261016-run280/byte0-result.json',CAPTURE_SHA='b2672bb0c01d5a306da9888a3f78ddac911a896c2d6d3e3b5698e0edd74c0071'
const CAP8='/tmp/g350-current243-cap8-two-declared-pdn-nodes-Vdd72-descriptor-v2-sourceonly.json',CAP8_SHA='20e698e6225f7aa0759aa4acf70103c5f90f3894ae94726336e098598b3f3976'
const ORIGINAL_RAW='/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json',ORIGINAL_RAW_SHA='d2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607'
const ORIGINAL_CONTROLS='/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/core-controls.json',ORIGINAL_CONTROLS_SHA='26323d939bbab3aba376630d9ba3629fbbd2a0bbf5c2a3bec2765893e10f0bc9'
const PRIOR185='/tmp/g350-native45-root-20261016-run185/byte0-result.json',PRIOR185_SHA='fd4517b48526b1cddb77de5227646d195c5786f09db2dcb2c3477d4e16912c88'
const SOURCE_PINS=[
 {path:'/tmp/g350-cap12-cap8-two-pdn-hardware-delta-sourceonly.ts',sha256:'b22beac524e07e00a5a01be0c4ea60221b6b2b4519da8562a1d6e330ff3e4253'},
 {path:'/tmp/g350-cap12-cap8-two-pdn-partial-projector-sourceonly.ts',sha256:'efc01538ff7a87a6734c4a81d13831dca971931c0998f3c4e457de661c033eb9'},
 {path:'/tmp/g350-cap12-cap8-two-pdn-partial-replay-overlay-sourceonly.ts',sha256:'250dcb269613e383e6d80afed6e4b9789c79eb99d59cb7d8cac7ca7c5014e00a'},
 {path:'/tmp/g350-cap12-cap8-two-pdn-partial-capture-core-sourceonly.ts',sha256:'3e27d346e7d1b40c0e8ff0da5a7f8bb4a88f053959f664363ecc9748bae5962d'},
 {path:'/tmp/g350-cap12-cap8-two-pdn-partial-capture-core-v2-exact-obj-loader-root-sourceonly.ts',sha256:'1174b5e84e23c1e47c56d0535657638e10260b76189e36a098056db7027c949f'},
 {path:'/tmp/g350-cap12-cap8-two-pdn-partial-capture-core-v3-exact-obj-step-loaders-root-sourceonly.ts',sha256:'df7e38369721152c4d8bb1930a4f55aba4ebf03904f93962e0b53d4935ae661f'},
 {path:'/workspace/g350-linux-handheld/node_modules/@tscircuit/core/dist/index.js',sha256:'97b8a4eb484630c3ce2bfc2d68588801484d85adf94785d8849a1d91c4404905'},
 {path:'/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v10-ca-top-bytes-bottom-prefork-successor-next/source/imports/USBLC6_2SC6/USBLC6_2SC6.obj',sha256:'b4a68fd1399fd2ab9e7baf51fd4bb6dd8b2a8be45c2b632e1f2c84723c5d7e45'},
 {path:'/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v10-ca-top-bytes-bottom-prefork-successor-next/source/imports/USBLC6_2SC6/USBLC6_2SC6.step',sha256:'53901e8dbe77366e4c00f90fd3613933fd2db1f1453ddc9eee51d8a18d44dbff'},
]
const L=['top','inner1','inner2','bottom'],EPS=1e-8
const sha=(data:string|Uint8Array)=>createHash('sha256').update(data).digest('hex')
const insist=(condition:unknown,message:string):asserts condition=>{if(!condition)throw Error(message)}
const clone=<T>(value:T):T=>structuredClone(value)
const diagnostic=(error:any)=>({name:error?.name??'Error',message:String(error?.message??error),stack:error?.stack??null})
const canonical=(v:any):string=>Array.isArray(v)?`[${v.map(canonical).join(',')}]`:v&&typeof v==='object'?`{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`:JSON.stringify(v)??'undefined'
const same=(a:any,b:any)=>canonical(a)===canonical(b)
const close=(a:number,b:number)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=EPS
const at=(a:R,b:R)=>!!a&&!!b&&close(a.x,b.x)&&close(a.y,b.y)
const roster=(a:any,b:string[])=>Array.isArray(a)&&a.length===b.length&&new Set(a).size===a.length&&a.every((v:string)=>b.includes(v))
const one=(rows:R[],label:string):R=>{insist(rows.length===1,label);return rows[0]}
const ALL49=Array.from({length:49},(_,i)=>'source_trace_'+i)
const EXPECTED_CONTROL_NAMES=[
 ...['source_component','source_trace','pcb_component','pcb_trace','pcb_via','source_manually_placed_via','source_port','pcb_port','pcb_smtpad','pcb_plated_hole','pcb_hole','source_bus','source_net','pcb_keepout'].map(k=>'count-'+k),
 'all280-real-parts-278-held-two-exact-cap12-cap8-translations','all49-original-logical-numeric-owners','all8-original-serialized-bus-rosters-and-skew-semantics-held',
 'all-pcb_smtpad-1157-held-four-exact-cap12-cap8-translations','all-pcb_plated_hole-physical-geometries-held','all-pcb_hole-physical-geometries-held','all-pcb_keepout-physical-geometries-held',
 'all1165-semantic-lands-and-ports-1161-held-four-exact-cap12-cap8-translations','all1165-fresh-lands-covered-bijectively','actual-source-path-component-origin-frame-held',
 'no-old-signal-carrier-source-wire-geometry-retained','all165-reference-wires-161-held-four-exact-connected-cap12-cap8-paths','all129-reference-barrel-geometries-held',
 'all98-old-signal-endpoint-stubs-replaced','all165-exact-reference-trace-rows-accounted','all-generated-signal-and-pdn-vias-real-layer-aliases-and-declared-pdn-nets',
 'all-pending-auxiliary-local-top-traces-real-and-exact','all-pending-original-bodies-removed','all-routed-source-wire-runs-and-planar-lengths',
 'actual-owned-graphs-routed-connected-and-pending-disconnected','exact-routed-connected-pending-disconnected-roster',
]
// The physical10 are exactly the public g350-ddr-physical-checks.mjs roster.
const PHYSICAL10 = [
  'checkEachPcbTraceNonOverlapping', 'checkViaPadClearance', 'checkViaTraceClearance',
  'checkPcbTraceSelfShorts', 'checkCopperToBoardEdgeClearance', 'checkDifferentNetViaSpacing',
  'checkHoleTraceClearance', 'checkPadTraceClearance', 'checkViasInPads', 'checkViasOffBoard',
]
// Preserve the full historical32 roster; this successor executes only the
// explicitly requested physical/contiguity/constraint checks below.
const ORIGINAL32_NAMES = [
  'checkSourceTracesHavePcbTraces', 'checkEachPcbPortConnectedToPcbTraces',
  'checkSourceTracesMatchPcbTraceThickness', 'checkPcbTraceLengths',
  'checkPcbBusLengthSkew', 'checkPcbRoutingConstraints', 'checkPcbTraceViaCounts',
  'checkTracesAreContiguous', 'checkDanglingTraces',
  ...PHYSICAL10,
  'checkSameNetViaSpacing', 'checkCopperPourShorts', 'checkPadPadClearance',
  'checkPcbTracesOutOfBoard', 'checkPcbBendZoneTraces',
  'checkPcbComponentsOutOfBoard', 'checkPcbComponentOverCutout',
  'checkPcbCopperOverKeepout', 'checkPcbComponentOverlap',
  'checkPinMustBeConnected', 'checkSameNameNetsAreConnected',
  'checkSourcePinVoltageCompatibility', 'checkTwoTerminalSwitchContactsOnDifferentNets',
]

const CHECK_NAMES = [...PHYSICAL10, 'checkTracesAreContiguous', 'checkDanglingTraces', 'checkPcbBusLengthSkew', 'checkPcbRoutingConstraints', 'checkPcbTraceViaCounts', 'checkCopperPourShorts']
const NOT_RETESTED_NAMES = ORIGINAL32_NAMES.filter(name => !CHECK_NAMES.includes(name))

function bridgeObservations(raw: any[], controls: any) {
  const projection = controls.logical49Projection
  const graphs = new Map(controls.physicalGraphs.map((g: any) => [g.originalSourceTraceId, g]))
  const pcbTraces = raw.filter((r: any) => r.type === 'pcb_trace')
  const rows = projection.map((p: any) => {
    const connected = (graphs.get(p.originalSourceTraceId) as any)?.physicallyConnectedByActualOwnedNumericIdGraph === true
    const owned = pcbTraces.filter((t: any) => t.source_trace_id === p.actualSourceTraceId)
    let planarLengthMm = 0
    for (const trace of owned) {
      const route = trace.route ?? []
      for (let i = 1; i < route.length; i++) {
        const a = route[i - 1], b = route[i]
        if (a.route_type !== 'wire' || b.route_type !== 'wire' || a.layer !== b.layer) continue
        insist([a.x, a.y, b.x, b.y].every(Number.isFinite), `Nonfinite wire in ${trace.pcb_trace_id}`)
        planarLengthMm += Math.hypot(b.x - a.x, b.y - a.y)
      }
    }
    return { originalSourceTraceId: p.originalSourceTraceId, actualSourceTraceId: p.actualSourceTraceId,
      name: p.name, connected, pcbTraceIds: owned.map((t: any) => t.pcb_trace_id),
      planarLengthMm: connected ? planarLengthMm : null }
  })
  const byName = new Map(rows.map((r: any) => [r.name, r]))
  const findings: any[] = []
  const cohorts = controls.sourceRuleBridge.effectiveCohorts.map((bus: any) => {
    const props = bus.props, members = props.connections.map((name: string) => {
      const row: any = byName.get(name)
      insist(row, `Effective bus ${bus.name} has unmapped member ${name}`)
      if (!row.connected) findings.push({ kind: 'missing_logical_owner', cohort: bus.name, ...row })
      else {
        if (Number.isFinite(props.minLength) && row.planarLengthMm < props.minLength - 1e-8)
          findings.push({ kind: 'below_source_minimum_length', cohort: bus.name, minimumMm: props.minLength, ...row })
        if (Number.isFinite(props.maxLength) && row.planarLengthMm > props.maxLength + 1e-8)
          findings.push({ kind: 'above_source_maximum_length', cohort: bus.name, maximumMm: props.maxLength, ...row })
      }
      return row
    })
    const measured = members.filter((r: any) => r.connected).map((r: any) => r.planarLengthMm)
    const skew = measured.length >= 2 ? Math.max(...measured) - Math.min(...measured) : null
    if (skew !== null && skew > props.maxLengthSkew + 1e-8)
      findings.push({ kind: 'source_cohort_length_skew', cohort: bus.name, measuredMm: skew, maximumMm: props.maxLengthSkew })
    return { name: bus.name, originalMemberNames: props.connections, minLengthMm: props.minLength ?? null,
      maxLengthMm: props.maxLength ?? null, maxLengthSkewMm: props.maxLengthSkew,
      routedMembers: measured.length, totalMembers: members.length, routedSubsetSkewMm: skew, members }
  })
  return { observationsOnly: true, usedAsAcceptanceGate: false, measurementsFromExactRawRows: true,
    lengthModel: 'Sum same-layer consecutive wire-center segments for each mapped fresh source_trace; no guessed via depth; disconnected owners remain null, never zero.',
    electricalDelayQualified: false, all49Complete: rows.length === 49 && rows.every((r: any) => r.connected), rows, cohorts, findings,
    preservedCoreTimingObservations: controls.timingObservations,
    sourceRuleBridge: controls.sourceRuleBridge }
}


export async function runAll49Plan269BothBytesMatchedFocusedNativeChecks(options:{inputPath:string;inputSha256:string;controlsPath:string;controlsSha256:string;planPath:string;planSha256:string;output:string;budgetMs?:number}){
 const started=performance.now(),budgetMs=options.budgetMs??165000
 insist(Number.isInteger(budgetMs)&&budgetMs>=1000&&budgetMs<=165000,'Finite1000..165000ms native budget')
 for(const value of [options.inputSha256,options.controlsSha256,options.planSha256])insist(/^[0-9a-f]{64}$/.test(value),'Explicit exact lowercase64hex raw/control/plan pins')
 insist(options.planSha256===PLAN_SHA,'Only reviewed actual269 both-byte-matched Source plan is authorized by this successor')
 const rawPath=resolve(options.inputPath),controlsPath=resolve(options.controlsPath),planPath=resolve(options.planPath),output=resolve(options.output),RAW_SHA=options.inputSha256,CONTROLS_SHA=options.controlsSha256
 const pins=[{path:rawPath,sha256:RAW_SHA},{path:controlsPath,sha256:CONTROLS_SHA},{path:planPath,sha256:PLAN_SHA},{path:CHECKS,sha256:CHECKS_SHA},{path:CANDIDATE,sha256:CANDIDATE_SHA},{path:CAPTURE,sha256:CAPTURE_SHA},{path:CAP8,sha256:CAP8_SHA},{path:ORIGINAL_RAW,sha256:ORIGINAL_RAW_SHA},{path:ORIGINAL_CONTROLS,sha256:ORIGINAL_CONTROLS_SHA},{path:PRIOR185,sha256:PRIOR185_SHA},...SOURCE_PINS]
 insist(!pins.some(p=>resolve(p.path)===output),'Fresh separate output required')
 const bytes=await Promise.all(pins.map(async p=>{const b=await fs.readFile(p.path);insist(sha(b)===p.sha256,'Exact input/helper pin mismatch '+p.path);return b}))
 const raw:R[]=JSON.parse(bytes[0].toString()),controls=JSON.parse(bytes[1].toString()),plan=JSON.parse(bytes[2].toString()),candidate=JSON.parse(bytes[4].toString()),capture=JSON.parse(bytes[5].toString()),cap8Declaration=JSON.parse(bytes[6].toString()),originalRaw:R[]=JSON.parse(bytes[7].toString()),originalControls=JSON.parse(bytes[8].toString()),prior185=JSON.parse(bytes[9].toString())
 insist(Array.isArray(raw)&&Array.isArray(originalRaw),'Exact CircuitJSON arrays required')
 insist(controls.scope==='PARTIAL_MIXED_JOINED_FRESH_EDITABLE_CORE_CONTROLS'&&controls.rawCoreSha256===RAW_SHA&&controls.freshCoreControlPassed===true&&controls.partialCoreControlPassed===true&&controls.partialDiagnosticReplayControlsPassed===true&&controls.freshCoreDerived===true&&controls.sourceNumericIdsDerivedFromActualRows===true&&controls.capturedIdsUsedAsFreshIds===false&&controls.circuitJsonGeometryEdited===false&&controls.rawIdsAssigned===false,'Fresh unedited actual Core controls and numeric-ID derivation')
 insist(EXPECTED_CONTROL_NAMES.length===35&&roster(controls.checks.map((c:R)=>c.label),EXPECTED_CONTROL_NAMES)&&controls.checks.every((c:R)=>c.passed===true),'All35 exact combined cap12/cap8/PDN replay controls required')
 insist(controls.candidateSha256===CANDIDATE_SHA&&controls.planSha256===PLAN_SHA&&controls.explicitPlanSha256===PLAN_SHA&&controls.actualCaptureSha256===CAPTURE_SHA&&resolve(controls.actualCapturePath)===resolve(CAPTURE)&&resolve(controls.rawCorePath)===rawPath,'Raw/controls/actual280capture/279plan/278candidate binding')
 insist(capture.passed===true&&capture.fullInverseSourceTreePassed===true&&capture.parentNormalizationInversePassed===true&&capture.candidateSha256===CANDIDATE_SHA&&capture.planSha256===PLAN_SHA&&capture.overlayPin.sha256===SOURCE_PINS[2].sha256,'Exact passed280 literal capture and complete reversible Source tree')
 insist(plan.scope==='SOURCE33B_PARTIAL_MIXED_JOINED_EDITABLE_PLAN_SOURCE_PROJECTION_ONLY'&&plan.partialLayerProfile==='compact-four-layer-partial'&&plan.inputBindings.candidate.sha256===CANDIDATE_SHA&&plan.hardwareDeltaProfile==='CAP12_X0P79_CAP8_TWO_NEW_PDN_VIAS'&&roster(plan.routedOwnerIds,ALL49)&&roster(plan.pendingOwnerIds,[])&&roster(plan.replacedOriginals.map((r:R)=>r.originalSourceTraceId),ALL49)&&plan.projectedGeometry.length===49,'Reviewed complete49 both-byte-matched combined279 plan')
 insist(candidate.all49Connected===true&&candidate.allSavedCarriersCurrentSceneQualified===true&&candidate.finalScenePhysicalReports.length===49&&candidate.finalScenePhysicalReports.every((r:R)=>r.passed)&&candidate.full49FanoutInput.obstacles.length===1300&&candidate.full49FanoutInput.traces.length===263&&same(candidate.cap8PlacementInverse,cap8Declaration),'Actual278 full49 physical scene and exact new PDN declaration; evidence is not fresh-native qualification')

 insist(same(controls.sourceRuleBridge,capture.sourceRuleBridge)&&controls.sourceRuleBridge.candidatePin.sha256===CANDIDATE_SHA&&controls.sourceRuleBridge.original49SignalLogicalEndpointsAndAllRulesHeld===true,'Exact Source bridge retains all original logical owners and timing constraints')
 const cohorts=controls.sourceRuleBridge.effectiveCohorts;insist(roster(cohorts.map((b:R)=>b.name),['DDR_BYTE0','DDR_BYTE1','DDR_COMMAND_CLOCK']),'Three original bounded DDR cohorts retained')
 for(const [name,max,min,count] of [['DDR_BYTE0',11.8,null,11],['DDR_BYTE1',14.2,null,11],['DDR_COMMAND_CLOCK',22.29,20.95,26]]as [string,number,number|null,number][]){const b=one(cohorts.filter((b:R)=>b.name===name),'One actual Source cohort '+name).props;insist(b.connections.length===count&&b.maxLengthSkew===.635&&b.maxLength===max&&(min===null?b.minLength===undefined:b.minLength===min)&&b.pcbTraceWidth===.1016&&roster(b.pcbAllowedLayers,L),'All original .635 cohort limits and allowed4 layers retained '+name)}
 insist(same(plan.originalPairRules,[{connectionNames:['source_trace_15','source_trace_16'],lengthTolerance:.127,traceGap:.12},{connectionNames:['source_trace_28','source_trace_27'],lengthTolerance:.127,traceGap:.12},{connectionNames:['source_trace_33','source_trace_34'],lengthTolerance:.127,traceGap:.12}]),'All original .127 pair and .12 spacing limits retained')
 const cap12=plan.cap12HardwareDelta,cap8=plan.cap8HardwareDelta
 insist(cap12.profile==='CAP12_TRANSLATE_X_0P79_ONLY'&&cap8.profile==='CAP8_AT_0_7P9_TWO_NEW_PLANE_VIAS_VDD7P2'&&cap12.candidateBinding.sha256===CANDIDATE_SHA&&cap8.candidateBinding.sha256===CANDIDATE_SHA&&cap8.descriptorBinding.sha256===CAP8_SHA&&same(cap8.originalDeclaration,cap8Declaration)&&same(controls.cap12HardwareDelta,cap12)&&same(controls.cap8HardwareDelta,cap8)&&controls.cap12HardwareDeltaProfile===cap12.profile&&controls.cap8HardwareDeltaProfile===cap8.profile&&same(capture.cap12HardwareDelta,cap12)&&same(capture.cap8HardwareDelta,cap8),'Exact two-cap and newPDN hardware profile across plan/capture/Core')
 const expectedCombined={realComponents:280,heldRealComponents:278,movedRealComponents:2,originalCopperLands:1165,heldCopperLands:1161,movedCopperLands:4,referencePaths:165,heldReferencePaths:161,changedReferencePaths:4,originalReferenceVias:129,heldOriginalReferenceVias:129,addedPdnReferenceVias:2}
 insist(same(controls.combinedHardwareExpectations,expectedCombined)&&same(capture.combinedHardwareExpectations,expectedCombined),'Only two real caps/four lands/four references changed; all129 original barrel geometries retained')
 const N=plan.newVias.length,I=plan.innerPortRegistrations.length,P=cap8.pdnVias.length,J=cap8.innerPortRegistrations.length,RUNS=plan.projectedGeometry.reduce((n:number,r:R)=>n+r.wireRuns.length,0),A=plan.auxiliaryLocalTraces.length
 insist(Number.isInteger(N)&&N>=0&&Number.isInteger(I)&&I>=0&&I<=2*N&&P===2&&J===4&&A===0&&RUNS>=49,'Finite distinct signal/PDN/inner-alias inventories')
 const expectedInventory={physicalVias:129+N+P,pcbComponents:280+129+N+P,sourceAndPcbPorts:1419+2*N+I+2*P+J,sourceTraces:1097+A,physicalTraces:165+RUNS+A,reactElements:2036+N+I+A+P+J,registeredInnerPorts:I+J,newVias:N+P,newSignalVias:N,newPdnVias:P,newInnerPorts:I+J,newSignalInnerPorts:I,newPdnInnerPorts:J,newWireRuns:RUNS+A,routedWireRuns:RUNS,auxiliaryWireRuns:A,auxiliaryLocalTraces:A,routedOwners:49,pendingOwners:0}
 insist(same(controls.expectedCounts,expectedInventory)&&same(capture.expectedCounts,expectedInventory),'Fresh counts derive original129 + signalN + newPDN2; never inherit old229')
 const d=plan.dynamicCounts
 insist(d.expectedPcbVias===expectedInventory.physicalVias&&d.expectedSourceVias===expectedInventory.physicalVias&&d.expectedPcbComponents===expectedInventory.pcbComponents&&d.expectedSourcePorts===expectedInventory.sourceAndPcbPorts&&d.expectedSourceTraces===expectedInventory.sourceTraces&&d.expectedPhysicalTraces===expectedInventory.physicalTraces&&d.expectedReactElements===expectedInventory.reactElements&&d.signalNewViaEvents===N&&d.signalInnerRegistrations===I&&d.addedPdnReferenceVias===P&&d.addedPdnInnerRegistrations===J&&d.totalNewFullspanSourceVias===N+P&&d.totalNewInnerRegistrations===I+J&&d.routedWireRuns===RUNS&&d.routedOwners===49&&d.pendingOwners===0,'All reviewed plan dynamic inventories match independently derived counts')
 const rows=(type:string)=>raw.filter(r=>r.type===type),byId=(type:string,key:string,id:string)=>one(rows(type).filter(r=>r[key]===id),'One actual '+type+' '+id)
 for(const[type,count]of[['source_component',280],['source_manually_placed_via',expectedInventory.physicalVias],['pcb_via',expectedInventory.physicalVias],['pcb_component',expectedInventory.pcbComponents],['source_port',expectedInventory.sourceAndPcbPorts],['pcb_port',expectedInventory.sourceAndPcbPorts],['source_trace',expectedInventory.sourceTraces],['pcb_trace',expectedInventory.physicalTraces]]as [string,number][])insist(rows(type).length===count,'Exact dynamic fresh '+type+' count')
 const parts=rows('source_component'),viaSources=rows('source_manually_placed_via'),components=rows('pcb_component'),partIds=new Set(parts.map(r=>r.source_component_id)),viaSourceIds=new Set(viaSources.map(r=>r.source_manually_placed_via_id))
 insist(partIds.size===280&&viaSourceIds.size===expectedInventory.physicalVias&&[...partIds].every(id=>!viaSourceIds.has(id))&&components.every(c=>Number(partIds.has(c.source_component_id))+Number(viaSourceIds.has(c.source_component_id))===1)&&[...partIds,...viaSourceIds].every(id=>components.filter(c=>c.source_component_id===id).length===1),'Fresh280 real components and dynamic manual-via components have exact typed ownership bijection')
 insist(roster(controls.routedOwnerIds,ALL49)&&roster(controls.pendingOwnerIds,[])&&controls.expectedConnectedOwners===49&&controls.expectedPendingOwners===0&&roster(controls.logical49Projection.map((r:R)=>r.originalSourceTraceId),ALL49)&&roster(controls.physicalGraphs.map((r:R)=>r.originalSourceTraceId),ALL49)&&controls.physicalGraphs.every((r:R)=>r.physicallyConnectedByActualOwnedNumericIdGraph===true),'All49 complete original logical/graph owner inventories')
 insist(controls.generatedViaChecks.length===N+P&&controls.generatedViaChecks.every((r:R)=>r.passed&&r.declaredNetPassed)&&controls.heldViaChecks.length===129&&controls.heldViaChecks.every((r:R)=>r.passed),'Fresh generated/held via controls required')
 const viaAuthentications:R[]=[],usedViaIds=new Set<string>()
 const authVia=(name:string,spec:R,record:R,kind:string)=>{
  const actualId=record.actualPcbViaId??record.actualFreshPcbViaId;insist(/^pcb_via_\d+$/.test(actualId)&&!usedViaIds.has(actualId),'Unique actual numeric physical via ID '+name);usedViaIds.add(actualId)
  const v=byId('pcb_via','pcb_via_id',actualId),expectedLayers=['top','bottom',...(spec.innerLayers??[])],ports=(v.pcb_port_ids??[]).map((id:string)=>byId('pcb_port','pcb_port_id',id)),sourcePorts=ports.map(p=>byId('source_port','source_port_id',p.source_port_id)),sourceOwners=[...new Set(sourcePorts.map(p=>p.source_component_id))];insist(sourceOwners.length===1,'One actual manual source owner per physical via '+name)
  const manual=byId('source_manually_placed_via','source_manually_placed_via_id',sourceOwners[0]),pc=one(components.filter(c=>c.source_component_id===manual.source_manually_placed_via_id),'One actual via component '+name)
  insist(roster(v.layers,L)&&v.outer_diameter===.4572&&v.hole_diameter===.254&&v.from_layer==='top'&&v.to_layer==='bottom'&&v.tented_on_top===true&&v.tented_on_bottom===true&&at(v,spec)&&ports.length===expectedLayers.length&&new Set(v.pcb_port_ids).size===ports.length&&roster(ports.map(p=>p.layers?.length===1?p.layers[0]:null),expectedLayers)&&at(pc.center,v)&&pc.width===.4572&&pc.height===.4572&&pc.layer==='top'&&pc.rotation===0,'Exact fullspan land/drill/placement/component/layer aliases '+name)
  const aliases=ports.map((p,i)=>{const sp=sourcePorts[i],layer=p.layers[0];insist(/^pcb_port_\d+$/.test(p.pcb_port_id)&&/^source_port_\d+$/.test(sp.source_port_id)&&p.pcb_component_id===pc.pcb_component_id&&sp.source_component_id===manual.source_manually_placed_via_id&&sp.name===layer&&at(p,v),'Actual numeric layer alias linked to exact manual Source/PCB component '+name);return {layer,actualPcbPortId:p.pcb_port_id,actualSourcePortId:sp.source_port_id}})
  if(kind!=='HELD_REFERENCE')insist(record.actualViaSourceId===manual.source_manually_placed_via_id&&record.actualPcbComponentId===pc.pcb_component_id&&record.generatedKind===kind,'Generated control matches independently authenticated actual via '+name)
  const a={name,kind,actualPcbViaId:v.pcb_via_id,actualViaSourceId:manual.source_manually_placed_via_id,actualPcbComponentId:pc.pcb_component_id,x:v.x,y:v.y,layers:clone(v.layers),outerDiameter:v.outer_diameter,holeDiameter:v.hole_diameter,aliases,declaredNetId:v.source_net_id??null,passed:true};viaAuthentications.push(a);return a
 }
 for(const spec of plan.newVias){const record=one(controls.generatedViaChecks.filter((r:R)=>r.name===spec.name&&r.generatedKind==='SIGNAL'),'One generated signal control');authVia(spec.name,spec,record,'SIGNAL')}
 for(const spec of cap8.pdnVias){const record=one(controls.generatedViaChecks.filter((r:R)=>r.name===spec.name&&r.generatedKind==='PDN'),'One generated PDN control');authVia(spec.name,spec,record,'PDN')}
 for(const record of controls.heldViaChecks){const oldMap=one(originalControls.viaProjection.filter((r:R)=>r.sourceViaName===record.name),'One authenticated original via source name'),old=one(originalRaw.filter(r=>r.type==='pcb_via'&&r.pcb_via_id===oldMap.actualViaId),'One original held via geometry'),a=authVia(record.name,{x:old.x,y:old.y,innerLayers:[]},record,'HELD_REFERENCE'),v=byId('pcb_via','pcb_via_id',a.actualPcbViaId);for(const key of ['x','y','hole_diameter','outer_diameter','layers','from_layer','to_layer','tented_on_top','tented_on_bottom'])insist(typeof old[key]==='number'?close(old[key],v[key]):same(old[key],v[key]),'Held129 via physical property preserved '+record.name+' '+key)}
 insist(viaAuthentications.length===expectedInventory.physicalVias&&usedViaIds.size===expectedInventory.physicalVias,'Every actual physical via authenticated exactly once:129held + signalN + PDN2')
 const independentOwnerGraphs:R[]=[]
 for(const logical of controls.logical49Projection){
  const sid=logical.originalSourceTraceId,actual=byId('source_trace','source_trace_id',logical.actualSourceTraceId),numeric=logical.actualNumericPcbPortIds.map((id:string)=>byId('pcb_port','pcb_port_id',id)),numericSources=numeric.map((p:R)=>byId('source_port','source_port_id',p.source_port_id));insist(numeric.length===2&&numeric.every((p:R)=>roster(p.layers,['top']))&&same(actual.connected_source_port_ids,numericSources.map((p:R)=>p.source_port_id)),'Actual original logical Source connects exactly both numeric Top pads '+sid)
  const specs=plan.newVias.filter((v:R)=>v.originalSourceTraceId===sid),ownVias=specs.map((s:R)=>one(viaAuthentications.filter(a=>a.kind==='SIGNAL'&&a.name===s.name),'One actual owner via')),allowed=new Set([...logical.actualNumericPcbPortIds,...ownVias.flatMap(v=>v.aliases.map((a:R)=>a.actualPcbPortId))]),owned=rows('pcb_trace').filter(t=>t.source_trace_id===logical.actualSourceTraceId),adj=new Map<string,Set<string>>(),usedPorts=new Set<string>(),edge=(a:string,b:string)=>{for(const[x,y]of[[a,b],[b,a]]){if(!adj.has(x))adj.set(x,new Set());adj.get(x)!.add(y)}}
  const projected=one(plan.projectedGeometry.filter((r:R)=>r.originalSourceTraceId===sid),'One exact projected owner geometry');insist(owned.length===projected.wireRuns.length,'Actual owned wire-run count '+sid)
  for(const t of owned){insist(t.route.length>=2&&t.route.every((p:R)=>p.route_type==='wire'&&p.width===.1016&&L.includes(p.layer)),'Actual pure .1016 wire runs '+sid);const a=t.route[0],b=t.route.at(-1),pa=byId('pcb_port','pcb_port_id',a.start_pcb_port_id),pb=byId('pcb_port','pcb_port_id',b.end_pcb_port_id);insist(allowed.has(pa.pcb_port_id)&&allowed.has(pb.pcb_port_id)&&at(a,pa)&&at(b,pb)&&pa.layers.includes(a.layer)&&pb.layers.includes(b.layer),'Every wire endpoint uses only its exact numeric pad or owned actual via layer '+sid);usedPorts.add(pa.pcb_port_id);usedPorts.add(pb.pcb_port_id);edge(pa.pcb_port_id,pb.pcb_port_id)}
  for(const v of ownVias){const wired=v.aliases.filter((a:R)=>usedPorts.has(a.actualPcbPortId));insist(wired.length===2,'Every declared signal barrel physically travels between exactly two real layer aliases '+v.name);for(const a of v.aliases)edge(a.actualPcbPortId,v.actualPcbViaId)}
  const [start,end]=logical.actualNumericPcbPortIds,seen=new Set([start]),queue=[start];for(let i=0;i<queue.length;i++)for(const next of adj.get(queue[i])??[])if(!seen.has(next)){seen.add(next);queue.push(next)}insist(seen.has(end),'Independent actual OWNED numeric port/barrel graph connected '+sid)
  independentOwnerGraphs.push({originalSourceTraceId:sid,actualSourceTraceId:logical.actualSourceTraceId,actualNumericPcbPortIds:clone(logical.actualNumericPcbPortIds),actualOwnedPcbTraceIds:owned.map(t=>t.pcb_trace_id),actualOwnedViaIds:ownVias.map(v=>v.actualPcbViaId),onlyActualOwnedViaAliasesIncluded:true,connected:true})
 }
 const pdnAuthentications:R[]=[]
 for(const spec of cap8.pdnVias){const v=one(viaAuthentications.filter(a=>a.kind==='PDN'&&a.name===spec.name),'One authenticated PDN node'),netName=String(spec.connectsTo).slice(4),net=one(rows('source_net').filter(n=>n.name===netName),'One actual declared PDN net'),manual=byId('source_manually_placed_via','source_manually_placed_via_id',v.actualViaSourceId),pv=byId('pcb_via','pcb_via_id',v.actualPcbViaId),ref=one(cap8.references.filter((r:R)=>r.toSelector==='.'+spec.name+' > port.bottom'),'One actual retargeted PDN reference spec'),source=one(rows('source_trace').filter(r=>r.name===ref.literalTraceName),'One actual retargeted PDN source trace'),wire=one(rows('pcb_trace').filter(r=>r.source_trace_id===source.source_trace_id),'One actual retargeted PDN wire'),bottom=one(v.aliases.filter((a:R)=>a.layer==='bottom'),'One actual PDN Bottom alias'),end=wire.route.at(-1),start=wire.route[0],startPort=byId('pcb_port','pcb_port_id',start.start_pcb_port_id),startSource=byId('source_port','source_port_id',startPort.source_port_id)
  insist(['DDR_1V5','GND'].includes(netName)&&manual.source_net_id===net.source_net_id&&pv.source_net_id===net.source_net_id&&same(source.connected_source_net_ids,[net.source_net_id])&&same(source.connected_source_port_ids,[startSource.source_port_id,bottom.actualSourcePortId])&&end.end_pcb_port_id===bottom.actualPcbPortId&&at(end,spec)&&wire.route.every((p:R)=>p.route_type==='wire'&&p.layer==='bottom'&&p.width===.2)&&wire.route.length===ref.absolutePoints.length&&wire.route.every((p:R,i:number)=>at(p,ref.absolutePoints[i])),'Both new PDN real declared rail/net ownership and width.2 path/Bottom numeric endpoint')
  const actualRefCheck=one(controls.referenceChecks.filter((r:R)=>r.literalTraceName===ref.literalTraceName),'One Core actual PDN reference control');insist(actualRefCheck.passed&&actualRefCheck.endpointSourceAndPhysicalConnectivityHeld&&actualRefCheck.declaredNetProof?.passed&&actualRefCheck.declaredNetProof.actualSourceNetId===net.source_net_id,'Actual fresh Core reference proof agrees with independently rederived PDN net')
  pdnAuthentications.push({name:spec.name,connectsTo:spec.connectsTo,actualSourceNetId:net.source_net_id,actualViaSourceId:manual.source_manually_placed_via_id,actualPcbViaId:pv.pcb_via_id,actualSourceTraceId:source.source_trace_id,actualPcbTraceId:wire.pcb_trace_id,actualBottomPcbPortId:bottom.actualPcbPortId,actualBottomSourcePortId:bottom.actualSourcePortId,allFourRealLayerAliases:clone(v.aliases),actualNumericPortAndNetOwnershipPassed:true,planeIslandContinuityQualified:false,planeGraphQualified:false})
 }
 insist(pdnAuthentications.length===2&&independentOwnerGraphs.length===49,'All49 independent owned graphs and both real PDN nets/aliases authenticated')
 insist(CHECK_NAMES.length===16&&new Set(CHECK_NAMES).size===16&&NOT_RETESTED_NAMES.length===16&&prior185.scope==='PARTIAL45_ACTUAL182_NATIVE_CHECK_DIAGNOSTIC'&&prior185.completed===true&&prior185.results.length===32&&prior185.results.every((r:R)=>r.state==='completed'&&Array.isArray(r.findings))&&roster(prior185.results.map((r:R)=>r.name),ORIGINAL32_NAMES),'All32 unfiltered historical185 results retained; exact current focused16 roster')
 const rawCanonicalSha256=sha(JSON.stringify(raw)),results:R[]=[]
 const report:R={scope:'ALL49_PLAN279_BOTH_BYTES_MATCHED_COMBINED_CAP12_CAP8_PDN2_FOCUSED16_FRESH_CORE_NATIVE_CHECK_DIAGNOSTIC',inputBindings:{raw:{path:rawPath,sha256:RAW_SHA},controls:{path:controlsPath,sha256:CONTROLS_SHA},reviewedSourcePlan:{path:planPath,sha256:PLAN_SHA},candidate278:{path:CANDIDATE,sha256:CANDIDATE_SHA},actualCapture280:{path:CAPTURE,sha256:CAPTURE_SHA},checks:{path:CHECKS,sha256:CHECKS_SHA,package:'@tscircuit/checks',version:'0.0.242'},sourceHelperPins:SOURCE_PINS},expectedInventory,combinedHardwareExpectations:expectedCombined,cap12HardwareDeltaProfile:cap12.profile,cap12HardwareDelta:cap12,cap8HardwareDeltaProfile:cap8.profile,cap8HardwareDelta:cap8,allActualViaAuthentications:viaAuthentications,independentOwnerGraphs,pdnAuthentications,logical49Projection:controls.logical49Projection,corePhysicalGraphs:controls.physicalGraphs,routedOwnerIds:controls.routedOwnerIds,pendingOwnerIds:controls.pendingOwnerIds,all49ConnectedByIndependentActualOwnedGraph:true,source257QualificationInherited:false,bothBytesMatchedRoutesAreCurrentCandidateEvidenceOnly:true,source264QualificationInherited:false,source272QualificationInherited:false,budgetMs,externalRootGuardRequired:{maximumWallMs:180000,memoryMb:2048},nativeExecuted:false,completed:false,currentCheck:null,requestedCheckNames:CHECK_NAMES,physical10:PHYSICAL10,results,allFindingsRetainedWithoutFilteringOrDedupe:true,prior185Evidence:{path:PRIOR185,sha256:PRIOR185_SHA,scope:prior185.scope,inputBindings:prior185.inputBindings,completeOriginal32Results:prior185.results,allOriginalFindingsRetained:true,inheritedQualification:false},notRetestedChecks:NOT_RETESTED_NAMES.map(name=>({name,state:'NOT_RETESTED',reason:'Focused16 only; historical185 full32 findings retained without inherited qualification',historical185Result:prior185.results.find((r:R)=>r.name===name),inheritedQualification:false})),rawInputEdited:false,rawCanonicalSha256,coreReplayControlsPassed:true,sourceTiming:bridgeObservations(raw,controls),customViaTrackManufacturing:{executed:false,qualified:false,reason:'A separate current-input authenticated all-layer SourceTrace/net diagnostic is mandatory for the dynamically derived physical vias; no inherited229 ownership, undefined-owner exemption or drill/whole-route qualification.',originalCustomHelperExecuted:false,allThroughViaBarrelsManufacturingQualified:false},nativeScopeLimits:['Focused16 only; the other16 native checks retain historical185 findings and were not freshly executed.','Native hole/trace checks do not prove every via/PTH drill pair.','Native inline via counts do not prove separately declared manual-via budgets.','Native individual-row self checks do not prove whole split-route/barrel self clearance.','Both new PDN actual identities/nets are derived from fresh raw; plane island continuity and full via/plane graph remain separate fresh gates.','All original .635 bus/.127 pair limits and every absolute/minimum/skew observation remain; no electrical delay or fabrication qualification follows from connectivity.'],all49Accepted:false,full49Accepted:false,fullBoardPassed:false,electricalTimingQualified:false,fabricationReady:false,wholeMixedC31Validated:false,wholeMixedNativeQualified:false,allThroughViaBarrelsPhysicalQualified:false,regeneratedPlaneContinuityQualified:false}
 await fs.writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'})
 const save=async()=>{report.elapsedMs=performance.now()-started;report.completedCheckCount=results.filter(r=>r.state==='completed').length;report.exceptionCount=results.filter(r=>r.state==='exception').length;report.totalReturnedFindingCount=results.reduce((n,r)=>n+(r.findings?.length??0),0);for(const pin of pins)insist(sha(await fs.readFile(pin.path))===pin.sha256,'Pinned input/helper changed during diagnostic '+pin.path);insist(sha(JSON.stringify(raw))===rawCanonicalSha256,'Canonical exact raw array changed');report.rawFileUnchanged=true;report.controlsFileUnchanged=true;report.allPinnedInputsUnchanged=true;const tmp=output+'.next';await fs.writeFile(tmp,JSON.stringify(report,null,2)+'\n',{flag:'wx'});await fs.rename(tmp,output)}
 try{
  const native:any=await import(pathToFileURL(CHECKS).href)
  for(const name of CHECK_NAMES){if(performance.now()-started>=budgetMs-500){results.push({name,state:'not_run_budget',findings:null});await save();continue}const result:R={name,state:'running',findings:null};results.push(result);report.currentCheck=name;await save();const checkStarted=performance.now();try{insist(typeof native[name]==='function','Missing reviewed native export '+name);const checkInput=clone(raw),before=sha(JSON.stringify(checkInput));report.nativeExecuted=true;const findings=await native[name](checkInput);insist(Array.isArray(findings),name+' returned nonarray findings');result.findings=findings;result.findingCount=findings.length;result.checkInputMutated=sha(JSON.stringify(checkInput))!==before;result.state='completed'}catch(error){result.state='exception';result.error=diagnostic(error)}result.elapsedMs=performance.now()-checkStarted;report.currentCheck=null;await save()}
  report.completed=results.length===CHECK_NAMES.length&&results.every(r=>r.state==='completed');report.allRequestedNativeChecksReturnedNoFindings=report.completed&&results.every(r=>r.findings.length===0);report.all32FreshNativeChecksExecuted=false;report.onlyFocused16WereRetested=true;report.finished=true;await save()
 }catch(error){report.workerError=diagnostic(error);report.finished=false;report.completed=false;await save();throw error}
 return report
}
if(import.meta.main){const args=process.argv.slice(2),opts:Record<string,string>={};for(let i=0;i<args.length;i+=2){insist(/^--(?:input|input-sha|controls|controls-sha|plan|plan-sha|output|budget-ms)$/.test(args[i])&&args[i+1]!==undefined,'Unknown/missing CLI '+args[i]);insist(!(args[i]in opts),'Duplicate CLI '+args[i]);opts[args[i]]=args[i+1]}for(const k of ['--input','--input-sha','--controls','--controls-sha','--plan','--plan-sha','--output'])insist(opts[k],'Required '+k);await runAll49Plan269BothBytesMatchedFocusedNativeChecks({inputPath:opts['--input'],inputSha256:opts['--input-sha'],controlsPath:opts['--controls'],controlsSha256:opts['--controls-sha'],planPath:opts['--plan'],planSha256:opts['--plan-sha'],output:opts['--output'],budgetMs:opts['--budget-ms']===undefined?undefined:Number(opts['--budget-ms'])})}
