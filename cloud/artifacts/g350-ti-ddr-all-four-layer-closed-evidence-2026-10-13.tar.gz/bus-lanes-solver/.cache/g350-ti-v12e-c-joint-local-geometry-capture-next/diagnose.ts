import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { createHash } from "node:crypto"
import type { SimpleRouteJson } from "../g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/source/lib/types"

const ROOT = import.meta.dir
const sha = (value: string | Uint8Array) => createHash("sha256").update(value).digest("hex")
assert.deepEqual(process.argv.slice(2), ["--run-one-approved"])
assert.equal(process.env.G350_LOCAL_DOGBONE_APPROVED, "1")
const manifestRaw = fs.readFileSync(path.join(ROOT, "SOURCE-manifest.json"))
const manifest = JSON.parse(manifestRaw.toString())
const authRaw = fs.readFileSync(process.env.G350_LOCAL_DOGBONE_AUTH_PATH!)
assert.equal(sha(authRaw), process.env.G350_LOCAL_DOGBONE_AUTH_SHA)
const auth = JSON.parse(authRaw.toString())
assert.equal(auth.authorizedByRoot, true)
assert.equal(auth.scope, manifest.scope)
assert.equal(auth.packetSha256, sha(manifestRaw))
assert.ok(/^[0-9a-f]{32,128}$/.test(auth.approvalToken))
assert.equal(fs.existsSync(path.join(ROOT, "run", "result.json")), false)
assert.equal(fs.existsSync(path.join(ROOT, "run", "whole-local-fanouts.json")), false)
const raw = fs.readFileSync(manifest.inputPath)
assert.equal(sha(raw), manifest.inputSha256)
const input = JSON.parse(raw.toString()) as SimpleRouteJson
assert.equal(input.connections.length, 49)
assert.equal(input.obstacles.length, 856)
assert.equal(input.traces?.length, 2)
const before = JSON.stringify(input)
const targets = new Map<string, string>()
for (const connection of input.connections) {
  const buses = (input.buses ?? []).filter(bus => bus.connectionNames.includes(connection.name))
  assert.equal(buses.length, 1)
  assert.equal(buses[0].allowedLayers?.length, 1)
  const target = buses[0].allowedLayers![0]
  assert.equal(target, manifest.cohortCarrierConstraints[buses[0].busId])
  targets.set(connection.name, target)
}
const widths = input.connections.map(c => (input.buses ?? []).find(bus => bus.connectionNames.includes(c.name))?.traceWidth ?? c.nominalTraceWidth ?? c.width ?? input.minTraceWidth)
const options = {
  targetLayers: targets,
  viaDiameter: input.minViaPadDiameter ?? .6,
  viaHoleDiameter: input.minViaHoleDiameter ?? .3,
  traceWidth: Math.max(input.minTraceWidth, ...widths),
  clearance: input.minTraceToPadEdgeClearance ?? input.defaultObstacleMargin ?? .075,
  boardEdgeClearance: input.minBoardEdgeClearance,
  holeToHoleClearance: input.minViaHoleEdgeToViaHoleEdgeClearance,
  allowBlindAndBuriedVias: input.allowBlindAndBuriedVias ?? false,
}
const prior = JSON.parse(fs.readFileSync(manifest.reusedLocalProofResultPath, "utf8"))
assert.equal(prior.inputSha256, manifest.reusedLocalProofInputSha256)
assert.equal(prior.patchedIndividualCalls, 196)
assert.equal(prior.patchedWholeCalls, 4)
assert.deepEqual([...targets], prior.targetLayerMap)
assert.deepEqual(JSON.parse(JSON.stringify({ ...options, targetLayers: undefined })), prior.exactOptions)
assert.deepEqual(prior.zeroIndividualNames, [])
assert.ok(prior.whole.every((row: any) => row.returned && row.connections === 49 && row.generatedViaRecords === 96))
// Exactly the already-qualified wrapper and copied 0.0.76 API. Attempt zero
// retains its original routing-frame choice; no independent rows are merged.
const { routeAlternateSignalDogbones } = await import("../g350-fanout-source-layer-clearance-fix-next/patched-alternate-signal-dogbones")
let calls = 0
const started = performance.now()
calls++
const whole = routeAlternateSignalDogbones(input, options, 0)
const elapsedMs = performance.now() - started
const wholeRaw = JSON.stringify(whole, null, 2) + "\n"
assert.ok(Buffer.byteLength(wholeRaw) <= 1024 * 1024)
fs.writeFileSync(path.join(ROOT, "run", "whole-local-fanouts.json"), wholeRaw, { flag: "wx" })
const viaRecords = whole.traces.flatMap((trace, traceIndex) => trace.route.flatMap((point, pointIndex) => point.route_type === "via" ? [{ traceIndex, pointIndex, connectionName: trace.connection_name, point }] : []))
const geometry = whole.traces.map(trace => ({ connection_name: trace.connection_name, route: trace.route }))
const result = {
  scope: manifest.scope, diagnosticOnly: true, accepted49: false,
  fabricationReady: false, physicalAcceptanceClaimed: false,
  CoreGeometryReused: true, sourceClassMetadataOverlayAlreadyForwarded: true,
  nativePlacementChecksInheritedNotRerun: true, nativePlacementChecks: 17,
  inputSha256: sha(raw), inputUnchanged: JSON.stringify(input) === before,
  patchedWholeCalls: calls, patchedIndividualCalls: 0, attempt: 0,
  reusedLocalProofResultSha256: manifest.reusedLocalProofResultSha256,
  historicalIndividual196AndWhole4ExplicitlyReusedNotRerun: true,
  sourceConnections: input.connections.length, fullObstaclesPerCall: input.obstacles.length,
  fixedReferencesPerCall: input.traces!.length, generatedConnections: whole.connections.length,
  generatedTraces: whole.traces.length, generatedViaRecords: viaRecords.length,
  generatedWirePrimitives: whole.traces.reduce((sum, trace) => sum + trace.route.filter(point => point.route_type === "wire").length, 0),
  targetLayerMap: [...targets], exactOptions: { ...options, targetLayers: undefined },
  wholeLocalFanoutsPath: "whole-local-fanouts.json", wholeLocalFanoutsSha256: sha(wholeRaw),
  geometrySha256: sha(JSON.stringify(geometry)), physicalViaRecords: viaRecords,
  privatePatchedMatcherSha256: manifest.privatePatchedMatcherSha256,
  originalTaskGeneratorPrefixSha256: manifest.originalTaskGeneratorPrefixSha256,
  noGridNoNativeChecker: true, elapsedMs,
  scopeLimit: "One joint local fanout call only. Raw returned local wires and full-depth via points are not CPU-to-RAM interconnect, checker-qualified copper, reference-plane acceptance, or a PR snapshot. No public routing or new Core/native checks."
}
const reportRaw = JSON.stringify(result, null, 2) + "\n"
fs.writeFileSync(path.join(ROOT, "run", "result.json"), reportRaw, { flag: "wx" })
// Preserve the actual returned object and report before checking expected shape.
assert.equal(calls, 1)
assert.equal(result.inputUnchanged, true)
assert.equal(whole.connections.length, 49)
assert.equal(whole.traces.length, 96)
assert.equal(viaRecords.length, 96)
assert.ok(viaRecords.every(({ point }) => JSON.stringify(point.layers) === JSON.stringify(["top", "inner1", "inner2", "bottom"]) && point.via_diameter === .4572 && point.via_hole_diameter === .254))
console.log(JSON.stringify({ diagnosticOnly: true, patchedWholeCalls: calls, generatedConnections: whole.connections.length, generatedViaRecords: viaRecords.length, wholeLocalFanoutsSha256: result.wholeLocalFanoutsSha256, geometrySha256: result.geometrySha256, accepted49: false }))
