import { strict as assert } from "node:assert"
import { test } from "bun:test"
import { runCapturedGridProbe } from "./grid-probe"
const capture = {
  input: { token: "held" },
  connection: { name: "n" },
  width: 0.1016,
  margin: 0.1524,
  owners: ["n"],
  copper: [{ token: "realCu" }],
  start: { x: 0, y: 0 },
  end: { x: 1, y: 1 },
}
class Scene {
  owners: Set<string>
  margin = 0.1524
  constructor(
    public input: any,
    public connection: any,
    public width: number,
    public copper: any,
  ) {
    this.owners = new Set([connection.name])
  }
  pathVisible(_path: any) {
    return true
  }
}
function controlled(kind: "capped" | "failed" | "solved") {
  const calls: any[] = []
  class Grid {
    solved = false
    failed = kind === "failed"
    expanded = kind === "capped" ? 499999 : 0
    result = [capture.start, capture.end]
    nx = 2
    ny = 2
    cellCount = 4
    constructor(...args: any[]) {
      calls.push(args)
    }
    step() {
      this.expanded++
      if (kind === "solved") this.solved = true
    }
    cancel() {
      if (!this.solved) this.failed = true
    }
  }
  return { api: { Scene, Grid }, calls }
}
test("only the existing optional component flag changes; original defaults and capture identities forwarded", () => {
  const c = controlled("failed"),
    result = runCapturedGridProbe(capture, c.api),
    args = c.calls[0]
  assert.equal(args[1], capture.start)
  assert.equal(args[2], capture.end)
  assert.equal(args[0].input, capture.input)
  assert.equal(args[0].copper, capture.copper)
  assert.ok(
    args[3].length === 0 &&
      args[4] === 4 &&
      args[5] === undefined &&
      args[6].checkReachability === true,
  )
  assert.equal(result.beforeCancel.steps, 0)
  assert.equal(result.physicalTrappingProven, false)
  assert.equal(result.accepted49, false)
})
test("bounded unknown is recorded before cleanup failure; solved and finite failure stay distinct", () => {
  const unknown = runCapturedGridProbe(capture, controlled("capped").api)
  assert.equal(unknown.status, "BOUNDED_GRID_UNKNOWN")
  assert.equal(unknown.beforeCancel.failed, false)
  assert.equal(unknown.afterCancel.failed, true)
  assert.equal(unknown.beforeCancel.expanded, 500000)
  assert.equal(unknown.cancelCalls, 1)
  const failed = runCapturedGridProbe(capture, controlled("failed").api)
  assert.equal(
    failed.status,
    "FINITE_OFFERED_GRID_DISCONNECTED_OR_COMPLETED_FAILURE",
  )
  assert.equal(failed.beforeCancel.failed, true)
  const solved = runCapturedGridProbe(capture, controlled("solved").api)
  assert.equal(solved.status, "EXACT_GRID_POSITIVE_WITNESS")
  assert.equal(solved.beforeCancel.solved, true)
  assert.equal(solved.cancelCalls, 1)
})
test("Scene parity mutation rejects with a bounded message before a Grid exists", () => {
  class Altered extends Scene {
    margin = 0.2
  }
  const controlledGrid = controlled("failed")
  assert.throws(
    () =>
      runCapturedGridProbe(capture, { ...controlledGrid.api, Scene: Altered }),
    /Scene parity/,
  )
  assert.equal(controlledGrid.calls.length, 0)
})
