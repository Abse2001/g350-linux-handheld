from pathlib import Path
import argparse, hashlib, importlib.util, json, re, stat, subprocess, sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/bus-lanes-solver')
BASE = ROOT.parent/'g350-count-conditioned-site-recovery-next'
POLICY = {'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
RESERVE = 2*1024**3
BUN = '/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);loaded=importlib.util.module_from_spec(spec);spec.loader.exec_module(loaded);return loaded
def verify():
    raw=(ROOT/'SOURCE-manifest.json').read_bytes();packet=json.loads(raw)
    for row in packet['files']+packet['externalFiles']:
        path=Path(row['path']);assert path.is_file() and not path.is_symlink()
        assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes'] and stat.S_IMODE(path.stat().st_mode)==row['mode'],str(path)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==packet['canonicalHead']
    scope=module('original_grid_phase_owned_scope',BASE/'process_scope.py')
    recovered=json.loads(Path(packet['jointRecoveredRootReceiptPath']).read_bytes())
    post=json.loads(Path(packet['jointPostauditPath']).read_bytes())
    assert recovered['sessionId']==67481 and recovered['toolExitCode'] is None and recovered['terminalRecoveredFromCompleteGuardPostaudit'] is True
    assert recovered['receipt']==post and recovered['postauditSha256']==sha(packet['jointPostauditPath'])
    execution=post['execution'];assert recovered['actualChildExitCode']==execution['exitCode']==0
    assert post['sourceAndArtifactsHeld'] is True and post['dependenciesBefore']==post['dependenciesAfter'] and post['diagnosticTrustEligible'] is True
    assert execution['endedAt'] and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values()) and not scope.owned(execution['pgid'])
    assert post['wholeLocalFanoutsSha256']==packet['jointGeometrySha256']==sha(packet['jointGeometryPath'])
    old=json.loads(Path(packet['closedPublicRootReceiptPath']).read_bytes());assert old['sessionId']==78137 and type(old['toolExitCode']) is int and old['sourceAndDependenciesHeld'] is True
    assert old['execution']['cleanupOwnedGroupEmpty'] and not any(old['execution']['oomDelta'].values()) and not scope.owned(old['execution']['pgid'])
    return packet,hashlib.sha256(raw).hexdigest(),scope
def dependencies():
    verifier=module('grid_phase_trusted_dependencies',BASE/'verify-installed-dependencies.py')
    result=verifier.verify(BASE/'dependencies/archive-receipt.json','1a49a60909258b542c7f4899e6378fa9f10c1cea08ef1aaf4b5366480dbf71b7',BASE/'audit-installed-dependencies.py')
    assert result['treeSha256']=='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
    return result
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--preflight-only',action='store_true');parser.add_argument('--run',action='store_true');parser.add_argument('--root-receipt');parser.add_argument('--root-receipt-sha256');args=parser.parse_args()
    packet,packet_sha,scope=verify()
    if args.preflight_only: print(json.dumps({'preflightPassed':True,'packetSha256':packet_sha,'sourceOnly':True,'workerStarted':False}));return 0
    assert args.run and args.root_receipt and args.root_receipt_sha256
    auth=json.loads(Path(args.root_receipt).read_bytes())
    assert sha(args.root_receipt)==args.root_receipt_sha256 and auth['authorizedByRoot'] is True and auth['scope']==packet['scope'] and auth['packetSha256']==packet_sha and auth['policy']==POLICY and re.fullmatch('[0-9a-f]{32,128}',auth['approvalToken'])
    assert auth['interveningWorkersCollected'] is True,'Root must collect any later metadata/full-suite scopes before launch'
    assert not (ROOT/'run').exists()
    before=dependencies();baseline=scope.memory()
    def gate(now):
        assert now['current']+POLICY['rssBytes']+RESERVE<POLICY['sharedBytes'],'Strict prefork reserve required'
        assert all(now['events'][key]==baseline['events'][key] for key in scope.OOM_KEYS)
    execution=scope.run_guarded([BUN,'--smol',str(ROOT/'diagnose.ts'),'--run-one-approved'],ROOT,ROOT/'run',POLICY,{'G350_GRID_PHASE_APPROVED':'1','G350_GRID_PHASE_AUTH_PATH':str(Path(args.root_receipt).resolve()),'G350_GRID_PHASE_AUTH_SHA':args.root_receipt_sha256},before_spawn=gate)
    verify();after=dependencies();assert before==after
    result_path=ROOT/'run/result.json';result=json.loads(result_path.read_bytes()) if result_path.is_file() else None
    clean=execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values())
    valid=clean and result is not None and result['fixtureGridCalls']==4 and result['sceneInputUnchanged'] is True and result['productionIntegrationApplied'] is False and result['defaultOff'] is True
    receipt={'execution':execution,'dependenciesBefore':before,'dependenciesAfter':after,'sourceAndArtifactsHeld':True,'packetSha256':packet_sha,'resultSha256':sha(result_path) if result else None,'diagnosticTrustEligible':valid,'accepted49':False,'fabricationReady':False,'physicalAcceptanceClaimed':False}
    (ROOT/'EXECUTION-postaudit.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'diagnosticTrustEligible':valid,'resultSha256':receipt['resultSha256'],'accepted49':False}));return 0 if valid else 2
if __name__=='__main__':raise SystemExit(main())
