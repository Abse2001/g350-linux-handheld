 def closed66():
  prior=closed65();assert prior['actualClosedScopeCount']==65
  for key in('actual66FailedCollectionPin','actual66PostauditPin','actual66CapturePhasePostPin','actual66TypesPhasePostPin','actual66TypesChildLogPin','actual66FailedGuardManifestPin','actual66FailedSourceManifestPin','actual66FailedCaptureWorkerPin','actual66FailedTypesWorkerPin','actual66CaptureOutputPin','actual66CaptureDiagnosticPin'):binding(proposal[key])
  r=read(proposal['actual66FailedCollectionPin']['path']);p=read(proposal['actual66PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==28922 and r['toolExitCode']==r['toolWrapperExitCode']==2
  assert r['postauditPath']==proposal['actual66PostauditPin']['path']and r['postauditSha256']==proposal['actual66PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['toolSessionCollected']is False
  for key,value in p.items():
   if key!='toolSessionCollected':assert r[key]==value,'Failed66 Root receipt preserves its saved POST: '+key
  for doc in(r,p):
   assert doc['scope']=='ROOT_SOURCE32_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH65_AUTHENTIC_PRIOR_CLOSURES'and doc['phase']=='capture-types-core-batch'and doc['sourceManifestSha256']==proposal['actual66FailedSourceManifestPin']['sha256']and doc['rootGuardProposalManifestSha256']==proposal['actual66FailedGuardManifestPin']['sha256']
   assert doc['orderedPhaseNames']==['capture','types']and doc['expectedPhaseNames']==['capture','types','core']and doc['notAttemptedPhaseNames']==['core']and len(doc['phases'])==2
   for key in('historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passedMeansCaptureStrictTypesAndRawCore32Only','batchScopeContainsThreeSerialOwnedChildren','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   assert doc['allThreeChildrenNaturallyCompleted']is doc['passed']is False and doc['batchFailure']=='Phase types failed; later phases not attempted'and doc['finalVerificationFailure']is None
   assert doc['captureChildInvocations']==doc['typesChildInvocations']==1 and all(doc[key]==0 for key in('CoreCalls','CoreChildInvocations','nativeCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'))
   for key in('Source32Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  assert p['sameGuardIdentity']['pid']==520581
  for i,(name,post_key,pid,exit_code)in enumerate([('capture','actual66CapturePhasePostPin',520701,0),('types','actual66TypesPhasePostPin',520783,2)]):
   row=p['phases'][i];assert row['phase']==name and row['postauditPath']==proposal[post_key]['path']and row['postauditSha256']==proposal[post_key]['sha256']and read(row['postauditPath'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   assert row['sourceAndDependenciesHeld']is row['ownedGroupEmptyActuallyObserved']is row['stageNaturallyCompleted']is True and row['ownedChildNatural0']is row['passed']is(i==0)
   assert row['runFailure']is row['postverificationFailure']is row['outputBindingFailure']is None
   assert row['resultInspectionFailure']==(None if i==0 else 'AssertionError: ')
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['guardIdentityBefore']==row['guardIdentityAfter']==p['sameGuardIdentity']and all(row[k]==0 for k in('CoreCalls','CoreChildInvocations','nativeCalls','originalApiCalls','cliCalls','cadCalls'))
   e=row['execution'];assert e['pid']==e['pgid']==pid and e['currentGuardPid']==520581 and e['exitCode']==exit_code and e['diagnosticStopped']is False and e['stopReasons']==[]and e['cleanupOwnedGroupEmpty']is True
   assert e['policy']=={'wallSeconds':60 if i==0 else 120,'rssBytes':1073741824 if i==0 else 2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}and e['signalErrors']==[]and e['signalErrorCount']==0 and e['oomDelta']and all(v==0 for v in e['oomDelta'].values())and e['endedAt']>=e['startedAt']
   assert e['command']==row['command']and e['freshLeaderIdentity']['pid']==e['freshLeaderIdentity']['pgid']==e['freshLeaderIdentity']['sid']==pid and e['freshLeaderIdentity']['argv']==e['command']
   assert c.guard.process_scope.owned(pid)==[]
  capture,types=p['phases'];assert capture['execution']['endedAt']<=types['execution']['startedAt']and not Path('/proc/520581').exists()
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is r['capturePassedTypesNatural2CoreUnattempted']is True and r['independentlyObservedOwnedGroupMembers']=={'520701':[],'520783':[]}and r['independentProcReadErrors']==[]and r['currentCheckedConnections']==29 and r['currentMissingConnections']==20 and r['partialAdoptionPerformedByThisCollection']is False
  base66=Path(proposal['actual66PostauditPin']['path']).parent
  assert capture['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',proposal['actual66FailedCaptureWorkerPin']['path'],str(base66/'capture/output/source-capture.json'),str(base66/'capture/output/source-tree-diagnostic.json')]
  assert types['command']==['bash',proposal['actual66FailedTypesWorkerPin']['path']]and types['result']is None and types['outputFiles']==[]
  assert capture['outputFiles']==[proposal['actual66CaptureOutputPin'],proposal['actual66CaptureDiagnosticPin']]
  assert capture['result']==inspect32_capture({'capture':Path(proposal['actual66CaptureOutputPin']['path']),'diagnostic':Path(proposal['actual66CaptureDiagnosticPin']['path'])})
  log=Path(proposal['actual66TypesChildLogPin']['path']).read_text();assert log.count("error TS2550: Property 'hasOwn' does not exist on type 'ObjectConstructor'.")==4 and log.count(': error TS')==4
  assert re.findall(r'source32[.]circuit[.]tsx[(](77|78),[0-9]+[)]: error TS2550:',log)==['77','77','78','78']
  prior['actual66Source32CapturePassTypesEs2020FailedCollectionPin']={k:proposal['actual66FailedCollectionPin'][k]for k in('path','sha256')}
  prior['actual66CapturePassDoesNotQualifyChangedSourceOrUnattemptedCore']=True
  prior['actual66TypesNatural2ExactlyFourObjectHasOwnTs2550NoCompilerRelaxation']=True
  prior['actual66SourceSdkGitAndOriginalFloorHeldWithoutRelabelingTypesFailure']=True
  prior['actualClosedScopeCount']=66
  return prior

