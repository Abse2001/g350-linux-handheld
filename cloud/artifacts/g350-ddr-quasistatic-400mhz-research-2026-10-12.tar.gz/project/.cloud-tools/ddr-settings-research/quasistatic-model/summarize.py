#!/usr/bin/env python3
"""Summarize already executed local jobs without solving or changing board data."""
from pathlib import Path
import hashlib
import json
import math
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
RAW = HERE / "raw"


def read(key):
    return json.loads((RAW / (key + ".json")).read_text())


def binding(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(HERE)), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


controls = read("controls-v3")
assert controls["passed"]
model_hash = hashlib.sha256((HERE / "model.py").read_bytes()).hexdigest()
jobs, cases = [], []
for stack in ["3313", "1080"]:
    for kind in ["single", "pair"]:
        prefix = f"{stack}-{kind}"
        meshes = [read(f"{prefix}-offset-{step}um-box1") for step in [4, 2, 1]]
        fine, coarse = meshes[-1], meshes[-2]
        domain = read(f"{prefix}-offset-1um-box2")
        alternate = read(f"{prefix}-stepped-1um-box1")
        alternate_coarse = read(f"{prefix}-stepped-2um-box1")
        key_list = [f"{prefix}-offset-{step}um-box1" for step in [4, 2, 1]]
        key_list += [f"{prefix}-offset-1um-box2",
                     f"{prefix}-stepped-2um-box1", f"{prefix}-stepped-1um-box1"]
        for key in key_list:
            case, execution = read(key), read(key + "-execution")
            assert case["sourceBinding"]["sha256"] == model_hash
            assert execution["modelSha256"] == model_hash
            assert execution["actualExitCode"] == 0 and execution["resourceStop"] is None
            assert execution["wallSeconds"] <= 60 and execution["sampledPeakOwnedRssBytes"] <= 1024 ** 3
            assert execution["oomEventDelta"].get("oom_kill", 0) == 0
            assert case["actual"]["relativeEquationResidual"] < 1e-8
            assert case["actual"]["relativeEnergyChargeMismatch"] < 1e-8
            if kind == "pair":
                assert case["relativeChargeOddSymmetryError"] < 1e-8
                assert case["relativeDiffChargeEnergyError"] < 1e-8
            jobs.append({"key": key, "output": binding(RAW / (key + ".json")),
                         "execution": binding(RAW / (key + "-execution.json")),
                         "actualExitCode": execution["actualExitCode"],
                         "wallSeconds": execution["wallSeconds"],
                         "sampledPeakOwnedRssBytes": execution["sampledPeakOwnedRssBytes"]})
        cases.append({
            "stackup": "JLC04161H-" + stack, "kind": kind,
            "meshRefinements": [{"stepUm": row["dimensions"]["nominalFineStepUm"],
                                 "impedanceOhm": row["impedanceOhm"],
                                 "effectiveEr": row["effectiveEr"],
                                 "phaseDelayPsPerMm": row["phaseDelayPsPerMmQuasistatic"]}
                                for row in meshes],
            "lastMeshDeltaOhm": abs(fine["impedanceOhm"] - coarse["impedanceOhm"]),
            "lastMeshDeltaPercent": 100 * abs(fine["impedanceOhm"] / coarse["impedanceOhm"] - 1),
            "threeMeshImpedanceSpreadOhm": max(row["impedanceOhm"] for row in meshes)
                                          - min(row["impedanceOhm"] for row in meshes),
            "offsetMask1umSmallBoxImpedanceOhm": fine["impedanceOhm"],
            "offsetMask1umDoubledBoxImpedanceOhm": domain["impedanceOhm"],
            "boxDoublingDeltaOhm": abs(domain["impedanceOhm"] - fine["impedanceOhm"]),
            "boxDoublingDeltaPercent": 100 * abs(domain["impedanceOhm"] / fine["impedanceOhm"] - 1),
            "steppedMask1umSmallBoxImpedanceOhm": alternate["impedanceOhm"],
            "steppedMaskLastMeshDeltaOhm": abs(alternate["impedanceOhm"] - alternate_coarse["impedanceOhm"]),
            "maskProfileDeltaAt1umOhm": abs(alternate["impedanceOhm"] - fine["impedanceOhm"]),
            "doubledBoxEffectiveEr": domain["effectiveEr"],
            "doubledBoxQuasistaticPhaseDelayPsPerMm": domain["phaseDelayPsPerMmQuasistatic"],
            "deltaIsNotARigorousContinuumOrManufacturingErrorBound": True,
        })

ratios = []
for stack in ["3313", "1080"]:
    single = next(row for row in cases if row["stackup"].endswith(stack) and row["kind"] == "single")
    pair = next(row for row in cases if row["stackup"].endswith(stack) and row["kind"] == "pair")
    zs = single["offsetMask1umDoubledBoxImpedanceOhm"]
    zd = pair["offsetMask1umDoubledBoxImpedanceOhm"]
    ratios.append({"stackup": "JLC04161H-" + stack, "isolatedSingleOhm": zs,
                   "differentialOhm": zd, "differentialOverTwiceIsolatedSingle": zd / (2 * zs),
                   "differenceFromTwiceIsolatedSinglePercent": 100 * (zd / (2 * zs) - 1),
                   "noTiDifferentialToleranceOrPassFailInvented": True})

inputs = controls["inputBindings"]
assert all(hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest() == row["sha256"]
           for row in inputs)
report = {
    "schemaVersion": 1, "createdUtc": datetime.now(timezone.utc).isoformat(),
    "purpose": "Independent bounded local quasi-static cross-section estimates; not JLC calculator output or manufacturing qualification",
    "method": {
        "equation": "div(epsilon grad(V))=0; Cartesian nonuniform finite-volume nodal discretization",
        "conductor": "Perfect trapezoidal conductor: lower width.1016mm, upper.0889mm, thickness.04064mm. Pair lower-edge gap.12mm; no geometry setting changed.",
        "dielectricFaces": "Harmonic endpoint dielectric coefficients; metal interface uses exterior dielectric only. Endpoint material transition is midpoint-approximated; series-interface refinement quantifies this grid error.",
        "metalBoundary": "Metal boundary is represented by fixed potential nodes inside/on polygon, with finite-volume face length divided by node separation. Exact critical flat boundaries are included; sloped sidewalls have stair-step grid error, assessed by refinement.",
        "energy": "2U per unit length = epsilon0 sum(each face once)[g*(deltaV)^2], g=relativeepsilon*dualfaceLength/nodeDistance",
        "single": "Signal1V, reference/boundaries0V: C=2U. All-air solve identical geometry/domain/mesh gives C0; Z=1/(c sqrt(C C0)); effectiveEr=C/C0.",
        "pair": "Symmetric pair±.5V, Vdiff1: Cdiff=2U=Qpositive. Zdiff=1/(c sqrt(Cdiff C0diff)); Codd=2Cdiff, Zodd=Zdiff/2. Independent capacitance-matrix excitation confirms normalization.",
        "outerBoundary": "Adjacent infinite reference plane approximated by ground y0 and distant grounded side/top boundaries. Small box±1.2mm/height.9mm doubled to±2.4mm/1.8mm. These finite-box changes are not absolute error bounds.",
        "maskProfiles": "Both use C1/C3.0254mm above substrate/in gap and C2.01524mm above copper, Er3.8. Offset profile unions basecoat with C2-distance offset around conductor; stepped profile raises mask over lower-width footprint. Sidewall/meniscus shape is an explicit sensitivity assumption, not specified by retained JLC parameter descriptions.",
        "modelSymmetry": "Both outer layers estimated equivalently because retained stackups are symmetric; actual full-board reference continuity and return transfer were not analyzed.",
    },
    "controls": {
        "outputBinding": binding(RAW / "controls-v3.json"),
        "executionBinding": binding(RAW / "controls-v3-execution.json"),
        "passedInternalControls": controls["passed"],
        "parallelPlateRelativeError": controls["parallelPlate"]["relativeError"],
        "homogeneousErScalingRelativeError": controls["homogeneousErScalingRelativeError"],
        "differentialCapacitanceMatrixNormalizationRelativeError": controls["differentialCapacitanceMatrixNormalizationRelativeError"],
        "twoLayerSeriesControlRelativeErrors": [{"stepUm": row["stepUm"], "error": row["relativeError"]}
                                                for row in controls["dielectricInterfaceSeriesCapacitorRefinements"]],
        "seriesControlIncludesUnphysicalInteriorMetalEr123": True,
        "microstripApproximation": controls["microstripAnalytic"],
        "finestMicrostripRelativeImpedanceError": controls["microstripFinestRelativeErrorAgainstApproximation"],
        "analyticApproximationIsNotExactReferenceOrManufacturerCalibration": True,
    },
    "cases": cases, "couplingRatios": ratios,
    "interpretation": [
        "The numerical model estimates both isolated single-ended impedances in TI50–75Ω nominal range. This is not each-segment±5Ω or production tolerance qualification.",
        "On unchanged width/gap, estimated differential impedance is about19.3%/15.3% below twice the corresponding isolated single impedance for3313/1080. The effect is much greater than observed mesh/boundary/mask deltas, so nominal2Zo cannot be inferred from physicalclearance/matching alone. Cross-check with a trusted independent field model before any geometry change; no TI differential pass/fail tolerance is invented.",
        "No exact stackup, width, gap or impedance target is selected by this work. A future hardware change needs explicit source changes and fresh complete routing/manufacturing/timing checks. Current solver geometric constraints remain unchanged.",
        "Quasistatic phase-delay estimates do not establish frequency-dependent group delay, package/via delay, return behavior, crosstalk, slew, jitter or400MHz setup/hold margin.",
    ],
    "limitations": [
        "Mesh values are not monotonically convergent due to stair-step sidewalls/material interfaces; no Richardson extrapolation or rigorous error bar is claimed.",
        "Convergence and controls assess this ideal electrostatic model only; they do not validate the actual mask profile, material dispersion/anisotropy, etched/plated trace shape, manufacturing variation or fixedtrace neighborhood.",
        "Copper is perfect/lossless; no resistive skin effect, dielectric loss, frequency dispersion, radiation,3Dvia/package/stub geometry or reference-plane cuts are modeled.",
        "Installed versions assertedPython3.12.14/NumPy2.3.5/SciPy1.17.0; recorded package file hashes verified independently without installation.",
        "History-v0 controls predate the metal-exterior coefficient correction and are superseded; controls-v1/v2 predate the final series-interface refinement. Raw historical results are preserved, not qualification evidence.",
    ],
    "runtimePackageAudit": binding(HERE / "runtime-package-audit.json"),
    "inputBindings": inputs, "inputsUnchanged": True,
    "modelBinding": binding(HERE / "model.py"), "guardBinding": binding(HERE / "run-job.py"),
    "jobs": jobs, "nominalAndSensitivityJobCount": len(jobs),
    "allActualExitCodesZero": True,
    "maximumSampledOwnedRssBytes": max(row["sampledPeakOwnedRssBytes"] for row in jobs),
    "maximumJobWallSeconds": max(row["wallSeconds"] for row in jobs),
    "jobsRanSequentially": True, "singleBlasThread": True,
    "networkRequests": 0, "boardOrFirmwareChanges": 0,
    "routingJobs": 0, "nativeOrCadChecks": 0,
    "impedanceQualified": False, "electricalTimingPassed": False,
    "accepted49": False, "fabricationReady": False,
}
(HERE / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"reportSha256": hashlib.sha256((HERE / "report.json").read_bytes()).hexdigest(),
                  "jobs": len(jobs), "couplingRatios": ratios,
                  "maximumRss": report["maximumSampledOwnedRssBytes"]}))
