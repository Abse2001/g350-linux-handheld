import { routeCoupledPair } from "./coupled"
import { runBoundedRouting } from "./bounded"
export const plannerExtra = Symbol("planner original export")
export function* planSharedPairCorridors(
  input: any,
  _layers: unknown,
  _fresh?: boolean,
  options?: unknown,
): Generator<unknown> {
  const tuple = yield* runBoundedRouting(
    routeCoupledPair(input, input.differentialPairs[0], [], options),
    6000,
  )
  if (tuple) yield tuple
}
