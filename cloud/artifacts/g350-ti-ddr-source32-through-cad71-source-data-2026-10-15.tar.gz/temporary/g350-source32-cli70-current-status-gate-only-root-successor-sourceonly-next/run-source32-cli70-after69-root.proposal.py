"""Root-only Source32 batch65 conditional recipe over authentic63; no operational evaluation by author."""
"""Root-only Source29 CLI56 after authentic Native54/API55; Source-only author never evaluates operational code."""
"""Root-only Source29 API55 two-child controller after authentic Native54; author never evaluates operational code."""
"""Root-only Source29 Native54 template after authentic three-child batch53; unset actual53 gates refuse before operational imports."""
"""Root-only Source29 serial capture/types/Core template; NULL future52/promotion gates refuse before operational imports."""
"""Root-only Source26 fresh offline CAD after authentic CLI51; future exact flat-file wrapper pins refuse this draft."""
"""Root-only Source24 first capture; author performs Source-only construction, never evaluation."""
"""Root-only changed-order direct-compact clock diagnostic; author never evaluates it."""
"""Root-only proposal. Author never imports or executes this guard or SDK."""
import fcntl, hashlib, importlib.util, json, os, re, secrets, shutil, stat, sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
PACKET=Path(__file__).resolve().parent
POLICIES = {'full644': {'wallSeconds':360,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}, 'optout9': {'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}}

def read(path): return json.loads(Path(path).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def binding(row):
 p=Path(row['path']);s=p.lstat();assert not p.is_symlink() and stat.S_ISREG(s.st_mode) and sha(p)==row['sha256'] and s.st_size==row['bytes'] and stat.S_IMODE(s.st_mode)==row['mode']
def rows(value):
 if isinstance(value,dict):
  if all(k in value for k in ('path','sha256','bytes','mode')): yield value
  else:
   for v in value.values(): yield from rows(v)
 elif isinstance(value,list):
  for v in value: yield from rows(v)
def write(path,value):
 with path.open('x') as f: json.dump(value,f,indent=2);f.write('\n')
 path.chmod(0o600)
def counts(log):
 found={k:re.findall(r'^\s*(\d+) '+k+r'\s*$',log,re.M) for k in ('pass','fail')}
 return {k:int(v[0]) for k,v in found.items()} if all(len(v)==1 for v in found.values()) else None
def no_git_redirects():
 exact={'GIT_DIR','GIT_WORK_TREE','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_NAMESPACE','GIT_REPLACE_REF_BASE','GIT_CONFIG','GIT_CONFIG_COUNT'}
 assert not any(k in exact or k.startswith(('GIT_CONFIG_KEY_','GIT_CONFIG_VALUE_')) for k in os.environ)
def git_inventory():
 root=Path('/workspace/bus-lanes-solver/.git')
 result=[]
 for p in sorted(root.rglob('*')):
  if 'objects' in p.relative_to(root).parts:continue
  assert not p.is_symlink(), 'Real Git metadata must not contain symlink entries'
  if p.is_file():
   s=p.lstat();assert stat.S_ISREG(s.st_mode)
   result.append(dict(path=str(p),sha256=sha(p),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode)))
 return result

import secrets
def closed_through31(c,h,gm,m,bindings,context14_path):
 h.failed_original_eleven()
 context,rows=h.root_current_closed_rows(context14_path);assert len(rows)==14
 bindings();r=c.read(gm['actual24184RawReceiptPin']['path']);q=c.read(gm['actual24184FreshSupplementPin']['path'])
 assert r['scope']=='ROOT_RAW_CURRENT_CORE49_RESULT_AND_DUPLICATE_SCOPE_REFUSAL_COLLECTION' and r['toolSessionCollected']is True
 assert r['observedToolWrapperExitCode']==1 and r['observedToolWrapperRefusedExistingRunDirectory']is True
 assert r['firstGuardToolWrapperExitUnknown']is True and r['firstGuardToolWrapperExitCode']is None and r['naturalOwnedSdkChildExitCode']==1
 assert r['originalStepCalls']==21732 and r['actualUniqueGeneratedCarrierCount']==0 and r['failureCode']=='no_planar_route' and r['passed']is False
 assert c.sha(r['postauditPath'])==r['postauditSha256'];p=c.read(r['postauditPath']);assert p['execution']==r['execution'] and p['sourceAndDependenciesHeld']is True
 h.held_inventory_post(p);h.finite(r['execution'],1)
 assert r['execution']['pgid']==452553 and c.guard.process_scope.owned(452553)==[] and not Path('/proc/452548').exists()
 assert q['rawReceiptSha256']==gm['actual24184RawReceiptPin']['sha256'] and q['rawPostauditSha256']==r['postauditSha256']
 assert q['ownedSdkGroupEmpty']is True and q['recordedFirstGuardAbsent']is True and q['firstToolWrapperExitStillUnknown']is True and q['allCurrentCallerGuardSourceBindingsHeld']is True
 assert q['freshBoardSdk']['treeSha256']==m['boardSdkTreeSha256'] and q['freshSolverSdk']['treeSha256']==gm['solverSdkTreeSha256']
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 # Older recorded Source/Core/native/CLI/CAD/render scopes stay independently empty.
 prior=c.read(c.BOARD/'.cloud-tools/ddr-strict18-smooth-fresh-kicad-sourceonly-next/run-cad/ROOT_AUTHORITY.json')['actualPriorCollectedRows']
 for name in('strict18-smooth-cad-37841-COLLECTED-root.json','context12-buslane-pool-52091-COLLECTED-root.json','context12-reset227-buslane-pool-62531-COLLECTED-root.json'):
  prior.append({'path':str(ROOT/name),'sha256':c.sha(ROOT/name)})
 for r in prior:assert c.guard.process_scope.owned(c.guard.collected(r)[2]['pgid'])==[]
 assert c.guard.process_scope.owned(c.read(ROOT/'smooth18-render-31726-COLLECTED-root.json')['execution']['pgid'])==[]
 pin=gm['actual77568CollectionPin'];u=c.read(pin['path']);p=c.read(u['postauditPath']);v=c.read(gm['actual77568ReportPin']['path'])
 assert u['authorizedByRoot']is True and u['scope']=='ROOT_ONE_FAITHFUL_CURRENT23_ORIGINAL_API_PARTIAL_DIAGNOSTIC' and u['toolSessionId']==77568 and u['toolSessionCollected']is True
 assert u['toolWrapperExitCode']==0 and u['toolExitCode']==0 and u['sourceManifestSha256']==gm['faithfulApiSourcePin']['sha256'] and p['sourceManifestSha256']==u['sourceManifestSha256']
 assert c.sha(u['postauditPath'])==u['postauditSha256']==gm['actual77568PostauditPin']['sha256'] and u['reportSha256']==gm['actual77568ReportPin']['sha256'] and p['resultSha256']==u['reportSha256']
 assert u['execution']==p['execution'] and u['passed']is True and p['passed']is True and u['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True
 h.held_inventory_post(p);h.finite(u['execution'],0);assert u['execution']['pgid']==455504 and c.guard.process_scope.owned(455504)==[]
 assert u['apiDispatchCalls']==100 and p['originalApiDirectCalls']==100 and v['directOriginalApiDispatchCount']==100 and v['actual23RawCarrierCount']==23 and v['all23ContinuousChecksPassed']is True
 assert v['faithfulCurrentInputSha256']==m['initialLayerOnlyInputPin']['sha256'] and v['full49TimingPassed']is False and v['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual97604CollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual97604PostauditPin']['path']);v=c.read(gm['actual97604ObserverPin']['path'])
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_CURRENT631_UNSEEDED_FULL49_PAIR_REJECTION_DIAGNOSTIC' and r['sourceManifestSha256']==gm['callerSourcePin']['sha256'] and r['toolSessionId']==97604 and r['toolSessionCollected']is True
 assert r['toolWrapperExitCode']==2 and r['toolExitCode']==2 and r['passed']is False and r['generationNaturallyCompleted']is True and r['pairObserverCompleted']is True
 assert r['postauditSha256']==gm['actual97604PostauditPin']['sha256'] and c.sha(r['postauditPath'])==r['postauditSha256'] and p['execution']==r['execution'] and p['sourceAndDependenciesHeld']is True
 h.held_inventory_post(p);h.finite(r['execution'],1);assert r['execution']['pgid']==456683 and c.guard.process_scope.owned(456683)==[]
 assert p['ownedGroupEmptyActuallyObserved']is True and p['rootGuardProposalManifestSha256']==gm['parentGuardManifestPin']['sha256'] and p['generationNaturallyCompleted']is True and p['pairObserverCompleted']is True
 assert r['originalStepCalls']==21732 and r['actualUniqueGeneratedCarrierCount']==0 and r['failureCode']=='no_planar_route' and r['fabricationReady']is False
 assert r['pairObserverSha256']==gm['actual97604ObserverPin']['sha256'] and p['pairObserverSha256']==r['pairObserverSha256'] and len(v['rows'])<=12 and gm['actual97604ObserverPin']['bytes']<=65536
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual66744CollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual66744PostauditPin']['path']);v=c.read(gm['actual66744ResultPin']['path'])
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_17_AUTHENTIC_PRIOR_CLOSURES' and r['phase']=='routing' and r['toolSessionId']==66744 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['remaining26CallerSourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==gm['parent18RunnerManifestPin']['sha256'] and r['toolWrapperExitCode']==2 and r['toolExitCode']==2 and r['passed']is False
 assert r['postauditSha256']==gm['actual66744PostauditPin']['sha256'] and c.sha(r['postauditPath'])==r['postauditSha256'] and r['execution']==p['execution'] and r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True
 h.held_inventory_post(p);h.finite(r['execution'],1);assert r['execution']['pgid']==460262 and c.guard.process_scope.owned(460262)==[] and p['ownedGroupEmptyActuallyObserved']is True
 assert r['stageNaturallyCompleted']is True and p['stageNaturallyCompleted']is True and r['originalStepCalls']==v['originalStepCalls']==425 and r['actualUniqueGeneratedCarrierCount']==v['actualUniqueGeneratedCarrierCount']==3 and r['failureCode']==v['failureCode']=='no_planar_route'
 assert r['resultSha256']==p['resultSha256']==gm['actual66744ResultPin']['sha256'] and v['all49Accepted']is False and v['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual3801BaselineCollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual3801BaselinePostauditPin']['path']);log=Path(gm['actual3801BaselineLogPin']['path']).read_text()
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_18_AUTHENTIC_PRIOR_CLOSURES' and r['phase']=='tests' and r['toolSessionId']==3801 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['cornerSourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==gm['parent19RunnerManifestPin']['sha256'] and r['toolWrapperExitCode']==2 and r['toolExitCode']==2 and r['passed']is False
 assert r['postauditSha256']==gm['actual3801BaselinePostauditPin']['sha256'] and c.sha(r['postauditPath'])==r['postauditSha256'] and r['childLogSha256']==gm['actual3801BaselineLogPin']['sha256'] and c.sha(r['childLogPath'])==r['childLogSha256'] and r['execution']==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True and r['stageNaturallyCompleted']is True and p['stageNaturallyCompleted']is True and r['baselineExpectedRedActuallyObserved']is True and p['baselineExpectedRedActuallyObserved']is True
 h.held_inventory_post(p);h.finite(r['execution'],1);assert r['execution']['pgid']==461476 and c.guard.process_scope.owned(461476)==[] and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['actualTestCounts']=={'pass':2,'fail':1,'expect':23} and re.search(r'^\s*2 pass\s*$',log,re.M)and re.search(r'^\s*1 fail\s*$',log,re.M)and re.search(r'^\s*23 expect\(\) calls\s*$',log,re.M)
 witnesses=[json.loads(line)for line in log.splitlines()if line.startswith('{')and '"scope":"FOCUSED_CURRENT631_PAIR_DIAGNOSTIC"'in line];assert len(witnesses)==1 and witnesses[0]==r['exactDiagnosticWitness']
 w=witnesses[0];assert w['inputSha256']=='631ac37009bb602a3a1e67d3ffe7a932669e38ee372d60b29ce196d3c76ddd6d'and w['sourceRoot']=='/workspace/bus-lanes-solver/.cache/paired-layer-fallback-sourceonly-next/lib'and w['naturalGeneratorCompletion']is True and w['originalYieldCount']==5568 and w['returnedCarrierCount']==0 and w['full49Accepted']is False and w['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual86792ResourceCollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual86792ResourcePostauditPin']['path']);log=Path(gm['actual86792ResourceLogPin']['path']).read_text();e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_19_AUTHENTIC_PRIOR_CLOSURES' and r['phase']=='tests' and r['toolSessionId']==86792 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['cornerSourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==gm['parent20RunnerManifestPin']['sha256'] and r['toolWrapperExitCode']==2 and r['toolExitCode']==2
 assert r['postauditSha256']==gm['actual86792ResourcePostauditPin']['sha256'] and c.sha(r['postauditPath'])==r['postauditSha256'] and r['childLogSha256']==gm['actual86792ResourceLogPin']['sha256'] and c.sha(r['childLogPath'])==r['childLogSha256'] and e==p['execution']
 # A resource-stopped scope is closed honestly, never passed through the natural-exit helper.
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p)
 assert e['exitCode']==-15 and e['diagnosticStopped']is True and e['stopReasons']==['OWNED_RSS_STOP'] and e['policy']['rssBytes']==1073741824 and e['peakOwnedRssBytes']==1080479744 and not any(e['oomDelta'].values())
 assert e['cleanupOwnedGroupEmpty']is True and e['pgid']==461945 and c.guard.process_scope.owned(461945)==[] and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['stageNaturallyCompleted']is False and p['stageNaturallyCompleted']is False and r['passed']is False and p['passed']is False and r['actualTestCounts']is None and r['focusedCurrentPairCompletionWitnessPresent']is False
 assert 'FOCUSED_CURRENT631_PAIR_DIAGNOSTIC'not in log and r['resourceStop']=='OWNED_RSS_STOP'and r['all49Accepted']is False and r['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual60763ResourceCollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual60763ResourcePostauditPin']['path']);log=Path(gm['actual60763ResourceLogPin']['path']).read_text();e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_20_AUTHENTIC_PRIOR_CLOSURES' and r['phase']=='tests' and r['toolSessionId']==60763 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['prioritySourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==gm['parent21RunnerManifestPin']['sha256'] and r['toolWrapperExitCode']==2 and r['toolExitCode']==2
 assert r['postauditSha256']==gm['actual60763ResourcePostauditPin']['sha256'] and c.sha(r['postauditPath'])==r['postauditSha256'] and r['childLogSha256']==gm['actual60763ResourceLogPin']['sha256'] and c.sha(r['childLogPath'])==r['childLogSha256'] and e==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p)
 assert e['exitCode']==-15 and e['diagnosticStopped']is True and e['stopReasons']==['OWNED_RSS_STOP']and e['policy']['rssBytes']==1073741824 and e['peakOwnedRssBytes']==1077477376 and not any(e['oomDelta'].values())
 assert e['cleanupOwnedGroupEmpty']is True and e['pgid']==463140 and c.guard.process_scope.owned(463140)==[] and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['stageNaturallyCompleted']is False and p['stageNaturallyCompleted']is False and r['passed']is False and p['passed']is False and r['actualTestCounts']is None and r['focusedCurrentPairCompletionWitnessPresent']is False and 'FOCUSED_CURRENT631_PAIR_DIAGNOSTIC'not in log
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual59592ResourceCollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual59592ResourcePostauditPin']['path']);log=Path(gm['actual59592ResourceLogPin']['path']).read_text();w=c.read(gm['actual59592AllocationWitnessPin']['path']);e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_21_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='tests'and r['toolSessionId']==59592 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['allocationSourcePin']['sha256']and r['rootGuardProposalManifestSha256']==gm['parent24RunnerManifestPin']['sha256']and r['toolWrapperExitCode']==2 and r['toolExitCode']==2
 assert c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual59592ResourcePostauditPin']['sha256']and c.sha(r['childLogPath'])==r['childLogSha256']==gm['actual59592ResourceLogPin']['sha256']and e==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p)
 assert e['exitCode']==-15 and e['diagnosticStopped']is True and e['stopReasons']==['OWNED_RSS_STOP']and e['policy']['rssBytes']==1073741824 and e['peakOwnedRssBytes']==1074499584 and not any(e['oomDelta'].values())
 assert e['cleanupOwnedGroupEmpty']is True and e['pgid']==464228 and c.guard.process_scope.owned(464228)==[]and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['stageNaturallyCompleted']is False and p['stageNaturallyCompleted']is False and r['passed']is False and p['passed']is False and r['actualTestCounts']is None and r['focusedCurrentPairCompletionWitnessPresent']is False and 'FOCUSED_CURRENT631_PAIR_DIAGNOSTIC'not in log
 assert r['allocationDiagnosticEvidenceAvailable']is True and p['allocationDiagnosticEvidenceAvailable']is True and r['allocationWitnessSha256']==p['allocationWitnessSha256']==gm['actual59592AllocationWitnessPin']['sha256']and r['allocationWitnessBytes']==5561 and w['observedEvents']==3629 and len(w['events'])==8 and w['full49Accepted']is False and w['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 for spec in gm['source14ObservedClosedRows']:
  r=c.read(spec['receiptPin']['path']);p=c.read(spec['postPin']['path']);v=c.read(spec['resultPin']['path']);e=r['execution']
  assert r['authorizedByRoot']is True and r['scope']==spec['scope']and r['phase']=='routing'and r['toolSessionId']==spec['toolSessionId']and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['sourceManifestSha256']==spec['sourceManifestSha256']and c.sha(r['postauditPath'])==r['postauditSha256']==spec['postPin']['sha256']and r['resultSha256']==p['resultSha256']==spec['resultPin']['sha256']and e==p['execution']
  assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p);h.finite(e,0)
  assert e['pgid']==spec['pgid']and c.guard.process_scope.owned(spec['pgid'])==[]and r['independentlyObservedOwnedGroupEmpty']is True and p['ownedGroupEmptyActuallyObserved']is True
  assert r['diagnosticCompleted']is True and p['diagnosticCompleted']is True and r['passed']is True and p['passed']is True and r['originalGridSolvedCandidate']is False and r['candidateTotalPlanarWithinWindow']is False
  assert v['diagnosticCompleted']is True and v['termination']=='NATURAL_FAILED'and v['originalStepCalls']==0 and v['terminalBeforeCancel']=={'expanded':0,'solved':False,'failed':True}and v['candidatePath']is None and v['totalPlanarWithinWindow']is False and v['sourceNativeCheckedCountRemains23']is True and v['all49Accepted']is False and v['fabricationReady']is False
  if spec['toolSessionId']==42702:assert v['constructorFailureReason']=='REACHABILITY_COMPONENT_REJECTION'and v['constructorAttachments']=={'starts':8,'ends':8,'cellCount':1413721}
  for f in p['outputFiles']:c.guard.source_guard.binding(f)
 pin=gm['actual24627ResourceCollectionPin'];r=c.read(pin['path']);p=c.read(gm['actual24627ResourcePostauditPin']['path']);log=Path(gm['actual24627ResourceLogPin']['path']).read_text();w=c.read(gm['actual24627AllocationWitnessPin']['path']);e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_24_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='tests'and r['toolSessionId']==24627 and r['toolSessionCollected']is True
 assert r['sourceManifestSha256']==gm['stampReuseSourcePin']['sha256']and r['rootGuardProposalManifestSha256']==gm['parent26RunnerManifestPin']['sha256']and r['toolWrapperExitCode']==r['toolExitCode']==2
 assert c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual24627ResourcePostauditPin']['sha256']and c.sha(r['childLogPath'])==r['childLogSha256']==gm['actual24627ResourceLogPin']['sha256']and e==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p)
 assert e['exitCode']==-15 and e['diagnosticStopped']is True and e['stopReasons']==['OWNED_RSS_STOP']and e['policy']['rssBytes']==1073741824 and not any(e['oomDelta'].values())and e['cleanupOwnedGroupEmpty']is True
 assert e['pgid']==465869 and c.guard.process_scope.owned(465869)==[]and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['stageNaturallyCompleted']is False and p['stageNaturallyCompleted']is False and r['passed']is False and p['passed']is False and r['actualTestCounts']is None and r['focusedCurrentPairCompletionWitnessPresent']is False and 'FOCUSED_CURRENT631_PAIR_DIAGNOSTIC'not in log
 assert r['allocationDiagnosticEvidenceAvailable']is True and p['allocationDiagnosticEvidenceAvailable']is True and r['allocationWitnessSha256']==p['allocationWitnessSha256']==gm['actual24627AllocationWitnessPin']['sha256']and w['observedEvents']==3733 and len(w['events'])==8 and w['full49Accepted']is False and w['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 r=c.read(gm['actual59892CollectionPin']['path']);p=c.read(gm['actual59892PostauditPin']['path']);v=c.read(gm['actual59892ResultPin']['path']);e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_25_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='routing'and r['toolSessionId']==59892 and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==0
 assert r['sourceManifestSha256']=='251c339a040a43ec0c5dcfb428157e37cdd2ecc07d7de134a505e932c4bf237b'and c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual59892PostauditPin']['sha256']and r['resultSha256']==p['resultSha256']==gm['actual59892ResultPin']['sha256']and e==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p);h.finite(e,0)
 assert e['pgid']==466570 and c.guard.process_scope.owned(466570)==[]and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['diagnosticCompleted']is True and p['diagnosticCompleted']is True and r['passed']is True and p['passed']is True and r['originalGridSolvedCandidate']is False and r['candidateTotalPlanarWithinWindow']is False
 assert v['diagnosticCompleted']is True and v['termination']=='ALL_REMAINING_LAYERS_TESTED'and v['attemptedLayers']==['top','inner2','bottom']and v['originalGridConstructorCalls']==3 and v['totalExpanded']==383387 and len(v['rows'])==3 and all(x['termination']=='NATURAL_FAILED'and x['terminalBeforeCancel']['solved']is False and x['totalPlanarWithinWindow']is False for x in v['rows'])and v['all49Accepted']is False and v['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 r=c.read(gm['actual60822CollectionPin']['path']);p=c.read(gm['actual60822PostauditPin']['path']);log=Path(gm['actual60822LogPin']['path']).read_text();w=c.read(gm['actual60822AllocationWitnessPin']['path']);e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_26_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='tests'and r['toolSessionId']==60822 and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==2
 assert r['sourceManifestSha256']==gm['scratchCapacitySourcePin']['sha256']and c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual60822PostauditPin']['sha256']and c.sha(r['childLogPath'])==r['childLogSha256']==gm['actual60822LogPin']['sha256']and e==p['execution']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p);h.finite(e,1)
 assert e['pgid']==468148 and c.guard.process_scope.owned(468148)==[]and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
 assert r['stageNaturallyCompleted']is True and p['stageNaturallyCompleted']is True and r['testSuiteCompleted']is True and r['passed']is False and p['passed']is False and r['actualTestCounts']=={'pass':6,'fail':1,'expect':3865}and r['observedEarlyNamedPassCount']==6
 rows27=[json.loads(line)for line in log.splitlines()if line.startswith('{')and '"scope":"FOCUSED_CURRENT631_PAIR_DIAGNOSTIC"'in line];assert len(rows27)==1 and rows27[0]==r['focusedCurrentPairWitness']
 witness27=rows27[0];assert witness27['inputSha256']=='631ac37009bb602a3a1e67d3ffe7a932669e38ee372d60b29ce196d3c76ddd6d'and witness27['sourceRoot']=='/workspace/bus-lanes-solver/.cache/paired-grid-scratch-capacity-reuse-sourceonly-next/lib'and witness27['naturalGeneratorCompletion']is False and witness27['originalYieldCount']==40000 and witness27['returnedCarrierCount']==0 and witness27['full49Accepted']is False and witness27['fabricationReady']is False
 assert r['originalPairGeneratorNaturallyCompleted']is False and r['originalPairGeneratorYieldCapReached']is True and r['originalPairReturnedCarrierCount']==0 and r['allocationDiagnosticEvidenceAvailable']is True and p['allocationDiagnosticEvidenceAvailable']is True
 assert r['allocationWitnessSha256']==p['allocationWitnessSha256']==gm['actual60822AllocationWitnessPin']['sha256']and w['observedEvents']==3795 and len(w['events'])==8 and w['full49Accepted']is False and w['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 for spec29 in gm['actualOwned156ClosedRows']:
  r=c.read(spec29['receiptPin']['path']);p=c.read(spec29['postPin']['path']);v=c.read(spec29['resultPin']['path']);e=r['execution']
  assert r['authorizedByRoot']is True and r['scope']==spec29['scope']and r['phase']=='routing'and r['toolSessionId']==spec29['toolSessionId']and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['sourceManifestSha256']==spec29['sourcePin']['sha256']and p['sourceManifestSha256']==r['sourceManifestSha256']and c.sha(r['postauditPath'])==r['postauditSha256']==spec29['postPin']['sha256']and r['resultSha256']==p['resultSha256']==spec29['resultPin']['sha256']and e==p['execution']
  assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p);h.finite(e,0)
  assert e['pgid']==spec29['pgid']and c.guard.process_scope.owned(spec29['pgid'])==[]and p['ownedGroupEmptyActuallyObserved']is True and r['independentlyObservedOwnedGroupEmpty']is True
  assert r['diagnosticCompleted']is True and p['diagnosticCompleted']is True and r['passed']is True and p['passed']is True and r['originalGridSolvedCandidate']is False and r['candidateTotalPlanarWithinWindow']is False and r['newRoutesAdopted']==0 and r['sourceNativeCheckedCount']==23
  assert v['diagnosticCompleted']is True and v['candidatePath']is None and v['winningLayer']is None and v['faithfulFull49InputSha256']=='631ac37009bb602a3a1e67d3ffe7a932669e38ee372d60b29ce196d3c76ddd6d'and v['all23BodiesRemainFixed']is True and v['all285OtherTracesAndAll1298ObstaclesAndAll23BodiesHeld']is True and v['sourceNativeCheckedCountRemains23']is True and v['all49Accepted']is False and v['fabricationReady']is False
  if spec29['toolSessionId']==88558:
   assert v['termination']=='SHARED_EXPANSION_CAP'and v['totalExpanded']==399999 and v['attemptedLayers']==['inner2','bottom']and v['originalStepCalls']==800 and len(v['rows'])==2
   assert v['rows'][0]['termination']=='NATURAL_FAILED'and v['rows'][0]['terminalBeforeCancel']=={'expanded':0,'solved':False,'failed':True}
   assert v['rows'][1]['termination']=='SHARED_EXPANSION_CAP'and v['rows'][1]['terminalBeforeCancel']=={'expanded':399999,'solved':False,'failed':False}
  else:
   assert spec29['toolSessionId']==32392 and v['termination']=='ALL_REMAINING_LAYERS_TESTED'and v['totalExpanded']==478323 and v['attemptedLayers']==['bottom']and v['originalStepCalls']==957 and len(v['rows'])==1
   assert v['rows'][0]['termination']=='NATURAL_FAILED'and v['rows'][0]['terminalBeforeCancel']=={'expanded':478323,'solved':False,'failed':True}
  for f in p['outputFiles']:c.guard.source_guard.binding(f)
 r=c.read(gm['actual63101IdentityRefusalPin']['path']);p=c.read(gm['actual63101PostauditPin']['path']);log=Path(gm['actual63101LogPin']['path']).read_text();e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_29_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='tests'and r['toolSessionId']==63101 and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==2
 assert r['sourceManifestSha256']==gm['compactFrontSourcePin']['sha256']and r['rootGuardProposalManifestSha256']==gm['parent30RunnerManifestPin']['sha256']and r['rootStageContractSha256']==gm['actual63101StageContractPin']['sha256']and e==p['execution']
 assert c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual63101PostauditPin']['sha256']and c.sha(r['childLogPath'])==r['childLogSha256']==gm['actual63101LogPin']['sha256']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p)
 # The old exception path did not save an exit status or leader row. Keep unknowns.
 assert e['exitCode']is None and e['diagnosticStopped']is True and e['stopReasons']==[]and e['guardError']=='RuntimeError'and 'freshLeaderIdentity'not in e and 'oomDelta'not in e
 assert r['childExitCodeUnknown']is True and r['childExitCode']is None and r['freshLeaderIdentityWasNotSaved']is True and r['guardStoppedDuringFreshLeaderIdentityCheck']is True
 assert r['runFailure']==p['runFailure']=='RuntimeError: Fresh owned leader command/session differs'and r['stageNaturallyCompleted']is False and p['stageNaturallyCompleted']is False and r['passed']is False and p['passed']is False
 assert e['pgid']==470139 and e['currentGuardPid']==470135 and c.guard.process_scope.owned(470139)==[]and not Path('/proc/470135').exists()and r['independentlyObservedOwnedGroupEmpty']is True and r['independentlyObservedGuardAbsent']is True and p['ownedGroupEmptyActuallyObserved']is True
 assert r['actualTestCounts']is None and r['testSuiteCompleted']is False and r['observedEarlyNamedPassCount']==0 and r['observedEarlyNamedPasses']==[]and r['focusedCurrentPairCompletionWitnessPresent']is False and r['allocationDiagnosticEvidenceAvailable']is False and 'FOCUSED_CURRENT631_PAIR_DIAGNOSTIC'not in log
 assert r['newRoutesAdopted']==0 and r['all49Accepted']is False and r['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 r=c.read(gm['actual85694CollectionPin']['path']);p=c.read(gm['actual85694PostauditPin']['path']);log=Path(gm['actual85694LogPin']['path']).read_text();w=c.read(gm['actual85694AllocationWitnessPin']['path']);e=r['execution']
 assert r['authorizedByRoot']is True and r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_30_AUTHENTIC_PRIOR_CLOSURES'and r['phase']=='tests'and r['toolSessionId']==85694 and r['toolSessionCollected']is True and r['toolWrapperExitCode']==r['toolExitCode']==0
 assert r['sourceManifestSha256']==gm['compactFrontSourcePin']['sha256']and r['rootGuardProposalManifestSha256']==gm['parent31RunnerManifestPin']['sha256']and r['rootStageContractSha256']==gm['actual85694StageContractPin']['sha256']and e==p['execution']
 assert c.sha(r['postauditPath'])==r['postauditSha256']==gm['actual85694PostauditPin']['sha256']and c.sha(r['childLogPath'])==r['childLogSha256']==gm['actual85694LogPin']['sha256']
 assert r['sourceAndDependenciesHeld']is True and p['sourceAndDependenciesHeld']is True;h.held_inventory_post(p);h.finite(e,0)
 assert e['pgid']==470739 and e['currentGuardPid']==470734 and c.guard.process_scope.owned(470739)==[]and not Path('/proc/470734').exists()and r['independentlyObservedOwnedGroupEmpty']is True and r['independentlyObservedGuardAbsent']is True and p['ownedGroupEmptyActuallyObserved']is True
 assert r['stageNaturallyCompleted']is True and p['stageNaturallyCompleted']is True and r['passed']is True and p['passed']is True and r['testSuiteCompleted']is True and r['actualTestCounts']=={'pass':9,'fail':0,'expect':1269}and r['observedEarlyNamedPassCount']==8
 rows31=[json.loads(line)for line in log.splitlines()if line.startswith('{')and '"scope":"FOCUSED_CURRENT631_PAIR_DIAGNOSTIC"'in line];assert len(rows31)==1 and rows31[0]==r['focusedCurrentPairWitness']
 witness31=rows31[0];assert witness31['inputSha256']=='631ac37009bb602a3a1e67d3ffe7a932669e38ee372d60b29ce196d3c76ddd6d'and witness31['sourceRoot']=='/workspace/bus-lanes-solver/.cache/paired-compact-front-portals-truthful-witness-successor-next/lib'and witness31['naturalGeneratorCompletion']is True and witness31['originalYieldCount']==5573 and witness31['returnedCarrierCount']==2 and witness31['full49Accepted']is False and witness31['fabricationReady']is False
 assert r['originalPairGeneratorNaturallyCompleted']is True and r['originalPairGeneratorYieldCapReached']is False and r['originalPairReturnedCarrierCount']==2 and r['allocationDiagnosticEvidenceAvailable']is True and p['allocationDiagnosticEvidenceAvailable']is True
 assert r['allocationWitnessSha256']==p['allocationWitnessSha256']==gm['actual85694AllocationWitnessPin']['sha256']and w['observedEvents']==1149 and len(w['events'])==8 and w['routingOrderAndPredicatesUnchanged']is False and w['originalLegacyAndCornerOrderAndPredicatesPreserved']is True and w['compactFrontFallbackAdded']is True and w['full49Accepted']is False and w['fabricationReady']is False
 assert r['newRoutesAdopted']==0 and r['all49Accepted']is False and r['fabricationReady']is False
 for f in p['outputFiles']:c.guard.source_guard.binding(f)
 return {'context14Binding':context,'current14Rows':rows,'special15RawReceipt':gm['actual24184RawReceiptPin'],'special15FreshSupplement':gm['actual24184FreshSupplementPin'],'actual16Api77568Receipt':gm['actual77568CollectionPin'],'actual17Pair97604Receipt':gm['actual97604CollectionPin'],'actual18Remaining66744Receipt':gm['actual66744CollectionPin'],'actual19Baseline3801Receipt':gm['actual3801BaselineCollectionPin'],'actual20Resource86792Receipt':gm['actual86792ResourceCollectionPin'],'actual21Resource60763Receipt':gm['actual60763ResourceCollectionPin'],'actual22Resource59592Receipt':gm['actual59592ResourceCollectionPin'],'actual23And24Source14Diagnostics':gm['source14ObservedClosedRows'],'actual25Resource24627Receipt':pin,'actual26RemainingLayers59892Receipt':gm['actual59892CollectionPin'],'actual27Scratch60822Receipt':gm['actual60822CollectionPin'],'actual28And29Owned156Diagnostics':gm['actualOwned156ClosedRows'],'actual30IdentityRefusal63101Receipt':gm['actual63101IdentityRefusalPin'],'unknown63101ChildExitAndLeaderSnapshotPreserved':True,'actual31NinePass85694Receipt':gm['actual85694CollectionPin'],'focusedPairPassIsNotFull49Qualification':True,'completedTestSuiteIsNotNaturalPairCompletion':True,'source14DiagnosticPassedIsNotGridRoutePass':True,'resourceStopsAreNotNaturalFailuresOrPasses':True,'actualClosedScopeCount':31,'originalWrapperExitUnknownPreserved':True}


def closed_through32(c,h,gm,m,bindings,context14_path,proposal):
 previous=closed_through31(c,h,gm,m,bindings,context14_path)
 assert previous['actualClosedScopeCount']==31 and previous['originalWrapperExitUnknownPreserved'] is True
 r=read(proposal['actual32CollectionPin']['path']);p=read(proposal['actual32PostauditPin']['path']);v=read(proposal['actual32ResultPin']['path']);e=r['execution']
 assert r['authorizedByRoot'] is True and r['toolSessionId']==60819 and r['toolSessionCollected'] is True and r['toolWrapperExitCode']==r['toolExitCode']==2
 assert r['scope']=='ROOT_ONE_REVIEWED_FOCUSED_STAGE_WITH_31_AUTHENTIC_PRIOR_CLOSURES' and r['phase']=='routing' and r['sourceManifestSha256']=='d92577c2ca8ac798640e9d04ee32ebd43fcc1599374556ca02617913bbe7f48b'
 assert r['rootGuardProposalManifestSha256']==proposal['reviewedThrough31ManifestPin']['sha256'] and r['rootStageContractSha256']=='9799d63254635dbde7e89a2fe0fde043dcd81d0b63e0409f44f2b561b2ffc3ab'
 assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual32PostauditPin']['sha256'] and sha(r['resultPath'])==r['resultSha256']==proposal['actual32ResultPin']['sha256'] and e==p['execution']
 assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is True and r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True and r['passed'] is p['passed'] is False
 h.held_inventory_post(p);h.finite(e,1)
 assert e['pgid']==471806 and e['currentGuardPid']==471801 and c.guard.process_scope.owned(471806)==[] and not Path('/proc/471801').exists()
 assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is p['ownedGroupEmptyActuallyObserved'] is True
 assert r['originalStepCalls']==v['originalStepCalls']==40000 and r['actualUniqueGeneratedCarrierCount']==v['actualUniqueGeneratedCarrierCount']==4
 assert r['generatedNames']==['source_trace_15','source_trace_16','source_trace_28','source_trace_27'] and r['failureCode']==v['failureCode']=='search_budget_exhausted'
 assert v['naturalSdkFailed'] is True and v['naturalSdkSolved'] is False and v['thrown'] is None and r['all49Accepted'] is v['all49Accepted'] is False and r['fabricationReady'] is v['fabricationReady'] is False
 for f in p['outputFiles']:binding(f)
 return {'through31':previous,'actual32CollectionPin':proposal['actual32CollectionPin'],'actualClosedScopeCount':32,'originalWrapperUnknownAndOriginalElevenFailurePreserved':True}

def main():
 assert not sys.flags.optimize and len(sys.argv)==6
 source_sha,peer_path,peer_sha,context14_path,out=sys.argv[1:]
 peer_path,context14_path,out=Path(peer_path),Path(context14_path),Path(out)
 assert all(re.fullmatch('[0-9a-f]{64}',v)for v in(source_sha,peer_sha))and sha(PACKET/'SOURCE-manifest.json')==source_sha
 proposal=read(PACKET/'SOURCE-manifest.json')
 assert proposal['actual69Sealed']is proposal['cli32ActivationSealed']is True,'Future actual69 success and late CLI32 source activation are unbound; refuse before helper imports'
 for key in('actual69CollectionPin','actual69PostauditPin','actual69ModelPin','actual69ProofPin','actual69RemovalInversePin','actual69ApiReportPin','actual69GuardManifestPin','cli32PreparationPin'):assert isinstance(proposal[key],dict)
 cli32_preparation=read(proposal['cli32PreparationPin']['path']);cli32_contract=read(proposal['cli32StageContractPin']['path']);cli32_policy=cli32_contract['policy']
 assert proposal['actual68Sealed']is True,'Authentic Native68 Source32 collection remains future; no helper import'
 for key in('actual68CollectionPin','actual68PostauditPin','actual68ReportPin','actual68BoundManifestPin','actual68AuthorityPin','actual68GuardManifestPin'):assert isinstance(proposal[key],dict)
 api32_contract=read(proposal['api32StageContractPin']['path'])
 assert proposal['actual67Sealed']is True,'Authentic Source32 three-child67 collection is required before helpers'
 for key in('actual67CollectionPin','actual67PostauditPin','actual67GuardManifestPin','actual67CoreRawPin','actual67CoreControlsPin','actual67CapturePin','actual67DiagnosticPin'):assert isinstance(proposal[key],dict)
 assert isinstance(proposal['actual67PhasePostauditPins'],list)and len(proposal['actual67PhasePostauditPins'])==3
 native32_preparation=read(proposal['native32PreparationPin']['path']);native32_template=read(proposal['native32TemplatePin']['path']);native32_contract=read(proposal['native32StageContractPin']['path']);policy32=native32_contract['policy']
 assert proposal['actual66FailedSealed']is True,'Authentic captured66 ES2020 types failure required before retry'
 assert proposal['actual65FailedSealed']is True,'Authentic failed65 collection required before corrected retry'
 assert proposal['actual64ClosedSealed']is proposal['source32PromotionSealed']is True,'Future64 collection and Root-verified promotion remain unbound; refuse before helper imports'
 for key in('actual64CollectionPin','actual64PostauditPin','actual64GuardManifestPin','source32RootPromotionReceiptPin'):assert isinstance(proposal[key],dict)
 assert proposal['actual63Sealed']is True,'Authentic successful collected full64763 remains unbound; no helper imports'
 for key in('actual63CollectionPin','actual63PostauditPin','actual63ChildLogPin','actual63GuardManifestPin'):assert isinstance(proposal[key],dict)
 for key in('actual63ToolSessionId','actual63Pgid','actual63GuardPid'):assert type(proposal[key])is int and proposal[key]>0
 assert proposal['actual59FailedSealed']is True
 for key in('actual59FailedCollectionPin','actual59PostauditPin','actual59ZoneExecutionPin','actual59CadExecutionPin','actual59ZonePinsPin','actual59WorkerFailureReportPin','actual59ResourcePin','actual59GuardManifestPin','actual59SnapshotWrapperPin'):assert isinstance(proposal[key],dict)
 assert proposal['actual62Sealed']is True,'Authentic focused62 two-child collection required before full647'
 for key in('actual62CollectionPin','actual62PostauditPin','actual62GuardManifestPin'):assert isinstance(proposal[key],dict)
 assert isinstance(proposal['actual62PhasePostauditPins'],list)and isinstance(proposal['actual62ChildLogPins'],list)
 assert proposal['actual61FailedSealed']is proposal['focusedStartupHelperSealed']is True
 for key in('actual61FailedCollectionPin','actual61PostauditPin','actual61GuardManifestPin','focusedProcessScopePin','focusedProcessScopeSourcePin'):assert isinstance(proposal[key],dict)
 assert len(proposal['actual61PhasePostauditPins'])==len(proposal['actual61ChildLogPins'])==len(proposal['actual61ExecutionPins'])==2
 assert proposal['actual60Sealed']is True,'Authentic CAD60 collection is required before focused regression'
 for key in('actual60CollectionPin','actual60PostauditPin','actual60ReportPin','actual60ResourcePin','actual60ZonePinsPin','actual60GuardManifestPin'):assert isinstance(proposal[key],dict)
 assert proposal['actual58FailedSealed']is True
 for key in('actual58FailedCollectionPin','actual58PostauditPin','actual58ZoneExecutionPin','actual58UnspawnedCadExecutionPin','actual58ZonePinsPin','actual58GuardManifestPin'):assert isinstance(proposal[key],dict)
 assert proposal['actual57FailedSealed']is True
 for key in('actual57FailedCollectionPin','actual57ZoneExecutionPin','actual57UnspawnedCadExecutionPin','actual57ZonePinsPin','actual57GuardManifestPin'):assert isinstance(proposal[key],dict)
 assert proposal['actual56Sealed']is True,'Genuine collected CLI56 remains future; CAD57 forbidden before it'
 for key in('actual56CollectionPin','actual56PostauditPin','actual56ReportPin','actual56ExportPin','actual56AuthorityPin','actual56GuardManifestPin','cad29SnapshotCopyInputsPin'):assert isinstance(proposal[key],dict)
 for key in('actual56ToolSessionId','actual56Pgid','actual56GuardPid'):assert type(proposal[key])is int and proposal[key]>0
 assert proposal['actual55Sealed']is proposal['cli29ActivationSealed']is True
 for key in('actual55CollectionPin','actual55PostauditPin','actual55ModelPin','actual55ProofPin','actual55ApiReportPin','actual55GuardManifestPin','cli29PreparationPin','cli29ActivationPeerPin'):assert isinstance(proposal[key],dict)
 assert proposal['actual55ToolSessionId']==20574 and isinstance(proposal['actual55PhasePostauditPins'],list)and len(proposal['actual55PhasePostauditPins'])==2
 assert proposal['actual54Sealed']is True
 for key in('actual54CollectionPin','actual54PostauditPin','actual54ReportPin','actual54BoundManifestPin','actual54AuthorityPin','actual54GuardManifestPin'):assert isinstance(proposal[key],dict)
 assert (proposal['actual54ToolSessionId'],proposal['actual54Pgid'],proposal['actual54GuardPid'])==(90477,501788,501737)
 assert proposal['actual53Sealed']is True
 for key in('actual53CollectionPin','actual53PostauditPin','actual53CapturePin','actual53DiagnosticPin','actual53CoreRawPin','actual53CoreControlsPin','actual53GuardManifestPin'):assert isinstance(proposal[key],dict)
 assert type(proposal['actual53ToolSessionId'])is int and isinstance(proposal['actual53PhasePostauditPins'],list)and len(proposal['actual53PhasePostauditPins'])==3
 assert proposal['actual52AndSource29PromotionSealed']is True
 for key in('actual52CollectionPin','actual52PostauditPin','actual52ResultPin','actual52ResourcePin','actual52ZonePinsPin','actual52GuardManifestPin','prepared29ActivationManifestPin','promoted29ManifestPin','promoted29ModulePin','promoted29ProposalPin','promoted29CapturePin','promoted29TypesPin','promoted29CorePin'):assert isinstance(proposal[key],dict)
 for key in('actual52ToolSessionId','actual52ZonePgid','actual52CadPgid','actual52GuardPid'):assert type(proposal[key])is int
 assert isinstance(proposal['actual52ContainerName'],str)
 # Sealed-successor and required authentic pins are checked before helper imports.
 assert proposal['status']=='AUTHOR_DONE_REQUIRES_ROOT_FULL_REVIEW_PEER_AND_EXCLUSIVE_AUTHORITY'
 assert proposal['cad26FlatWrapperSealed']is proposal['actual51Sealed']is proposal['cli26ActivationSealed']is proposal['actual50Sealed']is proposal['actual49Sealed']is proposal['actual48Sealed']is proposal['future47AndPromotionSealed']is True
 for key in('actual51CollectionPin','actual51PostauditPin','actual51ReportPin','actual51ExportPin','actual51AuthorityPin','cad26WrapperSourcePin','cad26SnapshotWrapperPin','cad26SnapshotCheckerPin','cad26ResourceReporterPin'):assert isinstance(proposal[key],dict)
 for key in('cli26PreparationPin','actual50CollectionPin','actual50PostauditPin','actual50ModelPin','actual50ProofPin','actual50ApiReportPin'):assert isinstance(proposal[key],dict)
 assert type(proposal['actual50ToolSessionId'])is int and len(proposal['actual50PhasePostauditPins'])==2
 for key in('actual49CollectionPin','actual49PostauditPin','actual49ReportPin','actual49BoundManifestPin','actual49AuthorityPin'):assert isinstance(proposal[key],dict)
 assert type(proposal['actual49ToolSessionId'])is int
 for key in('actual48CollectionPin','actual48PostauditPin','actual48CapturePin','actual48DiagnosticPin','actual48CoreRawPin','actual48CoreControlsPin','actual47CollectionPin','actual47PostauditPin','actual47ResultPin','promoted26ManifestPin','promoted26ModulePin','promoted26ProposalPin','promoted26CapturePin','promoted26TypesPin','promoted26CorePin'):assert isinstance(proposal[key],dict)
 assert type(proposal['actual48ToolSessionId'])is int and len(proposal['actual48PhasePostauditPins'])==3
 regression=read(proposal['reviewedRegressionManifestPin']['path']);base=read(regression['regressionBaseSourcePin']['path'])
 gm=read(regression['reviewedThrough31ManifestPin']['path']);m=read(gm['callerSourcePin']['path']);clock=read(proposal['clockCallerSourcePin']['path'])
 stage=read(proposal['source24StagesManifestPin']['path']);declaration=read(stage['parentEditableCandidateManifest']['path']);source23=read(stage['genuineParentSource']['path'])
 native_preparation=read(proposal['nativePreparationPin']['path']);api_preparation=read(proposal['apiPreparationPin']['path']);cli_preparation=read(proposal['cliPreparationPin']['path'])
 # All historical command checks retain the executed CAD46 contract aliases.
 historicalCad46=read(proposal['historicalCad46ManifestPin']['path']);contract=read(proposal['historicalCad46ContractPin']['path']);batch=read(proposal['batchContractPin']['path'])
 prepared26=read(proposal['prepared26ManifestPin']['path']);promoted26=read(proposal['promoted26ManifestPin']['path']);data26=read(proposal['promoted26ProposalPin']['path'])
 native26_preparation=read(proposal['native26PreparationPin']['path']);native26_template=read(proposal['native26TemplatePin']['path']);native_contract=read(proposal['native26StageContractPin']['path'])
 api26_contract=read(proposal['api26StageContractPin']['path']);assert api26_contract['requiredPriorScopeCount']==49 and api26_contract['orderedPhases']==['projection','api']and api26_contract['sharedReserveBytes']==1073741824
 cli26_preparation=read(proposal['cli26PreparationPin']['path']);cli26_contract=read(proposal['cli26StageContractPin']['path']);cli26_policy={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 cad26_contract=read(proposal['cad26StageContractPin']['path']);cad26_wrapper=read(proposal['cad26WrapperSourcePin']['path']);cad26_copies=read(proposal['cad26SnapshotCopyInputsPin']['path'])
 assert cad26_contract['requiredPriorScopeCount']==51 and cad26_contract['zonePinsPolicy']=={'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}and cad26_contract['cadPolicy']=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5,'diskFreeGuard':{'path':'/var/lib/docker','minimumFreeBytes':134217728}}
 assert cad26_contract['vfsOverheadBufferBytes']==201326592 and cad26_contract['sampledDiskMinimumFreeBytes']==134217728 and cad26_contract['noImageLoadBuildPull']is True and cad26_copies['runtimeSourceManifest']==proposal['cli26PreparationPin']
 assert cli26_contract['requiredPriorScopeCount']==50 and cli26_contract['phase']=='cli'and cli26_contract['policy']==cli26_policy and cli26_contract['sharedReserveBytes']==1073741824 and cli26_contract['cliWorkerPin']in cli26_preparation['files']
 assert cli26_preparation['genuineSourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and cli26_preparation['requiresNativeSourceManifestSha256']==cli26_preparation['requiresApiSourceManifestSha256']==proposal['native26PreparationPin']['sha256']
 assert cli26_preparation['actualPrerequisites']['actualApiCollection']==proposal['actual50CollectionPin']and cli26_preparation['actualPrerequisites']['actualNativeCollection']==proposal['actual49CollectionPin']and cli26_preparation['actualPrerequisites']['actualCoreRaw']==proposal['actual48CoreRawPin']and cli26_preparation['actualPrerequisites']['actualCoreControls']==proposal['actual48CoreControlsPin']
 assert api26_contract['apiWorkerPin']in native26_preparation['files']and api26_contract['projectorPin']in native26_preparation['files']and api26_contract['apiWorkerPin']['sha256']=='05d243c3e63c9ad23f5a2efbb2fdac96d7de8ba4e6ae6182e4ded58aa12a6491'and api26_contract['projectorPin']['sha256']=='e20c01c5e957d42c74c04f2b6819040c57e505348bbbda04863b094dc9ce92a3'
 policy={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 assert native_contract['phase']=='native'and native_contract['policy']==policy and native_contract['sharedReserveBytes']==1073741824 and native_contract['requiredPriorScopeCount']==48
 assert native_contract['workerPin']in native26_preparation['files']and native_contract['workerPin']['sha256']=='1440e321428bcfb9512ecd03b9b2f055b9cc901949efb0f9dec1a023d98609eb'
 assert native26_preparation['knownPromotedSource26Manifest']==proposal['promoted26ManifestPin']and native26_preparation['knownPromotedSource26Proposal']==proposal['promoted26ProposalPin']
 assert batch['requiredPriorScopeCount']==47 and batch['orderedPhases']==['capture','types','core']and batch['sharedReserveBytes']==1073741824
 assert len(stage['baseline169SourceBindings'])==stage['baseline169Count']==169 and stage['baseline169ByteDelta']==[]and stage['expandedLocalSourceAndControllerImportClosureCount']==176
 assert stage['boardSdkTreeSha256']=='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'and stage['solverSdkTreeSha256']=='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
 assert stage['reviewedRuntimeChecksBundle']['sha256']=='1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc'
 prepared29=read(proposal['prepared29ActivationManifestPin']['path']);promoted29=read(proposal['promoted29ManifestPin']['path']);data29=read(proposal['promoted29ProposalPin']['path']);batch29=read(proposal['source29BatchContractPin']['path'])
 assert batch29['requiredPriorScopeCount']==52 and batch29['orderedPhases']==['capture','types','core']and batch29['sharedReserveBytes']==1073741824
 native29_preparation=read(proposal['native29PreparationPin']['path']);native29_template=read(proposal['native29TemplatePin']['path']);native29_contract=read(proposal['native29StageContractPin']['path'])
 policy29={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 assert native29_contract['phase']=='native'and native29_contract['policy']==policy29 and native29_contract['sharedReserveBytes']==1073741824 and native29_contract['requiredPriorScopeCount']==53
 assert native29_contract['workerPin']in native29_preparation['files']and native29_contract['workerPin']['sha256']=='02928a080a47f7b4ca15c2febe935c51eb21dcfb6aeb57b3f18742958e8fe0f0'
 assert native29_preparation['knownPromotedSource29Manifest']==proposal['promoted29ManifestPin']and native29_preparation['knownPromotedSource29Proposal']==proposal['promoted29ProposalPin']and native29_preparation['allThreeWorkersKnownPromotedConstantsBound']is True
 assert native29_contract['native29PreparationPin']==proposal['native29PreparationPin']and native29_contract['promoted29ManifestPin']==proposal['promoted29ManifestPin']and native29_contract['expectedPhysicalChecks']==18 and native29_contract['expectedConnectedOriginals']==29 and native29_contract['expectedMissingOriginals']==20
 assert native29_contract['expectedPhysicalTraceCount']==292 and native29_contract['expectedInnerAliasCount']==46 and native29_contract['expectedPhysicalPortCount']==1661
 assert native29_template['coreSourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and native29_template['source29ProposalPath']==proposal['promoted29ProposalPin']['path']and native29_template['source29ProposalSha256']==proposal['promoted29ProposalPin']['sha256']
 api29_contract=read(proposal['api29StageContractPin']['path']);assert api29_contract['requiredPriorScopeCount']==54 and api29_contract['orderedPhases']==['projection','api']and api29_contract['sharedReserveBytes']==1073741824
 assert api29_contract['apiWorkerPin']in native29_preparation['files']and api29_contract['projectorPin']in native29_preparation['files']and api29_contract['apiWorkerPin']['sha256']=='e46819f54ad494b545b84c8805605174777c5473e7cbe2c4b5fc2a130815448a'and api29_contract['projectorPin']['sha256']=='58953778f6fc604d6abf53644dc6340be934da37e831fa427154355830710807'
 assert api29_contract['primaryBooleanPredicates']==128 and api29_contract['secondaryDqs1BooleanPredicates']==3 and api29_contract['totalBooleanPredicates']==131 and api29_contract['expectedLoadedCohortSizes']=={'DDR_BYTE0':6,'DDR_BYTE1':11,'DDR_COMMAND_CLOCK':11}and api29_contract['expectedSignalStubSerializedPrimitives']==414 and api29_contract['heldSourceClosureCount']==186
 cli29_preparation=read(proposal['cli29PreparationPin']['path']);cli29_contract=read(proposal['cli29StageContractPin']['path']);cli29_policy={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 assert cli29_contract['requiredPriorScopeCount']==55 and cli29_contract['phase']=='cli'and cli29_contract['policy']==cli29_policy and cli29_contract['sharedReserveBytes']==1073741824 and cli29_contract['cliWorkerPin']in cli29_preparation['files']
 assert cli29_preparation['genuineSourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and cli29_preparation['requiresNativeSourceManifestSha256']==cli29_preparation['requiresApiSourceManifestSha256']==proposal['native29PreparationPin']['sha256']
 assert cli29_preparation['actualPrerequisites']['actualApiCollection']==proposal['actual55CollectionPin']and cli29_preparation['actualPrerequisites']['actualNativeCollection']==proposal['actual54CollectionPin']and cli29_preparation['actualPrerequisites']['actualCoreRaw']==proposal['actual53CoreRawPin']and cli29_preparation['actualPrerequisites']['actualCoreControls']==proposal['actual53CoreControlsPin']
 cad29_contract=read(proposal['cad29StageContractPin']['path']);cad29_wrapper=read(proposal['cad29WrapperSourcePin']['path']);cad29_copies=read(proposal['cad29SnapshotCopyInputsPin']['path'])
 assert cad29_contract['requiredPriorScopeCount']==59 and cad29_contract['zonePinsPolicy']==cad26_contract['zonePinsPolicy']and cad29_contract['cadPolicy']==cad26_contract['cadPolicy']and cad29_contract['vfsOverheadBufferBytes']==201326592 and cad29_contract['sampledDiskMinimumFreeBytes']==134217728
 assert cad29_contract['noImageLoadBuildPull']is True and cad29_copies['runtimeSourceManifest']==proposal['cli29PreparationPin']
 focused=read(proposal['focusedStageContractPin']['path']);candidate=read(proposal['candidateSourcePin']['path']);inspector_source=read(proposal['logInspectorManifestPin']['path']);focused_helper_source=read(proposal['focusedProcessScopeSourcePin']['path'])
 assert focused['requiredPriorScopeCount']==61 and focused['orderedPhases']==['baseline','proposed']and focused['candidateSourcePin']==proposal['candidateSourcePin']and focused['workerPin']==proposal['focusedWorkerPin']
 assert len(candidate['solverSourceFiles'])==len(candidate['originalSolverSourceFiles'])==120 and candidate['status']=='AUTHOR_DONE_UNRUN_REQUIRES_ROOT_REVIEW_INDEPENDENT_PEER_AND_SERIAL_APP_GUARD'
 public_caller=read(proposal['public49CallerPin']['path']);public_contract=read(proposal['public49StageContractPin']['path'])
 assert public_caller['futureActualFocused62CollectionPin']==proposal['actual62CollectionPin']and public_caller['futureActualFull64763CollectionPin']==proposal['actual63CollectionPin'],'Caller prerequisite metadata must be authentically activated before helpers'
 full_project=read(proposal['full647CurrentProjectBindingPin']['path']);full_plan=read(full_project['copyPlanPin']['path']);full_contract=read(full_project['stageContractPin']['path'])
 assert full_project['candidateSourcePin']==proposal['candidateSourcePin']and full_plan['copiedFileCount']==len(full_plan['stagedSourceFiles'])==442 and full_plan['oldTestFileCount']==189 and full_plan['expectedTestFileCount']==190
 assert full_contract['requiredPriorScopeCount']==62 and full_contract['expectedCounts']=={'pass':647,'fail':0}and full_contract['cwd']==full_plan['project']and full_contract['env']['G350_DOOMED_ESCAPE_SOURCE_ROOT']==focused['proposedSourceRoot']
 no_git_redirects()
 # Exactly two future metadata records are not concrete inputs; the whole copy document remains pinned.
 assert cad26_copies['unresolvedFutureRows']==[{'field': 'newCadAuthority', 'path': '/tmp/g350-source26-cad-root-20261015-after51/ROOT_CAD_AUTHORITY.json', 'sha256': None, 'bytes': None, 'mode': None, 'RootCreatesAfterReview': True}, {'field': 'actualSourceZonePins', 'path': '/tmp/g350-source26-cad-root-20261015-after51/SOURCE_ZONE_PINS.json', 'sha256': None, 'bytes': None, 'mode': None, 'RootDerivesAfterReview': True}]
 cad26_concrete_copies={k:v for k,v in cad26_copies.items()if k!='unresolvedFutureRows'}
 prepared32=read(proposal['prepared32ActivationManifestPin']['path']);promoted32=read(proposal['promoted32ManifestPin']['path']);data32=read(proposal['promoted32ProposalPin']['path']);batch32=read(proposal['source32BatchContractPin']['path']);runtime32=read(proposal['source32FinalRuntimePin']['path'])
 def bindings():
  assert sha(PACKET/'SOURCE-manifest.json')==source_sha
  for row in proposal['runtimeBindings']:binding(row)
  seen={}
  for doc in(prepared32,promoted32,data32,batch32,runtime32,proposal,historicalCad46,contract,regression,base,gm,m,clock,stage,declaration,source23,native_preparation,api_preparation,cli_preparation,prepared26,promoted26,data26,batch,native26_preparation,native26_template,native_contract,api26_contract,cli26_preparation,cli26_contract,cad26_contract,cad26_wrapper,cad26_concrete_copies,prepared29,promoted29,data29,batch29,native29_preparation,native29_template,native29_contract,api29_contract,cli29_preparation,cli29_contract,cad29_contract,cad29_wrapper,cad29_copies,focused,candidate,inspector_source,focused_helper_source,full_project,full_plan,full_contract,read(gm['faithfulApiSourcePin']['path']),read(stage['sourceProposal']['path'])):
   for row in rows(doc):
    row={k:row[k]for k in('path','sha256','bytes','mode')};assert row['path']not in seen or seen[row['path']]==row
    seen[row['path']]=row;binding(row)
  assert promoted26['baseline176SourceBindings']==prepared26['baseline176SourceBindings']==stage['expandedLocalSourceAndControllerImportClosure']
  closure=promoted26['expandedHeldSourceAndControllerClosure'];assert len(closure)==promoted26['expandedHeldSourceAndControllerClosureCount']==181
  held={r['path']:r for r in closure};assert len(held)==181 and all(held[r['path']]==r for r in stage['expandedLocalSourceAndControllerImportClosure'])
  target=Path(prepared26['intendedWorkspacePromotionDirectory']);assert target==Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-source26-reset-source3-editable-source-stages-sourceonly-next')
  prior_paths={r['path']for r in stage['expandedLocalSourceAndControllerImportClosure']};additions=[r for r in closure if r['path']not in prior_paths]
  old_by_name={Path(r['path']).name:r for r in prepared26['files']}
  assert len(additions)==5 and {Path(r['path']).name for r in additions}=={'source26.circuit.tsx','source26-proposal.json','source26-types.ts','capture-source26.ts','render-source26-core.ts'}
  for row in additions:
   assert Path(row['path']).parent==target and {k:row[k]for k in('sha256','bytes','mode')}=={k:old_by_name[Path(row['path']).name][k]for k in('sha256','bytes','mode')}
  for key,name in(('promoted26ModulePin','source26.circuit.tsx'),('promoted26ProposalPin','source26-proposal.json'),('promoted26CapturePin','capture-source26.ts'),('promoted26CorePin','render-source26-core.ts')):assert proposal[key]in additions and Path(proposal[key]['path']).name==name
  assert Path(proposal['promoted26TypesPin']['path'])==target/'typecheck-source26.sh'and {k:proposal['promoted26TypesPin'][k]for k in('sha256','bytes','mode')}=={k:old_by_name['typecheck-source26.sh'][k]for k in('sha256','bytes','mode')}
  assert promoted29['parent181HeldSourceBindings']==prepared29['parent181HeldSourceBindings']==promoted26['expandedHeldSourceAndControllerClosure']
  closure29=promoted29['expandedHeldSourceAndControllerClosure'];assert len(closure29)==promoted29['expandedHeldSourceAndControllerClosureCount']==186
  held29={r['path']:r for r in closure29};assert len(held29)==186 and all(held29[r['path']]==r for r in promoted26['expandedHeldSourceAndControllerClosure'])
  target29=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-source29-joint7-ca6-ca18-reset-editable-source-stages-sourceonly-next')
  prior29_paths={r['path']for r in promoted26['expandedHeldSourceAndControllerClosure']};additions29=[r for r in closure29 if r['path']not in prior29_paths];prepared29_by_name={Path(r['path']).name:r for r in prepared29['files']}
  assert len(additions29)==5 and {Path(r['path']).name for r in additions29}=={'source29.circuit.tsx','source29-proposal.json','source29-types.ts','capture-source29.ts','render-source29-core.ts'}
  for row in additions29:assert Path(row['path']).parent==target29 and {k:row[k]for k in('sha256','bytes','mode')}=={k:prepared29_by_name[Path(row['path']).name][k]for k in('sha256','bytes','mode')}
  for key,name in(('promoted29ModulePin','source29.circuit.tsx'),('promoted29ProposalPin','source29-proposal.json'),('promoted29CapturePin','capture-source29.ts'),('promoted29CorePin','render-source29-core.ts')):assert proposal[key]in additions29 and Path(proposal[key]['path']).name==name
  assert Path(proposal['promoted29TypesPin']['path'])==target29/'typecheck-source29.sh'and {k:proposal['promoted29TypesPin'][k]for k in('sha256','bytes','mode')}=={k:prepared29_by_name['typecheck-source29.sh'][k]for k in('sha256','bytes','mode')}
  assert promoted29['source29ProposalPin']==proposal['promoted29ProposalPin']and promoted29['source29ModulePin']==proposal['promoted29ModulePin']and promoted29['captureWorkerPin']==proposal['promoted29CapturePin']and promoted29['coreWorkerPin']==proposal['promoted29CorePin']and promoted29['typecheckWorkerPin']==proposal['promoted29TypesPin']
  assert data29['promotedParent26Source']==proposal['promoted26ManifestPin']and data29['actualParent26Qualification']==proposal['actual52CollectionPin']and data29['actualParent26Stages']['cad']==proposal['actual52ResultPin']
  assert data29['parent26QualificationBindings']['collectionPins']['cad52']==proposal['actual52CollectionPin']and data29['parent26QualificationBindings']['stagePins']['cad']==proposal['actual52ResultPin']and data29['parent26QualificationBindings']['cad52Postaudit']==proposal['actual52PostauditPin']
  assert promoted29['actualParent26QualificationPin']==proposal['actual52CollectionPin']and batch29['actualParent26CadCollectionPin']==proposal['actual52CollectionPin']and batch29['promotedSource29ManifestPin']==proposal['promoted29ManifestPin']
  for row in base['symlinkContracts']:
   p=Path(row['stagePath']);assert p.is_symlink()and os.readlink(p)==row['linkTarget']and str(p.resolve())==row['resolvedTarget']
  assert peer_path.is_file()and not peer_path.is_symlink()and sha(peer_path)==peer_sha
  peer=read(peer_path);assert peer['sourceManifestSha256']==proposal['cli32PreparationPin']['sha256']and peer['guardProposalManifestSha256']==source_sha and peer['decision']==cli32_contract['expectedPeerDecision']
  candidate_peer=read(proposal['candidateSourcePeerPin']['path']);assert candidate_peer['sourceManifestSha256']==proposal['candidateSourcePin']['sha256']and candidate_peer['decision']=='GO_SOURCE_ONLY_TO_ROOT_GUARDED_DOOMED_ESCAPE_ORDER_FOCUSED_RED_GREEN'
  for link in full_plan['symlinkContracts']:
   path=Path(link['stagePath']);assert path.is_symlink()and os.readlink(path)==link['linkTarget']and str(path.resolve())==link['resolvedTarget']
  candidate_libs={str(Path(row['path']).relative_to(Path(candidate['solverSourceRoot']).parent)):row for row in candidate['solverSourceFiles']}
  staged_libs={row['relativePath']:row['destination']for row in full_plan['copies']if row['relativePath'].startswith('lib/')}
  assert set(candidate_libs)==set(staged_libs)and len(staged_libs)==120
  for rel,row in staged_libs.items():assert {k:row[k]for k in('sha256','bytes','mode')}=={k:candidate_libs[rel][k]for k in('sha256','bytes','mode')}
  prepared_peer=read(proposal['prepared26PeerPin']['path']);assert prepared_peer['candidateManifest']['sha256']==proposal['prepared26ManifestPin']['sha256']and prepared_peer['decision']==proposal['prepared26PeerDecision']
  assert batch32['requiredPriorScopeCount']==66 and batch32['orderedPhases']==['capture','types','core']and batch32['sharedReserveBytes']==1073741824
  assert promoted32['parent186HeldSourceBindings']==prepared32['parent186HeldSourceBindings']==promoted29['expandedHeldSourceAndControllerClosure']
  closure32=promoted32['expandedHeldSourceAndControllerClosure'];assert len(closure32)==promoted32['expandedHeldSourceAndControllerClosureCount']==191
  held32={r['path']:r for r in closure32};assert len(held32)==191 and all(held32[r['path']]==r for r in promoted29['expandedHeldSourceAndControllerClosure'])
  target32=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-source32-intermediate20-21-ca45-es2020-own-property-source-stages-sourceonly-next');prior32_paths={r['path']for r in promoted29['expandedHeldSourceAndControllerClosure']}
  additions32=[r for r in closure32 if r['path']not in prior32_paths];prepared32_by_name={Path(r['path']).name:r for r in prepared32['files']}
  assert len(additions32)==5 and {Path(r['path']).name for r in additions32}=={'source32.circuit.tsx','source32-proposal.json','source32-types.ts','capture-source32.ts','render-source32-core.ts'}
  for row in additions32:assert Path(row['path']).parent==target32 and {k:row[k]for k in('sha256','bytes','mode')}=={k:prepared32_by_name[Path(row['path']).name][k]for k in('sha256','bytes','mode')}
  for key,name in(('promoted32ModulePin','source32.circuit.tsx'),('promoted32ProposalPin','source32-proposal.json'),('promoted32CapturePin','capture-source32.ts'),('promoted32CorePin','render-source32-core.ts')):assert proposal[key]in additions32 and Path(proposal[key]['path']).name==name
  assert proposal['promoted32TypesPin']==promoted32['typecheckWorkerPin']and Path(proposal['promoted32TypesPin']['path'])==target32/'typecheck-source32.sh'
  assert promoted32['source32ProposalPin']==proposal['promoted32ProposalPin']and promoted32['source32ModulePin']==proposal['promoted32ModulePin']and promoted32['captureWorkerPin']==proposal['promoted32CapturePin']and promoted32['coreWorkerPin']==proposal['promoted32CorePin']
  assert data32['actualParent29Qualification']==proposal['actual60CollectionPin']and data32['actualParent29Capture']==proposal['actual53CapturePin']
  assert data32['actualParent29Stages']['cad']==proposal['actual60ReportPin']and data32['parent29QualificationBindings']['collectionPins']['cad60']==proposal['actual60CollectionPin']
  assert proposal['source32FinalRuntimePin']['sha256']=='2dc1b80988869d3fff899e4ec3909e8d0c589181ce65d7ee7816bbb04f58c2d2'and proposal['source32FinalRuntimePeerPin']['sha256']=='2c5650e124d1e5466941914d33d51c1252df856f44178fcd58dbf285f5ad01b5'
  assert any(r['sha256']=='7c5304d643cec436fa746e3e1858e494a5ac46e3afdab4963bf24f34b4c69b9e'for r in runtime32['files'])
  copy_receipt=read(proposal['source32RootPromotionReceiptPin']['path'])
  assert copy_receipt['scope']=='ROOT_SOURCE32_FOUR_ES2020_OWN_PROPERTY_CORRECTIONS_COPY_AFTER_CLOSED66_NOT_QUALIFICATION'and copy_receipt['sourceManifestSha256']==proposal['source32PromotionPlanManifestPin']['sha256']and copy_receipt['copyPlanSha256']==proposal['source32CopyPlanPin']['sha256']and copy_receipt['peerSha256']==proposal['source32CopyPlanPeerPin']['sha256']
  assert copy_receipt['priorClosed66Collection']==proposal['actual66FailedCollectionPin']and copy_receipt['promotedSourceManifestPin']==proposal['promoted32ManifestPin']and copy_receipt['targetDirectory']==str(target32)
  assert copy_receipt['filesCopiedAndVerified']==11 and copy_receipt['importClosureFilesVerified']==191 and copy_receipt['SDKOrCoreExecuted']is copy_receipt['source32Accepted']is copy_receipt['all49Accepted']is copy_receipt['fabricationReady']is False
  assert copy_receipt['exactFourOwnPropertyCallCorrections']is copy_receipt['compilerFlagsUnchanged']is copy_receipt['originalFailedSourcePreserved']is True
 bindings()
 helper=Path(regression['operationalHelperPin']['path']);binding(regression['operationalHelperPin'])
 spec=importlib.util.spec_from_file_location('source26_batch_existing_root_closure',helper);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);c=h.c
 binding(gm['diagnosticProcessScopePin']);binding(gm['originalProcessScopePin'])
 assert Path(c.guard.process_scope.__file__).resolve()==Path(gm['originalProcessScopePin']['path']).resolve()
 spec=importlib.util.spec_from_file_location('source26_batch_reviewed_process_scope',gm['diagnosticProcessScopePin']['path']);process_runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(process_runner)
 binding(proposal['focusedProcessScopePin']);spec=importlib.util.spec_from_file_location('c31_active_focused_bounded_startup_runner',proposal['focusedProcessScopePin']['path']);focused_process_runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(focused_process_runner)
 binding(proposal['logInspectorPin']);spec=importlib.util.spec_from_file_location('c31_existing_pure_focused_inspector',proposal['logInspectorPin']['path']);inspector=importlib.util.module_from_spec(spec);spec.loader.exec_module(inspector)
 def closed34():
  prior=closed_through32(c,h,gm,m,bindings,context14_path,proposal)
  assert prior['actualClosedScopeCount']==32 and prior['originalWrapperUnknownAndOriginalElevenFailurePreserved'] is True
  for number,phase,scope,expected in ((33,'full644','ROOT_C30_FULL644_WITH32_AUTHENTIC_PRIOR_CLOSURES',{'pass':644,'fail':0}),(34,'optout9','ROOT_C30_OPTOUT9_WITH33_AUTHENTIC_PRIOR_CLOSURES',{'pass':9,'fail':0})):
   r=read(proposal[f'actual{number}CollectionPin']['path']);p=read(proposal[f'actual{number}PostauditPin']['path']);e=r['execution']
   assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolWrapperExitCode']==r['toolExitCode']==0 and r['passed'] is True
   assert type(r['toolSessionId']) is int and r['toolSessionId']>0 and r['scope']==scope and r['phase']==phase
   assert r['sourceManifestSha256']==r['rootGuardProposalManifestSha256']==proposal['reviewedRegressionManifestPin']['sha256']
   assert sha(r['postauditPath'])==r['postauditSha256']==proposal[f'actual{number}PostauditPin']['sha256'] and p['execution']==e and p['sourceManifestSha256']==r['sourceManifestSha256']
   assert p['passed'] is p['stageNaturallyCompleted'] is p['sourceAndDependenciesHeld'] is True and p['observedCounts']==expected and p['actualClosedPriorScopes']==prior
   assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
   assert p['dependenciesBefore']['treeSha256']==base['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==base['solverSdkTreeSha256']
   h.held_inventory_post(p);h.finite(e,0)
   assert c.guard.process_scope.owned(e['pgid'])==[] and p['ownedGroupEmptyActuallyObserved'] is True and p['workspaceFreeBytesFloorHeld'] is True and p['gitMetadataHeld'] is True
   assert not Path('/proc',str(e['currentGuardPid'])).exists()
   assert sha(p['childLogPath'])==p['childLogSha256']==proposal[f'actual{number}ChildLogPin']['sha256'] and counts(Path(p['childLogPath']).read_text())==expected
   assert p['all49Accepted'] is p['referenceQualified'] is p['electricalTimingPassed'] is p['fabricationReady'] is p['fixReleaseQualificationPassed'] is False
   if number==34:
    witness=p['focusedCurrentPairWitness']
    assert isinstance(witness,dict) and witness['scope']=='FOCUSED_CURRENT631_PAIR_DIAGNOSTIC' and witness['inputSha256']=='631ac37009bb602a3a1e67d3ffe7a932669e38ee372d60b29ce196d3c76ddd6d'
    assert witness['sourceRoot']==clock['solverSourceRoot'] and witness['naturalGeneratorCompletion'] is True and witness['returnedCarrierCount']==2 and 0<=witness['originalYieldCount']<40000
    assert witness['allocationObserverInstalledForDdrCase'] is False and witness['diagnosticMode']=='optout' and re.fullmatch('[0-9a-f]{64}',witness['returnedTracesSha256'])
    raw=[json.loads(line) for line in Path(p['childLogPath']).read_text().splitlines() if line.startswith('{') and '"scope":"FOCUSED_CURRENT631_PAIR_DIAGNOSTIC"' in line]
    assert raw==[witness]
   prior[f'actual{number}'+('Full644' if number==33 else 'Optout9')+'CollectionPin']={'path':str(Path(proposal[f'actual{number}CollectionPin']['path']).resolve()),'sha256':proposal[f'actual{number}CollectionPin']['sha256']}
   prior['actualClosedScopeCount']=number
  return prior

 def closed35():
  prior=closed34()
  assert prior['actualClosedScopeCount']==34 and prior['originalWrapperUnknownAndOriginalElevenFailurePreserved'] is True
  r=read(proposal['actual35CollectionPin']['path']);p=read(proposal['actual35PostauditPin']['path']);v=read(proposal['actual35ResultPin']['path']);raw=read(proposal['actual35RawResultPin']['path']);w=read(proposal['actual35AllocationWitnessPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==30459 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_C30_CLOCK_FIRST_VISIT_WITH34_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='clock_diagnostic'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['priorClockCallerSourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['priorClockGuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual35PostauditPin']['sha256'] and e==p['execution'] and p['actualClosed34Scopes']==prior
  assert sha(r['resultPath'])==r['resultSha256']==p['resultSha256']==proposal['actual35ResultPin']['sha256'] and sha(r['rawResultPath'])==r['rawResultSha256']==p['rawResultSha256']==proposal['actual35RawResultPin']['sha256']
  assert sha(r['allocationWitnessPath'])==r['allocationWitnessSha256']==proposal['actual35AllocationWitnessPin']['sha256'] and r['allocationWitnessBytes']<=16384
  assert r['passed'] is p['passed'] is r['diagnosticCompleted'] is p['diagnosticCompleted'] is True and r['passedMeansDiagnosticCompletionOnly'] is p['passedMeansDiagnosticCompletionOnly'] is True and r['testSuccess'] is p['testSuccess'] is None
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['stageNaturallyCompleted'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter'] and p['dependenciesBefore']['treeSha256']==clock['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==clock['solverDependenciesTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['pgid']==476561 and e['currentGuardPid']==476540 and c.guard.process_scope.owned(e['pgid'])==[] and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True
  assert r['pairReturned'] is p['pairReturned'] is r['pairAccepted'] is p['pairAccepted'] is r['clockRoutingQualified'] is p['clockRoutingQualified'] is False
  assert r['termination']==p['termination']==v['termination']=='ORIGINAL_PAIR_YIELD_CAP' and v['diagnosticCompleted'] is True and v['naturalGeneratorCompletion'] is False and v['original40000YieldCapReached'] is True
  assert r['originalPairYieldCount']==v['originalYieldCount']==v['nextCalls']==40000 and r['originalPairGeneratorNaturallyCompleted'] is False and r['originalPairReturnedCarrierCount']==v['returnedCarrierCount']==0 and v['thrown'] is None
  for key in ('naturalGeneratorCompletion','originalYieldCount','nextCalls','original40000YieldCapReached','thrown','returnedCarrierCount'):assert raw[key]==v[key]
  assert raw['traces'] is None and v['rawGeometryComplete'] is True and p['pairYieldCapReached'] is True and p['naturalNullReturned'] is False
  assert w['scope']=='ROOT_OPT_IN_LAST8_GRID_ALLOCATION_WITNESS' and w['inputSha256']==clock['faithfulInputPin']['sha256'] and w['sourceRoot']==clock['solverSourceRoot'] and w['pairNames']==['source_trace_33','source_trace_34'] and w['observedEvents']==2916 and len(w['events'])==8
  assert w['maximumEvents']==8 and w['maximumBytes']==16384 and all(row['event']['pass']=='legacy' for row in w['events'])
  for key in ('all49Accepted','fabricationReady'):assert r[key] is p[key] is v[key] is raw[key] is w[key] is False
  for key in ('originalAll11AcceptanceClaimed','fixReleaseQualificationPassed','referenceQualified','electricalTimingPassed'):assert p[key] is False
  assert p['sourceNativeCheckedCountRemains23'] is True and p['newRoutesAdopted']==r['newRoutesAdopted']==0
  for row in p['outputFiles']:binding(row)
  prior['actual35ClockLegacyYieldCapCollectionPin']={'path':proposal['actual35CollectionPin']['path'],'sha256':proposal['actual35CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=35
  prior['actual35LegacyPairCapIsNotNaturalNullOrNoRoute']=True
  return prior

 def closed36():
  prior=closed35()
  assert prior['actualClosedScopeCount']==35
  r=read(proposal['actual36CollectionPin']['path']);p=read(proposal['actual36PostauditPin']['path']);w=read(proposal['actual36AllocationWitnessPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==64637
  assert r['toolWrapperExitCode']==2 and r['toolExitCode']==-15 and e==p['execution']
  assert r['scope']==p['scope']=='ROOT_C30_CLOCK_DIRECT_COMPACT_WITH35_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='clock_direct_compact_diagnostic'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['clockCallerSourcePin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['directClockGuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual36PostauditPin']['sha256'] and p['actualClosed35Scopes']==prior
  assert e['exitCode']==-15 and e['accepted'] is False and e['diagnosticStopped'] is True and e['stopReasons']==['WALL_STOP']
  assert e['policy']=={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['cleanupOwnedGroupEmpty'] is True and e['signalErrors']==[] and e['signalErrorCount']==0
  assert e['endedAt'] and e['stoppedAt'] and e['wallSeconds']>=90 and e['peakOwnedRssBytes']==528244736
  assert isinstance(e['oomDelta'],dict) and bool(e['oomDelta']) and not any(e['oomDelta'].values())
  assert e['pgid']==477899 and e['currentGuardPid']==477868 and c.guard.process_scope.owned(e['pgid'])==[] and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is p['ownedGroupEmptyActuallyObserved'] is True
  assert r['independentProcReadErrors']==[] and r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==clock['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==clock['solverDependenciesTreeSha256']
  h.held_inventory_post(p)
  for key in ('passed','stageNaturallyCompleted','diagnosticCompleted','pairReturned','pairAccepted','clockRoutingQualified','all49Accepted','fabricationReady'):assert r[key] is p[key] is False
  assert r['testSuccess'] is p['testSuccess'] is r['naturalGeneratorCompletion'] is p['naturalGeneratorCompletion'] is r['termination'] is p['termination'] is None
  assert r['originalPairYieldCount'] is r['originalPairGeneratorNaturallyCompleted'] is r['originalPairReturnedCarrierCount'] is None
  assert r['resultSha256'] is p['resultSha256'] is r['rawResultSha256'] is p['rawResultSha256'] is None
  assert r['resultPath']==p['resultPath'] and r['rawResultPath']==p['rawResultPath']
  assert not Path(r['resultPath']).exists() and not Path(r['rawResultPath']).exists()
  assert p['rawReportedYieldCount'] is p['rawReportedReturnedCarrierCount'] is p['rawGeometryComplete'] is None
  assert p['naturalNullReturned'] is p['pairYieldCapReached'] is False and r['wallStopIsNotNaturalNullOrYieldCap'] is True
  assert sha(r['allocationWitnessPath'])==r['allocationWitnessSha256']==proposal['actual36AllocationWitnessPin']['sha256'] and r['allocationWitnessBytes']==6312
  assert r['allocationObservedEvents']==w['observedEvents']==989 and w['scope']=='ROOT_OPT_IN_LAST8_CLOCK_DIRECT_COMPACT_GRID_ALLOCATION_WITNESS'
  assert w['inputSha256']==clock['faithfulInputPin']['sha256'] and w['sourceRoot']==clock['solverSourceRoot'] and w['pairNames']==['source_trace_33','source_trace_34']
  assert len(w['events'])==w['maximumEvents']==8 and w['maximumBytes']==16384 and all(row['event']['pass']=='compact' for row in w['events'])
  for doc in (r,p,w):
   assert doc['searchOrderChanged'] is doc['directCompactOnly'] is doc['originalC30PredicatesUnchanged'] is True and doc['exactOriginalFull49Call'] is False
  assert w['all49Accepted'] is w['fabricationReady'] is False
  for key in ('originalAll11AcceptanceClaimed','fixReleaseQualificationPassed','referenceQualified','electricalTimingPassed'):assert p[key] is False
  assert p['sourceNativeCheckedCountRemains23'] is True and p['newRoutesAdopted']==r['newRoutesAdopted']==0
  for row in p['outputFiles']:binding(row)
  prior['actual36ClockDirectCompactWallStopCollectionPin']={'path':proposal['actual36CollectionPin']['path'],'sha256':proposal['actual36CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=36
  prior['actual36WallStopIsNotNaturalNullOrYieldCap']=True
  prior['actual36PairYieldNaturalAndReturnCountersRemainUnknown']=True
  return prior

 def closed37():
  prior=closed36();assert prior['actualClosedScopeCount']==36
  r=read(proposal['actual37CollectionPin']['path']);p=read(proposal['actual37PostauditPin']['path']);v=read(proposal['actualSource24CaptureOutputPin']['path']);d=read(proposal['actual37DiagnosticPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==9465 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FIRST_CAPTURE_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='capture'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['source24StagesManifestPin']['sha256']
  assert r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual37GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual37PostauditPin']['sha256'] and p['execution']==e and p['actualClosedPriorScopes']==prior
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['passedMeansSourceCaptureAndFullInverseOnly'] is p['passedMeansSourceCaptureAndFullInverseOnly'] is True
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['policy']=={'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['pgid']==479464 and e['currentGuardPid']==479394 and c.guard.process_scope.owned(e['pgid'])==[] and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['capturePath']==p['capturePath']==proposal['actualSource24CaptureOutputPin']['path'] and sha(r['capturePath'])==r['captureSha256']==p['captureSha256']==proposal['actualSource24CaptureOutputPin']['sha256']
  assert r['diagnosticPath']==p['diagnosticPath']==proposal['actual37DiagnosticPin']['path'] and sha(r['diagnosticPath'])==r['diagnosticSha256']==p['diagnosticSha256']==proposal['actual37DiagnosticPin']['sha256']
  assert r['captureBytes']==1891094 and r['diagnosticBytes']==5664984 and r['expandedSourceWorkerControllerClosureCount']==p['expandedSourceWorkerControllerClosureCount']==176
  assert v['passed'] is v['fullInverseSourceTreePassed'] is v['actualParent23CheckpointHeld'] is True and v['scope']=='ACTUAL_ROOT_SOURCE24_CAPTURE_WITH_AUTHENTIC_PARENT23_FULL_INVERSE'
  assert v['sourceOnlyProposalSha256']==stage['sourceProposal']['sha256'] and v['actualDiagnosticPath']==r['diagnosticPath'] and v['actualDiagnosticSha256']==r['diagnosticSha256']
  assert v['proposedReactElementCount']==2270 and v['genuineNewInnerPortCount']==38 and v['expectedCarrierPaths']==24 and v['missingOriginal49RequestsExpected']==25
  assert v['actualSourceTree']==d['actualProposedSource24Tree'] and v['pureSourceEvaluationExecuted'] is True
  for doc in (r,p):
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True
   for key in ('CoreCalls','nativeCalls','originalApiCalls','cliCalls','cadCalls'):assert doc[key]==0
  for key in ('typesExecuted','coreRendered','nativeExecuted','actualFreshCircuitIdsAssigned','fixReleaseQualificationPassed','originalAll11AcceptanceClaimed'):assert p[key] is False
  assert p['futureActualSource24TypesReceipt'] is p['futureActualSource24CoreReceipt'] is None
  for row in p['outputFiles']:binding(row)
  prior['actual37Source24CaptureCollectionPin']={'path':proposal['actual37CollectionPin']['path'],'sha256':proposal['actual37CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=37;prior['actual37CaptureDoesNotQualifyCoreOrNative']=True
  return prior

 def closed_prior():
  prior=closed37();assert prior['actualClosedScopeCount']==37
  r=read(proposal['actual38CollectionPin']['path']);p=read(proposal['actual38PostauditPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==95941 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_TYPES_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='types'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['source24StagesManifestPin']['sha256']
  assert r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual38GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual38PostauditPin']['sha256'] and p['execution']==e and p['actualClosedPriorScopes']==prior
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['passedMeansCompilerOnly'] is p['passedMeansCompilerOnly'] is True and r['passedMeansSourceCoreControlsOnly'] is p['passedMeansSourceCoreControlsOnly'] is False
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['policy']=={'wallSeconds':120,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['command']==['/bin/bash',stage['typesWorker']['path']]
  assert e['pgid']==480229 and e['currentGuardPid']==480096 and c.guard.process_scope.owned(e['pgid'])==[] and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['capturePath']==p['capturePath']==proposal['actualSource24CaptureOutputPin']['path'] and sha(r['capturePath'])==r['captureSha256']==p['captureSha256']==proposal['actualSource24CaptureOutputPin']['sha256']
  assert r['expandedSourceWorkerControllerClosureCount']==p['expandedSourceWorkerControllerClosureCount']==176
  assert p['rawCorePath'] is p['rawCoreSha256'] is p['coreControlsPath'] is p['coreControlsSha256'] is None
  for doc in (r,p):
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady','coreRendered'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True and doc['typesExecuted'] is True
   for key in ('CoreCalls','nativeCalls','originalApiCalls','cliCalls','cadCalls'):assert doc[key]==0
  for key in ('nativeExecuted','fixReleaseQualificationPassed','originalAll11AcceptanceClaimed'):assert p[key] is False
  assert p['futureActualSource24CoreReceipt'] is None
  for row in p['outputFiles']:binding(row)
  prior['actual38Source24TypesCollectionPin']={'path':proposal['actual38CollectionPin']['path'],'sha256':proposal['actual38CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=38;prior['actual38TypesDoesNotQualifyCoreOrNative']=True
  return prior

 def closed39():
  prior=closed_prior();assert prior['actualClosedScopeCount']==38
  for name in ('actual39CollectionPin','actual39PostauditPin','actualCoreRawPin','actualCoreControlsPin'):
   assert isinstance(proposal.get(name),dict),'Actual collected Core39 is required; draft future pins refuse execution'
   binding(proposal[name])
  r=read(proposal['actual39CollectionPin']['path']);p=read(proposal['actual39PostauditPin']['path']);v=read(proposal['actualCoreControlsPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==43066
  assert r['toolWrapperExitCode']==r['toolExitCode']==0 and r['scope']==p['scope']=='ROOT_SOURCE24_CORE_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='core'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['source24StagesManifestPin']['sha256']
  assert r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual39GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual39PostauditPin']['sha256'] and p['execution']==e and p['actualClosedPriorScopes']==prior
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['passedMeansSourceCoreControlsOnly'] is p['passedMeansSourceCoreControlsOnly'] is True and r['passedMeansCompilerOnly'] is p['passedMeansCompilerOnly'] is False
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['policy']=={'wallSeconds':180,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',stage['coreWorker']['path'],proposal['actualCoreRawPin']['path'],proposal['actualCoreControlsPin']['path'],proposal['actualSource24CaptureOutputPin']['path']]
  assert e['pgid']==480874 and e['currentGuardPid']==480851 and c.guard.process_scope.owned(e['pgid'])==[] and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['rawCorePath']==p['rawCorePath']==proposal['actualCoreRawPin']['path'] and sha(r['rawCorePath'])==r['rawCoreSha256']==p['rawCoreSha256']==proposal['actualCoreRawPin']['sha256']
  assert r['coreControlsPath']==p['coreControlsPath']==proposal['actualCoreControlsPin']['path'] and sha(r['coreControlsPath'])==r['coreControlsSha256']==p['coreControlsSha256']==proposal['actualCoreControlsPin']['sha256']
  assert v['scope']=='ROOT_FRESH_EDITABLE_SOURCE_CORE_OWNER_MOVED_227_JOINT24' and v['rawCorePath']==r['rawCorePath'] and v['rawCoreSha256']==r['rawCoreSha256']
  assert v['freshCoreControlPassed'] is True and len(v['checks'])==29 and all(x['passed'] is True for x in v['checks'])
  assert v['expectedOriginalCarrierCount']==24 and v['expectedMissingOriginalSignalCount']==25 and len(v['carriers'])==24 and len(v['actualSourcePortMatches']['registrations'])==38
  assert len(v['componentProjection'])==280 and len(v['viaProjection'])==227 and len(v['referenceProjection'])==165 and len(v['landProjection'])==1165 and len(v['signalTopProjection'])==98
  for doc in (r,p):
   assert doc['CoreCalls']==1 and doc['coreRendered'] is True and doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady','nativeExecuted'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True
  for row in p['outputFiles']:binding(row)
  prior['actual39Source24CoreCollectionPin']={'path':proposal['actual39CollectionPin']['path'],'sha256':proposal['actual39CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=39;prior['actual39CoreDoesNotQualifyNativeOrApi']=True
  return prior

 def closed40():
  prior=closed39();assert prior['actualClosedScopeCount']==39
  r=read(proposal['actual40CollectionPin']['path']);p=read(proposal['actual40PostauditPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==10372 and r['toolWrapperExitCode']==2 and r['toolExitCode']==-15
  assert r['scope']==p['scope']=='ROOT_SOURCE24_NATIVE18_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='native'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['nativePreparationPin']['sha256']
  assert r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual40GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual40PostauditPin']['sha256'] and p['execution']==e and p['actualClosedPriorScopes']==prior
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p)
  assert e['exitCode']==-15 and e['diagnosticStopped'] is True and e['accepted'] is False and e['stopReasons']==[] and e['guardError']=='RuntimeError'
  assert e['policy']=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['cleanupOwnedGroupEmpty'] is True and e['signalErrors']==[] and e['signalErrorCount']==0 and e['endedAt'] and e['wallSeconds']>0
  assert isinstance(e['oomDelta'],dict) and bool(e['oomDelta']) and not any(e['oomDelta'].values())
  assert e['pgid']==e['pid']==481468 and e['currentGuardPid']==481462 and c.guard.process_scope.owned(481468)==[] and not Path('/proc/481462').exists()
  assert e['freshLeaderIdentity']=={'pid':481468,'pgid':481468,'sid':481468,'start':23675899,'state':'R','rss':12288,'argv':[]}
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['runFailure']==p['runFailure']=='RuntimeError: Fresh owned leader command/session differs' and r['postverificationFailure'] is p['postverificationFailure'] is None
  assert r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is r['resultPassed'] is p['resultPassed'] is r['passed'] is p['passed'] is False
  assert r['nativeCalls'] is p['nativeCalls'] is None and r['reportSha256'] is p['reportSha256'] is None and r['reportPath']==p['reportPath'] and not Path(r['reportPath']).exists()
  assert r['nativeResultUnknown'] is r['identityRefusalIsNotPhysicalCheckFailure'] is r['identityRefusalCauseNotEstablished'] is True
  assert proposal['actual40ChildLogPin']['bytes']==r['childLogBytes']==0
  assert sha(r['boundManifestPath'])==r['boundManifestSha256']==r['packetSha256']==p['packetSha256']==proposal['actual40BoundManifestPin']['sha256']
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',contract['workerPin']['path'],proposal['actual40BoundManifestPin']['path'],proposal['actual40BoundManifestPin']['sha256'],proposal['actual40AuthorityPin']['path'],proposal['actual40AuthorityPin']['sha256'],r['reportPath']]
  assert r['actualCoreSha256']==p['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256']
  for doc in (r,p):
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady','coreRendered'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True and doc['CoreCalls']==0 and doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0
  for row in p['outputFiles']:binding(row)
  prior['actual40NativeIdentityRefusalCollectionPin']={'path':proposal['actual40CollectionPin']['path'],'sha256':proposal['actual40CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=40;prior['actual40NativeResultUnknownNotPhysicalFailure']=True;prior['actual40IdentityRefusalCauseUnestablished']=True
  return prior

 def closed41():
  prior=closed40();assert prior['actualClosedScopeCount']==40
  for name in ('actual41CollectionPin','actual41PostauditPin','actualNativeReportPin','actualNativeBoundManifestPin'):
   assert isinstance(proposal.get(name),dict),'Genuine collected Native success is required; future pins refuse execution'
   binding(proposal[name])
  r=read(proposal['actual41CollectionPin']['path']);p=read(proposal['actual41PostauditPin']['path']);v=read(proposal['actualNativeReportPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==80755 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_NATIVE18_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='native'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['nativePreparationPin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual41GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual41PostauditPin']['sha256'] and p['execution']==e and p['actualClosedPriorScopes']==prior
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter'] and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['policy']=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',contract['workerPin']['path'],proposal['actualNativeBoundManifestPin']['path'],proposal['actualNativeBoundManifestPin']['sha256'],proposal['actualNativeAuthorityPin']['path'],proposal['actualNativeAuthorityPin']['sha256'],proposal['actualNativeReportPin']['path']]
  assert e['pgid']==481983 and e['currentGuardPid']==481960 and c.guard.process_scope.owned(481983)==[] and not Path('/proc/481960').exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['reportPath']==p['reportPath']==proposal['actualNativeReportPin']['path'] and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actualNativeReportPin']['sha256']
  assert r['packetSha256']==p['packetSha256']==v['packetSha256']==proposal['actualNativeBoundManifestPin']['sha256'] and sha(r['boundManifestPath'])==r['boundManifestSha256']==proposal['actualNativeBoundManifestPin']['sha256']
  assert v['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and v['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256'] and v['coreSourceManifestSha256']==proposal['source24StagesManifestPin']['sha256']
  assert v['checkCount']==18 and v['physicalErrors']==0 and v['physicalCpuRamConnectedCarrierCount']==24 and v['actualNativePairFindings']==[] and not any(v['counts'].values())
  for doc in (r,p):
   assert doc['nativeCalls']==18 and doc['CoreCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0 and doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key] is False
  for row in p['outputFiles']:binding(row)
  prior['actual41NativeSuccessCollectionPin']={'path':proposal['actual41CollectionPin']['path'],'sha256':proposal['actual41CollectionPin']['sha256']}
  prior['actualClosedScopeCount']=41;prior['actual41NativePassDoesNotQualifyApiOrCad']=True
  return prior

 def closed42():
  prior=closed41();assert prior['actualClosedScopeCount']==41
  r=read(proposal['actual42CollectionPin']['path']);p=read(proposal['actual42PostauditPin']['path']);v=read(proposal['actualApiReportPin']['path']);pe=p['projectionExecution'];ae=p['apiExecution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==76367 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH49_PROJECTION_AND_API111_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='api'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['apiPreparationPin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual42GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual42PostauditPin']['sha256'] and p['actualClosedPriorScopes']==prior and r['execution']==p['execution']==ae
  assert r['projectionExecution']==pe and r['apiExecution']==ae
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter'] and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p)
  for e,pgid,wall in ((pe,483260,60),(ae,483278,90)):
   h.finite(e,0);assert e['policy']=={'wallSeconds':wall,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
   assert e['pgid']==pgid and e['currentGuardPid']==483233 and c.guard.process_scope.owned(pgid)==[] and not Path('/proc/483233').exists()
  assert r['independentlyObservedProjectionGroupEmpty'] is r['independentlyObservedApiGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  for key in ('projectionOwnedChildWaitReturned','projectionOwnedGroupEmptyActuallyObserved','apiOwnedGroupEmptyActuallyObserved','bothOwnedGroupsIndependentlyObservedEmpty','projectionBeforeApiSeriallyEnforced'):assert r[key] is p[key] is True
  assert pe['endedAt']<=ae['startedAt'] and r['reportPath']==p['reportPath']==proposal['actualApiReportPin']['path'] and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actualApiReportPin']['sha256']
  assert r['packetSha256']==p['packetSha256']==v['packetSha256'] and v['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and v['actualNativeReportSha256']==proposal['actualNativeReportPin']['sha256']
  assert v['allOriginalApiLoaded24ChecksPassed'] is True and v['actualCompleteOriginalSignalCount']==24 and v['expectedMissingOriginalSignalCount']==25
  assert v['checkInventory']['primaryBooleanPredicates']==108 and v['checkInventory']['secondaryDqs1BooleanPredicates']==3 and v['checkInventory']['primaryPlusSecondaryBooleanPredicates']==111
  assert p['actualFresh49Model']==proposal['actualFresh49ModelPin'] and p['actualFresh49ProjectionProof']==proposal['actualFresh49ProofPin']
  assert v['original49Input']=={k:proposal['actualFresh49ModelPin'][k]for k in ('path','sha256')}
  proof=read(proposal['actualFresh49ProofPin']['path']);assert proof['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and proof['actualNativeReportSha256']==proposal['actualNativeReportPin']['sha256'] and proof['constructorInputSha256']==proposal['actualFresh49ModelPin']['sha256'] and proof['exactFullInverseToFresh24Parent'] is True
  for doc in (r,p):
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True and doc['CoreCalls']==doc['nativeCalls']==doc['cliCalls']==doc['cadCalls']==0
  for row in p['outputFiles']:binding(row)
  prior['actual42Api111CollectionPin']={'path':proposal['actual42CollectionPin']['path'],'sha256':proposal['actual42CollectionPin']['sha256']};prior['actualClosedScopeCount']=42;prior['actual42TwoOwnedChildrenGenuinelyClosed']=True
  return prior

 def closed43():
  prior=closed42();assert prior['actualClosedScopeCount']==42
  for key in ('actual43CollectionPin','actual43PostauditPin','actual43GuardManifestPin','actual43AuthorityPin','actual43ChildLogPin','actual43PartialExportPin'):binding(proposal[key])
  r=read(proposal['actual43CollectionPin']['path']);p=read(proposal['actual43PostauditPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==68388 and r['toolWrapperExitCode']==2 and r['toolExitCode']==-15
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH_PINNED_CLI_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='cli'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cliPreparationPin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual43GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual43PostauditPin']['sha256'] and e==p['execution'] and p['actualClosedPriorScopes']==prior
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter'] and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p)
  assert e['exitCode']==-15 and e['diagnosticStopped'] is True and e['accepted'] is False and e['stopReasons']==['OWNED_RSS_STOP'] and 'guardError' not in e
  assert e['policy']=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['peakOwnedRssBytes']==1121136640 and e['peakOwnedRssBytes']>e['policy']['rssBytes'] and e['cleanupOwnedGroupEmpty'] is True and e['signalErrors']==[] and e['signalErrorCount']==0 and e['endedAt'] and 0<e['wallSeconds']<90
  assert isinstance(e['oomDelta'],dict) and bool(e['oomDelta']) and not any(e['oomDelta'].values())
  assert e['pgid']==e['pid']==484702 and e['currentGuardPid']==484660 and c.guard.process_scope.owned(484702)==[] and not Path('/proc/484660').exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['runFailure'] is p['runFailure'] is r['postverificationFailure'] is p['postverificationFailure'] is None
  assert r['resultInspectionFailure']==p['resultInspectionFailure']=='AssertionError: ' and r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is r['resultPassed'] is p['resultPassed'] is r['passed'] is p['passed'] is False
  assert r['cliResultUnknown'] is r['exportNotAcceptedBecauseNoNaturalCli0OrReport'] is r['resourceStopIsNotRoutingFailure'] is r['cliReportAbsent'] is True
  assert r['cliCalls'] is p['cliCalls'] is None and r['reportSha256'] is p['reportSha256'] is None and r['reportPath']==p['reportPath'] and not Path(r['reportPath']).exists()
  assert r['exportPath']==p['exportPath']==proposal['actual43PartialExportPin']['path'] and r['exportSha256']==p['exportSha256']==proposal['actual43PartialExportPin']['sha256'] and proposal['actual43PartialExportPin']['bytes']==3603790
  assert proposal['actual43ChildLogPin']['bytes']==0
  assert e['command']==[contract['pythonInterpreterPin']['path'],'-B',contract['cliWorkerPin']['path'],'--root-receipt',proposal['actual43AuthorityPin']['path'],'--root-receipt-sha256',proposal['actual43AuthorityPin']['sha256'],'--output-directory',str(Path(r['exportPath']).parent)]
  for doc in (r,p):
   assert doc['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and doc['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256']
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cadCalls']==0
  for row in p['outputFiles']:binding(row)
  prior['actual43CliResourceStopCollectionPin']={'path':proposal['actual43CollectionPin']['path'],'sha256':proposal['actual43CollectionPin']['sha256']};prior['actualClosedScopeCount']=43;prior['actual43CliCompletionUnknownResourceStopNotRoutingFailure']=True
  return prior

 def closed44():
  prior=closed43();assert prior['actualClosedScopeCount']==43
  for key in ('actual44CollectionPin','actual44PostauditPin','actual44GuardManifestPin','actual44AuthorityPin','actual44ChildLogPin','actualCliReportPin','actualCliExportPin'):binding(proposal[key])
  r=read(proposal['actual44CollectionPin']['path']);p=read(proposal['actual44PostauditPin']['path']);v=read(proposal['actualCliReportPin']['path']);e=r['execution']
  assert r['authorizedByRoot'] is r['toolSessionCollected'] is True and r['toolSessionId']==8435 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH_PINNED_CLI_WITH_AUTHENTIC_PRIOR_CLOSURES' and r['phase']==p['phase']=='cli'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==v['sourceManifestSha256']==proposal['cliPreparationPin']['sha256'] and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual44GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual44PostauditPin']['sha256'] and e==p['execution'] and p['actualClosedPriorScopes']==prior
  assert r['passed'] is p['passed'] is r['resultPassed'] is p['resultPassed'] is r['stageNaturallyCompleted'] is p['stageNaturallyCompleted'] is True
  assert r['sourceAndDependenciesHeld'] is p['sourceAndDependenciesHeld'] is p['ownedGroupEmptyActuallyObserved'] is p['workspaceFreeBytesFloorHeld'] is p['gitMetadataHeld'] is True
  assert p['dependenciesBefore']==p['dependenciesAfter'] and p['solverDependenciesBefore']==p['solverDependenciesAfter'] and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256'] and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.held_inventory_post(p);h.finite(e,0)
  assert e['policy']=={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['pgid']==e['pid']==485294 and e['currentGuardPid']==485259 and c.guard.process_scope.owned(485294)==[] and not Path('/proc/485259').exists()
  assert r['independentlyObservedOwnedGroupEmpty'] is r['independentlyObservedGuardAbsent'] is True and r['independentProcReadErrors']==[]
  assert r['runFailure'] is p['runFailure'] is r['postverificationFailure'] is p['postverificationFailure'] is r['resultInspectionFailure'] is p['resultInspectionFailure'] is None
  assert r['reportPath']==p['reportPath']==proposal['actualCliReportPin']['path'] and r['reportSha256']==p['reportSha256']==proposal['actualCliReportPin']['sha256']
  assert r['exportPath']==p['exportPath']==proposal['actualCliExportPin']['path'] and r['exportSha256']==p['exportSha256']==proposal['actualCliExportPin']['sha256']
  assert v['scope']==cli_preparation['scope'] and v['exportPassed'] is True and v['cliExitCode']==0 and v['byteIdenticalCopyOnly'] is True and v['recognizedCircuitJsonSha256']==proposal['actualCoreRawPin']['sha256']
  assert v['outputPath']==proposal['actualCliExportPin']['path'] and v['outputSha256']==proposal['actualCliExportPin']['sha256'] and proposal['actualCliExportPin']['bytes']==3603790
  assert v['actualSourceSegmentCount']==961 and v['actualSourceOwnedCarrierCount']==24 and v['actualPhysicalViaCount']==227 and v['actualPhysicalTraceCount']==287 and v['sourceOnlyMissingRoutes']==25
  assert v['nativeAndOriginalApiStagesPassed'] is True and v['actualNativeReport']==cli_preparation['actualPrerequisites']['actualNativeReport'] and v['actualOriginalApiReport']==cli_preparation['actualPrerequisites']['actualOriginalApiReport']
  assert v['argv']==[cli_preparation['bun'],'--smol',cli_preparation['cliMainPath'],'export',str(Path(v['outputPath']).parent/'fresh-source24.circuit.json'),'--format','kicad_pcb','--output',v['outputPath'],'--disable-parts-engine']
  assert e['command']==[contract['pythonInterpreterPin']['path'],'-B',contract['cliWorkerPin']['path'],'--root-receipt',proposal['actual44AuthorityPin']['path'],'--root-receipt-sha256',proposal['actual44AuthorityPin']['sha256'],'--output-directory',str(Path(v['outputPath']).parent)]
  for key in ('originalRawEdited','sourceModuleEvaluated','sourcePortHookReplayedByCli','automaticCoreSrjUsed','complete24Accepted','referenceQualified','electricalTimingQualified','accepted49','fabricationReady'):assert v[key] is False
  for doc in (r,p):
   assert doc['actualCoreSha256']==proposal['actualCoreRawPin']['sha256'] and doc['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256']
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key] is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23'] is True and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cadCalls']==0 and doc['cliCalls']==1
  for row in p['outputFiles']:binding(row)
  prior['actual44SuccessfulCli24ExportCollectionPin']={'path':proposal['actual44CollectionPin']['path'],'sha256':proposal['actual44CollectionPin']['sha256']};prior['actualClosedScopeCount']=44;prior['actual44CliPassDoesNotQualifyCadOrFull49']=True
  return prior

 def closed45():
  prior=closed44();assert prior['actualClosedScopeCount']==44
  for key in ('actual45CollectionPin','actual45PostauditPin','actual45GuardManifestPin','actual45ResourcePin','actual45ZonePinsPin','actual45CadLogPin','actual45ZoneLogPin'):binding(proposal[key])
  r=read(proposal['actual45CollectionPin']['path']);p=read(proposal['actual45PostauditPin']['path']);ze=r['zonePinsExecution'];ce=r['cadExecution'];v=read(proposal['actual45ResourcePin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==29982 and r['toolWrapperExitCode']==2 and r['toolExitCode']==1
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH_OFFLINE_CAD_WITH44_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cliPreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual45GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual45PostauditPin']['sha256']and p['actualClosedPriorScopes']==prior and r['execution']==p['execution']==ce and p['zonePinsExecution']==ze and p['cadExecution']==ce
  assert r['sourceAndDependenciesHeld']is p['sourceAndDependenciesHeld']is p['workspaceFreeBytesFloorHeld']is p['gitMetadataHeld']is True
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  for e,pgid,wall,code in ((ze,486709,60,0),(ce,486716,90,1)):
   h.finite(e,code);assert e['policy']=={'wallSeconds':wall,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
   assert e['pgid']==e['pid']==pgid and e['currentGuardPid']==486687 and c.guard.process_scope.owned(pgid)==[]and not Path('/proc/486687').exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedZoneGroupEmpty']is r['independentlyObservedCadGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert ze['endedAt']<=ce['startedAt']and r['zonePinsChildNatural0']is p['zonePinsChildNatural0']is r['zonePinsOwnedGroupEmptyActuallyObserved']is p['zonePinsOwnedGroupEmptyActuallyObserved']is True
  assert r['cadChildNatural0']is p['cadChildNatural0']is False and r['cadOwnedGroupEmptyActuallyObserved']is p['cadOwnedGroupEmptyActuallyObserved']is r['bothOwnedGroupsIndependentlyObservedEmpty']is p['bothOwnedGroupsIndependentlyObservedEmpty']is r['zoneBeforeCadSeriallyEnforced']is p['zoneBeforeCadSeriallyEnforced']is True
  assert r['resourceGateBlockedBeforeContainer']is p['resourceGateBlockedBeforeContainer']is r['actualCadApplicationCompletionUnknown']is p['actualCadApplicationCompletionUnknown']is True
  assert r['containerAbsenceNotIndependentlyRequeried']is r['priorInitialOwnedContainerAbsenceCheckCompletedByWorker']is r['resourceFailureIsNotPhysicalCheckFailure']is r['noCadReportProduced']is r['zonePinDataDerivationPassed']is True
  assert r['ownedContainerActuallyEmpty']is p['ownedContainerActuallyEmpty']is None and r['ownedContainerName']==p['ownedContainerName']==proposal['previousScope45ContainerName']
  assert r['containerResourceObservations']==p['containerResourceObservations']==v and r['containerResourceObservationsBinding']==p['containerResourceObservationsBinding']==proposal['actual45ResourcePin']
  assert v['imageId']==cli_preparation['imageId']and v['containerName']==proposal['previousScope45ContainerName']and v['cleanupStatusRecorded']is False and v['ownedContainerActuallyEmpty']is v['containerWorkerStatus']is None
  assert v['observations']==[{'phase':'BEFORE_CONTAINER','imageId':cli_preparation['imageId'],'imageSizeBytes':1519935209,'storageDriver':'vfs','dockerRootDir':'/var/lib/docker','freeBytesActuallyObserved':3275755520,'requiredVfsBytes':3308305874,'actualVfsReserveSatisfiedAtObservation':False,'imageAlreadyPresent':True,'noImageLoadBuildPull':True}]
  assert r['runFailure']is p['runFailure']is r['postverificationFailure']is p['postverificationFailure']is None and r['resultInspectionFailure']==p['resultInspectionFailure']=='Resource receipt AssertionError: ; AssertionError: '
  assert r['stageNaturallyCompleted']is p['stageNaturallyCompleted']is r['resultPassed']is p['resultPassed']is r['passed']is p['passed']is False and r['cadCalls']is p['cadCalls']is None
  assert r['reportPath']==p['reportPath']and r['reportSha256']is p['reportSha256']is None and not Path(r['reportPath']).exists()
  zone=read(proposal['actual45ZonePinsPin']['path']);assert zone['actualCoreRawSha256']==proposal['actualCoreRawPin']['sha256']and zone['actualExportPath']==proposal['actualCliExportPin']['path']and zone['actualExportSha256']==proposal['actualCliExportPin']['sha256']and zone['actualSourceKeepoutCount']==2
  assert Path(ce['command'][1]).name=='run-kicad-offline-with-snapshots.sh'and ce['command'][1]==proposal['actual45WrapperPin']['path']and ce['command'][3]==proposal['previousScope45ContainerName']and ce['command'][6]==contract['cadWorkerPin']['path']
  for doc in (r,p):
   for key in ('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23']is True and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==0 and doc['zonePinsChildInvocations']==1
  for item in p['outputFiles']:binding(item)
  prior['actual45VfsReserveRefusalCollectionPin']={'path':proposal['actual45CollectionPin']['path'],'sha256':proposal['actual45CollectionPin']['sha256']};prior['actualClosedScopeCount']=45;prior['actual45CadCompletionUnknownNotPhysicalFailure']=True
  return prior
 def closed46():
  prior=closed45();assert prior['actualClosedScopeCount']==45
  for key in ('actual46CollectionPin','actual46PostauditPin','actual46GuardManifestPin','actual46ResourcePin','actual46RecoveryReportPin','actual46ZonePinsPin','actual46CadLogPin','actual46ZoneLogPin'):binding(proposal[key])
  r=read(proposal['actual46CollectionPin']['path']);p=read(proposal['actual46PostauditPin']['path']);ze=r['zonePinsExecution'];ce=r['cadExecution'];v=read(proposal['actual46ResourcePin']['path']);recovery=read(proposal['actual46RecoveryReportPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==56016 and r['toolWrapperExitCode']==2 and r['toolExitCode']==-15
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH_OFFLINE_CAD_WITH45_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cliPreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual46GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual46PostauditPin']['sha256']and p['actualClosedPriorScopes']==prior and r['execution']==p['execution']==ce and p['zonePinsExecution']==ze and p['cadExecution']==ce
  # Original exit evidence remains failed/unknown, including the broad held flag.
  assert r['sourceAndDependenciesHeld']is p['sourceAndDependenciesHeld']is r['workspaceFreeBytesFloorHeld']is p['workspaceFreeBytesFloorHeld']is r['gitMetadataHeld']is p['gitMetadataHeld']is False
  assert r['originalPostFloorAndSourceHeldBooleansPreservedFalse']is r['originalSdkInventoryBeforeAfterByteIdentical']is True
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  h.finite(ze,0);assert ze['policy']=={'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert ce['policy']=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5,'diskFreeGuard':{'path':'/var/lib/docker','minimumFreeBytes':134217728}}
  assert ce['exitCode']==-15 and ce['diagnosticStopped']is True and ce['stopReasons']==['OWNED_DISK_FREE_STOP']and ce['accepted']is False and ce['cleanupOwnedGroupEmpty']is True
  assert ce['signalErrors']==[]and ce['signalErrorCount']==0 and isinstance(ce['oomDelta'],dict)and bool(ce['oomDelta'])and not any(ce['oomDelta'].values())
  disk=ce['diskFreeGuard'];assert disk==r['diskFreeGuardActuallyObserved']==p['diskFreeGuardActuallyObserved']=={'path':'/var/lib/docker','minimumFreeBytes':134217728,'beforeAvailableBytes':3270901760,'minimumAvailableBytesObserved':120123392,'lastAvailableBytes':120123392,'sampleCount':274,'readErrorCount':0,'lastReadErrorType':None}
  assert disk['minimumAvailableBytesObserved']<disk['minimumFreeBytes']and 0<ce['stopElapsedSeconds']<=ce['wallSeconds']<90 and ze['endedAt']<=ce['startedAt']
  for e,pgid in ((ze,488591),(ce,488592)):
   assert e['pid']==e['pgid']==pgid and e['currentGuardPid']==488542 and c.guard.process_scope.owned(pgid)==[]and not Path('/proc/488542').exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedZoneGroupEmpty']is r['independentlyObservedCadGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert r['zonePinsChildNatural0']is p['zonePinsChildNatural0']is r['zonePinsOwnedGroupEmptyActuallyObserved']is p['zonePinsOwnedGroupEmptyActuallyObserved']is True
  assert r['cadChildNatural0']is p['cadChildNatural0']is False and r['bothOwnedGroupsIndependentlyObservedEmpty']is p['bothOwnedGroupsIndependentlyObservedEmpty']is r['zoneBeforeCadSeriallyEnforced']is p['zoneBeforeCadSeriallyEnforced']is True
  assert r['runFailure']is p['runFailure']is None and r['postverificationFailure']==p['postverificationFailure']=='AssertionError: 'and r['resultInspectionFailure']==p['resultInspectionFailure']=='Resource receipt AssertionError: ; AssertionError: '
  assert r['ownedContainerActuallyEmpty']is p['ownedContainerActuallyEmpty']is None and r['ownedContainerName']==p['ownedContainerName']==proposal['previousScope46ContainerName']
  assert r['containerResourceObservations']==p['containerResourceObservations']==v and r['containerResourceObservationsBinding']==p['containerResourceObservationsBinding']==proposal['actual46ResourcePin']
  assert v['containerName']==proposal['previousScope46ContainerName']and v['imageId']==cli_preparation['imageId']and v['cleanupStatusRecorded']is False and v['ownedContainerActuallyEmpty']is v['containerWorkerStatus']is None
  assert len(v['observations'])==1 and v['observations'][0]=={'phase':'BEFORE_CONTAINER','imageId':cli_preparation['imageId'],'imageSizeBytes':1519935209,'storageDriver':'vfs','dockerRootDir':'/var/lib/docker','freeBytesActuallyObserved':3270901760,'requiredVfsBytes':3241197010,'actualVfsReserveSatisfiedAtObservation':True,'imageAlreadyPresent':True,'noImageLoadBuildPull':True,'vfsOverheadBufferBytes':201326592,'continuousDiskMinimumFreeBytesExpected':134217728}
  assert r['resourceGateBlockedBeforeContainer']is p['resourceGateBlockedBeforeContainer']is False and r['actualCadApplicationCompletionUnknown']is p['actualCadApplicationCompletionUnknown']is r['actualCadCompletionUnknown']is r['noCadReportProduced']is r['resourceFailureIsNotPhysicalCheckFailure']is True
  assert r['originalContainerStatusAtCadGuardExitRemainsUnknown']is True and r['stageNaturallyCompleted']is p['stageNaturallyCompleted']is r['resultPassed']is p['resultPassed']is r['passed']is p['passed']is False
  assert r['reportPath']==p['reportPath']and r['reportSha256']is p['reportSha256']is r['cadCalls']is p['cadCalls']is None and not Path(r['reportPath']).exists()
  assert p['workspaceFreeBytesBefore']==3270901760 and p['workspaceFreeBytesAfter']==116445184 and r['source24Adopted']is False
  # Authenticate recovery independently; never overwrite the original POST.
  assert r['scope46IncludesTwoExplicitOwnedRecoverySubscopes']is True and r['newSdkScopeOutside46OpenedForRecovery']is False
  assert r['rootCleanupReportBinding']==proposal['actual46RecoveryReportPin']and r['rootCleanupReport']==recovery and r['ownedContainerActuallyEmptyAfterRootRecovery']is r['workspaceFloorRecoveredAfterRootCleanup']is True
  assert recovery=={'scope':'ROOT_EXACT_SCOPE46_OWNED_CONTAINER_AND_SCRATCH_CLEANUP','containerName':proposal['previousScope46ContainerName'],'ownedContainerSeenBeforeCleanup':False,'ownedContainerActuallyAbsentAfterCleanup':True,'ownedScratchPath':'/tmp/g350-source24-fresh-cad.Nl6W3d','ownedScratchRemoved':True,'originalCacheFilesVerifiedUnchanged':12057,'originalCacheSymlinksVerifiedUnchanged':451,'originalCacheBytesVerifiedUnchanged':1158893348,'imageIdHeld':cli_preparation['imageId'],'workspaceFreeBytesBefore':3270901760,'workspaceFreeBytesAfter':3270901760,'originalWorkspaceFloor':3270901760,'originalWorkspaceFloorRecovered':True,'originalPostauditHeld':True,'hardwareOrSourceOrSdkOrOriginalCacheEdited':False,'accepted49':False,'fabricationReady':False}
  attempts=r['rootCleanupAttempts'];assert attempts==proposal['actual46RootCleanupAttempts']and len(attempts)==2
  for attempt,session,code,wrapper,pgid,guard,outcome in zip(attempts,(30363,35917),(1,0),(2,0),(489356,489466),(489355,489465),('OWNED_CONTAINER_CLEANUP_THEN_CACHE_SYMLINK_ASSERTION_REFUSAL','EXACT_OWNED_CLEANUP_AND_ORIGINAL_CACHE_VERIFY_PASS')):
   for key in('executionPin','logPin','sourcePin'):binding(attempt[key])
   e=attempt['execution'];assert read(attempt['executionPin']['path'])==e and attempt['toolSessionCollected']is True and attempt['toolSessionId']==session and attempt['toolWrapperExitCode']==wrapper and attempt['result']==outcome
   h.finite(e,code);assert e['policy']=={'wallSeconds':60,'rssBytes':268435456,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
   assert e['pid']==e['pgid']==pgid and e['currentGuardPid']==guard and c.guard.process_scope.owned(pgid)==[]and not Path('/proc',str(guard)).exists()and attempt['independentlyObservedGroupEmptyAndGuardAbsent']is True
   assert e['command']==['/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3','-B',attempt['sourcePin']['path']]
  assert attempts[0]['execution']['endedAt']<=attempts[1]['execution']['startedAt']and ce['endedAt']<=attempts[0]['execution']['startedAt']
  assert r['actualDiskFloorStopObserved']is r['diskSamplingIsNotKernelReservation']is True
  zone=read(proposal['actual46ZonePinsPin']['path']);assert zone['actualCoreRawSha256']==proposal['actualCoreRawPin']['sha256']and zone['actualExportPath']==proposal['actualCliExportPin']['path']and zone['actualExportSha256']==proposal['actualCliExportPin']['sha256']and zone['actualSourceKeepoutCount']==2
  for doc in(r,p):
   for key in('source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['newRoutesAdopted']==0 and doc['sourceNativeCheckedCountRemains23']is True and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==0 and doc['zonePinsChildInvocations']==1
  for item in p['outputFiles']:binding(item)
  prior['actual46RecoveredDiskFloorStopCollectionPin']={'path':proposal['actual46CollectionPin']['path'],'sha256':proposal['actual46CollectionPin']['sha256']};prior['actualClosedScopeCount']=46;prior['actual46CadCompletionUnknownWithSeparateRecovery']=True
  return prior

 def closed47():
  prior=closed46();assert prior['actualClosedScopeCount']==46
  for key in('actual47CollectionPin','actual47PostauditPin','actual47ResultPin','actual47GuardManifestPin','actual47ResourcePin'):binding(proposal[key])
  r=read(proposal['actual47CollectionPin']['path']);p=read(proposal['actual47PostauditPin']['path']);v=read(proposal['actual47ResultPin']['path']);ze=r['zonePinsExecution'];ce=r['cadExecution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==83144 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE24_FRESH_OFFLINE_CAD_WITH46_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cliPreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual47GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual47PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['execution']==p['execution']==ce and p['zonePinsExecution']==ze and p['cadExecution']==ce
  for doc in(r,p):
   for key in('sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','stageNaturallyCompleted','resultPassed','passed','zonePinsChildNatural0','cadChildNatural0','bothOwnedGroupsIndependentlyObservedEmpty','zoneBeforeCadSeriallyEnforced','ownedGroupEmptyActuallyObserved','zonePinsOwnedGroupEmptyActuallyObserved','cadOwnedGroupEmptyActuallyObserved','ownedContainerActuallyEmpty'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('resourceGateBlockedBeforeContainer','actualCadApplicationCompletionUnknown','source24Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['sourceNativeCheckedCountRemains23']is True and doc['newRoutesAdopted']==0 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==0 and doc['cadCalls']==1 and doc['zonePinsChildInvocations']==1
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  for execution,pgid,wall in((ze,490917,60),(ce,490934,90)):
   h.finite(execution,0);assert execution['pid']==execution['pgid']==pgid and execution['currentGuardPid']==490869 and c.guard.process_scope.owned(pgid)==[]and not Path('/proc/490869').exists()
   expected={'wallSeconds':wall,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
   if pgid==490934:expected['diskFreeGuard']={'path':'/var/lib/docker','minimumFreeBytes':134217728}
   assert execution['policy']==expected
  assert ze['endedAt']<=ce['startedAt']and r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedZoneGroupEmpty']is r['independentlyObservedCadGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert r['reportPath']==p['reportPath']==proposal['actual47ResultPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual47ResultPin']['sha256']and r['actualCadReportPin']==proposal['actual47ResultPin']
  assert r['actualCoreSha256']==p['actualCoreSha256']==proposal['actualCoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256']
  assert v['scope']=='SOURCE24_FRESH_CLI_AND_KICAD_WITH_ACTUAL_CORE_NATIVE_API_BINDINGS'and v['sourceManifestSha256']==proposal['cliPreparationPin']['sha256']and v['passed']is v['diagnosticCompleted']is v['nativeAndOriginalApiStagesPassed']is v['allInputBytesHeld']is True
  assert v['actualCorePath']==proposal['actualCoreRawPin']['path']and v['actualCoreSha256']==proposal['actualCoreRawPin']['sha256']and v['actualCoreControlsSha256']==proposal['actualCoreControlsPin']['sha256']and v['actualExportPath']==proposal['actualCliExportPin']['path']and v['actualExportSha256']==proposal['actualCliExportPin']['sha256']
  assert v['actualDerivedSourceSegmentCount']==961 and v['actualSourceOwnedGraphCount']==v['actual24NonzeroNetGraphCount']==v['actual24PhysicalCpuRamGraphCount']==24 and v['expectedMissingOriginalSignalCount']==25
  assert v['all287SourceTracesMappedBijectively']is True and v['actualLocalNetAgreementCount']==v['actualLocalPhysicalApproachCount']==98 and v['actualLoadedLayerCount']==4 and v['actualRetainedNativeHardwareKeepoutZones']==2 and v['actualNativeCopperPourZones']==0
  for key in('sourceRawOrSdkEdited','rawExportEdited','netRepairPerformed','saveBoardPerformed','refillPerformed','allRuleDrcPerformed','referenceQualified','electricalTimingQualified','accepted49','fabricationReady','complete24Accepted'):assert v[key]is False
  resource=read(proposal['actual47ResourcePin']['path']);assert r['containerResourceObservations']==p['containerResourceObservations']==resource and r['containerResourceObservationsBinding']==p['containerResourceObservationsBinding']==proposal['actual47ResourcePin']
  assert r['ownedContainerName']==p['ownedContainerName']==resource['containerName']==proposal['previousScope47ContainerName']and resource['imageId']==cli_preparation['imageId']and resource['ownedContainerActuallyEmpty']is resource['cleanupStatusRecorded']is True and resource['containerWorkerStatus']==0
  assert resource['previousScope45ContainerAbsenceCheckPassed']is resource['previousScope46ContainerAbsenceCheckPassed']is True and [x['phase']for x in resource['observations']]==['BEFORE_CONTAINER','AFTER_CLEANUP']
  assert all(x['imageId']==cli_preparation['imageId']and x['imageAlreadyPresent']is x['noImageLoadBuildPull']is x['actualVfsReserveSatisfiedAtObservation']is True for x in resource['observations'])
  assert r['ownedContainerAbsenceActuallyObservedByOwnedWorkerAfterCleanup']is r['rootDidNotIndependentlyRequeryDockerAfterNaturalWrapperExit']is True
  disk=r['diskFreeGuardActuallyObserved'];assert disk==p['diskFreeGuardActuallyObserved']==ce['diskFreeGuard']and disk['minimumAvailableBytesObserved']==445816832 and disk['minimumAvailableBytesObserved']>=disk['minimumFreeBytes']==134217728 and disk['readErrorCount']==0
  for item in p['outputFiles']:binding(item)
  prior['actual47SuccessfulSource24CadCollectionPin']={'path':proposal['actual47CollectionPin']['path'],'sha256':proposal['actual47CollectionPin']['sha256']};prior['actualClosedScopeCount']=47;prior['actual47CadPartial24OnlyNotFull49OrElectrical']=True
  return prior

 def guard_identity():
  row=process_runner.process(os.getpid());assert row is not None and row['pid']==os.getpid()
  return {k:row[k]for k in('pid','pgid','sid','start','argv')}
 def file_row(path):
  p=Path(path);s=p.lstat();assert p.is_file()and not p.is_symlink()and stat.S_ISREG(s.st_mode)
  return dict(path=str(p),sha256=sha(p),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
 def read_bounded(path,limit):
  p=Path(path);assert p.is_file()and not p.is_symlink()and 0<p.stat().st_size<=limit
  return read(p)
 def inspect_capture(paths):
  capture,diagnostic=paths['capture'],paths['diagnostic'];r=read_bounded(capture,5242880);d=read_bounded(diagnostic,7340032)
  assert r['scope']=='ACTUAL_ROOT_SOURCE26_CAPTURE_WITH_PARENT24_FULL_INVERSE'and d['scope']=='ACTUAL_SOURCE26_AND_PARENT24_BEFORE_INVERSE_ASSERTIONS'
  for key in('passed','fullInverseSourceTreePassed','actualParent24DeclarationsHeld','original49LogicalTracesHeld','original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse','pureSourceEvaluationExecuted','automaticCoreSrjForThisForkMustNotBeUsed','bothDqs1CoupledViewsRequireFreshOriginalApi'):assert r[key]is True
  for key,value in dict(proposedReactElementCount=2272,previousReactElementCount=2270,genuineNewInnerPortCount=40,exactNewPortDeclarations=2,exactChangedOriginalRouteDeclarations=2,exactChangedLocalSuppressions=4,exactMovedExistingViaCount=1,expectedPhysicalVias=227,expectedPhysicalTraces=289,expectedCarrierPaths=26,missingOriginal49RequestsExpected=23).items():assert r[key]==value
  assert r['movedViaName']=='V_TI_SIGNAL_source_trace_3_0'and r['movedViaCapturedPriorIdProvenanceOnly']=='pcb_via_135'and r['sourceOnlyProposalSha256']==proposal['promoted26ProposalPin']['sha256']
  assert r['actualDiagnosticPath']==str(diagnostic)and r['actualDiagnosticSha256']==sha(diagnostic)and r['actualSourceTree']==d['actualProposedSource26Tree']
  assert d['actualParent24Tree']==read(data26['inputBindings']['actualParent24Capture']['path'])['actualSourceTree']
  assert d['beforeCounts']['reactElements']==2270 and d['afterCounts']['reactElements']==2272 and d['beforeCounts']['unsupported']==d['afterCounts']['unsupported']==0 and d['inverseChecksExecuted']is False
  for key in('circuitConstructed','coreRendered','all49Accepted','fabricationReady'):assert r[key]is d[key]is False
  for key in('source24QualificationInherited','nativeExecuted','cadExecuted','singleCoupledSectionCoversBoth','referenceQualified','electricalTimingPassed'):assert r[key]is False
  return dict(sourceCapturePin=file_row(capture),sourceDiagnosticPin=file_row(diagnostic),fullSourceInversePassed=True,CoreExecuted=False)
 def inspect_core(paths,capture_pin):
  raw,controls=paths['raw'],paths['controls'];core=read_bounded(raw,16777216);r=read_bounded(controls,4194304)
  assert isinstance(core,list)and r['scope']=='ROOT_FRESH_EDITABLE_SOURCE_CORE_OWNER_MOVED_227_RESET_SOURCE3_26'
  assert r['rawCorePath']==str(raw)and r['rawCoreSha256']==sha(raw)and r['actualCapturePath']==capture_pin['path']and r['actualCaptureSha256']==capture_pin['sha256']
  assert r['freshCoreControlPassed']is True and len(r['checks'])==29 and all(x['passed']is True for x in r['checks'])
  expected={'source_component':280,'source_trace':1195,'pcb_component':507,'pcb_smtpad':1161,'pcb_plated_hole':4,'pcb_hole':2,'pcb_via':227,'source_manually_placed_via':227,'pcb_trace':289,'source_port':1655,'pcb_port':1655,'source_net':98,'source_bus':8,'pcb_keepout':2}
  for kind,count in expected.items():assert sum(row['type']==kind for row in core)==count
  assert len(r['carriers'])==26 and all(x['passed']is True for x in r['carriers'])and len(r['signalTopProjection'])==98 and all(x['passed']is True for x in r['signalTopProjection'])
  assert len(r['original49Projection'])==49 and all(x['passed']is True for x in r['original49Projection'])and len(r['viaProjection'])==227 and all(x['passed']is True for x in r['viaProjection'])
  assert len(r['actualSourcePortMatches']['registrations'])==40 and r['expectedOriginalCarrierCount']==26 and r['expectedMissingOriginalSignalCount']==23 and r['actualNonzeroWireSegmentCount']==1001
  event=r['source3OwnerEvent'];assert event['sourceViaName']=='V_TI_SIGNAL_source_trace_3_0'and event['capturedPriorViaIdProvenanceOnly']=='pcb_via_135'and event['freshIdsDerivedFromActualCore']is True and event['capturedIdAssignedToFreshCore']is False
  vp=event['actualViaProjection'];sp=event['actualTopStubProjection'];cp=event['actualCarrierProjection'];assert vp['passed']is sp['passed']is cp['passed']is True and sp['originalSourceTraceId']==cp['originalSourceTraceId']=='source_trace_3'and sp['side']==0
  via=[v for v in core if v['type']=='pcb_via'and v['pcb_via_id']==vp['actualViaId']];assert len(via)==1 and abs(via[0]['x']-6.2)<1e-8 and abs(via[0]['y']-12.4)<1e-8 and via[0]['layers']==['top','inner1','inner2','bottom']and via[0]['outer_diameter']==.4572 and via[0]['hole_diameter']==.254
  stub=[v for v in core if v['type']=='pcb_trace'and v['pcb_trace_id']==sp['actualPcbTraceId']];assert len(stub)==1 and len(stub[0]['route'])==4 and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in stub[0]['route'])
  for key in('sourceNumericAndPhysicalIdsDerivedWithoutAssignment','pcbRoutingDisabled','authoredPourLiteralsHeldByActualSourceInverse','manualPairSourceBusForkHeld','automaticCoreSrjForThisForkMustNotBeUsed','originalCouplingApisRequiredAgainstFreshActualGeometry'):assert r[key]is True
  for key in('circuitJsonGeometryEdited','parent24ActualQualificationInherited','nativeExecuted','cadExecuted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert r[key]is False
  return dict(rawCorePin=file_row(raw),coreControlsPin=file_row(controls),all29CorePredicatesPassed=True,actualCandidateCarrierCount=26,nativeQualificationPerformed=False)

 def closed48():
  prior=closed47();assert prior['actualClosedScopeCount']==47
  for key in('actual48CollectionPin','actual48PostauditPin','actual48CapturePin','actual48DiagnosticPin','actual48CoreRawPin','actual48CoreControlsPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert len(proposal['actual48PhasePostauditPins'])==3
  for row in proposal['actual48PhasePostauditPins']:binding(row)
  r=read(proposal['actual48CollectionPin']['path']);p=read(proposal['actual48PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual48ToolSessionId'])is int and r['toolSessionId']==proposal['actual48ToolSessionId']and r['toolWrapperExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE26_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH47_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='capture-types-core-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual48GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual48PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert len(p['phases'])==3 and p['orderedPhaseNames']==p['expectedPhaseNames']==['capture','types','core']and p['notAttemptedPhaseNames']==[]
  identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()
  for doc in(r,p):
   for key in('historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','allThreeChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansCaptureStrictTypesAndRawCore29Only','batchScopeContainsThreeSerialOwnedChildren','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('batchFailure','finalVerificationFailure'):assert doc[key]is None
   for key in('Source26Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
   assert doc['newRoutesAdopted']==0 and doc['CoreCalls']==doc['CoreChildInvocations']==doc['captureChildInvocations']==doc['typesChildInvocations']==1 and doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  previous=None;owned=[]
  for phase,row,pin in zip(('capture','types','core'),p['phases'],proposal['actual48PhasePostauditPins']):
   assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
   for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and sha(pin['path'])==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   e=row['execution'];h.finite(e,0);assert e['policy']==batch['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and c.guard.process_scope.owned(e['pgid'])==[]and e['pgid']not in owned
   owned.append(e['pgid'])
   if previous is not None:assert previous['endedAt']<=e['startedAt']
   previous=e
   for output in row['outputFiles']:binding(output)
   for key in('Source26Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
   assert row['nativeCalls']==row['originalApiCalls']==row['cliCalls']==row['cadCalls']==0
  capture,types,core=p['phases'];assert capture['result']['sourceCapturePin']==proposal['actual48CapturePin']and capture['result']['sourceDiagnosticPin']==proposal['actual48DiagnosticPin']and core['result']['rawCorePin']==proposal['actual48CoreRawPin']and core['result']['coreControlsPin']==proposal['actual48CoreControlsPin']
  assert capture['result']==inspect_capture(dict(capture=Path(proposal['actual48CapturePin']['path']),diagnostic=Path(proposal['actual48DiagnosticPin']['path'])))
  assert types['result']==dict(strictNoEmitTypecheckNatural0=True,actualPriorCapturePin=proposal['actual48CapturePin'])and types['outputFiles']==[]
  assert core['result']==inspect_core(dict(raw=Path(proposal['actual48CoreRawPin']['path']),controls=Path(proposal['actual48CoreControlsPin']['path'])),proposal['actual48CapturePin'])
  bun=str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe')
  assert capture['command']==[bun,'--smol',proposal['promoted26CapturePin']['path'],proposal['actual48CapturePin']['path'],proposal['actual48DiagnosticPin']['path']]
  assert types['command']==['bash',proposal['promoted26TypesPin']['path']]
  assert core['command']==[bun,'--smol',proposal['promoted26CorePin']['path'],proposal['actual48CoreRawPin']['path'],proposal['actual48CoreControlsPin']['path'],proposal['actual48CapturePin']['path']]
  prior['actual48Source26ThreeSerialCaptureTypesCoreCollectionPin']={'path':proposal['actual48CollectionPin']['path'],'sha256':proposal['actual48CollectionPin']['sha256']};prior['actualClosedScopeCount']=48;prior['actual48ThreeChildrenDoNotQualifyNativeOrFull49']=True
  return prior

 def closed49():
  prior=closed48();assert prior['actualClosedScopeCount']==48
  for key in('actual49CollectionPin','actual49PostauditPin','actual49ReportPin','actual49BoundManifestPin','actual49AuthorityPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  r=read(proposal['actual49CollectionPin']['path']);p=read(proposal['actual49PostauditPin']['path']);v=read(proposal['actual49ReportPin']['path']);e=r['execution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual49ToolSessionId'])is int and r['toolSessionId']==proposal['actual49ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE26_NATIVE18_WITH_AUTHENTIC_48_THREE_STAGE_PRIOR_CLOSURES'and r['phase']==p['phase']=='native'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['native26PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual49GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual49PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['execution']==e
  for doc in(r,p):
   for key in('passed','resultPassed','stageNaturallyCompleted','ownedChildNatural0','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','baseline169SourceHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passedMeansNative18AndActual26NumericPhysicalGraphsOnly','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('Source26Accepted','referenceQualified','electricalTimingPassed','fixReleaseQualificationPassed','originalAll11AcceptanceClaimed','all49Accepted','accepted49','fabricationReady','typesExecuted','coreRendered'):assert doc[key]is False
   assert doc['expandedSourceWorkerControllerClosureCount']==181 and doc['nativeCalls']==18 and doc['CoreCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(e,0);assert e['policy']==native_contract['policy']and type(e['pgid'])is int and e['pgid']>0 and c.guard.process_scope.owned(e['pgid'])==[]and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert r['reportPath']==p['reportPath']==proposal['actual49ReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual49ReportPin']['sha256']
  assert r['boundManifestPath']==p['boundManifestPath']==proposal['actual49BoundManifestPin']['path']and sha(r['boundManifestPath'])==r['boundManifestSha256']==p['boundManifestSha256']==r['packetSha256']==p['packetSha256']==v['packetSha256']==proposal['actual49BoundManifestPin']['sha256']
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',native_contract['workerPin']['path'],proposal['actual49BoundManifestPin']['path'],proposal['actual49BoundManifestPin']['sha256'],proposal['actual49AuthorityPin']['path'],proposal['actual49AuthorityPin']['sha256'],proposal['actual49ReportPin']['path']]
  assert r['coreSourceManifestSha256']==p['coreSourceManifestSha256']==v['coreSourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and r['actualCorePath']==p['actualCorePath']==v['actualCorePath']==proposal['actual48CoreRawPin']['path']and r['actualCoreSha256']==p['actualCoreSha256']==v['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==v['actualCoreControlsSha256']==proposal['actual48CoreControlsPin']['sha256']
  assert v['scope']=='ACTUAL_FRESH_MOVED26_CORE289_NATIVE18_PHYSICAL_AND_NUMERIC_OWNER_GRAPH_QUALIFICATION'and v['sourceManifestSha256']==proposal['native26PreparationPin']['sha256']and v['originalSource26ProposalSha256']==proposal['promoted26ProposalPin']['sha256']
  assert v['checkCount']==len(v['counts'])==18 and not any(v['counts'].values())and v['physicalErrors']==0 and v['physicalCpuRamConnectedCarrierCount']==26 and v['expectedMissingOriginalSignalCount']==23 and v['actualNativePairFindings']==[]
  proof=v['actualOwnershipProof'];assert len(proof['signalMappings'])==98 and len(proof['referenceMappings'])==165 and len(proof['carriers'])==26 and all(x['actualSourceOwnedPhysicalGraph']['physicallyConnected']is x['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is True for x in proof['carriers'])
  for key in('all165ReferencePathsPreserved','all129ReferenceBarrelsPreserved','all98SignalBarrelsAndSource26TopStubsProved','source14RamBarrelAndTopStubChangedOnlyAsExplicitlyProposed','source3CpuBarrelAndFourPointTopStubChangedOnlyAsExplicitlyProposed','source27And28CarriersChangedOnlyAsExplicitlyProposed','all49OriginalLogicalNumericRequestsPreserved','rawCircuitUnmodified','onlyAuthenticRam25Hs8PadAndStripContactRegistered','originalAll3CouplingApisAgainstActualGeometryRequiredSeparately','noCoreRenderPerformed','noRoutingPerformed','noCliOrCadPerformed','full49RoutesUnfinished'):assert v[key]is True
  for key in('circuitJsonGeometryOrIdentitiesEdited','sourceNetFabricationPerformed','globalSameNetManufacturingExemption','fullCohortTimingPassed','electricalTimingQualified','referenceQualified','complete26Accepted','accepted49','fabricationReady'):assert v[key]is False
  for row in p['outputFiles']:binding(row)
  prior['actual49Native26PhysicalSuccessCollectionPin']={'path':proposal['actual49CollectionPin']['path'],'sha256':proposal['actual49CollectionPin']['sha256']};prior['actualClosedScopeCount']=49;prior['actual49NativeDoesNotQualifyOriginalApisCliCadOrFull49']=True
  return prior

 def closed50():
  prior=closed49();assert prior['actualClosedScopeCount']==49
  for key in('actual50CollectionPin','actual50PostauditPin','actual50ModelPin','actual50ProofPin','actual50ApiReportPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert len(proposal['actual50PhasePostauditPins'])==2
  for pin in proposal['actual50PhasePostauditPins']:binding(pin)
  r=read(proposal['actual50CollectionPin']['path']);p=read(proposal['actual50PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual50ToolSessionId'])is int and r['toolSessionId']==proposal['actual50ToolSessionId']and r['toolWrapperExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE26_FRESH49_PROJECTION_AND_ORIGINAL_API119_WITH49_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='projection-api-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['native26PreparationPin']['sha256']and r['coreSourceManifestSha256']==p['coreSourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual50GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual50PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert len(p['phases'])==2 and p['orderedPhaseNames']==p['expectedPhaseNames']==['projection','api']and p['notAttemptedPhaseNames']==[]
  identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()
  for doc in(r,p):
   for key in('guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','bothChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansFresh49ProjectionAndOriginalLoaded26Api119Only','hardwareAcceptanceCheckpointUnchanged','projectionPassed','apiPassed','projectionBeforeApiSeriallyEnforced','originalApiMethodInvocationCountNotInstrumented'):assert doc[key]is True
   for key in('batchFailure','finalVerificationFailure','originalApiCalls'):assert doc[key]is None
   for key in('Source26Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['originalApiBooleanPredicates']==119 and doc['CoreCalls']==doc['nativeCalls']==doc['cliCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  owned=[];previous=None
  for phase,row,pin in zip(('projection','api'),p['phases'],proposal['actual50PhasePostauditPins']):
   assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
   for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   e=row['execution'];h.finite(e,0);assert e['policy']==api26_contract['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and e['pgid']not in owned and c.guard.process_scope.owned(e['pgid'])==[];owned.append(e['pgid'])
   if previous is not None:assert previous['endedAt']<=e['startedAt']
   previous=e
   binding(row['packetPin'])
   if row['authorityPin']is not None:binding(row['authorityPin'])
   for output in row['outputFiles']:binding(output)
   for key in('Source26Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
   assert row['CoreCalls']==row['nativeCalls']==row['cliCalls']==row['cadCalls']==0
  projection,api=p['phases'];assert p['projectionExecution']==projection['execution']and p['apiExecution']==api['execution']and len(projection['outputFiles'])==5 and len(api['outputFiles'])==1
  assert projection['result']==dict(actualFresh49Model=proposal['actual50ModelPin'],actualFresh49ProjectionProof=proposal['actual50ProofPin'],source26FreshFull49ProjectionPassed=True,actual49Requests=49,actualFixedTraces=263,actualHardObstacles=1298,actualSignalViaEvents=98,zeroSelected26CarrierBodiesSeeded=True)
  assert api['result']==dict(actualOriginalApiReportPin=proposal['actual50ApiReportPin'],originalApiLoaded26ChecksPassed=True,originalApiBooleanPredicates=119,apiMethodInvocationCount=None,methodCountNotInstrumented=True,bothDqs1CoupledViewsPassed=True,loadedCohortsExplicitlyPartial=dict(DDR_BYTE0=6,DDR_BYTE1=11,DDR_COMMAND_CLOCK=8))and api['originalApiCalls']is None and api['originalApiBooleanPredicates']==119
  assert p['actualFresh49Model']==proposal['actual50ModelPin']and p['actualFresh49ProjectionProof']==proposal['actual50ProofPin']and p['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and p['actualNativeReport']==proposal['actual49ReportPin']
  proof=read(proposal['actual50ProofPin']['path']);model=read(proposal['actual50ModelPin']['path']);v=read(proposal['actual50ApiReportPin']['path'])
  assert proof['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and proof['actualNativeReportSha256']==proposal['actual49ReportPin']['sha256']and proof['constructorInputSha256']==proposal['actual50ModelPin']['sha256']and proof['sourceManifestSha256']==proposal['promoted26ManifestPin']['sha256']and proof['originalSource26ProposalSha256']==proposal['promoted26ProposalPin']['sha256']and proof['exactFullInverseToFresh26Parent']is True
  assert len(model['connections'])==49 and len(model['traces'])==263 and len(model['obstacles'])==1298 and model['layerCount']==4 and sum(q['route_type']=='via'for t in model['traces']for q in t['route'])==98
  assert v['scope']=='ACTUAL_MOVED26_FRESH_CORE_ALL3_UNCHANGED_ORIGINAL_PRIVATE_API_DIAGNOSTIC'and v['packetSha256']==api['packetPin']['sha256']and v['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and v['actualNativeReportSha256']==proposal['actual49ReportPin']['sha256']and v['original49Input']=={k:proposal['actual50ModelPin'][k]for k in('path','sha256')}
  assert v['actualCompleteOriginalSignalCount']==26 and v['expectedMissingOriginalSignalCount']==23 and v['allOriginalApiLoaded26ChecksPassed']is True and v['checkInventory']['primaryBooleanPredicates']==116 and v['checkInventory']['secondaryDqs1BooleanPredicates']==3 and v['checkInventory']['primaryPlusSecondaryBooleanPredicates']==119
  assert v['secondaryDqs1View']['geometryAndEndpointsUnchanged']is v['secondaryDqs1View']['passed']is v['exactMaterialHeld']is v['fullOriginalBusRostersAndConstraintsHeld']is v['originalPrivateContinuousApiImplementationsUnchanged']is True
  for key in('complete26Accepted','accepted49','fabricationReady','referenceQualified','fullCohortTimingPassed','electricalDelayModelQualified'):assert v[key]is False
  assert {proposal['actual50ModelPin']['path'],proposal['actual50ProofPin']['path']}.issubset({x['path']for x in projection['outputFiles']})and api['outputFiles']==[proposal['actual50ApiReportPin']]
  assert projection['command']==[api26_contract['pythonInterpreterPin']['path'],'-B',api26_contract['projectorPin']['path'],projection['packetPin']['path'],projection['packetPin']['sha256'],str(Path(proposal['actual50ModelPin']['path']).parent)]
  assert api['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',api26_contract['apiWorkerPin']['path'],api['packetPin']['path'],api['packetPin']['sha256'],api['authorityPin']['path'],api['authorityPin']['sha256'],proposal['actual49ReportPin']['path'],proposal['actual50ApiReportPin']['path']]
  prior['actual50Fresh49AndOriginalApi119CollectionPin']={'path':proposal['actual50CollectionPin']['path'],'sha256':proposal['actual50CollectionPin']['sha256']};prior['actualClosedScopeCount']=50;prior['actual50TwoChildrenDoNotQualifyCliCadFull49OrElectrical']=True
  return prior

 def closed51():
  prior=closed50();assert prior['actualClosedScopeCount']==50
  for key in('actual51CollectionPin','actual51PostauditPin','actual51ReportPin','actual51ExportPin','actual51AuthorityPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  r=read(proposal['actual51CollectionPin']['path']);p=read(proposal['actual51PostauditPin']['path']);v=read(proposal['actual51ReportPin']['path']);e=r['execution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==14495 and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE26_FRESH_PINNED_CLI_WITH50_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cli'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli26PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual51GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual51PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['execution']==e
  for doc in(r,p):
   for key in('passed','resultPassed','stageNaturallyCompleted','ownedChildNatural0','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('Source26Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['cliCalls']==1 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(e,0);assert e['policy']==cli26_policy and e['pid']==e['pgid']==496025 and e['currentGuardPid']==495807 and c.guard.process_scope.owned(496025)==[]and not Path('/proc/495807').exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert e['command']==[cli26_contract['pythonInterpreterPin']['path'],'-B',cli26_contract['cliWorkerPin']['path'],'--root-receipt',proposal['actual51AuthorityPin']['path'],'--root-receipt-sha256',proposal['actual51AuthorityPin']['sha256'],'--output-directory',str(Path(proposal['actual51ExportPin']['path']).parent)]
  assert r['reportPath']==p['reportPath']==proposal['actual51ReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual51ReportPin']['sha256']and r['exportPath']==p['exportPath']==proposal['actual51ExportPin']['path']and sha(r['exportPath'])==r['exportSha256']==p['exportSha256']==proposal['actual51ExportPin']['sha256']
  assert r['actualCoreSha256']==p['actualCoreSha256']==v['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==v['coreControlsSha256']==proposal['actual48CoreControlsPin']['sha256']
  assert v['scope']==cli26_preparation['scope']and v['sourceManifestSha256']==proposal['cli26PreparationPin']['sha256']and v['exportPassed']is v['byteIdenticalCopyOnly']is v['nativeAndOriginalApiStagesPassed']is True and v['cliExitCode']==0
  assert v['recognizedCircuitJsonSha256']==proposal['actual48CoreRawPin']['sha256']and v['outputPath']==proposal['actual51ExportPin']['path']and v['outputSha256']==proposal['actual51ExportPin']['sha256']and v['actualSourceSegmentCount']==1001 and v['actualSourceOwnedCarrierCount']==26 and v['actualPhysicalViaCount']==227 and v['actualPhysicalTraceCount']==289 and v['sourceOnlyMissingRoutes']==23
  assert v['actualNativeReport']==proposal['actual49ReportPin']and v['actualOriginalApiReport']==proposal['actual50ApiReportPin']
  assert v['argv']==[cli26_preparation['bun'],'--smol',cli26_preparation['cliMainPath'],'export',str(Path(proposal['actual51ExportPin']['path']).parent/'fresh-source26.circuit.json'),'--format','kicad_pcb','--output',proposal['actual51ExportPin']['path'],'--disable-parts-engine']
  for key in('originalRawEdited','sourceModuleEvaluated','sourcePortHookReplayedByCli','automaticCoreSrjUsed','complete26Accepted','referenceQualified','electricalTimingQualified','accepted49','fabricationReady'):assert v[key]is False
  for row in p['outputFiles']:binding(row)
  prior['actual51Source26CliSuccessCollectionPin']={'path':proposal['actual51CollectionPin']['path'],'sha256':proposal['actual51CollectionPin']['sha256']};prior['actualClosedScopeCount']=51;prior['actual51CliDoesNotQualifyFreshCadOrFull49']=True
  return prior

 def closed52():
  prior=closed51();assert prior['actualClosedScopeCount']==51
  keys=('actual52CollectionPin','actual52PostauditPin','actual52ResultPin','actual52ResourcePin','actual52ZonePinsPin','actual52GuardManifestPin')
  for key in keys:assert isinstance(proposal[key],dict);binding(proposal[key])
  assert type(proposal['actual52ToolSessionId'])is int and type(proposal['actual52ZonePgid'])is int and type(proposal['actual52CadPgid'])is int and type(proposal['actual52GuardPid'])is int
  assert (proposal['actual52ToolSessionId'],proposal['actual52ZonePgid'],proposal['actual52CadPgid'],proposal['actual52GuardPid'])==(63739,498512,498529,498287)
  r=read(proposal['actual52CollectionPin']['path']);p=read(proposal['actual52PostauditPin']['path']);v=read(proposal['actual52ResultPin']['path']);resources=read(proposal['actual52ResourcePin']['path']);zone=read(proposal['actual52ZonePinsPin']['path']);ze=r['zonePinsExecution'];ce=r['cadExecution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==proposal['actual52ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE26_FRESH_OFFLINE_CAD_WITH51_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli26PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual52GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual52PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior
  assert r['execution']==p['execution']==ce and p['zonePinsExecution']==ze and p['cadExecution']==ce
  for doc in(r,p):
   for key in('passed','resultPassed','stageNaturallyCompleted','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','zonePinsOwnedGroupEmptyActuallyObserved','cadOwnedGroupEmptyActuallyObserved','zonePinsChildNatural0','cadChildNatural0','bothOwnedGroupsIndependentlyObservedEmpty','zoneBeforeCadSeriallyEnforced','workspaceFreeBytesFloorHeld','gitMetadataHeld','ownedContainerActuallyEmpty','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('Source26Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady','resourceGateBlockedBeforeContainer','actualCadApplicationCompletionUnknown'):assert doc[key]is False
   assert doc['cadCalls']==doc['zonePinsChildInvocations']==1 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(ze,0);h.finite(ce,0);assert ze['policy']==cad26_contract['zonePinsPolicy']and ce['policy']==cad26_contract['cadPolicy']and ze['endedAt']<=ce['startedAt']
  assert ze['pid']==ze['pgid']==proposal['actual52ZonePgid']and ce['pid']==ce['pgid']==proposal['actual52CadPgid']and ze['pgid']!=ce['pgid']and ze['currentGuardPid']==ce['currentGuardPid']==proposal['actual52GuardPid']
  assert c.guard.process_scope.owned(ze['pgid'])==c.guard.process_scope.owned(ce['pgid'])==[]and not Path('/proc',str(proposal['actual52GuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedZoneGroupEmpty']is r['independentlyObservedCadGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert r['actualCadReportPin']==proposal['actual52ResultPin']and r['ownedContainerAbsenceActuallyObservedByOwnedWorkerAfterCleanup']is r['rootDidNotIndependentlyRequeryDockerAfterNaturalWrapperExit']is True
  assert r['allCurrent52ScopesCollected']is r['source26NewlyAdoptedForPartialRoutingOnly']is True and r['rootPartialMilestoneAfterCollection']=={'previousCheckedConnections':24,'checkedConnections':26,'missingConnections':23,'fullSignalCount':49,'nativePhysicalChecksAll18Zero':True,'freshKiCadPhysicalGraphCount':26,'electricalTimingPassed':False,'referenceQualified':False,'fabricationReady':False}
  assert r['ownedContainerName']==p['ownedContainerName']==proposal['actual52ContainerName']and resources==r['containerResourceObservations']==p['containerResourceObservations']and p['containerResourceObservationsBinding']==proposal['actual52ResourcePin']
  assert resources['imageId']==cli26_preparation['imageId']and resources['containerName']==proposal['actual52ContainerName']and resources['cleanupStatusRecorded']is resources['ownedContainerActuallyEmpty']is True and resources['containerWorkerStatus']==0
  observations=resources['observations'];assert len(observations)==2 and [x['phase']for x in observations]==['BEFORE_CONTAINER','AFTER_CLEANUP']
  first=observations[0];assert first['imageId']==cli26_preparation['imageId']and first['imageSizeBytes']==1519935209 and first['storageDriver']=='vfs'and first['dockerRootDir']=='/var/lib/docker'and first['requiredVfsBytes']==2*first['imageSizeBytes']+201326592 and first['actualVfsReserveSatisfiedAtObservation']is first['imageAlreadyPresent']is first['noImageLoadBuildPull']is True and first['freeBytesActuallyObserved']>=first['requiredVfsBytes']
  disk=ce['diskFreeGuard'];assert disk['path']=='/var/lib/docker'and disk['minimumFreeBytes']==134217728 and disk['sampleCount']>=2 and disk['readErrorCount']==0 and disk['lastReadErrorType']is None and all(disk[k]>=134217728 for k in('beforeAvailableBytes','minimumAvailableBytesObserved','lastAvailableBytes'))
  assert zone['actualCoreRawSha256']==proposal['actual48CoreRawPin']['sha256']and zone['actualExportPath']==proposal['actual51ExportPin']['path']and zone['actualExportSha256']==proposal['actual51ExportPin']['sha256']and zone['actualSourceKeepoutCount']==2
  assert ce['command'][1]==proposal['cad26SnapshotWrapperPin']['path']and ce['command'][3]==proposal['actual52ContainerName']and ce['command'][6]==cad26_contract['cadWorkerPin']['path']
  assert r['reportPath']==p['reportPath']==proposal['actual52ResultPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual52ResultPin']['sha256']
  assert v['scope']==cli26_preparation['scope']and v['sourceManifestSha256']==proposal['cli26PreparationPin']['sha256']and v['passed']is v['diagnosticCompleted']is v['allInputBytesHeld']is v['nativeAndOriginalApiStagesPassed']is True
  assert v['actualCoreSha256']==proposal['actual48CoreRawPin']['sha256']and v['actualCoreControlsSha256']==proposal['actual48CoreControlsPin']['sha256']and v['actualExportPath']==proposal['actual51ExportPin']['path']and v['actualExportSha256']==proposal['actual51ExportPin']['sha256']
  assert v['actualKiCadVersion'].startswith('10.0.6')and v['actualLoadedFootprints']==507 and v['actualLoadedVias']==227 and v['actualLoadedSegments']==v['actualDerivedSourceSegmentCount']==1001 and v['actualLoadedLayerCount']==4 and v['actualRetainedNativeHardwareKeepoutZones']==2 and v['actualNativeCopperPourZones']==0 and v['all289SourceTracesMappedBijectively']is True
  assert len(v['signalObservations'])==v['actualLocalNetAgreementCount']==v['actualLocalPhysicalApproachCount']==98 and len(v['actual26GraphObservations'])==v['actual26NonzeroNetGraphCount']==v['actual26PhysicalCpuRamGraphCount']==26 and v['expectedMissingOriginalSignalCount']==23
  for key in('sourceRawOrSdkEdited','rawExportEdited','netRepairPerformed','saveBoardPerformed','refillPerformed','allRuleDrcPerformed','referenceQualified','electricalTimingQualified','complete26Accepted','accepted49','fabricationReady'):assert v[key]is False
  for row in p['outputFiles']:binding(row)
  prior['actual52Source26FreshCadSuccessCollectionPin']={'path':proposal['actual52CollectionPin']['path'],'sha256':proposal['actual52CollectionPin']['sha256']};prior['actualClosedScopeCount']=52;prior['actual52OnlyPartial26GeometryQualifiedAll49ReferenceElectricalStillFalse']=True
  return prior

 def inspect29_capture(paths):
  capture,diagnostic=paths['capture'],paths['diagnostic'];r=read_bounded(capture,5242880);d=read_bounded(diagnostic,7340032)
  assert r['scope']=='ACTUAL_ROOT_SOURCE29_CAPTURE_WITH_PARENT26_FULL_INVERSE'and d['scope']=='ACTUAL_SOURCE29_AND_PARENT26_BEFORE_INVERSE_ASSERTIONS'
  for key in('passed','fullInverseSourceTreePassed','actualParent26DeclarationsHeld','original49LogicalTracesHeld','original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse','pureSourceEvaluationExecuted','automaticCoreSrjForThisForkMustNotBeUsed','bothDqs1CoupledViewsRequireFreshOriginalApi'):assert r[key]is True
  for key,value in dict(proposedReactElementCount=2278,previousReactElementCount=2272,genuineNewInnerPortCount=46,exactNewPortDeclarations=6,exactChangedOriginalRouteDeclarations=4,exactChangedLocalSuppressions=6,exactMovedExistingViaCount=1,expectedPhysicalVias=227,expectedPhysicalTraces=292,expectedCarrierPaths=29,missingOriginal49RequestsExpected=20).items():assert r[key]==value
  assert r['movedViaName']=='V_TI_SIGNAL_source_trace_7_1'and r['movedViaCapturedPriorIdProvenanceOnly']is None and r['sourceOnlyProposalSha256']==proposal['promoted29ProposalPin']['sha256']
  assert r['actualDiagnosticPath']==str(diagnostic)and r['actualDiagnosticSha256']==sha(diagnostic)and r['actualSourceTree']==d['actualProposedSource29Tree']
  assert r['actualParent26CapturePin']=={k:proposal['actual48CapturePin'][k]for k in('path','sha256')}
  assert d['actualParent26Tree']==read(proposal['actual48CapturePin']['path'])['actualSourceTree']
  assert d['beforeCounts']['reactElements']==2272 and d['afterCounts']['reactElements']==2278 and d['beforeCounts']['unsupported']==d['afterCounts']['unsupported']==0 and d['inverseChecksExecuted']is False
  for key in('circuitConstructed','coreRendered','all49Accepted','fabricationReady'):assert r[key]is d[key]is False
  for key in('source26QualificationInherited','nativeExecuted','cadExecuted','singleCoupledSectionCoversBoth','referenceQualified','electricalTimingPassed'):assert r[key]is False
  return dict(sourceCapturePin=file_row(capture),sourceDiagnosticPin=file_row(diagnostic),fullSourceInversePassed=True,CoreExecuted=False)

 def inspect29_core(paths,capture_pin):
  raw,controls=paths['raw'],paths['controls'];core=read_bounded(raw,16777216);r=read_bounded(controls,4194304)
  assert isinstance(core,list)and r['scope']=='ROOT_FRESH_EDITABLE_SOURCE_CORE_OWNER_MOVED_227_SOURCE7_SOURCE6_SOURCE18_RESET_REPAIR_29'
  assert r['rawCorePath']==str(raw)and r['rawCoreSha256']==sha(raw)and r['actualCapturePath']==capture_pin['path']and r['actualCaptureSha256']==capture_pin['sha256']
  assert r['freshCoreControlPassed']is True and len(r['checks'])==29 and all(x['passed']is True for x in r['checks'])
  expected={'source_component':280,'source_trace':1195,'pcb_component':507,'pcb_smtpad':1161,'pcb_plated_hole':4,'pcb_hole':2,'pcb_via':227,'source_manually_placed_via':227,'pcb_trace':292,'source_port':1661,'pcb_port':1661,'source_net':98,'source_bus':8,'pcb_keepout':2}
  for kind,count in expected.items():assert sum(row['type']==kind for row in core)==count
  assert len(r['carriers'])==29 and all(x['passed']is True for x in r['carriers'])and len(r['signalTopProjection'])==98 and all(x['passed']is True for x in r['signalTopProjection'])
  assert len(r['original49Projection'])==49 and all(x['passed']is True for x in r['original49Projection'])and len(r['viaProjection'])==227 and all(x['passed']is True for x in r['viaProjection'])
  assert len(r['actualSourcePortMatches']['registrations'])==46 and r['expectedOriginalCarrierCount']==29 and r['expectedMissingOriginalSignalCount']==20 and r['actualNonzeroWireSegmentCount']==1053
  event=r['source3OwnerEvent'];assert event['sourceViaName']=='V_TI_SIGNAL_source_trace_3_0'and event['capturedPriorViaIdProvenanceOnly']=='pcb_via_135'and event['freshIdsDerivedFromActualCore']is True and event['capturedIdAssignedToFreshCore']is False
  vp=event['actualViaProjection'];sp=event['actualTopStubProjection'];cp=event['actualCarrierProjection'];assert vp['passed']is sp['passed']is cp['passed']is True and sp['originalSourceTraceId']==cp['originalSourceTraceId']=='source_trace_3'and sp['side']==0
  via=[v for v in core if v['type']=='pcb_via'and v['pcb_via_id']==vp['actualViaId']];assert len(via)==1 and abs(via[0]['x']-6.2)<1e-8 and abs(via[0]['y']-12.4)<1e-8 and via[0]['layers']==['top','inner1','inner2','bottom']and via[0]['outer_diameter']==.4572 and via[0]['hole_diameter']==.254
  stub=[v for v in core if v['type']=='pcb_trace'and v['pcb_trace_id']==sp['actualPcbTraceId']];assert len(stub)==1 and len(stub[0]['route'])==4 and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in stub[0]['route'])
  moved7=[x for x in r['viaProjection']if x['sourceViaName']=='V_TI_SIGNAL_source_trace_7_1'];stub7=[x for x in r['signalTopProjection']if x['originalSourceTraceId']=='source_trace_7'and x['side']==1];assert len(moved7)==len(stub7)==1 and moved7[0]['passed']is stub7[0]['passed']is True
  via7=[x for x in core if x['type']=='pcb_via'and x['pcb_via_id']==moved7[0]['actualViaId']];assert len(via7)==1 and abs(via7[0]['x']+7.4)<1e-8 and abs(via7[0]['y']-7.8)<1e-8 and via7[0]['layers']==['top','inner1','inner2','bottom']and via7[0]['outer_diameter']==.4572 and via7[0]['hole_diameter']==.254
  top7=[x for x in core if x['type']=='pcb_trace'and x['pcb_trace_id']==stub7[0]['actualPcbTraceId']];assert len(top7)==1 and len(top7[0]['route'])==13 and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in top7[0]['route'])
  for key in('sourceNumericAndPhysicalIdsDerivedWithoutAssignment','pcbRoutingDisabled','authoredPourLiteralsHeldByActualSourceInverse','manualPairSourceBusForkHeld','automaticCoreSrjForThisForkMustNotBeUsed','originalCouplingApisRequiredAgainstFreshActualGeometry'):assert r[key]is True
  for key in('circuitJsonGeometryEdited','parent26ActualQualificationInherited','nativeExecuted','cadExecuted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert r[key]is False
  return dict(rawCorePin=file_row(raw),coreControlsPin=file_row(controls),all29CorePredicatesPassed=True,actualCandidateCarrierCount=29,nativeQualificationPerformed=False)

 def closed53():
  prior=closed52();assert prior['actualClosedScopeCount']==52
  for key in('actual53CollectionPin','actual53PostauditPin','actual53CapturePin','actual53DiagnosticPin','actual53CoreRawPin','actual53CoreControlsPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert len(proposal['actual53PhasePostauditPins'])==3
  assert proposal['actual53ToolSessionId']==36688
  for row in proposal['actual53PhasePostauditPins']:binding(row)
  r=read(proposal['actual53CollectionPin']['path']);p=read(proposal['actual53PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual53ToolSessionId'])is int and r['toolSessionId']==proposal['actual53ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE29_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH52_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='capture-types-core-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual53GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual53PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert len(p['phases'])==3 and p['orderedPhaseNames']==p['expectedPhaseNames']==['capture','types','core']and p['notAttemptedPhaseNames']==[]
  identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()
  assert identity['pid']==500295 and [row['execution']['pgid']for row in p['phases']]==[500361,500419,500510]
  for doc in(r,p):
   for key in('historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','allThreeChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansCaptureStrictTypesAndRawCore29Only','batchScopeContainsThreeSerialOwnedChildren','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('batchFailure','finalVerificationFailure'):assert doc[key]is None
   for key in('Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
   assert doc['newRoutesAdopted']==0 and doc['CoreCalls']==doc['CoreChildInvocations']==doc['captureChildInvocations']==doc['typesChildInvocations']==1 and doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  previous=None;owned=[]
  for phase,row,pin in zip(('capture','types','core'),p['phases'],proposal['actual53PhasePostauditPins']):
   assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
   for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and sha(pin['path'])==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   e=row['execution'];h.finite(e,0);assert e['policy']==batch29['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and c.guard.process_scope.owned(e['pgid'])==[]and e['pgid']not in owned
   owned.append(e['pgid'])
   if previous is not None:assert previous['endedAt']<=e['startedAt']
   previous=e
   for output in row['outputFiles']:binding(output)
   for key in('Source29Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
   assert row['nativeCalls']==row['originalApiCalls']==row['cliCalls']==row['cadCalls']==0
  capture,types,core=p['phases'];assert capture['result']['sourceCapturePin']==proposal['actual53CapturePin']and capture['result']['sourceDiagnosticPin']==proposal['actual53DiagnosticPin']and core['result']['rawCorePin']==proposal['actual53CoreRawPin']and core['result']['coreControlsPin']==proposal['actual53CoreControlsPin']
  assert capture['result']==inspect29_capture(dict(capture=Path(proposal['actual53CapturePin']['path']),diagnostic=Path(proposal['actual53DiagnosticPin']['path'])))
  assert types['result']==dict(strictNoEmitTypecheckNatural0=True,actualPriorCapturePin=proposal['actual53CapturePin'])and types['outputFiles']==[]
  assert core['result']==inspect29_core(dict(raw=Path(proposal['actual53CoreRawPin']['path']),controls=Path(proposal['actual53CoreControlsPin']['path'])),proposal['actual53CapturePin'])
  bun=str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe')
  assert capture['command']==[bun,'--smol',proposal['promoted29CapturePin']['path'],proposal['actual53CapturePin']['path'],proposal['actual53DiagnosticPin']['path']]
  assert types['command']==['bash',proposal['promoted29TypesPin']['path']]
  assert core['command']==[bun,'--smol',proposal['promoted29CorePin']['path'],proposal['actual53CoreRawPin']['path'],proposal['actual53CoreControlsPin']['path'],proposal['actual53CapturePin']['path']]
  prior['actual53Source29ThreeSerialCaptureTypesCoreCollectionPin']={'path':proposal['actual53CollectionPin']['path'],'sha256':proposal['actual53CollectionPin']['sha256']};prior['actualClosedScopeCount']=53;prior['actual53ThreeChildrenDoNotQualifyNativeOrFull49']=True
  return prior

 def closed54():
  prior=closed53();assert prior['actualClosedScopeCount']==53
  for key in('actual54CollectionPin','actual54PostauditPin','actual54ReportPin','actual54BoundManifestPin','actual54AuthorityPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  r=read(proposal['actual54CollectionPin']['path']);p=read(proposal['actual54PostauditPin']['path']);v=read(proposal['actual54ReportPin']['path']);e=r['execution']
  assert (proposal['actual54ToolSessionId'],proposal['actual54Pgid'],proposal['actual54GuardPid'])==(90477,501788,501737)
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual54ToolSessionId'])is int and r['toolSessionId']==proposal['actual54ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE29_NATIVE18_WITH_AUTHENTIC_53_THREE_STAGE_PRIOR_CLOSURES'and r['phase']==p['phase']=='native'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['native29PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual54GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual54PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['execution']==e
  for doc in(r,p):
   for key in('passed','resultPassed','stageNaturallyCompleted','ownedChildNatural0','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','baseline169SourceHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passedMeansNative18AndActual29NumericPhysicalGraphsOnly','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('Source29Accepted','referenceQualified','electricalTimingPassed','fixReleaseQualificationPassed','originalAll11AcceptanceClaimed','all49Accepted','accepted49','fabricationReady','typesExecuted','coreRendered'):assert doc[key]is False
   assert doc['expandedSourceWorkerControllerClosureCount']==186 and doc['nativeCalls']==18 and doc['CoreCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(e,0);assert e['policy']==native29_contract['policy']and type(e['pgid'])is int and e['pgid']>0 and e['pid']==e['pgid']==proposal['actual54Pgid']and e['currentGuardPid']==proposal['actual54GuardPid']and c.guard.process_scope.owned(e['pgid'])==[]and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert r['reportPath']==p['reportPath']==proposal['actual54ReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual54ReportPin']['sha256']
  assert r['boundManifestPath']==p['boundManifestPath']==proposal['actual54BoundManifestPin']['path']and sha(r['boundManifestPath'])==r['boundManifestSha256']==p['boundManifestSha256']==r['packetSha256']==p['packetSha256']==v['packetSha256']==proposal['actual54BoundManifestPin']['sha256']
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',native29_contract['workerPin']['path'],proposal['actual54BoundManifestPin']['path'],proposal['actual54BoundManifestPin']['sha256'],proposal['actual54AuthorityPin']['path'],proposal['actual54AuthorityPin']['sha256'],proposal['actual54ReportPin']['path']]
  assert r['coreSourceManifestSha256']==p['coreSourceManifestSha256']==v['coreSourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and r['actualCorePath']==p['actualCorePath']==v['actualCorePath']==proposal['actual53CoreRawPin']['path']and r['actualCoreSha256']==p['actualCoreSha256']==v['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==v['actualCoreControlsSha256']==proposal['actual53CoreControlsPin']['sha256']
  assert v['scope']=='ACTUAL_FRESH_MOVED29_CORE292_NATIVE18_PHYSICAL_AND_NUMERIC_OWNER_GRAPH_QUALIFICATION'and v['sourceManifestSha256']==proposal['native29PreparationPin']['sha256']and v['originalSource29ProposalSha256']==proposal['promoted29ProposalPin']['sha256']
  assert v['checkCount']==len(v['counts'])==18 and not any(v['counts'].values())and v['physicalErrors']==0 and v['physicalCpuRamConnectedCarrierCount']==29 and v['expectedMissingOriginalSignalCount']==20 and v['actualNativePairFindings']==[]
  proof=v['actualOwnershipProof'];assert len(proof['signalMappings'])==98 and len(proof['referenceMappings'])==165 and len(proof['carriers'])==29 and all(x['actualSourceOwnedPhysicalGraph']['physicallyConnected']is x['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is True for x in proof['carriers'])
  for key in('all165ReferencePathsPreserved','all129ReferenceBarrelsPreserved','all98SignalBarrelsAndSource29TopStubsProved','source14RamBarrelAndTopStubChangedOnlyAsExplicitlyProposed','source3CpuBarrelAndFourPointTopStubChangedOnlyAsExplicitlyProposed','source27And28CarriersChangedOnlyAsExplicitlyProposed','source7RamBarrelAndThirteenPointTopStubChangedOnlyAsExplicitlyProposed','resetEightVertexCarrierRepairExplicit','all25OtherParent26CarriersExact','all49OriginalLogicalNumericRequestsPreserved','rawCircuitUnmodified','onlyAuthenticRam25Hs8PadAndStripContactRegistered','originalAll3CouplingApisAgainstActualGeometryRequiredSeparately','noCoreRenderPerformed','noRoutingPerformed','noCliOrCadPerformed','full49RoutesUnfinished'):assert v[key]is True
  for key in('circuitJsonGeometryOrIdentitiesEdited','sourceNetFabricationPerformed','globalSameNetManufacturingExemption','fullCohortTimingPassed','electricalTimingQualified','referenceQualified','complete26Accepted','accepted49','fabricationReady'):assert v[key]is False
  for row in p['outputFiles']:binding(row)
  prior['actual54Native29PhysicalSuccessCollectionPin']={'path':proposal['actual54CollectionPin']['path'],'sha256':proposal['actual54CollectionPin']['sha256']};prior['actualClosedScopeCount']=54;prior['actual54NativeDoesNotQualifyOriginalApisCliCadOrFull49']=True
  return prior

 def closed55():
  prior=closed54();assert prior['actualClosedScopeCount']==54
  for key in('actual55CollectionPin','actual55PostauditPin','actual55ModelPin','actual55ProofPin','actual55ApiReportPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert len(proposal['actual55PhasePostauditPins'])==2
  for pin in proposal['actual55PhasePostauditPins']:binding(pin)
  r=read(proposal['actual55CollectionPin']['path']);p=read(proposal['actual55PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual55ToolSessionId'])is int and r['toolSessionId']==proposal['actual55ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE29_FRESH49_PROJECTION_AND_ORIGINAL_API131_WITH54_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='projection-api-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['native29PreparationPin']['sha256']and r['coreSourceManifestSha256']==p['coreSourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual55GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual55PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert len(p['phases'])==2 and p['orderedPhaseNames']==p['expectedPhaseNames']==['projection','api']and p['notAttemptedPhaseNames']==[]
  identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']>0 and not Path('/proc',str(identity['pid'])).exists()
  assert proposal['actual55ToolSessionId']==20574 and identity['pid']==502956 and [x['execution']['pgid']for x in p['phases']]==[503042,503380]
  for doc in(r,p):
   for key in('guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','bothChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansFresh49ProjectionAndOriginalLoaded29Api131Only','hardwareAcceptanceCheckpointUnchanged','projectionPassed','apiPassed','projectionBeforeApiSeriallyEnforced','originalApiMethodInvocationCountNotInstrumented'):assert doc[key]is True
   for key in('batchFailure','finalVerificationFailure','originalApiCalls'):assert doc[key]is None
   for key in('Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['originalApiBooleanPredicates']==131 and doc['CoreCalls']==doc['nativeCalls']==doc['cliCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  owned=[];previous=None
  for phase,row,pin in zip(('projection','api'),p['phases'],proposal['actual55PhasePostauditPins']):
   assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
   for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   e=row['execution'];h.finite(e,0);assert e['policy']==api29_contract['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and e['pgid']not in owned and c.guard.process_scope.owned(e['pgid'])==[];owned.append(e['pgid'])
   if previous is not None:assert previous['endedAt']<=e['startedAt']
   previous=e
   binding(row['packetPin'])
   if row['authorityPin']is not None:binding(row['authorityPin'])
   for output in row['outputFiles']:binding(output)
   for key in('Source29Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
   assert row['CoreCalls']==row['nativeCalls']==row['cliCalls']==row['cadCalls']==0
  projection,api=p['phases'];assert p['projectionExecution']==projection['execution']and p['apiExecution']==api['execution']and len(projection['outputFiles'])==5 and len(api['outputFiles'])==1
  assert projection['result']==dict(actualFresh49Model=proposal['actual55ModelPin'],actualFresh49ProjectionProof=proposal['actual55ProofPin'],source29FreshFull49ProjectionPassed=True,actual49Requests=49,actualFixedTraces=263,actualHardObstacles=1298,actualSignalViaEvents=98,zeroSelected29CarrierBodiesSeeded=True)
  assert api['result']==dict(actualOriginalApiReportPin=proposal['actual55ApiReportPin'],originalApiLoaded29ChecksPassed=True,originalApiBooleanPredicates=131,apiMethodInvocationCount=None,methodCountNotInstrumented=True,bothDqs1CoupledViewsPassed=True,loadedCohortsExplicitlyPartial=dict(DDR_BYTE0=6,DDR_BYTE1=11,DDR_COMMAND_CLOCK=11))and api['originalApiCalls']is None and api['originalApiBooleanPredicates']==131
  assert p['actualFresh49Model']==proposal['actual55ModelPin']and p['actualFresh49ProjectionProof']==proposal['actual55ProofPin']and p['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and p['actualNativeReport']==proposal['actual54ReportPin']
  proof=read(proposal['actual55ProofPin']['path']);model=read(proposal['actual55ModelPin']['path']);v=read(proposal['actual55ApiReportPin']['path'])
  assert proof['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and proof['actualNativeReportSha256']==proposal['actual54ReportPin']['sha256']and proof['constructorInputSha256']==proposal['actual55ModelPin']['sha256']and proof['sourceManifestSha256']==proposal['promoted29ManifestPin']['sha256']and proof['originalSource29ProposalSha256']==proposal['promoted29ProposalPin']['sha256']and proof['exactFullInverseToFresh29Parent']is True
  assert len(model['connections'])==49 and len(model['traces'])==263 and len(model['obstacles'])==1298 and model['layerCount']==4 and sum(q['route_type']=='via'for t in model['traces']for q in t['route'])==98
  assert v['scope']=='ACTUAL_MOVED29_FRESH_CORE_ALL3_UNCHANGED_ORIGINAL_PRIVATE_API_DIAGNOSTIC'and v['packetSha256']==api['packetPin']['sha256']and v['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and v['actualNativeReportSha256']==proposal['actual54ReportPin']['sha256']and v['original49Input']=={k:proposal['actual55ModelPin'][k]for k in('path','sha256')}
  assert v['actualCompleteOriginalSignalCount']==29 and v['expectedMissingOriginalSignalCount']==20 and v['allOriginalApiLoaded26ChecksPassed']is True and v['checkInventory']['primaryBooleanPredicates']==128 and v['checkInventory']['secondaryDqs1BooleanPredicates']==3 and v['checkInventory']['primaryPlusSecondaryBooleanPredicates']==131
  assert v['secondaryDqs1View']['geometryAndEndpointsUnchanged']is v['secondaryDqs1View']['passed']is v['exactMaterialHeld']is v['fullOriginalBusRostersAndConstraintsHeld']is v['originalPrivateContinuousApiImplementationsUnchanged']is True
  for key in('complete26Accepted','accepted49','fabricationReady','referenceQualified','fullCohortTimingPassed','electricalDelayModelQualified'):assert v[key]is False
  assert {proposal['actual55ModelPin']['path'],proposal['actual55ProofPin']['path']}.issubset({x['path']for x in projection['outputFiles']})and api['outputFiles']==[proposal['actual55ApiReportPin']]
  assert projection['command']==[api29_contract['pythonInterpreterPin']['path'],'-B',api29_contract['projectorPin']['path'],projection['packetPin']['path'],projection['packetPin']['sha256'],str(Path(proposal['actual55ModelPin']['path']).parent)]
  assert api['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',api29_contract['apiWorkerPin']['path'],api['packetPin']['path'],api['packetPin']['sha256'],api['authorityPin']['path'],api['authorityPin']['sha256'],proposal['actual54ReportPin']['path'],proposal['actual55ApiReportPin']['path']]
  prior['actual55Fresh49AndOriginalApi131CollectionPin']={'path':proposal['actual55CollectionPin']['path'],'sha256':proposal['actual55CollectionPin']['sha256']};prior['actualClosedScopeCount']=55;prior['actual55TwoChildrenDoNotQualifyCliCadFull49OrElectrical']=True
  return prior


 def closed56():
   prior=closed55();assert prior['actualClosedScopeCount']==55
   for key in('actual56CollectionPin','actual56PostauditPin','actual56ReportPin','actual56ExportPin','actual56AuthorityPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
   r=read(proposal['actual56CollectionPin']['path']);p=read(proposal['actual56PostauditPin']['path']);v=read(proposal['actual56ReportPin']['path']);e=r['execution']
   assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==proposal['actual56ToolSessionId'] and r['toolWrapperExitCode']==r['toolExitCode']==0
   assert r['scope']==p['scope']=='ROOT_SOURCE29_FRESH_PINNED_CLI_WITH55_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cli'
   assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual56GuardManifestPin']['sha256']
   assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual56PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['execution']==e
   for doc in(r,p):
    for key in('passed','resultPassed','stageNaturallyCompleted','ownedChildNatural0','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
    for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
    for key in('Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
    assert doc['cliCalls']==1 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
   assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
   h.finite(e,0);assert e['policy']==cli29_policy and e['pid']==e['pgid']==proposal['actual56Pgid'] and e['currentGuardPid']==proposal['actual56GuardPid'] and c.guard.process_scope.owned(proposal['actual56Pgid'])==[]and not Path('/proc',str(proposal['actual56GuardPid'])).exists()
   assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
   assert e['command']==[cli29_contract['pythonInterpreterPin']['path'],'-B',cli29_contract['cliWorkerPin']['path'],'--root-receipt',proposal['actual56AuthorityPin']['path'],'--root-receipt-sha256',proposal['actual56AuthorityPin']['sha256'],'--output-directory',str(Path(proposal['actual56ExportPin']['path']).parent)]
   assert r['reportPath']==p['reportPath']==proposal['actual56ReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual56ReportPin']['sha256']and r['exportPath']==p['exportPath']==proposal['actual56ExportPin']['path']and sha(r['exportPath'])==r['exportSha256']==p['exportSha256']==proposal['actual56ExportPin']['sha256']
   assert r['actualCoreSha256']==p['actualCoreSha256']==v['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==v['coreControlsSha256']==proposal['actual53CoreControlsPin']['sha256']
   assert v['scope']==cli29_preparation['scope']and v['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and v['exportPassed']is v['byteIdenticalCopyOnly']is v['nativeAndOriginalApiStagesPassed']is True and v['cliExitCode']==0
   assert v['recognizedCircuitJsonSha256']==proposal['actual53CoreRawPin']['sha256']and v['outputPath']==proposal['actual56ExportPin']['path']and v['outputSha256']==proposal['actual56ExportPin']['sha256']and v['actualSourceSegmentCount']==1053 and v['actualSourceOwnedCarrierCount']==29 and v['actualPhysicalViaCount']==227 and v['actualPhysicalTraceCount']==292 and v['sourceOnlyMissingRoutes']==20
   assert v['actualNativeReport']==proposal['actual54ReportPin']and v['actualOriginalApiReport']==proposal['actual55ApiReportPin']
   assert v['argv']==[cli29_preparation['bun'],'--smol',cli29_preparation['cliMainPath'],'export',str(Path(proposal['actual56ExportPin']['path']).parent/'fresh-source29.circuit.json'),'--format','kicad_pcb','--output',proposal['actual56ExportPin']['path'],'--disable-parts-engine']
   for key in('originalRawEdited','sourceModuleEvaluated','sourcePortHookReplayedByCli','automaticCoreSrjUsed','complete29Accepted','referenceQualified','electricalTimingQualified','accepted49','fabricationReady'):assert v[key]is False
   for row in p['outputFiles']:binding(row)
   prior['actual56Source29CliSuccessCollectionPin']={'path':proposal['actual56CollectionPin']['path'],'sha256':proposal['actual56CollectionPin']['sha256']};prior['actualClosedScopeCount']=56;prior['actual56CliDoesNotQualifyFreshCadOrFull49']=True
   return prior


 def closed57():
  prior=closed56();assert prior['actualClosedScopeCount']==56
  for key in('actual57FailedCollectionPin','actual57ZoneExecutionPin','actual57UnspawnedCadExecutionPin','actual57ZonePinsPin','actual57GuardManifestPin'):binding(proposal[key])
  r=read(proposal['actual57FailedCollectionPin']['path']);zone=read(proposal['actual57ZoneExecutionPin']['path']);attempt=read(proposal['actual57UnspawnedCadExecutionPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==98055 and r['toolExitCode']==r['toolWrapperExitCode']==1 and r['passed']is False
  assert r['scope']=='ROOT_SOURCE29_CAD57_ZONE_ONLY_CAD_PREFORK_REJECTED_POSTAUDIT_CRASH_RECOVERY'and r['phase']=='cad-prefork-failure'
  assert r['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==proposal['actual57GuardManifestPin']['sha256']and r['actualClosedPriorScopes']==prior
  assert r['zonePinsExecutionPin']==proposal['actual57ZoneExecutionPin']and r['cadAttemptExecutionPin']==proposal['actual57UnspawnedCadExecutionPin']and r['actualSourceZonePins']==proposal['actual57ZonePinsPin']
  assert r['zonePinsExecution']==zone and r['unspawnedCadAttemptExecution']==attempt
  h.finite(zone,0);assert zone['policy']==cad29_contract['zonePinsPolicy']and zone['pid']==zone['pgid']==506788 and zone['currentGuardPid']==506698 and c.guard.process_scope.owned(506788)==[]and not Path('/proc/506698').exists()
  assert 'pid'not in attempt and 'pgid'not in attempt and attempt['exitCode']is None and attempt['cleanupOwnedGroupEmpty']is None and attempt['diagnosticStopped']is True and attempt['guardError']=='AssertionError'and attempt['stopReasons']==[]
  assert attempt['policy']==cad29_contract['cadPolicy']and attempt['currentGuardPid']==506698 and not any(attempt['oomDelta'].values())and attempt['signalErrors']==[]and attempt['diskFreeGuard']['sampleCount']==0
  assert r['originalCadExitCode']is r['originalCadCleanupOwnedGroupEmpty']is r['completeSdkPostauditHeld']is None
  for key in('zonePinsChildNatural0','actualCadApplicationCompletionUnknown','memoryAdmissionGateWouldRejectObservedSnapshot','resourceReceiptAbsent','outputDirectoryEmpty','completeSdkPostauditUnavailableBecauseGuardCrashed','independentlyObservedAllActuallySpawnedOwnedGroupsEmpty','independentlyObservedGuardAbsent'):assert r[key]is True
  for key in('cadChildPidOrPgidAllocated','cadWrapperSpawned','cadApplicationInvoked','containerInvocationPerformed','originalPostauditProduced','Source29Accepted','accepted49','fabricationReady','referenceQualified','electricalTimingPassed'):assert r[key]is False
  assert r['guardPostauditFailure']=='KeyError: pgid in zoneBeforeCadSeriallyEnforced expression'and r['observedMemoryBeforeBytes']==attempt['memoryBefore']['current']==27931193344 and r['requiredProcessContainerAndSafetyReserveBytes']==4294967296 and r['sharedCapBytes']==32212254720 and r['observedAdmissionExcessBytes']==13905920
  assert r['observedMemoryBeforeBytes']+r['requiredProcessContainerAndSafetyReserveBytes']-r['sharedCapBytes']==r['observedAdmissionExcessBytes']and r['diskSamples']==0
  assert r['independentlyObservedOwnedGroupMembers']=={'506788':[]}and r['independentProcReadErrors']==[]and r['actualClosedScopeCount']==57
  assert not Path(proposal['original57RunRoot'],'POSTAUDIT.json').exists()and not Path(proposal['original57RunRoot'],'cad-resource-observations.json').exists()and not any(Path(proposal['original57RunRoot'],'output').iterdir())
  z=read(proposal['actual57ZonePinsPin']['path']);assert z['actualCoreRawSha256']==proposal['actual53CoreRawPin']['sha256']and z['actualExportSha256']==proposal['actual56ExportPin']['sha256']and z['actualSourceKeepoutCount']==2
  prior['actual57ZoneOnlyCadPreforkRefusalPostauditCrashCollectionPin']={k:proposal['actual57FailedCollectionPin'][k]for k in('path','sha256')};prior['actual57CadNeverSpawnedOriginalExitAndSdkPostUnknown']=True;prior['actualClosedScopeCount']=57
  return prior


 def closed58():
  prior=closed57();assert prior['actualClosedScopeCount']==57
  for key in('actual58FailedCollectionPin','actual58PostauditPin','actual58ZoneExecutionPin','actual58UnspawnedCadExecutionPin','actual58ZonePinsPin','actual58GuardManifestPin'):binding(proposal[key])
  r=read(proposal['actual58FailedCollectionPin']['path']);p=read(proposal['actual58PostauditPin']['path']);zone=read(proposal['actual58ZoneExecutionPin']['path']);attempt=read(proposal['actual58UnspawnedCadExecutionPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==59882 and r['toolWrapperExitCode']==r['toolExitCode']==2 and r['passed']is False
  assert r['scope']==p['scope']=='ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH57_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual58GuardManifestPin']['sha256']
  assert r['postauditPath']==proposal['actual58PostauditPin']['path']and r['postauditSha256']==proposal['actual58PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior
  assert r['execution']==p['execution']==r['cadExecution']==p['cadExecution']==attempt and r['zonePinsExecution']==p['zonePinsExecution']==zone
  h.finite(zone,0);assert zone['policy']==cad29_contract['zonePinsPolicy']and zone['pid']==zone['pgid']==507769 and zone['currentGuardPid']==507764 and c.guard.process_scope.owned(507769)==[]and not Path('/proc/507764').exists()
  assert 'pid'not in attempt and 'pgid'not in attempt and attempt['exitCode']is None and attempt['cleanupOwnedGroupEmpty']is None and attempt['diagnosticStopped']is True and attempt['guardError']=='AssertionError'and attempt['stopReasons']==[]
  assert attempt['policy']==cad29_contract['cadPolicy']and attempt['currentGuardPid']==507764 and not any(attempt['oomDelta'].values())and attempt['signalErrors']==[]and attempt['diskFreeGuard']['sampleCount']==0
  for doc in(r,p):
   for key in('sourceAndDependenciesHeld','zonePinsOwnedGroupEmptyActuallyObserved','zonePinsChildNatural0','actualCadApplicationCompletionUnknown','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('passed','resultPassed','stageNaturallyCompleted','cadChildNatural0','zoneBeforeCadSeriallyEnforced','cadOwnedGroupEmptyActuallyObserved','bothOwnedGroupsIndependentlyObservedEmpty','ownedGroupEmptyActuallyObserved','Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['ownedContainerActuallyEmpty']is doc['containerResourceObservations']is doc['containerResourceObservationsBinding']is doc['reportSha256']is doc['cadCalls']is None
   assert doc['postverificationFailure']is None and doc['runFailure']=='AssertionError: 'and doc['resultInspectionFailure']=='AssertionError: 'and doc['zonePinsChildInvocations']==1
   assert doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['newRoutesAdopted']==doc['workspaceDataCopiesPerformed']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  assert r['cadWrapperSpawned']is r['cadApplicationInvoked']is r['containerInvocationPerformed']is False and r['resourceReceiptAbsent']is r['outputDirectoryEmpty']is True
  assert r['independentlyObservedAllActuallySpawnedOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentlyObservedOwnedGroupMembers']=={'507769':[]}and r['independentProcReadErrors']==[]
  assert attempt['memoryBefore']['current']==27967787008 and r['memoryAdmissionExcessAtObservedBeforeSnapshotBytes']==50499584 and attempt['memoryBefore']['current']+4294967296-attempt['policy']['sharedBytes']==50499584
  assert not Path(p['reportPath']).exists()and not Path(proposal['original58RunRoot'],'cad-resource-observations.json').exists()and not any(Path(proposal['original58RunRoot'],'output').iterdir())
  z=read(proposal['actual58ZonePinsPin']['path']);assert z['actualCoreRawSha256']==proposal['actual53CoreRawPin']['sha256']and z['actualExportSha256']==proposal['actual56ExportPin']['sha256']and z['actualSourceKeepoutCount']==2
  prior['actual58ZoneOnlyCadPreforkRefusalTruthfulPostCollectionPin']={k:proposal['actual58FailedCollectionPin'][k]for k in('path','sha256')};prior['actual58CadNeverSpawnedExitCleanupUnknownFullSdkPostHeld']=True;prior['actualClosedScopeCount']=58
  return prior


 def closed59():
  prior=closed58();assert prior['actualClosedScopeCount']==58
  for key in('actual59FailedCollectionPin','actual59PostauditPin','actual59ZoneExecutionPin','actual59CadExecutionPin','actual59ZonePinsPin','actual59WorkerFailureReportPin','actual59ResourcePin','actual59GuardManifestPin','actual59SnapshotWrapperPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  r=read(proposal['actual59FailedCollectionPin']['path']);p=read(proposal['actual59PostauditPin']['path']);v=read(proposal['actual59WorkerFailureReportPin']['path']);resource=read(proposal['actual59ResourcePin']['path']);zone=read(proposal['actual59ZonePinsPin']['path']);ze=r['zonePinsExecution'];ce=r['cadExecution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==31552 and r['toolWrapperExitCode']==r['toolExitCode']==2
  assert r['scope']==p['scope']=='ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH58_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual59GuardManifestPin']['sha256']
  assert r['postauditPath']==proposal['actual59PostauditPin']['path']and sha(r['postauditPath'])==r['postauditSha256']==proposal['actual59PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior
  assert read(proposal['actual59ZoneExecutionPin']['path'])==ze==p['zonePinsExecution']and read(proposal['actual59CadExecutionPin']['path'])==ce==p['cadExecution']==p['execution']==r['execution']
  for doc in(r,p):
   for key in('sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareAcceptanceCheckpointUnchanged','ownedGroupEmptyActuallyObserved','zonePinsOwnedGroupEmptyActuallyObserved','cadOwnedGroupEmptyActuallyObserved','bothOwnedGroupsIndependentlyObservedEmpty','zoneBeforeCadSeriallyEnforced','zonePinsChildNatural0'):assert doc[key]is True
   for key in('passed','resultPassed','stageNaturallyCompleted','cadChildNatural0','resourceGateBlockedBeforeContainer','Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['ownedContainerActuallyEmpty']is None and doc['actualCadApplicationCompletionUnknown']is True and doc['cadCalls']is None
   assert doc['runFailure']is doc['postverificationFailure']is None and doc['resultInspectionFailure']=='Resource receipt AssertionError: ; AssertionError: '
   assert doc['zonePinsChildInvocations']==1 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(ze,0);h.finite(ce,2);assert ze['policy']==cad29_contract['zonePinsPolicy']and ce['policy']==cad29_contract['cadPolicy']and ze['endedAt']<=ce['startedAt']
  assert ze['pid']==ze['pgid']==508276 and ce['pid']==ce['pgid']==508277 and ze['currentGuardPid']==ce['currentGuardPid']==508271
  assert c.guard.process_scope.owned(508276)==c.guard.process_scope.owned(508277)==[]and not Path('/proc/508271').exists()
  assert r['independentlyObservedAllActuallySpawnedOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentlyObservedOwnedGroupMembers']=={'508276':[],'508277':[]}and r['independentProcReadErrors']==[]
  assert r['cadWrapperSpawned']is r['containerInvocationPerformed']is r['cadDiagnosticWorkerInvoked']is r['workerFailedBeforeCadBoardLoad']is True
  assert r['actualKiCadLoadBoardPerformed']is r['actualConnectivityDiagnosticPerformed']is False and r['diagnosticFailure']==v['failure']=='ValueError: Absolute regular artifact'
  # Root and the owned resource reporter establish absence separately; preserve the outer POST null.
  assert r['rootIndependentExactContainerPsWrapperExitCode']==0 and r['rootIndependentlyObservedOwnedContainerAbsent']is r['containerCleanupEvidenceActuallyEmpty']is r['outerPostContainerEmptyRemainsNull']is True
  assert resource==r['containerResourceObservations']==p['containerResourceObservations']and p['containerResourceObservationsBinding']==r['containerCleanupEvidenceBinding']==proposal['actual59ResourcePin']
  assert resource['scope']=='ROOT_OWNED_CAD_CHILD_ACTUAL_DOCKER_RESOURCES'and resource['imageId']==cli29_preparation['imageId']and resource['containerName']==r['ownedContainerName']==p['ownedContainerName']=='g350-source29-fresh-cad-26a8fb65e40f70d0-b128c08f004e8974'
  assert resource['cleanupStatusRecorded']is resource['ownedContainerActuallyEmpty']is True and resource['containerWorkerStatus']==2
  observations=resource['observations'];assert len(observations)==2 and [x['phase']for x in observations]==['BEFORE_CONTAINER','AFTER_CLEANUP']
  for x in observations:assert x['imageId']==cli29_preparation['imageId']and x['imageSizeBytes']==1519935209 and x['storageDriver']=='vfs'and x['dockerRootDir']=='/var/lib/docker'and x['requiredVfsBytes']==2*x['imageSizeBytes']+201326592 and x['actualVfsReserveSatisfiedAtObservation']is x['imageAlreadyPresent']is x['noImageLoadBuildPull']is True and x['freeBytesActuallyObserved']>=x['requiredVfsBytes']
  disk=ce['diskFreeGuard'];assert disk==p['diskFreeGuardActuallyObserved']and disk['path']=='/var/lib/docker'and disk['minimumFreeBytes']==134217728 and disk['sampleCount']>=2 and disk['readErrorCount']==0 and disk['lastReadErrorType']is None and all(disk[k]>=134217728 for k in('beforeAvailableBytes','minimumAvailableBytesObserved','lastAvailableBytes'))
  assert ce['command'][1]==proposal['actual59SnapshotWrapperPin']['path']and ce['command'][3]==resource['containerName']and ce['command'][6]==cad29_contract['cadWorkerPin']['path']
  assert zone['actualCoreRawSha256']==r['actualCoreSha256']==p['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and zone['actualExportPath']==proposal['actual56ExportPin']['path']and zone['actualExportSha256']==proposal['actual56ExportPin']['sha256']and zone['actualSourceKeepoutCount']==2
  assert r['reportPath']==p['reportPath']==proposal['actual59WorkerFailureReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual59WorkerFailureReportPin']['sha256']and r['cadWorkerFailureReportBinding']==proposal['actual59WorkerFailureReportPin']
  assert v['scope']==cli29_preparation['scope']and v['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and v['allInputBytesHeld']is True and v['status']=='FAILED_FRESH_KICAD_SOURCE29_NARROW_DIAGNOSTIC'
  assert v['passed']is v['diagnosticCompleted']is v['nativeAndOriginalApiStagesPassed']is v['complete29Accepted']is v['accepted49']is v['fabricationReady']is False
  assert v['actualOriginalApiReport']==proposal['actual55ApiReportPin']and v['actualNativeStageReport']==proposal['actual54ReportPin']and v['actualCollectedNativeToolWrapperExitCode']is v['actualNativePhysicalChildExitCode']is v['actualOriginalApiChildExitCode']is None
  for key in('apiAnglesFailed','geometryFixesPending','sourceRawOrSdkEdited','rawExportEdited','netRepairPerformed','saveBoardPerformed','refillPerformed','allRuleDrcPerformed','referenceQualified','electricalTimingQualified'):assert v[key]is False
  assert v['actualOriginalApiAngleFailures']==[]and v['expectedMissingOriginalSignalCount']==20 and r['currentCheckedConnections']==26 and r['currentMissingConnections']==23
  for row in p['outputFiles']:binding(row)
  prior['actual59ContainerWorkerPreconditionFailureCollectionPin']={k:proposal['actual59FailedCollectionPin'][k]for k in('path','sha256')};prior['actual59WorkerBeforePcbLoadFailedNoHardwareQualification']=True;prior['actual59OuterContainerEmptyNullAndCompletionUnknownPreserved']=True;prior['actualClosedScopeCount']=59
  return prior

 def closed60():
  prior=closed59();assert prior['actualClosedScopeCount']==59
  keys=('actual60CollectionPin','actual60PostauditPin','actual60ReportPin','actual60ResourcePin','actual60ZonePinsPin','actual60GuardManifestPin')
  for key in keys:assert isinstance(proposal[key],dict);binding(proposal[key])
  assert type(proposal['actual60ToolSessionId'])is int and type(proposal['actual60ZonePgid'])is int and type(proposal['actual60CadPgid'])is int and type(proposal['actual60GuardPid'])is int
  r=read(proposal['actual60CollectionPin']['path']);p=read(proposal['actual60PostauditPin']['path']);v=read(proposal['actual60ReportPin']['path']);resources=read(proposal['actual60ResourcePin']['path']);zone=read(proposal['actual60ZonePinsPin']['path']);ze=r['zonePinsExecution'];ce=r['cadExecution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==proposal['actual60ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH59_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual60GuardManifestPin']['sha256']
  assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual60PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior
  assert r['execution']==p['execution']==ce and p['zonePinsExecution']==ze and p['cadExecution']==ce
  for doc in(r,p):
   for key in('passed','resultPassed','stageNaturallyCompleted','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','zonePinsOwnedGroupEmptyActuallyObserved','cadOwnedGroupEmptyActuallyObserved','zonePinsChildNatural0','cadChildNatural0','bothOwnedGroupsIndependentlyObservedEmpty','zoneBeforeCadSeriallyEnforced','workspaceFreeBytesFloorHeld','gitMetadataHeld','ownedContainerActuallyEmpty','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
   for key in('Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady','resourceGateBlockedBeforeContainer','actualCadApplicationCompletionUnknown'):assert doc[key]is False
   assert doc['cadCalls']==doc['zonePinsChildInvocations']==1 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(ze,0);h.finite(ce,0);assert ze['policy']==cad29_contract['zonePinsPolicy']and ce['policy']==cad29_contract['cadPolicy']and ze['endedAt']<=ce['startedAt']
  assert ze['pid']==ze['pgid']==proposal['actual60ZonePgid']and ce['pid']==ce['pgid']==proposal['actual60CadPgid']and ze['pgid']!=ce['pgid']and ze['currentGuardPid']==ce['currentGuardPid']==proposal['actual60GuardPid']
  assert c.guard.process_scope.owned(ze['pgid'])==c.guard.process_scope.owned(ce['pgid'])==[]and not Path('/proc',str(proposal['actual60GuardPid'])).exists()
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedAllActuallySpawnedOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
  assert r['independentlyObservedOwnedGroupMembers']=={str(proposal['actual60ZonePgid']):[],str(proposal['actual60CadPgid']):[]}
  assert r['rootIndependentExactContainerPsWrapperExitCode']==0 and r['rootIndependentlyObservedOwnedContainerAbsent']is True
  assert r['successfulNarrow29Only']is True and r['partialAdoptionPerformedByThisCollection']is False and r['currentCheckedConnections']==26 and r['currentMissingConnections']==23
  assert r['ownedContainerName']==p['ownedContainerName']==proposal['actual60ContainerName']and resources==r['containerResourceObservations']==p['containerResourceObservations']and p['containerResourceObservationsBinding']==proposal['actual60ResourcePin']
  assert resources['imageId']==cli29_preparation['imageId']and resources['containerName']==proposal['actual60ContainerName']and resources['cleanupStatusRecorded']is resources['ownedContainerActuallyEmpty']is True and resources['containerWorkerStatus']==0
  observations=resources['observations'];assert len(observations)==2 and [x['phase']for x in observations]==['BEFORE_CONTAINER','AFTER_CLEANUP']
  first=observations[0];assert first['imageId']==cli29_preparation['imageId']and first['imageSizeBytes']==1519935209 and first['storageDriver']=='vfs'and first['dockerRootDir']=='/var/lib/docker'and first['requiredVfsBytes']==2*first['imageSizeBytes']+201326592 and first['actualVfsReserveSatisfiedAtObservation']is first['imageAlreadyPresent']is first['noImageLoadBuildPull']is True and first['freeBytesActuallyObserved']>=first['requiredVfsBytes']
  disk=ce['diskFreeGuard'];assert disk['path']=='/var/lib/docker'and disk['minimumFreeBytes']==134217728 and disk['sampleCount']>=2 and disk['readErrorCount']==0 and disk['lastReadErrorType']is None and all(disk[k]>=134217728 for k in('beforeAvailableBytes','minimumAvailableBytesObserved','lastAvailableBytes'))
  assert zone['actualCoreRawSha256']==proposal['actual53CoreRawPin']['sha256']and zone['actualExportPath']==proposal['actual56ExportPin']['path']and zone['actualExportSha256']==proposal['actual56ExportPin']['sha256']and zone['actualSourceKeepoutCount']==2
  assert ce['command'][1]==proposal['cad29SnapshotWrapperPin']['path']and ce['command'][3]==proposal['actual60ContainerName']and ce['command'][6]==cad29_contract['cadWorkerPin']['path']
  assert r['reportPath']==p['reportPath']==proposal['actual60ReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual60ReportPin']['sha256']
  assert v['scope']==cli29_preparation['scope']and v['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and v['passed']is v['diagnosticCompleted']is v['allInputBytesHeld']is v['nativeAndOriginalApiStagesPassed']is True
  assert v['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and v['actualCoreControlsSha256']==proposal['actual53CoreControlsPin']['sha256']and v['actualExportPath']==proposal['actual56ExportPin']['path']and v['actualExportSha256']==proposal['actual56ExportPin']['sha256']
  assert v['actualKiCadVersion'].startswith('10.0.6')and v['actualLoadedFootprints']==507 and v['actualLoadedVias']==227 and v['actualLoadedSegments']==v['actualDerivedSourceSegmentCount']==1053 and v['actualLoadedLayerCount']==4 and v['actualRetainedNativeHardwareKeepoutZones']==2 and v['actualNativeCopperPourZones']==0 and v['all292SourceTracesMappedBijectively']is True
  assert len(v['signalObservations'])==v['actualLocalNetAgreementCount']==v['actualLocalPhysicalApproachCount']==98 and len(v['actual29GraphObservations'])==v['actual29NonzeroNetGraphCount']==v['actual29PhysicalCpuRamGraphCount']==29 and v['expectedMissingOriginalSignalCount']==20
  for key in('sourceRawOrSdkEdited','rawExportEdited','netRepairPerformed','saveBoardPerformed','refillPerformed','allRuleDrcPerformed','referenceQualified','electricalTimingQualified','complete29Accepted','accepted49','fabricationReady'):assert v[key]is False
  for row in p['outputFiles']:binding(row)
  prior['actual60Source29FreshCadSuccessCollectionPin']={'path':proposal['actual60CollectionPin']['path'],'sha256':proposal['actual60CollectionPin']['sha256']};prior['actualClosedScopeCount']=60;prior['actual60OnlyPartial29GeometryQualifiedAll49ReferenceElectricalStillFalse']=True
  return prior

 def closed61():
  prior=closed60();assert prior['actualClosedScopeCount']==60
  for key in('actual61FailedCollectionPin','actual61PostauditPin','actual61GuardManifestPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert len(proposal['actual61PhasePostauditPins'])==len(proposal['actual61ChildLogPins'])==len(proposal['actual61ExecutionPins'])==2
  r=read(proposal['actual61FailedCollectionPin']['path']);p=read(proposal['actual61PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==5443 and r['toolWrapperExitCode']==r['toolExitCode']==2
  assert r['scope']==p['scope']=='ROOT_C31_FOCUSED_TWO_SERIAL_RED_GREEN_WITH60_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='focused-red-green-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['candidateSourcePin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual61GuardManifestPin']['sha256']
  assert r['postauditPath']==proposal['actual61PostauditPin']['path']and sha(r['postauditPath'])==r['postauditSha256']==proposal['actual61PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert len(p['phases'])==2 and r['orderedPhaseNames']==p['orderedPhaseNames']==r['expectedPhaseNames']==p['expectedPhaseNames']==['baseline','proposed']and r['notAttemptedPhaseNames']==p['notAttemptedPhaseNames']==[]
  assert r['sameGuardPid']==p['sameGuardPid']==511475 and not Path('/proc/511475').exists()
  for doc in(r,p):
   for key in('passedMeansRegressionReproducedAndProposedGreenOnly','redOwnedGroupEmptyBeforeGreen','allOwnedGroupsIndependentlyObservedEmpty','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareSourceAndCarrierCountUnchanged'):assert doc[key]is True
   for key in('passed','baselineTestSuitePassed','greenTestSuitePassed','full647Requalified','allElevenBenchmarksAccepted','originalAll11AcceptanceClaimed','fixReleaseQualificationPassed','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
   assert doc['batchFailure']=='Focused proposed protocol failed'and doc['finalVerificationFailure']is None and doc['crossRunLogInspection']is None
   assert doc['newRoutesAdopted']==doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  for phase,row,post_pin,log_pin,execution_pin in zip(('baseline','proposed'),p['phases'],proposal['actual61PhasePostauditPins'],proposal['actual61ChildLogPins'],proposal['actual61ExecutionPins']):
   binding(post_pin);binding(log_pin);binding(execution_pin)
   assert row['phase']==phase and row['sameGuardPid']==511475 and row['postauditPath']==post_pin['path']and row['postauditSha256']==post_pin['sha256']and read(post_pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   assert row['childLogPath']==log_pin['path']and row['childLogSha256']==log_pin['sha256']and sha(log_pin['path'])==log_pin['sha256']and read(execution_pin['path'])==row['execution']
   assert row['sourceAndDependenciesHeld']is row['ownedGroupEmptyActuallyObserved']is row['passedMeansFocusedRedOrGreenProtocolOnly']is True and row['postverificationFailure']is None and row['testSuitePassed']is False
   assert row['externalRootToolCollectionClaimedForIndividualPhase']is row['all49Accepted']is row['fabricationReady']is False
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   e=row['execution'];assert e['policy']==focused['policy']and e['currentGuardPid']==511475 and e['pid']==e['pgid']and e['cleanupOwnedGroupEmpty']is True and not any(e['oomDelta'].values())and e['stopReasons']==[]
   assert row['command']==e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol','test','--timeout','55000',proposal['focusedWorkerPin']['path']]
   expected_root=focused['baselineSourceRoot']if phase=='baseline'else focused['proposedSourceRoot'];assert row['selectedSourceRoot']==expected_root
  red,green=p['phases'];re,ge=red['execution'],green['execution']
  assert re['pid']==re['pgid']==511574 and ge['pid']==ge['pgid']==511822 and re['endedAt']<=ge['startedAt']and c.guard.process_scope.owned(511574)==c.guard.process_scope.owned(511822)==[]
  h.finite(re,1);assert red['expectedOwnedChildExitCode']==1 and red['passed']is red['stageNaturallyCompleted']is red['expectedBaselineFailureVerified']is True and red['runFailure']is red['resultInspectionFailure']is None and red['observedCounts']=={'pass':2,'fail':1}
  assert inspector.inspect_bun_log(Path(red['childLogPath']).read_text(),'baseline',focused['baselineSourceRoot'])==red['focusedLogInspection']
  assert green['expectedOwnedChildExitCode']==0 and green['passed']is green['stageNaturallyCompleted']is green['expectedBaselineFailureVerified']is False and green['observedCounts']is green['focusedLogInspection']is None
  assert green['runFailure']=='RuntimeError: Fresh owned leader command/session differs'and green['resultInspectionFailure']=='ValueError: log size or type'
  assert ge['exitCode']==-15 and ge['diagnosticStopped']is True and ge['guardError']=='RuntimeError'and ge['cleanupOwnedGroupEmpty']is True
  identity=ge['freshLeaderIdentity'];assert identity['pid']==identity['pgid']==identity['sid']==511822 and identity['start']==25388467 and identity['state']=='R'and identity['argv']==[]
  assert Path(green['childLogPath']).stat().st_size==0 and green['childLogSha256']=='e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]and r['independentlyObservedOwnedGroupMembers']=={'511574':[],'511822':[]}
  assert r['baselineSpecificRegressionReproduced']is r['proposedTestSuiteCompletionUnknown']is r['proposedStoppedByFreshLeaderIdentityCheck']is r['firstProposedFreshLeaderHadEmptyArgv']is r['proposedChildLogEmpty']is True
  assert r['currentCheckedConnections']==29 and r['currentMissingConnections']==20
  prior['actual61C31RedReproducedGreenFreshLeaderStartupStopCollectionPin']={k:proposal['actual61FailedCollectionPin'][k]for k in('path','sha256')};prior['actual61GreenCompletionUnknownNoTestPassOrFailureInferred']=True;prior['actualClosedScopeCount']=61
  return prior

 def closed62():
  prior=closed61();assert prior['actualClosedScopeCount']==61
  for key in('actual62CollectionPin','actual62PostauditPin','actual62GuardManifestPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  assert type(proposal['actual62ToolSessionId'])is int and proposal['actual62ToolSessionId']>0
  assert len(proposal['actual62PhasePostauditPins'])==len(proposal['actual62ChildLogPins'])==2
  r=read(proposal['actual62CollectionPin']['path']);p=read(proposal['actual62PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==proposal['actual62ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
  assert r['scope']==p['scope']=='ROOT_C31_FOCUSED_TWO_SERIAL_RED_GREEN_WITH61_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='focused-red-green-batch'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['candidateSourcePin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual62GuardManifestPin']['sha256']
  assert r['postauditPath']==proposal['actual62PostauditPin']['path']and sha(r['postauditPath'])==r['postauditSha256']==proposal['actual62PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
  assert 'execution'not in r and 'execution'not in p and 'observedCounts'not in r and 'observedCounts'not in p
  assert r['candidateSourceManifestSha256']==proposal['candidateSourcePin']['sha256']and r['baselineSpecificRegressionReproduced']is r['proposedFocusedTestsPassed']is r['noSyntheticTopLevelExecutionOrAggregateTestCounts']is True
  assert r['currentCheckedConnections']==29 and r['currentMissingConnections']==20
  assert len(p['phases'])==2 and r['orderedPhaseNames']==p['orderedPhaseNames']==r['expectedPhaseNames']==p['expectedPhaseNames']==['baseline','proposed']and r['notAttemptedPhaseNames']==p['notAttemptedPhaseNames']==[]
  guard_pid=p['sameGuardPid'];assert type(guard_pid)is int and guard_pid>0 and r['sameGuardPid']==guard_pid and not Path('/proc',str(guard_pid)).exists()
  for doc in(r,p):
   for key in('passed','passedMeansRegressionReproducedAndProposedGreenOnly','greenTestSuitePassed','redOwnedGroupEmptyBeforeGreen','allOwnedGroupsIndependentlyObservedEmpty','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareSourceAndCarrierCountUnchanged'):assert doc[key]is True
   for key in('baselineTestSuitePassed','full647Requalified','allElevenBenchmarksAccepted','originalAll11AcceptanceClaimed','fixReleaseQualificationPassed','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
   assert doc['batchFailure']is doc['finalVerificationFailure']is None and doc['newRoutesAdopted']==doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['cadCalls']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  owned=[];previous=None;logs=[]
  for phase,row,post_pin,log_pin,expected_exit,expected_counts in zip(('baseline','proposed'),p['phases'],proposal['actual62PhasePostauditPins'],proposal['actual62ChildLogPins'],(1,0),({'pass':2,'fail':1},{'pass':3,'fail':0})):
   binding(post_pin);binding(log_pin);assert row['phase']==phase and row['sameGuardPid']==guard_pid and row['expectedOwnedChildExitCode']==expected_exit and row['observedCounts']==expected_counts
   assert row['postauditPath']==post_pin['path']and row['postauditSha256']==post_pin['sha256']and read(post_pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   assert row['childLogPath']==log_pin['path']and row['childLogSha256']==log_pin['sha256']and sha(log_pin['path'])==log_pin['sha256']
   for key in('passed','passedMeansFocusedRedOrGreenProtocolOnly','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted'):assert row[key]is True
   assert row['runFailure']is row['postverificationFailure']is row['resultInspectionFailure']is None
   assert row['expectedBaselineFailureVerified']is(phase=='baseline')and row['testSuitePassed']is(phase=='proposed')and row['externalRootToolCollectionClaimedForIndividualPhase']is False
   assert row['all49Accepted']is row['fabricationReady']is False
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   e=row['execution'];h.finite(e,expected_exit);assert e['policy']==focused['policy']and e['pid']==e['pgid']and type(e['pgid'])is int and e['pgid']>0 and e['pgid']not in owned and e['currentGuardPid']==guard_pid and c.guard.process_scope.owned(e['pgid'])==[]
   assert row['command']==e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol','test','--timeout','55000',proposal['focusedWorkerPin']['path']]
   selected=focused['baselineSourceRoot']if phase=='baseline'else focused['proposedSourceRoot'];assert row['selectedSourceRoot']==selected
   parsed=inspector.inspect_bun_log(Path(log_pin['path']).read_text(),phase,selected);assert row['focusedLogInspection']==parsed
   if previous is not None:assert previous['endedAt']<=e['startedAt']
   owned.append(e['pgid']);previous=e;logs.append(Path(log_pin['path']).read_bytes())
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]and r['independentlyObservedOwnedGroupMembers']=={str(pgid):[]for pgid in owned}
  cross=inspector.inspect_red_green(logs[0],logs[1],baseline_child_exit_code=1,proposed_child_exit_code=0);assert cross==p['crossRunLogInspection']==r['crossRunLogInspection']
  prior['actual62C31RegressionReproducedAndGreenTwoChildCollectionPin']={k:proposal['actual62CollectionPin'][k]for k in('path','sha256')};prior['actual62RedSuiteFailedAsExpectedGreenSuitePassedOnly']=True;prior['actualClosedScopeCount']=62
  return prior

 def closed63():
  prior=closed62();assert prior['actualClosedScopeCount']==62
  assert proposal['actual63Sealed']is True
  for key in('actual63CollectionPin','actual63PostauditPin','actual63ChildLogPin','actual63GuardManifestPin'):binding(proposal[key])
  r=read(proposal['actual63CollectionPin']['path']);p=read(proposal['actual63PostauditPin']['path']);e=p['execution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is r['passed']is p['passed']is True and r['toolExitCode']==r['toolWrapperExitCode']==0 and r['toolSessionId']==proposal['actual63ToolSessionId']
  assert r['postauditPath']==proposal['actual63PostauditPin']['path']and r['postauditSha256']==proposal['actual63PostauditPin']['sha256']and r['execution']==e
  assert r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior
  for d in(r,p):
   assert d['scope']=='ROOT_C31_FULL647_WITH62_AUTHENTIC_PRIOR_CLOSURES'and d['phase']=='full647'and d['sourceManifestSha256']==d['candidateSourceManifestSha256']==proposal['candidateSourcePin']['sha256']and d['rootGuardProposalManifestSha256']==proposal['actual63GuardManifestPin']['sha256']
   assert d['full647ProjectManifestSha256']==proposal['full647PreparedProjectManifestPin']['sha256']and d['observedCounts']=={'pass':647,'fail':0}
   for k in('sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','stageNaturallyCompleted','full647Requalified','ownedGroupEmptyActuallyObserved','passedMeansFull647RegressionOnly'):assert d[k]is True
   assert all(d[k]is None for k in('runFailure','postverificationFailure','resultInspectionFailure'))
   assert all(d[k]is False for k in('originalAll11AcceptanceClaimed','fixReleaseQualificationPassed','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'))and all(d[k]==0 for k in('CoreCalls','nativeCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'))
  assert r['testSuiteCompleted']is True and r['observedCounts']=={'pass':647,'fail':0}and r['observedTestFileCount']==190 and p['observedTestFileCount']==190
  h.finite(e,0);h.held_inventory_post(p);assert e['policy']==full_contract['policy']and e['command']==full_contract['command']and e['pid']==e['pgid']==proposal['actual63Pgid']and e['currentGuardPid']==proposal['actual63GuardPid']
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]and c.guard.process_scope.owned(e['pgid'])==[]and not Path('/proc',str(e['currentGuardPid'])).exists()
  assert r['childLogPath']==p['childLogPath']==proposal['actual63ChildLogPin']['path']and r['childLogSha256']==p['childLogSha256']==proposal['actual63ChildLogPin']['sha256']
  log=Path(p['childLogPath']).read_text();assert counts(log)=={'pass':647,'fail':0}and re.findall(r'^Ran (\d+) tests across (\d+) files\. \[[^\n]+\]$',log,re.M)==[('647','190')]
  prior['actual63Full647RegressionCollectionPin']={k:proposal['actual63CollectionPin'][k]for k in('path','sha256')};prior['actual63Full647Natural647Pass190FilesOnly']=True;prior['actualClosedScopeCount']=63
  return prior

 def closed64():
  prior=closed63();assert prior['actualClosedScopeCount']==63 and proposal['actual64ClosedSealed']is True
  for key in('actual64CollectionPin','actual64PostauditPin','actual64GuardManifestPin','actual64DiagnosticResultPin','actual64RawFinalStatePin','actual64AuthorityPin'):binding(proposal[key])
  r=read(proposal['actual64CollectionPin']['path']);p=read(proposal['actual64PostauditPin']['path']);e=p['execution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==88438 and r['toolWrapperExitCode']==r['toolExitCode']==2
  assert r['postauditPath']==proposal['actual64PostauditPin']['path']and r['postauditSha256']==proposal['actual64PostauditPin']['sha256']and r['execution']==e
  assert r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['toolSessionCollected']is False
  for k,v in p.items():
   if k!='toolSessionCollected':assert r[k]==v,'Corrected Root64 receipt preserves every historical POST value: '+k
  for doc in(r,p):
   assert doc['scope']=='ROOT_C31_CURRENT29_FULL49_PUBLIC_DIAGNOSTIC_WITH63_AUTHENTIC_PRIOR_CLOSURES'and doc['phase']=='public49-diagnostic'
   assert doc['sourceManifestSha256']==proposal['public49CallerPin']['sha256']and doc['rootGuardProposalManifestSha256']==proposal['actual64GuardManifestPin']['sha256']and doc['candidateSourceManifestSha256']==proposal['candidateSourcePin']['sha256']
   assert doc['runFailure']is doc['resultInspectionFailure']is None and doc['postverificationFailure']=='AssertionError: '
   for key in('sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','stageNaturallyCompleted','diagnosticCompleted','passed'):assert doc[key]is False
   for key in('actualOriginalStepCalls','actualGeneratedCarrierCount','naturalSdkSolved','naturalSdkFailed'):assert doc[key]is None
   assert doc['ownedGroupEmptyActuallyObserved']is True and doc['currentInputActualSource29']is doc['all49RequestsAnd263FixedRowsAnd1298ObstaclesAnd98EventsPreserved']is True and doc['staticCompleted29BodiesSeeded']is False
   assert doc['publicConstructorLimit']==1 and doc['publicStepLimit']==40000 and doc['checkpointCountLimit']==41 and doc['checkpointTotalByteLimit']==40000000 and doc['workspaceFreeBytesBefore']==3577614336
   for key in('originalAll11AcceptanceClaimed','fixReleaseQualificationPassed','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert doc[key]is False
   for key in('newRoutesAdopted','CoreCalls','nativeCalls','originalApiCalls','cliCalls','cadCalls'):assert doc[key]==0
  # Exact equal SDK snapshots are narrower evidence than the failed full postverification.
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']
  assert p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  assert e['exitCode']==1 and e['accepted']is False and e['diagnosticStopped']is False and e['stopReasons']==[]and e['cleanupOwnedGroupEmpty']is True
  assert e['policy']==public_contract['policy']and e['policy']=={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
  assert e['pid']==e['pgid']==517767 and e['currentGuardPid']==517632 and e['signalErrors']==[]and e['signalErrorCount']==0
  assert isinstance(e['oomDelta'],dict)and e['oomDelta']and all(v==0 for v in e['oomDelta'].values())and e['endedAt']>=e['startedAt']and 0<e['wallSeconds']<90
  assert e['peakOwnedRssBytes']==888311808<e['policy']['rssBytes']and e['peakSharedBytes']<e['policy']['sharedBytes']
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',proposal['public49WorkerPin']['path'],proposal['actual64AuthorityPin']['path']]
  assert c.guard.process_scope.owned(517767)==[]and not Path('/proc/517632').exists()
  assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentlyObservedOwnedGroupMembers']=={'517767':[]}and r['independentProcReadErrors']==[]
  assert r['currentCheckedConnections']==29 and r['currentMissingConnections']==20 and r['partialAdoptionPerformedByThisCollection']is False
  assert len(p['outputFiles'])==45 and p['outputFiles']==proposal['actual64OutputFiles']
  for row in p['outputFiles']:binding(row)
  assert proposal['actual64DiagnosticResultPin']in p['outputFiles']and proposal['actual64RawFinalStatePin']in p['outputFiles']
  checkpoints=[row for row in p['outputFiles']if Path(row['path']).name.startswith('CHECKPOINT-')];assert len(checkpoints)==41 and sum(row['bytes']for row in checkpoints)==3001621<40000000
  v=read(proposal['actual64DiagnosticResultPin']['path']);raw=read(proposal['actual64RawFinalStatePin']['path'])
  assert v['scope']=='ROOT_C31_ACTUAL55_UNSEEDED_FRESH49_PUBLIC_DIAGNOSTIC'and v['originalStepCalls']==raw['publicStepCalls']==raw['iterations']==40000 and v['publicConstructorCalls']==raw['constructorCalls']==1
  assert v['actualGeneratedCarrierCount']==v['actualUniqueGeneratedCarrierCount']==raw['actualPublicTraceCount']==len(raw['traces'])==2 and len(v['missingOriginal49'])==47
  assert v['naturalSdkSolved']is raw['solved']is False and v['naturalSdkFailed']is raw['failed']is True and v['thrown']is raw['thrown']is None
  assert v['phase']==raw['phase']=='failed'and v['error']==raw['error']=='BusLanesSolver ran out of iterations'and v['failureCode']==raw['failureCode']=='search_budget_exhausted'
  assert v['currentC31Full49RoutingQualificationPassed']is False and v['checkpointCount']==41 and v['checkpointBytes']==3001621 and v['checkpointByteLimit']==40000000
  for doc in(v,raw):
   for key in('referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
  # Never call held_inventory_post on this failed64 POST or substitute raw-worker observations for its NULL qualified results.
  prior['actual64C31Public49PostverificationFailedCollectionPin']={k:proposal['actual64CollectionPin'][k]for k in('path','sha256')}
  prior['actual64PostverificationHeldFloorGitFalseAndQualifiedResultsNullPreserved']=True
  prior['actual64EqualSdkSnapshotDictionariesDoNotRepairFailedPostverification']=True
  prior['actual64RawWorkerBudgetFailure40000StepsTwoCarriersNotAcceptedOrPostQualified']=True
  prior['actual64NoEstablishedPostverificationFailureCause']=True
  prior['actual64NextScopeRequiresFreshSourceSdkGitAndDiskFloorHoldings']=True
  prior['actualClosedScopeCount']=64
  return prior

 def closed65():
  prior=closed64();assert prior['actualClosedScopeCount']==64
  for key in('actual65FailedCollectionPin','actual65PostauditPin','actual65CapturePhasePostPin','actual65CaptureChildLogPin','actual65FailedGuardManifestPin','actual65FailedSourceManifestPin','actual65FailedCaptureWorkerPin'):binding(proposal[key])
  r=read(proposal['actual65FailedCollectionPin']['path']);p=read(proposal['actual65PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==36546 and r['toolExitCode']==r['toolWrapperExitCode']==2
  assert r['postauditPath']==proposal['actual65PostauditPin']['path']and r['postauditSha256']==proposal['actual65PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['toolSessionCollected']is False
  for key,value in p.items():
   if key!='toolSessionCollected':assert r[key]==value,'Failed65 Root receipt preserves its original POST: '+key
  for doc in(r,p):
   assert doc['scope']=='ROOT_SOURCE32_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH64_AUTHENTIC_PRIOR_CLOSURES'and doc['phase']=='capture-types-core-batch'and doc['sourceManifestSha256']==proposal['actual65FailedSourceManifestPin']['sha256']and doc['rootGuardProposalManifestSha256']==proposal['actual65FailedGuardManifestPin']['sha256']
   assert doc['orderedPhaseNames']==['capture']and doc['expectedPhaseNames']==['capture','types','core']and doc['notAttemptedPhaseNames']==['types','core']and len(doc['phases'])==1
   for key in('historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passedMeansCaptureStrictTypesAndRawCore32Only','batchScopeContainsThreeSerialOwnedChildren','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   assert doc['allThreeChildrenNaturallyCompleted']is doc['passed']is False and doc['batchFailure']=='Phase capture failed; later phases not attempted'and doc['finalVerificationFailure']is None
   assert doc['captureChildInvocations']==1 and all(doc[key]==0 for key in('CoreCalls','typesChildInvocations','CoreChildInvocations','nativeCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'))
   for key in('Source32Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  row=p['phases'][0];assert row['phase']=='capture'and row['postauditPath']==proposal['actual65CapturePhasePostPin']['path']and row['postauditSha256']==proposal['actual65CapturePhasePostPin']['sha256']and read(row['postauditPath'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
  assert row['sourceAndDependenciesHeld']is row['ownedGroupEmptyActuallyObserved']is row['stageNaturallyCompleted']is True and row['ownedChildNatural0']is row['passed']is False and row['result']is None and row['outputFiles']==[]
  assert row['runFailure']is row['postverificationFailure']is row['outputBindingFailure']is None and row['resultInspectionFailure']=='AssertionError: '
  assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
  assert row['guardIdentityBefore']==row['guardIdentityAfter']==p['sameGuardIdentity']and p['sameGuardIdentity']['pid']==518922
  assert all(row[key]==0 for key in('CoreCalls','CoreChildInvocations','nativeCalls','originalApiCalls','cliCalls','cadCalls'))
  e=row['execution'];assert e['pid']==e['pgid']==518995 and e['currentGuardPid']==518922 and e['exitCode']==1 and e['accepted']is False and e['diagnosticStopped']is False and e['stopReasons']==[]and e['cleanupOwnedGroupEmpty']is True
  assert e['policy']=={'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}and e['signalErrors']==[]and e['signalErrorCount']==0 and e['oomDelta']and all(v==0 for v in e['oomDelta'].values())and e['endedAt']>=e['startedAt']and 0<e['wallSeconds']<60
  assert e['command']==row['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',proposal['actual65FailedCaptureWorkerPin']['path'],str(Path(proposal['actual65PostauditPin']['path']).parent/'capture/output/source-capture.json'),str(Path(proposal['actual65PostauditPin']['path']).parent/'capture/output/source-tree-diagnostic.json')]
  assert e['freshLeaderIdentity']['pid']==e['freshLeaderIdentity']['pgid']==e['freshLeaderIdentity']['sid']==518995 and e['freshLeaderIdentity']['argv']==e['command']
  assert c.guard.process_scope.owned(518995)==[]and not Path('/proc/518922').exists()
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is r['captureChildNatural1BeforeTypesAndCore']is True and r['independentlyObservedOwnedGroupMembers']=={'518995':[]}and r['independentProcReadErrors']==[]and r['currentCheckedConnections']==29 and r['currentMissingConnections']==20 and r['partialAdoptionPerformedByThisCollection']is False
  log=Path(proposal['actual65CaptureChildLogPin']['path']).read_text();assert 'error: Actual29 API131 uses its preserved legacy result-key spelling without retagging'in log and 'requireFutureQualifiedParent29'in log and 'source32.circuit.tsx:135:2'in log and 'Bun v1.3.14'in log
  prior['actual65Source32CapturePreconditionFailedCollectionPin']={k:proposal['actual65FailedCollectionPin'][k]for k in('path','sha256')}
  prior['actual65OnlyCaptureNatural1TypesCoreUnattemptedNoOutputsNoQualification']=True
  prior['actual65SourceSdkGitAndOriginalFloorHeldWithoutRelabelingCaptureFailure']=True
  prior['actual65Parent29ApiPropertyLookupFailureRequiresNewSourceAndFreshCapture']=True
  prior['actualClosedScopeCount']=65
  return prior

 def closed66():
  prior=closed65();assert prior['actualClosedScopeCount']==65
  for key in('actual66FailedCollectionPin','actual66PostauditPin','actual66CapturePhasePostPin','actual66TypesPhasePostPin','actual66TypesChildLogPin','actual66FailedGuardManifestPin','actual66FailedSourceManifestPin','actual66FailedCaptureWorkerPin','actual66FailedTypesWorkerPin','actual66CaptureOutputPin','actual66CaptureDiagnosticPin'):binding(proposal[key])
  r=read(proposal['actual66FailedCollectionPin']['path']);p=read(proposal['actual66PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==28922 and r['toolExitCode']==r['toolWrapperExitCode']==2
  assert r['postauditPath']==proposal['actual66PostauditPin']['path']and r['postauditSha256']==proposal['actual66PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['toolSessionCollected']is False
  for key,value in p.items():
   if key!='toolSessionCollected':assert r[key]==value,'Failed66 Root receipt preserves its saved POST: '+key
  for doc in(r,p):
   assert doc['scope']=='ROOT_SOURCE32_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH65_AUTHENTIC_PRIOR_CLOSURES'and doc['phase']=='capture-types-core-batch'and doc['sourceManifestSha256']==proposal['actual66FailedSourceManifestPin']['sha256']and doc['rootGuardProposalManifestSha256']==proposal['actual66FailedGuardManifestPin']['sha256']
   assert doc['orderedPhaseNames']==['capture','types']and doc['expectedPhaseNames']==['capture','types','core']and doc['notAttemptedPhaseNames']==['core']and len(doc['phases'])==2
   for key in('historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passedMeansCaptureStrictTypesAndRawCore32Only','batchScopeContainsThreeSerialOwnedChildren','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
   assert doc['allThreeChildrenNaturallyCompleted']is doc['passed']is False and doc['batchFailure']=='Phase types failed; later phases not attempted'and doc['finalVerificationFailure']is None
   assert doc['captureChildInvocations']==doc['typesChildInvocations']==1 and all(doc[key]==0 for key in('CoreCalls','CoreChildInvocations','nativeCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'))
   for key in('Source32Accepted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert doc[key]is False
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256']
  assert p['sameGuardIdentity']['pid']==520581
  for i,(name,post_key,pid,exit_code)in enumerate([('capture','actual66CapturePhasePostPin',520701,0),('types','actual66TypesPhasePostPin',520783,2)]):
   row=p['phases'][i];assert row['phase']==name and row['postauditPath']==proposal[post_key]['path']and row['postauditSha256']==proposal[post_key]['sha256']and read(row['postauditPath'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   assert row['sourceAndDependenciesHeld']is row['ownedGroupEmptyActuallyObserved']is row['stageNaturallyCompleted']is True and row['ownedChildNatural0']is row['passed']is(i==0)
   assert row['runFailure']is row['postverificationFailure']is row['outputBindingFailure']is None
   assert row['resultInspectionFailure']==(None if i==0 else 'AssertionError: ')
   assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
   assert row['guardIdentityBefore']==row['guardIdentityAfter']==p['sameGuardIdentity']and all(row[k]==0 for k in('CoreCalls','CoreChildInvocations','nativeCalls','originalApiCalls','cliCalls','cadCalls'))
   e=row['execution'];assert e['pid']==e['pgid']==pid and e['currentGuardPid']==520581 and e['exitCode']==exit_code and e['diagnosticStopped']is False and e['stopReasons']==[]and e['cleanupOwnedGroupEmpty']is True
   assert e['policy']=={'wallSeconds':60 if i==0 else 120,'rssBytes':1073741824 if i==0 else 2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}and e['signalErrors']==[]and e['signalErrorCount']==0 and e['oomDelta']and all(v==0 for v in e['oomDelta'].values())and e['endedAt']>=e['startedAt']
   assert e['command']==row['command']and e['freshLeaderIdentity']['pid']==e['freshLeaderIdentity']['pgid']==e['freshLeaderIdentity']['sid']==pid and e['freshLeaderIdentity']['argv']==e['command']
   assert c.guard.process_scope.owned(pid)==[]
  capture,types=p['phases'];assert capture['execution']['endedAt']<=types['execution']['startedAt']and not Path('/proc/520581').exists()
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is r['capturePassedTypesNatural2CoreUnattempted']is True and r['independentlyObservedOwnedGroupMembers']=={'520701':[],'520783':[]}and r['independentProcReadErrors']==[]and r['currentCheckedConnections']==29 and r['currentMissingConnections']==20 and r['partialAdoptionPerformedByThisCollection']is False
  base66=Path(proposal['actual66PostauditPin']['path']).parent
  assert capture['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',proposal['actual66FailedCaptureWorkerPin']['path'],str(base66/'capture/output/source-capture.json'),str(base66/'capture/output/source-tree-diagnostic.json')]
  assert types['command']==['bash',proposal['actual66FailedTypesWorkerPin']['path']]and types['result']is None and types['outputFiles']==[]
  assert capture['outputFiles']==[proposal['actual66CaptureOutputPin'],proposal['actual66CaptureDiagnosticPin']]
  assert capture['result']==inspect32_capture({'capture':Path(proposal['actual66CaptureOutputPin']['path']),'diagnostic':Path(proposal['actual66CaptureDiagnosticPin']['path'])})
  log=Path(proposal['actual66TypesChildLogPin']['path']).read_text();assert log.count("error TS2550: Property 'hasOwn' does not exist on type 'ObjectConstructor'.")==4 and log.count(': error TS')==4
  assert re.findall(r'source32[.]circuit[.]tsx[(](77|78),[0-9]+[)]: error TS2550:',log)==['77','77','78','78']
  prior['actual66Source32CapturePassTypesEs2020FailedCollectionPin']={k:proposal['actual66FailedCollectionPin'][k]for k in('path','sha256')}
  prior['actual66CapturePassDoesNotQualifyChangedSourceOrUnattemptedCore']=True
  prior['actual66TypesNatural2ExactlyFourObjectHasOwnTs2550NoCompilerRelaxation']=True
  prior['actual66SourceSdkGitAndOriginalFloorHeldWithoutRelabelingTypesFailure']=True
  prior['actualClosedScopeCount']=66
  return prior

 def inspect32_capture(paths):
  capture,diagnostic=paths['capture'],paths['diagnostic'];r=read_bounded(capture,5242880);d=read_bounded(diagnostic,7340032)
  assert r['scope']=='ACTUAL_ROOT_SOURCE32_CAPTURE_WITH_PARENT29_FULL_INVERSE'and d['scope']=='ACTUAL_SOURCE32_AND_PARENT29_BEFORE_INVERSE_ASSERTIONS'
  for key in('passed','fullInverseSourceTreePassed','all227ExistingViasAnd29PriorRoutesHeld','all98NumericBranchesAnd49LogicalOwnersHeld','original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse','pureSourceEvaluationExecuted','automaticCoreSrjForThisForkMustNotBeUsed','bothDqs1CoupledViewsRequireFreshOriginalApi'):assert r[key]is True
  for key,value in dict(proposedReactElementCount=2286,previousReactElementCount=2278,genuineNewInnerPortCount=52,exactNewPortDeclarations=6,exactChangedOriginalRouteDeclarations=3,exactChangedLocalSuppressions=6,exactMovedExistingViaCount=0,exactAddedIntermediateCarrierViaCount=2,expectedPhysicalVias=229,expectedPhysicalTraces=297,expectedCarrierPaths=32,expectedPhysicalCarrierBodyPaths=34,missingOriginal49RequestsExpected=17).items():assert r[key]==value
  assert r['newViaRole']=='REMOVABLE_CARRIER_NOT_FIXED_FANOUT'and r['sourceOnlyProposalSha256']==proposal['promoted32ProposalPin']['sha256']
  assert r['actualDiagnosticPath']==str(diagnostic)and r['actualDiagnosticSha256']==sha(diagnostic)and r['actualSourceTree']==d['actualProposedSource32Tree']
  assert r['actualParent29CapturePin']==proposal['actual53CapturePin']
  assert d['actualParent29Tree']==read(proposal['actual53CapturePin']['path'])['actualSourceTree']
  assert d['beforeCounts']['reactElements']==2278 and d['afterCounts']['reactElements']==2286 and d['beforeCounts']['unsupported']==d['afterCounts']['unsupported']==0 and d['inverseChecksExecuted']is False
  for key in('circuitConstructed','coreRendered','all49Accepted','fabricationReady'):assert r[key]is d[key]is False
  for key in('source29QualificationInherited','nativeExecuted','cadExecuted','singleCoupledSectionCoversBoth','referenceQualified','electricalTimingPassed'):assert r[key]is False
  return dict(sourceCapturePin=file_row(capture),sourceDiagnosticPin=file_row(diagnostic),fullSourceInversePassed=True,CoreExecuted=False)

 def inspect32_core(paths,capture_pin):
  raw,controls=paths['raw'],paths['controls'];core=read_bounded(raw,16777216);r=read_bounded(controls,4194304)
  assert isinstance(core,list)and r['scope']=='ROOT_FRESH_EDITABLE_SOURCE_CORE_229_SOURCE20_SOURCE21_INTERMEDIATE_VIAS_AND_SOURCE45_32'
  assert r['rawCorePath']==str(raw)and r['rawCoreSha256']==sha(raw)and r['actualCapturePath']==capture_pin['path']and r['actualCaptureSha256']==capture_pin['sha256']
  assert r['freshCoreControlPassed']is True and len(r['checks'])==29 and all(x['passed']is True for x in r['checks'])
  expected={'source_component':280,'source_trace':1195,'pcb_component':509,'pcb_smtpad':1161,'pcb_plated_hole':4,'pcb_hole':2,'pcb_via':229,'source_manually_placed_via':229,'pcb_trace':297,'source_port':1671,'pcb_port':1671,'source_net':98,'source_bus':8,'pcb_keepout':2}
  for kind,count in expected.items():assert sum(row['type']==kind for row in core)==count
  assert len(r['carriers'])==32 and all(x['passed']is True for x in r['carriers'])and len(r['signalTopProjection'])==98 and all(x['passed']is True for x in r['signalTopProjection'])
  assert len(r['original49Projection'])==49 and all(x['passed']is True for x in r['original49Projection'])and len(r['viaProjection'])==229 and all(x['passed']is True for x in r['viaProjection'])
  assert len(r['actualSourcePortMatches']['registrations'])==52 and r['expectedOriginalCarrierCount']==32 and r['expectedMissingOriginalSignalCount']==17 and r['actualNonzeroWireSegmentCount']==1116
  assert r['all29PriorCarrierGeometryHeldByExactSourceInverse']is r['source20And21ExactFourPathArchitectureOnly']is True
  mids=r['explicitIntermediateCarrierViaProjection'];assert len(mids)==2 and {x['sourceViaName']for x in mids}=={'V_TI_SIGNAL_INTERMEDIATE_source_trace_20_0','V_TI_SIGNAL_INTERMEDIATE_source_trace_21_0'}
  assert all(x['passed']is True and x['carrierOwned']is True and x['reference']is False for x in mids)
  mid_ids={x['actualViaId']for x in mids};assert len(mid_ids)==2
  for row in core:
   if row['type']=='pcb_via'and row['pcb_via_id']in mid_ids:assert row['layers']==['top','inner1','inner2','bottom']and row['from_layer']=='top'and row['to_layer']=='bottom'and row['outer_diameter']==.4572 and row['hole_diameter']==.254
  body_ids=[]
  for carrier in r['carriers']:
   mixed=carrier['originalSourceTraceId']in('source_trace_20','source_trace_21')
   assert len(carrier['actualDirectPcbTraceIds'])==(4 if mixed else 3)and len(set(carrier['actualDirectPcbTraceIds']))==len(carrier['actualDirectPcbTraceIds'])
   if mixed:
    assert carrier['carrierArchitecture']=='TWO_LAYER_ONE_OWNED_INTERMEDIATE_VIA'and carrier['physicalFullThroughBarrels']==3 and len(carrier['actualCarrierPcbTraceIds'])==2 and len(carrier['actualRemovableCarrierViaIds'])==1 and carrier['actualRemovableCarrierViaIds'][0]in mid_ids
    assert carrier['actualSourceOwnedPhysicalGraph']['physicallyConnected']is carrier['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is carrier['intermediateViaIsNotFixedFanout']is True
    body_ids.extend(carrier['actualCarrierPcbTraceIds'])
   else:body_ids.append(carrier['actualCarrierPcbTraceId'])
  assert len(body_ids)==len(set(body_ids))==34
  event=r['source3OwnerEvent'];assert event['sourceViaName']=='V_TI_SIGNAL_source_trace_3_0'and event['capturedPriorViaIdProvenanceOnly']=='pcb_via_135'and event['freshIdsDerivedFromActualCore']is True and event['capturedIdAssignedToFreshCore']is False
  vp=event['actualViaProjection'];sp=event['actualTopStubProjection'];cc=event['actualCarrierProjection'];assert vp['passed']is sp['passed']is cc['passed']is True and sp['originalSourceTraceId']==cc['originalSourceTraceId']=='source_trace_3'and sp['side']==0
  for name,x,y,vertices,side,owner in [('V_TI_SIGNAL_source_trace_3_0',6.2,12.4,4,0,'source_trace_3'),('V_TI_SIGNAL_source_trace_7_1',-7.4,7.8,13,1,'source_trace_7')]:
   v=[x for x in r['viaProjection']if x['sourceViaName']==name];s=[x for x in r['signalTopProjection']if x['originalSourceTraceId']==owner and x['side']==side];assert len(v)==len(s)==1 and v[0]['passed']is s[0]['passed']is True
   actual=[p for p in core if p['type']=='pcb_via'and p['pcb_via_id']==v[0]['actualViaId']];assert len(actual)==1 and abs(actual[0]['x']-x)<1e-8 and abs(actual[0]['y']-y)<1e-8 and actual[0]['layers']==['top','inner1','inner2','bottom']and actual[0]['outer_diameter']==.4572 and actual[0]['hole_diameter']==.254
   stub=[p for p in core if p['type']=='pcb_trace'and p['pcb_trace_id']==s[0]['actualPcbTraceId']];assert len(stub)==1 and len(stub[0]['route'])==vertices and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in stub[0]['route'])
  for key in('sourceNumericAndPhysicalIdsDerivedWithoutAssignment','pcbRoutingDisabled','authoredPourLiteralsHeldByActualSourceInverse','manualPairSourceBusForkHeld','automaticCoreSrjForThisForkMustNotBeUsed','originalCouplingApisRequiredAgainstFreshActualGeometry'):assert r[key]is True
  for key in('circuitJsonGeometryEdited','parent29ActualQualificationInherited','nativeExecuted','cadExecuted','referenceQualified','electricalTimingPassed','all49Accepted','fabricationReady'):assert r[key]is False
  return dict(rawCorePin=file_row(raw),coreControlsPin=file_row(controls),all29CorePredicatesPassed=True,actualCandidateCarrierCount=32,actualCarrierWireBodyCount=34,actualPhysicalViaCount=229,nativeQualificationPerformed=False)

 def closed67():
  prior=closed66();assert prior['actualClosedScopeCount']==66 and proposal['actual67Sealed']is True
  for key in('actual67CollectionPin','actual67PostauditPin','actual67GuardManifestPin','actual67CoreRawPin','actual67CoreControlsPin','actual67CapturePin','actual67DiagnosticPin'):binding(proposal[key])
  r=read(proposal['actual67CollectionPin']['path']);p=read(proposal['actual67PostauditPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is r['passed']is p['passed']is True and r['toolExitCode']==r['toolWrapperExitCode']==0 and r['toolSessionId']==proposal['actual67ToolSessionId']
  assert r['postauditPath']==proposal['actual67PostauditPin']['path']and r['postauditSha256']==proposal['actual67PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior
  for d in(r,p):
   assert d['scope']=='ROOT_SOURCE32_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH66_AUTHENTIC_PRIOR_CLOSURES'and d['phase']=='capture-types-core-batch'and d['sourceManifestSha256']==proposal['promoted32ManifestPin']['sha256']and d['rootGuardProposalManifestSha256']==proposal['actual67GuardManifestPin']['sha256']
   assert d['orderedPhaseNames']==d['expectedPhaseNames']==['capture','types','core']and d['notAttemptedPhaseNames']==[]and 'execution'not in d
   for k in('passedMeansCaptureStrictTypesAndRawCore32Only','batchScopeContainsThreeSerialOwnedChildren','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','allThreeChildrenNaturallyCompleted'):assert d[k]is True
   assert d['batchFailure']is d['finalVerificationFailure']is None and d['CoreCalls']==d['CoreChildInvocations']==d['captureChildInvocations']==d['typesChildInvocations']==1
   assert all(d[k]==0 for k in('nativeCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'))and all(d[k]is False for k in('Source32Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'))
  assert r['phases']==p['phases']and len(p['phases'])==3 and len(proposal['actual67PhasePostauditPins'])==3
  before_end=None;groups=[]
  for i,row in enumerate(p['phases']):
   phasepin=proposal['actual67PhasePostauditPins'][i];binding(phasepin);assert row['postauditPath']==phasepin['path']and row['postauditSha256']==phasepin['sha256']and read(phasepin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
   assert row['phase']==['capture','types','core'][i]and all(row[k]is True for k in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'))and all(row[k]is None for k in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'))
   e=row['execution'];h.finite(e,0);assert e['policy']==batch32['phasePolicies'][row['phase']]and e['pid']==e['pgid']and e['currentGuardPid']==proposal['actual67GuardPid']and e['pgid']not in groups and(before_end is None or before_end<=e['startedAt']);groups.append(e['pgid']);before_end=e['endedAt']
   assert c.guard.process_scope.owned(e['pgid'])==[]and row['guardIdentityBefore']==row['guardIdentityAfter']==p['sameGuardIdentity']and row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']
   for artifact in row['outputFiles']:binding(artifact)
  capture,types,core=p['phases'];assert capture['result']==inspect32_capture({'capture':Path(proposal['actual67CapturePin']['path']),'diagnostic':Path(proposal['actual67DiagnosticPin']['path'])})and types['result']['strictNoEmitTypecheckNatural0']is True and types['result']['actualPriorCapturePin']==capture['result']['sourceCapturePin']
  assert core['result']==inspect32_core({'raw':Path(proposal['actual67CoreRawPin']['path']),'controls':Path(proposal['actual67CoreControlsPin']['path'])},capture['result']['sourceCapturePin'])and core['result']['rawCorePin']==proposal['actual67CoreRawPin']and core['result']['coreControlsPin']==proposal['actual67CoreControlsPin']
  assert capture['result']['sourceCapturePin']==proposal['actual67CapturePin']and capture['result']['sourceDiagnosticPin']==proposal['actual67DiagnosticPin']
  assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]and r['independentlyObservedOwnedGroupMembers']=={str(g):[]for g in groups}and not Path('/proc',str(proposal['actual67GuardPid'])).exists();h.held_inventory_post(p)
  prior['actual67Source32CaptureTypesCoreCollectionPin']={k:proposal['actual67CollectionPin'][k]for k in('path','sha256')};prior['actual67ThreeSerialCaptureTypesCore32PassedOnly']=True;prior['actualClosedScopeCount']=67
  return prior
 def native32_bindings():
  bindings()
  for row in native32_preparation['files']+native32_preparation['externalFiles']:binding(row)
  binding(proposal['native32PreparationPin']);binding(proposal['native32TemplatePin']);binding(proposal['native32StageContractPin'])
  assert native32_preparation['knownPromotedSource32Manifest']==proposal['promoted32ManifestPin']and native32_preparation['knownPromotedSource32Proposal']==proposal['promoted32ProposalPin']and native32_template['source32ProposalPath']==proposal['promoted32ProposalPin']['path']and native32_template['source32ProposalSha256']==proposal['promoted32ProposalPin']['sha256']
  assert policy32=={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}

 def closed68():
  prior=closed67();assert prior['actualClosedScopeCount']==67 and proposal['actual68Sealed']is True
  for key in('actual68CollectionPin','actual68PostauditPin','actual68ReportPin','actual68BoundManifestPin','actual68AuthorityPin','actual68GuardManifestPin'):binding(proposal[key])
  r=read(proposal['actual68CollectionPin']['path']);p=read(proposal['actual68PostauditPin']['path']);report=read(proposal['actual68ReportPin']['path'])
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolExitCode']==r['toolWrapperExitCode']==0 and r['toolSessionId']==proposal['actual68ToolSessionId']
  assert r['postauditPath']==proposal['actual68PostauditPin']['path']and r['postauditSha256']==proposal['actual68PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['execution']==p['execution']
  for d in(r,p):
   assert d['scope']=='ROOT_SOURCE32_NATIVE18_WITH_AUTHENTIC_67_THREE_STAGE_PRIOR_CLOSURES'and d['phase']=='native'and d['sourceManifestSha256']==proposal['native32PreparationPin']['sha256']and d['rootGuardProposalManifestSha256']==proposal['actual68GuardManifestPin']['sha256']
   assert d['coreSourceManifestSha256']==proposal['promoted32ManifestPin']['sha256']and d['actualCorePath']==proposal['actual67CoreRawPin']['path']and d['actualCoreSha256']==proposal['actual67CoreRawPin']['sha256']and d['actualCoreControlsPath']==proposal['actual67CoreControlsPin']['path']and d['actualCoreControlsSha256']==proposal['actual67CoreControlsPin']['sha256']
   assert d['reportPath']==proposal['actual68ReportPin']['path']and d['reportSha256']==proposal['actual68ReportPin']['sha256']and d['boundManifestPath']==proposal['actual68BoundManifestPin']['path']and d['boundManifestSha256']==d['packetSha256']==proposal['actual68BoundManifestPin']['sha256']
   for k in('passed','resultPassed','passedMeansNative18AndActual32NumericPhysicalGraphsOnly','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0','baseline169SourceHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareAcceptanceCheckpointUnchanged'):assert d[k]is True
   assert d['runFailure']is d['postverificationFailure']is d['resultInspectionFailure']is None and d['expandedSourceWorkerControllerClosureCount']==191 and d['nativeCalls']==18 and all(d[k]==0 for k in('CoreCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'))
   for k in('Source32Accepted','all49Accepted','accepted49','referenceQualified','electricalTimingPassed','fabricationReady'):assert d[k]is False
  e=p['execution'];h.finite(e,0);assert e['pid']==e['pgid']==proposal['actual68Pgid']and e['currentGuardPid']==proposal['actual68GuardPid']and e['policy']==native32_contract['policy']
  assert e['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',native32_contract['workerPin']['path'],proposal['actual68BoundManifestPin']['path'],proposal['actual68BoundManifestPin']['sha256'],proposal['actual68AuthorityPin']['path'],proposal['actual68AuthorityPin']['sha256'],proposal['actual68ReportPin']['path']]
  assert c.guard.process_scope.owned(e['pgid'])==[]and r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]and not Path('/proc',str(proposal['actual68GuardPid'])).exists()
  assert report['scope']=='ACTUAL_FRESH_SOURCE32_CORE297_NATIVE18_WITH_TWO_EXPLICIT_CARRIER_VIAS'and report['packetSha256']==proposal['actual68BoundManifestPin']['sha256']and report['sourceManifestSha256']==proposal['native32PreparationPin']['sha256']and report['coreSourceManifestSha256']==proposal['promoted32ManifestPin']['sha256']and report['originalSource32ProposalSha256']==proposal['promoted32ProposalPin']['sha256']and report['actualCoreSha256']==proposal['actual67CoreRawPin']['sha256']and report['actualCoreControlsSha256']==proposal['actual67CoreControlsPin']['sha256']
  assert report['checkCount']==len(report['counts'])==18 and report['physicalErrors']==0 and not any(report['counts'].values())and report['actualNativePairFindings']==[]and report['physicalCpuRamConnectedCarrierCount']==32 and report['expectedMissingOriginalSignalCount']==17
  proof=report['actualOwnershipProof'];assert len(proof['signalMappings'])==98 and len(proof['referenceMappings'])==165 and len(proof['carriers'])==32 and len(proof['intermediateCarrierMappings'])==2 and {x['originalSourceTraceId']for x in proof['intermediateCarrierMappings']}=={'source_trace_20','source_trace_21'}
  for k in('all29PriorThreePathCarriersStrictlyProved','source45AdditionalThreePathCarrierStrictlyProved','onlySource20And21FourPathGraphsProved','newTwoIntermediateViasPrivatelyRegisteredAfterGraphProof','raw229PhysicalBarrelsAccounted','rawCircuitUnmodified','all49OriginalLogicalNumericRequestsPreserved'):assert report[k]is True
  for k in('complete32Accepted','accepted49','referenceQualified','electricalTimingQualified','fabricationReady'):assert report[k]is False
  assert r['outputFiles']==p['outputFiles']and proposal['actual68ReportPin']in p['outputFiles']
  for artifact in p['outputFiles']:binding(artifact)
  h.held_inventory_post(p)
  prior['actual68Native32CollectionPin']={k:proposal['actual68CollectionPin'][k]for k in('path','sha256')};prior['actual68Native18And32PhysicalGraphsPassedOnly']=True;prior['actualClosedScopeCount']=68
  return prior
 def api32_bindings():
  native32_bindings();binding(proposal['api32StageContractPin'])
  assert api32_contract['requiredPriorScopeCount']==68 and api32_contract['orderedPhases']==['projection','api']and api32_contract['sharedReserveBytes']==1073741824 and api32_contract['projectorPin']in native32_preparation['files']and api32_contract['apiWorkerPin']in native32_preparation['files']
  assert api32_contract['expectedOriginalApiBooleanPredicates']==151 and api32_contract['expectedAdditionalJointNetAggregates']==2 and api32_contract['expectedLoadedCohorts']=={'DDR_BYTE0':6,'DDR_BYTE1':11,'DDR_COMMAND_CLOCK':14}and api32_contract['expectedProjectionFiles']==6
  binding(api32_contract['pythonInterpreterPin'])

 def closed69():
   assert proposal['actual69Sealed']is True,'Authentic successful API69 collection remains future'
   prior=closed68();assert prior['actualClosedScopeCount']==68
   for key in('actual69CollectionPin','actual69PostauditPin','actual69ModelPin','actual69ProofPin','actual69RemovalInversePin','actual69ApiReportPin','actual69GuardManifestPin'):
    assert isinstance(proposal[key],dict);binding(proposal[key])
   assert isinstance(proposal['actual69PhasePostauditPins'],list)and len(proposal['actual69PhasePostauditPins'])==2
   for row in proposal['actual69PhasePostauditPins']:binding(row)
   r=read(proposal['actual69CollectionPin']['path']);p=read(proposal['actual69PostauditPin']['path'])
   assert r['authorizedByRoot']is r['toolSessionCollected']is True and type(proposal['actual69ToolSessionId'])is int and r['toolSessionId']==proposal['actual69ToolSessionId']and r['toolWrapperExitCode']==r['toolExitCode']==0
   assert r['scope']==p['scope']=='ROOT_SOURCE32_FRESH49_PROJECTION_AND_ORIGINAL_API151_PLUS2_JOINT_WITH68_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='projection-api-batch'
   assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['native32PreparationPin']['sha256']and r['coreSourceManifestSha256']==p['coreSourceManifestSha256']==proposal['promoted32ManifestPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual69GuardManifestPin']['sha256']
   assert r['postauditPath']==proposal['actual69PostauditPin']['path']and sha(r['postauditPath'])==r['postauditSha256']==proposal['actual69PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and r['phases']==p['phases']
   assert all(key not in p for key in('execution','outputFiles','packetSha256')),'Two real children, no synthetic standalone receipt'
   assert r['independentlyObservedAllOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
   assert len(p['phases'])==2 and p['orderedPhaseNames']==p['expectedPhaseNames']==['projection','api']and p['notAttemptedPhaseNames']==[]
   identity=p['sameGuardIdentity'];assert type(identity['pid'])is int and identity['pid']==proposal['actual69GuardPid']and not Path('/proc',str(identity['pid'])).exists()
   assert [x['execution']['pgid']for x in p['phases']]==proposal['actual69Pgids']and len(set(proposal['actual69Pgids']))==2
   assert r['independentlyObservedOwnedGroupMembers']=={str(pg):[]for pg in proposal['actual69Pgids']}
   for doc in(r,p):
    for key in('guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','bothChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','passedMeansFresh49ProjectionAndOriginalLoaded32Api151Plus2JointOnly','hardwareAcceptanceCheckpointUnchanged','projectionPassed','apiPassed','projectionBeforeApiSeriallyEnforced','originalApiMethodInvocationCountNotInstrumented','mixedWholeNetJointAggregatesPassed'):assert doc[key]is True
    for key in('batchFailure','finalVerificationFailure','originalApiCalls'):assert doc[key]is None
    for key in('Source32Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
    assert doc['originalApiBooleanPredicates']==151 and doc['additionalJointNetAggregates']==2 and doc['CoreCalls']==doc['nativeCalls']==doc['cliCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
   assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
   owned=[];previous=None
   for phase,row,pin in zip(('projection','api'),p['phases'],proposal['actual69PhasePostauditPins']):
    assert row['phase']==phase and row['guardIdentityBefore']==row['guardIdentityAfter']==identity
    for key in('passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0'):assert row[key]is True
    for key in('runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure'):assert row[key]is None
    assert row['phaseSnapshotsBefore']==row['phaseSnapshotsAfter']and row['phaseSnapshotsBefore']['board']==p['dependenciesBefore']and row['phaseSnapshotsBefore']['solver']==p['solverDependenciesBefore']
    assert row['postauditPath']==pin['path']and row['postauditSha256']==pin['sha256']and read(pin['path'])=={k:v for k,v in row.items()if k not in('postauditPath','postauditSha256')}
    e=row['execution'];h.finite(e,0);assert e['policy']==api32_contract['phasePolicies'][phase]and e['command']==row['command']and e['currentGuardPid']==identity['pid']and type(e['pgid'])is int and e['pgid']>0 and e['pgid']not in owned and c.guard.process_scope.owned(e['pgid'])==[];owned.append(e['pgid'])
    if previous is not None:assert previous['endedAt']<=e['startedAt']
    previous=e;binding(row['packetPin'])
    if row['authorityPin']is not None:binding(row['authorityPin'])
    for output in row['outputFiles']:binding(output)
    for key in('Source32Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady'):assert row[key]is False
    assert row['CoreCalls']==row['nativeCalls']==row['cliCalls']==row['cadCalls']==0
   projection,api=p['phases'];assert p['projectionExecution']==projection['execution']and p['apiExecution']==api['execution']and len(projection['outputFiles'])==6 and len(api['outputFiles'])==1
   assert projection['result']==dict(actualFresh49Model=proposal['actual69ModelPin'],actualFresh49ProjectionProof=proposal['actual69ProofPin'],actualRemovableCarrierGeometryInverse=proposal['actual69RemovalInversePin'],source32FreshFull49ProjectionPassed=True,actual49Requests=49,actualFixedTraces=263,actualHardObstacles=1298,actualSignalViaEvents=98,zeroSelected32CarrierBodiesSeeded=True,actualCarrierWireBodyRowsRemoved=34,actualIntermediateCarrierViasRemoved=2)
   assert api['result']==dict(actualOriginalApiReportPin=proposal['actual69ApiReportPin'],originalApiLoaded32ChecksPassed=True,originalApiBooleanPredicates=151,additionalJointNetAggregates=2,mixedWholeNetJointAggregatesPassed=True,apiMethodInvocationCount=None,methodCountNotInstrumented=True,bothDqs1CoupledViewsPassed=True,loadedCohortsExplicitlyPartial=dict(DDR_BYTE0=6,DDR_BYTE1=11,DDR_COMMAND_CLOCK=14))and api['originalApiCalls']is None and api['originalApiBooleanPredicates']==151 and api['additionalJointNetAggregates']==2 and api['mixedWholeNetJointAggregatesPassed']is True
   assert p['actualFresh49Model']==proposal['actual69ModelPin']and p['actualFresh49ProjectionProof']==proposal['actual69ProofPin']and p['actualCoreSha256']==proposal['actual67CoreRawPin']['sha256']and p['actualNativeReport']==proposal['actual68ReportPin']
   proof=read(proposal['actual69ProofPin']['path']);model=read(proposal['actual69ModelPin']['path']);v=read(proposal['actual69ApiReportPin']['path']);inverse=read(proposal['actual69RemovalInversePin']['path'])
   assert proof['actualCoreSha256']==proposal['actual67CoreRawPin']['sha256']and proof['actualNativeReportSha256']==proposal['actual68ReportPin']['sha256']and proof['constructorInputSha256']==proposal['actual69ModelPin']['sha256']and proof['sourceManifestSha256']==proposal['promoted32ManifestPin']['sha256']and proof['originalSource32ProposalSha256']==proposal['promoted32ProposalPin']['sha256']and proof['exactFullInverseToFresh32Parent']is True
   assert proof['raw229BarrelsExplicitlyPartitioned']is proof['unseededFixed227BarrelsRepresentedExactlyOnce']is proof['intermediateViasNeverSerializedAsFixedFanouts']is True and len(proof['removedIntermediateCarrierViaIds2'])==2
   assert inverse['scope']=='ACTUAL_CORE32_CARRIER_BODY_AND_INTERMEDIATE_VIA_EXCLUSIONS_NOT_FIXED_FANOUT'and inverse['sourceManifestSha256']==proposal['promoted32ManifestPin']['sha256']and inverse['actualCoreSha256']==proposal['actual67CoreRawPin']['sha256']and inverse['actualNativeReportSha256']==proposal['actual68ReportPin']['sha256']
   assert len(inverse['excludedBodyRows34'])==34 and len(inverse['excludedIntermediateViaRows2'])==2 and len(inverse['excludedCarrierObstacles2'])==2 and len(inverse['excludedPlaceholderComponents2'])==2 and len(inverse['removedRawRows52'])==52
   for key in('exactFullRawRowInverseProved','exactRaw1398ObstacleInverseProved','exactRaw509ComponentInverseProved','newIntermediateViasNotSerializedAsFanouts','rawCircuitUnmodified'):assert inverse[key]is True
   assert inverse['rawPhysicalVias229']==229 and inverse['unseededFixedPhysicalBarrels227']==227 and inverse['originalEndpointFanouts98']==98 and inverse['originalReferenceBarrels129']==129
   assert len(model['connections'])==49 and len(model['traces'])==263 and len(model['obstacles'])==1298 and model['layerCount']==4 and sum(q['route_type']=='via'for t in model['traces']for q in t['route'])==98
   assert v['scope']=='ACTUAL_SOURCE32_TWO_INTERMEDIATE_VIAS_ALL3_UNCHANGED_PRIVATE_APIS_PER_RUN_DIAGNOSTIC'and v['packetSha256']==api['packetPin']['sha256']and v['actualCoreSha256']==proposal['actual67CoreRawPin']['sha256']and v['actualNativeReportSha256']==proposal['actual68ReportPin']['sha256']and v['original49Input']=={k:proposal['actual69ModelPin'][k]for k in('path','sha256')}
   assert v['actualCompleteOriginalSignalCount']==32 and v['expectedMissingOriginalSignalCount']==17 and v['allOriginalApiLoaded32ChecksPassed']is True
   assert v['checkInventory']['allOriginalApiBooleanPredicates']==151 and v['checkInventory']['additionalJointNetAggregates']==2 and v['checkInventory']['originalApiPlusJointAggregateGates']==153 and v['checkInventory']['actualWireRunRows']==34
   assert len(v['jointNetChecks'])==len(v['fullSpanViaCoverage'])==2 and {x['connectionName']for x in v['jointNetChecks']}=={'source_trace_20','source_trace_21'}and all(x['passed']is True for x in v['jointNetChecks'])
   assert {x['originalSourceTraceId']for x in v['fullSpanViaCoverage']}=={'source_trace_20','source_trace_21'}and all(x['allFourLayersIncluded']is x['foreignScenesDoNotIgnoreThisOwner']is True and x['capsuleCount']==4 for x in v['fullSpanViaCoverage'])
   assert v['secondaryDqs1View']['geometryAndEndpointsUnchanged']is v['secondaryDqs1View']['passed']is v['exactMaterialHeld']is v['fullOriginalBusRostersAndConstraintsHeld']is v['originalFullDifferentialPairArrayUnchanged']is v['originalPrivateContinuousApiImplementationsUnchanged']is True
   for key in('complete32Accepted','accepted49','fabricationReady','referenceQualified','fullCohortTimingPassed','electricalDelayModelQualified'):assert v[key]is False
   assert {proposal['actual69ModelPin']['path'],proposal['actual69ProofPin']['path'],proposal['actual69RemovalInversePin']['path']}.issubset({x['path']for x in projection['outputFiles']})and api['outputFiles']==[proposal['actual69ApiReportPin']]
   assert projection['command']==[api32_contract['pythonInterpreterPin']['path'],'-B',api32_contract['projectorPin']['path'],projection['packetPin']['path'],projection['packetPin']['sha256'],str(Path(proposal['actual69ModelPin']['path']).parent)]
   assert api['command']==[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',api32_contract['apiWorkerPin']['path'],api['packetPin']['path'],api['packetPin']['sha256'],api['authorityPin']['path'],api['authorityPin']['sha256'],proposal['actual68ReportPin']['path'],proposal['actual69ApiReportPin']['path']]
   prior['actual69Fresh49AndOriginalApi151Plus2CollectionPin']={k:proposal['actual69CollectionPin'][k]for k in('path','sha256')};prior['actualClosedScopeCount']=69;prior['actual69TwoChildrenDoNotQualifyCliCadFull49OrElectrical']=True
   return prior

 def cli32_bindings():
   api32_bindings();binding(proposal['cli32StageContractPin']);binding(proposal['cli32PreparationPin'])
   for row in cli32_preparation['files']+cli32_preparation['externalFiles']:binding(row)
   assert cli32_contract['requiredPriorScopeCount']==69 and cli32_policy=={'wallSeconds':90,'rssBytes':2147483648,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}and cli32_contract['sharedReserveBytes']==1073741824
   assert cli32_contract['cliWorkerPin']in cli32_preparation['files']and cli32_contract['cliPreparationPin']==proposal['cli32PreparationPin']
   assert cli32_preparation['genuineSourceManifestSha256']==proposal['promoted32ManifestPin']['sha256']and cli32_preparation['requiresNativeSourceManifestSha256']==cli32_preparation['requiresApiSourceManifestSha256']==proposal['native32PreparationPin']['sha256']
   binding(cli32_contract['pythonInterpreterPin'])

 cli32_bindings()
 assert out.parent==Path('/tmp')and out.name.startswith('g350-source32-cli-root-')and out.resolve()==out and not out.exists()and not out.is_symlink()
 with(ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  prior=closed69();assert prior['actualClosedScopeCount']==cli32_contract['requiredPriorScopeCount']==69
  identity_before=guard_identity();_,native_before,board_before,solver_before,_=c.guard.checked();bindings();git_before=git_inventory();assert git_before==base['gitMetadataFiles']
  assert board_before['treeSha256']==stage['boardSdkTreeSha256']and solver_before['treeSha256']==stage['solverSdkTreeSha256']
  workspace_floor=shutil.disk_usage('/workspace').free;out.mkdir(mode=0o700);(out/'bun-cache').mkdir(mode=0o700);(out/'tmp').mkdir(mode=0o700);output=out/'output';output.mkdir(mode=0o700)
  authority={**cli32_preparation['actualPrerequisites'],'authorizedByRoot':True,'scope':cli32_preparation['scope'],'sourceManifestSha256':proposal['cli32PreparationPin']['sha256'],'genuineSourceManifestSha256':proposal['promoted32ManifestPin']['sha256'],'actualNativeSourceManifestSha256':proposal['native32PreparationPin']['sha256'],'actualApiSourceManifestSha256':proposal['native32PreparationPin']['sha256'],'actualPreviousScopesCollectedAndEmpty':True,'noConcurrentRootWorker':True,'rootFullWorkerReadPassed':True,'rootGuardProposalManifestSha256':source_sha,'actualClosedPriorScopes':prior,'outputDirectory':str(output),'policy':cli32_policy,'nonce':secrets.token_hex(32),'all49Accepted':False,'fabricationReady':False}
  ap=out/'ROOT_AUTHORITY.json';write(ap,authority);authority_sha=sha(ap)
  command=[cli32_contract['pythonInterpreterPin']['path'],'-B',cli32_contract['cliWorkerPin']['path'],'--root-receipt',str(ap),'--root-receipt-sha256',authority_sha,'--output-directory',str(output)]
  environment={'NO_COLOR':'1','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(out/'bun-cache'),'TMPDIR':str(out/'tmp'),'G350_SOURCE32_FRESH_JSON_CLI_ROOT_GUARDED':'1'}
  def invariant_check():
   bindings();no_git_redirects();assert closed69()==prior,'Current prior closure differs';assert guard_identity()==identity_before,'Current guard identity differs';assert sha(ap)==authority_sha,'Current authority hash differs';assert git_inventory()==git_before,'Current Git inventory differs';current_free=shutil.disk_usage('/workspace').free;assert current_free>=workspace_floor,f'Current workspace free floor decreased: current={current_free}, before={workspace_floor}'
  def prefork(memory):
   invariant_check();assert memory['current']+cli32_policy['rssBytes']+1073741824<cli32_policy['sharedBytes']and shutil.disk_usage('/tmp').free>=536870912
  execution=None;run_error=post_error=inspection_error=None;native_after=board_after=solver_after=None;result=None;result_passed=False;empty=None
  try:execution=focused_process_runner.run_guarded(command,str(c.BOARD),out/'owned',cli32_policy,environment,before_spawn=prefork)
  except BaseException as error:
   run_error=type(error).__name__+': '+str(error)
   try:
    if(out/'owned/execution.json').is_file():execution=read(out/'owned/execution.json')
   except BaseException as parse_error:run_error+='; execution recovery '+type(parse_error).__name__+': '+str(parse_error)
  try:
   _,native_after,board_after,solver_after,_=c.guard.checked();invariant_check();assert native_before==native_after and board_before==board_after and solver_before==solver_after
  except BaseException as error:post_error=type(error).__name__+': '+str(error)
  held=post_error is None and native_before==native_after and board_before==board_after and solver_before==solver_after
  try:
   assert isinstance(execution,dict);empty=c.guard.process_scope.owned(execution['pgid'])==[]
  except BaseException as error:inspection_error='Owned scope '+type(error).__name__+': '+str(error)
  natural=bool(isinstance(execution,dict)and type(execution.get('exitCode'))is int and execution['exitCode']>=0 and execution.get('diagnosticStopped')is False and not execution.get('stopReasons')and execution.get('cleanupOwnedGroupEmpty')is True and isinstance(execution.get('oomDelta'),dict)and bool(execution['oomDelta'])and not any(execution['oomDelta'].values())and empty is True)
  report=output/'cli-export-report.json';export=output/'g350-source32.kicad_pcb'
  try:
   assert held and run_error is post_error is inspection_error is None and natural and execution['exitCode']in(0,1,2);h.finite(execution,execution['exitCode']);assert execution['policy']==cli32_policy and execution['command']==command and execution['currentGuardPid']==identity_before['pid']and guard_identity()==identity_before and 'guardError'not in execution
   assert {p.name for p in output.iterdir()}=={'fresh-source32.circuit.json','g350-source32.kicad_pcb','pinned-cli.log','cli-export-report.json'}
   for path,limit in((report,4194304),(export,33554432),(output/'fresh-source32.circuit.json',16777216),(output/'pinned-cli.log',4194304)):assert path.is_file()and not path.is_symlink()and 0<=path.stat().st_size<=limit
   result=read(report);assert result['scope']==cli32_preparation['scope']and result['sourceManifestSha256']==proposal['cli32PreparationPin']['sha256']and result['actualCoreSha256']==proposal['actual67CoreRawPin']['sha256']and result['coreControlsSha256']==proposal['actual67CoreControlsPin']['sha256']
   assert result['exportPassed']is True and result['cliExitCode']==0 and result['byteIdenticalCopyOnly']is True and result['recognizedCircuitJsonSha256']==proposal['actual67CoreRawPin']['sha256']and sha(output/'fresh-source32.circuit.json')==proposal['actual67CoreRawPin']['sha256']
   assert result['outputPath']==str(export)and result['outputSha256']==sha(export)and export.stat().st_size>0 and result['actualSourceSegmentCount']==1116 and result['actualSourceOwnedCarrierCount']==32 and result['actualPhysicalViaCount']==229 and result['actualPhysicalTraceCount']==297 and result['sourceOnlyMissingRoutes']==17
   assert result['nativeAndOriginalApiStagesPassed']is True and result['actualNativeReport']==cli32_preparation['actualPrerequisites']['actualNativeReport']==proposal['actual68ReportPin']and result['actualOriginalApiReport']==cli32_preparation['actualPrerequisites']['actualOriginalApiReport']==proposal['actual69ApiReportPin']
   assert result['argv']==[cli32_preparation['bun'],'--smol',cli32_preparation['cliMainPath'],'export',str(output/'fresh-source32.circuit.json'),'--format','kicad_pcb','--output',str(export),'--disable-parts-engine']
   for key in('originalRawEdited','sourceModuleEvaluated','sourcePortHookReplayedByCli','automaticCoreSrjUsed','complete32Accepted','referenceQualified','electricalTimingQualified','accepted49','fabricationReady'):assert result[key]is False
   result_passed=bool(natural and execution['exitCode']==0)
  except BaseException as error:inspection_error=(inspection_error+'; 'if inspection_error else'')+type(error).__name__+': '+str(error)
  files=[file_row(p)for p in sorted([*out.iterdir(),*output.iterdir()])if p.is_file()and not p.is_symlink()]
  post=dict(scope='ROOT_SOURCE32_FRESH_PINNED_CLI_WITH69_AUTHENTIC_PRIOR_CLOSURES',phase='cli',sourceManifestSha256=proposal['cli32PreparationPin']['sha256'],rootGuardProposalManifestSha256=source_sha,execution=execution,actualClosedPriorScopes=prior,sourceAndDependenciesHeld=held,dependenciesBefore=board_before,dependenciesAfter=board_after,solverDependenciesBefore=solver_before,solverDependenciesAfter=solver_after,runFailure=run_error,postverificationFailure=post_error,resultInspectionFailure=inspection_error,ownedGroupEmptyActuallyObserved=empty,stageNaturallyCompleted=natural,ownedChildNatural0=natural and execution['exitCode']==0,resultPassed=result_passed,passed=result_passed,reportPath=str(report),reportSha256=sha(report)if report.is_file()and not report.is_symlink()else None,exportPath=str(export),exportSha256=sha(export)if export.is_file()and not export.is_symlink()else None,actualCoreSha256=proposal['actual67CoreRawPin']['sha256'],actualCoreControlsSha256=proposal['actual67CoreControlsPin']['sha256'],CoreCalls=0,nativeCalls=0,originalApiCalls=0,cliCalls=1 if isinstance(result,dict)else None,cadCalls=0,Source32Accepted=False,hardwareAcceptanceCheckpointUnchanged=True,newRoutesAdopted=0,referenceQualified=False,electricalTimingPassed=False,all49Accepted=False,accepted49=False,fabricationReady=False,workspaceFreeBytesBefore=workspace_floor,workspaceFreeBytesFloorHeld=post_error is None,gitMetadataHeld=post_error is None,outputFiles=files,toolSessionCollected=False)
  pp=out/'POSTAUDIT.json';write(pp,post);print(json.dumps(dict(passed=result_passed,phase='cli',postauditPath=str(pp),postauditSha256=sha(pp),execution=execution)))
 return 0 if result_passed else 2

if __name__=='__main__':raise SystemExit(main())
