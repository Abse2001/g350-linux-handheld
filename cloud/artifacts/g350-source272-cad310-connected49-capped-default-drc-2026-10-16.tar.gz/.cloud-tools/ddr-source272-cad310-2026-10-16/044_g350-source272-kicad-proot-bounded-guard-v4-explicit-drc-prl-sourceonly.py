#!/usr/bin/env python3
"""SOURCE ONLY. Root-run trusted KiCad stages in a single exact PRoot rootfs.
No author execution. All PRoot/guest descendants inherit the reviewed owned PGID;
original sampled2GiB/180s/shared30GiB/+1GiB reserve are preserved. PRoot is NOT
kernel read-only or network isolation. No board save/refill command is allowed.
"""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

BOARD=Path('/workspace/g350-linux-handheld')
CACHE=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
STAGE=BOARD/'dist/g350-source272-kicad49-root-20261016'
ROOTFS=BOARD/'.cloud-tools/kicad10-single-rootfs-root-20261016/ROOTFS.json'
ROOTFS_SHA='61b8b426aaa3220d5413480cc0e32f901e367020d723fc0496ca9489b97f14c9'
WORKER=Path('/tmp/g350-source272-kicad-proot-worker-v3-private-fontconfig-sourceonly.py')
WORKER_SHA='f3b441e3b5f6c4667c2ca45ce533d4d765ea0164f2946c6afc84d4c292f39ac7'
PREFLIGHT=Path('/tmp/g350-source272-kicad-proot-api-preflight-sourceonly.py')
PREFLIGHT_SHA='19b001bb9eab1e8b57de0b5f15a8009bbd8c1d9f55bf828bdc3745f58b6e79ec'
VERIFIER=Path('/tmp/g350-source272-kicad49-verify-v2-sourceonly.py')
VERIFIER_SHA='8c911f2e47d1e23b198fe275f9e616fb2094498792cefd960ce5387d8b85d0d5'
HELPER=Path('/tmp/g350-process-scope-empty-argv-bounded-startup-retry-sourceonly-next/process_scope_empty_argv_retry.proposal.py')
HELPER_SHA='3756c2f9bfc8284135954669c0a1cbe0e5e966796b0743c6f462af703e17a361'
MANIFEST=Path('/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/SOURCE-manifest.json')
MANIFEST_SHA='b9700a9a44c9be5f661fd38c37ca9ff6c2f012983e49a750fecea3c8d75e19e0'
PROTECTED={
 'AGENTS.md':'d3086d9ff8887bd296ed0d480fcbef732686bf45e075ae766a0a292518086723',
 'cloud/CONTINUE_BOARD.md':'bb9a879c5c68c3718d24c82a77326f5b175d47899f101407b1e1ee106c8b19ef',
 'scripts/prepare-g350-ram90-four-layer.mjs':'ec6b56c59d2c8f72f969934076dd3597014833e8b2e8e4387c1045f03eaadda0',
 'scripts/tune-g350-ram90-native-lengths.mjs':'5bfe731744159cf9f65ddde71b513cb1a0d2384574e740cd11bc087ce69b4b40',
 'node_modules/@tscircuit/checks/dist/index.js':'1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc',
 'node_modules/@tscircuit/core/dist/index.js':'97b8a4eb484630c3ce2bfc2d68588801484d85adf94785d8849a1d91c4404905',
 'node_modules/@tscircuit/cli/dist/cli/main.js':'2135bc7f5e27b72ddfaa9b65586c905897e4222f989328ebc0434b1d1961c19c'}
INPUTS={
 STAGE/'source272-via-key-bridge.circuit.json':'53a6975d24aed09d7669d0eef2a54b12d6a715772e4467c4d6ac7a1dba63a4d1',
 STAGE/'source272-kicad49-expected.json':'4e04245bee872685747fd1ed5deb8dfa4dbedbc31e93d195679b071d70506a3f',
 STAGE/'SERIALIZER_BRIDGE.json':'0a9321f765cd36af2eb06d8cad22f6319b06693b38253457c264fa3cacf0288a',
 STAGE/'original-source272.circuit.json':'33584d197a1bb45a0dc76ac0a69e7016866a2369f1750c72d5eedc41ef444594',
 Path('/tmp/g350-both-bytes-ca9-matched49-core272-raw.json'):'33584d197a1bb45a0dc76ac0a69e7016866a2369f1750c72d5eedc41ef444594'}

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
  if hasattr(os,'posix_fadvise'):os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 return h.hexdigest()
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('run',type=Path)
 ap.add_argument('--expected-scope',type=int,required=True);ap.add_argument('--mode',choices=('preflight','drc','verify'),required=True)
 ap.add_argument('--board-sha',required=True);ap.add_argument('--drc-sha');ap.add_argument('--drc-exit-code',type=int)
 ap.add_argument('--preflight-report-sha');args=ap.parse_args();run=args.run
 assert run.is_absolute() and str(run).startswith('/tmp/g350-') and run.resolve()==run and not run.exists(),'Fresh public owned run'
 assert STAGE.is_dir() and STAGE.resolve()==STAGE and re.fullmatch('[0-9a-f]{64}',args.board_sha)
 for p,h in [(WORKER,WORKER_SHA),(PREFLIGHT,PREFLIGHT_SHA),(HELPER,HELPER_SHA),(MANIFEST,MANIFEST_SHA),(ROOTFS,ROOTFS_SHA)]:
  assert p.is_file() and not p.is_symlink() and sha(p)==h,'Exact reviewed runtime/preflight/helper/material pin'
 sys.dont_write_bytecode=True
 worker=load('trusted_proot_worker',WORKER);owned=load('owned_scope',HELPER)
 solver_pins=json.loads(MANIFEST.read_text())['solverSourceFiles'];assert len(solver_pins)==120
 board_path=STAGE/'source272-bridged-fresh.kicad_pcb';input_pins={**INPUTS,board_path:args.board_sha,ROOTFS:ROOTFS_SHA}
 api_report=STAGE/'SOURCE272_KICAD10_API_PREFLIGHT.json';drc=STAGE/'source272-full-unfiltered-drc.json'
 auxiliary=None;auxiliary_sha=None
 if args.mode=='preflight':
  target=api_report;auxiliary=PREFLIGHT;auxiliary_sha=PREFLIGHT_SHA
  trusted=['xvfb-run','-a','/usr/bin/python3','-B','/g350-runtime/stage-script.py','--output',str(target)]
 else:
  assert args.preflight_report_sha and re.fullmatch('[0-9a-f]{64}',args.preflight_report_sha)
  assert worker.regular(api_report) and sha(api_report)==args.preflight_report_sha
  proof=worker.read(api_report)
  assert proof['passed'] is True and proof['boardLoaded'] is False and proof['version'].startswith('10.0.6'),'Actual bounded API preflight first'
  input_pins[api_report]=args.preflight_report_sha
  if args.mode=='drc':
   target=drc;trusted=['/usr/bin/kicad-cli','pcb','drc',str(board_path),'--format','json','--severity-all',
    '--all-track-errors','--exit-code-violations','-o',str(drc)]
  else:
   assert args.drc_sha and re.fullmatch('[0-9a-f]{64}',args.drc_sha) and args.drc_exit_code is not None
   assert worker.regular(VERIFIER) and sha(VERIFIER)==VERIFIER_SHA
   target=STAGE/'SOURCE272_KICAD49_READ_ONLY_REPORT.json';auxiliary=VERIFIER;auxiliary_sha=VERIFIER_SHA
   input_pins[drc]=args.drc_sha
   trusted=['xvfb-run','-a','/usr/bin/python3','-B','/g350-runtime/stage-script.py',
    '--board',str(board_path),'--board-sha',args.board_sha,
    '--expected',str(STAGE/'source272-kicad49-expected.json'),'--expected-sha',INPUTS[STAGE/'source272-kicad49-expected.json'],
    '--bridge',str(STAGE/'SERIALIZER_BRIDGE.json'),'--bridge-sha',INPUTS[STAGE/'SERIALIZER_BRIDGE.json'],
    '--drc',str(drc),'--drc-sha',args.drc_sha,'--drc-exit-code',str(args.drc_exit_code),
    '--output',str(target),'--budget-ms','130000']
 assert not target.exists() and not target.is_symlink(),'No output overwrite'
 if auxiliary is not None:input_pins[auxiliary]=auxiliary_sha
 def verify():
  for pin in solver_pins:
   p=Path(pin['path']);assert worker.regular(p) and sha(p)==pin['sha256'] and p.stat().st_size==pin['bytes'],p
  for rel,h in PROTECTED.items():assert worker.regular(BOARD/rel) and sha(BOARD/rel)==h,rel
  for p,h in input_pins.items():assert worker.regular(p) and sha(p)==h,str(p)
 verify();policy={'wallSeconds':180,'rssBytes':2*1024**3,'sharedBytes':30*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
 def admit(m):assert m['current']+policy['rssBytes']+1024**3<policy['sharedBytes'],('memory admission',m['current'])
 journal=CACHE/'LATEST_CONTINUATION_2026-10-14.json'
 with (CACHE/'strict18-root-serial.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX);state=json.loads(journal.read_text());assert not state.get('rootSdkInvocationOpen')
  scope=int(state.get('requiresCurrentClosedScopes',88))+1;assert scope==args.expected_scope,('Exact current scope',scope)
  verify();assert not target.exists() and not target.is_symlink();previous_umask=os.umask(0o077);run.mkdir(parents=True,exist_ok=False)
  job={'run':str(run),'stage':str(STAGE),'scope':scope,'mode':args.mode,'rootfsManifest':str(ROOTFS),'rootfsManifestSha256':ROOTFS_SHA,
   'stageInventory':worker.inventory(STAGE),'trustedCommand':trusted,'allowedOutputs':[target.name]+([board_path.with_suffix('.kicad_prl').name] if args.mode=='drc' else []),
   'auxiliaryScriptPath':str(auxiliary) if auxiliary else None,'auxiliaryScriptSha256':auxiliary_sha}
  job_path=run/'job.json';worker.save(job_path,job)
  command=[sys.executable,str(WORKER),'--job',str(job_path),'--job-sha',sha(job_path)]
  before={str(p):sha(p) for p in [Path(__file__).resolve(),WORKER,PREFLIGHT,HELPER,MANIFEST,job_path,*input_pins]}
  state.update(rootSdkInvocationOpen=True,activeRootScope=scope,lastAction=owned.utc(),
   nextOperation='Bounded trusted single-rootfs PRoot Source272 KiCad '+args.mode+'; no whole-board qualification',currentRouteRun=str(run))
  journal.write_text(json.dumps(state,indent=2)+'\n')
  execution=None;guard_error=None;errors=[];published=[];pins_ok=False;material_ok=False
  try:execution=owned.run_guarded(command,str(BOARD),run/'owned',policy,before_spawn=admit)
  except BaseException as exc:guard_error={'type':type(exc).__name__,'message':str(exc)}
  finally:
   path=run/'owned/execution.json';actual=execution if execution is not None else worker.read(path) if path.exists() else None
   group_empty=bool(actual and actual.get('cleanupOwnedGroupEmpty') is True)
   if actual and actual.get('pgid'):group_empty=group_empty and owned.owned(actual['pgid'])==[]
   try:
    verify();assert all(worker.regular(Path(p)) and sha(Path(p))==h for p,h in before.items());pins_ok=True
   except BaseException as exc:errors.append({'phase':'pinVerification','type':type(exc).__name__,'message':str(exc)})
   if group_empty:
    try:worker.verify_rootfs(ROOTFS,ROOTFS_SHA);material_ok=True
    except BaseException as exc:errors.append({'phase':'rootfsMaterialVerification','type':type(exc).__name__,'message':str(exc)})
   runtime_path=run/'proot-runtime.json';runtime=worker.read(runtime_path) if runtime_path.exists() else None
   try:
    if group_empty and pins_ok and material_ok and (run/'original-output-inventory.json').exists():published=worker.publish(job)
   except BaseException as exc:errors.append({'phase':'newReportPublication','type':type(exc).__name__,'message':str(exc)})
   receipt={'scope':scope,'closedAt':owned.utc(),'execution':actual,'guardError':guard_error,'errors':errors,
    'sourcePinsUnchanged':pins_ok,'protectedFilesUnchanged':pins_ok,'inputFilesUnchanged':pins_ok,
    'rootfsImageFileAndLinkMaterialUnchanged':material_ok,'hostOwnedGroupEmpty':group_empty,
    'runtime':runtime,'publishedNewOutputs':published,'actualKiCadExitCode':runtime.get('actualKiCadExitCode') if runtime else None,
    'inputBindings':[{'path':p,'sha256':h} for p,h in before.items()],
    'prootAndTrustedCommandInheritOwnedPgid':True,'kernelReadOnlyFilesystemEnforced':False,'networkNamespaceIsolationEnforced':False,
    'prootIsPathTranslationOnly':True,'trustedReviewedCommandsOnly':True,'intendedBoardSaveOrRefill':False,
    'cadConnectivityQualified':False,'cadManufacturingQualified':False,'all49Accepted':False,'fabricationReady':False}
   worker.save(run/'COLLECTED.json',receipt)
   state=json.loads(journal.read_text());state.update(rootSdkInvocationOpen=False,activeRootScope=None,requiresCurrentClosedScopes=scope,
    lastAction=owned.utc(),lastRouteCollection=str(run/'COLLECTED.json'));journal.write_text(json.dumps(state,indent=2)+'\n');os.umask(previous_umask)
  print(json.dumps({'run':str(run),'scope':scope,'mode':args.mode,'exitCode':actual.get('exitCode') if actual else None,
   'ownedGroupEmpty':group_empty,'imageMaterialUnchanged':material_ok,'publishedOutputs':published,
   'guardError':guard_error,'errors':errors,'cadConnectivityQualified':False,'fabricationReady':False}))
  if guard_error or errors or not group_empty or not pins_ok or not material_ok:raise SystemExit(1)
  raise SystemExit(actual['exitCode'] if actual is not None else 1)

if __name__=='__main__':main()
