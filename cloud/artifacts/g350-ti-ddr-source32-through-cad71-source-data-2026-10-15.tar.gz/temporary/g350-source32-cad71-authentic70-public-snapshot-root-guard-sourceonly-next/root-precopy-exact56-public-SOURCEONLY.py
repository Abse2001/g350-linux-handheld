"""SOURCE ONLY until Root invokes: exact public /tmp copies, no apps or authority."""
import hashlib,json,pathlib,re,stat,sys
PLAN = {'path': '/tmp/g350-source32-cad71-authentic70-public-snapshot-root-guard-sourceonly-next/SNAPSHOT_COPY_INPUTS.json', 'sha256': '3a4c5d98b59bb76dbb1de31fcadc194bec0cc00e502e7a7a97d2ff519cef9d89', 'bytes': 45057, 'mode': 384}
PRIVATE = {'ROOT_CAD_AUTHORITY.json', 'ROOT_AUTHORITY.json', 'API-BOUND.json', 'BOUND.json', 'BOUND-manifest.json', 'API_ROOT_AUTHORITY.json', 'PROJECTION-BOUND.json', 'BOUND_MANIFEST.json'}
def pin(path):
 p=pathlib.Path(path);b=p.read_bytes();s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink()and p.resolve()==p
 return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),mode=stat.S_IMODE(s.st_mode))
def main():
 assert len(sys.argv)==1 and pin(PLAN['path'])==PLAN
 plan=json.loads(pathlib.Path(PLAN['path']).read_text());run=pathlib.Path(plan['runRoot']);root=pathlib.Path(plan['snapshotRoot'])
 assert run.parent==pathlib.Path('/tmp')and re.fullmatch('g350-source32-cad-root-[A-Za-z0-9_-]+',run.name)and not run.exists()and not run.is_symlink()and run.resolve()==run
 assert root.parent==run/'snapshots'and re.fullmatch('[0-9a-f]{32}',root.name)
 assert len(plan['snapshots'])==plan['requiredSparseFileCount']and sum(x['original']['bytes']for x in plan['snapshots'])==plan['requiredSparseBytes']<=67108864
 for row in plan['snapshots']:
  assert pathlib.Path(row['original']['path']).name not in PRIVATE and pin(row['original']['path'])==row['original']
 run.mkdir(mode=0o700);(run/'snapshots').mkdir(mode=0o700);root.mkdir(mode=0o700)
 for row in plan['snapshots']:
  original=row['original'];target=root/row['snapshotRelativePath'];assert target==pathlib.Path(row['snapshotPath'])and target.is_relative_to(root)and row['containerTargetPath']==original['path']
  target.parent.mkdir(mode=0o700,parents=True,exist_ok=True);assert not target.exists()and not target.is_symlink()
  with target.open('xb')as stream:stream.write(pathlib.Path(original['path']).read_bytes())
  target.chmod(original['mode']);assert pin(target)=={**original,'path':str(target)}and pin(original['path'])==original
 assert pin(PLAN['path'])==PLAN
 report={'scope':'ROOT_SOURCE32_CAD71_PUBLIC_INPUT_PRECOPY_ONLY_NOT_CAD_OR_AUTHORITY','copyPlanPin':PLAN,'runtimeSourceManifest':plan['runtimeSourceManifest'],'runRoot':str(run),'snapshotRoot':str(root),'actualCopiedFileCount':len(plan['snapshots']),'actualCopiedBytes':plan['requiredSparseBytes'],'allOriginalsAndCopiesByteSizeModeHeld':True,'allHistoricalActualAuthorityAndBoundBodiesExcluded':True,'RootAuthorityCreated':False,'SDKOrOperationalHelpersOrAppsExecuted':False,'workspaceWrites':False,'all49Accepted':False,'fabricationReady':False}
 p=run/'ROOT_PRECOPY_REPORT.json'
 with p.open('x')as stream:json.dump(report,stream,indent=2);stream.write('\n')
 p.chmod(0o600);print(json.dumps({'report':pin(p),'files':len(plan['snapshots']),'bytes':plan['requiredSparseBytes']}))
if __name__=='__main__':main()
