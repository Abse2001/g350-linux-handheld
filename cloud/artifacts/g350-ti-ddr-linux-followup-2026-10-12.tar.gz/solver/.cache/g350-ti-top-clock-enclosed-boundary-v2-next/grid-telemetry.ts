type Constructor = new (...args: any[]) => any
type Stage =
  | "center"
  | "package_cpu"
  | "package_ram"
  | "enclosed_terminal"
  | "unknown"
type Row = {
  id: number
  connection: string
  stage: Stage
  layer: string
  callsite: string
  constructorMs: number
  constructorThrew: boolean
  nx: number | null
  ny: number | null
  cellCount: number | null
  maxLength: number | string | null
  checkReachability: boolean
  start: { x: number; y: number } | null
  end: { x: number; y: number } | null
  steps: number
  cancels: number
  stepMs: number
  expanded: number | null
  solved: boolean
  failed: boolean
}

/** Temporary bindings are declared instrumentation. Original instances and
 * method results/errors are preserved. Only scalar records survive a call. */
export function installGridProfile(
  module: { GridVisibilitySearch: Constructor },
  publish: (value: unknown) => void,
  limit = 32,
  replaceConstructor: ((value: Constructor) => void) | undefined = undefined,
  clockMembers: readonly {
    name: string
    pointsToConnect: readonly { x: number; y: number }[]
  }[] = [],
) {
  const Original = module.GridVisibilitySearch
  const exportDescriptor = Object.getOwnPropertyDescriptor(
    module,
    "GridVisibilitySearch",
  )!
  const replace =
    replaceConstructor ??
    ((value: Constructor) =>
      Object.defineProperty(module, "GridVisibilitySearch", {
        ...exportDescriptor,
        value,
      }))
  const prototype = Original.prototype
  const originalStep = prototype.step,
    originalCancel = prototype.cancel
  const stepDescriptor = Object.getOwnPropertyDescriptor(prototype, "step")!,
    cancelDescriptor = Object.getOwnPropertyDescriptor(prototype, "cancel")!
  const rows: Row[] = []
  const byInstance = new WeakMap<
    object,
    { stage: Stage; row?: Row; terminal?: string }
  >()
  const stages = Object.fromEntries(
    [
      "center",
      "package_cpu",
      "package_ram",
      "enclosed_terminal",
      "unknown",
    ].map((stage) => [
      stage,
      {
        constructors: 0,
        steps: 0,
        cancels: 0,
        constructorThrows: 0,
        solved: 0,
        failed: 0,
        unfinishedCancelled: 0,
      },
    ]),
  ) as Record<
    Stage,
    {
      constructors: number
      steps: number
      cancels: number
      constructorThrows: number
      solved: number
      failed: number
      unfinishedCancelled: number
    }
  >
  const classify = (args: any[]): Stage => {
    const [scene, start] = args,
      name = scene?.connection?.name
    if (name === "pair_corridor") return "center"
    const member = clockMembers.find((member) => member.name === name)
    if (!member)
      return typeof name === "string" ? "enclosed_terminal" : "unknown"
    const end = member.pointsToConnect.findIndex(
      (p) => p.x === start?.x && p.y === start?.y,
    )
    return end === 0 ? "package_cpu" : end === 1 ? "package_ram" : "unknown"
  }
  let constructors = 0,
    steps = 0,
    cancels = 0,
    observationErrors = 0,
    constructorThrows = 0,
    restoreCalls = 0
  const observe = (fn: () => void) => {
    try {
      fn()
    } catch {
      observationErrors++
    }
  }
  const scalar = (v: unknown) =>
    typeof v === "number" && Number.isFinite(v) ? v : null
  const state = (row: Row, instance: any) => {
    row.nx = scalar(instance.nx)
    row.ny = scalar(instance.ny)
    row.cellCount = scalar(instance.cellCount)
    row.expanded = scalar(instance.expanded)
    row.solved = instance.solved === true
    row.failed = instance.failed === true
  }
  const trackTerminal = (
    tracking: { stage: Stage; row?: Row; terminal?: string },
    instance: any,
  ) => {
    if (tracking.terminal) return
    if (instance.solved === true) {
      tracking.terminal = "solved"
      stages[tracking.stage].solved++
    } else if (instance.failed === true) {
      tracking.terminal = "failed"
      stages[tracking.stage].failed++
    }
  }
  const snapshot = () => ({
    constructors,
    steps,
    cancels,
    constructorThrows,
    observationErrors,
    rowLimit: limit,
    droppedRows: Math.max(0, constructors - rows.length),
    stages: Object.fromEntries(
      Object.entries(stages).map(([stage, value]) => [stage, { ...value }]),
    ),
    rows: rows.map((row) => ({ ...row })),
  })
  const emit = () => observe(() => publish(snapshot()))
  let constructorProxy: Constructor
  const construct = (args: any[], passedTarget: Constructor) => {
    const newTarget =
      passedTarget === constructorProxy ? Original : passedTarget
    constructors++
    const started = performance.now()
    let row: Row | undefined
    let stage: Stage = "unknown"
    observe(() => {
      stage = classify(args)
      stages[stage].constructors++
      if (rows.length >= limit) return
      const [scene, start, end, , , , grid] = args
      const point = (p: any) =>
        p && Number.isFinite(p.x) && Number.isFinite(p.y)
          ? { x: p.x, y: p.y }
          : null
      row = {
        id: constructors,
        connection: String(scene?.connection?.name ?? "unknown").slice(0, 128),
        stage,
        layer: String(
          scene?.connection?.pointsToConnect?.[0]?.layer ?? "unknown",
        ).slice(0, 32),
        callsite: (
          new Error().stack
            ?.split("\n")
            .find((line) => line.includes("/source/lib/")) ?? "unknown"
        ).slice(0, 384),
        constructorMs: 0,
        constructorThrew: false,
        nx: null,
        ny: null,
        cellCount: null,
        maxLength: Number.isFinite(grid?.maxLength)
          ? grid.maxLength
          : grid?.maxLength === Infinity
            ? "Infinity"
            : null,
        checkReachability: grid?.checkReachability === true,
        start: point(start),
        end: point(end),
        steps: 0,
        cancels: 0,
        stepMs: 0,
        expanded: null,
        solved: false,
        failed: false,
      }
      rows.push(row)
      emit() // Persist before original unyielded constructor work.
    })
    try {
      const instance = Reflect.construct(Original, args, newTarget)
      observe(() => {
        const tracking = { stage, row }
        byInstance.set(instance, tracking)
        trackTerminal(tracking, instance)
        if (row) {
          row.constructorMs = performance.now() - started
          state(row, instance)
        }
      })
      return instance
    } catch (error) {
      constructorThrows++
      observe(() => {
        stages[stage].constructorThrows++
        if (row) {
          row.constructorMs = performance.now() - started
          row.constructorThrew = true
        }
      })
      throw error
    } finally {
      if (constructors <= limit) emit()
    }
  }
  const step = function (this: any, ...args: any[]) {
    steps++
    const tracking = byInstance.get(this),
      row = tracking?.row
    const started = performance.now()
    try {
      return Reflect.apply(originalStep, this, args)
    } finally {
      observe(() => {
        stages[tracking?.stage ?? "unknown"].steps++
        if (tracking) trackTerminal(tracking, this)
        if (row) {
          row.steps++
          row.stepMs += performance.now() - started
          state(row, this)
        }
      })
      if (steps % 250 === 0) emit()
    }
  }
  const cancel = function (this: any, ...args: any[]) {
    cancels++
    const tracking = byInstance.get(this),
      row = tracking?.row
    // Original cancel marks an unfinished search failed as cleanup state.
    // Attribute the existing terminal state before that mutation, so cancellation
    // is not reported as an algorithmic search failure.
    observe(() => {
      if (tracking) trackTerminal(tracking, this)
    })
    try {
      return Reflect.apply(originalCancel, this, args)
    } finally {
      observe(() => {
        stages[tracking?.stage ?? "unknown"].cancels++
        if (tracking) {
          if (!tracking.terminal) {
            tracking.terminal = "unfinished_cancelled"
            stages[tracking.stage].unfinishedCancelled++
          }
        }
        if (row) {
          row.cancels++
          state(row, this)
        }
      })
      if (cancels <= limit) emit()
    }
  }
  const restore = () => {
    if (restoreCalls++) return
    try {
      replace(Original)
    } finally {
      try {
        Object.defineProperty(prototype, "step", stepDescriptor)
      } finally {
        Object.defineProperty(prototype, "cancel", cancelDescriptor)
      }
    }
  }
  try {
    constructorProxy = new Proxy(Original, {
      construct(_target, args, newTarget) {
        return construct(args, newTarget as Constructor)
      },
    })
    replace(constructorProxy)
    Object.defineProperty(prototype, "step", {
      ...stepDescriptor,
      value: step,
    })
    Object.defineProperty(prototype, "cancel", {
      ...cancelDescriptor,
      value: cancel,
    })
  } catch (error) {
    restore()
    throw error
  }
  return {
    snapshot,
    restore,
    Original,
    // Plain Proxy/descriptor wrappers keep no Bun mock histories.
    clearHistories: () => {},
    constructorHistorySizes: () => ({
      calls: 0,
      results: 0,
      instances: 0,
      contexts: 0,
    }),
  }
}
