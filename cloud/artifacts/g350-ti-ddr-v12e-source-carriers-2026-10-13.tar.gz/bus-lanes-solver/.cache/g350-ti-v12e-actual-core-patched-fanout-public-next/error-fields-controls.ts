import assert from "node:assert/strict"
import { ownPublicFailureFields } from "./public-failure-fields"
let assertions = 0, getterCalls = 0, coercionCalls = 0
const check = (value: unknown, expected: unknown) => { assert.deepEqual(ownPublicFailureFields(value), expected); assertions++ }
const expected = (error: string | null, failureCode: string | null, errorFieldKind = "string", failureCodeFieldKind = "string", errorTruncated = false, failureCodeTruncated = false) => ({ error, failureCode, errorFieldKind, failureCodeFieldKind, errorTruncated, failureCodeTruncated })
const healthy = { error: null, failureCode: null }
check(healthy, expected(null, null, "null", "null"))
check({ error: "Cannot route original dogbone", failureCode: "local_dogbone_failed" }, expected("Cannot route original dogbone", "local_dogbone_failed"))
check({ error: "e".repeat(1025), failureCode: "f".repeat(1024) }, expected("e".repeat(1024), "f".repeat(1024), "string", "string", true))
const accessor = Object.defineProperties({}, { error: { get() { getterCalls++; throw Error("Getter must remain uncalled") } }, failureCode: { get() { getterCalls++; return "wrong" } } })
check(accessor, expected(null, null, "accessor", "accessor"))
check(Object.create({ error: "inherited", failureCode: "inherited" }), expected(null, null, "absent", "absent"))
check({ error: { toString() { coercionCalls++; throw Error("Coercion must remain uncalled") } }, failureCode: false }, expected(null, null, "unsupported", "unsupported"))
check(null, expected(null, null, "absent", "absent"))
check(undefined, expected(null, null, "absent", "absent"))
assert.equal(getterCalls, 0); assertions++
assert.equal(coercionCalls, 0); assertions++
assert.deepEqual(healthy, { error: null, failureCode: null }); assertions++
console.log(JSON.stringify({ passed: true, assertions, getterCalls, coercionCalls, solverCalls: 0, nativeCalls: 0, runtimeImports: 0, maximumFieldCharacters: 1024 }))
