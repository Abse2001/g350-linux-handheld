"""Root serial capture/types/Core of the exact-three-path Source successor."""
import fcntl,importlib.util,json,secrets,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
s=importlib.util.spec_from_file_location('smooth_source_parent_stdlib',ROOT/'run-strict18-source-capture-root.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
PACKET=c.BOARD/'.cloud-tools/ddr-strict18-smooth-manual-source-core-successor-next'
SOURCE_SHA='deb65c68de4f7852e9ca1f693251574affaab4fb7ce27a07dfd70144e2641707'
CORE_SHA='1159cf6013a1a32820568ae1a2c87e35b9a77176698c07c92a5de803dd2b9dd9'
def bindings():
 assert c.sha(PACKET/'SOURCE-manifest.json')==SOURCE_SHA and c.sha(PACKET/'CORE-manifest.json')==CORE_SHA
 m=c.read(PACKET/'SOURCE-manifest.json');cm=c.read(PACKET/'CORE-manifest.json')
 assert cm['requiresSourceManifestSha256']==SOURCE_SHA and m['exactThreeSourceCarrierPathSuccessor'] and m['sourceOwnerPortSuppressionOverlayByteIdentical']
 for row in m['files']+m['original144LexicalSourceImportClosure']+m['lexicalLocalSourceImportClosure']+m['externalActualInputBindings']+cm['ownFiles']+cm['externalFiles']+cm['lexicalLocalSourceImportClosure']:c.guard.source_guard.binding(row)
 geo=c.read(m['geometrySourceManifestPath']);assert c.sha(m['geometrySourceManifestPath'])==m['geometrySourceManifestSha256']
 for row in geo['files']+geo['externalFiles']:c.guard.source_guard.binding(row)
 for name in ('node_modules','.pnp.cjs','.pnp.loader.mjs','.yarn'):
  p=PACKET/name;assert not p.exists() and not p.is_symlink()
 return m,cm
def main():
 assert len(sys.argv)==6
 phase=sys.argv[1];assert phase in ('capture','types','core');m,cm=bindings()
 rows=c.read(c.BOARD/'.cloud-tools/ddr-strict18-fresh-core-native-api-sourceonly-next/run-native/ROOT_AUTHORITY.json')['actualPriorCollectedRows']
 for name in ['strict18-native-api-54946-COLLECTED-root.json','strict18-cli-angle-diagnostic-10835-COLLECTED-root.json','strict18-cad-angle-diagnostic-67603-COLLECTED-root.json','strict18-cad-copper-zone-52647-COLLECTED-root.json']:rows.append({'path':str(ROOT/name),'sha256':c.sha(ROOT/name)})
 if phase!='capture':
  assert sys.argv[2]!='-' and c.sha(sys.argv[2])==sys.argv[3]
  cr,cp,ce=c.guard.collected({'path':sys.argv[2],'sha256':sys.argv[3]},positive=True)
  assert cr['sourceManifestSha256']==SOURCE_SHA and cp['phase']=='capture' and cp['sourceCapturePassed']
  captured=c.read(cp['capturePath']);assert c.sha(cp['capturePath'])==cp['captureSha256'] and captured['exactThreeSmoothedPathSuccessorInversePassed'] and captured['fullInverseSourceTreePassed']
  rows.append({'path':sys.argv[2],'sha256':sys.argv[3]})
 if phase=='core':
  assert sys.argv[4]!='-' and c.sha(sys.argv[4])==sys.argv[5]
  tr,tp,te=c.guard.collected({'path':sys.argv[4],'sha256':sys.argv[5]},positive=True)
  assert tr['sourceManifestSha256']==SOURCE_SHA and tr['coreSourceManifestSha256']==CORE_SHA and tp['phase']=='types' and tp['typecheckPassed'] and tp['typecheckCommand'][-1]==str(PACKET/'render-strict18-core.ts')
  rows.append({'path':sys.argv[4],'sha256':sys.argv[5]})
 def closed():
  for row in rows:assert c.guard.process_scope.owned(c.guard.collected(row)[2]['pgid'])==[]
 closed();_,oldsha,before,sbefore,_=c.guard.checked();c.bindings()
 out=PACKET/('run-'+phase);assert not out.exists() and not out.is_symlink();out.mkdir()
 rss={'capture':1073741824,'types':3221225472,'core':2147483648}[phase]
 policy={'wallSeconds':60 if phase=='capture' else 90,'rssBytes':rss,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 auth={'authorizedByRoot':True,'phase':phase,'sourceManifestSha256':SOURCE_SHA,'coreSourceManifestSha256':CORE_SHA,'rootFullSourceCaptureTypeCoreWorkerReadPassed':True,'noConcurrentRootWorker':True,'allPreviousRootWorkersCollected':True,'actualPriorCollectedRows':rows,'policy':policy,'approvalToken':secrets.token_hex(32),'complete18Accepted':False,'accepted49':False,'fabricationReady':False}
 ap=out/'ROOT_AUTHORITY.json'
 with ap.open('x')as f:json.dump(auth,f,indent=2);f.write('\n')
 ap.chmod(0o600);ah=c.sha(ap)
 capture=out/'source-capture.json';diagnostic=out/'source-tree-diagnostic.json';raw=out/'raw-core.json';controls=out/'core-controls.json'
 if phase=='capture':argv=[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',str(PACKET/'capture-strict18-source.ts'),str(capture),str(diagnostic)];env={'G350_STRICT18_SOURCE_ROOT_GUARDED':'1'}
 elif phase=='types':
  old=c.read(c.PACKET/'run-types/POSTAUDIT.json')['typecheckCommand'];assert len(old)==23
  argv=old[:-3]+[str(PACKET/name)for name in ['strict18-source-overlay.tsx','capture-strict18-source.ts','render-strict18-core.ts']];env={}
 else:argv=[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',str(PACKET/'render-strict18-core.ts'),str(raw),str(controls)];env={'G350_STRICT18_CORE_ROOT_GUARDED':'1'}
 def prefork(mem):
  closed();assert mem['current']+rss+1073741824<policy['sharedBytes']
 execution=None;error=None
 with (ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  try:execution=c.guard.process_scope.run_guarded(argv,str(c.BOARD),out/'owned',policy,env,before_spawn=prefork)
  except BaseException as ex:
   error=type(ex).__name__+': '+str(ex)
   if (out/'owned/execution.json').is_file():execution=c.read(out/'owned/execution.json')
  after=None;safter=None;held=False;post_error=None
  try:
   _,nsha,after,safter,_=c.guard.checked();c.bindings();bindings();closed();held=oldsha==nsha and before==after and sbefore==safter and c.sha(ap)==ah
  except BaseException as ex:post_error=type(ex).__name__+': '+str(ex)
  clean=execution is not None and execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values())
  success=False
  if phase=='capture'and capture.is_file():
   r=c.read(capture);success=r['passed'] and r['exactThreeSmoothedPathSuccessorInversePassed'] and r['exactChangedOriginalSourceIds']==['source_trace_15','source_trace_16','source_trace_28'] and r['fullInverseSourceTreePassed'] and r['routingInputLayerForkInversePassed'] and r['genuineNewInnerLayerPorts']==24 and r['newOriginalThreePathDeclarations']==16 and r['duplicateLocalPcbRenderSuppressions']==32 and r['explicitAuthorizedBusAllowedLayerChanges']==4 and c.sha(diagnostic)==r['actualDiagnosticSha256']
  if phase=='types':success=bool(clean)
  if phase=='core'and controls.is_file():
   r=c.read(controls);success=r['freshCoreControlPassed'] and len(r['checks'])==120 and all(x['passed']for x in r['checks']) and c.sha(raw)==r['rawCoreSha256'] and len(r['newDirectOriginalSignals'])==16
  passed=held and error is None and post_error is None and clean and success
  files=[{'path':str(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':c.sha(p)}for p in sorted(out.iterdir())if p.is_file()and not p.is_symlink()]
  post={'scope':'ACTUAL_SMOOTHED_STRICT18_'+phase.upper()+'_SOURCE_SUCCESSOR','phase':phase,'sourceManifestSha256':SOURCE_SHA,'coreSourceManifestSha256':CORE_SHA,'execution':execution,'sourceAndDependenciesHeld':held,'dependenciesBefore':before,'dependenciesAfter':after,'solverDependenciesBefore':sbefore,'solverDependenciesAfter':safter,'runFailure':error,'postverificationFailure':post_error,'outputFiles':files,'passed':bool(passed),'sourceCapturePassed':bool(success)if phase=='capture'else False,'typecheckPassed':bool(success)if phase=='types'else False,'coreControlPassed':bool(success)if phase=='core'else False,'sourceCaptureCalls':int(phase=='capture'),'coreCalls':int(phase=='core'),'nativeCalls':0,'cadCalls':0,'complete18Accepted':False,'accepted49':False,'fabricationReady':False}
  if phase=='capture':post.update(capturePath=str(capture),captureSha256=c.sha(capture)if capture.is_file()else None,diagnosticPath=str(diagnostic),diagnosticSha256=c.sha(diagnostic)if diagnostic.is_file()else None)
  if phase=='types':post['typecheckCommand']=argv
  if phase=='core':post.update(rawCorePath=str(raw),rawCoreSha256=c.sha(raw)if raw.is_file()else None,coreControlsPath=str(controls),coreControlsSha256=c.sha(controls)if controls.is_file()else None)
  with (out/'POSTAUDIT.json').open('x')as f:json.dump(post,f,indent=2);f.write('\n')
  print(json.dumps({k:post[k]for k in ('scope','passed','sourceAndDependenciesHeld','runFailure','postverificationFailure','execution')}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
