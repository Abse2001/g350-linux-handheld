import {Children,cloneElement,isValidElement,type ReactElement,type ReactNode} from "react"
import {buildV12eSource} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-ram7-reference-right-source-proposal-next/v12e-ram7-reference-right-overlay"
type Props=Record<string,unknown>&{name?:string;children?:ReactNode}
const swap={DDR_RESET:{before:"bottom",after:"top"},DDR_BYTE0:{before:"top",after:"bottom"}} as const
export function buildV12eCSource(){
 const base=buildV12eSource(),groups=new Map<string,Record<string,unknown>>(),changes:Array<Record<string,unknown>>=[]
 function apply(node:ReactNode):ReactNode{
  if(!isValidElement<Props>(node))return node
  const p={...node.props};const spec=swap[p.name as keyof typeof swap]
  if(spec){
   if(node.type!=="bus"||groups.has(p.name!))throw Error("Exactly two original literal buses required")
   for(const field of ["pcbAllowedLayers","preferredLayers"] as const){
    if(JSON.stringify(p[field])!==JSON.stringify([spec.before]))throw Error("Original V12e layer list changed: "+p.name+" "+field)
    changes.push({busId:p.name,field,before:p[field],after:[spec.after]});p[field]=[spec.after]
   }
   groups.set(p.name!,p)
  }
  return cloneElement(node as ReactElement<Props>,p,...Children.toArray(node.props.children).map(apply))
 }
 const element=apply(base.element)
 if(groups.size!==2||changes.length!==4)throw Error("Exactly four layer-list props across two original buses required")
 const proof={...base.authoredPolicyProof,groups:base.authoredPolicyProof.groups.map(g=>groups.has(String(g.busId))?{...g,pcbAllowedLayers:groups.get(String(g.busId))!.pcbAllowedLayers,preferredLayers:groups.get(String(g.busId))!.preferredLayers}:g)}
 return {...base,element,authoredPolicyProof:proof,layerMetadataProposal:{changedProps:changes,allPhysicalPlacementsAndOriginalThreeRigidXMotionsHeld:true,newCoreBuildPerformed:false,newNativePlacementCheckPerformed:false}}
}
export default()=>buildV12eCSource().element
