import { expect, test } from "bun:test"
import {
  createPublicPipeline,
  runPublicSteps,
  type PipelineState,
} from "./public-pipeline-protocol"

test("constructor forwards exact input and ONLY the three requested supported options", () => {
  const input = { identity: "kept" }
  let call: unknown[] = []
  class Ctor {
    iterations = 0
    MAX_ITERATIONS = 3
    solved = false
    failed = false
    traces: unknown[] = []
    constructor(...args: [typeof input, Record<string, number | boolean>]) {
      call = args
    }
    step() {}
  }
  const result = createPublicPipeline(Ctor, input)
  expect(result).toBeInstanceOf(Ctor)
  expect(call[0] === input).toBe(true)
  expect(call.length).toBe(2)
  expect(call[1]).toEqual({
    maxBusViaCountSkew: 0,
    maxPairViaCountSkew: 0,
    precheckEnclosedTerminals: true,
  })
})

test("natural success and failure preserve receiver, steps, cap and trace refs", () => {
  for (const kind of ["solved", "failed"] as const) {
    const traces = [{}]
    const solver: PipelineState = {
      iterations: 0,
      MAX_ITERATIONS: 9,
      solved: false,
      failed: false,
      traces,
      step() {
        expect(this === solver).toBe(true)
        expect(arguments.length).toBe(0)
        this.iterations++
        if (this.iterations === 2) this[kind] = true
      },
    }
    const observed: number[] = []
    const result = runPublicSteps(solver, (progress, state) => {
      expect(state === solver).toBe(true)
      expect(state.traces === traces).toBe(true)
      observed.push(progress.iterations)
    })
    expect(observed).toEqual([0, 1, 2])
    expect(result.publicSteps).toBe(2)
    expect(result.defaultCap).toBe(9)
    expect(result.termination).toBe(
      kind === "solved" ? "NATURAL_SOLVED" : "NATURAL_FAILED",
    )
    expect(solver.MAX_ITERATIONS).toBe(9)
  }
})

test("source cap stops without invented terminal flags or acceptance calls", () => {
  let acceptanceCalls = 0
  const solver = {
    iterations: 0,
    MAX_ITERATIONS: 3,
    solved: false,
    failed: false,
    traces: [],
    step() {
      this.iterations++
    },
    tryFinalAcceptance() {
      acceptanceCalls++
    },
  }
  const result = runPublicSteps(solver, () => {})
  expect(result).toEqual({
    publicSteps: 3,
    defaultCap: 3,
    termination: "ORIGINAL_CAP_REACHED_UNRESOLVED",
  })
  expect(solver.solved).toBe(false)
  expect(solver.failed).toBe(false)
  expect(acceptanceCalls).toBe(0)
})

test("original error object propagates even if passive observation throws", () => {
  const original = new Error("original")
  const solver = {
    iterations: 0,
    MAX_ITERATIONS: 3,
    solved: false,
    failed: false,
    traces: [],
    step() {
      this.iterations++
      throw original
    },
  }
  let caught: unknown
  try {
    runPublicSteps(solver, () => {
      throw new Error("observation")
    })
  } catch (error) {
    caught = error
  }
  expect(caught === original).toBe(true)
  expect(solver.iterations).toBe(1)
})
