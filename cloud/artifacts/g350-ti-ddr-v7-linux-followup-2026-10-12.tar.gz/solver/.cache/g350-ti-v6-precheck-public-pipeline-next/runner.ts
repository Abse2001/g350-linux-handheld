/** Root-nonce-only full49 diagnostic. Importing this file never constructs a solver. */
import assert from "node:assert/strict"
import { createHash } from "node:crypto"
import fs from "node:fs"
import path from "node:path"
import {
  createPublicPipeline,
  runPublicSteps,
} from "./public-pipeline-protocol"
import type { ScalarProgress } from "./public-pipeline-protocol"
import type { SimpleRouteJson, Trace } from "./source/lib"
import { sameHardware } from "./input-parity"

const ROOT = import.meta.dir
const sha = (bytes: string | Buffer) =>
  createHash("sha256").update(bytes).digest("hex")
const atomic = (name: string, value: unknown) => {
  const target = path.join(ROOT, "run", name)
  fs.writeFileSync(`${target}.tmp`, `${JSON.stringify(value, null, 2)}\n`)
  fs.renameSync(`${target}.tmp`, target)
}

export async function main() {
  assert.deepEqual(process.argv.slice(2), ["--run-one-approved"])
  assert.equal(process.env.G350_COMBINED_PUBLIC_PIPELINE_APPROVED, "1")
  const receiptPath = process.env.G350_COMBINED_PUBLIC_RECEIPT_PATH
  const receiptSha = process.env.G350_COMBINED_PUBLIC_RECEIPT_SHA256
  assert(receiptPath && receiptSha)
  const receiptRaw = fs.readFileSync(receiptPath)
  assert.equal(sha(receiptRaw), receiptSha)
  const receipt = JSON.parse(receiptRaw.toString())
  const packetRaw = fs.readFileSync(path.join(ROOT, "packet-manifest.json"))
  const packet = JSON.parse(packetRaw.toString())
  const packetSha256 = sha(packetRaw)
  assert.equal(receipt.authorizedByRoot, true)
  assert.equal(
    receipt.scope,
    "one-source914-ti-v6-precheck-public-full49-control",
  )
  assert.equal(receipt.packetSha256, packetSha256)
  assert.deepEqual(receipt.policy, packet.policy)
  assert(/^[0-9a-f]{32,128}$/.test(receipt.approvalToken))
  assert(fs.statSync(path.join(ROOT, "run")).isDirectory())
  assert(!fs.existsSync(path.join(ROOT, "run", "result.json")))
  const inputRaw = fs.readFileSync(path.join(ROOT, "input.json"))
  const originalRaw = fs.readFileSync(
    path.join(ROOT, "original-unrestricted-input.json"),
  )
  assert.equal(
    sha(inputRaw),
    "dc14a2e24414e66179ae7d8ddc72f8216b1faef2c7d9c8f739cf57de05dd93a1",
  )
  assert.equal(
    sha(originalRaw),
    "477a0ec386e1e3be556d8ea3418c615db718c4f2275c9a9fa118c91a3250b2ca",
  )
  const input: SimpleRouteJson = JSON.parse(inputRaw.toString())
  const original: SimpleRouteJson = JSON.parse(originalRaw.toString())
  assert(sameHardware(input, original))
  assert.equal(input.connections.length, 49)
  assert.equal(input.obstacles.length, 856)
  assert.equal(input.traces?.length, 2)
  assert.deepEqual(input.allowedLayers, ["top", "bottom"])
  const inputJsonBefore = JSON.stringify(input)
  const inputNames = new Set(
    input.connections.map((connection) => connection.name),
  )
  const fixedReferencesSha256 = sha(JSON.stringify(input.traces))
  atomic("latest-progress.json", {
    phase: "BEFORE_PUBLIC_CONSTRUCTOR",
    constructorStarted: false,
    packetSha256,
    inputSha256: sha(inputRaw),
    accepted49: false,
  })
  // Dynamic import is deliberately below every approval/input check. No spies.
  const { BusLanesPipelineSolver } = await import("./source/lib")
  atomic("latest-progress.json", {
    phase: "PUBLIC_CONSTRUCTOR_START",
    constructorStarted: true,
    packetSha256,
    inputSha256: sha(inputRaw),
    accepted49: false,
  })
  const started = performance.now()
  const solver = createPublicPipeline(BusLanesPipelineSolver, input)
  const originalDefaultCap = solver.MAX_ITERATIONS
  assert.equal(originalDefaultCap, 8000000)
  const constructorOptions = { ...solver.options }
  assert.equal(solver.options.goal, undefined)
  assert.equal(solver.options.maxSearchIterations, undefined)
  assert.equal(solver.options.maxBusViaCountSkew, 0)
  assert.equal(solver.options.maxPairViaCountSkew, 0)
  assert.equal(solver.options.precheckEnclosedTerminals, true)
  let previousPhase: string | null | undefined
  let previousTraceCount = -1
  let events = 0
  let droppedEvents = 0
  let snapshotBytes = 0
  const snapshots: Array<{
    path: string
    bytes: number
    sha256: string
    traceCount: number
    publicSteps: number
  }> = []
  const observationErrors: string[] = []
  const MAX_EVENTS = 1201
  const MAX_SNAPSHOTS = 24
  const PER_ARTIFACT = 16 * 1024 ** 2
  const TOTAL_ARTIFACTS = 64 * 1024 ** 2
  const observe = (progress: ScalarProgress, actual: typeof solver) => {
    if (
      progress.phase === previousPhase &&
      progress.actualTraceCount === previousTraceCount &&
      progress.publicSteps % 5000 !== 0 &&
      !progress.solved &&
      !progress.failed
    )
      return
    const row = {
      ...progress,
      elapsedSeconds: (performance.now() - started) / 1000,
      packetSha256,
      accepted49: false,
      fabricationReady: false,
    }
    try {
      atomic("latest-progress.json", row)
      if (events < MAX_EVENTS) {
        fs.appendFileSync(
          path.join(ROOT, "run", "progress.jsonl"),
          `${JSON.stringify(row)}\n`,
        )
        events++
      } else droppedEvents++
      if (
        actual.traces.length > 0 &&
        snapshots.length < MAX_SNAPSHOTS &&
        (progress.phase !== previousPhase ||
          progress.actualTraceCount !== previousTraceCount ||
          progress.solved ||
          progress.failed)
      ) {
        // Only the solver's actual public .traces; never accepted/preseeded input.
        const raw = Buffer.from(
          `${JSON.stringify({
            diagnosticOnly: true,
            accepted49: false,
            fabricationReady: false,
            packetSha256,
            sourceCommit: null,
            sourceRevisionLabel: packet.sourceRevision,
            sourceManifestSha256: packet.sourceManifestSha256,
            libraryManifestSha256: packet.libraryManifestSha256,
            libTree: null,
            inputSha256: sha(inputRaw),
            progress,
            traces: actual.traces,
          })}\n`,
        )
        if (
          raw.byteLength <= PER_ARTIFACT &&
          snapshotBytes + raw.byteLength <= TOTAL_ARTIFACTS
        ) {
          const name = `actual-public-traces-${String(snapshots.length).padStart(2, "0")}.json`
          fs.writeFileSync(path.join(ROOT, "run", name), raw)
          snapshots.push({
            path: name,
            bytes: raw.byteLength,
            sha256: sha(raw),
            traceCount: actual.traces.length,
            publicSteps: progress.publicSteps,
          })
          snapshotBytes += raw.byteLength
        }
      }
    } catch (error) {
      if (observationErrors.length < 16)
        observationErrors.push(String(error).slice(0, 512))
    }
    previousPhase = progress.phase
    previousTraceCount = progress.actualTraceCount
  }
  let terminal: ReturnType<typeof runPublicSteps> | undefined
  let originalException: string | null = null
  try {
    terminal = runPublicSteps(solver, observe)
  } catch (error) {
    originalException = String(error).slice(0, 2048)
  }
  const fixedReferencesHeld =
    sha(JSON.stringify(solver.input.traces)) === fixedReferencesSha256
  const ownTraceNames = solver.traces.map(
    (trace: Trace) => trace.connection_name ?? trace.source_trace_id,
  )
  const ownTraceNamesInOriginal49 = ownTraceNames.every(
    (name) => typeof name === "string" && inputNames.has(name),
  )
  const solvedOutputNamesComplete49 =
    !solver.solved ||
    (solver.traces.length === 49 &&
      new Set(ownTraceNames).size === 49 &&
      ownTraceNamesInOriginal49)
  const inputUnchanged =
    JSON.stringify(input) === inputJsonBefore &&
    sha(fs.readFileSync(path.join(ROOT, "input.json"))) === sha(inputRaw)
  let publicOutput: { path: string; bytes: number; sha256: string } | null =
    null
  if (solver.solved) {
    const raw = Buffer.from(`${JSON.stringify(solver.getOutput())}\n`)
    if (
      raw.byteLength <= PER_ARTIFACT &&
      snapshotBytes + raw.byteLength <= TOTAL_ARTIFACTS
    ) {
      fs.writeFileSync(
        path.join(ROOT, "run", "natural-public-output.json"),
        raw,
      )
      publicOutput = {
        path: "natural-public-output.json",
        bytes: raw.byteLength,
        sha256: sha(raw),
      }
      snapshotBytes += raw.byteLength
    }
  }
  const diagnosticQualified =
    terminal !== undefined &&
    originalException === null &&
    inputUnchanged &&
    fixedReferencesHeld &&
    ownTraceNamesInOriginal49 &&
    solver.MAX_ITERATIONS === originalDefaultCap &&
    solvedOutputNamesComplete49
  const result = {
    diagnosticOnly: true,
    diagnosticQualified,
    packetSha256,
    sourceCommit: null,
    sourceRevisionLabel: packet.sourceRevision,
    sourceManifestSha256: packet.sourceManifestSha256,
    libraryManifestSha256: packet.libraryManifestSha256,
    libTree: null,
    sourceClosureSha256: packet.sourceClosureSha256,
    sourceFileCount: 914,
    inputSha256: sha(inputRaw),
    originalInputSha256: sha(originalRaw),
    publicPipelineExecuted: true,
    constructorOptions,
    requestedOptions: {
      maxBusViaCountSkew: 0,
      maxPairViaCountSkew: 0,
      precheckEnclosedTerminals: true,
    },
    originalDefaultCap,
    capUnchanged: solver.MAX_ITERATIONS === originalDefaultCap,
    terminal: terminal ?? null,
    originalException,
    inputUnchanged,
    fullHardwareHeld: sameHardware(input, original),
    fixedReferencesHeld,
    suppliedPhysicalReferences: 2,
    ownTraceNamesInOriginal49,
    solvedOutputNamesComplete49,
    actualSolverState: {
      iterations: solver.iterations,
      solved: solver.solved,
      failed: solver.failed,
      phase: solver.phase,
      error: solver.error,
      actualTraceCount: solver.traces.length,
      ownTraceNames,
    },
    observations: {
      events,
      droppedEvents,
      observationErrors,
      snapshots,
      snapshotBytes,
      progressLimit: MAX_EVENTS,
      publicOutput,
    },
    totalChildSeconds: (performance.now() - started) / 1000,
    accepted49: false,
    tiEligibleBoard: false,
    fabricationReady: false,
    finalStrictValidation:
      "PENDING: native DRC, all49 ownership/connectivity, coupling, min/max lengths, bus/pair skew, via counts and fixed references",
    scope:
      "Fresh full49 public pipeline control only; success flag is not independently accepted49",
  }
  atomic("result.json", result)
  console.log(
    JSON.stringify({
      diagnosticQualified,
      termination: terminal?.termination ?? "ORIGINAL_EXCEPTION",
      accepted49: false,
    }),
  )
  return diagnosticQualified ? 0 : 2
}

if (import.meta.main) process.exitCode = await main()
