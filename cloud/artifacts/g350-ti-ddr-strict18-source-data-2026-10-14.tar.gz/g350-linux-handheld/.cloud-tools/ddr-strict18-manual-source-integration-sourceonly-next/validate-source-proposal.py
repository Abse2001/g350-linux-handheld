"""Independent stdlib geometry/owner/inverse controls; no Source/SDK imports."""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
def require(value, reason):
    if not value:
        raise ValueError(reason)
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def close(a, b):
    return all(abs(a[key] - b[key]) <= 1e-8 for key in ['x', 'y'])

def verify(proposal, fork):
    bindings = proposal['inputBindings']
    for binding in bindings.values():
        path = Path(binding['path'])
        require(path.is_file() and not path.is_symlink() and digest(path) == binding['sha256'], 'Actual immutable Source/geometry binding changed')
    raw = json.loads(Path(bindings['rawCore']['path']).read_text())
    source_traces = {row['source_trace_id']: row for row in raw if row['type'] == 'source_trace'}
    source_ports = {row['source_port_id']: row for row in raw if row['type'] == 'source_port'}
    components = {row['source_component_id']: row for row in raw if row['type'] == 'source_component'}
    static = json.loads(Path(bindings['static18']['path']).read_text())['records']
    static_by_id = {row['sourceTraceId']: row for row in static}
    require(len(static_by_id) == 18, 'Exactly18 independent static carriers')
    new = proposal['newOriginalSignalChanges']
    require(len(new) == 16 and len({row['originalSourceTraceId'] for row in new}) == 16 and
            {row['originalSourceTraceId'] for row in new} == set(static_by_id) - {'source_trace_33', 'source_trace_34'}, 'Exactly16 new original owners, clocks excluded')
    require({row['originalSourceTraceId'] for row in proposal['existingQualifiedClocksHeld']} == {'source_trace_33', 'source_trace_34'} and
            all(row['existingClockPcbPropsMustRemainExact'] for row in proposal['existingQualifiedClocksHeld']), 'Both original qualified clocks held')
    native = json.loads(Path(bindings['actualNative']['path']).read_text())['actualOwnershipProof']
    native_by_port = {row['originalNumericSourcePortId']: row for row in native['signalMappings']}
    require(len(native_by_port) == 96, 'Actual96 authenticated signal endpoint owners')
    expected_ports = []
    physical_paths = []
    for row in new:
        original = source_traces[row['originalSourceTraceId']]
        cpu, ram = row['cpu'], row['ram']
        require(original['name'] == row['originalLogicalTraceName'] and original['connected_source_port_ids'] == [cpu['originalSourcePortId'], ram['originalSourcePortId']], 'Original actual numeric Source declaration owner/order')
        for owner in [cpu, ram]:
            source_port = source_ports[owner['originalSourcePortId']]
            mapping = native_by_port[owner['originalSourcePortId']]
            require(mapping['sourceViaName'] == owner['viaName'] and mapping['originalSourceTraceId'] == row['originalSourceTraceId'] and source_port['pin_number'] == owner['numericPin'] and components[source_port['source_component_id']]['name'] == owner['package'], 'Genuine measured SourceVia/numeric-pin owner')
        require(row['originalNumericFrom'] == f"{cpu['package']}.pin{cpu['numericPin']}" and row['originalNumericTo'] == f"{ram['package']}.pin{ram['numericPin']}", 'Actual numeric selectors')
        layer = static_by_id[row['originalSourceTraceId']]['layer']
        require(row['carrierLayer'] == layer and row['physicalViaPrimitives'] == 0, 'Actual independently selected layer, no fictitious extra transition')
        cpu_top, ram_top = f".{cpu['viaName']} > port.top", f".{ram['viaName']} > port.top"
        cpu_layer, ram_layer = f".{cpu['viaName']} > port.{layer}", f".{ram['viaName']} > port.{layer}"
        paths = row['newPcbPaths']
        require(len(paths) == 3 and paths[0] == [row['originalNumericFrom'], cpu_top] and paths[2] == [ram_top, row['originalNumericTo']] and row['newPcbPathRelativeTo'] == cpu_layer and paths[1][0] == cpu_layer and paths[1][-1] == ram_layer, 'Exactlythree physically owned pad/Top/barrel/carrier paths')
        reproduced = [cpu['viaXY']] + [{key: point[key] + cpu['viaXY'][key] for key in ['x', 'y']} for point in paths[1][1:-1]] + [ram['viaXY']]
        selected = static_by_id[row['originalSourceTraceId']]['path']
        require(len(reproduced) == len(selected) and all(close(a, b) for a, b in zip(reproduced, selected)), 'Source relative carrier reconstructs every actual static point')
        require(all(point['route_type'] == 'wire' and point['layer'] == layer and point['width'] == .1016 for point in row['expectedCarrierPhysicalRoute']) and len(row['expectedCarrierPhysicalRoute']) == len(reproduced) and all(close(a, b) for a, b in zip(row['expectedCarrierPhysicalRoute'], reproduced)), 'Exact constant-width complete expected carrier geometry')
        require(row['newLocalRenderSuppressions'] == [cpu['traceName'], ram['traceName']], 'Onlytwo corresponding duplicate local renderings suppressed')
        if layer in ['inner1', 'inner2']:
            expected_ports.extend([{'viaName': owner['viaName'], 'layer': layer, 'viaXY': owner['viaXY'], 'numericSelector': f"{owner['package']}.pin{owner['numericPin']}"} for owner in [cpu, ram]])
        physical_paths.append({'sourceTraceId': row['originalSourceTraceId'], 'layer': layer, 'carrierPoints': len(reproduced), 'actualCpuNumericPin': cpu['numericPin'], 'actualRamNumericPin': ram['numericPin']})
    require(len(expected_ports) == 24 and proposal['addedRealInnerLayerPorts'] == expected_ports, 'Exactly24 genuine new real inner ports; Top/Bottom use existing aliases')
    original = json.loads(Path(bindings['combined49']['path']).read_text())
    restored = copy.deepcopy(fork)
    require(len(fork['connections']) == 49 and len(fork['differentialPairs']) == 3, 'Complete49 and3 original pair constraints')
    changes = proposal['authorizedAllFourLayerFork']['routingInputAllowedLayerChanges']
    require(len(changes) == 4 and proposal['authorizedAllFourLayerFork']['sourceBusAllowedLayerChanges'] == [{**change, 'field': 'pcbAllowedLayers'} for change in changes], 'Exactlyfour declared Source/input allowed-layer changes with their real field names')
    for old, actual, change in zip(original['buses'], restored['buses'], changes):
        require(change == {'busId': old['busId'], 'field': 'allowedLayers', 'originalAllowedLayers': old['allowedLayers'], 'newAllowedLayers': ['top', 'inner1', 'inner2', 'bottom'], 'preferredLayersHeld': old['preferredLayers']} and actual['allowedLayers'] == change['newAllowedLayers'], 'Only declared all4 routing layer list widening')
        actual['allowedLayers'] = change['originalAllowedLayers']
    require(restored == original, 'Full inverse retains all original numeric endpoints, Source input geometry, rosters, width, max/min, skew and gap')
    return physical_paths

def main():
    path = ROOT / 'strict18-source-proposal.json'
    proposal = json.loads(path.read_text())
    input_path = ROOT / 'authorized-all4-routing-input.json'
    fork = json.loads(input_path.read_text())
    require(digest(input_path) == proposal['authorizedAllFourLayerFork']['routingInputSha256'], 'Exact authored authorized input')
    paths = verify(proposal, fork)
    tests = []
    def rejected(name, change):
        damaged, damaged_input = copy.deepcopy(proposal), copy.deepcopy(fork)
        change(damaged, damaged_input)
        try:
            verify(damaged, damaged_input)
        except (ValueError, KeyError, IndexError):
            tests.append({'name': name, 'rejected': True})
        else:
            raise AssertionError('Bad geometry/owner/input accepted: ' + name)
    rejected('wrong-real-numeric-owner', lambda p, i: p['newOriginalSignalChanges'][0]['cpu'].update(numericPin=999))
    rejected('wrong-existing-barrel-owner', lambda p, i: p['newOriginalSignalChanges'][0]['cpu'].update(viaName=p['newOriginalSignalChanges'][1]['cpu']['viaName']))
    rejected('missing-real-layer-port', lambda p, i: p['addedRealInnerLayerPorts'].pop())
    rejected('extra-real-layer-port', lambda p, i: p['addedRealInnerLayerPorts'].append(copy.deepcopy(p['addedRealInnerLayerPorts'][0])))
    rejected('wrong-carrier-layer', lambda p, i: p['newOriginalSignalChanges'][0].update(carrierLayer='bottom'))
    rejected('carrier-copper-shift', lambda p, i: p['newOriginalSignalChanges'][0]['newPcbPaths'][1][1].update(x=999))
    rejected('qualified-clock-replaced', lambda p, i: p['newOriginalSignalChanges'][0].update(originalSourceTraceId='source_trace_33'))
    rejected('missing-new-original-owner', lambda p, i: p['newOriginalSignalChanges'].pop())
    rejected('bus-maximum-length-weakened', lambda p, i: i['buses'][1].update(maxLength=100))
    rejected('bus-skew-weakened', lambda p, i: i['buses'][1].update(maxLengthSkew=1))
    rejected('pair-gap-weakened', lambda p, i: i['differentialPairs'][0].update(traceGap=.01))
    rejected('pair-skew-weakened', lambda p, i: i['differentialPairs'][0].update(lengthTolerance=1))
    rejected('preferred-layers-silently-changed', lambda p, i: i['buses'][1].update(preferredLayers=['top']))
    rejected('logical-endpoint-removed', lambda p, i: i['connections'][0]['pointsToConnect'].pop())
    verify(proposal, fork)
    report = {'scope': 'ACTUAL_STDLIB_STATIC18_MANUAL_SOURCE_OWNER_AND_GEOMETRY_CONTROLS', 'passed': True,
        'proposalSha256': digest(path), 'authorizedRoutingInputSha256': digest(input_path), 'source16GeometryOwnerControls': paths,
        'negativeControls': tests, 'actualSourceImportsOrSdkOrCoreOrNativeOrCadCalls': 0, 'all24RealInnerPortDescriptorsChecked': True,
        'originalAll49LogicTimingSkewGapAndPreferredLayersHeldUnderInverse': True, 'explicitAllowedLayerForkInverseChecked': True,
        'sourceCaptureExecuted': False, 'referenceQualified': False, 'complete18Accepted': False, 'accepted49': False, 'fabricationReady': False}
    output = ROOT / 'STDLIB_CONTROLS.json'
    with output.open('x') as handle:
        json.dump(report, handle, indent=2); handle.write('\n')
    output.chmod(0o600)
    print(json.dumps({'passed': True, 'negativeControls': len(tests), 'reportSha256': digest(output), 'applicationCalls': 0}))

if __name__ == '__main__':
    main()
