"""Persist selected already-closed regular-file evidence; no project imports."""
from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,stat,tarfile
BOARD=Path('/workspace/g350-linux-handheld');SOLVER=Path('/workspace/bus-lanes-solver');ROOT=Path(__file__).resolve().parent
NAME='g350-ti-ddr-all-four-layer-closed-evidence-2026-10-13'
OUT=BOARD/'cloud/artifacts';ARCHIVE=OUT/(NAME+'.tar.gz');MANIFEST=OUT/(NAME+'.manifest.json')
VALIDATION=BOARD/'cloud/TI_DDR_ALL_FOUR_LAYER_ARCHIVE_DATA_VALIDATION_2026-10-13.json'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while block:=f.read(1024*1024):h.update(block)
 return h.hexdigest()
def load(p):return json.loads(p.read_bytes())
def snapshot(p):
 s=p.stat();return {'sha256':sha(p),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'inode':s.st_ino,'mtimeNs':s.st_mtime_ns}
def safe(name):
 p=PurePosixPath(name);return bool(name) and not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and '.git' not in p.parts and 'node_modules' not in p.parts and '__pycache__' not in p.parts
protected={name:snapshot(BOARD/name) for name in ['AGENTS.md','cloud/CONTINUE_BOARD.md','scripts/prepare-g350-ram90-four-layer.mjs','scripts/tune-g350-ram90-native-lengths.mjs']}
expected=['d3086d9ff8887bd296ed0d480fcbef732686bf45e075ae766a0a292518086723','bb9a879c5c68c3718d24c82a77326f5b175d47899f101407b1e1ee106c8b19ef','ec6b56c59d2c8f72f969934076dd3597014833e8b2e8e4387c1045f03eaadda0','5bfe731744159cf9f65ddde71b513cb1a0d2384574e740cd11bc087ce69b4b40']
assert [v['sha256'] for v in protected.values()]==expected
assert not ARCHIVE.exists() and not MANIFEST.exists() and not VALIDATION.exists()
selected={}
def add(p,role):
 if p.is_symlink() or not p.is_file():return
 name=str(p.relative_to(Path('/workspace')));assert safe(name)
 if p not in selected:selected[p]={'roles':[]}
 if role not in selected[p]['roles']:selected[p]['roles'].append(role)
def tree(p,role):
 for q in sorted(p.rglob('*')):
  if not any(x in q.relative_to(p).parts for x in ['.git','node_modules','__pycache__']):add(q,role)
def roots(p,role):
 for q in sorted(p.iterdir()):
  if q.is_file():add(q,role)
scopes=['g350-ti-v12e-c-handoff-length-prune-runtime128-public-next','g350-ti-v12e-c-joint-local-geometry-capture-next','g350-ti-v12e-c-actual-via-grid-phase-control-next','g350-coupled-handoff-length-prune-canonical-qualifier-next','g350-coupled-handoff-length-prune-canonical-fullsuite-next','g350-coupled-handoff-length-prune-canonical-fullsuite-smol-successor-next','g350-coupled-handoff-length-prune-canonical-fullsuite-smol-2g-successor-next']
for name in scopes:
 p=SOLVER/'.cache'/name;post=load(p/'EXECUTION-postaudit.json');e=post['execution'];assert e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()) and (post.get('sourceAndArtifactsHeld') is True or post.get('sourceAndArtifactHeld') is True)
 roots(p,'newly-closed-controller-source-and-receipts');tree(p/'run','newly-closed-raw-child-evidence')
runtime=SOLVER/'.cache'/scopes[0]
tree(runtime/'source/lib','runtime128-source-library');tree(runtime/'fanout-source','private-patched-fanout-source');tree(runtime/'error-capture-qualification','completed-deterministic-build-and-origin-controls')
for name in ['index.ts','package.json','bunfig.toml','tsconfig.json']:add(runtime/'source'/name,'runtime128-source-entry-config')
tree(SOLVER/'.cache/g350-coupled-handoff-length-prune-canonical-sourceonly-next','minimal-canonical-patch-and-qualified-witness-source')
for name in ['ti-ddr-v12e-c-fresh-ti-window-source-next','ti-ddr-v12e-c-fresh-ti-window-qualified-input-bridge-next']:tree(BOARD/'.cloud-tools'/name,'actual-fresh-ti-metadata-source-capture-and-bridge')
collections=['runtime128-c-length-build-COLLECTED-root.json','runtime128-c-length-public-COLLECTED-root.json','c-joint-local-geometry-RECOVERED-root.json','canonical-handoff-length-focused-COLLECTED-root.json','canonical-handoff-length-fullsuite-COLLECTED-root.json','canonical-fullsuite-smol-COLLECTED-root.json','canonical-fullsuite-smol-2g-COLLECTED-root.json','c-fresh-ti-window-capture-COLLECTED-root.json','actual-c-via-phase-COLLECTED-root.json']
for name in collections:
 p=SOLVER/'.cache/root-routing-progress'/name;d=load(p);assert (d.get('toolExitCode') in [0,2]) or (d.get('toolExitCode') is None and d.get('terminalRecoveredFromCompleteGuardPostaudit') is True);add(p,'exact-outside-root-closed-collection')
for name in ['runtime128-c-length-public-root.json','canonical-handoff-length-focused-root.json','canonical-handoff-length-fullsuite-root.json','canonical-fullsuite-smol-root.json','canonical-fullsuite-smol-2g-root.json','c-fresh-ti-window-capture-root.json','c-joint-local-geometry-root.json']:add(SOLVER/'.cache/root-routing-progress'/name,'original-closed-scope-root-authority')
add(ROOT/'archive-selection-plan.json','source-only-proportional-selection-plan');add(Path(__file__),'data-only-archive-builder-no-solver-imports')
rows=[];before={}
for p,value in sorted(selected.items(),key=lambda v:str(v[0])):
 s=snapshot(p);before[p]=s;rows.append({'path':str(p.relative_to(Path('/workspace'))),'sourcePath':str(p),'bytes':s['bytes'],'sha256':s['sha256'],'mode':s['mode'],'roles':value['roles']})
logical=sum(r['bytes'] for r in rows);assert logical<=100*1024*1024
parent=BOARD/'cloud/artifacts/g350-ti-ddr-v12e-source-carriers-2026-10-13.manifest.json';pm=load(parent);assert sha(BOARD/pm['archive']['path'])==pm['archive']['sha256']
index={'schemaVersion':1,'scope':'DATA_ONLY_SELECTED_NEWLY_CLOSED_REGULAR_EVIDENCE_NO_STANDALONE_OPERATIONAL_CLOSURE','files':rows,'logicalPayloadBytes':logical,'parentArchive':pm['archive'],'parentManifestSha256':sha(parent),'allNamedAncestorBindingsIncluded':False,'externalReplayRequirements':'Existing indexed parent hardware/ancestor evidence, installed exact runtime dependencies/native patch and KiCad reconstruction remain required. Selection manifests can name inherited or retained ignored paths outside this payload. No standalone controller/replay/Start restoration pass is claimed.','activeOrMutableProgressIncluded':False,'regularFilesOnly':True,'restorationTested':False,'accepted49':False,'referenceQualified':False,'fabricationReady':False}
index_bytes=(json.dumps(index,indent=2)+'\n').encode();temporary=ROOT/(NAME+'.tar.gz.tmp');assert not temporary.exists()
with temporary.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=9,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|',format=tarfile.PAX_FORMAT) as tar:
 for row in rows:
  info=tarfile.TarInfo(row['path']);info.size=row['bytes'];info.mode=row['mode'];info.mtime=0
  with Path(row['sourcePath']).open('rb') as f:tar.addfile(info,f)
 info=tarfile.TarInfo('CLOSED-EVIDENCE-INDEX.json');info.size=len(index_bytes);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(index_bytes))
assert temporary.stat().st_size<=10*1024*1024
expected_rows={r['path']:r for r in rows};seen=set()
with tarfile.open(temporary,'r:gz') as tar:
 for member in tar:
  assert member.isfile() and safe(member.name) and member.name not in seen;seen.add(member.name);f=tar.extractfile(member)
  if member.name=='CLOSED-EVIDENCE-INDEX.json':assert f.read()==index_bytes and member.mode==0o600;continue
  row=expected_rows[member.name];h=hashlib.sha256()
  while block:=f.read(1024*1024):h.update(block)
  assert h.hexdigest()==row['sha256'] and member.size==row['bytes'] and member.mode==row['mode']
assert seen==set(expected_rows)|{'CLOSED-EVIDENCE-INDEX.json'}
assert all(snapshot(p)==s for p,s in before.items());after={name:snapshot(BOARD/name) for name in protected};assert after==protected
temporary.rename(ARCHIVE)
manifest={**index,'archive':{'path':str(ARCHIVE.relative_to(BOARD)),'bytes':ARCHIVE.stat().st_size,'sha256':sha(ARCHIVE)},'internalIndex':{'path':'CLOSED-EVIDENCE-INDEX.json','bytes':len(index_bytes),'sha256':hashlib.sha256(index_bytes).hexdigest()},'payloadFileCount':len(rows),'totalRegularMemberCount':len(seen),'allMemberBytesSizesModesVerified':True,'allSelectedOriginalSourcesHeldBeforeAfter':True,'protectedFourHeld':True,'newArchiveFullRestoreOrStartQualificationClaimed':False}
with MANIFEST.open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
validation={'scope':'DATA_ONLY_NEWLY_CLOSED_ARCHIVE_BUILD_AND_COMPLETE_REGULAR_MEMBER_HASH_MODE_VERIFICATION','archiveSha256':manifest['archive']['sha256'],'archiveBytes':manifest['archive']['bytes'],'manifestSha256':sha(MANIFEST),'payloadFileCount':len(rows),'regularMemberCount':len(seen),'logicalPayloadBytes':logical,'allIndexedOriginalSourcesHeldBeforeAfter':True,'allSafeUniqueRegularMemberBytesSizesModesVerified':True,'protected4Before':protected,'protected4After':after,'noSolverImportsOrTestsOrRoutingInvoked':True,'noStandaloneOperationalClosureClaimed':True,'restorationTested':False,'startTested':False,'accepted49':False,'referenceQualified':False,'fabricationReady':False}
with VALIDATION.open('x') as f:json.dump(validation,f,indent=2);f.write('\n')
print(json.dumps({k:validation[k] for k in ['archiveSha256','archiveBytes','manifestSha256','payloadFileCount','regularMemberCount','logicalPayloadBytes','allSafeUniqueRegularMemberBytesSizesModesVerified','restorationTested']}))
