import {Children, cloneElement, isValidElement, type ReactElement, type ReactNode} from "react"
import {writeFileSync} from "node:fs"
import {buildV12dSource} from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12d-byte0-top-reset-bottom-next/v12d-final-layer-overlay"
import {buildV12eSource} from "./v12e-ram7-reference-right-overlay"
if(import.meta.main){
 const [output,...extra]=process.argv.slice(2)
 if(!output||extra.length)throw Error("Usage: bun --smol capture-v12e-authored-props.ts FRESH_OUTPUT_JSON")
 const rawBefore=buildV12dSource(),after=buildV12eSource()
 // Match the exact one extra cloneElement/Children.toArray traversal performed
 // by V12e, preserving generated React keys as well as explicit keys.
 function identityClone(node:ReactNode):ReactNode{
  if(!isValidElement<Record<string,unknown>>(node))return node
  return cloneElement(node as ReactElement<Record<string,unknown>>,{...node.props},...Children.toArray(node.props.children as ReactNode).map(identityClone))
 }
 const before={...rawBefore,element:identityClone(rawBefore.element)}
 let comparedElements=0;const changes:Array<Record<string,unknown>>=[]
 function compare(a:ReactNode,b:ReactNode,path:string){
  if(!isValidElement<Record<string,unknown>>(a)||!isValidElement<Record<string,unknown>>(b)){
   if(JSON.stringify(a)!==JSON.stringify(b))throw Error("Non-element source value changed: "+path)
   return
  }
  comparedElements++
  if(a.type!==b.type||a.key!==b.key)throw Error("Source type or key changed: "+path)
  const pa={...a.props},pb={...b.props};delete pa.children;delete pb.children
  const name=pa.name
  const expected=({C_DDR_RAM_7:[6.8,8.2,8.75],V_TI_RAM7_POWER:[7.85,9.25,8.75],V_TI_RAM7_GROUND:[7.65,9.05,8.15]} as Record<string,number[]>)[String(name)]
  if(expected){
   if(typeof pa.pcbX!=="number"||Math.abs(pa.pcbX-expected[0]!)>1e-9||typeof pb.pcbX!=="number"||Math.abs(pb.pcbX-expected[1]!)>1e-9||Math.abs(Number(pb.pcbY)-expected[2]!)>1e-9)throw Error("Rigid proposal changed: "+name)
   changes.push({name,oldX:pa.pcbX,pcbX:pb.pcbX,pcbY:pb.pcbY})
   pb.pcbX=pa.pcbX
  }
  if(JSON.stringify(pa)!==JSON.stringify(pb))throw Error("Unexpected source props changed: "+path)
  const ca=Children.toArray(a.props.children as ReactNode),cb=Children.toArray(b.props.children as ReactNode)
  if(ca.length!==cb.length)throw Error("Source children count changed: "+path)
  ca.forEach((child,i)=>compare(child,cb[i],path+"/"+i))
 }
 compare(before.element,after.element,"board")
 if(changes.length!==3||new Set(changes.map(c=>c.name)).size!==3)throw Error("Exactly three original X overrides required")
 for(const key of ["authoredPolicyProof","referenceCopperCandidates","referenceQualified","TIplaneArrangement","globalSignalLayerProjection","naturallyDerivedGenericDefaultCap"] as const)
  if(JSON.stringify(before[key])!==JSON.stringify(after[key]))throw Error("Original policy/reference prop changed: "+key)
 writeFileSync(output,JSON.stringify({scope:"PURE_ACTUAL_V12E_FINAL_REACT_THREE_RIGID_X_PROPS_ONLY",actualFinalReactTreeEvaluated:true,
 comparedElements,allOtherTreePropsTypesKeysChildrenExactlyHeld:true,changedProps:after.placementProposal.changedProps,
 placementProposal:after.placementProposal,authoredPolicyProof:after.authoredPolicyProof,referenceCopperCandidates:after.referenceCopperCandidates,
 globalSignalLayerProjection:after.globalSignalLayerProjection,naturallyDerivedGenericDefaultCap:after.naturallyDerivedGenericDefaultCap,
 referenceQualified:false,TIplaneArrangement:false,coreRenderCalled:false,nativePlacementChecksInvoked:false,routingSolverInstantiated:false,
 accepted49:false,fabricationReady:false},null,2)+"\n",{flag:"wx",mode:0o600})
}
