"""Build an exclusive diagnostic archive, then verify every indexed member."""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import io
import json
import stat
import tarfile


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as src:
        for block in iter(lambda: src.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('inventory', type=Path)
parser.add_argument('archive', type=Path)
parser.add_argument('manifest', type=Path)
args = parser.parse_args()
project = Path('/workspace/g350-linux-handheld')
assert not args.archive.is_symlink() and not args.manifest.is_symlink()
args.inventory = args.inventory.resolve()
args.archive = args.archive.resolve()
args.manifest = args.manifest.resolve()
assert args.archive.is_relative_to(project) and args.manifest.is_relative_to(project)
assert not args.archive.exists() and not args.archive.is_symlink()
assert not args.manifest.exists() and not args.manifest.is_symlink()
inventory = json.loads(args.inventory.read_text())
records = inventory['members']
checked = []
seen = set()
for item in records:
    name = item['member']
    relative = PurePosixPath(name)
    assert not relative.is_absolute() and str(relative) == name
    assert all(part not in ('.', '..') for part in relative.parts)
    assert name not in seen and name != 'manifest.json'
    seen.add(name)
    source = Path(item['sourcePath'])
    assert source.is_absolute() and source.resolve().is_relative_to('/workspace')
    assert stat.S_ISREG(source.lstat().st_mode) and not source.is_symlink()
    assert source.stat().st_size == item['bytes'] and digest(source) == item['sha256']
    checked.append({**item, 'path': name, 'mode': stat.S_IMODE(source.stat().st_mode)})

internal = {
    'schemaVersion': 1,
    'diagnosticOnly': True,
    'scope': inventory['scope'],
    'files': checked,
    'externalReplayRequirements': inventory['externalReplayRequirements'],
    'accepted49': False,
    'fabricationReady': False,
}
raw_index = (json.dumps(internal, indent=2) + '\n').encode()
with args.archive.open('xb') as archive_file:
    with gzip.GzipFile(filename='', mode='wb', fileobj=archive_file, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for item in checked:
                source = Path(item['sourcePath'])
                info = tarfile.TarInfo(item['path'])
                info.size = item['bytes']
                info.mode = item['mode']
                info.mtime = 0
                with source.open('rb') as src:
                    tar.addfile(info, src)
                assert digest(source) == item['sha256'], 'Archive input changed during copy'
            info = tarfile.TarInfo('manifest.json')
            info.size = len(raw_index)
            info.mode = 0o600
            info.mtime = 0
            tar.addfile(info, io.BytesIO(raw_index))

index_row = {'path': 'manifest.json', 'bytes': len(raw_index),
             'sha256': hashlib.sha256(raw_index).hexdigest(), 'mode': 0o600}
expected = {item['path']: item for item in checked + [index_row]}
actual = set()
with tarfile.open(args.archive, 'r:gz') as tar:
    for member in tar:
        assert member.isfile() and member.name in expected and member.name not in actual
        row = expected[member.name]
        assert member.size == row['bytes'] and member.mode == row['mode']
        stream = tar.extractfile(member)
        h = hashlib.sha256()
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
        assert h.hexdigest() == row['sha256'], 'Archived member hash mismatch'
        actual.add(member.name)
assert actual == set(expected)
manifest = {
    'archive': {'path': str(args.archive.relative_to(project)),
                'bytes': args.archive.stat().st_size, 'sha256': digest(args.archive)},
    'files': checked + [index_row],
    'indexedFiles': len(checked),
    'diagnosticOnly': True,
    'scope': inventory['scope'],
    'externalReplayRequirements': inventory['externalReplayRequirements'],
    'accepted49': False,
    'fabricationReady': False,
}
with args.manifest.open('x') as output:
    output.write(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'archive': manifest['archive'], 'verifiedMembers': len(actual),
                  'accepted49': False, 'fabricationReady': False}))
