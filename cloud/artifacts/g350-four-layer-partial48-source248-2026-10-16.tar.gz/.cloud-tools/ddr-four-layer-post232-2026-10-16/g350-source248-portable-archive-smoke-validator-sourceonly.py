#!/usr/bin/env python3
"""SOURCE ONLY: Root-run isolated smoke test of the new Source248 evidence archive.

No SDK, native, CAD, routing, workspace restoration, or artifact publication.
The only writes are to a fresh owned /tmp directory. A successful run removes
its extracted payload and preserves REPORT.json; failures preserve diagnostics.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import time

BOARD = Path('/workspace/g350-linux-handheld')
SAVED_REL = '.cloud-tools/ddr-four-layer-post232-2026-10-16'
STEM = 'g350-four-layer-partial48-source248-2026-10-16'
RESTORER = BOARD / 'scripts/restore-g350-routing-evidence.py'
RESTORER_SHA = '148bad0fc4132ece5f78f18b05e4bc71d79019312343eda954ed7ca91874a643'
WORKSPACE_HELPER = BOARD / 'scripts/restore-g350-four-layer-routing-workspace.py'
WORKSPACE_HELPER_SHA = '6c5d321a256eadf58697f0f565b5bffa4a55491fce39ed0db7e7675604b6f3cc'
MODEL_SHA = 'cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
FALLBACK_SHA = '71bbec7babdeabda657ba1b2be75d35f5d7210d5a53d55cd2fc2b279ffb0d17b'
RAW_SHA = 'c5129a2ec734e873c209ab8cdccf2cad1753d177f1c87857ffae0cf7ff12a486'
CONTROLS_SHA = '5fb5a432d5854a8cccf689070d901ed4823a427cb42ec6487d474c50d081d525'
DENIED = ('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT', 'AUTHORITY_PACKET')
CHUNK = 1024 * 1024


def require(value, message):
    if not value:
        raise ValueError(message)


def sha_file(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(CHUNK), b''):
            digest.update(chunk)
    return digest.hexdigest()


def regular(path):
    return path.is_file() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)


def hex_sha(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def safe_relative(value):
    require(isinstance(value, str), 'String member path required')
    path = PurePosixPath(value)
    require(not path.is_absolute() and path.parts and all(p not in ('', '.', '..') for p in path.parts)
            and str(path) == value and '\\' not in value and '\x00' not in value, 'Canonical relative path required')
    require(not any(word in value.upper() for word in DENIED), 'Private authority/context payload is forbidden')
    return path


def verify_file(path, row):
    require(regular(path), 'Regular non-symlink file required: ' + str(path))
    require(type(row['bytes']) is int and path.stat().st_size == row['bytes']
            and hex_sha(row['sha256']) and sha_file(path) == row['sha256'], 'Exact file bytes/hash required: ' + str(path))
    require(type(row['mode']) is int and 0 <= row['mode'] <= 0o777
            and stat.S_IMODE(path.stat().st_mode) == row['mode'], 'Exact recorded file mode required: ' + str(path))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('archive', 'manifest'):
        parser.add_argument('--' + name, type=Path, required=True)
        parser.add_argument('--' + name + '-sha', required=True)
    parser.add_argument('--budget-ms', type=int, default=165000)
    args = parser.parse_args()
    require(1000 <= args.budget_ms <= 165000, 'Budget must be1000..165000ms')
    archive_path, manifest_path = args.archive.resolve(), args.manifest.resolve()
    require(archive_path == BOARD / ('cloud/artifacts/' + STEM + '.tar.gz')
            and manifest_path == BOARD / ('cloud/artifacts/' + STEM + '.manifest.json'), 'Only the new Source248 archive pair is eligible')
    require(hex_sha(args.archive_sha) and hex_sha(args.manifest_sha), 'Explicit actual archive/manifest SHA256 pins required')
    require(regular(args.archive) and regular(args.manifest) and sha_file(archive_path) == args.archive_sha
            and sha_file(manifest_path) == args.manifest_sha, 'New archive and manifest must already exist with exact bytes')
    require(regular(RESTORER) and sha_file(RESTORER) == RESTORER_SHA
            and regular(WORKSPACE_HELPER) and sha_file(WORKSPACE_HELPER) == WORKSPACE_HELPER_SHA, 'Exact reviewed restoration helper sources required')
    manifest = json.loads(manifest_path.read_bytes())
    require(manifest['scope'] == 'PORTABLE_POST232_PARTIAL48_SOURCE248_SOURCE_AND_DATA'
            and manifest['regularFilesOnly'] is True and manifest['historicalDataOnly'] is True
            and manifest['inputDirectories'] == [SAVED_REL] and manifest['baseArchivesIncluded'] is False,
            'Exact partial Source248 delta archive scope required')
    require(manifest['archive']['path'] == 'cloud/artifacts/' + STEM + '.tar.gz'
            and manifest['archive']['sha256'] == args.archive_sha
            and manifest['archive']['bytes'] == archive_path.stat().st_size, 'Manifest must bind exact actual archive')
    require(manifest['partial48Candidate']['sha256'] == MODEL_SHA
            and manifest['primaryCandidate']['sha256'] == FALLBACK_SHA
            and manifest['source248ReplayControls']['raw']['sha256'] == RAW_SHA
            and manifest['source248ReplayControls']['controls']['sha256'] == CONTROLS_SHA
            and manifest['source248ReplayControls']['passedControlCount'] == 35
            and manifest['source248ReplayControls']['connectedOwners'] == 48
            and manifest['source248ReplayControls']['pendingOwnerIds'] == ['source_trace_26'], 'Separate model48 and held fallback47 identities required')
    require(all(manifest[k] is False for k in ('all49Accepted', 'electricalTimingQualified', 'referenceQualified', 'cadQualified', 'fabricationReady')),
            'Partial evidence never becomes whole-board or fabrication qualification')
    rows = {}
    for row in manifest['files']:
        name = str(safe_relative(row['path']))
        require(name.startswith(SAVED_REL + '/') and name not in rows, 'Exact unique owned saved-directory members required')
        rows[name] = row
    metadata_names = ['WORKSPACE_HASH_INDEX.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'PROGRESS.json', 'README.md']
    expected_metadata = {SAVED_REL + '/' + name for name in metadata_names}
    require(set(manifest['snapshotPins']) == expected_metadata and all(hex_sha(v) for v in manifest['snapshotPins'].values())
            and all(rows[name]['sha256'] == value for name, value in manifest['snapshotPins'].items()), 'All four final saved-metadata pins must be present in archive members')
    prior_umask = os.umask(0o077)
    owned = Path(tempfile.mkdtemp(prefix='g350-source248-portable-archive-smoke-', dir='/tmp'))
    extracted, report_path = owned / 'extracted', owned / 'REPORT.json'
    started = time.monotonic()
    report = {'scope': 'SOURCE248_PARTIAL48_ISOLATED_PORTABLE_ARCHIVE_SMOKE_NOT_BOARD_QUALIFICATION',
        'passed': False, 'ownedDirectory': str(owned), 'extractionDestination': str(extracted), 'umask': '077',
        'inputBindings': {'archive': {'path': str(archive_path), 'sha256': args.archive_sha},
            'manifest': {'path': str(manifest_path), 'sha256': args.manifest_sha},
            'genericRestorer': {'path': str(RESTORER), 'sha256': RESTORER_SHA},
            'workspaceVerifier': {'path': str(WORKSPACE_HELPER), 'sha256': WORKSPACE_HELPER_SHA},
            'validator': {'path': str(Path(__file__).resolve()), 'sha256': sha_file(Path(__file__))}},
        'snapshotPins': manifest['snapshotPins'], 'commands': [], 'memberChecks': [],
        'archiveMembersExpected': len(rows), 'workspaceRestoreTargetsExpected': manifest['workspaceRestoreTargetCount'],
        'sdkExecuted': False, 'nativeExecuted': False, 'routingExecuted': False, 'cadExecuted': False,
        'workspaceRestorePerformed': False, 'defaultBoardPromoted': False, 'frozenFoldersWritten': False,
        'all49Accepted': False, 'fullBoardPassed': False, 'electricalTimingQualified': False,
        'referenceQualified': False, 'fabricationReady': False, 'isolatedPayloadRemovedAfterVerification': False}

    def save():
        report['elapsedMs'] = (time.monotonic() - started) * 1000
        temp = owned / '.REPORT.next'
        with temp.open('x') as stream:
            json.dump(report, stream, indent=2, allow_nan=False); stream.write('\n')
        os.replace(temp, report_path)

    def run(command):
        remaining = args.budget_ms / 1000 - (time.monotonic() - started)
        require(remaining > 0, 'Finite smoke budget exhausted')
        entry = {'argv': command, 'cwd': str(BOARD), 'state': 'RUNNING', 'umask': '077'}
        report['commands'].append(entry); save()
        begin = time.monotonic()
        completed = subprocess.run(command, cwd=BOARD, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, text=True, timeout=remaining, check=False)
        entry.update({'returncode': completed.returncode, 'stdout': completed.stdout, 'stderr': completed.stderr,
                      'elapsedMs': (time.monotonic() - begin) * 1000, 'state': 'COMPLETED'})
        save(); require(completed.returncode == 0, 'Read-only restoration verifier failed')
        return completed.stdout.strip()

    def restoration_count(text, expected_restored):
        match = re.fullmatch(r'Verified (\d+) evidence members; restored (\d+)', text)
        require(match and int(match[1]) == len(rows) and int(match[2]) == expected_restored, 'Exact generic restorer member/restoration counts required')

    try:
        save()
        base_command = [sys.executable, str(RESTORER), str(manifest_path), '--destination', str(extracted)]
        restoration_count(run(base_command + ['--verify-archive']), 0)
        seen = set()
        with tarfile.open(archive_path, 'r|gz') as archive:
            for member in archive:
                require(member.isfile() and not member.issym() and not member.islnk(), 'Only regular archive payload members are allowed')
                name = str(safe_relative(member.name))
                require(name in rows and name not in seen, 'No unknown or duplicate archive member')
                row = rows[name]
                require(member.size == row['bytes'] and stat.S_IMODE(member.mode) == row['mode'], 'Tar member size/mode mismatch')
                require(member.uid == member.gid == 0 and member.uname == member.gname == '' and member.mtime == 0,
                        'Normalized uid/gid/uname/gname/mtime required for every effective tar header')
                digest, count = hashlib.sha256(), 0
                stream = archive.extractfile(member)
                require(stream is not None, 'Readable regular member required')
                for chunk in iter(lambda: stream.read(CHUNK), b''):
                    digest.update(chunk); count += len(chunk)
                require(count == row['bytes'] and digest.hexdigest() == row['sha256'], 'Every member hash/bytes must match actual manifest')
                seen.add(name)
                report['memberChecks'].append({'path': name, 'bytes': count, 'sha256': digest.hexdigest(),
                    'mode': stat.S_IMODE(member.mode), 'uid': 0, 'gid': 0, 'uname': '', 'gname': '', 'mtime': 0, 'passed': True})
        require(seen == set(rows), 'All manifest members must be present exactly once')
        report['allMemberHashesSizesModesVerified'] = True; report['tarHeadersNormalized'] = True; save()
        restoration_count(run(base_command), len(rows))
        extracted_files = {p.relative_to(extracted).as_posix() for p in extracted.rglob('*') if p.is_file()}
        require(extracted_files == set(rows), 'Only exact indexed files may exist in the isolated extraction')
        for name, row in rows.items():
            target = extracted / safe_relative(name)
            require(target.resolve().is_relative_to(extracted.resolve()), 'Isolated member escaped destination')
            verify_file(target, row)
        saved = extracted / SAVED_REL
        for name, expected in manifest['snapshotPins'].items():
            require(sha_file(extracted / name) == expected, 'Extracted final metadata pin mismatch')
        index = json.loads((saved / 'WORKSPACE_HASH_INDEX.json').read_bytes())
        indexed = {SAVED_REL + '/' + str(safe_relative(row['path'])): row for row in index['files']}
        require(len(indexed) == len(index['files']) and set(indexed) | {SAVED_REL + '/WORKSPACE_HASH_INDEX.json'} == set(rows), 'Complete extracted saved-file index required')
        for name, row in indexed.items():
            require(all(row[k] == rows[name][k] for k in ('bytes', 'sha256', 'mode')), 'Extracted index and archive member metadata must agree')
        restore = json.loads((saved / 'WORKSPACE_RESTORE_MANIFEST.json').read_bytes())
        require(len(restore['files']) == manifest['workspaceRestoreTargetCount'], 'Exact local workspace target count required')
        target_rows = {}
        for row in restore['files'] + restore.get('baseDependencyRestoreFiles', []):
            target = Path(row['restorePath'])
            cache_root = BOARD.parent / 'bus-lanes-solver/.cache/root-routing-progress'
            temporary = str(target).startswith('/tmp/g350-') and target.resolve().is_relative_to('/tmp')
            solver_cache = target.parent == cache_root and target.name.endswith('.json') and target.resolve().parent == cache_root.resolve()
            require(target.is_absolute() and (temporary or solver_cache)
                    and not any(word in str(target).upper() for word in DENIED), 'Only explicit public restore targets in the existing helper scope may be verified')
            previous = target_rows.get(str(target))
            require(previous is None or all(previous[k] == row[k] for k in ('bytes', 'sha256', 'mode')), 'Conflicting actual target metadata')
            verify_file(target, row); target_rows[str(target)] = row
        restoration_count(run(base_command), 0)
        report['secondExtractionRestoredZero'] = True
        helper_command = [sys.executable, str(WORKSPACE_HELPER), '--saved-directory', str(saved)]
        helper = json.loads(run(helper_command))
        require(helper['savedFilesVerified'] == len(restore['files']) and helper['restoredFiles'] == 0 and helper['mode'] == 'verify'
                and helper['routingExecuted'] is False and helper['all49Accepted'] is False and helper['fabricationReady'] is False,
                'Workspace helper must verify every local target and restore nothing')
        report['workspaceVerification'] = helper
        report['allActualRecordedTargetCount'] = len(target_rows)
        report['allActualRecordedTargetsHashesSizesModesVerified'] = True
        report['inputFilesUnchanged'] = all(sha_file(path) == expected for path, expected in (
            (archive_path, args.archive_sha), (manifest_path, args.manifest_sha),
            (RESTORER, RESTORER_SHA), (WORKSPACE_HELPER, WORKSPACE_HELPER_SHA)))
        require(report['inputFilesUnchanged'], 'Archive/manifest/helper inputs must remain byte-identical')
        require(extracted.parent == owned and extracted.name == 'extracted' and not extracted.is_symlink()
                and owned.name.startswith('g350-source248-portable-archive-smoke-'), 'Cleanup is restricted to this owned extracted payload')
        shutil.rmtree(extracted)
        report['isolatedPayloadRemovedAfterVerification'] = not extracted.exists()
        report['passed'] = report['isolatedPayloadRemovedAfterVerification']; save()
        print(json.dumps({'report': str(report_path), 'reportSha256': sha_file(report_path), 'passed': report['passed'],
                          'members': len(rows), 'workspaceTargets': len(restore['files']), 'all49Accepted': False, 'fabricationReady': False}))
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        report['passed'] = False; save()
        print(json.dumps({'report': str(report_path), 'passed': False, 'isolatedPayloadPreserved': extracted.exists()}))
        raise
    finally:
        os.umask(prior_umask)


if __name__ == '__main__':
    main()
