import fs from 'node:fs'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import * as checks from '/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js'
import {g350DdrPhysicalChecks} from './source/scripts/lib/g350-ddr-physical-checks.mjs'
const [input,expectedSourceSha,output,...extra]=process.argv.slice(2)
assert(input&&expectedSourceSha&&output&&extra.length===0)
const raw=fs.readFileSync(input)
const hash=createHash('sha256').update(raw).digest('hex')
assert.equal(hash,expectedSourceSha)
const checkerSha=createHash('sha256').update(fs.readFileSync('/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js')).digest('hex')
assert.equal(checkerSha,'1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc')
const circuit=JSON.parse(raw),results={}
for(const name of [...g350DdrPhysicalChecks,'checkPadPadClearance','checkTracesAreContiguous','checkDanglingTraces','checkPcbTracesOutOfBoard','checkPcbCopperOverKeepout','checkPcbComponentOverlap','checkPcbComponentsOutOfBoard']){
 const start=performance.now();results[name]=checks[name](circuit)
 console.log(JSON.stringify({check:name,errors:results[name].length,seconds:(performance.now()-start)/1000}))
}
const counts=Object.fromEntries(Object.entries(results).map(([k,v])=>[k,v.length]))
const physicalErrors=Object.values(results).flat().length
assert(!fs.existsSync(output))
fs.writeFileSync(output,JSON.stringify({sourceSha256:hash,checkerSha256:checkerSha,checkCount:17,counts,results,physicalErrors,scope:'Fresh routing-disabledV6 fullplacement and existing2 reference stubs only; no49 connection/timing acceptance',signalRoutingPerformed:false,accepted49:false,fabricationReady:false},null,2)+'\n')
assert.equal(Object.keys(results).length,17)
process.exitCode=physicalErrors?1:0
