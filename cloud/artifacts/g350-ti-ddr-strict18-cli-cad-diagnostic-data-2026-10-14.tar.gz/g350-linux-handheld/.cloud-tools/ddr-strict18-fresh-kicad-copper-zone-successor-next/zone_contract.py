"""Stdlib-only authentic Source pour/keepout to raw-zone projection.

Delete only owned copper-zone byte spans. Preserve every hardware keepout.
No triangulation/fill/net repair or KiCad import occurs in this module.
"""
import hashlib,json

def require(value,label):
 if not value:raise ValueError(label)
def digest(value):return hashlib.sha256(value).hexdigest()
def canonical(value):return digest(json.dumps(value,sort_keys=True,separators=(',',':')).encode())
def one(rows,label):
 require(len(rows)==1,label+'; matches='+str(len(rows)));return rows[0]
def polygon_points(node,helper):
 pts=one(helper.children(node,'pts'),'One polygon point list')
 points=[]
 for point in helper.children(pts,'xy'):
  require(len(point.items)==3 and all(isinstance(v,str) for v in point.items),'Scalar polygon coordinates')
  points.append([float(point.items[1]),float(point.items[2])])
 require(len(points)>=3,'Actual polygon needs at least3 points');return points
def normalize_source_ring(vertices,helper):
 # Exact installed CLI getBrepZoneRings transformations: affine XY then
 # rotate start to largest X/largest Y, remove consecutive/closing duplicates.
 points=[helper.transform(p['x'],p['y']) for p in vertices]
 if len(points)>1:
  start=max(range(len(points)),key=lambda i:(points[i][0],points[i][1]));points=points[start:]+points[:start]
 result=[]
 for point in points:
  if not result or result[-1]!=point:result.append(point)
 if len(result)>1 and result[0]==result[-1]:result.pop()
 return result

def map_zones(raw,data,helper,pinned):
 require(digest(data)==pinned['actualExportSha256'] and canonical([r for r in raw if r['type'] in ['pcb_copper_pour','pcb_keepout']])==pinned['actualSourceZoneRowsCanonicalSha256'],'Exact fresh export and actual Source zone rows required')
 root=helper.parse_sexpressions(data);zones=helper.children(root,'zone')
 pours=[r for r in raw if r['type']=='pcb_copper_pour'];keepouts=[r for r in raw if r['type']=='pcb_keepout'];nets={r['source_net_id']:r for r in raw if r['type']=='source_net'}
 require(len(pours)==pinned['actualSourceCopperPourCount'] and len(keepouts)==pinned['actualSourceKeepoutCount'] and len(zones)==len(pours)+len(keepouts),'Raw zones must exactly represent actual Source pours plus keepouts')
 raw_nets={int(n.items[1]):n.items[2] for n in helper.children(root,'net')};mapped=set();copper=[];retained=[];rows=[]
 for source in pours+keepouts:
  is_keepout=source['type']=='pcb_keepout';source_id=source[source['type']+'_id'];expected_uuid=helper.converter_uuid(('keepout:' if is_keepout else 'zone:')+source_id)
  zone=one([z for z in zones if helper.values(z,'uuid')==[expected_uuid]],'Authentic Source zone UUID '+source_id)
  require(expected_uuid not in mapped,'One actual zone per Source record');mapped.add(expected_uuid)
  node=data[zone.start:zone.end];pin=one([r for r in pinned['zones'] if r['sourceId']==source_id],'Pinned actual zone bytes '+source_id)
  require(pin['sourceCanonicalSha256']==canonical(source) and pin['rawZoneSha256']==digest(node) and pin['rawZoneBytes']==len(node) and pin['rawZoneUuid']==expected_uuid,'Every authentic raw zone node is byte pinned to its Source record')
  polygons=helper.children(zone,'polygon');actual_rings=[polygon_points(p,helper) for p in polygons]
  if is_keepout:
   require(source['shape']=='rect' and len(polygons)==1 and len(helper.children(zone,'keepout'))==1 and not helper.children(zone,'layer'),'Only actual hardware rectangular keepout eligible for retention')
   require(helper.values(zone,'layers')==[helper.LAYER_NAMES[layer] for layer in source['layers']] and helper.values(zone,'net')==['0'] and helper.values(zone,'net_name')==[''],'Authentic hardware keepout layers/net0')
   restrictions=one(helper.children(zone,'keepout'),'One keepout restriction list')
   require({n.head:tuple(n.items[1:]) for n in restrictions.items if isinstance(n,helper.Node)}=={k:('not_allowed',) for k in ['tracks','vias','pads','copperpour','footprints']},'All original hardware keepout restrictions retained')
   x,y=source['center']['x'],source['center']['y'];w,h=source['width']/2,source['height']/2
   expected_rings=[[helper.transform(px,py) for px,py in [(x-w,y-h),(x+w,y-h),(x+w,y+h),(x-w,y+h)]]];retained.append(zone)
  else:
   require(source['shape']=='brep' and not helper.children(zone,'keepout') and not helper.children(zone,'layers'),'Only actual Source-owned copper pour eligible for removal')
   net=nets[source['source_net_id']];net_id=int(one(helper.values(zone,'net'),'Actual copper netcode'))
   require(helper.values(zone,'layer')==[helper.LAYER_NAMES[source['layer']]] and helper.values(zone,'net_name')==[net['name']] and raw_nets[net_id]==net['name'] and net_id!=0,'Authentic Source copper layer and named physical net')
   rings=[source['brep_shape']['outer_ring']]+source['brep_shape']['inner_rings'];expected_rings=[normalize_source_ring(r['vertices'],helper) for r in rings];expected_rings=[r for r in expected_rings if len(r)>=3];copper.append(zone)
  require(len(actual_rings)==len(expected_rings) and all(len(actual)==len(expected) and all(helper.at(a,b) for a,b in zip(actual,expected)) for actual,expected in zip(actual_rings,expected_rings)),'Exact Source↔raw zone outline/hole geometry '+source_id)
  rows.append({'sourceId':source_id,'sourceCanonicalSha256':canonical(source),'rawZoneUuid':expected_uuid,'rawZoneSha256':digest(node),'rawZoneBytes':len(node),'sourceKind':source['type'],'rawPolygonCount':len(actual_rings),'rawPolygonPointCount':sum(map(len,actual_rings)),'filledPolygonBytesPinned':not is_keepout,'layer':source.get('layer'),'layers':source.get('layers'),'sourceNetId':source.get('source_net_id'),'sourceNetName':nets[source['source_net_id']]['name'] if not is_keepout else None,'removedForDiagnostic':not is_keepout,'retainedByteExact':is_keepout,'sourceGeometryAndRawNodeBytesMatched':True})
 require(len(mapped)==len(zones) and len(copper)==len(pours) and len(retained)==len(keepouts),'Every raw zone has exactly one real Source owner')
 clean=helper.drop_spans(data,copper);tree=helper.parse_sexpressions(clean)
 require([clean[n.start:n.end] for n in helper.children(tree,'zone')]==[data[n.start:n.end] for n in retained],'Retain all hardware keepout node bytes/order exactly')
 for kind in ['footprint','via','segment']:
  require([clean[n.start:n.end] for n in helper.children(tree,kind)]==[data[n.start:n.end] for n in helper.children(root,kind)],'Every original '+kind+' node byte retained')
 report={'actualSourceCopperPourCount':len(pours),'actualSourceKeepoutCount':len(keepouts),'actualRawZoneCount':len(zones),'removedOnlySourceMappedCopperZones':len(copper),'retainedExactHardwareKeepoutZones':len(retained),'allSourceToRawZoneNetLayerGeometryAndPinnedNodeBytesMatched':True,'allFootprintViaSegmentKeepoutBytesHeld':True,'zoneRows':rows,'copperFreeWithKeepoutsSha256':digest(clean),'sourceOrRawEdited':False,'fillOrNetRepairPerformed':False,'referenceQualified':False,'fabricationReady':False}
 return clean,report
