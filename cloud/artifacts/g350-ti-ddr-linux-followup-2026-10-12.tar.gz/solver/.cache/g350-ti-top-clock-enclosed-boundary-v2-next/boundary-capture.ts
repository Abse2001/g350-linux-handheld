import assert from "node:assert/strict"
import { fingerprint } from "./recipe"

export function wrapBoundaryConstructor<T extends new (...args: any[]) => any>(
  Original: T,
  observe: (args: any[]) => void,
) {
  let observationErrors = 0
  let ProxyConstructor: T
  ProxyConstructor = new Proxy(Original, {
    construct(target, args, newTarget) {
      try {
        observe(args)
      } catch {
        observationErrors++
      }
      return Reflect.construct(
        target,
        args,
        newTarget === ProxyConstructor ? target : newTarget,
      )
    },
  })
  return {
    Constructor: ProxyConstructor,
    observationErrors: () => observationErrors,
  }
}

/** Raw scene data only: no Grid, checker, path reconstruction or geometry call. */
export function makeBoundaryCapture(
  input: any,
  pairNames: readonly string[],
  physical: readonly any[],
  save: (value: unknown) => void,
) {
  let attempted = false,
    succeeded = false,
    error: string | null = null
  let bytes = 0,
    targetName: string | null = null
  const observeConstructor = (args: any[]) => {
    const scene = args[0],
      name = scene?.connection?.name
    if (
      attempted ||
      typeof name !== "string" ||
      pairNames.includes(name) ||
      name === "pair_corridor"
    )
      return
    attempted = true
    try {
      assert.ok(input.connections.some((c: any) => c.name === name))
      assert.equal(fingerprint(scene.input), fingerprint(input))
      assert.equal(input.connections.length, 49)
      assert.equal(input.obstacles.length, 856)
      assert.ok(scene.copper instanceof Array && scene.owners instanceof Set)
      assert.ok(Number.isFinite(scene.width) && Number.isFinite(scene.margin))
      const layer = scene.connection.pointsToConnect[0].layer
      const filteredPhysical = physical.filter(
        (c) =>
          c.layer === layer &&
          !c.owners.some((owner: string) => scene.owners.has(owner)),
      )
      assert.ok(
        fingerprint(scene.copper.slice(0, filteredPhysical.length)) ===
          fingerprint(filteredPhysical),
        "Filtered physical Copper prefix fingerprint differs",
      )
      const clockCandidateCopper = scene.copper.slice(filteredPhysical.length)
      assert.ok(clockCandidateCopper.length > 0)
      assert.ok(
        clockCandidateCopper.every((c: any) =>
          c.owners.some((owner: string) => pairNames.includes(owner)),
        ),
      )
      assert.equal(
        args.length,
        3,
        "Original enclosed Grid call must retain three supplied arguments",
      )
      const capture = {
        diagnosticOnly: true,
        boundary:
          "FIRST_ENCLOSED_GRID_CONSTRUCTOR_THEN_FIRST_ORIGINAL_YIELD_AND_RETURN",
        constructorArgumentCount: args.length,
        originalGridOptionalArguments: {
          soft: "UNSUPPLIED",
          penalty: "UNSUPPLIED",
          history: "UNSUPPLIED",
          options: "UNSUPPLIED",
        },
        input: scene.input,
        connection: scene.connection,
        width: scene.width,
        margin: scene.margin,
        owners: [...scene.owners],
        copper: scene.copper,
        start: args[1],
        end: args[2],
        originalPhysicalCopper: physical,
        filteredPhysicalCopper: filteredPhysical,
        clockCandidateCopper,
        filteredPhysicalPrefixHeld: true,
        clockCopperSuffixOnly: true,
        copperGeometryReconstruction:
          "Raw actual ordered Copper records are authoritative; no Trace/coupledSection is fabricated or reconstructed.",
        inputFingerprint: fingerprint(input),
        physicalFingerprint: fingerprint(physical),
        acceptedClock: false,
        accepted49: false,
        fabricationReady: false,
      }
      const raw = JSON.stringify(capture)
      bytes = Buffer.byteLength(raw)
      assert.ok(bytes <= 4 * 1024 ** 2)
      save(capture)
      targetName = name
      succeeded = true
    } catch (caught) {
      error = String(caught).slice(0, 1024)
    }
  }
  return {
    observeConstructor,
    attempted: () => attempted,
    status: () => ({ attempted, succeeded, error, bytes, targetName }),
  }
}
