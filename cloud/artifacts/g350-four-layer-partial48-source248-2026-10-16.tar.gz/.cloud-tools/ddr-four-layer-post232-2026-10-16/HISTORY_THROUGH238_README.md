Merged233 partial47 evidence, closed233–238.

This separate collection preserves current223's data-route progress and exact204
CA tuning bodies: 47/49 physical paths, with D12/source26 and DQM0/source30 still
pending. Root233 requalified all47 bodies and numeric joins, both actual DQS1
critical views/all five APIs, and all derived hard maxima. Only13/26 CA owners
meet20.95mm; CA spread15.8186mm and three fresh native bus-skew findings remain.
Full timing, electrical readiness, TI qualification, CAD, default promotion,
all49 acceptance and fabrication readiness are FALSE.

Source234 projection, capture235/full inverse and fresh Core236/all35 controls
passed. Native237 reran focused16 checks: physical10 and other requested geometry
checks returned zero findings; all3 bus-skew findings are retained. Other16 native
checks were not rerun, and prior185 full32 results are historical only. Auth238
authenticated all227 manual vias and found no foreign via-to-track violations.

LITERAL15-POUR CLEARANCE IS NOT YET QUALIFIED. The Source228 all14-pour pass is a
base dependency only and is NOT inherited for the new Source236 copper geometry.
No new pour pass, own-net reentry proof, complete routing or fabrication claim is
made by this collector.

The seven frozen g350-ti-current233-source236-* report/script/control files are
included with exact hashes and modes as ANALYSIS ONLY. Their literal reference-
material gap witnesses are retained. TI/reference-plane/electrical qualification
is not established by this review; all-four-signal routing is not proof of the
documented signal/GND/power/signal stack. The original Source CA minimum20.95mm
remains unchanged and stricter than the current-placement pure TI arithmetic
minimum19.75mm. The assessment does not relax any retained routing requirement.

Restore Source209 and its documented prior prerequisites first, then the frozen
Source228 archive. Their exact archive/manifest hashes are recorded in
WORKSPACE_RESTORE_MANIFEST.json. They are dependencies and were not copied or
rewritten here. The helper does not enforce dependency order; that is a caller
precondition. Then verify/restore this new saved workspace using:

python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post232-2026-10-16
python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post232-2026-10-16 --restore

The existing helper rejects different bytes/modes instead of replacing local
work. Only public regular files are saved; private authority/context bodies are
excluded. No SDK, Bun/Node, application import, archive creation or commit is
performed by the collector. Prior post209 metadata and payloads remain frozen.
