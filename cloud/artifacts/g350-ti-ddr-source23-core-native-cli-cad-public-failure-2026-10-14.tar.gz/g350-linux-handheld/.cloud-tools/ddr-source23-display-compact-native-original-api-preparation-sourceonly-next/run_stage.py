"""Root-only serial Native then originalAPI stage inside Root's bounded ownedprocessgroup."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
BUN=Path('/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe')
def require(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 packet=os.environ.get('G350_MOVED23_NATIVE_BOUND_PATH');packet_sha=os.environ.get('G350_MOVED23_NATIVE_BOUND_SHA');authority=os.environ.get('G350_MOVED23_NATIVE_ROOT_AUTHORITY');authority_sha=os.environ.get('G350_MOVED23_NATIVE_ROOT_AUTHORITY_SHA');run=os.environ.get('G350_MOVED23_NATIVE_OWNED_OUTPUT')
 require(all([packet,packet_sha,authority,authority_sha,run]),'Only Root outerowned stage')
 require(sha(packet)==packet_sha and sha(authority)==authority_sha,'Exact Root boundmanifest/authority')
 import importlib.util
 spec=importlib.util.spec_from_file_location('moved23_stdlib_prerequisites',ROOT/'validate-root-prerequisites.py');validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)
 m=json.loads(Path(packet).read_bytes());a=json.loads(Path(authority).read_bytes());validator.validate_binding(m,a,packet_sha)
 out=Path(run);require(out.is_dir()and not out.is_symlink(),'Owned actual outputdirectory')
 require(not any((out/name).exists()for name in ['native23-report.json','actual-original-all3-pair-api.json','result.json']),'Exclusive newoutputs')
 env=os.environ.copy()
 for key in ['NODE_OPTIONS','NODE_PATH','BUN_OPTIONS','BUN_INSTALL']:env.pop(key,None)
 env['G350_MOVED23_FRESH_NATIVE_APPROVED']='1'
 results=[]
 commands=[('native',[str(BUN),'--smol',str(ROOT/'qualify-fresh-native.mjs'),packet,packet_sha,authority,authority_sha,str(out/'native23-report.json')]),('original3pairAPI',[str(BUN),'--smol',str(ROOT/'check-fresh-original-all3-pair-api.ts'),packet,packet_sha,authority,authority_sha,str(out/'native23-report.json'),str(out/'actual-original-all3-pair-api.json')])]
 for phase,command in commands:
  with(out/(phase+'.log')).open('x')as log:code=subprocess.run(command,cwd='/workspace/g350-linux-handheld',env=env,stdout=log,stderr=subprocess.STDOUT,check=False).returncode
  results.append({'phase':phase,'command':command,'exitCode':code})
  if code:break
 native=json.loads((out/'native23-report.json').read_bytes())if(out/'native23-report.json').is_file()else None
 api=json.loads((out/'actual-original-all3-pair-api.json').read_bytes())if(out/'actual-original-all3-pair-api.json').is_file()else None
 passed=len(results)==2 and all(r['exitCode']==0 for r in results)and native is not None and native.get('physicalErrors')==0 and native.get('physicalCpuRamConnectedCarrierCount')==23 and api is not None and api.get('allOriginalApiLoaded23ChecksPassed')is True
 result={'scope':m['scope'],'packetSha256':packet_sha,'sourceManifestSha256':m['sourceManifestSha256'],'passed':passed,'commands':results,'nativeCalls':sum(r['phase']=='native'for r in results),'original3PairApiCalls':sum(r['phase']=='original3pairAPI'for r in results),'actualCoreSha256':m['actualFreshArtifacts']['actualCoreSha256'],'actualCoreControlsSha256':m['actualFreshArtifacts']['coreControlsSha256'],'actualNativeReportPath':str(out/'native23-report.json'),'actualNativeReportSha256':sha(out/'native23-report.json')if native else None,'actualOriginal3PairApiReportPath':str(out/'actual-original-all3-pair-api.json'),'actualOriginal3PairApiReportSha256':sha(out/'actual-original-all3-pair-api.json')if api else None,'coreCalls':0,'cliCalls':0,'cadCalls':0,'expectedMissingOriginalSignalCount':26,'referenceQualified':False,'electricalTimingQualified':False,'complete23Accepted':False,'accepted49':False,'fabricationReady':False}
 with(out/'result.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'passed':passed,'nativeCalls':result['nativeCalls'],'original3PairApiCalls':result['original3PairApiCalls'],'accepted49':False}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
