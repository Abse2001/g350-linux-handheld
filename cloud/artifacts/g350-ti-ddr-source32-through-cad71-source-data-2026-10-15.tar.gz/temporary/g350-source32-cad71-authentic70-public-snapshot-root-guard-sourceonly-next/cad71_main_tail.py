"""SOURCE-ONLY conditional CAD71 tail over successful CAD60 control flow.
Inherited history through genuine70 stays in the independently reviewed prefix.
No Docker command is executed by the outer tail. The owned wrapper records cleanup.
"""
import fcntl,hashlib,importlib.util,json,os,re,secrets,shutil,stat
from pathlib import Path

ROOT=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
RUNTIME_SHA='66ab647ebed4f4c754afbfdcd2da87c02b21e7aef34a474840ccfb6022c15764'
COPY_SHA='3a4c5d98b59bb76dbb1de31fcadc194bec0cc00e502e7a7a97d2ff519cef9d89'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def row(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink()
 return dict(path=str(p),sha256=sha(p),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def binding(r):assert row(r['path'])=={k:r[k]for k in('path','sha256','bytes','mode')}
def write(p,value):
 with Path(p).open('x')as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
 Path(p).chmod(0o600)

def run_cad71_tail(*,c,focused_process_runner,proposal,contract,stage,cli_preparation,
                   source_sha,out,bindings,closed70,git_inventory,base):
 """Return 0/2 after writing POSTAUDIT; all setup checks precede either owned child.
 Required new proposal fields: cad32SnapshotCopyInputsPin, cad32SnapshotRoot,
 cadSnapshotWrapperPin, cadSnapshotCheckerPin. Root copies only the final exact transitive inputs after genuine67/68/69/70, including all3Core67 and bothAPI69 phasePOSTs.
 """
 out=Path(out);assert out.parent==Path('/tmp')and out.name.startswith('g350-source32-cad-root-')and out.resolve()==out and out.is_dir()and not out.is_symlink()
 assert isinstance(COPY_SHA,str)and re.fullmatch('[0-9a-f]{64}',COPY_SHA),'Future exact Source32 sparse-copy plan remains unbound'
 assert isinstance(RUNTIME_SHA,str)and re.fullmatch('[0-9a-f]{64}',RUNTIME_SHA),'Future late-activated CLI32 runtime remains unbound'
 assert proposal['cli32PreparationPin']['sha256']==RUNTIME_SHA and sha(proposal['cad32SnapshotCopyInputsPin']['path'])==COPY_SHA
 binding(proposal['cad32SnapshotCopyInputsPin']);copy_inputs=read(proposal['cad32SnapshotCopyInputsPin']['path'])
 assert copy_inputs['requiredSparseFileCount']==len(copy_inputs['snapshots'])==proposal['cad32ExpectedSparseFileCount']and copy_inputs['requiredSparseBytes']==proposal['cad32ExpectedSparseBytes']==sum(item['original']['bytes']for item in copy_inputs['snapshots'])and 0<copy_inputs['requiredSparseBytes']<=67108864
 assert copy_inputs['runtimeSourceManifest']==proposal['cli32PreparationPin']
 snapshot_root=Path(proposal['cad32SnapshotRoot']);assert snapshot_root.parent==out/'snapshots'and re.fullmatch('[0-9a-f]{32}',snapshot_root.name)and snapshot_root.is_dir()and snapshot_root.resolve()==snapshot_root
 assert str(out)==copy_inputs['runRoot']and str(snapshot_root)==copy_inputs['snapshotRoot']
 for key in('cad32SnapshotWrapperPin','cad32SnapshotCheckerPin'):binding(proposal[key])
 runtime=Path(proposal['cli32PreparationPin']['path']).parent;output=out/'output'
 zone_policy={'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 cad_policy={**zone_policy,'wallSeconds':90,'diskFreeGuard':{'path':'/var/lib/docker','minimumFreeBytes':134217728}}
 binding(proposal['cad32DiskProcessScopePin']);spec=importlib.util.spec_from_file_location('root_cad46_optional_disk_process_scope',proposal['cad32DiskProcessScopePin']['path']);cad_process_runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(cad_process_runner)
 with(ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);prior=closed70();assert prior['actualClosedScopeCount']==70
  _,native_before,board_before,solver_before,_=c.guard.checked();bindings();git_before=git_inventory();assert git_before==base['gitMetadataFiles']
  assert board_before['treeSha256']==stage['boardSdkTreeSha256']and solver_before['treeSha256']==stage['solverSdkTreeSha256']
  def snapshots_held():
   binding(proposal['cad32SnapshotCopyInputsPin'])
   for item in copy_inputs['snapshots']:
    original=item['original'];binding(original);target=snapshot_root/item['snapshotRelativePath']
    assert item['containerTargetPath']==original['path']and item['snapshotPath']==str(target)and target.resolve()==target
    binding({**original,'path':str(target)})
  snapshots_held()
  for p in(output,out/'owned-zone',out/'owned-cad',out/'ROOT_ZONE_AUTHORITY.json',out/'ROOT_CAD_AUTHORITY.json',out/'SOURCE_ZONE_PINS.json',out/'SNAPSHOT_PLAN.json',out/'cad-resource-observations.json'):
   assert not p.exists()and not p.is_symlink(),'Fresh CAD45 exclusive output: '+str(p)
  output.mkdir(mode=0o700);(out/'tmp').mkdir(mode=0o700)
  authority={**cli_preparation['actualPrerequisites'],'authorizedByRoot':True,'scope':cli_preparation['scope'],
   'sourceManifestSha256':RUNTIME_SHA,'genuineSourceManifestSha256':proposal['promoted32ManifestPin']['sha256'],
   'actualNativeSourceManifestSha256':proposal['native32PreparationPin']['sha256'],'actualApiSourceManifestSha256':proposal['native32PreparationPin']['sha256'],
   'actualPreviousScopesCollectedAndEmpty':True,'noConcurrentRootWorker':True,'rootFullWorkerReadPassed':True,
   'rootGuardProposalManifestSha256':source_sha,'actualClosedPriorScopes':prior,'outputDirectory':str(output),
   'actualCliCollection':copy_inputs['actualClosedCliCollection'],'actualCliReport':copy_inputs['actualCliReport'],
   'actualExport':copy_inputs['actualExport'],'policy':zone_policy,'nonce':secrets.token_hex(32),'all49Accepted':False,'fabricationReady':False}
  zone_auth=out/'ROOT_ZONE_AUTHORITY.json';write(zone_auth,authority);zone_auth_sha=sha(zone_auth)
  pins=out/'SOURCE_ZONE_PINS.json';final_auth=out/'ROOT_CAD_AUTHORITY.json';plan_path=out/'SNAPSHOT_PLAN.json'
  container_name='g350-source32-fresh-cad-'+secrets.token_hex(8)+'-'+secrets.token_hex(8)
  environment={'NO_COLOR':'1','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','TMPDIR':str(out/'tmp')}
  workspace_before=shutil.disk_usage('/workspace').free
  zone_execution=cad_execution=None;run_error=post_error=inspection_error=None;result=None;resource=None
  zone_empty=cad_empty=False;container_empty=None;zone_sha=final_sha=plan_sha=None
  def prefork(policy,phase):
   def check(memory):
    bindings();assert closed70()==prior and git_inventory()==git_before;snapshots_held();assert sha(zone_auth)==zone_auth_sha
    if phase=='cad':assert sha(pins)==zone_sha and sha(final_auth)==final_sha and sha(plan_path)==plan_sha
    assert memory['current']+policy['rssBytes']+1073741824+(2147483648 if phase=='cad'else 0)<policy['sharedBytes']
    assert shutil.disk_usage('/workspace').free>=workspace_before
    assert shutil.disk_usage('/tmp').free>=536870912
   return check
  def independently_empty(e):
   if not isinstance(e,dict):return False
   pg=e.get('pgid');return type(pg)is int and pg>0 and c.guard.process_scope.owned(pg)==[]
  def natural(e):
   if not isinstance(e,dict):return False
   empty=independently_empty(e)
   return bool(e.get('exitCode')==0 and e.get('cleanupOwnedGroupEmpty')is True and e.get('diagnosticStopped')is False
    and not e.get('stopReasons')and isinstance(e.get('oomDelta'),dict)and bool(e['oomDelta'])and not any(e['oomDelta'].values())and empty)
  try:
   zone_command=[contract['pythonInterpreterPin']['path'],'-B',str(runtime/'build_bound_zone_pins.py'),
    '--root-receipt',str(zone_auth),'--root-receipt-sha256',zone_auth_sha,
    '--cli-collection',copy_inputs['actualClosedCliCollection']['path'],'--cli-collection-sha256',copy_inputs['actualClosedCliCollection']['sha256'],
    '--cli-report',copy_inputs['actualCliReport']['path'],'--cli-report-sha256',copy_inputs['actualCliReport']['sha256'],'--output-pins',str(pins)]
   zone_execution=focused_process_runner.run_guarded(zone_command,str(c.BOARD),out/'owned-zone',zone_policy,
    {**environment,'G350_SOURCE32_ZONE_PINS_ROOT_GUARDED':'1'},before_spawn=prefork(zone_policy,'zone'))
   zone_empty=natural(zone_execution);assert zone_empty,'Zone derivation must be natural0 and independently empty before CAD'
   zone=read(pins);assert zone['actualCoreRawSha256']==proposal['actual67CoreRawPin']['sha256']and zone['actualExportPath']==copy_inputs['actualExport']['path']and zone['actualExportSha256']==copy_inputs['actualExport']['sha256']and zone['actualSourceKeepoutCount']==2
   zone_sha=sha(pins);authority.update(actualSourceZonePins=row(pins),policy=cad_policy);write(final_auth,authority);final_sha=sha(final_auth)
   plan={k:copy_inputs[k]for k in('runtimeSourceManifest','actualClosedCliCollection','actualCliPostaudit','actualCliReport','actualExport')}
   plan.update(newCadAuthority=row(final_auth),actualSourceZonePins=row(pins),snapshotRoot=str(snapshot_root),
    snapshots=[{'originalPath':item['original']['path'],'snapshotPath':str(snapshot_root/item['snapshotRelativePath'])}for item in copy_inputs['snapshots']])
   # Root-reviewed checker is stdlib-only; import only after its source is bound.
   binding(proposal['cad32SnapshotCheckerPin']);spec=importlib.util.spec_from_file_location('root_cad45_sparse_snapshot_checker',proposal['cad32SnapshotCheckerPin']['path'])
   checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker);mounts=checker.validate_snapshot_plan(plan)
   assert isinstance(mounts,list)and mounts and all(isinstance(x,str)for x in mounts)
   write(plan_path,plan);plan_sha=sha(plan_path)
   cad_command=['bash',proposal['cad32SnapshotWrapperPin']['path'],str(output),container_name,str(plan_path),plan_sha,str(runtime/'inspect_source32.py'),
    '--root-receipt',str(final_auth),'--root-receipt-sha256',final_sha,'--output-directory',str(output)]
   assert natural(zone_execution)and c.guard.process_scope.owned(zone_execution['pgid'])==[]
   cad_execution=cad_process_runner.run_guarded(cad_command,str(c.BOARD),out/'owned-cad',cad_policy,
    {**environment,'G350_SOURCE32_CAD_ROOT_GUARDED':'1'},before_spawn=prefork(cad_policy,'cad'))
   cad_empty=natural(cad_execution)
  except BaseException as error:
   run_error=type(error).__name__+': '+str(error)
  # Recover truthful owned receipts even when a run_guarded call raised.
  for phase in('zone','cad'):
   ep=out/('owned-'+phase)/'execution.json'
   if ep.is_file():
    if phase=='zone':zone_execution=read(ep)
    else:cad_execution=read(ep)
  zone_natural=natural(zone_execution);cad_natural=natural(cad_execution)
  zone_empty=independently_empty(zone_execution);cad_empty=independently_empty(cad_execution)
  resource_path=out/'cad-resource-observations.json'
  try:
   if resource_path.is_file():
    resource=read(resource_path)
    assert resource['containerName']==container_name and resource['imageId']==cli_preparation['imageId']and resource['cleanupStatusRecorded']is True
    assert resource['previousScope45ContainerName']==proposal['previousScope45ContainerName']and resource['previousScope45ContainerAbsenceCheckPassed']is True
    assert resource['previousScope46ContainerName']==proposal['previousScope46ContainerName']and resource['previousScope46ContainerAbsenceCheckPassed']is True
    observations=resource['observations'];assert len(observations)==2 and [r['phase']for r in observations]==['BEFORE_CONTAINER','AFTER_CLEANUP']
    for observation in observations:
     assert observation['imageId']==cli_preparation['imageId']and observation['imageAlreadyPresent']is observation['noImageLoadBuildPull']is True
     assert observation['dockerRootDir']==cad_policy['diskFreeGuard']['path']and observation['vfsOverheadBufferBytes']==201326592 and observation['continuousDiskMinimumFreeBytesExpected']==134217728
     assert type(observation['imageSizeBytes'])is int and observation['imageSizeBytes']>0 and type(observation['freeBytesActuallyObserved'])is int
     assert observation['requiredVfsBytes']==(2*observation['imageSizeBytes']+201326592 if observation['storageDriver']=='vfs'else 0)
     assert observation['actualVfsReserveSatisfiedAtObservation']is True and observation['freeBytesActuallyObserved']>=observation['requiredVfsBytes']
    assert resource['containerWorkerStatus']==0
    container_empty=resource['ownedContainerActuallyEmpty']is True
  except BaseException as error:inspection_error='Resource receipt '+type(error).__name__+': '+str(error)
  native_after=board_after=solver_after=None
  try:
   _,native_after,board_after,solver_after,_=c.guard.checked();bindings();assert closed70()==prior and git_inventory()==git_before;snapshots_held();assert sha(zone_auth)==zone_auth_sha
   if zone_sha:assert sha(pins)==zone_sha
   if final_sha:assert sha(final_auth)==final_sha
   if plan_sha:assert sha(plan_path)==plan_sha
   assert shutil.disk_usage('/workspace').free>=workspace_before
  except BaseException as error:post_error=type(error).__name__+': '+str(error)
  workspace_after=shutil.disk_usage('/workspace').free;workspace_floor_held=workspace_after>=workspace_before
  held=post_error is None and native_before==native_after and board_before==board_after and solver_before==solver_after
  report=output/'kicad-source32-report.json';result_passed=False
  try:
   assert {p.name for p in output.iterdir()}=={'source32-copper-zone-free-with-keepouts.kicad_pcb','actual-net-and-physical-graph-observations.json','kicad-source32-report.json'}
   for p in output.iterdir():assert p.is_file()and not p.is_symlink()and 0<p.stat().st_size<=33554432
   result=read(report);assert result['scope']==cli_preparation['scope']and result['sourceManifestSha256']==RUNTIME_SHA
   assert result['passed']is result['diagnosticCompleted']is result['allInputBytesHeld']is result['nativeAndOriginalApiStagesPassed']is True
   assert result['actualCoreSha256']==proposal['actual67CoreRawPin']['sha256']and result['actualCoreControlsSha256']==proposal['actual67CoreControlsPin']['sha256']
   assert result['actualExportPath']==copy_inputs['actualExport']['path']and result['actualExportSha256']==copy_inputs['actualExport']['sha256']
   assert result['actualKiCadVersion'].startswith('10.0.6')and result['actualLoadedFootprints']==509 and result['actualLoadedVias']==229
   assert result['actualLoadedSegments']==result['actualDerivedSourceSegmentCount']==1116 and result['actualLoadedLayerCount']==4
   assert result['actualRetainedNativeHardwareKeepoutZones']==2 and result['actualNativeCopperPourZones']==0 and result['all297SourceTracesMappedBijectively']is True
   assert len(result['signalObservations'])==result['actualLocalNetAgreementCount']==result['actualLocalPhysicalApproachCount']==98
   assert len(result['actual32GraphObservations'])==result['actual32NonzeroNetGraphCount']==result['actual32PhysicalCpuRamGraphCount']==32
   assert result['expectedMissingOriginalSignalCount']==17
   for key in('sourceRawOrSdkEdited','rawExportEdited','netRepairPerformed','saveBoardPerformed','refillPerformed','allRuleDrcPerformed','referenceQualified','electricalTimingQualified','complete32Accepted','accepted49','fabricationReady'):assert result[key]is False
   disk=cad_execution['diskFreeGuard'];assert disk['path']=='/var/lib/docker'and disk['minimumFreeBytes']==134217728 and disk['sampleCount']>=2 and disk['readErrorCount']==0 and disk['lastReadErrorType']is None and disk['beforeAvailableBytes']>=134217728 and disk['minimumAvailableBytesObserved']>=134217728 and disk['lastAvailableBytes']>=134217728
   result_passed=bool(held and run_error is None and inspection_error is None and zone_natural and cad_natural and container_empty)
  except BaseException as error:inspection_error=(inspection_error+'; 'if inspection_error else'')+type(error).__name__+': '+str(error)
  files=[row(p)for p in sorted([*out.iterdir(),*output.iterdir()])if p.is_file()and not p.is_symlink()]
  post=dict(scope='ROOT_SOURCE32_FRESH_OFFLINE_CAD_WITH70_AUTHENTIC_PRIOR_CLOSURES',phase='cad',sourceManifestSha256=RUNTIME_SHA,
   rootGuardProposalManifestSha256=source_sha,execution=cad_execution if isinstance(cad_execution,dict)else zone_execution,
   zonePinsExecution=zone_execution,cadExecution=cad_execution,actualClosedPriorScopes=prior,
   zonePinsOwnedGroupEmptyActuallyObserved=zone_empty,cadOwnedGroupEmptyActuallyObserved=cad_empty,zonePinsChildNatural0=zone_natural,cadChildNatural0=cad_natural,
   bothOwnedGroupsIndependentlyObservedEmpty=zone_empty and cad_empty,zoneBeforeCadSeriallyEnforced=bool(zone_natural and isinstance(cad_execution,dict)and type(cad_execution.get('pgid'))is int and cad_execution['pgid']>0 and zone_execution['pgid']!=cad_execution['pgid']and zone_execution['endedAt']<=cad_execution['startedAt']),
   ownedGroupEmptyActuallyObserved=bool(zone_empty and(cad_empty if isinstance(cad_execution,dict)else True)),
   ownedContainerName=container_name,ownedContainerActuallyEmpty=container_empty,containerResourceObservations=resource,
   resourceGateBlockedBeforeContainer=bool(isinstance(resource,dict)and len(resource.get('observations',[]))==1 and resource['observations'][0].get('phase')=='BEFORE_CONTAINER'and resource['observations'][0].get('actualVfsReserveSatisfiedAtObservation')is False),
   actualCadApplicationCompletionUnknown=bool(isinstance(cad_execution,dict)and not(isinstance(result,dict)and result.get('diagnosticCompleted')is True)),
   containerResourceObservationsBinding=row(resource_path)if resource_path.is_file()else None,
   diskFreeGuardPolicy=cad_policy['diskFreeGuard'],diskFreeGuardActuallyObserved=cad_execution.get('diskFreeGuard')if isinstance(cad_execution,dict)else None,vfsOverheadBufferBytes=201326592,
   sourceAndDependenciesHeld=held,dependenciesBefore=board_before,dependenciesAfter=board_after,solverDependenciesBefore=solver_before,solverDependenciesAfter=solver_after,
   runFailure=run_error,postverificationFailure=post_error,resultInspectionFailure=inspection_error,
   stageNaturallyCompleted=bool(held and zone_natural and cad_natural),resultPassed=result_passed,passed=result_passed,
   reportPath=str(report),reportSha256=sha(report)if report.is_file()else None,actualCoreSha256=proposal['actual67CoreRawPin']['sha256'],actualCoreControlsSha256=proposal['actual67CoreControlsPin']['sha256'],
   CoreCalls=0,nativeCalls=0,originalApiCalls=0,cliCalls=0,cadCalls=1 if isinstance(result,dict)and result.get('diagnosticCompleted')is True else(None if isinstance(cad_execution,dict)else 0),zonePinsChildInvocations=1 if isinstance(zone_execution,dict)else 0,
   Source32Accepted=False,hardwareAcceptanceCheckpointUnchanged=True,newRoutesAdopted=0,referenceQualified=False,electricalTimingPassed=False,all49Accepted=False,accepted49=False,fabricationReady=False,
   workspaceFreeBytesBefore=workspace_before,workspaceFreeBytesAfter=workspace_after,workspaceFreeBytesFloorHeld=workspace_floor_held,workspaceDataCopiesPerformed=0,
   gitMetadataHeld=post_error is None,outputFiles=files,toolSessionCollected=False)
  pp=out/'POSTAUDIT.json';write(pp,post);print(json.dumps({'passed':result_passed,'phase':'cad','postauditPath':str(pp),'postauditSha256':sha(pp),'execution':post['execution'],'zonePinsExecution':zone_execution,'ownedContainerActuallyEmpty':container_empty}))
  return 0 if result_passed else 2
