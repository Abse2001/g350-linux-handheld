// SOURCE ONLY. Strict22347 + exact204 ordinaryCA body merge preflight.
// Based on audited225 companion APIs; Root alone executes. All223 foundation
// objects/nonCA bodies and literal169 critical6 stay exact; only22CA bodies differ.
import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {pathToFileURL} from 'node:url'
type R=Record<string,any>
const LIB='/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib/'
const INPUT='/tmp/g350-current223-ca204-maximal_clear-planning.json',INPUT_SHA='ad252b05aa6a5fc47a208028b34e3194e6144566fcbb9334295622cae123a833'
const CURRENT='/tmp/g350-deterministic-manual47-root-20261016-run223/byte0-result.candidate.json',CURRENT_SHA='ddaa4efd8d20f16cefca89b9166e834a956113194beed6f0f13903e346e36ea0'
const DONOR='/tmp/g350-ca24-matching-root-20261016-run204/byte0-result.candidate.json',DONOR_SHA='454b1b02ca5fa4a8bdce8e4e752097090cc8a28d449360c075be65bc6d1be86f'
const SCREEN='/tmp/g350-current223-ca204-merge-pure-screen.json',SCREEN_SHA='264d62a858d2db2636f773a1f42b67a97a01042cc67cdd5978e9a04efb86fccb'
const MANIFEST='/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/SOURCE-manifest.json',MANIFEST_SHA='b9700a9a44c9be5f661fd38c37ca9ff6c2f012983e49a750fecea3c8d75e19e0'
const PARENT='/tmp/g350-manual-d5-two-refills-root-20261016-run215/byte0-result.candidate.json',PARENT_SHA='150b45fa398153a8e3fd1f6f8c52ed51d4dff981e538800b221e0a0e72a5da3d'
const ANCHOR='/tmp/g350-clock33-shorten-root-20261016-run169/byte0-result.candidate.json',ANCHOR_SHA='157b33c88108d5315ad3630ea4f0666ebfb5db0a00376d545299026f05939683'
const RAW='/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json',RAW_SHA='d2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607'
const QUAL='/tmp/g350-mixed-carrier-physical-four-vias-sourceonly.ts',QUAL_SHA='cdea6326a318b332ba98bb74bb1c8fd52c3b757bde34d75402558bd6dc86623f'
const L=['top','inner1','inner2','bottom'],N=Array.from({length:49},(_,i)=>'source_trace_'+i),C=[15,16,27,28,33,34].map(i=>'source_trace_'+i),W=.1016,VD=.4572,HD=.254
const req=(v:any,m:string)=>{if(!v)throw Error(m)},clone=<T>(v:T):T=>structuredClone(v),same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b),owner=(t:R)=>t.connection_name??t.source_trace_id,near=(a:R,b:R)=>Math.hypot(a.x-b.x,a.y-b.y)<1e-8,sha=(b:any)=>createHash('sha256').update(b).digest('hex'),roster=(a:string[],b:string[])=>a.length===b.length&&new Set(a).size===a.length&&a.every(n=>b.includes(n))
const args=new Map<string,string>();for(let i=2;i<process.argv.length;i+=2){const k=process.argv[i],v=process.argv[i+1];req(['--caller-intent','--input','--input-sha','--output','--budget-ms'].includes(k)&&v&&!args.has(k),'Invalid CLI '+k);args.set(k,v)}
req(args.get('--caller-intent')==='ROOT_AUTHORIZED_CURRENT223_CA204_MERGE47'&&['--input','--input-sha','--output'].every(k=>args.has(k)),'Root-only explicit planned input/hash/output required')
const input=path.resolve(args.get('--input')!),inputSha=args.get('--input-sha')!,out=path.resolve(args.get('--output')!),budget=Number(args.get('--budget-ms')??165000),started=performance.now()
req(inputSha===INPUT_SHA&&input===INPUT&&!fs.existsSync(out)&&!fs.existsSync(out.replace(/\.json$/,'')+'.candidate.json')&&input!==out&&Number.isFinite(budget)&&budget>=1000&&budget<=170000,'Exact planned merge input/hash, fresh output, bounded budget required')
const read=(p:string,h:string)=>{const b=fs.readFileSync(p);req(sha(b)===h,'Pinned public file changed '+p);return JSON.parse(b.toString())}
const manifest=read(MANIFEST,MANIFEST_SHA);req(manifest.solverSourceRoot===LIB.slice(0,-1)&&manifest.solverSourceFiles.length===120,'Exact Source120 solver manifest required')
for(const pin of manifest.solverSourceFiles){req(path.resolve(pin.path).startsWith(LIB)&&!fs.lstatSync(pin.path).isSymbolicLink(),'Exact actual solver Source file');const b=fs.readFileSync(pin.path);req(sha(b)===pin.sha256&&b.length===pin.bytes&&(fs.statSync(pin.path).mode&0o777)===pin.mode,'Solver Source bytes/mode changed '+pin.path)}
req(sha(fs.readFileSync(QUAL))===QUAL_SHA,'Reviewed independent physical qualifier')
const packet=read(input,inputSha),current=read(CURRENT,CURRENT_SHA),donor=read(DONOR,DONOR_SHA),screen=read(SCREEN,SCREEN_SHA)
const parent=read(PARENT,PARENT_SHA),anchor=read(ANCHOR,ANCHOR_SHA),raw:R[]=read(RAW,RAW_SHA)
const base:R=clone(packet.full49FanoutInput),held:R[]=clone(packet.heldCarrierTraces),ordinary:R[]=clone(packet.ordinaryCarrierTraces),all:R[]=clone(packet.carrierTraces)
const ca=base.buses.find((b:R)=>b.busId==='DDR_COMMAND_CLOCK'),caOrdinary:string[]=ca.connectionNames.filter((n:string)=>!C.includes(n))
const selected:string[]=screen.selectedMaximalCompatibleNewOwners
req(caOrdinary.length===24&&roster(selected,current.carrierTraces.filter((t:R)=>caOrdinary.includes(owner(t))&&!same(t,donor.carrierTraces.find((z:R)=>owner(z)===owner(t)))).map(owner)),'Exact22 changed donor CA objects and full24 ordinaryCA roster')
req(selected.length===22&&screen.full24DonorMergeClearInCrossScenePrimitiveModel===true&&screen.newNewCAConflicts.length===0&&Object.values(screen.hardForeignConflicts).every((v:any)=>v.length===0),'Exact clear pure22-body cross-scene merge result')
req(screen.inputBindings.current223.sha256===CURRENT_SHA&&screen.inputBindings.donor204.sha256===DONOR_SHA&&screen.selectedPlanningCandidate.sha256===INPUT_SHA&&screen.selectedPlanningCandidate.caMinPassCount===13,'Exact pure-screen source bindings/13 CA minimum observations')
const expectedAll=current.carrierTraces.map((t:R)=>caOrdinary.includes(owner(t))?clone(donor.carrierTraces.find((z:R)=>owner(z)===owner(t))):clone(t))
const expectedInverse=selected.map(sid=>({owner:sid,before:current.carrierTraces.find((t:R)=>owner(t)===sid),after:donor.carrierTraces.find((t:R)=>owner(t)===sid)}))
req(same(base,current.full49FanoutInput)&&same(held,current.heldCarrierTraces)&&same(all,expectedAll)&&same(ordinary,current.ordinaryCarrierTraces.map((t:R)=>expectedAll.find((z:R)=>owner(z)===owner(t)))),'All223 foundation/held/nonCA objects literal; every ordinaryCA equals exact204 object')
req(packet.ca204Merge?.current223Sha256===CURRENT_SHA&&packet.ca204Merge?.donor204Sha256===DONOR_SHA&&same(packet.ca204Merge.selectedOwners,selected)&&same(packet.ca204Merge.inverse,expectedInverse)&&packet.allSavedCarriersCurrentSceneQualified===false,'Exact body-only before/after inverse and unqualified planning boundary')
req(current.allSavedCarriersCurrentSceneQualified===true&&donor.allSavedCarriersCurrentSceneQualified===true,'Both separate parent qualification provenance retained without inheritance')
for(const sid of caOrdinary){req(same(base.connections.find((c:R)=>c.name===sid),donor.full49FanoutInput.connections.find((c:R)=>c.name===sid))&&same(base.traces.filter((t:R)=>owner(t)===sid),donor.full49FanoutInput.traces.filter((t:R)=>owner(t)===sid)),'CA handoffs and owned numeric approaches unchanged');req(same(current.carrierTraces.find((t:R)=>owner(t)===sid).route.filter((p:R)=>p.route_type==='via'),donor.carrierTraces.find((t:R)=>owner(t)===sid).route.filter((p:R)=>p.route_type==='via')),'Every physical CA body via object unchanged')}
req(base&&roster(base.connections.map((c:R)=>c.name),N)&&base.traces.length===263&&base.obstacles.length===1298&&held.length===6&&roster(held.map(owner),C)&&ordinary.length>=39&&ordinary.length<=43&&same(all,[...held,...ordinary])&&new Set(all.map(owner)).size===all.length&&all.every(t=>N.includes(owner(t))),'Exact49 requests /263 foundation /1298 obstacles /6 critical and coherent45..49 current owners')
req(all.length===47&&ordinary.length===41&&roster(N.filter(n=>!all.some(t=>owner(t)===n)),['source_trace_26','source_trace_30']),'Exact merged47 and pending26/30 profile')
req(held.every(t=>same(t,anchor.heldCarrierTraces.find((a:R)=>owner(a)===owner(t))))&&same(held,parent.heldCarrierTraces),'Literal actual169 repaired critical6 required; this explicit215 profile cannot silently accept RAM-cycle or another clock')
const omit=(v:R,ks:string[])=>Object.fromEntries(Object.entries(v).filter(([k])=>!ks.includes(k)))
req(same(omit(base,['traces','connections']),omit(parent.full49FanoutInput,['traces','connections']))&&same(base.traces.slice(0,165),parent.full49FanoutInput.traces.slice(0,165)),'All165 references/all1298 obstacles/original rules/board literal actual215; no reference-placement exception in this profile')
for(const c of base.connections){const before=parent.full49FanoutInput.connections.find((q:R)=>q.name===c.name);req(same(omit(c,['pointsToConnect']),omit(before,['pointsToConnect']))&&c.pointsToConnect.length===2,'Original connection ownership/dimensions unchanged');if(C.includes(c.name))req(same(c,before)&&same(base.traces.filter((t:R)=>owner(t)===c.name),parent.full49FanoutInput.traces.filter((t:R)=>owner(t)===c.name)),'Critical endpoints/fanouts literal215')}
req(base.layerCount===4&&same(base.allowedLayers,L)&&base.allowBlindAndBuriedVias===false&&base.minTraceWidth===W&&base.minViaDiameter===VD&&base.minViaHoleDiameter===HD&&base.minTraceToPadEdgeClearance===W&&base.minViaEdgeToPadEdgeClearance===W,'Actual original four-layer fullspan physical controls')
req(base.differentialPairs.length===3&&base.differentialPairs.every((p:R)=>p.lengthTolerance===.127&&p.traceGap===.12)&&base.buses.find((b:R)=>b.busId==='DDR_BYTE0').maxLength===11.8&&base.buses.find((b:R)=>b.busId==='DDR_BYTE1').maxLength===14.2&&base.buses.find((b:R)=>b.busId==='DDR_COMMAND_CLOCK').minLength===20.95&&base.buses.find((b:R)=>b.busId==='DDR_COMMAND_CLOCK').maxLength===22.29,'All literal original limits retained')
const fingerprint=JSON.stringify({base,held,ordinary,all}),report:R={scope:'CURRENT22347_WITH_EXACT204_CA_BODIES_FRESH_PHYSICAL_AND_BOTH_CRITICAL_VIEWS',inputPath:input,inputSha256:inputSha,current223Sha256:CURRENT_SHA,donor204Sha256:DONOR_SHA,pureScreenSha256:SCREEN_SHA,parent215Sha256:PARENT_SHA,literalHeld169Sha256:ANCHOR_SHA,source120ManifestSha256:MANIFEST_SHA,qualifierSha256:QUAL_SHA,currentConnectedOwnerCount:all.length,currentMissingOwners:N.filter(n=>!all.some(t=>owner(t)===n)),selectedCABodyOwners:selected,bodyOnlyInverse:clone(expectedInverse),fullScenePhysicalReports:[],joinedNativeGeometryReports:[],criticalValidationViews:[],literalOriginalRules:{buses:clone(base.buses),differentialPairs:clone(base.differentialPairs)},criticalProfileQualified:false,currentScenePhysicalAndCriticalAssertionsFreshlyQualified:false,all49Accepted:false,fullBoardPassed:false,matched:false,timingPassed:false,electricalTimingQualified:false,nativeExecuted:false,cadExecuted:false,fabricationReady:false}
fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,'',{flag:'wx'});const save=()=>{report.elapsedMs=performance.now()-started;fs.writeFileSync(out+'.tmp',JSON.stringify(report,null,2)+'\n');fs.renameSync(out+'.tmp',out)};save()
try{
 const imp=(n:string)=>import(pathToFileURL(LIB+n+'.ts').href)
 const api=await imp('bus-lanes-solver'),v=await imp('vector-scene'),g=await imp('geometry'),len=await imp('route-lengths'),sh=await imp('shared-pair-spacing'),co=await imp('pair-coupling'),ex=await imp('exterior-pair-spacing'),ng=await imp('native-signal-geometry'),lt=await imp('length-tuning'),js=await imp('join-signal-escapes'),rt=await imp('retarget-generated-escape'),bo=await imp('board-outline'),q=await import(pathToFileURL(QUAL).href)
 const H={VectorScene:v.VectorScene,fixedCopper:v.fixedCopper,clearanceToCopper:v.clearanceToCopper,pointSegmentDistanceToPoints:g.pointSegmentDistanceToPoints,segmentDistance:g.segmentDistance,nativeSignalGeometryIsValid:ng.nativeSignalGeometryIsValid,tuningPathIsSelfClear:lt.tuningPathIsSelfClear,boardOutlineViolations:bo.boardOutlineViolations,BusLanesSolver:api.BusLanesSolver}
 const holes=(input:R)=>{const h:R[]=[];for(const t of input.traces)for(const p of t.route)if(p.route_type==='via')h.push({x:p.x,y:p.y,diameter:p.via_hole_diameter,owner:owner(t),physicalId:t.pcb_trace_id,layers:p.layers});for(const o of input.obstacles){const m=o.circuitJsonMetadata??{},id=m.pcb_via_id??m.pcb_hole_id??m.pcb_plated_hole_id;if(!id)continue;const r=raw.find(r=>(r.type==='pcb_via'&&r.pcb_via_id===id)||(r.type==='pcb_hole'&&r.pcb_hole_id===id)||(r.type==='pcb_plated_hole'&&r.pcb_plated_hole_id===id));req(r&&near(r,o.center),'Actual unchanged fixed drill '+id);const diameter=r.hole_diameter??Math.hypot(r.hole_width,r.hole_height);req(Number.isFinite(diameter)&&diameter>0,'Real drill dimensions');h.push({...o.center,diameter,physicalId:id,layers:o.layers,owners:o.connectedTo})}return h}
 const joined=(t:R)=>{const branches=base.traces.filter((f:R)=>owner(f)===owner(t));req(branches.length===2,'Exactly two genuine owned branches');const escapes=branches.map((f:R)=>{const e=f.route.at(-1),layer=near(e,t.route[0])?t.route[0].layer:near(e,t.route.at(-1))?t.route.at(-1).layer:undefined;req(layer,'Actual endpoint matches owned branch');return rt.retargetGeneratedEscape(clone(f),layer)}),j=js.joinSignalEscapes(t,escapes);req([j.route[0],j.route.at(-1)].every((p:R)=>p.route_type==='wire'&&p.layer==='top'&&base.obstacles.some((o:R)=>near(p,o.center)&&o.circuitJsonMetadata?.pcb_port_id&&o.connectedTo.includes(owner(t)))),'Authentic numeric Top pads at both critical ends');return j}
 const nativeViaLandReport=(carrier:R,input:R)=>{const sites:R[]=[];for(const t of input.traces)if(owner(t)!==owner(carrier))for(const p of t.route)if(p.route_type==='via')sites.push({x:p.x,y:p.y,diameter:p.via_diameter,physicalId:t.pcb_trace_id});for(const o of input.obstacles)if(o.circuitJsonMetadata?.pcb_via_id&&!o.connectedTo.includes(owner(carrier)))sites.push({...o.center,diameter:Math.max(o.width,o.height),physicalId:o.circuitJsonMetadata.pcb_via_id});const rows=carrier.route.filter((p:R)=>p.route_type==='via').map((p:R)=>({via:{x:p.x,y:p.y},violations:sites.filter(s=>Math.hypot(p.x-s.x,p.y-s.y)<p.via_diameter/2+s.diameter/2+.15-1e-8)}));return{minimumForeignViaLandGapMm:.15,passed:rows.every((r:R)=>!r.violations.length),reports:rows}}
 const numeric:R[]=[]
 for(const t of all){
  req(performance.now()-started<budget,'Full47 physical wall budget')
  const input={...clone(base),traces:[...base.traces,...all.filter(z=>owner(z)!==owner(t))]}
  const qualification=q.qualifyMixedCarrier({...input,extraPhysicalHoles:holes(input)},base.connections.find((c:R)=>c.name===owner(t)),t,H)
  const nativeLand=nativeViaLandReport(t,input),joinedTrace=joined(t),native=ng.nativeSignalGeometryIsValid(joinedTrace)
  numeric.push(joinedTrace)
  report.fullScenePhysicalReports.push({owner:owner(t),...qualification,nativeViaLandSupplement:nativeLand,passed:qualification.passed&&nativeLand.passed})
  report.joinedNativeGeometryReports.push({owner:owner(t),passed:native});save()
 }
 const criticalNames=new Set(held.map(owner)),criticalBuses=base.buses.map((b:R)=>({...clone(b),connectionNames:b.connectionNames.filter((n:string)=>criticalNames.has(n))})).filter((b:R)=>b.connectionNames.length),criticalBase={...clone(base),traces:[...base.traces,...ordinary],connections:base.connections.filter((c:R)=>criticalNames.has(c.name)),buses:criticalBuses}
 for(const view of [{name:'DQS1_LOWER_U_SHARED_VIEW',sections:{source_trace_27:[24,28],source_trace_28:[30,34]}},{name:'DQS1_EARLY_MEANDER_SHARED_VIEW',sections:{source_trace_27:[5,12],source_trace_28:[3,10]}}]){
  req(performance.now()-started<budget,'Critical pair API wall budget');const viewHeld=held.map(t=>view.sections[owner(t)]?{...clone(t),coupledSection:clone(view.sections[owner(t)])}:clone(t)),input={...clone(criticalBase),differentialPairs:clone(base.differentialPairs)},reports={bus:len.busLengthReports(input,viewHeld),pair:len.pairLengthReports(input,viewHeld),shared:sh.sharedPairSpacingReports(input,viewHeld),coupling:co.pairCouplingReports(input,viewHeld),exterior:ex.exteriorPairSpacingReports(input,viewHeld)},validator=api.BusLanesSolver.forValidation(input,viewHeld,{smoothTuning:true,denseSearch:true,maxSearchIterations:2000000});for(let k=0;k<8&&!validator.failed&&!validator.solved;k++)validator.step()
  const passed=validator.solved&&Object.values(reports).every((rs:any)=>rs.length===3&&rs.every((r:R)=>r.matched&&r.aboveMinimumLength!==false&&r.withinLengthLimit!==false));report.criticalValidationViews.push({scope:view.name,actualDQS1SharedSections:clone(view.sections),samePhysicalCriticalCopper:true,differentialPairs:clone(base.differentialPairs),reports,c31:{solved:validator.solved,error:validator.error,failureCode:validator.failureCode},passed});save()
 }
 const planar=(t:R)=>t.route.slice(1).reduce((sum:number,p:R,i:number)=>{const a=t.route[i];return sum+(a.route_type==='wire'&&p.route_type==='wire'&&a.layer===p.layer?Math.hypot(a.x-p.x,a.y-p.y):0)},0)
 const whole=new Map(all.map(t=>[owner(t),len.fixedRouteLength(base,owner(t))+planar(t)]))
 report.originalBusReports=len.busLengthReports(base,all)
 report.originalPairReports=len.pairLengthReports(base,all)
 report.originalBusConstraintObservations=base.buses.map((rule:R)=>{
  const present=rule.connectionNames.filter((sid:string)=>whole.has(sid)).map((sid:string)=>({owner:sid,wholePlanarLengthMm:whole.get(sid)!}))
  const missingOwners=rule.connectionNames.filter((sid:string)=>!whole.has(sid)),values=present.map((r:R)=>r.wholePlanarLengthMm)
  const skew=values.length>1?Math.max(...values)-Math.min(...values):null,violations:R[]=[]
  for(const row of present){
   if(rule.minLength!==undefined&&row.wholePlanarLengthMm<rule.minLength-1e-7)violations.push({kind:'ORIGINAL_MIN_LENGTH',owner:row.owner,actualMm:row.wholePlanarLengthMm,requiredMm:rule.minLength})
   if(rule.maxLength!==undefined&&row.wholePlanarLengthMm>rule.maxLength+1e-7)violations.push({kind:'ORIGINAL_MAX_LENGTH',owner:row.owner,actualMm:row.wholePlanarLengthMm,requiredMm:rule.maxLength})
  }
  if(skew!==null&&rule.maxLengthSkew!==undefined&&skew>rule.maxLengthSkew+1e-7)violations.push({kind:'ORIGINAL_MAX_LENGTH_SKEW',actualMm:skew,requiredMm:rule.maxLengthSkew})
  return{originalRule:clone(rule),present,missingOwners,allMembersPresent:!missingOwners.length,observedSkewMm:skew,minimumPassingPresentOwners:rule.minLength===undefined?null:present.filter((r:R)=>r.wholePlanarLengthMm>=rule.minLength-1e-7).map((r:R)=>r.owner),violations,observedPlanarConstraintsPassed:!missingOwners.length&&!violations.length,electricalTimingQualified:false}
 })
 report.originalPairConstraintObservations=base.differentialPairs.map((rule:R)=>{
  const values=rule.connectionNames.map((sid:string)=>({owner:sid,wholePlanarLengthMm:whole.get(sid)??null}))
  const missingOwners=values.filter((r:R)=>r.wholePlanarLengthMm===null).map((r:R)=>r.owner)
  const skew=missingOwners.length?null:Math.abs(values[0].wholePlanarLengthMm-values[1].wholePlanarLengthMm)
  return{originalRule:clone(rule),values,missingOwners,observedLengthSkewMm:skew,lengthToleranceSatisfied:skew===null?null:skew<=rule.lengthTolerance+1e-7,electricalTimingQualified:false}
 })
 report.cohortWindows=base.buses.map((rule:R)=>{
  const heldOwners=rule.connectionNames.filter((sid:string)=>C.includes(sid))
  const heldValues=heldOwners.map((sid:string)=>whole.get(sid)!)
  req(heldValues.every(Number.isFinite),'Finite actual held-pair whole lengths')
  let lo=rule.minLength??null,hi=rule.maxLength??null
  if(heldValues.length&&rule.maxLengthSkew!==undefined){
   req(Number.isFinite(rule.maxLengthSkew)&&rule.maxLengthSkew>=0&&Math.max(...heldValues)-Math.min(...heldValues)<=rule.maxLengthSkew+1e-7,'Literal held pair must fit original cohort skew')
   const pairLo=Math.max(...heldValues)-rule.maxLengthSkew,pairHi=Math.min(...heldValues)+rule.maxLengthSkew
   lo=lo===null?pairLo:Math.max(lo,pairLo)
   hi=hi===null?pairHi:Math.min(hi,pairHi)
  }
  req((lo===null||Number.isFinite(lo))&&(hi===null||Number.isFinite(hi))&&(lo===null||hi===null||lo<=hi+1e-7),'Finite nonempty actual held-cohort search intersection')
  return{busId:rule.busId,originalRule:clone(rule),heldOwners,heldWholePlanarMm:Object.fromEntries(heldOwners.map((sid:string)=>[sid,whole.get(sid)])),minLengthMm:lo,maxLengthMm:hi,derivedSearchIntersectionOnly:true}
 })
 report.ordinaryMinimumLengthObservations=ordinary.map(t=>{
  const sid=owner(t),rule=base.buses.find((b:R)=>b.connectionNames.includes(sid)),length=whole.get(sid)!
  const window=report.cohortWindows.find((w:R)=>w.busId===rule.busId)
  req(Number.isFinite(length)&&window,'Actual finite whole length and exactly one original cohort')
  return{owner:sid,wholeLengthMm:length,originalBusRule:clone(rule),derivedWholeWindowMm:[window.minLengthMm,window.maxLengthMm],minimumBoundPresent:window.minLengthMm!==null,maximumBoundPresent:window.maxLengthMm!==null,minimumMatched:window.minLengthMm===null?null:length>=window.minLengthMm-1e-7,maximumSatisfied:window.maxLengthMm===null?null:length<=window.maxLengthMm+1e-7,belowMinimumNeedsLengthTuning:window.minLengthMm!==null&&length<window.minLengthMm-1e-7,matched:false,timingPassed:false}
 })
 report.derivedMaximumViolations=all.flatMap(t=>{
  const sid=owner(t),rule=base.buses.find((b:R)=>b.connectionNames.includes(sid)),window=report.cohortWindows.find((w:R)=>w.busId===rule.busId),length=whole.get(sid)!
  req(Number.isFinite(length)&&window,'Finite whole lengths for every saved owner')
  return window.maxLengthMm!==null&&length>window.maxLengthMm+1e-7?[{owner:sid,busId:rule.busId,wholeLengthMm:length,derivedMaximumMm:window.maxLengthMm,originalMaximumMm:rule.maxLength??null}]:[]
 })
 report.allDerivedMaximumBoundsSatisfied=report.derivedMaximumViolations.length===0
 report.minimumLengthFailuresRetained=report.ordinaryMinimumLengthObservations.filter((r:R)=>r.minimumMatched===false).map((r:R)=>r.owner)
 const caObservation=report.originalBusConstraintObservations.find((r:R)=>r.originalRule.busId==='DDR_COMMAND_CLOCK')
 report.caMinimumPassingOwners=caObservation.minimumPassingPresentOwners
 report.caMinimumPassingCount=report.caMinimumPassingOwners.length
 req(caObservation.present.length===26&&report.caMinimumPassingCount===13,'Exact retained13-of26 CA minimum observations after merge')
 report.criticalProfileQualified=report.criticalValidationViews.length===2&&report.criticalValidationViews.every((r:R)=>r.passed)
 report.currentScenePhysicalAndCriticalAssertionsFreshlyQualified=report.fullScenePhysicalReports.length===47&&report.fullScenePhysicalReports.every((r:R)=>r.passed)&&report.joinedNativeGeometryReports.length===47&&report.joinedNativeGeometryReports.every((r:R)=>r.passed)&&report.criticalProfileQualified
 req(JSON.stringify({base,held,ordinary,all})===fingerprint,'Current input geometry mutated')
 report.inputFilesUnchanged=[[input,INPUT_SHA],[CURRENT,CURRENT_SHA],[DONOR,DONOR_SHA],[SCREEN,SCREEN_SHA],[PARENT,PARENT_SHA],[ANCHOR,ANCHOR_SHA],[RAW,RAW_SHA]].every(([p,h])=>sha(fs.readFileSync(p))===h)
 req(report.inputFilesUnchanged,'Pinned public inputs changed during qualification')
 req(report.allDerivedMaximumBoundsSatisfied,'Every finite actual held-pair-derived hard maximum must hold before saving any qualified candidate; under-minimum owners remain UNMATCHED')
 if(report.currentScenePhysicalAndCriticalAssertionsFreshlyQualified){
  const candidate={...clone(packet),scope:'CURRENT22347_WITH_CA204_TIMING_PROGRESS_FRESH_PHYSICAL_AND_CRITICAL_PENDING_SOURCE',planningOnly:false,freshSource:false,freshSourceCoreDerived:false,carrierTraces:all,ordinaryCarrierTraces:ordinary,heldCarrierTraces:held,full49FanoutInput:base,joinedNumericPadTraces:numeric,joinedNumericPadTracesRequireFreshRebuild:false,finalScenePhysicalReports:report.fullScenePhysicalReports,physicalRunReports:report.fullScenePhysicalReports.flatMap((r:R)=>(r.physicalRunReports??[]).map((z:R)=>({owner:r.owner,...z}))),newViaReports:report.fullScenePhysicalReports.flatMap((r:R)=>(r.newViaReports??[]).map((z:R)=>({owner:r.owner,...z}))),criticalValidationViews:report.criticalValidationViews,joinedNativeGeometryReports:report.joinedNativeGeometryReports,allSavedCarriersCurrentSceneQualified:true,originalRulesPreservedLiteral:true,originalBusConstraintObservations:report.originalBusConstraintObservations,originalPairConstraintObservations:report.originalPairConstraintObservations,ordinaryMinimumLengthObservations:report.ordinaryMinimumLengthObservations,minimumLengthFailuresRetained:report.minimumLengthFailuresRetained,minimumMatched:false,caMinimumPassingOwners:report.caMinimumPassingOwners,caMinimumPassingCount:report.caMinimumPassingCount,current223CA204MergeProfile:{kind:'CURRENT22347_WITH_EXACT204_CA_BODIES_FRESH_PHYSICAL_AND_CRITICAL',current223Sha256:CURRENT_SHA,donor204Sha256:DONOR_SHA,pureScreenSha256:SCREEN_SHA,planningPacketSha256:INPUT_SHA,all223FoundationObjectsUnchanged:true,all223NonCAAndCriticalBodiesUnchanged:true,selectedCABodyOwners:selected,bodyOnlyInverse:clone(expectedInverse),all47CurrentScenePhysicalQualified:true,allCriticalAssertionsFreshlyQualified:true,caMinimumPassingCount:report.caMinimumPassingCount,sourceCoreFresh:false},all49Connected:false,all49Accepted:false,wholeMixedC31Supported:false,matched:false,timingPassed:false,electricalTimingQualified:false,nativeExecuted:false,cadExecuted:false,fabricationReady:false}
  Object.assign(candidate,{derivedCohortWindows:clone(report.cohortWindows),allDerivedMaximumBoundsSatisfied:true,derivedMaximumViolations:[]})
  const file=out.replace(/\.json$/,'')+'.candidate.json'
  fs.writeFileSync(file,JSON.stringify(candidate,null,2)+'\n',{flag:'wx'})
  report.qualifiedCandidate={path:file,sha256:sha(fs.readFileSync(file)),connectedOwners:47,pendingOwners:2,caMinimumPassingCount:report.caMinimumPassingCount}
 }
 report.terminalOutcome=report.currentScenePhysicalAndCriticalAssertionsFreshlyQualified?'FRESH_MERGED47_PHYSICAL_AND_BOTH_CRITICAL_VIEWS_PASS_CA13_MIN_RETAINED_SOURCE_NATIVE_PENDING':'MERGED47_PHYSICAL_OR_CRITICAL_CHECK_FAILED_NO_ACCEPTANCE'
 if(!report.currentScenePhysicalAndCriticalAssertionsFreshlyQualified)process.exitCode=2
}catch(e:any){report.error=e.stack??String(e);report.terminalOutcome='EXCEPTION_NO_ACCEPTANCE';process.exitCode=2}finally{save()}
console.log(JSON.stringify({out,terminalOutcome:report.terminalOutcome,physicalAndCriticalPassed:report.currentScenePhysicalAndCriticalAssertionsFreshlyQualified,qualifiedCandidate:report.qualifiedCandidate??null,all49Accepted:false}))
