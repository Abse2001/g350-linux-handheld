import { expect, test } from "bun:test"
import {
  hasCompleteNaturalPair,
  installFirstThreeGate,
  type Job,
} from "./prefix-control"

const names = [
  ["a", "b"],
  ["c", "d"],
  ["e", "f"],
]
const args = (index: number) => [
  {},
  { connectionNames: names[index] },
  [],
  {
    variant: 0,
    allowProvisionalPairTuning: false,
    preferPackageOnlyTuning: true,
    copper: [],
    penalty: 0,
  },
]

test("forwards original receiver, arguments and IteratorResult; blocks fourth before factory", () => {
  let calls = 0
  const results: IteratorResult<unknown>[] = []
  const module: Record<string, any> = {
    routeCoupledPair(this: unknown, ...values: any[]) {
      expect(this).toBe(module)
      expect(values).toEqual(args(calls++))
      let count = 0
      const work: any = {
        next(this: unknown, value: unknown) {
          expect(this).toBe(work)
          expect(value).toBe("forward")
          const result = {
            done: count++ > 0,
            value: count > 1 ? ["actual"] : undefined,
          }
          results.push(result)
          return result
        },
        return() {
          throw Error("unexpected return")
        },
        throw() {
          throw Error("unexpected throw")
        },
        [Symbol.iterator]() {
          return this
        },
      }
      return work
    },
  }
  const original = module.routeCoupledPair
  const captured: unknown[] = []
  const gate = installFirstThreeGate(module, names, (job: Job) =>
    captured.push(JSON.parse(JSON.stringify(job))),
  )
  try {
    for (let index = 0; index < 3; index++) {
      const work = module.routeCoupledPair(...args(index))
      expect(work[Symbol.iterator]()).toBe(work)
      expect(work.next("forward")).toBe(results.at(-1))
      expect(work.next("forward")).toBe(results.at(-1))
    }
    expect(() => module.routeCoupledPair(...args(0))).toThrow(gate.boundary)
    expect(calls).toBe(3)
    expect(gate.originalFactories).toBe(3)
    expect(gate.factoryAttempts).toBe(4)
    expect(captured).toHaveLength(3)
  } finally {
    gate.restore()
  }
  expect(module.routeCoupledPair).toBe(original)
})

test("capture failure is nonthrowing and original return/throw results survive", () => {
  const returned = { done: true, value: "closed" }
  const thrown = { done: true, value: "caught" }
  const marker = Error("same original exception")
  const work: any = {
    next() {
      throw marker
    },
    return(value: unknown) {
      expect(value).toBe("close")
      return returned
    },
    throw(value: unknown) {
      expect(value).toBe(marker)
      return thrown
    },
    [Symbol.iterator]() {
      return this
    },
  }
  const module = { routeCoupledPair: (..._args: any[]) => work }
  const gate = installFirstThreeGate(module, names, () => {
    throw Error("writer failed")
  })
  try {
    const wrapped = module.routeCoupledPair(...args(0))
    expect(() => wrapped.next()).toThrow(marker)
    expect(wrapped.return("close")).toBe(returned)
    expect(wrapped.throw(marker)).toBe(thrown)
    expect(gate.errors).toEqual(["writer failed"])
    expect(() => module.routeCoupledPair(...args(1))).not.toThrow()
    expect(() => module.routeCoupledPair(...args(2))).not.toThrow()
    expect(() => module.routeCoupledPair(...args(0))).toThrow(
      "before first three terminal",
    )
  } finally {
    gate.restore()
  }
})

test("rejects changed first-family policy before original factory", () => {
  let calls = 0
  const module = {
    routeCoupledPair: (..._args: any[]) => {
      calls++
      return null
    },
  }
  const gate = installFirstThreeGate(module, names, () => {})
  try {
    const changed = args(0)
    ;(changed[3] as any).variant = 2
    expect(() => module.routeCoupledPair(...changed)).toThrow(
      "arguments differ",
    )
    expect(calls).toBe(0)
  } finally {
    gate.restore()
  }
})

test("physical collision qualification excludes capped/null/incomplete return bodies", () => {
  const complete = {
    terminalMethod: "next",
    output: { projectionComplete: true, count: 2 },
    result: ["a", "b"].map((connection_name) => ({
      connection_name,
      route: [
        { x: 0, y: 0 },
        { x: 1, y: 1 },
      ],
    })),
  }
  expect(hasCompleteNaturalPair(complete)).toBe(true)
  expect(
    hasCompleteNaturalPair({ ...complete, terminalMethod: "return" }),
  ).toBe(false)
  expect(hasCompleteNaturalPair({ ...complete, result: null })).toBe(false)
  expect(
    hasCompleteNaturalPair({
      ...complete,
      output: { projectionComplete: false, count: 2 },
    }),
  ).toBe(false)
  expect(
    hasCompleteNaturalPair({
      ...complete,
      result: [{ connection_name: "a", route: [] }],
    }),
  ).toBe(false)
})
