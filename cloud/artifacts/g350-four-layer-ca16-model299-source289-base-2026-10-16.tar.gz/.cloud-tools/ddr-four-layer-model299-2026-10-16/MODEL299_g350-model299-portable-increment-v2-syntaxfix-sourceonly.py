#!/usr/bin/env python3
"""SOURCE ONLY. Root-run small MODEL299 increment; never runs SDK/native/CAD.

Build requires the already published exact Source289 archive/manifest. Verify
uses the unchanged generic restorer and no-op workspace helper only after every
existing model/base target and dependency link is authenticated. Source289 stays
the latest editable Source; MODEL299 is a separately labelled model milestone.
"""
import argparse,datetime,gzip,hashlib,json,os,re,shutil,stat,subprocess,sys,tarfile,tempfile
from pathlib import Path,PurePosixPath
BOARD=Path('/workspace/g350-linux-handheld')
BASE=Path('/tmp/g350-source289-post274-checkpoint-20261016')
BASE_REL='.cloud-tools/ddr-four-layer-post274-2026-10-16'
SAVED=Path('/tmp/g350-model299-portable-increment-20261016')
SAVED_REL='.cloud-tools/ddr-four-layer-model299-2026-10-16'
STEM='g350-four-layer-ca16-model299-source289-base-2026-10-16'
BASE_STEM='g350-four-layer-both-bytes-ca15-connected49-source289-2026-10-16'
MODEL_SHA='8abef05761375014f8a310f9cfcab92d7a5b7da978598fe4a49b1c118658d34d'
BASE_SHA='adf4821e147029e694dffe97f5894fe060e9607d9510867e20a9e9b7f6fd621e'
BASE_PINS={'PROGRESS.json':'a5dac7b49d9d90ca487d98dd8392c17b9a92e7fc4a071aa007fa7b8f806cd8ff','README.md':'44dad1146d345d6d6238dede42adc5d13b6488f0f4c235b4727dbdff32c7a0b9','WORKSPACE_HASH_INDEX.json':'b4d32ff34a898bbf8a3144f5880f3d017d3f424af552c988282457057384de9b','WORKSPACE_RESTORE_MANIFEST.json':'549aa8fe04733861fccc4feaa8956bf33e8fdd81a37e5a80546b5d25414dbec4'}
RESTORER=BOARD/'scripts/restore-g350-routing-evidence.py'
RESTORER_SHA='148bad0fc4132ece5f78f18b05e4bc71d79019312343eda954ed7ca91874a643'
HELPER=BOARD/'scripts/restore-g350-four-layer-routing-workspace.py'
HELPER_SHA='6c5d321a256eadf58697f0f565b5bffa4a55491fce39ed0db7e7675604b6f3cc'
ROWS=[
 {
  "restorePath": "/tmp/g350-source24-TI3W-foreign34W-matched49-finite1g-root-20261016-run299/byte0-result.candidate.json",
  "bytes": 12938321,
  "sha256": "8abef05761375014f8a310f9cfcab92d7a5b7da978598fe4a49b1c118658d34d",
  "mode": 384
 },
 {
  "restorePath": "/tmp/g350-source24-TI3W-foreign34W-matched49-finite1g-root-20261016-run299/byte0-result.json",
  "bytes": 3278231,
  "sha256": "acd3b0d98a9fad735160c12c2498b557d79f0049efb386795a7b5324b15b9445",
  "mode": 384
 },
 {
  "restorePath": "/tmp/g350-source24-TI3W-foreign34W-matched49-finite1g-root-20261016-run299/COLLECTED.json",
  "bytes": 2188,
  "sha256": "a171be544f73e6c70f525b4ae32202fb24841a387ac5c8df9dfaed56de1b36e5",
  "mode": 384
 },
 {
  "restorePath": "/tmp/g350-source24-TI3W-foreign34W-matched49-finite1g-root-20261016-run299/owned/execution.json",
  "bytes": 1842,
  "sha256": "b4e6c59723f2ca8c5c39bc90c29a17f1d62d9c2abb7d41225910536e2919dc31",
  "mode": 384
 },
 {
  "restorePath": "/tmp/g350-source24-TI3W-foreign34W-matched49-finite1g-root-20261016-run299/owned/child.log",
  "bytes": 469,
  "sha256": "d1d4f8ae45c3a8e23b556366f2e4bfac16be17d2ca5771d43644fb3443435072",
  "mode": 384
 },
 {
  "restorePath": "/tmp/g350-source24-TI3W-foreign34W-matched49-finite1g-root-20261016-run299/owned/memory.jsonl",
  "bytes": 218778,
  "sha256": "7d81f00478266682c27ac2f4bb09054b589de31d34e11d07f09b7ebccaed82f2",
  "mode": 384
 },
 {
  "restorePath": "/tmp/g350-actual286-only24-Bottom-TI3W-bank-foreign-DDR-spacing-physical49-v4-sourceonly.ts",
  "bytes": 58088,
  "sha256": "54f732236a6c19a5605125eae5c883cec4324efbf60c237ede4a40ff223a40ff",
  "mode": 384
 },
 {
  "restorePath": "/tmp/g350-actual286-source24-TI3W-bank-foreign-spacing-v4-worker-proof.json",
  "bytes": 59821,
  "sha256": "391332a7f7756d461102a6903f1599d72c5d4b22057bc4104a065e2c1325d61e",
  "mode": 384
 },
 {
  "restorePath": "/tmp/g350-actual286-source24-TI3W-bank-foreign-spacing-v4b-report.json",
  "bytes": 67285,
  "sha256": "27ad67fcf7f0b4fa2680aa083587ba329bccbf23e6784a43b0e8d117588f8fa9",
  "mode": 384
 },
 {
  "restorePath": "/tmp/g350-actual286-source24-TI3W-foreign-spacing-v4-independent-peer-report.json",
  "bytes": 5066,
  "sha256": "9de459cb75543ac9d267e1b3264a8c1907c393e6e43cd84c24a8f48b52080773",
  "mode": 384
 },
 {
  "restorePath": "/tmp/g350-actual286-source24-TI3W-bank-foreign-spacing-v4b-sourceonly.py",
  "bytes": 5027,
  "sha256": "5365ac5b168afd6ed6e6872e8b368dc4f2d89dabfc7d1d8d3da799cb832956c1",
  "mode": 384
 },
 {
  "restorePath": "/tmp/g350-actual286-source24-TI3W-foreign-spacing-v4-independent-peer-sourceonly.py",
  "bytes": 2487,
  "sha256": "e111ee77a6c1b8ebafdb6fdc503415a0ae92ebc8129bb2a42ac00d85224e70b3",
  "mode": 384
 }
]
META=('README.md','PROGRESS.json','WORKSPACE_RESTORE_MANIFEST.json','WORKSPACE_HASH_INDEX.json')
FALSE={'all49Accepted':False,'fullBoardPassed':False,'fullTimingPassed':False,'electricalTimingQualified':False,'tiQualified':False,'referenceContinuityQualified':False,'cadQualified':False,'defaultBoardPromoted':False,'fabricationReady':False}
def need(v,m):
 if not v:raise ValueError(m)
def regular(p):return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
  os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 return h.hexdigest()
def read(p):return json.loads(p.read_bytes())
def md(p):return {'bytes':p.stat().st_size,'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)}
def exact(p,r):need(regular(p) and md(p)=={k:r[k] for k in ('bytes','sha256','mode')},'Exact bytes/hash/mode '+str(p))
def relative(n):
 p=PurePosixPath(n);need(p.parts and not p.is_absolute() and '..' not in p.parts and str(p)==n and '\\' not in n,'Canonical relative member');return Path(*p.parts)
def write(p,d):
 with p.open('x') as f:os.fchmod(f.fileno(),0o600);json.dump(d,f,indent=2,allow_nan=False);f.write('\n')
def publish(t,p):os.link(t,p);t.unlink()
def source289(a):
 for n,h in BASE_PINS.items():need(regular(BASE/n) and sha(BASE/n)==h,'Frozen Source289 metadata')
 idx,mf,pr=read(BASE/'WORKSPACE_HASH_INDEX.json'),read(BASE/'WORKSPACE_RESTORE_MANIFEST.json'),read(BASE/'PROGRESS.json')
 need(len(idx['files'])==155 and len(mf['files'])==135 and len(mf['baseDependencyRestoreFiles'])==32,'Exact base156/135/32')
 for r in idx['files']:exact(BASE/relative(r['path']),r)
 targets=[{'baseSavedDirectory':BASE_REL,**r} for r in mf['files']]+mf['baseDependencyRestoreFiles'];need(len({r['restorePath'] for r in targets})==167,'Unique167 base targets')
 for r in targets:exact(Path(r['restorePath']),r)
 ar=BOARD/('cloud/artifacts/'+BASE_STEM+'.tar.gz');mp=ar.with_name(BASE_STEM+'.manifest.json')
 for p,h in [(ar,a.source289_archive_sha),(mp,a.source289_manifest_sha)]:need(re.fullmatch('[0-9a-f]{64}',h) and regular(p) and sha(p)==h,'Explicit actual Source289 archive binding')
 am=read(mp);need(am['scope']=='PORTABLE_POST274_BOTH_BYTES_CA15_CONNECTED49_SOURCE289_SOURCE_AND_DATA' and am['archive']['sha256']==a.source289_archive_sha and am['archive']['bytes']==ar.stat().st_size and am['primaryCandidate']['sha256']==BASE_SHA,'Exact current Source289 portable archive')
 need(am['snapshotPins']=={BASE_REL+'/'+n:h for n,h in BASE_PINS.items()} and am['workspaceRestoreTargetCount']==135,'Pinned complete Source289 archive')
 dep={**am['archive'],'manifest':mp.relative_to(BOARD).as_posix(),'manifestSha256':a.source289_manifest_sha,'mustBeRestoredFirst':True,'payloadCopiedByThisCollector':False}
 return mf,pr,targets,dep

def model_controls():
 for r in ROWS:exact(Path(r['restorePath']),r)
 ds=[read(Path(ROWS[i]['restorePath'])) for i in (0,1,2,7,8,9)]
 c,report,receipt,proof,pure,peer=ds;base=read(BASE/'byte0-result.candidate.json')
 owner=lambda t:t.get('connection_name',t.get('source_trace_id'))
 need(c['full49FanoutInput']==base['full49FanoutInput'] and c['heldCarrierTraces']==base['heldCarrierTraces'],'Entire foundation/held6 literal Source286/Source289')
 old={owner(t):t for t in base['carrierTraces']};new={owner(t):t for t in c['carrierTraces']}
 need(set(old)==set(new)=={'source_trace_'+str(i) for i in range(49)} and all(new[n]==old[n] for n in old if n!='source_trace_24'),'Only24 body, all48 other bodies literal')
 inv=proof['bodyInverses'];need(len(inv)==1 and inv[0]['owner']=='source_trace_24' and inv[0]['before']==old['source_trace_24'] and inv[0]['after']==new['source_trace_24'],'Exact24 body inverse')
 for d in (c,report):
  need(d['all49Connected'] is True and d['allSavedCarriersCurrentSceneQualified'] is True and len(d['finalScenePhysicalReports'])==49 and all(r['passed'] is True for r in d['finalScenePhysicalReports']),'Fresh model299 all49 physical')
  need(len(d['criticalValidationViews'])==2 and all(v['passed'] is True and v['c31']['solved'] is True and set(v['reports'])=={'bus','pair','shared','coupling','exterior'} and all(len(rs)==3 and all(q['matched'] is True for q in rs) for rs in v['reports'].values()) for v in d['criticalValidationViews']),'Both actual critical views/full5 APIs')
  need(d['byte0PlanarBusSkewPassed'] is True and d['byte1PlanarBusSkewPassed'] is True and d['caCohortPlanarObservation']['minimumPassingCount']==16 and d['caCohortPlanarObservation']['fullBusTimingPassed'] is False,'Model299 CA16/bothbytes/fullCAfail')
  q=d['source24ForeignDdrClassSpacingAudit'];need(q['noExceptionWaiversApplied'] is True and q['subGuidancePairCount']==0 and q['subGuidancePairs']==[] and q['sameClass3WCenterlineMm']==.3048 and q['otherDdrClass4WCenterlineMm']==.4064 and q['wholeTiRoutingQualified'] is False,'Scoped foreign3W/4W proof, no wholeTI claim')
  need(all(d[k] is False for k in ('all49Accepted','matched','nativeExecuted','cadExecuted','freshSourceCoreDerived','fabricationReady')),'Model-only qualification boundary')
 need(receipt['scope']==299 and receipt['execution']['exitCode']==0 and receipt['execution']['cleanupOwnedGroupEmpty'] is True and receipt['sourcePinsUnchanged'] is True and receipt['protectedFilesUnchanged'] is True,'Actual closed299 receipt')
 need(receipt['execution']['command'][1]==ROWS[6]['restorePath'],'Exact actual reviewed worker')
 need(proof['source24PureProofSha256']==ROWS[8]['sha256'] and peer['proofSha256']==ROWS[7]['sha256'] and peer['allFixedMaterialAndOther48BodiesHeld'] is True and pure['matchedCaMinimumPassingCountAfter']==16,'Full current pure/independent evidence binding')
 return c,report

def build(a):
 need(not SAVED.exists(),'Fresh model-only staging folder');mf,pr,base_targets,dep=source289(a);c,report=model_controls()
 need(shutil.disk_usage('/tmp').free>sum(r['bytes'] for r in ROWS)+1024**3,'Tmp capacity plus1GiB')
 need(int(Path('/sys/fs/cgroup/memory.current').read_text())+64*1024**2+1024**3<30*1024**3,'Shared30GiB reserve')
 ar=BOARD/('cloud/artifacts/'+STEM+'.tar.gz');mp=ar.with_name(STEM+'.manifest.json')
 need(not ar.exists() and not mp.exists(),'Fresh immutable model archive pair')
 SAVED.mkdir(mode=0o700);rows=[]
 for i,r in enumerate(ROWS+[{'restorePath':str(Path(__file__).resolve()),**md(Path(__file__))}]):
  p=Path(r['restorePath']);n=('MODEL299_OWNED_' if '/owned/' in str(p) else 'MODEL299_')+p.name
  out=SAVED/n
  with p.open('rb') as f,out.open('xb') as g:shutil.copyfileobj(f,g,1048576);os.fchmod(g.fileno(),r['mode'])
  exact(out,r);rows.append({**r,'savedPath':n})
 deps=pr['baseArchiveDependenciesInRestoreOrder']+[dep]
 model={'scope':'MODEL299_ONLY24_BOTTOM_BANK_CA16_BOTH_BYTES_CURRENT_MODEL_PHYSICAL_NO_FRESH_SOURCE','candidateSha256':MODEL_SHA,'savedCandidate':rows[0]['savedPath'],'routedOwners':49,'pendingOwnerIds':[],'all49ModelPhysicalPassed':True,'bothCriticalViewsAndFiveApisPassed':True,'byte0PlanarSkewPassed':True,'byte1PlanarSkewPassed':True,'caMinimumPassingCount':16,'caUnderMinimumCount':10,'caPlanarSkewPassed':False,'source24ForeignDdr3W4WCenterlineSpacingPassed':True,'source24WholeTiQualified':False,'sourceCoreReplayExecuted':False,'nativeBoardChecksExecuted':False,'currentPourQualificationPending':True,'currentCadQualificationPending':True,**FALSE}
 common={'scope':model['scope'],'frozenCheckpoint':True,'updatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'latestClosedScopeIncluded':299,'primaryCandidate':model,'primaryModelCandidate':model,'latestSourceVerifiedCheckpoint':pr['latestSourceVerifiedCheckpoint'],'latestEditableSourceSavedDirectory':BASE_REL,'latestEditableSourceCoreScope':289,'model299QualificationInheritedFromSource289':False,'baseArchiveDependency':dep,'baseArchiveDependenciesInRestoreOrder':deps,'laterWorkRequiresNewSavedDirectory':True,**FALSE}
 restore={**common,'solverSourceRoot':mf['solverSourceRoot'],'files':rows,'baseDependencyRestoreFiles':base_targets,'immutableWorkspaceAssets':[],'immutableAssetsRestoredByBaseArchives':mf['immutableAssetsRestoredByBaseArchives']}
 write(SAVED/'WORKSPACE_RESTORE_MANIFEST.json',restore)
 with (SAVED/'README.md').open('x') as f:
  os.fchmod(f.fileno(),0o600);f.write('MODEL299 supplemental branch:49 model paths/both bytes PASS, CA16/26 at minimum;fullCA skew still FAILS.\nOnly Source24 body changes, all other48 bodies/foundation/critical6 literal Source289 model.\nScoped new24 foreign DDR3W/4W audit has zero exceptions. WholeTI/electrical/fab false.\nLatest editable Source remains289 with its separate951 native findings and19 unqualified pours.\nNo fresh Source/Core/native-board/CAD/pour/PDN qualification is claimed for299.\nRestore all six prior archives209→228→248→257→272-v2→289 before this increment.\nExisting generic archive restorer and legacy /tmp workspace helper are compatible.\nNo SDK/application code is executed by this collector/archive author.\n')
 write(SAVED/'PROGRESS.json',{**common,'modelEvidence':rows,'sdkExecutedByCollector':False,'archiveCreatedByOwnStdlib':True})
 index=[{'path':p.name,**md(p)} for p in sorted(SAVED.iterdir())];write(SAVED/'WORKSPACE_HASH_INDEX.json',{'scope':model['scope'],'files':index,'selfExcluded':True,'frozenCheckpoint':True})
 members=[{'path':SAVED_REL+'/'+p.name,'_source':p,**md(p)} for p in sorted(SAVED.iterdir())]
 need(len(members)==17 and len(index)==16 and len(rows)==13,'Exact small17 members/13tmp targets')
 temp=None;durable=None;mt=None
 try:
  fd,n=tempfile.mkstemp(prefix='g350-model299-',suffix='.tar.gz',dir='/tmp');temp=Path(n)
  with os.fdopen(fd,'wb') as output:
   os.fchmod(output.fileno(),0o600)
   with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0,compresslevel=6) as gz:
    with tarfile.open(mode='w|',fileobj=gz,format=tarfile.PAX_FORMAT) as tf:
     for r in members:
      exact(r['_source'],r);info=tarfile.TarInfo(r['path']);info.size=r['bytes'];info.mode=r['mode'];info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
      with r['_source'].open('rb') as f:tf.addfile(info,f)
      exact(r['_source'],r)
   output.flush();os.fsync(output.fileno())
  for r in ROWS:exact(Path(r['restorePath']),r)
  source289(a);actual={'path':ar.relative_to(BOARD).as_posix(),**md(temp)}
  manifest={'schemaVersion':1,'scope':'PORTABLE_MODEL299_CA16_INCREMENT_NOT_FRESH_SOURCE','regularFilesOnly':True,'historicalDataOnly':True,'archive':actual,'files':[{k:v for k,v in r.items() if k!='_source'} for r in members],'inputDirectories':[SAVED_REL],'extraWorkspaceAssetMembers':[],'baseArchiveDependenciesInRestoreOrder':deps,'baseArchivesIncluded':False,'workspaceRestoreTargetCount':13,'baseRestoreTargetCount':167,'snapshotPins':{SAVED_REL+'/'+n:sha(SAVED/n) for n in META},'primaryCandidate':{'path':SAVED_REL+'/'+rows[0]['savedPath'],'sha256':MODEL_SHA},'latestSourceVerifiedCheckpoint':pr['latestSourceVerifiedCheckpoint'],'latestEditableSourceCoreScope':289,'solverSourceRoot':mf['solverSourceRoot'],**FALSE}
  fd,n=tempfile.mkstemp(prefix='.'+mp.name+'.',suffix='.partial',dir=mp.parent);mt=Path(n)
  with os.fdopen(fd,'w') as f:os.fchmod(f.fileno(),0o600);json.dump(manifest,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
  need(shutil.disk_usage(ar.parent).free>temp.stat().st_size+256*1024**2,'Measured model archive plus256MiB durable reserve')
  fd,n=tempfile.mkstemp(prefix='.'+ar.name+'.',suffix='.partial',dir=ar.parent);durable=Path(n)
  with temp.open('rb') as f,os.fdopen(fd,'wb') as g:shutil.copyfileobj(f,g,1048576);os.fchmod(g.fileno(),0o600);g.flush();os.fsync(g.fileno())
  exact(durable,actual);publish(durable,ar);durable=None;publish(mt,mp);mt=None
  print(json.dumps({'archive':str(ar),'archiveSha256':sha(ar),'manifest':str(mp),'manifestSha256':sha(mp),'files':17,'tmpTargets':13,'baseTargets':167,'latestEditableSource':289,'primaryModelScope':299,'sdkExecuted':False,'fabricationReady':False}))
 finally:
  for p in (temp,durable,mt):
   if p is not None and p.exists():p.unlink()

def verify(a):
 _,_,base_targets,_=source289(a);model_controls();ar=BOARD/('cloud/artifacts/'+STEM+'.tar.gz');mp=ar.with_name(STEM+'.manifest.json')
 for p,h in [(ar,a.archive_sha),(mp,a.manifest_sha)]:need(h and re.fullmatch('[0-9a-f]{64}',h) and regular(p) and sha(p)==h,'Actual new model archive/manifest SHA')
 am=read(mp);need(am['scope']=='PORTABLE_MODEL299_CA16_INCREMENT_NOT_FRESH_SOURCE' and am['archive']['sha256']==a.archive_sha and len(am['files'])==17,'Exact MODEL29917-member increment')
 for p,h in [(RESTORER,RESTORER_SHA),(HELPER,HELPER_SHA)]:need(regular(p) and sha(p)==h,'Exact existing restoration Source')
 owned=Path(tempfile.mkdtemp(prefix='g350-model299-smoke-',dir='/tmp'));dest=owned/'extracted';commands=[]
 def run(argv):
  r=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=120,check=False);commands.append({'argv':argv,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});need(r.returncode==0,'Restoration-only verifier');return r.stdout
 try:
  command=[sys.executable,str(RESTORER),str(mp),'--destination',str(dest)]
  need(run(command+['--verify-archive']).strip()=='Verified 17 evidence members; restored 0','Exact verify count')
  need(run(command).strip()=='Verified 17 evidence members; restored 17','Exact isolated17 extraction')
  names={p.relative_to(dest).as_posix() for p in dest.rglob('*') if p.is_file()};need(names=={r['path'] for r in am['files']},'Only exact regular archive members')
  for r in am['files']:exact(dest/relative(r['path']),r)
  for n,h in am['snapshotPins'].items():need(sha(dest/relative(n))==h,'All extracted metadata pins')
  mf=read(dest/SAVED_REL/'WORKSPACE_RESTORE_MANIFEST.json');need(len(mf['files'])==13 and mf['baseDependencyRestoreFiles']==base_targets and mf['latestEditableSourceCoreScope']==289,'Literal167 base restore refs and13 local targets')
  targets=mf['files']+base_targets;need(len({r['restorePath'] for r in targets})==180,'All180 current targets exist before no-op')
  for r in targets:exact(Path(r['restorePath']),r)
  link=Path(mf['solverSourceRoot']).parent/'node_modules';need(link.is_symlink() and link.resolve()==(BOARD.parent/'bus-lanes-solver/node_modules').resolve(),'Existing exact dependency link')
  link_id=(link.lstat().st_dev,link.lstat().st_ino,link.lstat().st_mtime_ns,link.lstat().st_ctime_ns,os.readlink(link))
  result=json.loads(run([sys.executable,str(HELPER),'--saved-directory',str(dest/SAVED_REL),'--restore']));need(result['savedFilesVerified']==13 and result['restoredFiles']==0 and result['mode']=='restore','Existing complete restore branch is zero-write')
  for r in targets:exact(Path(r['restorePath']),r)
  need((link.lstat().st_dev,link.lstat().st_ino,link.lstat().st_mtime_ns,link.lstat().st_ctime_ns,os.readlink(link))==link_id,'Dependency link unchanged')
  source289(a);model_controls();need(sha(ar)==a.archive_sha and sha(mp)==a.manifest_sha,'Archive inputs unchanged')
  shutil.rmtree(dest);write(owned/'REPORT.json',{'scope':'MODEL299_INCREMENT_ISOLATED_EXTRACTION_AND180_TARGET_NOOP_RESTORE_NOT_SOURCE_QUALIFICATION','passed':True,'commands':commands,'archiveSha256':a.archive_sha,'manifestSha256':a.manifest_sha,'isolatedPayloadRemoved':True,'all180ActualTargetsUnchanged':True,'existingHelperRestoreCodePathExecuted':True,'restoredWorkspaceFiles':0,'latestEditableSource':289,'primaryModelScope':299,'sdkExecuted':False,**FALSE})
  print(json.dumps({'report':str(owned/'REPORT.json'),'sha256':sha(owned/'REPORT.json'),'passed':True,'sdkExecuted':False}))
 except BaseException as e:
  write(owned/'FAILURE.json',{'passed':False,'error':str(e),'commands':commands,'isolatedPayloadPreserved':dest.exists(),**FALSE});raise

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['build','verify']);p.add_argument('--source289-archive-sha',required=True);p.add_argument('--source289-manifest-sha',required=True);p.add_argument('--archive-sha');p.add_argument('--manifest-sha');a=p.parse_args()
 (build if a.mode=='build' else verify)(a)
if __name__=='__main__':main()
