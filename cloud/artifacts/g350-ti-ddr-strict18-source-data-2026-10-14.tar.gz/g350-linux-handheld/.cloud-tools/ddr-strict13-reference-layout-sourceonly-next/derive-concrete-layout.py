"""Stdlib concrete two-patch proposal and analytic foreign-copper deficits.

The .4 mm half corridor is a provisional layout reservation, not an electrical
return-field model. Original source/225 holes remain unchanged. No applications.
"""
from pathlib import Path
import json
import hashlib
import math

ROOT = Path('/workspace/g350-linux-handheld')
HERE = Path(__file__).parent
ROUTES = ROOT / '.cloud-tools/ddr-byte1-pair-ripup-sourceonly-next/NORMALIZED_MATCHED_B1_THREE_B0EIGHT_CLOCK2_INTERACTION_13.json'
ROUTES_SHA = '3dff9eb8a0e58ea268be167405e3c744ebfb48849639878dada22bb01b4f0a84'
INPUT = ROOT / '.cloud-tools/ddr-package101-plus96-signals-combined-sourceonly-next/combined-input.json'
INPUT_SHA = 'ed97be5fae82111e8e08247ba97f2a4a5977d33bd1b901a0428a1cf155af59fc'
CONTEXT = ROOT / '.cloud-tools/ddr-package101-plus96-signals-combined-sourceonly-next/native-context.json'
CONTEXT_SHA = 'e9edfcd1b47c6d04ffa2a817a6957ed5b395a8f8f2d4554a03cf28eda589e44e'
LAYERS = ('top', 'inner1', 'inner2', 'bottom')
REFERENCE = {'top': ('inner1', 'GND'), 'inner1': ('top', 'GND'), 'inner2': ('bottom', 'GND'), 'bottom': ('inner2', 'DDR_1V5')}
WIDTH, CLEARANCE, CANDIDATE_HALF = .1016, .12, .4


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def xy(p):
    q = (p['x'], p['y']) if isinstance(p, dict) else tuple(p)
    assert len(q) == 2 and all(math.isfinite(v) for v in q)
    return q


def merge(intervals):
    out = []
    for lo, hi in sorted(intervals,key=lambda pair:(pair[0],pair[1])):
        if hi <= lo:
            continue
        if out and lo <= out[-1][1]:
            out[-1][1] = max(out[-1][1], hi)
        else:
            out.append([lo, hi])
    return out


def linear_band(origin, slope, lo, hi):
    if slope == 0:
        return (0, 1) if lo <= origin <= hi else None
    a, b = (lo-origin)/slope, (hi-origin)/slope
    return (max(0, min(a,b)), min(1, max(a,b)))


def circle_interval(a, b, center, radius):
    d = (b[0]-a[0], b[1]-a[1]);f = (a[0]-center[0], a[1]-center[1])
    aa = d[0]**2+d[1]**2;bb = 2*(f[0]*d[0]+f[1]*d[1]);cc = f[0]**2+f[1]**2-radius**2
    assert aa > 0
    disc = bb*bb-4*aa*cc
    if disc <= 0:
        return []
    delta = math.sqrt(disc)
    return merge([(max(0,(-bb-delta)/(2*aa)), min(1,(-bb+delta)/(2*aa)))])


def capsule_intervals(a, b, c, d, radius):
    length = math.dist(c,d)
    if length == 0:
        return circle_interval(a,b,c,radius)
    u = ((d[0]-c[0])/length,(d[1]-c[1])/length);n = (-u[1],u[0])
    delta = (b[0]-a[0],b[1]-a[1]);p = (a[0]-c[0],a[1]-c[1])
    along = linear_band(p[0]*u[0]+p[1]*u[1],delta[0]*u[0]+delta[1]*u[1],0,length)
    across = linear_band(p[0]*n[0]+p[1]*n[1],delta[0]*n[0]+delta[1]*n[1],-radius,radius)
    intervals = circle_interval(a,b,c,radius)+circle_interval(a,b,d,radius)
    if along and across:
        intervals.append((max(along[0],across[0]),min(along[1],across[1])))
    return merge(intervals)


def box_intervals(a,b,box):
    ix=linear_band(a[0],b[0]-a[0],box[0],box[1]);iy=linear_band(a[1],b[1]-a[1],box[2],box[3])
    return merge([(max(ix[0],iy[0]),min(ix[1],iy[1]))]) if ix and iy else []


def rounded_rect_intervals(a,b,box,radius):
    x0,x1,y0,y1=box
    intervals=box_intervals(a,b,(x0-radius,x1+radius,y0,y1))+box_intervals(a,b,(x0,x1,y0-radius,y1+radius))
    for x in (x0,x1):
        for y in (y0,y1):intervals+=circle_interval(a,b,(x,y),radius)
    return merge(intervals)


def make_items(full, records):
    items=[]
    for i,o in enumerate(full['obstacles']):
        identity=o.get('circuitJsonMetadata',{}).get('pcb_via_id') or o.get('circuitJsonMetadata',{}).get('pcb_smtpad_id') or o.get('circuitJsonMetadata',{}).get('pcb_plated_hole_id') or f'original_obstacle_{i}'
        net='GND' if 'source_net_0' in o.get('connectedTo',[]) else 'DDR_1V5' if 'source_net_5' in o.get('connectedTo',[]) else 'FOREIGN_OR_UNNAMED'
        c=xy(o['center']);w,h=o['width'],o['height']
        if o.get('shape')=='circle':shape={'kind':'capsule','a':c,'b':c,'radius':max(w,h)/2}
        else:shape={'kind':'rect_conservative_bound','box':(c[0]-w/2,c[0]+w/2,c[1]-h/2,c[1]+h/2)}
        items.append({'id':identity,'net':net,'layers':o['layers'],'basis':'ORIGINAL_FIXED_LAND_HOLE_KEEPOUT_OR_REFERENCE_VIA',**shape})
    for trace in full['traces']:
        owner=trace.get('physicalContextMetadata',{}).get('source_net_id')
        net='GND' if owner=='source_net_0' else 'DDR_1V5' if owner=='source_net_5' else 'FOREIGN_OR_UNNAMED'
        for i,(a,b) in enumerate(zip(trace['route'],trace['route'][1:])):
            if a['route_type']==b['route_type']=='wire' and a['layer']==b['layer'] and xy(a)!=xy(b):
                assert a['width']==b['width']
                items.append({'id':trace['pcb_trace_id']+':segment:'+str(i),'net':net,'layers':[a['layer']],'basis':'EXACT_FIXED_LOCAL_COPPER','kind':'capsule','a':xy(a),'b':xy(b),'radius':a['width']/2})
        for i,p in enumerate(trace['route']):
            if p['route_type']=='via':
                items.append({'id':trace['pcb_trace_id']+':signal_barrel:'+str(i),'net':net,'layers':p['layers'],'basis':'EXACT_FIXED96_SIGNAL_BARREL','kind':'capsule','a':xy(p),'b':xy(p),'radius':p['via_diameter']/2})
    for record in records:
        points=list(map(xy,record['path']))
        for i,(a,b) in enumerate(zip(points,points[1:])):
            if a!=b:items.append({'id':record['sourceTraceId']+':current13_segment:'+str(i),'net':'FOREIGN_OR_UNNAMED','layers':[record['layer']],'basis':'CURRENT13_MAIN_CARRIER','kind':'capsule','a':a,'b':b,'radius':WIDTH/2})
    return items


def blocked(a,b,item,halfwidth,clearance):
    if item['kind']=='capsule':return capsule_intervals(a,b,item['a'],item['b'],item['radius']+halfwidth+clearance)
    return rounded_rect_intervals(a,b,item['box'],halfwidth+clearance)


def item_bbox(item,extra):
    if item['kind']=='capsule':
        r=item['radius']+extra;a,b=item['a'],item['b'];return(min(a[0],b[0])-r,max(a[0],b[0])+r,min(a[1],b[1])-r,max(a[1],b[1])+r)
    x0,x1,y0,y1=item['box'];return(x0-extra,x1+extra,y0-extra,y1+extra)


def overlap(a,b):
    return a[0]<=b[1] and b[0]<=a[1] and a[2]<=b[3] and b[2]<=a[3]


def main():
    assert sha(ROUTES)==ROUTES_SHA and sha(INPUT)==INPUT_SHA and sha(CONTEXT)==CONTEXT_SHA
    route=json.loads(ROUTES.read_text());full=json.loads(INPUT.read_text());context=json.loads(CONTEXT.read_text())
    assert len(route['records'])==13 and len({r['sourceTraceId'] for r in route['records']})==13
    assert route['fullInputSha256']==INPUT_SHA and len(full['connections'])==49
    assert len(context['referenceVias'])==129 and len(context['signalDogbones'])==96
    for r in route['records']:assert r['layer'] in LAYERS
    items=make_items(full,route['records']);patches=[]
    for signal_layer,patch_layer in [('inner1','top'),('inner2','bottom')]:
        points=[xy(p) for r in route['records'] if r['layer']==signal_layer for p in r['path']]
        x0,x1=min(p[0] for p in points)-CANDIDATE_HALF,max(p[0] for p in points)+CANDIDATE_HALF
        y0,y1=min(p[1] for p in points)-CANDIDATE_HALF,max(p[1] for p in points)+CANDIDATE_HALF
        outlines=[{'x':x0,'y':y0},{'x':x1,'y':y0},{'x':x1,'y':y1},{'x':x0,'y':y1}]
        stitch_candidates=[]
        for v in context['referenceVias']:
            if v['source_net_id']!='source_net_0':continue
            p=xy(v);r=v['outer_diameter']/2
            if not(x0+r+CLEARANCE<=p[0]<=x1-r-CLEARANCE and y0+r+CLEARANCE<=p[1]<=y1-r-CLEARANCE):continue
            collisions=[]
            for foreign in items:
                if foreign['net']=='GND':continue
                bbox=item_bbox(foreign,r+full['minViaEdgeToPadEdgeClearance'])
                if not(bbox[0]<=p[0]<=bbox[1] and bbox[2]<=p[1]<=bbox[3]):continue
                # Point modeled as a nonzero test line; exact center-distance
                # screen is conservative and does not create/move any hole.
                if foreign['kind']=='capsule':
                    a,b=foreign['a'],foreign['b'];d=(b[0]-a[0],b[1]-a[1]);den=d[0]**2+d[1]**2
                    t=max(0,min(1,((p[0]-a[0])*d[0]+(p[1]-a[1])*d[1])/den)) if den else 0
                    distance=math.dist(p,(a[0]+t*d[0],a[1]+t*d[1]))-foreign['radius']
                else:
                    b=foreign['box'];distance=math.hypot(max(b[0]-p[0],0,p[0]-b[1]),max(b[2]-p[1],0,p[1]-b[3]))
                if distance<r+full['minViaEdgeToPadEdgeClearance']:collisions.append(foreign['id'])
            stitch_candidates.append({'pcb_via_id':v['pcb_via_id'],'source_net_id':'source_net_0','net':'GND','x':v['x'],'y':v['y'],'layers':v['layers'],'outerDiameterMm':v['outer_diameter'],'holeDiameterMm':v['hole_diameter'],'newHole':False,'foreignCopperScreenConflicts':collisions,'candidateOnlyNeedsActualSameFilledComponentBinding':True})
        patches.append({'name':'G350_CURRENT13_REFERENCE_'+patch_layer.upper(),'layer':patch_layer,'connectsTo':'net.GND','outline':outlines,'clearanceMm':CLEARANCE,'cutoutMarginMm':CLEARANCE,'useThermalReliefs':False,'targetSignalLayer':signal_layer,'provisionalReservationHalfWidthMm':CANDIDATE_HALF,'candidateNearDielectricFacesMm':.0764,'stitchCandidates':stitch_candidates,'filledCoverageQualified':False})
    deficits=[]
    for r in route['records']:
        ref_layer,ref_net=REFERENCE[r['layer']];points=list(map(xy,r['path']));prefix=0;all_intervals=[];carrier_only=[];matches=[];corridor_intervals=[]
        for i,(a,b) in enumerate(zip(points,points[1:])):
            length=math.dist(a,b)
            if length==0:continue
            bbox=(min(a[0],b[0]),max(a[0],b[0]),min(a[1],b[1]),max(a[1],b[1]))
            for item in items:
                if ref_layer not in item['layers'] or item['net']==ref_net:continue
                if not overlap(bbox,item_bbox(item,CANDIDATE_HALF+CLEARANCE)):continue
                intervals=blocked(a,b,item,WIDTH/2,CLEARANCE)
                broad=blocked(a,b,item,CANDIDATE_HALF,CLEARANCE)
                if intervals:
                    spans=[[prefix+lo*length,prefix+hi*length] for lo,hi in intervals];all_intervals+=spans
                    if item['basis']=='CURRENT13_MAIN_CARRIER':carrier_only+=spans
                    matches.append({'segmentIndex':i,'foreignOwnerId':item['id'],'foreignBasis':item['basis'],'segmentFractions':intervals,'distanceAlongCarrierMm':spans})
                corridor_intervals += [[prefix+lo*length,prefix+hi*length] for lo,hi in broad]
            prefix+=length
        union=merge(all_intervals);main_union=merge(carrier_only);broad=merge(corridor_intervals)
        deficits.append({'sourceTraceId':r['sourceTraceId'],'signalLayer':r['layer'],'referenceLayer':ref_layer,'referenceNet':ref_net,'mainCarrierLengthMm':prefix,'minimumPhysicalFootprintBlockedLengthMm':sum(hi-lo for lo,hi in union),'current13MainCarrierOnlyBlockedLengthMm':sum(hi-lo for lo,hi in main_union),'provisionalP4HalfCorridorBlockedLengthMm':sum(hi-lo for lo,hi in broad),'blockedDistanceIntervalsMm':union,'current13MainCarrierBlockedIntervalsMm':main_union,'provisionalCorridorBlockedIntervalsMm':broad,'foreignOwnerMatches':matches,'transitionAntipadsIncludedWithoutExemption':True,'actualFilledReferenceCoverageQualified':False})
    proposal={'scope':'CONCRETE_PROVISIONAL_CURRENT13_ADJACENT_REFERENCE_LAYOUT_NOT_FULL49','pins':{str(ROUTES):ROUTES_SHA,str(INPUT):INPUT_SHA,str(CONTEXT):CONTEXT_SHA},'signalCarrierCount':13,'remaining49Signals':36,'groundPatchCandidates':patches,'referenceAssignments':deficits,'originalReferencePlanesHeld':context['referencePlanesUnmodifiedButUnqualified'],'original129ReferenceViasAnd96SignalDogbonesHeld':True,'existing225FullSpanViasHeld':True,'newHolesAdded':0,'reset227ForkAdopted':False,'conditionalByte0All11Conflict42Vs26Adopted':False,'nominalClockMHz':400,'userNominalBoardThicknessMm':1.6,'manufacturer1080SelectionConfirmed':False,'actualModelsExecuted':0,'sourceOnly':True,'appImports':0,'coreCalls':0,'nativeCalls':0,'cadCalls':0,'referenceQualified':False,'accepted49':False,'fabricationReady':False}
    out=HERE/'CONCRETE_CURRENT13_REFERENCE_PROPOSAL.json';assert not out.exists();out.write_text(json.dumps(proposal,indent=2)+'\n');out.chmod(0o600)
    print(json.dumps({'proposalSha256':sha(out),'patchCandidates':len(patches),'stitchCandidates':[len(p['stitchCandidates']) for p in patches],'minimumBlockedLengthsMm':{r['sourceTraceId']:round(r['minimumPhysicalFootprintBlockedLengthMm'],6) for r in deficits},'accepted49':False}))


if __name__=='__main__':main()
