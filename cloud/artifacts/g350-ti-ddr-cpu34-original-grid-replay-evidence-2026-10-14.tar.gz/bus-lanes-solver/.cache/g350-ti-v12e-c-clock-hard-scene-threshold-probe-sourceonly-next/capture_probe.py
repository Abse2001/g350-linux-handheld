"""Read-only bounded probe for a source-bound atomic capture; no solver imports."""
from pathlib import Path
import json,math,os,re,stat
LIMIT=2*1024*1024
REASON='PERSISTED_FAILED_HARD_SCENE'
MIN_EXPANDED=50000
REQUIRED=['callerSha256','gridSha256','publicInputSha256','stageObserverSha256']

def make_capture_probe(path,expected_bindings,expected_scene_input):
    bindings=dict(expected_bindings)
    assert set(bindings)==set(REQUIRED+['precheckEnclosedTerminals'])
    assert bindings['precheckEnclosedTerminals'] is True
    assert all(isinstance(bindings[key],str) and re.fullmatch('[0-9a-f]{64}',bindings[key]) for key in REQUIRED)
    # Expectation is derived from the bound fresh49 +joint49/96 projection,
    # never inferred from an arbitrary captured connection count.
    expected=json.loads(json.dumps(expected_scene_input,allow_nan=False))
    assert isinstance(expected,dict) and expected.get('layerCount')==4
    assert len(expected.get('connections',[]))==26 and len(expected.get('traces',[]))==98
    assert len(expected.get('obstacles',[]))==856
    assert len(expected.get('buses',[]))==1 and expected['buses'][0]['busId']=='DDR_COMMAND_CLOCK'
    assert len(expected.get('differentialPairs',[]))==1
    assert expected['differentialPairs'][0]['connectionNames']==['source_trace_33','source_trace_34']
    expected_serialized=json.dumps(expected,separators=(',',':'),ensure_ascii=False,allow_nan=False)
    expected_clock=next(connection for connection in expected['connections'] if connection['name']=='source_trace_34')
    path=Path(path)
    fingerprint=None
    cached_reason=None
    def finite(value):
        return type(value) in (int,float) and math.isfinite(value)
    def point(value):
        return isinstance(value,dict) and finite(value.get('x')) and finite(value.get('y'))
    def scene_envelope(record):
        data=record.get('data');paths=record.get('undefinedPaths')
        if not isinstance(data,dict) or not isinstance(paths,list):return False
        required=['input','connection','width','hardCopper','margin','start','end','grid','stateAtThresholdCapture']
        if any(key not in data for key in required):return False
        if not isinstance(data['input'],dict) or data['input'].get('layerCount')!=4:return False
        if data['input']!=expected:return False
        if json.dumps(data['input'],separators=(',',':'),ensure_ascii=False,allow_nan=False)!=expected_serialized:return False
        connection=data['connection']
        if not isinstance(connection,dict) or connection!=expected_clock:return False
        if json.dumps(connection,separators=(',',':'),ensure_ascii=False,allow_nan=False)!=json.dumps(expected_clock,separators=(',',':'),ensure_ascii=False,allow_nan=False):return False
        terminals=connection.get('pointsToConnect')
        if not isinstance(terminals,list) or len(terminals)!=2:return False
        if any(not point(p) or p.get('layer')!='inner1' for p in terminals):return False
        if not point(data['start']) or not point(data['end']):return False
        if any(data['start'][axis]!=terminals[1][axis] for axis in ['x','y']):return False
        if not finite(data['width']) or data['width']<=0 or not finite(data['margin']) or data['margin']<0:return False
        copper=data['hardCopper']
        if not isinstance(copper,list) or not any(isinstance(row,dict) and isinstance(row.get('owners'),list) and 'reserved_pair_tail' in row['owners'] for row in copper):return False
        grid=data['grid']
        if not isinstance(grid,dict) or grid.get('checkReachability') is not True or not finite(grid.get('step')) or grid['step']<=0:return False
        bounds=grid.get('bounds')
        if not isinstance(bounds,dict) or any(not finite(bounds.get(key)) for key in ['minX','maxX','minY','maxY']):return False
        if not bounds['minX']<=bounds['maxX'] or not bounds['minY']<=bounds['maxY']:return False
        state=data['stateAtThresholdCapture']
        if not isinstance(state,dict):return False
        if type(state.get('expanded')) is not int or not MIN_EXPANDED<=state['expanded']<500000:return False
        if state.get('solved') is not False or state.get('failed') is not False:return False
        # Validate the detached undefined-path envelope without restoring or mutating it.
        for path in paths:
            if not isinstance(path,list) or not path or any(not isinstance(key,str) for key in path):return False
            current=data
            for key in path:
                if isinstance(current,dict) and key in current:current=current[key]
                elif isinstance(current,list) and key.isascii() and key.isdecimal() and int(key)<len(current):current=current[int(key)]
                else:return False
            if current is not None:return False
        return True
    def eligible(value):
        if not isinstance(value,dict) or value.get('bindings')!=bindings:return False
        if value.get('diagnosticOnly') is not True or value.get('accepted49') is not False or value.get('fabricationReady') is not False:return False
        records=value.get('records')
        if not isinstance(records,list) or not 1<=len(records)<=2:return False
        counters=['observedAttempts','persistedAttempts','releasedSuccesses','releasedAbandoned']
        if any(type(value.get(key)) is not int or not 0<=value[key]<=16 for key in counters):return False
        if value['persistedAttempts']>value['observedAttempts']:return False
        if value['persistedAttempts']!=value['releasedSuccesses']+value['releasedAbandoned']+len(records):return False
        if type(value.get('complete')) is not bool or value['complete']!=(len(records)==2):return False
        exhausted=value.get('attemptBudgetExhausted')
        if type(exhausted) is not bool:return False
        active=any(isinstance(record,dict) and record.get('outcome') is None for record in records)
        if exhausted!=(value['observedAttempts']==16 and not active):return False
        count=0
        ids=set()
        for record in records:
            if not isinstance(record,dict) or record.get('kind') not in ['original-coarse','original-fine']:return False
            if type(record.get('id')) is not int or not 1<=record['id']<=value['observedAttempts'] or record['id'] in ids:return False
            ids.add(record['id'])
            if record.get('captureAt')!='before-original-step-at-expanded-threshold':return False
            if record.get('frontierCaptured') is not False or record.get('fullFrontierReplayClaimed') is not False:return False
            if not scene_envelope(record):return False
            outcome=record.get('outcome')
            if outcome is None:continue
            if not isinstance(outcome,dict) or outcome.get('originalCancelReturned') is not True:return False
            if outcome.get('observedAt')!='before-first-original-cancel':return False
            solved,failed,expanded=outcome.get('solved'),outcome.get('failed'),outcome.get('expanded')
            if type(solved) is not bool or type(failed) is not bool or type(expanded) is not int or expanded<0:return False
            if expanded<record['data']['stateAtThresholdCapture']['expanded']:return False
            kind=outcome.get('kind')
            if kind=='NATURAL_FAILURE':
                if solved or not failed:return False
                count+=1
            elif kind=='CAP_STOP':
                if solved or failed or expanded<500000:return False
                count+=1
            else:return False
        return type(value.get('persistedFailingScenes')) is int and value['persistedFailingScenes']==count and count>0
    def probe():
        nonlocal fingerprint,cached_reason
        try:
            fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
            with os.fdopen(fd,'rb') as stream:
                status=os.fstat(stream.fileno())
                if not stat.S_ISREG(status.st_mode):return None
                current=(status.st_dev,status.st_ino,status.st_size,status.st_mtime_ns,status.st_ctime_ns)
                if current==fingerprint:return cached_reason
                fingerprint=current;cached_reason=None
                if not 0<status.st_size<=LIMIT:return None
                raw=stream.read(LIMIT+1)
                if len(raw)!=status.st_size or len(raw)>LIMIT:return None
                value=json.loads(raw)
                if eligible(value):cached_reason=REASON
                return cached_reason
        except (OSError,ValueError,UnicodeDecodeError,RecursionError,OverflowError):return None
    return probe
