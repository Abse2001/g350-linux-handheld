/** One root-approved original partial-qualification suite; no routing/init. */
import { strict as assert } from "node:assert"
import { createHash } from "node:crypto"
import { readFileSync, writeFileSync } from "node:fs"
import { join } from "node:path"
import { qualifyPartialNative, type PartialNativeApis } from "./partial-native"
import { validateParentCaptureSummaries } from "./parent-summary"
import { checkRealComponentEndpointNegative } from "./real-endpoint-control"
import type { OriginalCapture } from "./identity-order"
import type { SimpleRouteJson, Trace } from "./source/lib/types"
assert.deepEqual(process.argv.slice(2), ["--run-one-approved"])
assert.equal(process.env.G350_PUBLIC_COHORT_NATIVE_APPROVED, "1")
const root = import.meta.dir,
  sha = (raw: Uint8Array | string) =>
    createHash("sha256").update(raw).digest("hex")
const raw = readFileSync(join(root, "packet-manifest.json")),
  packet = JSON.parse(raw.toString())
const bound = <T>(name: string): T => {
  const bytes = readFileSync(join(root, name))
  assert.equal(sha(bytes), packet.inputBindings[name].sha256)
  return JSON.parse(bytes.toString())
}
const native = bound<SimpleRouteJson>("native-input.json"),
  escapes = bound<Trace[]>("all-owned-approaches.json"),
  captures = [2, 1, 3].map((id) => bound<OriginalCapture>(`job-${id}.json`)),
  registry = bound<any>("physical-reference-registry.json")
const parent = bound<any>("parent-result.json"),
  post = bound<any>("parent-postflight.json")
assert.equal(parent.packetSha256, packet.parentPrefixPacketSha256)
assert.equal(post.packetSha256Before, packet.parentPrefixPacketSha256)
assert.equal(post.packetSha256After, packet.parentPrefixPacketSha256)
assert.equal(
  post.resultSha256,
  packet.inputBindings["parent-result.json"].sha256,
)
assert.equal(post.resultTrustEligible, true)
assert.equal(post.execution.exitCode, 0)
assert.equal(post.execution.cleanupOwnedGroupEmpty, true)
assert.equal(post.execution.diagnosticStopped, false)
assert.equal(parent.diagnosticQualified, true)
assert.equal(parent.accepted49, false)
assert.equal(parent.captureContractSatisfied, true)
validateParentCaptureSummaries(parent.captures, captures)
// Dynamic original imports happen only after the authority and parent guards.
const [j, p, g, l, c, e, o, h, f] = await Promise.all([
  import("./source/lib/join-signal-escapes"),
  import("./source/scripts/g350-path-integrity"),
  import("./source/lib/native-signal-geometry"),
  import("./source/lib/route-lengths"),
  import("./source/lib/pair-coupling"),
  import("./source/lib/exterior-pair-spacing"),
  import("./source/lib/board-outline"),
  import("./source/lib/expanded-signal-sites"),
  import("@tscircuit/fanout-solver"),
])
const originals: PartialNativeApis = {
  joinSignalEscapes: j.joinSignalEscapes,
  validateG350PathIntegrity: p.validateG350PathIntegrity,
  nativeSignalGeometryIsValid: g.nativeSignalGeometryIsValid,
  validateRoutedCopperDrc: f.validateRoutedCopperDrc,
  pairLengthReports: l.pairLengthReports,
  pairCouplingReports: c.pairCouplingReports,
  exteriorPairSpacingReports: e.exteriorPairSpacingReports,
  boardOutlineViolations: o.boardOutlineViolations,
  generatedEscapeHolesConflict: h.generatedEscapeHolesConflict,
}
const calls: Record<string, number> = {}
const api = Object.fromEntries(
  Object.entries(originals).map(([name, fn]) => [
    name,
    (...args: any[]) => {
      calls[name] = (calls[name] ?? 0) + 1
      return (fn as any)(...args)
    },
  ]),
) as unknown as PartialNativeApis
const result = qualifyPartialNative(native, escapes, captures, registry, api)
const negative = checkRealComponentEndpointNegative(native, result, api)
assert.deepEqual(calls, {
  joinSignalEscapes: 4,
  validateG350PathIntegrity: 2,
  nativeSignalGeometryIsValid: 26,
  validateRoutedCopperDrc: 2,
  pairLengthReports: 1,
  pairCouplingReports: 1,
  exteriorPairSpacingReports: 1,
  boardOutlineViolations: 1,
  generatedEscapeHolesConflict: 325,
})
const report = {
  status: "ORIGINAL_PARTIAL_NATIVE_SUITE_RETURNED",
  ...result,
  realComponentEndpointNegativeControl: negative,
  realComponentEndpointNegativeControlRejected:
    negative.realComponentEndpointRulePreserved,
  packetSha256: sha(raw),
  sourceCommit: packet.sourceRevision,
  libTree: packet.libTree,
  parentPrefixTrusted: true,
  parentPrefixResultSha256: packet.inputBindings["parent-result.json"].sha256,
  originalUnrestrictedInputSha256:
    packet.inputBindings["native-input.json"].sha256,
  qualifierSuiteInvocations: 1,
  sourceCalls: calls,
  newInitializerCalls: 0,
  diagnosticQualified:
    result.inputAndHardwareHeld &&
    result.nativeDrcActuallyIngestedAllPhysicalTraces,
  physicalFailuresAreNotAcceptance: true,
  wholeBoardQualified: false,
}
const output = JSON.stringify(report, null, 2) + "\n"
assert.ok(Buffer.byteLength(output) <= 16 * 1024 ** 2)
writeFileSync(join(root, "run/result.json"), output, { flag: "wx" })
console.log(
  JSON.stringify({
    diagnosticQualified: report.diagnosticQualified,
    nativeConnectedSignals: result.nativeConnectedSignals,
    drcValid: result.drc.valid,
    allPhysicalTraceCount: result.allPhysicalTraceCount,
    fullspanViaCount: result.fullspanViaCount,
    accepted49: false,
    fabricationReady: false,
  }),
)
