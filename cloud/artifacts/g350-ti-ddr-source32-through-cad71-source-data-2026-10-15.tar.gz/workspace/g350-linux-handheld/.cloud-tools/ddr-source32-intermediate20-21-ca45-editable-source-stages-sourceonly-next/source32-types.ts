export type Pin = { path: string; sha256: string; bytes?: number; mode?: number }
export type Point = { x:number; y:number }
export type InnerPort = { viaName:string; layer:"inner1"|"inner2"; viaXY:Point; numericSelector:string|null; originalSourceTraceId?:string }
export type Source32Proposal = Record<string,any> & {
  scope:string; parent29QualificationBindings:Parent29QualificationBindings; promotedParent29Source:Pin; parent29Proposal:Pin; sealedIntermediateGeometryPins:Pin[]
  actualParent29Qualification:Pin|null; actualParent29Stages:Record<string,Pin|null>; actualParent29Capture:Pin|null
  jointIntermediateViaGeometryPeer:Pin|null;source45IndependentGeometryPeer:Pin|null
  source32Delta:{exactNewOriginalSourceTraceRoster:string[];exactIntermediateOriginalSourceTraceRoster:string[];newIntermediateCarrierVias:Record<string,any>[];newSixInnerPorts:InnerPort[];routeChanges:Record<string,any>[];localSuppressions:Record<string,any>[]}
  intermediateCarrierVias:Record<string,any>[];selected32OriginalCarriers:Record<string,any>[];added52RealInnerLayerPorts:InnerPort[]
}

export type Parent29QualificationBindings = {
 sourceManifest:Pin;sourceProposal:Pin;nativeApiRuntime:Pin;cliCadRuntime:Pin
 collectionPins:Record<string,Pin|null>;postauditPins:Record<string,Pin|null>;stagePins:Record<string,Pin|null>
 failedCadAttemptPins:Record<string,Pin>;failedCadAttemptPostPins:Record<string,Pin|null>
 rawCore:Pin;coreControls:Pin;fresh49Model:Pin;fresh49ProjectionProof:Pin;cliExport:Pin
}
