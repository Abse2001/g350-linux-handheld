"""Nonmutating V12e source/input provenance; no worker/Core/native/router APIs."""
import copy,hashlib,importlib.util,json,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
LAYERS=['top','inner1','inner2','bottom']
CARRIERS={'DDR_RESET':'bottom','DDR_BYTE0':'top','DDR_BYTE1':'inner2','DDR_COMMAND_CLOCK':'inner1'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def require(v,s):
 if not v:raise ValueError(s)
def verify_rows(base,rows):
 for row in rows:
  p=base/row['path'] if base else Path(row['path'])
  require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Binding changed: '+str(p))
def verify(expected_manifest_sha256):
 require(sha(ROOT/'SOURCE-INPUT-manifest.json')==expected_manifest_sha256,'Exact sealed V12e qualified source/input manifest required')
 m=load(ROOT/'SOURCE-INPUT-manifest.json');verify_rows(ROOT,m['files']);verify_rows(None,m['externalFiles'])
 control=Path(m['actualControlDirectory']);packet=load(control/'CONTROL-manifest.json')
 require(sha(control/'CONTROL-manifest.json')==m['actualControlManifestSha256'],'Original actual Core control packet changed')
 verify_rows(control,packet['files']);verify_rows(None,packet['externalBindings'])
 spec=importlib.util.spec_from_file_location('g350_v12e_prior_d_logic_only',Path(packet['parentProvenanceModule']));parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent);parent.verify(packet['parentManifestSha256'])
 post=load(control/'run/postflight.json');result=load(control/'run/result.json');execution=post['execution'];native=load(control/'run/native-physical.json')
 forward=Path(m['pureForwardDirectory']);forward_packet=load(forward/'CONTROL-manifest.json')
 require(sha(forward/'CONTROL-manifest.json')==m['pureForwardManifestSha256'],'Narrow pure forward packet changed')
 verify_rows(forward,forward_packet['files']);verify_rows(None,forward_packet['externalFiles'])
 final=load(forward/'run/RECEIPT.json');final_execution=final['execution'];proof=load(forward/'run/validated-input/actual-source-validation.json')
 require(final['passed'] is True and final['sourceHeld'] is True and final['sourceManifestSha256']==m['pureForwardManifestSha256'] and final['actualSourceAndInputCombinedTrustEligible'] is True and final['priorActualNativeCheckCount']==17 and final['priorActualNativeErrors']==0 and final['newCoreOrNativeOrRouterApiCalls']==0,'Narrow pure successor over exact actual Core/native records must pass')
 require(final_execution['exitCode']==0 and final_execution['diagnosticStopped'] is False and final_execution['cleanupOwnedGroupEmpty'] is True and not any(final_execution['oomDelta'].values()),'Pure successor must have clean original bounded exit')
 require(post['actualSourceAndInputTrustEligible'] is False and post['packetSha256Before']==post['packetSha256After']==m['actualControlManifestSha256'] and post['boardDependenciesBefore']==post['boardDependenciesAfter'],'Original failed final comparison and held actual Core/native source records required')
 require(execution['exitCode']==1 and execution['diagnosticStopped'] is False and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values()),'Original strict proof failure must remain cleanly closed under original scope')
 require(result['sourceBuildCount']==1 and result['actualSourceAndInputQualified'] is False and [(c['name'],c['exitCode']) for c in result['commands']]==[('actual-source-build',0),('actual-core-projection',0),('actual-native-placement',0),('actual-forward-proof',1)],'Actual one-build/all17-before-validated-input ordering required')
 require(native['physicalErrors']==0 and native['checkCount']==17 and len(native['counts'])==17 and all(v==0 for v in native['counts'].values()),'All17 original actual native checks must be zero')
 require(native['sourceSha256']==proof['actualCircuitSha256']==m['actualCircuitSha256'] and sha(control/'run/fresh-layout.circuit.json')==m['actualCircuitSha256'],'Actual full board and checker source binding changed')
 require(proof['allExistingAssetBytesAndResolvedFilesExactlyHeld'] is True and proof['onlyExistingOwnedForeignViaAntipadRingsMovedRigidly'] is True and len(proof['derivedCopperPourCutoutRows'])==2 and len(proof['preservedAssetUrlResolutionChanges'])==2 and proof['emittedValidatedInputsUseActualRawCoreGeometry'] is True and proof['validatedInputRawBytesCopiedWithoutReserialization'] is True and proof['allOriginal280Parts1161Contacts217LogicalConnectionsHeld'] is True and proof['all49OriginalCpuRamNumericContactIdsHeld'] is True and proof['allOtherPhysicalAndLogicalSourceFieldsExactlyHeldWithinOriginalTolerance'] is True and proof['onlyOneCapAndTwoOwnedReferencesMovedRigidlyMm']=={'x':1.4,'y':0} and len(proof['changedPhysicalRows'])==30,'Actual source/geometry parity must hold')
 require(sha(ROOT/'input.json')==proof['validatedInputSha256']==m['inputSha256'] and sha(ROOT/'original-unrestricted-input.json')==proof['validatedUnrestrictedInputSha256']==m['unrestrictedInputSha256'],'Exact fresh actual validated input bytes required')
 require((ROOT/'input.json').read_bytes()==(forward/'run/validated-input/input.json').read_bytes()==(control/'output/ddr-input.json').read_bytes(),'Input must be original actual Core projection bytes, not the proposal')
 actual=load(ROOT/'input.json');broad=load(ROOT/'original-unrestricted-input.json');expected_broad=copy.deepcopy(actual)
 for bus in expected_broad['buses']:bus['allowedLayers']=LAYERS;bus['preferredLayers']=['inner1','inner2','bottom','top']
 require(broad==expected_broad,'Broad counterpart changes only exact legal layer lists')
 require(actual['allowedLayers']==LAYERS and actual['layerCount']==4 and len(actual['connections'])==49 and len(actual['obstacles'])==856 and len(actual['traces'])==2,'Original four physical layers and49/856/2 inventory required')
 require({b['busId']:b['allowedLayers'] for b in actual['buses']}=={k:[v] for k,v in CARRIERS.items()},'Original exact four singleton carriers changed')
 pure=load(packet['actualPureCapture']);receipt=load(packet['actualPureReceipt']);e=receipt['execution']
 require(receipt['passed'] is True and receipt['sourceHeld'] is True and receipt['captureSha256']==sha(packet['actualPureCapture']) and receipt['sourceManifestSha256']==packet['actualPurePacketSha256'] and e['exitCode']==0 and e['diagnosticStopped'] is False and e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()),'Actual V12e pure capture must remain clean/source-held')
 require(pure['actualFinalReactTreeEvaluated'] is True and pure['allOtherTreePropsTypesKeysChildrenExactlyHeld'] is True and pure['changedProps']==packet['threePlacementOverrides'] and pure['globalSignalLayerProjection']==LAYERS and pure['naturallyDerivedGenericDefaultCap']==800000,'Actual final props/three moves must hold')
 for d in [post,result,final,proof,pure]:
  require(d['accepted49'] is False and d['fabricationReady'] is False,'No acceptance or fabrication claim allowed')
 for d in [proof,pure]:require(d['referenceQualified'] is False and d['TIplaneArrangement'] is False,'Regional reference redesign remains open')
 return {'scope':'QUALIFIED_ACTUAL_V12E_CORE17_THREE_RIGID_X_MOVE_INPUT_BRIDGE_REFERENCE_PENDING','inputSha256':m['inputSha256'],'unrestrictedInputSha256':m['unrestrictedInputSha256'],'freshCircuitSha256':m['actualCircuitSha256'],'actualControlManifestSha256':m['actualControlManifestSha256'],'pureForwardManifestSha256':m['pureForwardManifestSha256'],'qualifiedByCombinedActualCoreNativeAndNarrowPureSuccessor':True,'originalStrictCoreProofFailurePreserved':True,'nativePlacementChecks':17,'nativePlacementErrors':0,'nativePlacementChecksInheritedNotRerun':False,'actualCoreInputQualified':True,'actualFinalReactTreeEvaluated':True,'sourceInputParityQualified':True,'exactAll49SourceConnectionsQualified':True,'proposedThreeRigidXMotionsExactlyHeld':True,'routingRequests':49,'obstacles':856,'fixedReferences':2,'signalLayersAllowed':LAYERS,'cohortCarrierConstraints':CARRIERS,'naturallyDerivedGenericDefaultCap':800000,'explicitSearchCapSupplied':False,'referenceQualified':False,'TIplaneArrangement':False,'referenceRedesignStillRequired':True,'newCoreBuildPerformed':True,'newNativePlacementCheckPerformed':True,'nativeCoreOrRouterApiInvoked':False,'accepted49':False,'fabricationReady':False}
def verify_producer_inputs(producer_directory,expected_manifest_sha256):
 result=verify(expected_manifest_sha256);p=Path(producer_directory)
 require(sha(p/'input.json')==result['inputSha256'] and sha(p/'original-unrestricted-input.json')==result['unrestrictedInputSha256'],'Producer inputs must match fresh actual qualified V12e geometry')
 return result
def verify_actual_authored_props(path):
 m=load(ROOT/'SOURCE-INPUT-manifest.json');control=Path(m['actualControlDirectory']);packet=load(control/'CONTROL-manifest.json');canonical=Path(packet['actualPureCapture'])
 require(sha(path)==sha(canonical) and load(path)==load(canonical),'Exact actual final V12e pure props capture required')
 return {'actualFinalReactTreeEvaluated':True,'captureSha256':sha(path),'signalLayersAllowed':LAYERS,'cohortCarrierConstraints':CARRIERS,'naturallyDerivedGenericDefaultCap':800000,'referenceQualified':False,'TIplaneArrangement':False,'newCoreBuildPerformed':False,'newNativePlacementCheckPerformed':False,'accepted49':False,'fabricationReady':False}
