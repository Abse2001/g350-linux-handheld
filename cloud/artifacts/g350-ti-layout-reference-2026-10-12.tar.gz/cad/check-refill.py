"""Fresh KiCad V5 reference refill/numeric pads/first bypass connectivity.
No DDR/full-board timing or connectivity pass is claimed.
"""
from pathlib import Path
import hashlib,json,math
import wx
wx.Log.SetLogLevel(wx.LOG_Error)
app=wx.App(False)
import pcbnew
ROOT=Path('/workspace/g350-linux-handheld')
CAD=ROOT/'.cloud-tools/ti-ddr-v5-cad-next/g350-ti-v5.kicad_pcb'
OUT=ROOT/'.cloud-tools/ti-ddr-v5-cad-next/g350-ti-v5-refilled.kicad_pcb'
SOURCE=ROOT/'.cloud-tools/ti-ddr-v5-reference-export-next/run/fresh-layout.circuit.json'
REPORT=ROOT/'.cloud-tools/ti-ddr-v5-cad-next/reference-refill-check.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(CAD)=='a7ae7915d87a9120d768e729eb63d6c2d7976b68c78a68d6d85a121fc2844a0a'
assert sha(SOURCE)=='98a50b122e6a550c3020c935886d6832dbae34e333ea135e28e9bc555c973d5e'
assert not OUT.exists() and not REPORT.exists()
source=json.loads(SOURCE.read_text())
board=pcbnew.LoadBoard(str(CAD))
assert board.GetCopperLayerCount()==4 and abs(pcbnew.ToMM(board.GetDesignSettings().GetBoardThickness())-1.6)<1e-6
footprints={f.GetReference():f for f in board.GetFootprints()}
assert len(footprints)==280
components={e['source_component_id']:e['name'] for e in source if e['type']=='source_component'}
logical={e['source_port_id']:e for e in source if e['type']=='source_port'}
contacts=0
for pp in [e for e in source if e['type']=='pcb_port']:
    sp=logical[pp['source_port_id']]
    if sp['source_component_id'] not in components: continue
    fp=footprints[components[sp['source_component_id']]]
    pads=[p for p in fp.Pads() if p.GetNumber()==str(sp['pin_number'])]
    authored=[e for e in source if e['type'] in ['pcb_smtpad','pcb_plated_hole'] and e.get('pcb_port_id')==pp['pcb_port_id']]
    assert len(pads)==len(authored),(fp.GetReference(),sp['pin_number'],'land inventory')
    position=pcbnew.VECTOR2I(pcbnew.FromMM(100+pp['x']),pcbnew.FromMM(100-pp['y']))
    assert any(p.HitTest(position) for p in pads),(fp.GetReference(),sp['pin_number'],'numeric contact outside authored copper')
    if len(pads)==1 and pads[0].GetShape()!=pcbnew.PAD_SHAPE_CUSTOM:
        p=pads[0].GetPosition()
        assert abs(pcbnew.ToMM(p.x)-(100+pp['x']))<1e-5 and abs(pcbnew.ToMM(p.y)-(100-pp['y']))<1e-5
    contacts+=1
assert contacts==1161
tracks=list(board.GetTracks());vias=[t for t in tracks if isinstance(t,pcbnew.PCB_VIA)]
assert len(vias)==2 and len(tracks)==5
for via in vias:
    assert via.TopLayer()==pcbnew.F_Cu and via.BottomLayer()==pcbnew.B_Cu
    assert abs(pcbnew.ToMM(via.GetDrillValue())-.254)<1e-6
    for layer in [pcbnew.F_Cu,pcbnew.In1_Cu,pcbnew.In2_Cu,pcbnew.B_Cu]: assert abs(pcbnew.ToMM(via.GetWidth(layer))-.4572)<1e-6
zones={z.GetNetname():z for z in board.Zones() if z.GetNetname()}
assert set(zones)=={'GND','DDR_1V5'}
assert zones['GND'].GetLayer()==pcbnew.In1_Cu and zones['DDR_1V5'].GetLayer()==pcbnew.In2_Cu
# The pinned converter emits .15 clearance and .25 minimum zone thickness.
# Reconstruct the source-declared .12 clearance and board's .1016 minimum
# feature before refill; original raw export remains immutable.
zone_changes=[]
for name,z in zones.items():
    zone_changes.append({'net':name,'oldLocalClearanceMm':pcbnew.ToMM(z.GetLocalClearance()),'oldMinThicknessMm':pcbnew.ToMM(z.GetMinThickness()),'sourceLocalClearanceMm':.12,'sourceMinFeatureMm':.1016})
    z.SetLocalClearance(pcbnew.FromMM(.12));z.SetMinThickness(pcbnew.FromMM(.1016))
pcbnew.ZONE_FILLER(board).Fill(board.Zones())
pcbnew.SaveBoard(str(OUT),board)
board=pcbnew.LoadBoard(str(OUT));board.BuildConnectivity()
zones={z.GetNetname():z for z in board.Zones() if z.GetNetname()}
vias=[t for t in board.GetTracks() if isinstance(t,pcbnew.PCB_VIA)]
footprints={f.GetReference():f for f in board.GetFootprints()}
rows=[]
for pin,net in [('1','DDR_1V5'),('2','GND')]:
    pad=next(p for p in footprints['C_DDR_RAM_7'].Pads() if p.GetNumber()==pin)
    via=next(v for v in vias if v.GetNetname()==net)
    linked={i.m_Uuid.AsString() for i in board.GetConnectivity().GetConnectedItems(pad)}
    assert pad.GetNetname()==net and via.m_Uuid.AsString() in linked and zones[net].m_Uuid.AsString() in linked
    zone=zones[net]
    assert zone.IsFilled() and zone.GetFilledPolysList(zone.GetLayer()).OutlineCount()==1
    assert zone.HitTestFilledArea(zone.GetLayer(),via.GetPosition())
    rows.append({'capacitor':'C_DDR_RAM_7','numericPin':int(pin),'net':net,'actualViaAndFilledPlaneConnected':True,'referenceLayer':board.GetLayerName(zone.GetLayer()),'filledPlaneIslands':zone.GetFilledPolysList(zone.GetLayer()).OutlineCount()})
report={'kicadVersion':pcbnew.GetBuildVersion(),'rawCadSha256':sha(CAD),'sourceSha256':sha(SOURCE),'freshRefilledCadSha256':sha(OUT),'fourCopperLayers':True,'originalComponentContactsVerified':contacts,'physicalThroughVias':2,'manualBypassTrackSegments':3,'sourceZonePolicyReconstructed':zone_changes,'rows':rows,'bothReferencePlanesSingleIslandAtThisPartialStage':True,'allPackageSupplyAndGroundConnectivityQualified':False,'ddrSignalsPhysicallyRouted':0,'fullBoardDrcQualified':False,'impedanceAndTimingQualified':False,'fabricationReady':False}
REPORT.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
