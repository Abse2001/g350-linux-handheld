"""Root-only offline KiCad10 check: fresh98 approaches and24 physical graphs.

No SaveBoard/refill/routing/net repair. Drop only actual Source-owned copper-zone spans into a fresh
diagnostic copy; all footprint/via/segment bytes stay exact. Missing25 and
reference/electrical/global DRC limitations remain explicit.
"""
import argparse,importlib.util,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
CONTRACT=ROOT/'artifact_contract.py'
sp=importlib.util.spec_from_file_location('source26_stdlib_artifacts',CONTRACT);a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
HELPER=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-cad-source-next/child/inspect-local101-hs64.py')

def save(path,value):
 with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
 path.chmod(0o600)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--root-receipt',type=Path,required=True);parser.add_argument('--root-receipt-sha256',required=True);parser.add_argument('--output-directory',type=Path,required=True);args=parser.parse_args()
 a.require(os.environ.get('G350_SOURCE26_CAD_ROOT_GUARDED')=='1','Actual owned Root CAD/container guard required')
 manifest=ROOT/'SOURCE-manifest.json';m=json.loads(manifest.read_bytes());packet=a.sha(manifest)
 for row in m['files']+m['externalFiles']:a.binding(row)
 auth=a.authority({'path':str(args.root_receipt),'sha256':args.root_receipt_sha256},packet,m['scope'])
 out=args.output_directory.resolve();a.require(args.output_directory.is_absolute() and not args.output_directory.is_symlink() and out.is_dir() and str(out)==auth['outputDirectory'] and not any(out.iterdir()),'Fresh exclusive Root-owned CAD output directory required')
 result={'scope':m['scope'],'sourceManifestSha256':packet,'passed':False,'diagnosticCompleted':False,'apiAnglesFailed':False,'actualOriginalApiAngleFailures':[],'actualCollectedNativeToolWrapperExitCode':None,'actualNativePhysicalChildExitCode':None,'actualOriginalApiChildExitCode':None,'actualOriginalApiReport':a.ACTUAL_API,'actualNativeStageReport':a.ACTUAL_NATIVE_REPORT,'nativeAndOriginalApiStagesPassed':False,'complete26Accepted':False,'geometryFixesPending':False,'sourceRawOrSdkEdited':False,'rawExportEdited':False,'netRepairPerformed':False,'saveBoardPerformed':False,'refillPerformed':False,'allRuleDrcPerformed':False,'referenceQualified':False,'electricalTimingQualified':False,'accepted49':False,'fabricationReady':False,'expectedMissingOriginalSignalCount':23}
 held={str(manifest):packet,str(args.root_receipt):args.root_receipt_sha256}
 try:
  raw,controls=a.actual_core();signal=a.load({'path':str(a.SIGNAL_PROPOSAL),'sha256':a.SIGNAL_SHA});ix,signals,carriers,segment_count=a.derive_owned(raw,controls,signal)
  native,_=a.native_prerequisite(auth,carriers)
  result.update(actualCollectedNativeToolWrapperExitCode=0,actualNativePhysicalChildExitCode=0,actualOriginalApiChildExitCode=0,nativeAndOriginalApiStagesPassed=True)
  a.require(native['sourceManifestSha256']==m['requiresNativeSourceManifestSha256'],'Exact reviewed genuine26 Native/API source predecessor required')
  _,cli_post=a.collected(auth['actualCliCollection']);cli=a.produced(cli_post,auth['actualCliReport'])
  a.require(cli['exportPassed'] is True and cli['cliExitCode']==0 and cli['sourceManifestSha256']==packet and cli['actualCoreSha256']==a.RAW_SHA and cli['coreControlsSha256']==a.CONTROLS_SHA and cli['actualNativeReport']==auth['actualNativeReport'] and cli['apiAnglesFailed'] is False and cli['complete26Accepted'] is False and cli['nativeAndOriginalApiStagesPassed'] is True and cli['actualOriginalApiReport']==a.ACTUAL_API,'Actual successful genuine26 pinned CLI predecessor with the same Native proof required')
  export=auth['actualExport'];a.require(export['path']==cli['outputPath'] and export['sha256']==cli['outputSha256'] and any(r['path']==export['path'] and r['sha256']==export['sha256'] for r in cli_post['outputFiles']),'Export must be exact actual collected CLI output')
  export_path=a.regular(export['path']);a.require(a.sha(export_path)==export['sha256'] and export_path.stat().st_size<=32*1024*1024,'Actual export bytes/hash required')
  for r in m['files']+m['externalFiles']:held[r['path']]=r['sha256']
  for r in [auth['actualCoreCollection'],auth['actualCoreRaw'],auth['actualCoreControls'],auth['actualNativeCollection'],auth['actualNativeReport'],auth['actualApiCollection'],auth['actualOriginalApiReport'],auth['actualFresh49Model'],auth['actualFresh49ProjectionProof'],auth['actualCliCollection'],auth['actualCliReport'],export]:held[r['path']]=r['sha256']
  result.update(actualCorePath=str(a.RAW),actualCoreSha256=a.RAW_SHA,actualCoreControlsSha256=a.CONTROLS_SHA,actualExportPath=str(export_path),actualExportSha256=export['sha256'],actualDerivedSourceSegmentCount=segment_count,actualSourceOwnedGraphCount=len(carriers),inputHashesBefore=held.copy())
  helper_spec=importlib.util.spec_from_file_location('preserved_kicad_stdlib_geometry',HELPER);helper=importlib.util.module_from_spec(helper_spec);helper_spec.loader.exec_module(helper)
  a.require(a.sha(HELPER)=='a14ef195d87e8c8ca77bcb8b851e78333649bcff7c54712884d06f6e9ccd60f6','Authentic prior KiCad parsing/UUID/coordinate contract')
  pcb_bytes=export_path.read_bytes();tree=helper.parse_sexpressions(pcb_bytes);items={kind:helper.children(tree,kind) for kind in ['footprint','via','segment','zone']}
  zone_spec=importlib.util.spec_from_file_location('authentic_source_copper_and_keepout_projection',ROOT/'zone_contract.py');zone_mapper=importlib.util.module_from_spec(zone_spec);zone_spec.loader.exec_module(zone_mapper)
  zone_pins=a.load(auth['actualSourceZonePins']);a.require(zone_pins['actualCoreRawSha256']==a.RAW_SHA and zone_pins['actualExportPath']==str(export_path) and zone_pins['actualExportSha256']==export['sha256'],'Root-bound pins must derive from this exact actual fresh Core/CLI export')
  held[auth['actualSourceZonePins']['path']]=auth['actualSourceZonePins']['sha256']
  zonefree,zone_proof=zone_mapper.map_zones(raw,pcb_bytes,helper,zone_pins)
  a.require([len(items[k]) for k in ['footprint','via','segment']]==[507,227,segment_count] and len(items['zone'])==zone_proof['actualSourceCopperPourCount']+zone_proof['actualSourceKeepoutCount'],'All actual exporter geometry and authentic Source-derived pours+keepouts')
  result['actualSourceToRawZoneProjection']=zone_proof
  zonefree_path=out/'source26-copper-zone-free-with-keepouts.kicad_pcb'
  with zonefree_path.open('xb') as stream:stream.write(zonefree)
  zonefree_path.chmod(0o600)
  result['copperFreeDiagnosticCopy']={'path':str(zonefree_path),'sha256':a.sha(zonefree_path),'removedOnlyActualSourceCopperPourZones':zone_proof['removedOnlySourceMappedCopperZones'],'retainedByteExactHardwareKeepoutZones':zone_proof['retainedExactHardwareKeepoutZones'],'allFootprintViaSegmentKeepoutBytesHeld':True,'originalExportHeld':True}
  import wx
  wx.Log.SetLogLevel(wx.LOG_Error);application=wx.App(False)
  import pcbnew
  version=pcbnew.GetBuildVersion();a.require(version.startswith('10.0.6'),'Existing tested pinnedKiCad10.0.6 required')
  board=pcbnew.LoadBoard(str(zonefree_path));a.require(board is not None and board.GetCopperLayerCount()==4,'Four-layer fresh export must load')
  # Baseline94957 proves native inference of serialized net0 barrels. This is
  # normal LoadBoard/BuildConnectivity behavior, not a metadata repair adapter.
  board.BuildConnectivity()
  uid=lambda item:item.m_Uuid.AsString();xy=lambda p:[pcbnew.ToMM(p.x),pcbnew.ToMM(p.y)]
  footprints=list(board.GetFootprints());tracks=list(board.GetTracks());vias=[t for t in tracks if isinstance(t,pcbnew.PCB_VIA)];segments=[t for t in tracks if not isinstance(t,pcbnew.PCB_VIA)]
  a.require([len(footprints),len(vias),len(segments),len(list(board.Zones()))]==[507,227,segment_count,zone_proof['actualSourceKeepoutCount']],'All loaded actual geometry and exact retained hardware keepouts')
  a.require(not any(hasattr(pcbnew,'PCB_ARC') and isinstance(t,pcbnew.PCB_ARC) for t in segments),'No unmodeled arcs')
  native_footprints={uid(f):f for f in footprints};a.require(len(native_footprints)==507,'Unique actual footprint UUIDs')
  loaded_zones=list(board.Zones());expected_keepout_uuids={r['rawZoneUuid'] for r in zone_proof['zoneRows'] if r['sourceKind']=='pcb_keepout'}
  a.require({uid(zone) for zone in loaded_zones}==expected_keepout_uuids and all(zone.GetIsRuleArea() for zone in loaded_zones),'Only the two authentic hardware keepout rule areas remain loaded')
  mapped_components={}
  for cid in {ix['pcb_port'][s['actualNumericPcbPortId']]['pcb_component_id'] for s in signals}:
   component=ix['pcb_component'][cid];matches=[]
   for node in items['footprint']:
    pos=helper.values(node,'at')
    if helper.at([float(p) for p in pos[:2]],helper.transform(component['center']['x'],component['center']['y'])):
     ident=helper.values(node,'uuid')[0]
     if helper.converter_uuid('footprint:'+cid+':'+pos[0]+','+pos[1])==ident:matches.append(native_footprints[ident])
   mapped_components[cid]=helper.one(matches,'Exact actual Source numeric footprint')
  mapped_vias={}
  for vid,source_via in ix['pcb_via'].items():
   via=helper.one([v for v in vias if helper.at(xy(v.GetPosition()),helper.transform(source_via['x'],source_via['y']))],'One actual Source barrel')
   a.require(via.GetViaType()==pcbnew.VIATYPE_THROUGH and via.TopLayer()==pcbnew.F_Cu and via.BottomLayer()==pcbnew.B_Cu and helper.near(pcbnew.ToMM(via.GetWidth(pcbnew.F_Cu)),source_via['outer_diameter']) and helper.near(pcbnew.ToMM(via.GetDrillValue()),source_via['hole_diameter']),'Real barrel geometry/dimensions/fullspan')
   mapped_vias[vid]=via
  mapped_traces={};used_segment_owners={}
  def actual_trace(trace_id):
   if trace_id in mapped_traces:return mapped_traces[trace_id]
   trace=ix['pcb_trace'][trace_id];matched=[]
   for p,q in zip(trace['route'],trace['route'][1:]):
    if (p['x'],p['y'])==(q['x'],q['y']):continue
    a.require(p['route_type']==q['route_type']=='wire' and p['layer']==q['layer'],'Same-layer actual Source segment')
    start,end=helper.transform(p['x'],p['y']),helper.transform(q['x'],q['y'])
    item=helper.one([s for s in segments if board.GetLayerName(s.GetLayer())==helper.LAYER_NAMES[p['layer']] and helper.near(pcbnew.ToMM(s.GetWidth()),p['width']) and ((helper.at(xy(s.GetStart()),start) and helper.at(xy(s.GetEnd()),end)) or (helper.at(xy(s.GetStart()),end) and helper.at(xy(s.GetEnd()),start)))],'One actual Source-owned serialized segment')
    ident=uid(item);a.require(ident not in used_segment_owners or used_segment_owners[ident]==trace_id,'No foreign Source trace may reuse another serialized segment');used_segment_owners[ident]=trace_id;matched.append(item)
   a.require(matched,'Nonempty authentic Source trace');mapped_traces[trace_id]=matched;return matched
  # Geometry bijection for ALL289 traces, not merely the selected26 carriers.
  for trace_id in ix['pcb_trace']:actual_trace(trace_id)
  a.require(len(used_segment_owners)==segment_count,'Exact complete nonzero Source segment bijection')
  connectivity=board.GetConnectivity();linked=lambda item:{uid(v) for v in connectivity.GetConnectedItems(item)}|{uid(item)}
  observations=[];pads={}
  for s in signals:
   numeric=ix['pcb_port'][s['actualNumericPcbPortId']];sp=ix['source_port'][numeric['source_port_id']]
   pad=helper.one([p for p in mapped_components[numeric['pcb_component_id']].Pads() if p.GetNumber()==str(sp['pin_number']) and helper.at(xy(p.GetPosition()),helper.transform(numeric['x'],numeric['y']))],'Real Source numeric pin pad and location')
   pads[s['actualNumericPcbPortId']]=pad;via=mapped_vias[s['actualViaId']];stub=actual_trace(s['actualPcbTraceId']);net=pad.GetNetCode();connected=linked(pad)
   agreement=net!=0 and all(t.GetNetCode()==net and t.GetNetname()==pad.GetNetname() for t in stub) and via.GetNetCode()==net and via.GetNetname()==pad.GetNetname()
   observations.append({**s,'actualNumericPin':sp['pin_number'],'actualPadUuid':uid(pad),'actualBarrelUuid':uid(via),'actualTopstubSegmentUuids':[uid(t) for t in stub],'actualPadNetCode':net,'actualPadNetName':pad.GetNetname(),'actualBarrelNetCode':via.GetNetCode(),'actualBarrelNetName':via.GetNetname(),'allOwnedLocalItemsSameNonzeroNet':agreement,'actualPadPhysicallyConnectedToOwnBarrelAndTopstub':uid(via) in connected and all(uid(t) in connected for t in stub)})
  graphs=[]
  for c in carriers:
   cpu=pads[c['actualCpuNumericPcbPortId']];ram=pads[c['actualRamNumericPcbPortId']];connected=linked(cpu);owned=[t for trace_id in c['actualDirectPcbTraceIds'] for t in actual_trace(trace_id)]+[mapped_vias[c['actualCpuViaId']],mapped_vias[c['actualRamViaId']]]
   same_net=cpu.GetNetCode()!=0 and ram.GetNetCode()==cpu.GetNetCode() and ram.GetNetname()==cpu.GetNetname() and all(t.GetNetCode()==cpu.GetNetCode() and t.GetNetname()==cpu.GetNetname() for t in owned)
   physically_connected=uid(ram) in connected and all(uid(t) in connected for t in owned)
   graphs.append({**c,'actualCpuPadUuid':uid(cpu),'actualRamPadUuid':uid(ram),'actualCpuPadNetCode':cpu.GetNetCode(),'actualRamPadNetCode':ram.GetNetCode(),'actualOwnedCopperUuids':[uid(t) for t in owned],'actualOwnedCopperNetCodes':[t.GetNetCode() for t in owned],'allOwned26GraphItemsSameNonzeroNet':same_net,'actualCpuToRamAndEveryOwnedPathItemPhysicallyConnected':physically_connected})
  result.update(diagnosticCompleted=True,actualKiCadVersion=version,actualLoadedFootprints=507,actualLoadedVias=227,actualLoadedSegments=segment_count,actualLoadedLayerCount=4,actualRetainedNativeHardwareKeepoutZones=len(loaded_zones),actualNativeCopperPourZones=0,all289SourceTracesMappedBijectively=True,signalObservations=observations,actual26GraphObservations=graphs,actualLocalNetAgreementCount=sum(o['allOwnedLocalItemsSameNonzeroNet'] for o in observations),actualLocalPhysicalApproachCount=sum(o['actualPadPhysicallyConnectedToOwnBarrelAndTopstub'] for o in observations),actual26NonzeroNetGraphCount=sum(g['allOwned26GraphItemsSameNonzeroNet'] for g in graphs),actual26PhysicalCpuRamGraphCount=sum(g['actualCpuToRamAndEveryOwnedPathItemPhysicallyConnected'] for g in graphs),nativeNetInferenceAllowedAndObservedWithoutRawRepair=True)
  save(out/'actual-net-and-physical-graph-observations.json',result)
  a.require(result['actualLocalNetAgreementCount']==result['actualLocalPhysicalApproachCount']==98 and result['actual26NonzeroNetGraphCount']==result['actual26PhysicalCpuRamGraphCount']==26,'Fresh actual98 local approaches/all26 physical Source-owned graphs must pass')
  result.update(passed=True,status='NARROW_FRESH_KICAD_98_LOCAL_APPROACHES_AND26_SOURCE_OWNED_GRAPHS_PASS')
 except Exception as error:result.update(failure=type(error).__name__+': '+str(error),status='FAILED_FRESH_KICAD_SOURCE26_NARROW_DIAGNOSTIC')
 result['inputHashesAfter']={p:a.sha(p) for p in held};result['allInputBytesHeld']=result['inputHashesAfter']==held
 if not result['allInputBytesHeld']:result.update(passed=False,failure='Immutable Source/raw/export/authority input changed')
 save(out/'kicad-source26-report.json',result)
 print(json.dumps({k:result.get(k) for k in ['passed','diagnosticCompleted','failure','actualLocalPhysicalApproachCount','actual26PhysicalCpuRamGraphCount','actualDerivedSourceSegmentCount','allInputBytesHeld','expectedMissingOriginalSignalCount','referenceQualified','electricalTimingQualified','accepted49','fabricationReady']}));return 0 if result['passed'] else 2
if __name__=='__main__':raise SystemExit(main())
