"""SOURCE-ONLY DRAFT. Root performs copies and creates fresh CAD authority.
This stdlib checker verifies sparse copied bytes and emits readonly Docker mounts.
It performs no file writes, subprocess calls, authority creation or SDK imports.
"""
import hashlib,json,re,stat,sys
from pathlib import Path

CAD_PARENT_PREFIX='g350-source26-cad-root-'

def require(value,message):
    if not value:raise ValueError(message)

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def checked(row,path=None):
    original=Path(row['path']);p=Path(path) if path is not None else original
    require(p.is_absolute()and p.resolve()==p,'Exact absolute path without symlink ancestors')
    q=p.lstat();require(stat.S_ISREG(q.st_mode)and not p.is_symlink(),'Regular nonsymlink snapshot file')
    require(q.st_size==row['bytes']and stat.S_IMODE(q.st_mode)==row['mode']and digest(p)==row['sha256'],'Byte/size/mode-identical original or snapshot')
    return p

def load(row):return json.loads(checked(row).read_bytes())

def tmp_root(path):
    p=Path(path);require(len(p.parts)>=4 and p.parts[1]=='tmp','Finite /tmp child path')
    return Path('/tmp')/p.parts[2]

def validate_snapshot_plan(plan):
    CAD_PARENT=Path(plan['newCadAuthority']['path']).parent
    require(CAD_PARENT.parent==Path('/tmp')and re.fullmatch(CAD_PARENT_PREFIX+'[A-Za-z0-9_-]+',CAD_PARENT.name)is not None and CAD_PARENT.resolve()==CAD_PARENT,'Exact owned temporary CAD run parent')
    source=plan['runtimeSourceManifest']
    require(source=={'path': '/tmp/g350-source26-cli-cad-api50-authentic-activation-sourceonly-next/SOURCE-manifest.json', 'sha256': 'e7520b13ed47872a1111b35b76b09d69ef669118ac1f765f4859f8fc45539b4f', 'bytes': 19882, 'mode': 384},'Exact reviewed final CoreCalls-corrected runtime manifest')
    runtime=load(source)
    require(re.fullmatch('[0-9a-f]{64}',source['sha256'])is not None,'Reviewed exact runtime source pin')
    require(source['path'].startswith('/tmp/g350-source26-')and Path(source['path']).name=='SOURCE-manifest.json','Explicit Source26 runtime manifest')
    cli=load(plan['actualClosedCliCollection']);require(cli['authorizedByRoot']is True and cli['toolSessionCollected']is True and cli['passed']is True and cli['toolExitCode']==cli['toolWrapperExitCode']==0,'Actual collected CLI43 prerequisite')
    post=load(plan['actualCliPostaudit']);require(cli['postauditPath']==plan['actualCliPostaudit']['path']and cli['postauditSha256']==plan['actualCliPostaudit']['sha256']and cli['execution']==post['execution'],'Exact collected CLI postaudit')
    e=post['execution'];require(e['exitCode']==0 and e['cleanupOwnedGroupEmpty']is True and e['diagnosticStopped']is False and not any(e['oomDelta'].values())and cli['sourceAndDependenciesHeld']is post['sourceAndDependenciesHeld']is True,'Actual CLI natural0/groupempty/OOM0/sourceheld')
    require(cli['sourceManifestSha256']==post['sourceManifestSha256']==source['sha256'],'Same reviewed runtime packet')
    cli_root=tmp_root(plan['actualCliPostaudit']['path']);require(cli_root.name.startswith('g350-source26-cli-root-'),'Only actual collected CLI root may be mounted')
    report=load(plan['actualCliReport']);require(report['exportPassed']is True and report['cliExitCode']==0 and report['sourceManifestSha256']==source['sha256'],'Actual pinned CLI export')
    require(report['outputPath']==plan['actualExport']['path']and report['outputSha256']==plan['actualExport']['sha256'],'Exact actual export binding')
    for row in (plan['actualCliReport'],plan['actualExport']):
        checked(row);require(tmp_root(row['path'])==cli_root and any(r['path']==row['path']and r['sha256']==row['sha256']for r in post['outputFiles']),'Only actually produced CLI artifacts')
    for key,name in [('newCadAuthority','ROOT_CAD_AUTHORITY.json'),('actualSourceZonePins','SOURCE_ZONE_PINS.json')]:
        checked(plan[key]);require(Path(plan[key]['path'])==CAD_PARENT/name,'Fresh CAD-only owned temporary authority/zone pins; never copy old authority/BOUND')
    snapshot_root=Path(plan['snapshotRoot']);require(snapshot_root.parent==CAD_PARENT/'snapshots'and re.fullmatch('[0-9a-f]{32}',snapshot_root.name)is not None and snapshot_root.resolve()==snapshot_root,'Owned finite temporary snapshot root')
    required=[*runtime['files'],*runtime['externalFiles'],source,plan['actualCliPostaudit'],plan['actualCliReport'],plan['actualExport']]
    rows={}
    for row in required:
        if not row['path'].startswith('/tmp/'):continue
        require(row['path']not in rows or rows[row['path']]==row,'No conflicting original bindings')
        rows[row['path']]=row
    forbidden={'ROOT_AUTHORITY.json','ROOT_CAD_AUTHORITY.json','BOUND-manifest.json','BOUND_MANIFEST.json','BOUND.json'}
    require(not any(Path(p).name in forbidden for p in rows),'Historical authority and BOUND files excluded from snapshots')
    declared=plan['snapshots'];require(len(declared)==len(rows),'Exact sparse allowlist, no unbound copied files')
    original_paths={r['originalPath']for r in declared};require(len(original_paths)==len(declared)and original_paths==set(rows),'Every required original /tmp file exactly once')
    roots={};copies=set()
    for mapping in declared:
        original=Path(mapping['originalPath']);root=tmp_root(original);target=snapshot_root/root.name;copy=target/original.relative_to(root)
        require(mapping['snapshotPath']==str(copy),'Preserved exact relative artifact path')
        checked(rows[str(original)]);checked(rows[str(original)],copy);copies.add(copy);roots[root]=target
    observed=set()
    for target in roots.values():
        require(target.is_dir()and target.resolve()==target,'Exact snapshot mount source')
        for p in target.rglob('*'):
            require(not p.is_symlink(),'No snapshot symlinks')
            if p.is_file():observed.add(p)
            else:require(p.is_dir(),'No special snapshot entries')
    require(observed==copies,'Sparse snapshot directory contains only exact allowlisted files')
    mounts=[]
    for original,target in sorted(roots.items(),key=lambda item:str(item[0])):
        require(all(re.fullmatch('[A-Za-z0-9_./-]+',str(p))is not None for p in (original,target)),'Safe exact Docker mount paths')
        mounts += ['--mount','type=bind,source='+str(target)+',target='+str(original)+',readonly']
    for key in ('newCadAuthority','actualSourceZonePins'):
        current=checked(plan[key])
        require(all(re.fullmatch('[A-Za-z0-9_./-]+',str(p))is not None for p in (current,)),'Safe exact current CAD file mount')
        mounts += ['--mount','type=bind,source='+str(current)+',target='+str(current)+',readonly']
    return mounts

def main():
    require(len(sys.argv)==3,'Bound snapshot-plan path and sha required')
    p=Path(sys.argv[1]);require(p.is_absolute()and p.resolve()==p and re.fullmatch('[0-9a-f]{64}',sys.argv[2])is not None and digest(p)==sys.argv[2],'Exact Root-reviewed snapshot plan')
    args=validate_snapshot_plan(json.loads(p.read_bytes()))
    sys.stdout.buffer.write(b'\0'.join(a.encode()for a in args)+b'\0')

if __name__=='__main__':main()
