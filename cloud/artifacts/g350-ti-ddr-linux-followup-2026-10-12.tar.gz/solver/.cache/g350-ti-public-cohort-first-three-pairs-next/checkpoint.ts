import { strict as assert } from "node:assert"
import { deriveFreshAllocation, type InitialResult } from "./derive-allocation"
import type { SimpleRouteJson } from "./source/lib/types"

/** Data-only continuation of the trusted actual public initializer. No rerun. */
export function pairedViewFromPublicCheckpoint(
  input: SimpleRouteJson,
  unrestricted: SimpleRouteJson,
  result: InitialResult,
  options: { targetLayers: Array<[string, string]>; attempt: number },
  report: any,
  post: any,
) {
  assert.equal(post.resultTrustEligible, true)
  assert.equal(report.publicPipelineExecuted, true)
  assert.equal(report.initializerPassed, true)
  assert.equal(report.boundaryQualified, true)
  assert.equal(report.targetsHeld, true)
  assert.equal(report.requestedLayersHeld, true)
  assert.equal(report.control.initializerCalls, 1)
  assert.equal(report.control.surfaceBodyAdvances, 0)
  assert.equal(report.initialization.inventoryValid, true)
  assert.equal(report.initialization.uniformViaCountWithinEachBus, true)
  assert.equal(options.attempt, 0)
  assert.deepEqual(options.targetLayers, report.actualTargetLayers)
  const normalized = {
    ...input,
    buses: input.buses!.map((bus) => ({
      ...bus,
      allowedLayers: ["top", "bottom"],
      preferredLayers: ["bottom", "top"],
    })),
  }
  assert.deepEqual(normalized, unrestricted)
  assert.equal(input.connections.length, 49)
  assert.equal(input.obstacles.length, 856)
  assert.equal(input.traces!.length, 2)
  const targets = new Map(options.targetLayers)
  assert.equal(targets.size, 49)
  assert.equal(
    [...targets.values()].filter((layer) => layer === "top").length,
    37,
  )
  assert.equal(
    [...targets.values()].filter((layer) => layer === "bottom").length,
    12,
  )
  for (const bus of input.buses!) {
    const expected = ["DDR_BYTE0", "DDR_RESET"].includes(bus.busId)
      ? "bottom"
      : "top"
    assert.deepEqual(bus.allowedLayers, [expected])
    assert.deepEqual(bus.preferredLayers, [expected])
    assert.ok(
      bus.connectionNames.every((name) => targets.get(name) === expected),
    )
  }
  const fresh = deriveFreshAllocation(input, result)
  assert.equal(fresh.escapes.length, 24)
  assert.equal(fresh.terminalLayers.size, 0)
  assert.equal(fresh.allocation.traces!.length, 6)
  assert.deepEqual(fresh.allocation.traces!.slice(0, 2), unrestricted.traces)
  const pairs = fresh.allocation.differentialPairs!
  const actualLayers = pairs.map((pair) => {
    const members = pair.connectionNames.map(
      (name) =>
        result.connections.find((connection) => connection.name === name)!,
    )
    const layers = [
      ...new Set(
        members.flatMap((connection) =>
          connection.pointsToConnect.map((point) => point.layer),
        ),
      ),
    ]
    assert.equal(layers.length, 1)
    assert.ok(layers[0] === "top" || layers[0] === "bottom")
    return layers[0]
  })
  assert.deepEqual(actualLayers, ["bottom", "top", "top"])
  return { ...fresh, actualLayers, targets }
}
