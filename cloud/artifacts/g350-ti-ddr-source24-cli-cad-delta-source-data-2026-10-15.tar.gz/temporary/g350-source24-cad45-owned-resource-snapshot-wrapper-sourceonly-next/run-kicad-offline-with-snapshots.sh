#!/usr/bin/env bash
# SOURCE ONLY. Root owns the actual serial guard and container invocation.
set -euo pipefail
board_root=/workspace/g350-linux-handheld
docker_local=(bash "$board_root/scripts/cloud-docker.sh")
image_id=sha256:11b9360b20752e87f20942639e229b0d111e96f6e30b1bd1cb2eaafce9f26cfc
[[ $# -ge 5 ]]
output_dir=$(realpath -e "$1")
container_name=$2
snapshot_plan=$3
snapshot_plan_sha=$4
shift 4
[[ "$output_dir" =~ ^/tmp/g350-source24-cad-root-[A-Za-z0-9_-]+/output$ ]]
[[ "$container_name" =~ ^g350-source24-fresh-cad-[0-9a-f]{16}-[0-9a-f]{16}$ ]]
[[ "${G350_SOURCE24_CAD_ROOT_GUARDED:-}" == 1 ]]
[[ $("${docker_local[@]}" image inspect "$image_id" --format '{{.Id}}') == "$image_id" ]]
[[ -z $("${docker_local[@]}" ps --all --quiet --filter "name=^/${container_name}$") ]]
resource_report="${output_dir%/output}/cad-resource-observations.json"
record_resources() {
  local observed_phase=$1 observed_empty=$2 observed_outcome=$3
  local observed_image observed_driver observed_root observed_bytes
  observed_image=$("${docker_local[@]}" image inspect "$image_id" --format '{{.Id}}') || return 2
  observed_driver=$("${docker_local[@]}" info --format '{{.Driver}}') || return 2
  observed_root=$("${docker_local[@]}" info --format '{{.DockerRootDir}}') || return 2
  observed_bytes=$("${docker_local[@]}" image inspect "$image_id" --format '{{.Size}}') || return 2
  python3 -B /tmp/g350-source24-cad45-owned-resource-snapshot-wrapper-sourceonly-next/record_cad_resources.py "$resource_report" "$observed_phase" "$container_name" "$image_id" "$observed_image" "$observed_driver" "$observed_root" "$observed_bytes" "$observed_empty" "$observed_outcome"
}
record_resources BEFORE_CONTAINER unknown 0
# Reuse the tested VFS disk requirement. Never load/build/pull a missing image
# or alter daemon/client proxy configuration. This stage has no network.
if [[ $("${docker_local[@]}" info --format '{{.Driver}}') == vfs ]]; then
  docker_root=$("${docker_local[@]}" info --format '{{.DockerRootDir}}')
  image_bytes=$("${docker_local[@]}" image inspect "$image_id" --format '{{.Size}}')
  python3 -B - "$docker_root" "$image_bytes" <<'PY'
import shutil,sys
available=shutil.disk_usage(sys.argv[1]).free
required=2*int(sys.argv[2])+256*1024*1024
if available<required:raise SystemExit('Existing KiCad VFS disk reserve fails; preserve source/image and stop')
PY
fi
scratch=$(mktemp -d /tmp/g350-source24-fresh-cad.XXXXXX)
mkdir -p "$scratch/xdg-config" "$scratch/xdg-cache" "$scratch/xdg-data"
for area in config cache data; do
  if [[ -d "$board_root/.cloud-tools/xdg-$area" ]]; then
    cp -a "$board_root/.cloud-tools/xdg-$area/." "$scratch/xdg-$area/"
  fi
done
cleanup() {
  outcome=$?
  trap - EXIT TERM INT
  # The daemon container is outside the host process group. Remove only this
  # uniquely named owned container, then preserve the actual worker status.
  if [[ -n $("${docker_local[@]}" ps --all --quiet --filter "name=^/${container_name}$") ]]; then
    "${docker_local[@]}" rm --force "$container_name" >/dev/null || outcome=2
  fi
  # Independently re-query only this uniquely owned container after cleanup.
  owned_container_empty=unknown
  if owned_container_ids=$("${docker_local[@]}" ps --all --quiet --filter "name=^/${container_name}$"); then
    if [[ -z "$owned_container_ids" ]]; then owned_container_empty=true; else owned_container_empty=false; outcome=2; fi
  else
    outcome=2
  fi
  if ! record_resources AFTER_CLEANUP "$owned_container_empty" "$outcome"; then outcome=2; fi
  rm -rf -- "$scratch"
  exit "$outcome"
}
trap cleanup EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
python3 -B /tmp/g350-source24-cad45-owned-resource-snapshot-wrapper-sourceonly-next/check_cad_snapshots.py "$snapshot_plan" "$snapshot_plan_sha" >"$scratch/snapshot-mounts.nul"
mapfile -d '' -t snapshot_mounts <"$scratch/snapshot-mounts.nul"
"${docker_local[@]}" run --rm --init -i --name "$container_name" \
  --user "$(id -u):$(id -g)" --network none \
  --memory 2147483648 --memory-swap 2147483648 --cpus 2 --pids-limit 256 \
  --read-only --tmpfs /tmp:rw,nosuid,size=512m \
  --tmpfs /tmp/.X11-unix:rw,nosuid,size=1m,mode=1777 \
  -v /workspace:/workspace:ro -v "$output_dir:$output_dir:rw" \
  "${snapshot_mounts[@]}" \
  -v "$scratch:/g350-runtime:rw" -w "$board_root" \
  -e PYTHONPATH="$board_root/.cloud-tools/python-compat" \
  -e PYTHONDONTWRITEBYTECODE=1 -e G350_SOURCE24_CAD_ROOT_GUARDED=1 \
  -e XDG_CONFIG_HOME=/g350-runtime/xdg-config \
  -e XDG_CACHE_HOME=/g350-runtime/xdg-cache \
  -e XDG_DATA_HOME=/g350-runtime/xdg-data \
  "$image_id" xvfb-run -a /usr/bin/python3 -B "$@"
