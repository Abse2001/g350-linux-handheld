"""Freeze passive source914 V6 prefix PREP; no production imports, constructors or authority."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,stat
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/bus-lanes-solver')
BASE=REPO/'.cache/g350-ti-v6-public-grid-prefix-telemetry-next'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def item(path,relative=False):
 if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):raise ValueError('Regular exact file required '+str(path))
 return {'path':str(path.relative_to(ROOT)) if relative else str(path),'bytes':path.stat().st_size,'sha256':sha(path),'mode':stat.S_IMODE(path.stat().st_mode)}
if (ROOT/'run').exists() or (ROOT/'root-launch-receipt.json').exists():raise ValueError('Fresh runtime and authority paths required')
base=json.loads((BASE/'packet-manifest.json').read_bytes());plan=json.loads((ROOT/'plan.json').read_bytes())
spec=importlib.util.spec_from_file_location('freeze_source914',ROOT/'source-audit.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit);source=audit.verify()
policy=plan['policy']
(ROOT/'launch-receipt.TEMPLATE.json').write_text(json.dumps({'authorizedByRoot':False,'scope':plan['scope'],'packetSha256':'ROOT_REVIEWED_PACKET_REQUIRED','policy':policy,'approvalToken':'ROOT_NEW_NONCE_REQUIRED','accepted49':False},indent=2)+'\n')
files=[item(p,True) for p in sorted(ROOT.rglob('*')) if p.is_file() and not p.is_symlink() and not any(part in {'node_modules','__pycache__','run'} for part in p.relative_to(ROOT).parts) and p.name not in {'packet-manifest.json','root-launch-receipt.json','final-preflight-validation.json'}]
external=[Path(row['path']) for row in base['externalFiles']]
external += [REPO/'.cache/g350-source914-actual-surface-priority-pair-observability-review.json',BASE/'packet-manifest.json',BASE/'runner.ts',BASE/'public-pipeline-protocol.ts',BASE/'guard.py',BASE/'run/execution.json',BASE/'run/postflight.json',BASE/'run/latest-grid-telemetry.json',BASE/'run/public-progress.jsonl',REPO/'.cache/g350-ti-top-clock-reachability-precheck-next/grid-telemetry.ts']
absent=[];bound={str(ROOT/f['path']) for f in files}
for name in base['requiredAbsentRuntimeFiles']:
 name=name.replace(str(BASE),str(ROOT));p=Path(name)
 if name in bound:continue
 if p.exists() or p.is_symlink():raise ValueError('Unbound resolver appeared '+name)
 absent.append(name)
manifest={k:base[k] for k in ['schemaVersion','sourceRevision','libTree','gitTree','publishedGitCommitVerified','sourceClosureSha256','sourceFileCount','sourceManifestSha256','libraryManifestSha256','releaseSha256','copiedRuntimeMembers','requestedOptions','defaultGoalAndCaps','dependencyReceiptSha256','dependencyTreeSha256','dependencyArchiveSha256','excludedMutableGitBindings']}
manifest.update({'preparedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'externalFiles':[item(p) for p in sorted(set(external))],'requiredAbsentRuntimeFiles':absent,'policy':policy,'captureLimits':plan['observationLimits'],'inputBindings':{name:item(ROOT/name,True) for name in ['input.json','original-unrestricted-input.json','input-derivation.json']},'scope':plan['scope'],'observationScope':plan['algorithm'],'first64JobRowsOnly':True,'prefixOnly':True,'priorOutcome':'Root-collected ed59 external wallstop25ksteps. Prior Grid data is historical only; no captured body is a routing input.','actual49ConstructorCalls':0,'actualLaunchCount':0,'rootActualGoRequired':True,'authorityPathExcludedAndAbsentAtFreeze':True,'accepted49':False,'tiEligibleBoard':False,'fabricationReady':False})
(ROOT/'packet-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'packetSha256':sha(ROOT/'packet-manifest.json'),'files':len(files),'external':len(manifest['externalFiles']),'source':source,'actual49ConstructorCalls':0}))
