def closed70():
   assert proposal['actual70Sealed']is True,'Future genuine successful CLI70 receipt remains unbound'
   prior=closed69();assert prior['actualClosedScopeCount']==69
   for key in('actual70CollectionPin','actual70PostauditPin','actual70ReportPin','actual70ExportPin','actual70AuthorityPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
   r=read(proposal['actual70CollectionPin']['path']);p=read(proposal['actual70PostauditPin']['path']);v=read(proposal['actual70ReportPin']['path']);e=r['execution']
   assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==proposal['actual70ToolSessionId'] and r['toolWrapperExitCode']==r['toolExitCode']==0
   assert r['scope']==p['scope']=='ROOT_SOURCE32_FRESH_PINNED_CLI_WITH69_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cli'
   assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli32PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual70GuardManifestPin']['sha256']
   assert sha(r['postauditPath'])==r['postauditSha256']==proposal['actual70PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior and p['execution']==e
   for doc in(r,p):
    for key in('passed','resultPassed','stageNaturallyCompleted','ownedChildNatural0','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareAcceptanceCheckpointUnchanged'):assert doc[key]is True
    for key in('runFailure','postverificationFailure','resultInspectionFailure'):assert doc[key]is None
    for key in('Source32Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
    assert doc['cliCalls']==1 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cadCalls']==doc['newRoutesAdopted']==0
   assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
   h.finite(e,0);assert e['policy']==cli32_policy and e['pid']==e['pgid']==proposal['actual70Pgid'] and e['currentGuardPid']==proposal['actual70GuardPid'] and c.guard.process_scope.owned(proposal['actual70Pgid'])==[]and not Path('/proc',str(proposal['actual70GuardPid'])).exists()
   assert r['independentlyObservedOwnedGroupEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentProcReadErrors']==[]
   assert e['command']==[cli32_contract['pythonInterpreterPin']['path'],'-B',cli32_contract['cliWorkerPin']['path'],'--root-receipt',proposal['actual70AuthorityPin']['path'],'--root-receipt-sha256',proposal['actual70AuthorityPin']['sha256'],'--output-directory',str(Path(proposal['actual70ExportPin']['path']).parent)]
   assert r['reportPath']==p['reportPath']==proposal['actual70ReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual70ReportPin']['sha256']and r['exportPath']==p['exportPath']==proposal['actual70ExportPin']['path']and sha(r['exportPath'])==r['exportSha256']==p['exportSha256']==proposal['actual70ExportPin']['sha256']
   assert r['actualCoreSha256']==p['actualCoreSha256']==v['actualCoreSha256']==proposal['actual67CoreRawPin']['sha256']and r['actualCoreControlsSha256']==p['actualCoreControlsSha256']==v['coreControlsSha256']==proposal['actual67CoreControlsPin']['sha256']
   assert v['scope']==cli32_preparation['scope']and v['sourceManifestSha256']==proposal['cli32PreparationPin']['sha256']and v['exportPassed']is v['byteIdenticalCopyOnly']is v['nativeAndOriginalApiStagesPassed']is True and v['cliExitCode']==0
   assert v['recognizedCircuitJsonSha256']==proposal['actual67CoreRawPin']['sha256']and v['outputPath']==proposal['actual70ExportPin']['path']and v['outputSha256']==proposal['actual70ExportPin']['sha256']and v['actualSourceSegmentCount']==1116 and v['actualSourceOwnedCarrierCount']==32 and v['actualPhysicalViaCount']==229 and v['actualPhysicalTraceCount']==297 and v['sourceOnlyMissingRoutes']==17
   assert v['actualNativeReport']==proposal['actual68ReportPin']and v['actualOriginalApiReport']==proposal['actual69ApiReportPin']
   assert v['argv']==[cli32_preparation['bun'],'--smol',cli32_preparation['cliMainPath'],'export',str(Path(proposal['actual70ExportPin']['path']).parent/'fresh-source32.circuit.json'),'--format','kicad_pcb','--output',proposal['actual70ExportPin']['path'],'--disable-parts-engine']
   for key in('originalRawEdited','sourceModuleEvaluated','sourcePortHookReplayedByCli','automaticCoreSrjUsed','complete32Accepted','referenceQualified','electricalTimingQualified','accepted49','fabricationReady'):assert v[key]is False
   for row in p['outputFiles']:binding(row)
   prior['actual70Source32CliSuccessCollectionPin']={'path':proposal['actual70CollectionPin']['path'],'sha256':proposal['actual70CollectionPin']['sha256']};prior['actualClosedScopeCount']=70;prior['actual70CliDoesNotQualifyFreshCadOrFull49']=True
   return prior
