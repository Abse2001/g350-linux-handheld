"""Root-only reuse of collected actual Core; no render/types/capture/export."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
 if len(sys.argv)!=2 or sys.argv[1]!='readonly' or os.environ.get('G350_PACKAGE_READONLY_STAGE')!='readonly':raise ValueError('Exact Root readonly stage required')
 manifest=ROOT/'PREPARED-manifest.json';m=json.loads(manifest.read_bytes())
 if os.environ.get('G350_PACKAGE_READONLY_PACKET_SHA')!=sha(manifest):raise ValueError('Readonly packet changed')
 auth=Path(os.environ['G350_PACKAGE_READONLY_ROOT_RECEIPT']);a=json.loads(auth.read_bytes())
 if sha(auth)!=os.environ['G350_PACKAGE_READONLY_ROOT_RECEIPT_SHA'] or a.get('authorizedByRoot') is not True or a.get('phase')!='readonly' or a.get('packetSha256')!=sha(manifest):raise ValueError('Root readonly receipt differs')
 run=ROOT/'run-readonly';actual=Path(m['existingActualCorePath']);expected=m['existingActualCoreSha256']
 if sha(actual)!=expected:raise ValueError('Existing actual Core changed')
 report={'phase':'readonly','packetSha256':sha(manifest),'commands':[],'passed':False,'coreBuildCount':0,'typecheckCount':0,'sourceCaptureCount':0,'cliCalls':0,'routingCalls':0,'cadCalls':0,'existingActualCoreSha256':expected,'accepted49':False,'fabricationReady':False}
 def save():(run/'result.json').write_text(json.dumps(report,indent=2)+'\n')
 def command(name,argv):
  started=time.monotonic()
  with (run/(name+'.log')).open('xb') as out:result=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT,check=False)
  report['commands'].append({'name':name,'argv':argv,'exitCode':result.returncode,'seconds':time.monotonic()-started});save()
  if result.returncode:raise ValueError('Readonly command failed: '+name)
 try:
  command('strict-seven-owned-top-alias-keys',[m['pinnedPython'],'-B',str(ROOT/'pinned-python-forward.py'),str(actual),expected,str(run/'actual-source-forward.json'),str(run/'python-gate.json')])
  command('unchanged-native17-plus101-package64-hs-owned-manufacturing',[m['bun'],'--smol',str(ROOT/'check-fresh-native-package-hs-loops.mjs'),str(actual),expected,str(run/'native-loop-report.json')])
  forward=json.loads((run/'actual-source-forward.json').read_bytes());native=json.loads((run/'native-loop-report.json').read_bytes())
  if not(forward['sourceForwardPassed'] is True and forward['allAcceptedHs64PhysicalRecordsExact'] is True and len(forward['originalOptionalTopAliasKeyAdditionsOnly'])==7 and forward['allOtherOriginalSourcePortFieldsExact'] is True and native['sourceSha256']==expected and native['checkCount']==18 and native['physicalErrors']==0 and len(native['retainedHsTerminalLoops'])==64 and len(native['packageTerminalLoops'])==101 and native['rawNative17InputUnmodified'] is True and native['noViaOrTraceForeignOwnerRewritten'] is True):raise ValueError('Seven-alias strict forward/native/physical graph gate failed')
  if sha(actual)!=expected:raise ValueError('Actual Core was changed by readonly verification')
  report.update(passed=True,sourceForwardSha256=sha(run/'actual-source-forward.json'),nativeLoopReportSha256=sha(run/'native-loop-report.json'),pythonGateSha256=sha(run/'python-gate.json'),only7ProvedAbsentToDerivedOriginalAliasKeys=True,allOriginalOtherSourceFieldsAndHs64CopperHeld=True,native17Passed=True,local101PackageAnd64HsNumericGraphsPassed=True,strictKnownOwnerManufacturingPassed=True)
  save();print(json.dumps({'phase':'readonly','passed':True,'existingActualCoreSha256':expected,'coreBuildCount':0,'accepted49':False}));return 0
 except BaseException as error:
  report['failure']=str(error);save();raise
if __name__=='__main__':raise SystemExit(main())
