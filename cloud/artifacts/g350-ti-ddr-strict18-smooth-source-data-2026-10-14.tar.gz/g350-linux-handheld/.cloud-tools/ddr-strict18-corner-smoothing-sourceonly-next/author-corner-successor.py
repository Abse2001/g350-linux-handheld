"""Author one conservative, length-restored three-carrier successor; stdlib only."""
import importlib.util,json,copy,math,hashlib,collections,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('stable_corner_geometry',HERE/'smooth-corners-stable.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
R=.102;records=copy.deepcopy(m.original);change={};started=time.monotonic()
def plen(p):return m.length([m.xy(q)for q in p])
def target_bisect(fn,lo,hi,target):
 assert fn(lo)[0]<target<fn(hi)[0]
 for _ in range(55):
  mid=(lo+hi)/2
  if fn(mid)[0]<target:lo=mid
  else:hi=mid
 x=(lo+hi)/2;return x,fn(x)
# The virtual tangent intersection is not a physical copper vertex. Restore
# measured polyline length while retaining the genuine endpoints and whole
# unchanged coupled interior after the outgoing tangent.
for n in ['source_trace_15','source_trace_16']:
 old=m.original[n]['path'];target=plen(old)
 def candidate(tip):
  p=copy.deepcopy(old);p[1]['x']=tip;q,arcs,index=m.fillet(p,[1],R);return plen(q),q,arcs,index
 tip,(ll,q,arcs,index)=target_bisect(candidate,4.9,5.2,target)
 old_section=m.original[n]['coupledSection'];section=[index[old_section[0]]['outgoing'],index[old_section[1]]['unchanged']]
 records[n]['path']=q;records[n]['coupledSection']=section
 assert all(q[index[i]['unchanged']]==old[i]for i in range(2,len(old)))
 assert q[0]==old[0]and q[-1]==old[-1]and abs(ll-target)<1e-10
 change[n]={'method':'LENGTH_RESTORED_TANGENT_CIRCLE_CPU_HEAD','physicalCircleRadiusMm':R,'maximumArcSampleStepDegrees':15,'virtualTangentIntersectionX':tip,'virtualIntersectionIsNotCopper':True,'originalSharpTurnDegrees':m.turns(old)[0]['turnDegrees'],'actualCircleDetails':arcs,'originalToNewIndexMap':index,'oldCoupledSection':old_section,'newCoupledSection':section,'unchangedSharedInteriorOriginalIndices':[2,old_section[1]],'trimmedSharedHorizontalPrefixMm':old[1]['x']-arcs[0]['outgoingTangent']['x'],'oldCarrierLengthMm':target,'newCarrierLengthMm':ll,'originalTwoEndpointCoordinatesHeld':True}
# Source28 CPU3 sharp folds, with a forward south handoff replacing the old
# collinear marker that would otherwise create a tiny 180-degree backtrack.
n='source_trace_28';old=m.original[n]['path'];target=plen(old);p=copy.deepcopy(old);p[1]['x']=1.5;p[2]['y']=13.1;p.pop(5);cpu,arcs,index=m.fillet(p,[2,3,4],R)
# Replace only the final genuine RAM approach segment with a sampled U. It lies
# inside the immutable package field, but must still clear every fixed barrel,
# land, reference wire and all seventeen other carriers.
a,b=map(m.xy,cpu[-2:]);span=math.dist(a,b);u=((b[0]-a[0])/span,(b[1]-a[1])/span);offset=.6;uw=.6;side=1
assert offset>R and offset+uw+R<span

def ram_candidate(depth):
 def at(t,z):return m.P((a[0]+u[0]*t-u[1]*z*side,a[1]+u[1]*t+u[0]*z*side))
 raw=[m.P(a),at(offset,0),at(offset,depth),at(offset+uw,depth),at(offset+uw,0),m.P(b)];curve,details,mp=m.fillet(raw,[1,2,3,4],R);q=cpu[:-2]+curve
 return plen(q),q,details,mp

depth,(ll,q,ramarcs,rammap)=target_bisect(ram_candidate,2*R,.4,target)
section=[index[4]['outgoing'],index[13]['unchanged']]
records[n]['path']=q;records[n]['coupledSection']=section
# Original DQS1 shared starts at old5; old5 is a collinear marker .002 mm above
# the new south tangent. Everything from old6 through old14 remains exact.
assert all(q[index[i-1]['unchanged']]==old[i]for i in range(6,31))
assert q[0]==old[0]and q[-1]==old[-1]and abs(ll-target)<1e-10
change[n]={'method':'CPU_TANGENT_FILLETS_PLUS_LENGTH_RESTORED_RAM_SAMPLED_U','physicalCircleRadiusMm':R,'maximumArcSampleStepDegrees':15,'originalSharpVertexIndices':[2,3,4],'cpuVirtualTipCoordinate':{'x':1.2,'y':13.1},'cpuEntryMarkerCoordinate':{'x':1.5,'y':12.8},'cpuCircleDetails':arcs,'oldCollinearMarkerRemovedOriginalIndex':5,'oldMarkerWouldCauseBacktrackMm':R-.1,'oldRawWithoutCollinearMarkerToCpuNewIndexMap':index,'oldCoupledSection':[5,14],'newCoupledSection':section,'unchangedSharedInteriorOriginalIndices':[6,14],'trimmedSharedVerticalPrefixMm':R-.1,'ramU':{'originalSegmentEndpoints':[m.P(a),m.P(b)],'offsetMm':offset,'widthMm':uw,'side':side,'depthMm':depth,'circleDetails':ramarcs,'maximumPhysicalDeviationFromOriginalRamSegmentMm':depth},'oldCarrierLengthMm':target,'newCarrierLengthMm':ll,'originalTwoEndpointCoordinatesHeld':True}
assert set(change)=={'source_trace_15','source_trace_16','source_trace_28'}
for n,r in records.items():
 if n not in change:assert r==m.original[n]
 assert r['layer']==m.original[n]['layer']and r['path'][0]==m.original[n]['path'][0]and r['path'][-1]==m.original[n]['path'][-1]
# Actual all18 reciprocal scene checks, not simply the changed conductors.
conductors={};fixed={}
for t in m.full['traces']:
 n=t.get('source_trace_id');fixed[n]=fixed.get(n,0)+sum(math.dist(m.xy(a),m.xy(b))for a,b in zip(t['route'],t['route'][1:])if a['route_type']==b['route_type']=='wire'and a['layer']==b['layer'])
rs={n:{'layer':r['layer'],'path':[m.xy(p)for p in r['path']]}for n,r in records.items()}
for n,r in records.items():
 sc=m.screen(records,n);scene=m.nfp.NativeFloorScene(m.full,{'connections':m.full['connections']},r['layer'],rs,n);meter=scene.exposure(rs[n]['path'],n)
 conductors[n]={**sc,'wholePlanarLengthIncludingImmutableTopStubsMm':plen(r['path'])+fixed[n],'exactReciprocalNormalSpacingExposure':meter,'allNativeFloorsClaimedAsActualApiExecution':False}
pairs=[]
for pair in m.full['differentialPairs']:
 names=pair['connectionNames'];lengths=[conductors[n]['wholePlanarLengthIncludingImmutableTopStubsMm']for n in names]
 pairs.append({'connectionNames':names,'lengthToleranceMm':pair['lengthTolerance'],'requestedGapMm':pair['traceGap'],'wholeLengthsMm':lengths,'skewMm':abs(lengths[0]-lengths[1]),'lengthMatched':abs(lengths[0]-lengths[1])<=pair['lengthTolerance']+1e-8})
buses=[]
for bus in m.full['buses']:
 present=[n for n in bus['connectionNames']if n in records]
 if not present:continue
 lengths=[conductors[n]['wholePlanarLengthIncludingImmutableTopStubsMm']for n in present];lo,hi=min(lengths),max(lengths)
 buses.append({'busId':bus['busId'],'completeOriginalRoster':bus['connectionNames'],'actualPresentNames':present,'actualPresentCount':len(present),'fullOriginalCount':len(bus['connectionNames']),'minimumMm':lo,'maximumMm':hi,'skewMm':hi-lo,'originalMinLengthMm':bus.get('minLength'),'originalMaxLengthMm':bus.get('maxLength'),'originalMaxLengthSkewMm':bus['maxLengthSkew'],'loadedWindowPass':(lo>=(bus.get('minLength') or 0)-1e-8 and hi<=(bus.get('maxLength')or math.inf)+1e-8 and hi-lo<=bus['maxLengthSkew']+1e-8)})
assert all(c['physicalViolationCount']==0 and c['self']['clear']and c['maximumTurnDegrees']<=45.2 and c['exactReciprocalNormalSpacingExposure']['absoluteTICapPass']for c in conductors.values())
assert all(p['lengthMatched']for p in pairs)and all(b['loadedWindowPass']for b in buses)
report={'scope':'SOURCE_ONLY_STRICT18_THREE_CORNER_SMOOTHING_WITH_SAMPLED_LENGTH_RESTORATION','decision':'SOURCE_GEOMETRY_CANDIDATE_FOR_FRESH_SOURCE_CORE_NATIVE_AND_UNCHANGED_ORIGINAL_API','originalDatasetPath':str(m.DATA),'originalDatasetSha256':m.sha(m.DATA),'fullInputPath':str(m.FULL),'fullInputSha256':m.sha(m.FULL),'changedCarrierIds':sorted(change),'changes':change,'all15OtherRecordsExact':True,'all18EndpointCoordinatesLayersHeld':True,'all225OriginalBarrels96TopStubs1165Lands165ReferenceTracesHeldByImmutableFullInput':True,'actualRecordCount':18,'missingOriginalSignalCount':31,'minimumFilletRadiusMm':R,'originalSelfClearRadiusFloorMm':.1016,'angleAssertionUnchanged45_2Degrees':True,'sampleTurnsAtMost15Degrees':True,'physicalAndSelfAndReciprocalReports':conductors,'originalFull49PairWindows':pairs,'originalFull49BusWindowsForExplicitLoadedCohorts':buses,'all18SourceStaticPhysicalSelfAngleAndMetersPass':True,'originalPrivateApiExecuted':False,'freshCoreExecuted':False,'nativeExecuted':False,'cadExecuted':False,'all49Accepted':False,'electricalTimingQualified':False,'referenceQualified':False,'fabricationReady':False,'elapsedSeconds':time.monotonic()-started}
rpt=HERE/'THREE_CORNER_SMOOTHING_STATIC_REPORT.json';rpt.write_text(json.dumps(report,indent=2)+'\n')
normalized={'scope':report['scope'],'strictUniqueCarrierCount':18,'records':[records[r['sourceTraceId']]for r in m.data['records']],'originalDatasetPath':str(m.DATA),'originalDatasetSha256':m.sha(m.DATA),'fullInputPath':str(m.FULL),'fullInputSha256':m.sha(m.FULL),'sourceReport':str(rpt),'sourceReportSha256':m.sha(rpt),'sourceOnlyPlanningCandidate':True,'all18SourceStaticPhysicalSelfAngleAndMetersPass':True,'changedCarrierIds':sorted(change),'all15OtherRecordsExact':True,'all18NumericEndpointsLayersHeld':True,'originalPrivateApisUnchangedAndNeedFreshExecution':True,'all49Accepted':False,'fabricationReady':False,'referenceQualified':False,'electricalTimingQualified':False}
out=HERE/'NORMALIZED_STRICT18_THREE_CORNER_SMOOTHING_LENGTH_RESTORED.json';out.write_text(json.dumps(normalized,indent=2)+'\n')
print(json.dumps({'normalizedSha256':m.sha(out),'reportSha256':m.sha(rpt),'physicalFailures':sum(c['physicalViolationCount']for c in conductors.values()),'selfFailures':sum(not c['self']['clear']for c in conductors.values()),'angleFailures':sum(c['maximumTurnDegrees']>45.2 for c in conductors.values()),'changedLengths':{n:conductors[n]['wholePlanarLengthIncludingImmutableTopStubsMm']for n in change},'busSkews':{b['busId']:b['skewMm']for b in buses},'pairSkews':pairs,'newSharedSections':{n:records[n]['coupledSection']for n in change},'ramDepthMm':depth}))
