from pathlib import Path
import json,hashlib,stat,copy,ast,difflib
OLD=Path('/tmp/g350-source29-three-stage-batch-authentic52-promoted-root-guard-sourceonly-next');NEW=Path('/tmp/g350-source29-three-stage-batch-source29-scope-literal-successor-sourceonly-next');assert not NEW.exists();NEW.mkdir(mode=0o700)
def pin(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def put(p,b):
 with p.open('xb')as f:f.write(b)
 p.chmod(0o600)
m=json.loads((OLD/'SOURCE-manifest.json').read_text());old_scope='ROOT_SOURCE26_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH52_AUTHENTIC_PRIOR_CLOSURES';new_scope='ROOT_SOURCE29_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH52_AUTHENTIC_PRIOR_CLOSURES';changed=[];patch=[]
for row in m['files']:
 p=Path(row['path']);assert pin(p)==row;b=p.read_bytes()
 if p.name in('run-source29-capture-types-core-batch-root.proposal.py','SOURCE29_SERIAL_MAIN_TAIL.py'):
  s=b.decode();assert s.count(old_scope)==1;t=s.replace(old_scope,new_scope);assert t.replace(new_scope,old_scope)==s;ast.parse(t if p.name.startswith('run-')else'def main():\n'+t[:t.index("if __name__")]);b=t.encode();changed.append(p.name);patch.extend(difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile='ea1f/'+p.name,tofile='scope29/'+p.name))
 put(NEW/p.name,b)
assert len(changed)==2
put(NEW/'EXACT_SOURCE29_SCOPE_LITERAL_ONLY_DELTA.patch',''.join(patch).encode())
def remap(v):
 if isinstance(v,dict):
  if all(k in v for k in('path','sha256','bytes','mode'))and Path(v['path']).parent==OLD:
   q=copy.deepcopy(v);q.update(pin(NEW/Path(v['path']).name));return q
  return{k:remap(x)for k,x in v.items()}
 if isinstance(v,list):return[remap(x)for x in v]
 return v
m=remap(m);m.update(historicalUnexecutedWrongScopeBatch53ManifestPin=pin(OLD/'SOURCE-manifest.json'),scopeLiteralCorrectionOnly=True,expectedCurrentBatchPostScope=new_scope,exactScopeLiteralDeltaPin=pin(NEW/'EXACT_SOURCE29_SCOPE_LITERAL_ONLY_DELTA.patch'))
m['files']=[pin(p)for p in sorted(NEW.iterdir())if p.is_file()];m['externalFiles'] +=[pin(OLD/'SOURCE-manifest.json'),pin(OLD/'run-source29-capture-types-core-batch-root.proposal.py'),pin(OLD/'SOURCE29_SERIAL_MAIN_TAIL.py'),pin(Path(__file__))];m['ownFileCountExcludingManifest']=len(m['files']);m['externalFileCount']=len(m['externalFiles'])
assert m['guardPin']==pin(NEW/'run-source29-capture-types-core-batch-root.proposal.py')and m['source29SerialMainTailPin']==pin(NEW/'SOURCE29_SERIAL_MAIN_TAIL.py')
s=(NEW/'run-source29-capture-types-core-batch-root.proposal.py').read_text();assert "assert proposal['status']=="+repr(m['status'])in s
with(NEW/'SOURCE-manifest.json').open('x')as f:json.dump(m,f,indent=2);f.write('\n')
(NEW/'SOURCE-manifest.json').chmod(0o600)
print(json.dumps(dict(manifest=pin(NEW/'SOURCE-manifest.json'),guard=pin(NEW/'run-source29-capture-types-core-batch-root.proposal.py'),tail=pin(NEW/'SOURCE29_SERIAL_MAIN_TAIL.py'),delta=pin(NEW/'EXACT_SOURCE29_SCOPE_LITERAL_ONLY_DELTA.patch'),own=len(m['files']),external=len(m['externalFiles'])),indent=2))
