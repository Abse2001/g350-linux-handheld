"""Own finite scalar waypoint/self-avoidance planner; no SDK/helper imports."""
import copy,heapq,json,math,pathlib,sys,time
sys.path.insert(0,'/tmp/g350-after27-remaining-ddr-scalar-planner-next');import joint27_plan as p
q=p.q;g=p.g;ROOT=pathlib.Path(__file__).resolve().parent;BASE=copy.deepcopy(q.PRIMS);NAME='source_trace_6';STEP=.1
DIRECTIONS=[(1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1)]
def search(name,layer,start,goal,heading=None,cap=65000):
 clear,_=q.setup(layer,name);a,z=[tuple(round(x/STEP)for x in v)for v in(start,goal)]
 if not clear(start,start)or not clear(goal,goal):return dict(termination='ENDPOINT_BLOCKED')
 def point(v):return(v[0]*STEP,v[1]*STEP)
 def h(v):
  dx,dy=abs(v[0]-z[0]),abs(v[1]-z[1]);return STEP*(max(dx,dy)+(math.sqrt(2)-1)*min(dx,dy))
 heap=[(h(a),0.,a)];cost={a:0.};parents={};cache={};expanded=0
 while heap and expanded<cap:
  _,c,n=heapq.heappop(heap)
  if c!=cost.get(n):continue
  if n==z:
   path=[goal];node=n
   while node!=a:node=parents[node];path.append(point(node))
   path[-1]=start;path.reverse();return dict(termination='FOUND',expanded=expanded,points=g.simplify(path),lengthMm=g.plen(path))
  expanded+=1
  for dx,dy in DIRECTIONS:
   if n==a and heading is not None:
    theta=math.atan2(dy,dx);turn=abs(math.atan2(math.sin(theta-heading),math.cos(theta-heading)))
    if turn>math.pi/4+1e-8:continue
   nxt=(n[0]+dx,n[1]+dy)
   if not(-14<=nxt[0]*STEP<=10 and-2<=nxt[1]*STEP<=22):continue
   le=c+STEP*(math.sqrt(2)if dx and dy else 1)
   if le>=cost.get(nxt,math.inf)-1e-12:continue
   edge=tuple(sorted((n,nxt)))
   if edge not in cache:cache[edge]=clear(point(n),point(nxt))
   if not cache[edge]:continue
   cost[nxt]=le;parents[nxt]=n;heapq.heappush(heap,(le+h(nxt),le,nxt))
 return dict(termination='CAP'if heap else'EXHAUSTED_FINITE_LOCAL_GRID',expanded=expanded)
def clip_last(path,contour):
 out=copy.deepcopy(path)
 while len(out)>1 and contour>0:
  a,b=out[-2:];le=math.dist(a,b)
  if le<=contour:out.pop();contour-=le
  else:out[-1]=(b[0]+(a[0]-b[0])*contour/le,b[1]+(a[1]-b[1])*contour/le);break
 return out

def selfcheck(path):
 h=[math.atan2(b[1]-a[1],b[0]-a[0])for a,b in zip(path,path[1:])];t=[math.atan2(math.sin(b-a),math.cos(b-a))for a,b in zip(h,h[1:])]
 if any(abs(a)>math.pi/4+1e-8 for a in t):return False,'angle',max(map(abs,t))
 low=math.inf
 for i,(a,b)in enumerate(zip(path,path[1:])):
  for j in range(i+2,len(path)-1):
   d=g.segdist(a,b,path[j],path[j+1]);ang=sum(abs(v)for v in t[i:j]);arc=g.plen(path[i+1:j+1]);local=ang<=math.pi/2+1e-8 and arc<=math.pi*(g.WIDTH+g.GAP)+1e-8
   if d<1e-8 or d<3*g.WIDTH-1e-8 and not local:return False,'self',dict(i=i,j=j,d=d,turn=ang,arc=arc)
   if not local:low=min(low,d)
 return True,low
if __name__=='__main__':
 out=[];start,goal=map(g.xy,g.CONNECTIONS[NAME]['pointsToConnect']);q.CLASSES['planned_same_ca_self_guard']='DDR_COMMAND_CLOCK'
 for target in [(-5.2,17.2),(-4.8,18),(-6,18),(-7.8,18),(-2,18),(-2,19.2),(-4,18.8),(-6.4,19.2),(-3.2,18),(-3.2,20),(-8,20),(-9.6,18.4)]:
  q.PRIMS=copy.deepcopy(BASE);prefix=search(NAME,'inner2',start,target);r=dict(name=NAME,target=target,prefix=prefix)
  if prefix['termination']=='FOUND':
   guard=clip_last(prefix['points'],.7);q.segment(guard,'inner2','planned_same_ca_self_guard','self_guard');a,b=prefix['points'][-2:];heading=math.atan2(b[1]-a[1],b[0]-a[0]);suffix=search(NAME,'inner2',target,goal,heading=heading);r['suffix']=suffix
   if suffix['termination']=='FOUND':r['path']=g.simplify(prefix['points']+suffix['points'][1:]);r['wholeMm']=g.plen(r['path'])+g.STUB_LENGTH[NAME];r['self']=selfcheck(r['path'])
  out.append(r);print(target,prefix['termination'],r.get('suffix',{}).get('termination'),r.get('wholeMm'),r.get('self'),flush=True)
 f=ROOT/'SOURCE6_INNER2_OUTER_WAYPOINT_SELF_AVOIDING_PROBES.json'
 with f.open('x')as fd:json.dump(dict(scope='OWN_SCALAR_SOURCE6_INNER2_FINITE_OUTER_DETOUR_PROBES',results=out,sourceAccepted=False,globalInfeasibilityClaimed=False),fd,indent=2);fd.write('\n')
 f.chmod(0o600)
