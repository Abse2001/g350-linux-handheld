#!/usr/bin/env python3
"""SOURCE ONLY; author did not execute this file, geometry, SDK, or supplied code.

Root-run literal BREP clearance audit. Native contact checks and this margin
diagnostic remain separate. Same-net exemptions use authenticated SourceTrace
declarations only; unknown ownership never exempts a physical comparison.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import time

LAYERS = ['top', 'inner1', 'inner2', 'bottom']
PENDING = []
ALL49 = ['source_trace_' + str(i) for i in range(49)]
PLAN254 = Path('/tmp/g350-cap8-pdn49-projector-root-20261016-run254/byte0-result.json')
PLAN254_SHA = '30ade5ec6bcaebef1f06247d1f74183b7730b71910a750dc02ab934e4ba63343'
CANDIDATE_SHA = 'f76709a0c4cf1a19920b1e9361e7d5f994ee1671f975836f88d775e17651df87'
CAP_PROFILE = 'CAP12_TRANSLATE_X_0P79_ONLY'
COMBINED_PROFILE = 'CAP12_X0P79_CAP8_TWO_NEW_PDN_VIAS'
CAP8_PROFILE = 'CAP8_AT_0_7P9_TWO_NEW_PLANE_VIAS_VDD7P2'
CAP_WORKER_SHA = 'c59dc40e2698664a55e43d809905521df4bc54113516556473ab123ace3cf930'
AUTH_SCOPE = 'EXPLICITLY_PINNED_M49_PLAN254_CAP12_CAP8_TWO_PDN_AUTHENTICATED_234_MANUAL_VIA_TRACK_MANUFACTURING_DIAGNOSTIC'
AUTH_POLICY = 'ONLY SourceTrace connected_source_port_ids and connected_source_net_ids; no PCB/copper/via alias/geometric union'
EPS, REQUIRED = 1e-8, .1016


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_pin(path, expected):
    require(len(expected) == 64 and all(c in '0123456789abcdef' for c in expected), 'Explicit lowercase64-hex SHA256 required')
    data = path.read_bytes()
    require(digest(data) == expected, 'Input SHA mismatch: ' + str(path))
    return json.loads(data)


def same_set(a, b):
    return isinstance(a, list) and len(a) == len(b) and len(set(a)) == len(a) and set(a) == set(b)


def index(rows, key):
    result = {}
    for row in rows:
        require(isinstance(row.get(key), str) and row[key] not in result, 'Unique actual ' + key + ' required')
        result[row[key]] = row
    return result


def point(p):
    q = (p['x'], p['y'])
    require(all(isinstance(v, (int, float)) and math.isfinite(v) for v in q), 'Finite actual XY required')
    return q


def near(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1]) <= EPS


def point_segment(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    den = dx * dx + dy * dy
    t = 0 if den == 0 else max(0, min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / den))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


def cross(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def segment_distance(a, b, c, d):
    p, q, r, s = cross(a, b, c), cross(a, b, d), cross(c, d, a), cross(c, d, b)
    if p * q < 0 and r * s < 0:
        return 0.0
    return min(point_segment(a, c, d), point_segment(b, c, d), point_segment(c, a, b), point_segment(d, a, b))


def ring(vertices):
    require(isinstance(vertices, list) and len(vertices) >= 3, 'At least3 actual BREP vertices required')
    pts = [point(p) for p in vertices]
    return {'points': pts, 'edges': [(pts[i - 1], p) for i, p in enumerate(pts)],
            'bounds': (min(p[0] for p in pts), min(p[1] for p in pts), max(p[0] for p in pts), max(p[1] for p in pts))}


def inside(p, r):
    bounds = r['bounds']
    if p[0] < bounds[0] or p[0] > bounds[2] or p[1] < bounds[1] or p[1] > bounds[3]:
        return False
    result = False
    for a, b in r['edges']:
        if point_segment(p, a, b) <= EPS:
            return True
        if (a[1] > p[1]) != (b[1] > p[1]):
            if p[0] < a[0] + (p[1] - a[1]) * (b[0] - a[0]) / (b[1] - a[1]):
                result = not result
    return result


def region_distance(a, b, region):
    """Distance from the complete point/line segment to the closed filled BREP.

    Actual outer AND hole edges are tested. A segment whose endpoints are in
    holes can still cross copper: segment-edge intersection gives distance0.
    There is no box-only clearance verdict or center-only wire approximation.
    """
    def filled(p):
        return inside(p, region['outer']) and not any(inside(p, h) for h in region['holes'])
    if filled(a) or filled(b) or filled(((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)):
        return 0.0
    if a == b:
        return min(point_segment(a, c, d) for r in [region['outer']] + region['holes'] for c, d in r['edges'])
    return min(segment_distance(a, b, c, d) for r in [region['outer']] + region['holes'] for c, d in r['edges'])


class Uf:
    def __init__(self):
        self.parent = {}

    def add(self, p):
        self.parent.setdefault(p, p)

    def root(self, p):
        if p not in self.parent:
            return None
        if self.parent[p] != p:
            self.parent[p] = self.root(self.parent[p])
        return self.parent[p]

    def union(self, a, b):
        self.add(a)
        self.add(b)
        self.parent[self.root(b)] = self.root(a)


def main():
    parser = argparse.ArgumentParser()
    for key in ('input', 'controls', 'auth', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    for key in ('input-sha', 'controls-sha', 'auth-sha'):
        parser.add_argument('--' + key, required=True)
    parser.add_argument('--budget-ms', type=int, default=165000)
    parser.add_argument('--wire-scope', choices=['all-routed'], default='all-routed')
    parser.add_argument('--pour-ids', required=True, help='Explicit comma-separated unique actual pour IDs; only these pours are audited')
    args = parser.parse_args()
    require(1000 <= args.budget_ms <= 165000 and not args.output.exists(), 'Fresh output and1000..165000ms budget required')
    require(args.output.resolve() not in {p.resolve() for p in (args.input, args.controls, args.auth, PLAN254)}, 'Output must not replace an input')
    require(all(len(v) == 64 and all(c in '0123456789abcdef' for c in v) for v in
            (args.input_sha, args.controls_sha, args.auth_sha)), 'Mandatory exact fresh raw/control/auth SHA256 pins required')
    started = time.monotonic()
    plan254 = read_pin(PLAN254, PLAN254_SHA)
    require(plan254.get('inputBindings', {}).get('candidate', {}).get('sha256') == 'f76709a0c4cf1a19920b1e9361e7d5f994ee1671f975836f88d775e17651df87', 'Exact combined cap12/cap8 candidate253 plan binding required')
    raw = read_pin(args.input, args.input_sha)
    controls = read_pin(args.controls, args.controls_sha)
    auth = read_pin(args.auth, args.auth_sha)
    require(isinstance(raw, list) and controls.get('rawCoreSha256') == args.input_sha, 'Exact raw array/controls binding required')
    require(controls.get('partialCoreControlPassed') is True and controls.get('partialDiagnosticReplayControlsPassed') is True
            and len(controls.get('checks', [])) == 35 and all(c.get('passed') is True for c in controls['checks']), 'All35 fresh Core controls must pass')
    require(controls.get('expectedConnectedOwners') == 49 and controls.get('expectedPendingOwners') == 0
            and same_set(controls.get('pendingOwnerIds'), PENDING)
            and same_set(controls.get('routedOwnerIds'), [sid for sid in ALL49 if sid not in PENDING]), 'Exact all49 connected/no-pending partition')
    require(same_set([p['originalSourceTraceId'] for p in controls.get('logical49Projection', [])], ALL49)
            and all(p.get('passed') is True for p in controls['logical49Projection'])
            and same_set([g['originalSourceTraceId'] for g in controls.get('physicalGraphs', [])], ALL49)
            and all(g.get('physicallyConnectedByActualOwnedNumericIdGraph') is (g['originalSourceTraceId'] not in PENDING)
                    for g in controls['physicalGraphs']), 'All49 actual logical/numeric graph records required')
    require(controls.get('planSha256') == PLAN254_SHA
            and plan254.get('scope') == 'SOURCE33B_PARTIAL_MIXED_JOINED_EDITABLE_PLAN_SOURCE_PROJECTION_ONLY'
            and same_set(plan254.get('routedOwnerIds'), controls['routedOwnerIds'])
            and same_set(plan254.get('pendingOwnerIds'), PENDING), 'Exact reviewed plan254 and fresh control binding required')
    n, i, a = len(plan254.get('newVias', [])), len(plan254.get('innerPortRegistrations', [])), len(plan254.get('auxiliaryLocalTraces', []))
    r = sum(len(g['wireRuns']) for g in plan254.get('projectedGeometry', []))
    cap8 = plan254.get('cap8HardwareDelta', {})
    p, j = len(cap8.get('pdnVias', [])), len(cap8.get('innerPortRegistrations', []))
    inventory = {'physicalVias': 129 + n + p, 'pcbComponents': 409 + n + p,
                 'sourceAndPcbPorts': 1419 + 2 * n + i + 2 * p + j,
                 'sourceTraces': 1097 + a, 'physicalTraces': 165 + r + a,
                 'reactElements': 2036 + n + i + a + p + j,
                 'newVias': n + p, 'newInnerPorts': i + j, 'newSignalVias': n, 'newPdnVias': p,
                 'newSignalInnerPorts': i, 'newPdnInnerPorts': j,
                 'routedWireRuns': r, 'auxiliaryLocalTraces': a, 'routedOwners': 49, 'pendingOwners': 0}
    require((n, i, r, a, p, j) == (103, 80, 152, 0, 2, 4) and inventory['physicalVias'] == 234
            and len(plan254.get('replacedOriginals', [])) == 49 and len(plan254.get('projectedGeometry', [])) == 49
            and all(controls.get('expectedCounts', {}).get(k) == v for k, v in inventory.items())
            and plan254['dynamicCounts'].get('expectedPcbVias') == inventory['physicalVias']
            and plan254['dynamicCounts'].get('expectedPhysicalTraces') == inventory['physicalTraces'],
            'Actual plan254 N103/I80/R152/A0/P2/J4 and fresh234/317/514/1713/1097/2225 inventory required')
    cap = plan254.get('cap12HardwareDelta', {})
    require(plan254.get('hardwareDeltaProfile') == COMBINED_PROFILE and cap.get('profile') == CAP_PROFILE
            and cap.get('candidateBinding') == plan254['inputBindings']['candidate']
            and cap.get('reviewedWorkerSourceSha256') == CAP_WORKER_SHA
            and cap.get('component', {}).get('sourcePlacement') == {
                'before': {'pcbX': 6, 'pcbY': 4.7, 'layer': 'bottom', 'pcbRotation': 180},
                'after': {'pcbX': 6.79, 'pcbY': 4.7, 'layer': 'bottom', 'pcbRotation': 180}}
            and cap.get('exactPhysicalScope') == {'componentCount': 280, 'heldPlacements': 279,
                'translatedPlacements': 1, 'totalLands': 1165, 'heldLands': 1163, 'translatedSmtPadsAndPorts': 2,
                'totalReferences': 165, 'heldReferences': 163, 'reroutedReferences': 2, 'heldReferenceVias': 129}
            and controls.get('candidateSha256') == CANDIDATE_SHA and controls.get('cap12HardwareDeltaProfile') == CAP_PROFILE
            and controls.get('cap12HardwareDelta') == cap, 'Exact declared cap12 placement/pad/reference ledger and current controls required')
    require(cap8.get('profile') == CAP8_PROFILE
            and cap8.get('descriptorBinding', {}).get('sha256') == '20e698e6225f7aa0759aa4acf70103c5f90f3894ae94726336e098598b3f3976'
            and cap8.get('proofBinding', {}).get('sha256') == 'ec002642c791f3fdcd041e647202712020f9acccf20ced6e22302db20c5601c3'
            and cap8.get('candidateBinding') == plan254['inputBindings']['candidate']
            and cap8.get('component', {}).get('sourcePlacement') == {
                'before': {'pcbX': 1.2, 'pcbY': 9.799999999999999, 'layer': 'bottom', 'pcbRotation': 0},
                'after': {'pcbX': 0, 'pcbY': 7.9, 'layer': 'bottom', 'pcbRotation': 0}}
            and controls.get('cap8HardwareDelta') == cap8
            and controls.get('cap8HardwareDeltaProfile') == CAP8_PROFILE
            and len(cap8.get('sourceEndpointInverses', [])) == 2,
            'Exact combined cap8 planned-to-fresh ledger is required; no Source248 hardware inheritance')
    require({v['name'] for v in cap8['pdnVias']} == {'V_CAP8_REPLAY_DDR_1V5', 'V_CAP8_REPLAY_GND'}
            and all(v.get('futureFreshIds') is None and v.get('plannedIdsAreSourceIdentitiesOnly') is True for v in cap8['pdnVias']),
            'Two explicitly named PDN declarations remain planned provenance until actual Core alias authentication')
    rows = lambda kind: [r for r in raw if r.get('type') == kind]
    vias = index(rows('pcb_via'), 'pcb_via_id')
    require(len(vias) == 234, 'Exact234 real fresh vias required')
    require(auth.get('complete') is True and auth.get('actualViaCount') == 234 and auth.get('completedViaCount') == 234
            and auth.get('inputBindings', {}).get('raw', {}).get('sha256') == args.input_sha
            and auth.get('inputBindings', {}).get('controls', {}).get('sha256') == args.controls_sha,
            'Completed current234 ownership diagnostic must bind these exact raw and controls bytes')
    require(auth.get('scope') == AUTH_SCOPE and auth.get('logicalUfPolicy') == AUTH_POLICY
            and auth.get('foreignViaTrackCopperClearancePassed') is True
            and auth.get('exactInputFilesUnchanged') is True
            and auth.get('inputBindings', {}).get('plan', {}).get('sha256') == PLAN254_SHA
            and auth.get('inputBindings', {}).get('candidate', {}).get('sha256') == 'f76709a0c4cf1a19920b1e9361e7d5f994ee1671f975836f88d775e17651df87'
            and auth.get('requiredCopperEdgeClearanceMm') == REQUIRED
            and auth.get('expectedConnectedOwners') == 49 and auth.get('expectedPendingOwners') == 0
            and same_set(auth.get('pendingOwnerIds'), PENDING)
            and same_set(auth.get('routedOwnerIds'), controls['routedOwnerIds'])
            and all(auth.get(k) == [] for k in ('violations', 'ambiguousVias', 'identityFailures', 'invalidSegments', 'unresolvedSegmentOwners')),
            'Exact current234 declared-UF234 identities/foreign-track evidence required; no earlier ownership result inherited')
    sources = index(rows('source_trace'), 'source_trace_id')
    nets = index(rows('source_net'), 'source_net_id')
    sp = index(rows('source_port'), 'source_port_id')
    pp = index(rows('pcb_port'), 'pcb_port_id')
    pc = index(rows('pcb_component'), 'pcb_component_id')
    manual = index(rows('source_manually_placed_via'), 'source_manually_placed_via_id')
    uf, declarations, global_failures = Uf(), [], []
    for sid, trace in sources.items():
        uf.add(sid)
        ports, net_ids = trace.get('connected_source_port_ids', []), trace.get('connected_source_net_ids', [])
        require(isinstance(ports, list) and isinstance(net_ids, list), 'Actual declaration arrays required')
        for port in ports:
            require(port in sp, 'Source declaration references unknown source port')
            uf.union(sid, port)
        for net in net_ids:
            require(net in nets, 'Source declaration references unknown real source net')
            uf.union(sid, net)
        declarations.append({'sourceTraceId': sid, 'connectedSourcePortIds': ports, 'connectedSourceNetIds': net_ids})
    if auth.get('scope') != AUTH_SCOPE or auth.get('logicalUfPolicy') != AUTH_POLICY or auth.get('declaredLogicalSources') != declarations:
        global_failures.append({'kind': 'AUTH_SOURCE_ONLY_UF_DECLARATION_MISMATCH', 'noOwnershipExemptionsApplied': True})
    auth_rows = index(auth.get('viaReports', []), 'pcbViaId')
    require(set(auth_rows) == set(vias), 'Auth report must cover exact234 unique actual via IDs')
    refs = {}
    for trace in rows('pcb_trace'):
        for i, p in enumerate(trace.get('route', [])):
            for key in ('start_pcb_port_id', 'end_pcb_port_id'):
                if p.get(key):
                    refs.setdefault(p[key], []).append((trace, i, p))
    alias_use = {}
    for vid, via in vias.items():
        for alias in via.get('pcb_port_ids', []):
            alias_use.setdefault(alias, []).append(vid)
    identity_failures, via_roots, identities = [], {}, []
    for vid, via in vias.items():
        proof, failures, observed = auth_rows[vid], [], set()
        aliases = via.get('pcb_port_ids', [])
        if not isinstance(aliases, list) or len(aliases) < 2 or len(set(aliases)) != len(aliases):
            failures.append('MISSING_OR_DUPLICATE_ACTUAL_ALIAS_IDS')
        if not same_set(via.get('layers'), LAYERS) or via.get('from_layer') != 'top' or via.get('to_layer') != 'bottom' or abs(via.get('outer_diameter', 0) - .4572) > EPS or abs(via.get('hole_diameter', 0) - .254) > EPS:
            failures.append('UNSUPPORTED_PHYSICAL_SPAN_OR_DIMENSIONS')
        manual_ids, part_ids, alias_layers = set(), set(), []
        for alias in aliases:
            p = pp.get(alias); s = sp.get(p.get('source_port_id')) if p else None
            c = pc.get(p.get('pcb_component_id')) if p else None
            m = manual.get(s.get('source_component_id')) if s else None
            layer = p['layers'][0] if p and len(p.get('layers', [])) == 1 else None
            good = p is not None and s is not None and c is not None and m is not None and near(point(p), point(via))
            good = good and near(point(c['center']), point(via)) and c.get('source_component_id') == s['source_component_id']
            good = good and c.get('layer') == 'top' and c.get('rotation') == 0 and abs(c.get('width', 0) - via['outer_diameter']) <= EPS and abs(c.get('height', 0) - via['outer_diameter']) <= EPS
            good = good and layer in LAYERS and s.get('name') == layer and alias_use.get(alias) == [vid]
            if not good:
                failures.append('UNAUTHENTICATED_ALIAS:' + alias)
                continue
            manual_ids.add(s['source_component_id']); part_ids.add(c['pcb_component_id']); alias_layers.append(layer)
            if uf.root(s['source_port_id']) is not None:
                observed.add(uf.root(s['source_port_id']))
            for trace, i, endpoint in refs.get(alias, []):
                root = uf.root(trace.get('source_trace_id'))
                if root is None or endpoint.get('route_type') != 'wire' or endpoint.get('layer') != layer or not near(point(endpoint), point(p)):
                    failures.append('INVALID_DECLARED_WIRE_ENDPOINT:' + trace['pcb_trace_id'] + ':' + str(i))
                else:
                    observed.add(root)
        if len(manual_ids) != 1 or len(part_ids) != 1 or len(set(alias_layers)) != len(alias_layers) or not {'top', 'bottom'} <= set(alias_layers):
            failures.append('VIA_ALIAS_COMPONENT_OR_LAYER_ROSTER_MISMATCH')
        for field, table in (('source_trace_id', sources), ('source_net_id', nets)):
            if via.get(field):
                root = uf.root(via[field]) if via[field] in table else None
                if root is None:
                    failures.append('UNKNOWN_EXPLICIT_' + field)
                else:
                    observed.add(root)
        if via.get('pcb_trace_id'):
            trace = next((t for t in rows('pcb_trace') if t['pcb_trace_id'] == via['pcb_trace_id']), None)
            root = uf.root(trace['source_trace_id']) if trace else None
            if root is None:
                failures.append('UNKNOWN_EXPLICIT_PCB_TRACE_OWNER')
            else:
                observed.add(root)
        if not proof.get('aliasIdentityAuthenticated') or not proof.get('logicalOwnerResolved') or not near(point(proof['xy']), point(via)) or proof.get('outerDiameter') != via['outer_diameter'] or proof.get('holeDiameter') != via['hole_diameter'] or not same_set(proof.get('layers'), via['layers']):
            failures.append('CURRENT_AUTH_IDENTITY_MISMATCH')
        if len(observed) != 1 or proof.get('selectedLogicalRoot') not in observed:
            failures.append('ACTUAL_DECLARED_SOURCE_ROOT_AMBIGUOUS_OR_AUTH_MISMATCH')
        root = next(iter(observed)) if not failures and not global_failures else None
        via_roots[vid] = root
        identities.append({'pcbViaId': vid, 'xy': point(via), 'layers': via['layers'], 'logicalRoot': root, 'failures': failures})
        if failures:
            identity_failures.append({'pcbViaId': vid, 'failures': failures, 'noSameNetExemptionApplied': True})

    selected = controls['routedOwnerIds']
    projection = {p['originalSourceTraceId']: p for p in controls['logical49Projection']}
    source_to_original = {projection[sid]['actualSourceTraceId']: sid for sid in selected}
    wires, unsupported = [], []
    for trace in rows('pcb_trace'):
        if trace.get('source_trace_id') not in source_to_original:
            continue
        root = uf.root(trace['source_trace_id']) if not global_failures else None
        for i, (a, b) in enumerate(zip(trace['route'], trace['route'][1:]), 1):
            if a.get('route_type') != 'wire' or b.get('route_type') != 'wire' or a.get('layer') != b.get('layer'):
                continue
            if near(point(a), point(b)):
                continue
            widths = [a.get('width'), b.get('width'), a.get('end_width', 0), b.get('end_width', 0)]
            if a.get('layer') not in LAYERS or any(not isinstance(v, (int, float)) or not math.isfinite(v) for v in widths) or max(widths) <= 0:
                unsupported.append({'kind': 'WIRE_GEOMETRY', 'pcbTraceId': trace['pcb_trace_id'], 'segmentEndIndex': i})
                continue
            wires.append({'pcbTraceId': trace['pcb_trace_id'], 'actualSourceTraceId': trace['source_trace_id'], 'originalOwner': source_to_original[trace['source_trace_id']],
                'segmentStartIndex': i - 1, 'segmentEndIndex': i, 'a': point(a), 'b': point(b), 'layer': a['layer'], 'radius': max(widths) / 2, 'root': root})
    require(len({w['pcbTraceId'] + ':' + str(w['segmentEndIndex']) for w in wires}) == len(wires)
            and set(source_to_original.values()) == set(selected), 'Exact unique dynamic routed-wire catalogue required')
    actual_pours = rows('pcb_copper_pour')
    actual_pour_index = index(actual_pours, 'pcb_copper_pour_id')
    require(len(actual_pour_index) > 0, 'At least one actual raw copper pour required; count and identities are derived from these pinned bytes')
    selected_ids = args.pour_ids.split(',')
    require(all(selected_ids) and len(set(selected_ids)) == len(selected_ids) and set(selected_ids) <= set(actual_pour_index), 'Explicit unique actual selected pour IDs required')
    pours = [p for p in actual_pours if p['pcb_copper_pour_id'] in selected_ids]
    report = {'scope': 'SOURCE49_PLAN254_CAP12_CAP8_TWO_PDN_LITERAL_SELECTED_FRESH_BREP_POUR_MARGIN_DIAGNOSTIC',
        'originalAuditSourceSha256': '489d58532a46ced3aba011e4e571c2b0c3dbb31bc0d504357002addf3739939c',
        'selectedAuditV2SourceSha256': 'ffec7460e2ded1ce8b4a71c49481f292b362397cdab449e3ba92490c8c92b979',
        'auditSourceSha256': digest(Path(__file__).read_bytes()),
        'coverageScope': 'EXPLICIT_ALL_ACTUAL_POURS' if len(pours) == len(actual_pours) else 'EXPLICIT_SELECTED_POURS_ONLY',
        'actualRawPourIds': [p['pcb_copper_pour_id'] for p in actual_pours],
        'actualRawPourRoster': [{'pcbCopperPourId': p['pcb_copper_pour_id'], 'layer': p.get('layer'), 'sourceNetId': p.get('source_net_id'), 'shape': p.get('shape')} for p in actual_pours],
        'selectedPourIds': [p['pcb_copper_pour_id'] for p in pours],
        'omittedPourIds': [p['pcb_copper_pour_id'] for p in actual_pours if p['pcb_copper_pour_id'] not in selected_ids],
        'allActualPoursCompleted': False, 'inputBindings': {
        'raw': {'path': str(args.input), 'sha256': args.input_sha}, 'controls': {'path': str(args.controls), 'sha256': args.controls_sha},
        'current234Ownership': {'path': str(args.auth), 'sha256': args.auth_sha},
        'reviewedSourcePlan254': {'path': str(PLAN254), 'sha256': PLAN254_SHA}},
        'planDerivedInventory': inventory, 'cap12HardwareDeltaProfile': CAP_PROFILE, 'cap12HardwareDelta': cap,
        'cap8HardwareDeltaProfile': CAP8_PROFILE, 'cap8HardwareDelta': cap8, 'freshPdnPlaneConnectivityQualified': False,
        'source248GeometryOrPourQualificationInherited': False,
        'actualRawPourCount': len(actual_pours),
        'wireScope': args.wire_scope, 'wireOriginalOwners': selected, 'wireSegmentCount': len(wires), 'actualViaCount': 234,
        'requiredForeignViaPourEdgeMm': REQUIRED, 'requiredForeignWirePourEdgeMm': REQUIRED, 'coordinateToleranceMm': EPS,
        'globalIdentityFailures': global_failures, 'viaIdentityFailures': identity_failures, 'actualViaIdentities': identities,
        'unsupportedGeometry': unsupported, 'unknownPourIdentities': [], 'pourReports': [], 'violations': [], 'sameNetExemptions': [],
        'completed': False, 'literalForeignPourMarginClear': False, 'sourceRuleBridge': controls.get('sourceRuleBridge'),
        'ownNetReentryQualified': False, 'PthSlotSupplementExecuted': False, 'referenceWireGeometryIncluded': False,
        'all49Accepted': False, 'full49Accepted': False, 'fullBoardPassed': False, 'electricalTimingQualified': False,
        'nativeExecuted': False, 'cadExecuted': False, 'fabricationReady': False,
        'distanceModel': 'Exact literal vertex-defined filled BREP with holes; min point/complete-segment distance to copper minus actual via radius or maximum actual wire half-width. Negative values mean overlap; no bounding-box-only pass.',
        'netExemptionPolicy': 'Only matching real SourceNet roots from explicit SourceTrace declarations and independently reauthenticated current234 via aliases; no geometry/component/undefined-root union.',
        'scopeLimits': ['Only the explicit selected pour subset is audited; completed refers to the selected subset; allActualPoursCompleted separately requires all current literal Source49 pours.',
            'This does not qualify own-net reentry, drill/slot, pad, full-board routing, coupling, delay, or fabrication.',
            'Pours are exact fresh raw polygons; no antipad is regenerated, substituted, or inferred by this audit.',
            'Referenced historical native/ownership qualifications are not inherited.']}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as f:
        json.dump(report, f, indent=2, allow_nan=False)
    def save():
        report['elapsedMs'] = (time.monotonic() - started) * 1000
        temp = Path(str(args.output) + '.next')
        with temp.open('x') as f:
            json.dump(report, f, indent=2, allow_nan=False)
            f.write('\n')
        os.replace(temp, args.output)
    def expired():
        return (time.monotonic() - started) * 1000 >= args.budget_ms - 500
    require(pours, 'At least one explicitly selected actual fresh copper pour required')
    for pour in pours:
        pr = {'pcbCopperPourId': pour.get('pcb_copper_pour_id'), 'layer': pour.get('layer'), 'sourceNetId': pour.get('source_net_id'),
              'state': 'RUNNING', 'viaChecks': [], 'wireChecks': [], 'violations': [], 'sameNetExemptionCount': 0}
        report['pourReports'].append(pr); save()
        try:
            require(pour.get('shape') == 'brep' and pour.get('layer') in LAYERS, 'Supported actual layer and BREP required')
            brep = pour['brep_shape']
            region = {'outer': ring(brep['outer_ring']['vertices']), 'holes': [ring(h['vertices']) for h in brep.get('inner_rings', [])]}
        except (KeyError, TypeError, ValueError) as error:
            unsupported.append({'kind': 'BREP_GEOMETRY', 'pcbCopperPourId': pr['pcbCopperPourId'], 'error': str(error)})
            pr['state'] = 'UNSUPPORTED'; save(); continue
        net = pour.get('source_net_id')
        pour_root = uf.root(net) if net in nets and not global_failures else None
        if pour_root is None:
            report['unknownPourIdentities'].append({'pcbCopperPourId': pr['pcbCopperPourId'], 'sourceNetId': net, 'noSameNetExemptionApplied': True})
        pr['logicalRoot'], pr['outerVertices'], pr['innerRings'] = pour_root, len(region['outer']['points']), len(region['holes'])
        def compare(kind, identity, a, b, radius, root, extra):
            if pour_root is not None and root is not None and root == pour_root:
                report['sameNetExemptions'].append({'pour': pr['pcbCopperPourId'], 'layer': pr['layer'], 'kind': kind, 'identity': identity, 'authenticatedLogicalRoot': root, 'ownNetReentryQualified': False})
                pr['sameNetExemptionCount'] += 1
                return
            distance = region_distance(a, b, region)
            gap = distance - radius
            result = {'kind': kind, 'identity': identity, 'layer': pr['layer'], 'centerlineDistanceToFilledPourMm': distance,
                'copperRadiusMm': radius, 'edgeClearanceMm': gap, 'requiredMm': REQUIRED, 'overlap': gap < 0,
                'passed': gap >= REQUIRED - EPS, 'objectLogicalRoot': root, 'pourLogicalRoot': pour_root, **extra}
            pr['viaChecks' if kind == 'via' else 'wireChecks'].append(result)
            if not result['passed']:
                violation = {'pcbCopperPourId': pr['pcbCopperPourId'], **result}
                pr['violations'].append(violation); report['violations'].append(violation)
        for vid, via in vias.items():
            if expired():
                break
            if pr['layer'] in via['layers']:
                p = point(via)
                compare('via', vid, p, p, via['outer_diameter'] / 2, via_roots[vid], {'xy': p, 'allPhysicalLayers': via['layers']})
        else:
            for wire in wires:
                if expired():
                    break
                if wire['layer'] == pr['layer']:
                    compare('wire', wire['pcbTraceId'] + ':' + str(wire['segmentEndIndex']), wire['a'], wire['b'], wire['radius'], wire['root'], wire)
            else:
                pr['state'] = 'COMPLETED'
        if pr['state'] != 'COMPLETED':
            pr['state'] = 'BOUNDED_PARTIAL'
            save(); break
        save()
    report['completed'] = len(report['pourReports']) == len(pours) and all(p['state'] == 'COMPLETED' for p in report['pourReports'])
    report['inputFilesUnchanged'] = all(digest(path.read_bytes()) == expected for path, expected in [
        (args.input, args.input_sha), (args.controls, args.controls_sha), (args.auth, args.auth_sha), (PLAN254, PLAN254_SHA)])
    report['literalForeignPourMarginClear'] = report['completed'] and report['inputFilesUnchanged'] and not report['violations'] and not unsupported and not global_failures and not identity_failures and not report['unknownPourIdentities']
    report['allActualPoursCompleted'] = report['completed'] and len(pours) == len(actual_pours)
    report['terminalOutcome'] = ('ALL_ACTUAL_LITERAL_POUR_MARGIN_COMPLETE_NOT_BOARD_QUALIFICATION' if report['allActualPoursCompleted'] else 'SELECTED_LITERAL_POUR_MARGIN_COMPLETE_NOT_BOARD_QUALIFICATION') if report['completed'] else 'PARTIAL_OR_UNSUPPORTED_SELECTED_POUR_AUDIT_NOT_QUALIFIED'
    save()


if __name__ == '__main__':
    main()
