import { strict as assert } from "node:assert"
import { isDeepStrictEqual } from "node:util"
const boundedEqual = (
  actual: unknown,
  expected: unknown,
  message = "Physical input binding changed",
) => assert.ok(isDeepStrictEqual(actual, expected), message)
import type { SimpleRouteJson, Trace } from "./source/lib/types"
import type { OriginalCapture } from "./identity-order"
import { orderCapturesByOriginalJobIdentity } from "./identity-order"

export interface PartialNativeApis {
  joinSignalEscapes: (lane: Trace, escapes: Trace[]) => Trace
  validateG350PathIntegrity: (input: SimpleRouteJson, traces: Trace[]) => any
  nativeSignalGeometryIsValid: (trace: Trace) => boolean
  validateRoutedCopperDrc: (params: any) => any
  pairLengthReports: (input: SimpleRouteJson, traces: Trace[]) => any
  pairCouplingReports: (input: SimpleRouteJson, traces: Trace[]) => any
  exteriorPairSpacingReports: (input: SimpleRouteJson, traces: Trace[]) => any
  boardOutlineViolations: (input: SimpleRouteJson, traces: Trace[]) => any
  generatedEscapeHolesConflict: (
    input: SimpleRouteJson,
    first: Trace[],
    second: Trace[],
  ) => boolean
}

export function referenceOwners(native: SimpleRouteJson, registry: any) {
  assert.equal(native.connections.length, 49)
  assert.equal(native.obstacles.length, 856)
  assert.equal(native.traces!.length, 2)
  assert.equal(
    registry.sourceLayoutSha256,
    "98a50b122e6a550c3020c935886d6832dbae34e333ea135e28e9bc555c973d5e",
  )
  const owners = registry.sourceTraces.map((source: any) => {
    assert.ok(
      ["source_trace_932", "source_trace_933"].includes(source.source_trace_id),
    )
    assert.equal(source.connected_source_net_ids.length, 1)
    const net = source.connected_source_net_ids[0]
    assert.equal(
      net,
      source.source_trace_id === "source_trace_932"
        ? "source_net_5"
        : "source_net_0",
    )
    const stub = registry.physicalStubs.find(
      (trace: any) => trace.source_trace_id === source.source_trace_id,
    )
    const fixed = native.traces!.find(
      (trace) => trace.source_trace_id === source.source_trace_id,
    )!
    assert.ok(stub && fixed && fixed.connection_name === source.source_trace_id)
    const sourceContacts = source.connected_source_port_ids.map(
      (id: string) => {
        const port = registry.pcbPorts.find(
          (entry: any) => entry.source_port_id === id,
        )
        assert.ok(
          port && port.layers.length === 1 && port.layers[0] === "bottom",
        )
        return {
          x: port.x,
          y: port.y,
          layer: "bottom",
          pointId: port.pcb_port_id,
          pcb_port_id: port.pcb_port_id,
        }
      },
    )
    assert.equal(sourceContacts.length, 2)
    assert.ok(
      sourceContacts.every((point: any) =>
        stub.route.some(
          (route: any) =>
            route.route_type === "wire" &&
            route.x === point.x &&
            route.y === point.y &&
            route.layer === point.layer,
        ),
      ),
    )
    const routeVia = fixed.route.find((point) => point.route_type === "via")!
    const via = registry.physicalVias.find(
      (entry: any) => entry.x === routeVia.x && entry.y === routeVia.y,
    )
    assert.ok(
      via &&
        via.source_net_id === net &&
        via.outer_diameter === routeVia.via_diameter &&
        via.hole_diameter === routeVia.via_hole_diameter,
    )
    assert.equal(routeVia.via_diameter, 0.4572)
    assert.equal(routeVia.via_hole_diameter, 0.254)
    boundedEqual(routeVia.layers, ["top", "inner1", "inner2", "bottom"])
    const obstacle = native.obstacles.find(
      (entry: any) => entry.circuitJsonMetadata?.pcb_via_id === via.pcb_via_id,
    )
    assert.ok(obstacle && obstacle.connectedTo.includes(source.source_trace_id))
    boundedEqual(obstacle.center, { x: routeVia.x, y: routeVia.y })
    assert.ok(obstacle.connectedTo.includes(net))
    boundedEqual(obstacle.layers, via.layers)
    assert.equal(
      (fixed as any).physicalContextMetadata.pcb_via_id,
      via.pcb_via_id,
    )
    assert.equal((fixed as any).physicalContextMetadata.source_net_id, net)
    boundedEqual(
      (fixed as any).connectsTo,
      sourceContacts.map((point: any) => point.pcb_port_id),
    )
    boundedEqual(
      fixed.route.slice(2).map((point) => ({
        route_type: point.route_type,
        x: point.x,
        y: point.y,
        width: (point as any).width,
        layer: (point as any).layer,
      })),
      stub.route.map(
        ({ start_pcb_port_id: _s, end_pcb_port_id: _e, ...point }: any) =>
          point,
      ),
    )
    // Standalone generated via aliases are copper contacts, not component
    // terminals. The unchanged native rule must still reject vias on real pads.
    const viaAliasContacts = sourceContacts.filter((point: any) =>
      via.pcb_port_ids.includes(point.pcb_port_id),
    )
    const pointsToConnect = sourceContacts.filter(
      (point: any) => !via.pcb_port_ids.includes(point.pcb_port_id),
    )
    assert.equal(viaAliasContacts.length, 1)
    assert.equal(pointsToConnect.length, 1)
    assert.ok(
      pointsToConnect.every((point: any) =>
        registry.pcbPorts.some(
          (port: any) =>
            port.pcb_port_id === point.pcb_port_id &&
            port.pcb_component_id === "pcb_component_131",
        ),
      ),
      "Actual capacitor component terminal required",
    )
    assert.ok(
      viaAliasContacts.every(
        (point: any) =>
          point.x === via.x &&
          point.y === via.y &&
          registry.pcbPorts.some(
            (port: any) =>
              port.pcb_port_id === point.pcb_port_id &&
              ["pcb_component_280", "pcb_component_281"].includes(
                port.pcb_component_id,
              ),
          ),
      ),
      "Actual generated via alias contact required",
    )
    return {
      providedCopperOwnerOnly: true,
      viaAliasContacts,
      sourceContacts,
      name: source.source_trace_id,
      source_trace_id: source.source_trace_id,
      rootConnectionName: net,
      netConnectionName: net,
      pointsToConnect,
    }
  })
  assert.equal(owners.length, 2)
  assert.equal(new Set(owners.map((owner: any) => owner.name)).size, 2)
  assert.ok(
    owners.every(
      (owner: any) =>
        !native.connections.some(
          (connection) => connection.name === owner.name,
        ),
    ),
  )
  return owners
}

/** Real joins and original qualifiers are injectable solely for preparation mocks. */
export function qualifyPartialNative(
  native: SimpleRouteJson,
  escapes: Trace[],
  captures: OriginalCapture[],
  registry: any,
  api: PartialNativeApis,
) {
  const before = JSON.stringify({ native, escapes, captures, registry })
  const ordered = orderCapturesByOriginalJobIdentity(native, captures)
  const natural = ordered.filter(
    (capture) =>
      capture.terminalMethod === "next" &&
      Array.isArray(capture.result) &&
      capture.result.length === 2,
  )
  const carriers = natural.flatMap((capture) => capture.result as Trace[])
  const ownerNames = new Set(carriers.map((trace) => trace.connection_name))
  assert.equal(natural.length, 2)
  boundedEqual(
    natural.map((capture) => capture.jobId),
    [1, 2],
  )
  assert.equal(ordered[2].terminalMethod, "return")
  boundedEqual(ordered[2].result, null, "Captured clock null result changed")
  assert.equal(carriers.length, 4)
  assert.equal(ownerNames.size, carriers.length)
  assert.ok(
    carriers.every((trace) =>
      native.connections.some(
        (connection) => connection.name === trace.connection_name,
      ),
    ),
  )
  assert.equal(escapes.length, 24)
  const joined = carriers.map((lane) =>
    api.joinSignalEscapes(
      lane,
      escapes.filter(
        (escape) => escape.connection_name === lane.connection_name,
      ),
    ),
  )
  const retained = escapes.filter(
    (escape) => !ownerNames.has(escape.connection_name),
  )
  const consumed = escapes.filter((escape) =>
    ownerNames.has(escape.connection_name),
  )
  assert.equal(consumed.length + retained.length, 24)
  assert.equal(consumed.length, 4)
  assert.equal(retained.length, 20)
  const fixed = native.traces!,
    ddr = [...joined, ...retained],
    all = [...fixed, ...ddr]
  const viaInventory = (traces: Trace[]) =>
    traces
      .flatMap((trace) =>
        trace.route.filter((point) => point.route_type === "via"),
      )
      .map((via) =>
        JSON.stringify([
          via.x,
          via.y,
          via.via_diameter,
          via.via_hole_diameter,
          via.layers,
        ]),
      )
      .sort()
  boundedEqual(
    viaInventory(all),
    viaInventory([...fixed, ...escapes]),
    "Joining must preserve every actual supplied/generated physical barrel exactly once",
  )
  const owners = referenceOwners(native, registry)
  const drcInput: SimpleRouteJson = {
    ...native,
    connections: [...native.connections, ...owners],
  }
  const drcOutput = { ...drcInput, traces: all }
  assert.equal(drcInput.connections.length, 51)
  boundedEqual(drcInput.connections.slice(0, 49), native.connections)
  assert.ok(
    all.every((trace) =>
      drcInput.connections.some(
        (connection) => connection.name === trace.connection_name,
      ),
    ),
  )
  const pathIntegrity = api.validateG350PathIntegrity(native, ddr)
  const referencePathIntegrity = api.validateG350PathIntegrity(
    { ...native, traces: [] },
    fixed,
  )
  const nativeGeometry = all.map((trace) => ({
    pcbTraceId: trace.pcb_trace_id,
    name: trace.connection_name,
    valid: api.nativeSignalGeometryIsValid(trace),
  }))
  const drc = api.validateRoutedCopperDrc({
    inputSrj: drcInput,
    routedSrj: drcOutput,
    clearance: native.minTraceToPadEdgeClearance ?? 0.1016,
    allowBlindAndBuriedVias: false,
  })
  const timingView = { ...native, traces: [...fixed, ...retained] }
  const pairLengths = api.pairLengthReports(timingView, joined)
  const pairCoupling = api.pairCouplingReports(timingView, joined)
  const exterior = api.exteriorPairSpacingReports(timingView, joined)
  const outline = api.boardOutlineViolations(native, all)
  const drillConflicts: any[] = []
  for (let a = 0; a < all.length; a++)
    for (let b = a + 1; b < all.length; b++)
      if (api.generatedEscapeHolesConflict(native, [all[a]], [all[b]]))
        drillConflicts.push([all[a].pcb_trace_id, all[b].pcb_trace_id])
  const connected = native.connections
    .filter((connection) => {
      const paths = joined.filter(
        (trace) => trace.connection_name === connection.name,
      )
      if (paths.length !== 1) return false
      const ends = [paths[0].route[0], paths[0].route.at(-1)!]
      return (
        connection.pointsToConnect.every((point) =>
          ends.some(
            (end) =>
              end.route_type === "wire" &&
              end.layer === point.layer &&
              Math.hypot(end.x - point.x, end.y - point.y) < 1e-7,
          ),
        ) &&
        ends.every(
          (end) =>
            end.route_type === "wire" &&
            connection.pointsToConnect.some(
              (point) =>
                point.layer === end.layer &&
                Math.hypot(end.x - point.x, end.y - point.y) < 1e-7,
            ),
        )
      )
    })
    .map((connection) => connection.name)
  const allVias = all.flatMap((trace) =>
    trace.route.filter((point) => point.route_type === "via"),
  )
  assert.equal(all.length, 26)
  assert.equal(allVias.length, 26)
  const complete49 = connected.length === 49 && joined.length === 49
  assert.ok(
    JSON.stringify({ native, escapes, captures, registry }) === before,
    "Original input or hardware mutated",
  )
  return {
    nativeRequestedSignals: 49,
    drcRegisteredOwnerInventory: 51,
    additionalPhysicalReferenceOwners: owners,
    obstacleCount: 856,
    naturalJobIds: natural.map((capture) => capture.jobId),
    cancelledOrNullJobIds: ordered
      .filter((capture) => !natural.includes(capture))
      .map((capture) => capture.jobId),
    joinedNativePaths: joined,
    retainedUnfinishedApproaches: retained,
    consumedApproachCount: consumed.length,
    retainedApproachCount: retained.length,
    totalOwnedApproachCount: 24,
    fixedReferenceCopperCount: 2,
    allPhysicalTraceCount: all.length,
    fullspanViaCount: allVias.length,
    viaDimensionsAndFullSpanHeld: allVias.every(
      (via) =>
        via.via_diameter === 0.4572 &&
        via.via_hole_diameter === 0.254 &&
        JSON.stringify(via.layers) ===
          JSON.stringify(["top", "inner1", "inner2", "bottom"]),
    ),
    nativeConnectedSignals: connected.length,
    connectedNativeNames: connected,
    missingNativeSignals: native.connections
      .filter((connection) => !connected.includes(connection.name))
      .map((connection) => connection.name),
    complete49,
    pathIntegrity,
    referencePathIntegrity,
    nativeGeometry,
    drc,
    nativeDrcActuallyIngestedAllPhysicalTraces:
      drc.checkedTraceCount === all.length &&
      drc.checkedViaCount === allVias.length,
    pairLengths,
    pairCoupling,
    exterior,
    outline,
    drillConflicts,
    inputAndHardwareHeld: true,
    busMatchingQualified: false,
    full49TimingQualified: false,
    accepted49: false,
    electricalTimingQualified: false,
    fabricationReady: false,
    newRoutingCalls: 0,
  }
}
