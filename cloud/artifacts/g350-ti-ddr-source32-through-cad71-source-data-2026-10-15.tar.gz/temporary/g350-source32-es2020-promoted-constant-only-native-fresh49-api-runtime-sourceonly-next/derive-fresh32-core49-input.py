"""Pure stdlib projection of actual checked Core31 to one unseeded full49 input. No SDK import/application evaluation."""
import copy,hashlib,json,math,stat,sys,os
from pathlib import Path
# Root must bind these only after authentic promoted Source32 and its original proposal are sealed.
FUTURE_SOURCE32_CORE_SOURCE_SHA = '6cffcee4868f6fa81c48c4a105b594256ef4e53af057d4866d42407d797f7b4e'
FUTURE_SOURCE32_PROPOSAL_SHA = '988491449fe1ed02ca09a62d2b6ecd40cf82f6e569f1a7916d546e81a7e17ac8'
HERE=None
LAYERS=['top','inner1','inner2','bottom']
def require(value,message):
 if not value:raise ValueError(message)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def binding(p):
 p=Path(p);s=p.lstat();require(p.is_absolute()and stat.S_ISREG(s.st_mode)and not p.is_symlink(),'Bound regular source/data');return dict(path=str(p),sha256=digest(p),bytes=s.st_size,mode=stat.S_IMODE(s.st_mode))
def load(p,sha):
 require(isinstance(p,str)and Path(p).is_absolute()and isinstance(sha,str)and len(sha)==64 and all(c in '0123456789abcdef'for c in sha),'Mandatory future actual path/SHA pin');require(digest(p)==sha,'Exact source/data pin '+str(p));return json.loads(Path(p).read_bytes())
def save(name,value):
 p=HERE/name
 with p.open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
 p.chmod(0o600);return binding(p)
def close(a,b):return math.isfinite(a)and math.isfinite(b)and abs(a-b)<1e-8
def samexy(a,b):return close(a['x'],b['x'])and close(a['y'],b['y'])
def one(rows,message):require(len(rows)==1,message);return rows[0]
def main():
 global HERE
 require(len(sys.argv)==4,'manifestPath manifestSha outputDirectory')
 require(os.environ.get('G350_FRESH32_FULL49_PROJECTION_APPROVED')=='1','Root-owned projection only')
 manifest=load(sys.argv[1],sys.argv[2]);HERE=Path(sys.argv[3])
 require(all(isinstance(v,str)and len(v)==64 and all(c in '0123456789abcdef'for c in v)for v in(FUTURE_SOURCE32_CORE_SOURCE_SHA,FUTURE_SOURCE32_PROPOSAL_SHA)),'Root must bind genuine promoted Source32 source/proposal pins')
 require(HERE.is_absolute()and HERE.is_dir()and not any(HERE.iterdir()),'Fresh empty Root-owned output directory')
 require(manifest['coreSourceManifestSha256']==FUTURE_SOURCE32_CORE_SOURCE_SHA,'Exact Source32 source closure')
 require(manifest['originalSource32ProposalSha256']==FUTURE_SOURCE32_PROPOSAL_SHA,'Exact Source32 geometry declaration')
 a=manifest['actualFreshArtifacts'];raw=load(a['actualCorePath'],a['actualCoreSha256']);controls=load(a['coreControlsPath'],a['coreControlsSha256'])
 native=load(manifest['actualNativeReportPath'],manifest['actualNativeReportSha256'])
 require(manifest['originalConstraintTemplateSha256']=='b2622586601e11262d79be9cb3e03cd367859a4945a553bdf50af25e4cd5e180','Exact original49 rule metadata, never old material')
 require(manifest['originalNumericMetadataSha256']=='ec3b67f2504fb9262c3f93276a321ed26bb20ca853f8e5a8249bf6c669735aad','Exact original numeric selector metadata')
 rules=load(manifest['originalConstraintTemplatePath'],manifest['originalConstraintTemplateSha256'])
 numeric_before=load(manifest['originalNumericMetadataPath'],manifest['originalNumericMetadataSha256'])
 require(controls['scope']=='ROOT_FRESH_EDITABLE_SOURCE_CORE_229_SOURCE20_SOURCE21_INTERMEDIATE_VIAS_AND_SOURCE45_32'and controls['rawCorePath']==a['actualCorePath']and controls['rawCoreSha256']==a['actualCoreSha256'],'Exact fresh Core31 controls/raw binding')
 require(controls['freshCoreControlPassed']is True and len(controls['checks'])==29 and all(x['passed']is True for x in controls['checks']),'All29 actual fresh Core controls')
 require(native['physicalErrors']==0 and native['physicalCpuRamConnectedCarrierCount']==32 and native['rawCircuitUnmodified']is True and native['checkCount']==18 and native['actualNativePairFindings']==[],'Actual31 Native18 ownership passed')
 require(native['actualCoreSha256']==a['actualCoreSha256']and native['actualCoreControlsSha256']==a['coreControlsSha256']and native['coreSourceManifestSha256']==manifest['coreSourceManifestSha256']and native['originalSource32ProposalSha256']==manifest['originalSource32ProposalSha256'],'Same Core31 native provenance')
 proof=native['actualOwnershipProof'];require(len(proof['signalMappings'])==98 and len(proof['referenceMappings'])==165 and len(proof['carriers'])==32,'Exact Native98/165/32 roster')
 before=a['actualCoreSha256'];bytype={t:[r for r in raw if r['type']==t]for t in {r['type']for r in raw}}
 indices={t:{r[t+'_id']:r for r in rows}for t,rows in bytype.items()if all(t+'_id'in r for r in rows)}
 get=lambda t,k:indices[t][k]
 require(len(bytype['source_component'])==280 and len(bytype['pcb_component'])==509 and len(bytype['pcb_via'])==229 and len(bytype['pcb_trace'])==297,'Current280/509/229/297')
 board=one(bytype['pcb_board'],'One current board');require(board['num_layers']==4 and board['outline']==rules['outline']and board['allow_blind_and_buried_vias']is False,'Current4-layer board/outline')
 # Only the old numeric request metadata/rules are reused; no old material coordinate enters the output.
 constraints={k:copy.deepcopy(v)for k,v in rules.items()if k not in {'connections','obstacles','traces'}}
 board_rules={'minTraceWidth':'min_trace_width','minTraceToPadEdgeClearance':'min_trace_to_pad_edge_clearance','minTraceToHoleEdgeClearance':'min_trace_to_hole_edge_clearance','minViaEdgeToPadEdgeClearance':'min_via_edge_to_pad_edge_clearance','minViaHoleEdgeToViaHoleEdgeClearance':'min_via_hole_edge_to_via_hole_edge_clearance','minPlatedHoleDrillEdgeToDrillEdgeClearance':'min_plated_hole_drill_edge_to_drill_edge_clearance','minPadEdgeToPadEdgeClearance':'min_pad_edge_to_pad_edge_clearance','minBoardEdgeClearance':'min_board_edge_clearance','min_via_hole_diameter':'min_via_hole_diameter','min_via_pad_diameter':'min_via_pad_diameter'}
 for outkey,rawkey in board_rules.items():require(close(constraints[outkey],board[rawkey]),'Unchanged current board constraint '+outkey)
 require(constraints['allowedLayers']==LAYERS and constraints['layerCount']==4,'All4 layer authority')
 for bus in constraints['buses']:
  src=one([b for b in bytype['source_bus']if b.get('name')==bus['busId']],'Actual original bus');require(src['source_trace_ids']==bus['connectionNames'],'Exact original bus members')
  if 'maxLengthSkew'in bus:require(src['max_length_skew']==bus['maxLengthSkew'],'Original bus skew')
 for pair in constraints['differentialPairs']:
  src=one([b for b in bytype['source_bus']if b['source_trace_ids']==pair['connectionNames']],'Actual original pair');require(src['max_length_skew']==pair['lengthTolerance'],'Original pair skew')
 maps={(m['originalSourceTraceId'],m['side']):m for m in proof['signalMappings']};require(len(maps)==98,'Unique original49/side0/1 owners')
 fixedids={m['actualPcbTraceId']for m in proof['referenceMappings']+proof['signalMappings']}
 body_ids=lambda c:c['actualCarrierPcbTraceIds']if c.get('carrierArchitecture')=='TWO_LAYER_ONE_OWNED_INTERMEDIATE_VIA'else[c['actualCarrierPcbTraceId']]
 all_body_ids=[i for c in proof['carriers']for i in body_ids(c)];carrierids=set(all_body_ids)
 require(len(fixedids)==263 and len(all_body_ids)==len(carrierids)==34 and not fixedids&carrierids and fixedids|carrierids==set(indices['pcb_trace']),'Exactly263 fixed plus all34 selected body paths; both20/21 pieces plus ordinary45 excluded')
 intermediates=proof['intermediateCarrierMappings'];require(len(intermediates)==2 and [m['originalSourceTraceId']for m in intermediates]==['source_trace_20','source_trace_21'],'Exact two removable carrier-via owners')
 carrier_via_ids={m['actualViaId']for m in intermediates};placeholder_ids={m['actualPlaceholderPcbComponentId']for m in intermediates}
 require(len(carrier_via_ids)==len(placeholder_ids)==2 and all(m['role']=='REMOVABLE_INTERMEDIATE_CARRIER_VIA_NOT_FIXED_FANOUT'and m['fixedFanout']is False and m['physicalGraphProved']is True for m in intermediates),'New vias are proved removable carrier geometry, never fixed dogbones')
 for m in intermediates:
  via=get('pcb_via',m['actualViaId']);component=get('pcb_component',m['actualPlaceholderPcbComponentId']);owner=get('source_manually_placed_via',m['actualSourceViaOwner'])
  require(via['layers']==LAYERS and via['from_layer']=='top'and via['to_layer']=='bottom'and via['outer_diameter']==.4572 and via['hole_diameter']==.254,'Actual full-span intermediate barrel')
  require(component['source_component_id']==owner['source_manually_placed_via_id']and samexy(component['center'],via),'Actual carrier-only placeholder owner')
  require(set(via['pcb_port_ids'])==set(m['actualPcbPortIds'])and len(m['actualPcbPortIds'])==len(m['actualSourcePortIds'])==3,'Actual Top/Bottom/Inner2 aliases only')
  require({one(get('pcb_port',pid)['layers'],'One real alias layer')for pid in m['actualPcbPortIds']}=={'top','bottom','inner2'},'No fabricated alias')
 fixed=[];fixedproof=[];padowners={};viaowners={};numeric=[];connections=[];contacts=[]
 oldnums={c['name']:c for c in numeric_before['connections']};oldcon={c['name']:c for c in rules['connections']}
 for i in range(49):
  name='source_trace_'+str(i);old=oldcon[name];logical=get('source_trace',name);require(len(logical['connected_source_port_ids'])==2,'True original numeric request')
  actualpoints=[];barrelpoints=[];contact=[]
  for side in(0,1):
   m=maps[(name,side)];sp=get('source_port',m['originalNumericSourcePortId']);pp=get('pcb_port',m['actualNumericPcbPortId']);part=get('source_component',sp['source_component_id']);pad=one([r for r in bytype['pcb_smtpad']if r['pcb_port_id']==pp['pcb_port_id']],'One original numeric land');via=get('pcb_via',m['actualViaId']);stub=get('pcb_trace',m['actualPcbTraceId']);alias=get('pcb_port',m['actualTopPcbPortId'])
   require(logical['connected_source_port_ids'][side]==sp['source_port_id']and pp['source_port_id']==sp['source_port_id'],'Unchanged true numeric Source owner')
   require(part['name']==('U_SOC'if side==0 else'U_RAM')and sp['pin_number']is not None,'CPU/RAM numeric pin')
   require(via['layers']==LAYERS and via['from_layer']=='top'and via['to_layer']=='bottom'and via['outer_diameter']==.4572 and via['hole_diameter']==.254,'Actual full4-span signal barrel')
   require(samexy(pp,pad)and samexy(alias,via)and alias['layers']==['top'],'Actual pad/Top alias geometry')
   require(len(stub['route'])==(4 if name=='source_trace_3'and side==0 else 11 if name=='source_trace_14'and side==1 else 13 if name=='source_trace_7'and side==1 else 2)and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in stub['route']),'Exact95 two-point stubs, Source3 CPUfour, Source14 RAMeleven and Source7 RAMthirteen')
   first,last=stub['route'][0],stub['route'][-1];forward=samexy(first,pp)and samexy(last,via);reverse=samexy(first,via)and samexy(last,pp)
   require(forward or reverse,'Actual pad-to-barrel stub in its authentic physical direction')
   require((first['start_pcb_port_id'],last['end_pcb_port_id'])==((pp['pcb_port_id'],alias['pcb_port_id'])if forward else(alias['pcb_port_id'],pp['pcb_port_id'])),'Actual dogbone endpoint identities match physical direction')
   require(stub['source_trace_id']==m['actualPhysicalSourceTraceId'],'Actual physical Source owner')
   local=get('source_trace',m['actualLocalSourceTraceId']);require(local['connected_source_port_ids']==[sp['source_port_id'],alias['source_port_id']],'Actual local numeric/via Source ownership')
   selector=part['name']+'.'+sp['name'];require(oldnums[name]['pointsToConnect'][side]['port_selector']==selector,'Original selector remains real')
   actualpoints.append(dict(x=pp['x'],y=pp['y'],layer='top',pointId=pp['pcb_port_id'],pcb_port_id=pp['pcb_port_id'],port_selector=selector))
   barrelpoints.append(dict(x=via['x'],y=via['y'],layer=old['pointsToConnect'][side]['layer'],layers=copy.deepcopy(LAYERS),pointId=via['pcb_via_id']))
   padowners[pad['pcb_smtpad_id']]=name;viaowners[via['pcb_via_id']]=name
   contact.append(dict(originalSourceTraceId=name,side=side,actualNumericSourcePortId=sp['source_port_id'],numericPin=sp['pin_number'],numericSelector=part['name']+'.pin'+str(sp['pin_number']),actualNumericPcbPortId=pp['pcb_port_id'],actualPad=copy.deepcopy(pad),actualBarrel=copy.deepcopy(via),actualTopAlias=copy.deepcopy(alias),actualFixedDogboneTraceId=stub['pcb_trace_id'],actualLocalSourceTraceId=local['source_trace_id']))
  numeric.append({**{k:copy.deepcopy(v)for k,v in old.items()if k!='pointsToConnect'},'pointsToConnect':actualpoints})
  connections.append({**{k:copy.deepcopy(v)for k,v in old.items()if k!='pointsToConnect'},'pointsToConnect':barrelpoints});contacts.extend(contact)
  require(connections[-1]['pointsToConnect'][0]['layer']==connections[-1]['pointsToConnect'][1]['layer'],'Initial fixed handoff layer held')
 for m in proof['signalMappings']:
  t=get('pcb_trace',m['actualPcbTraceId']);out={**copy.deepcopy(t),'connection_name':m['originalSourceTraceId']};fixed.append(out);fixedproof.append(dict(actualPcbTraceId=t['pcb_trace_id'],actualPhysicalSourceTraceId=t['source_trace_id'],solverConnectionOwner=m['originalSourceTraceId'],kind='TRUE_NUMERIC_SOURCE_OWNED_TOP_STUB',side=m['side'],actualViaId=m['actualViaId']))
 for m in proof['referenceMappings']:
  t=get('pcb_trace',m['actualPcbTraceId']);fixed.append({**copy.deepcopy(t),'connection_name':t['source_trace_id']});fixedproof.append(dict(actualPcbTraceId=t['pcb_trace_id'],actualPhysicalSourceTraceId=t['source_trace_id'],solverConnectionOwner=t['source_trace_id'],kind='ACTUAL_REFERENCE_PATH',actualViaId=m['actualViaId']))
 refowners={}
 for m in proof['referenceMappings']:refowners.setdefault(m['actualViaId'],[]).append(m['actualSourceTraceId'])
 obstacles=[];obproof=[]
 def obstacle(rawrow,idkey,layers,center,width,height,shape=None,owners=None,extra=None):
  require(all(math.isfinite(v)for v in(center['x'],center['y'],width,height))and width>0 and height>0,'Finite current obstacle')
  o=dict(type='rect',obstacleId=rawrow[idkey],componentId=rawrow.get('pcb_component_id'),layers=copy.deepcopy(layers),center=copy.deepcopy(center),width=width,height=height,connectedTo=owners or[rawrow[idkey]],circuitJsonMetadata={idkey:rawrow[idkey]})
  if o['componentId']is None:del o['componentId']
  if shape:o['shape']=shape
  if extra:o.update(extra)
  if rawrow.get('pcb_port_id'):o['circuitJsonMetadata']['pcb_port_id']=rawrow['pcb_port_id']
  obstacles.append(o);obproof.append(dict(actualRowType=rawrow['type'],actualRowId=rawrow[idkey],actualRowSha256=hashlib.sha256(json.dumps(rawrow,sort_keys=True,separators=(',',':')).encode()).hexdigest(),projection=copy.deepcopy(o),geometrySource='EXACT_BOUND_ACTUAL_CORE32_ROW',conservativeEnvelope=rawrow.get('shape')in('polygon','pill')))
 for p in bytype['pcb_smtpad']:
  own=[p['pcb_smtpad_id'],p['pcb_port_id']]+([padowners[p['pcb_smtpad_id']]]if p['pcb_smtpad_id']in padowners else[])
  if p['shape']=='circle':obstacle(p,'pcb_smtpad_id',[p['layer']],dict(x=p['x'],y=p['y']),2*p['radius'],2*p['radius'],'circle',own)
  elif p['shape']=='rect':obstacle(p,'pcb_smtpad_id',[p['layer']],dict(x=p['x'],y=p['y']),p['width'],p['height'],owners=own,extra=dict(ccwRotationDegrees=p.get('ccw_rotation',0)))
  elif p['shape']=='polygon':
   xs=[q['x']for q in p['points']];ys=[q['y']for q in p['points']];obstacle(p,'pcb_smtpad_id',[p['layer']],dict(x=(min(xs)+max(xs))/2,y=(min(ys)+max(ys))/2),max(xs)-min(xs),max(ys)-min(ys),owners=own)
  else:raise ValueError('Unsupported actual pad shape '+p['shape'])
 for v in bytype['pcb_via']:
  own=[v['pcb_via_id'],*v['pcb_port_ids']]+([viaowners[v['pcb_via_id']]]if v['pcb_via_id']in viaowners else[m['originalSourceTraceId']for m in intermediates if m['actualViaId']==v['pcb_via_id']]or refowners.get(v['pcb_via_id'],[]))
  obstacle(v,'pcb_via_id',v['layers'],dict(x=v['x'],y=v['y']),v['outer_diameter'],v['outer_diameter'],'circle',own)
 for h in bytype['pcb_plated_hole']:obstacle(h,'pcb_plated_hole_id',h['layers'],dict(x=h['x'],y=h['y']),h['outer_width'],h['outer_height'],owners=[h['pcb_plated_hole_id'],h['pcb_port_id']],extra=dict(ccwRotationDegrees=h.get('ccw_rotation',0)))
 for h in bytype['pcb_hole']:
  require(h['hole_shape']=='circle','Only actual circular NPTH supported');obstacle(h,'pcb_hole_id',LAYERS,dict(x=h['x'],y=h['y']),h['hole_diameter'],h['hole_diameter'],'circle',[],dict(isNonPlatedHole=True))
 for k in bytype['pcb_keepout']:
  require(k['shape']=='rect','Actual rectangular hardware keepout');obstacle(k,'pcb_keepout_id',k['layers'],k['center'],k['width'],k['height'],owners=[])
 require(len(obstacles)==1398 and len(fixed)==263 and len(connections)==49 and len(contacts)==98,'Complete raw229-barrel material inventory before explicit route-owned removal')
 require(len({o['obstacleId']for o in obstacles})==1398 and {t['pcb_trace_id']for t in fixed}==fixedids,'No material duplicate/lost rows')
 all_raw_obstacles=copy.deepcopy(obstacles);all_raw_components=copy.deepcopy(bytype['pcb_component'])
 removed_carrier_obstacles=[o for o in obstacles if o.get('circuitJsonMetadata',{}).get('pcb_via_id')in carrier_via_ids]
 require(len(removed_carrier_obstacles)==2,'Remove both actual intermediate via obstacles only')
 obstacles=[o for o in obstacles if o.get('circuitJsonMetadata',{}).get('pcb_via_id')not in carrier_via_ids]
 unseeded_components=[c for c in bytype['pcb_component']if c['pcb_component_id']not in placeholder_ids]
 require(len(obstacles)==1396 and len(unseeded_components)==507,'Unseeded material excludes only2 route-owned via/placeholder additions')
 inverse_obstacles={o['obstacleId']:copy.deepcopy(o)for o in obstacles+removed_carrier_obstacles}
 require([inverse_obstacles[o['obstacleId']]for o in all_raw_obstacles]==all_raw_obstacles,'Exact all1398 raw obstacle inverse')
 removed_placeholders=[c for c in bytype['pcb_component']if c['pcb_component_id']in placeholder_ids]
 inverse_components={c['pcb_component_id']:c for c in unseeded_components+removed_placeholders}
 require([inverse_components[c['pcb_component_id']]for c in all_raw_components]==all_raw_components,'Exact all509 raw component-placeholder inverse')
 removal_ids={'pcb_trace':carrierids,'pcb_via':carrier_via_ids,'pcb_component':placeholder_ids,'pcb_port':{i for m in intermediates for i in m['actualPcbPortIds']},'source_port':{i for m in intermediates for i in m['actualSourcePortIds']},'source_manually_placed_via':{m['actualSourceViaOwner']for m in intermediates}}
 removed_raw_rows=[dict(index=i,row=copy.deepcopy(row))for i,row in enumerate(raw)if row.get(row['type']+'_id')in removal_ids.get(row['type'],set())]
 require(len(removed_raw_rows)==52,'34 bodies+2 physical vias+2 placeholders+6 PCB aliases+6 Source aliases+2 source-via owners')
 removed_index={x['index']:x['row']for x in removed_raw_rows};kept_raw=[copy.deepcopy(row)for i,row in enumerate(raw)if i not in removed_index];kept_iter=iter(kept_raw)
 require([removed_index[i]if i in removed_index else next(kept_iter)for i in range(len(raw))]==raw,'Exact full raw-row exclusion inverse, without editing authoritative Core')
 exclusions=save('REMOVABLE_CARRIER_GEOMETRY_EXCLUSION_AND_INVERSE.json',dict(scope='ACTUAL_CORE32_CARRIER_BODY_AND_INTERMEDIATE_VIA_EXCLUSIONS_NOT_FIXED_FANOUT',sourceManifestSha256=manifest['coreSourceManifestSha256'],actualCoreSha256=before,actualNativeReportSha256=manifest['actualNativeReportSha256'],excludedBodyPcbTraceIds=sorted(carrierids),excludedBodyRows34=[copy.deepcopy(get('pcb_trace',i))for i in all_body_ids],intermediateCarrierMappings=copy.deepcopy(intermediates),excludedIntermediateViaRows2=[copy.deepcopy(get('pcb_via',m['actualViaId']))for m in intermediates],excludedCarrierObstacles2=removed_carrier_obstacles,excludedPlaceholderComponents2=removed_placeholders,removedRawRows52=removed_raw_rows,keptRawCanonicalSha256=hashlib.sha256(json.dumps(kept_raw,sort_keys=True,separators=(',',':')).encode()).hexdigest(),exactFullRawRowInverseProved=True,exactRaw1398ObstacleInverseProved=True,exactRaw509ComponentInverseProved=True,rawPhysicalVias229=229,unseededFixedPhysicalBarrels227=227,originalEndpointFanouts98=98,originalReferenceBarrels129=129,newIntermediateViasNotSerializedAsFanouts=True,rawCircuitUnmodified=True,accepted49=False,fabricationReady=False))
 for i,c in enumerate(connections):require({k:v for k,v in c.items()if k!='pointsToConnect'}=={k:v for k,v in rules['connections'][i].items()if k!='pointsToConnect'},'All original request metadata held')
 actual={**constraints,'connections':connections,'traces':fixed,'obstacles':obstacles};numeric_view={**constraints,'connections':numeric,'traces':copy.deepcopy(fixed),'obstacles':copy.deepcopy(obstacles)}
 require({k:v for k,v in actual.items()if k not in('connections','traces','obstacles')}=={k:v for k,v in rules.items()if k not in('connections','traces','obstacles')},'Every original rule remains unchanged')
 input_binding=save('GENUINE_CORE32_FULL49_UNSEEDED_PUBLIC_INPUT.json',actual);numeric_binding=save('GENUINE_CURRENT_CORE49_NUMERIC_REQUESTS_AND_CONTACTS.json',dict(scope='CURRENT_CORE_TRUE49_NUMERIC_AND98_BARREL_CONTACTS',numericFull49Input=numeric_view,contacts=contacts))
 save('CURRENT_MATERIAL_PROJECTION_PROOF.json',dict(scope='STDLIB_CURRENT_CORE32_TO_UNSEEDED_FULL49_MATERIAL_PROJECTION',sourceManifestSha256=manifest['coreSourceManifestSha256'],originalSource32ProposalSha256=manifest['originalSource32ProposalSha256'],actualCoreSha256=before,actualCoreControlsSha256=a['coreControlsSha256'],actualNativeReportSha256=manifest['actualNativeReportSha256'],inputBinding=input_binding,numericBinding=numeric_binding,currentComponentMaterial=copy.deepcopy(unseeded_components),rawCurrentComponentMaterialCount=509,removedCarrierGeometryInverse=exclusions,original280RealComponentMetadata=copy.deepcopy(bytype['source_component']),fixed263Projection=fixedproof,excludedActualCarrierBodies34=copy.deepcopy(proof['carriers']),excludedOnlyTwoRouteOwnedViaPlaceholders=True,current1396ObstacleProjection=[r for r in obproof if r['actualRowId']not in carrier_via_ids],raw1398ObstacleProjection=obproof,currentUnqualifiedSourcePourRows=copy.deepcopy(bytype['pcb_copper_pour']),sourcePoursNotHardObstacles=True,sourcePoursRequireSeparatePlaneAndManufacturingQualification=True,originalRulesExactlyHeld=True,all98GenuineFull4SpanBarrelsAndCurrentNumericPadContactsHeld=True,oldPlanningMaterialNotReused=True,publicConnectionNameProjectionDoesNotRetagRawPhysicalSourceIds=True,currentCoreRawEdited=False,publicRoutingExecuted=False,newRoutesClaimed=0,referenceQualified=False,electricalTimingQualified=False,accepted49=False,fabricationReady=False))
 require(digest(a['actualCorePath'])==before,'Actual Source/Core immutable')
 project_via_events(actual,dict(contacts=contacts),raw,native,manifest)
 print(json.dumps(dict(parentInputSha256=input_binding['sha256'],constructorInputSha256=digest(HERE/'GENUINE_CURRENT_CORE49_CONSTRUCTOR_INPUT.json'),fixedTraces263=True,obstacles1298=True,excludedBodies34=True,excludedIntermediateVias2=True,all49Requests98CurrentTopStubs=True,oldGeometryReused=False,publicSolverExecuted=False)))

def planar(route):return sum(math.hypot(b['x']-a['x'],b['y']-a['y'])for a,b in zip(route,route[1:]))
def project_via_events(parent,numeric,core,native,manifest):
 proof=native['actualOwnershipProof']
 original=copy.deepcopy(parent);result=copy.deepcopy(parent);changes=[];fixed={t['pcb_trace_id']:t for t in result['traces']};by={(c['originalSourceTraceId'],c['side']):c for c in numeric['contacts']};raw={r['pcb_trace_id']:r for r in core if r['type']=='pcb_trace'};vias={r['pcb_via_id']:r for r in core if r['type']=='pcb_via'};signal_ids={m['actualViaId']for m in proof['signalMappings']};refs={m['actualViaId']for m in proof['referenceMappings']};carrier_ids={m['actualViaId']for m in proof['intermediateCarrierMappings']};require(len(signal_ids)==98 and len(refs)==129 and len(carrier_ids)==2 and signal_ids.isdisjoint(refs)and not carrier_ids&(signal_ids|refs)and signal_ids|refs|carrier_ids==set(vias),'229 physical barrels split exactly into129reference+98endpoints+2removable carriers')
 require(not any(o.get('circuitJsonMetadata',{}).get('pcb_via_id')in carrier_ids for o in parent['obstacles']),'No intermediate carrier via in unseeded material')
 for m in proof['signalMappings']:
  t=fixed[m['actualPcbTraceId']];contact=by[(m['originalSourceTraceId'],m['side'])];v=vias[m['actualViaId']];wire=copy.deepcopy(t['route']);require(wire==raw[t['pcb_trace_id']]['route']and len(wire)==(4 if m['originalSourceTraceId']=='source_trace_3'and m['side']==0 else 11 if m['originalSourceTraceId']=='source_trace_14'and m['side']==1 else 13 if m['originalSourceTraceId']=='source_trace_7'and m['side']==1 else 2),'Exact full raw Top stub polyline')
  reverse=not samexy(wire[0],contact['actualPad']);canonical=copy.deepcopy(wire[::-1]if reverse else wire);require(samexy(canonical[0],contact['actualPad'])and samexy(canonical[-1],v),'True numeric pad→barrel direction');canonical[0]['pcb_port_id']=m['actualNumericPcbPortId']
  marker=dict(route_type='via',x=v['x'],y=v['y'],from_layer=v['from_layer'],to_layer=v['to_layer'],layers=copy.deepcopy(v['layers']),via_diameter=v['outer_diameter'],via_hole_diameter=v['hole_diameter'],pcb_via_id=v['pcb_via_id'])
  tail=dict(route_type='wire',x=v['x'],y=v['y'],layer='bottom',width=.1016,pcb_port_id=m['actualBottomPcbPortId']);t['route']=[*canonical,marker,tail];require(v['layers']==LAYERS and v['from_layer']=='top'and v['to_layer']=='bottom'and v['outer_diameter']==.4572 and v['hole_diameter']==.254,'Actual genuine full-span event')
  require(planar(t['route'])==planar(wire),'Zero-length barrel handoff adds no planar length');inverse=copy.deepcopy(t['route'][:-2]);del inverse[0]['pcb_port_id'];inverse=inverse[::-1]if reverse else inverse;require(inverse==wire,'Exact whole-polyline inverse including direction and raw IDs')
  changes.append(dict(originalSourceTraceId=m['originalSourceTraceId'],side=m['side'],actualPcbTraceId=t['pcb_trace_id'],actualViaId=v['pcb_via_id'],actualNumericPcbPortId=m['actualNumericPcbPortId'],actualBottomPcbPortId=m['actualBottomPcbPortId'],rawDirectionReversedForCanonicalPadFirst=reverse,rawWireRoute=wire,projectedRoute=copy.deepcopy(t['route']),originalPlanarLengthMm=planar(wire),projectedPlanarLengthMm=planar(t['route']),addedViaCount=0,existingPhysicalBarrelSerializedOnce=True))
 removed=[o for o in result['obstacles']if o.get('circuitJsonMetadata',{}).get('pcb_via_id')in signal_ids];require(len(removed)==98,'Deduplicate98 signal barrels from obstacle layer');result['obstacles']=[o for o in result['obstacles']if o not in removed]
 rawholes={h['pcb_hole_id']:h for h in core if h['type']=='pcb_hole'};holechanges=[];generic=result['minTraceToPadEdgeClearance'];extra=max(0,result['minTraceToHoleEdgeClearance']-generic);require(generic==.1016 and abs(extra-.0984)<1e-12,'Exact generic-margin compensation')
 for o in result['obstacles']:
  hid=o.get('circuitJsonMetadata',{}).get('pcb_hole_id')
  if not hid:continue
  h=rawholes[hid];require(o['shape']=='circle'and o['width']==o['height']==h['hole_diameter'],'Exact current physical NPTH before conservative envelope');before=copy.deepcopy(o);o['width']+=2*extra;o['height']+=2*extra
  holechanges.append(dict(actualHoleId=hid,rawHole=copy.deepcopy(h),beforeObstacle=before,constructorObstacle=copy.deepcopy(o),physicalRadiusMm=h['hole_diameter']/2,conservativeRadiusAdditionMm=extra,actualGenericPadMarginMm=generic,requiredTraceHoleEdgeClearanceMm=result['minTraceToHoleEdgeClearance'],implementedGenericClearanceMm=extra+generic,rawPhysicalHoleEdited=False))
 require(len(holechanges)==2 and len(result['obstacles'])==1298,'Actual2 NPTHs/1298 deduplicated hard obstacles')
 terminals=[]
 for c in result['connections']:
  for side,p in enumerate(c['pointsToConnect']):require(p['layers']==LAYERS,'Originalfull4 availability');del p['layers']
  terminals.append(dict(connectionName=c['name'],availableLayers=copy.deepcopy(LAYERS),actualBarrelIds=[by[(c['name'],side)]['actualBarrel']['pcb_via_id']for side in(0,1)]))
 inv=copy.deepcopy(result)
 for c in inv['connections']:
  for p in c['pointsToConnect']:p['layers']=copy.deepcopy(LAYERS)
 for ch in changes:
  t=next(t for t in inv['traces']if t['pcb_trace_id']==ch['actualPcbTraceId']);t['route']=ch['rawWireRoute']
 holebefore={c['actualHoleId']:c['beforeObstacle']for c in holechanges}
 obstacleby={o['obstacleId']:o for o in inv['obstacles']};obstacleby.update({o['obstacleId']:o for o in removed})
 for hid,o in holebefore.items():obstacleby[hid]=o
 inv['obstacles']=[obstacleby[o['obstacleId']]for o in original['obstacles']];require(inv==original,'Full inverse to exact fresh32 input outside declared serialization/margin changes')
 serialized_signal_stubs=[fixed[m['actualPcbTraceId']]for m in proof['signalMappings']]
 require(len(changes)==98 and sum(len(t['route'])==4 for t in serialized_signal_stubs)==95 and sum(len(t['route'])==6 for t in serialized_signal_stubs)==1 and sum(len(t['route'])==13 for t in serialized_signal_stubs)==1 and sum(len(t['route'])==15 for t in serialized_signal_stubs)==1 and sum(len(t['route'])for t in serialized_signal_stubs)==414 and sum(p['route_type']=='via'for t in result['traces']for p in t['route'])==98,'One event per actualsignal barrel; full four-point Source3 CPU and eleven-point Source14 RAM and thirteen-point Source7 RAM wires retained')
 require(len(result['connections'])==49 and len(result['traces'])==263 and all(t['pcb_trace_id']not in{i for c in proof['carriers']for i in(c['actualCarrierPcbTraceIds']if c.get('carrierArchitecture')=='TWO_LAYER_ONE_OWNED_INTERMEDIATE_VIA'else[c['actualCarrierPcbTraceId']])}for t in result['traces']),'Unseeded49/263; all34 actual carrier bodies absent')
 for m in proof['referenceMappings']:require(fixed[m['actualPcbTraceId']]==next(t for t in original['traces']if t['pcb_trace_id']==m['actualPcbTraceId']),'All165 actual reference wires held')
 require({o['circuitJsonMetadata']['pcb_via_id']for o in result['obstacles']if 'pcb_via_id'in o.get('circuitJsonMetadata',{})}==refs,'Shared129 reference barrels each represented exactly once as obstacles')
 save('GENUINE_CURRENT_CORE49_CONSTRUCTOR_INPUT.json',result)
 save('CURRENT_VIA_EVENT_AND_NPTH_INVERSE_PROOF.json',dict(scope='SOURCE_ONLY_ACTUAL98_VIA_EVENT_SERIALIZATION_AND_GENERIC_NPTH_MARGIN_CONSTRUCTOR_PROJECTION',sourceManifestSha256=manifest['coreSourceManifestSha256'],originalSource32ProposalSha256=manifest['originalSource32ProposalSha256'],actualCoreSha256=manifest['actualFreshArtifacts']['actualCoreSha256'],actualNativeReportSha256=manifest['actualNativeReportSha256'],parentInputSha256=digest(HERE/'GENUINE_CORE32_FULL49_UNSEEDED_PUBLIC_INPUT.json'),constructorInputSha256=digest(HERE/'GENUINE_CURRENT_CORE49_CONSTRUCTOR_INPUT.json'),exactFullInverseToFresh32Parent=True,viaEvents98=changes,removedDuplicateSignalViaObstacles98=removed,reference129BarrelsAsOwnedObstaclesExactlyOnce=True,reference165WiresUnchanged=True,raw229BarrelsExplicitlyPartitioned=True,unseededFixed227BarrelsRepresentedExactlyOnce=True,removedIntermediateCarrierViaIds2=sorted(carrier_ids),intermediateViasNeverSerializedAsFixedFanouts=True,removableCarrierGeometryInverse=binding(HERE/'REMOVABLE_CARRIER_GEOMETRY_EXCLUSION_AND_INVERSE.json'),viaEventsRepresentExistingPhysicalBarrelsNotNewHoles=True,wireGeometryWidthsAndPlanarLengthsHeld=True,terminalMap49=terminals,only98TerminalLayersKeysRemoved=True,npthConservativeMarginProjection=holechanges,specialHoleFlagsNotClaimedApiEnforced=True,genericClearanceSourceRule='VectorScene.margin=width/2+(input.minTraceToPadEdgeClearance??defaultObstacleMargin??.075); circle fixedCopper.radius=obstacle.width/2',allOriginalConstraintFieldsHeld=True,physicalSourceAndCoreUntouched=True,SDKOrRoutingOrHelpersEvaluated=False,newRoutesClaimed=0,referenceQualified=False,electricalTimingQualified=False,accepted49=False,fabricationReady=False))

if __name__=='__main__':main()
