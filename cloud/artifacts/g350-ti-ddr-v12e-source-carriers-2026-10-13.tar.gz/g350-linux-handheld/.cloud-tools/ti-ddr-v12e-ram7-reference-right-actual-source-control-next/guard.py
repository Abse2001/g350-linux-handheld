"""Root-authorized original 120s/3GiB source-forward process guard."""
import argparse
import hashlib
import importlib.util
import json
import re
import stat
import sys
from pathlib import Path
import inventory
import process_scope

ROOT = Path(__file__).resolve().parent
BOARD = Path('/workspace/g350-linux-handheld')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def checked():
    packet_path = ROOT / 'CONTROL-manifest.json'
    packet = json.loads(packet_path.read_bytes())
    for row in packet['files']:
        path = ROOT / row['path']
        if not (path.is_file() and not path.is_symlink() and path.stat().st_size == row['bytes'] and
                sha(path) == row['sha256'] and stat.S_IMODE(path.stat().st_mode) == row['mode']):
            raise ValueError('Immutable prepared member changed: ' + row['path'])
    listed = {row['path'] for row in packet['files']}
    for path in (ROOT / 'source').rglob('*'):
        if path.is_symlink():
            if path != ROOT / 'source/node_modules' or str(path.readlink()) != str(BOARD / 'node_modules'):
                raise ValueError('Unexpected source resolver symlink')
            continue
        if path.is_file():
            relative = path.relative_to(ROOT).as_posix()
            if relative not in listed:
                exact_data = relative in packet['allowedGeneratedSourceDataFiles']
                autorouting_json = relative.startswith('source/.tscircuit/autorouting-artifacts/') and path.suffix == '.json'
                if not (exact_data or autorouting_json):
                    raise ValueError('Unexpected source/resolver artifact: ' + relative)
    for relative in ('node_modules', '.pnp.cjs', '.pnp.loader.mjs', '.yarn', 'source/.pnp.cjs', 'source/.pnp.loader.mjs', 'source/.yarn'):
        if (ROOT / relative).exists() or (ROOT / relative).is_symlink():
            raise ValueError('Unexpected nearest dependency resolver: ' + relative)
    spec=importlib.util.spec_from_file_location('g350_v12e_core_original_d_source',Path(packet['parentProvenanceModule']))
    parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent)
    parent.verify(packet['parentManifestSha256'])
    pure = json.loads(Path(packet['actualPureCapture']).read_bytes())
    receipt = json.loads(Path(packet['actualPureReceipt']).read_bytes())
    e = receipt['execution']
    if not (receipt['passed'] is True and receipt['sourceHeld'] is True and
            receipt['sourceManifestSha256'] == packet['actualPurePacketSha256'] and
            receipt['captureSha256'] == sha(packet['actualPureCapture']) and
            e['exitCode'] == 0 and e['diagnosticStopped'] is False and
            e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()) and
            pure['actualFinalReactTreeEvaluated'] is True and
            pure['allOtherTreePropsTypesKeysChildrenExactlyHeld'] is True and
            pure['changedProps'] == packet['threePlacementOverrides']):
        raise ValueError('Exact actual clean source-held V12e pure capture required')
    actual = inventory.tree(BOARD / 'node_modules')
    expected = packet['boardDependencyInventory']
    for field in ('treeSha256', 'regularFiles', 'regularBytes', 'symlinks', 'directories'):
        if actual[field] != expected[field]:
            raise ValueError('Complete pinned board dependencies changed: ' + field)
    if sha(BOARD / 'node_modules/@tscircuit/checks/dist/index.js') != packet['reviewedNativeChecksSha256']:
        raise ValueError('Reviewed native checker patch changed')
    for row in packet['externalBindings']:
        path = Path(row['path'])
        if not (path.is_file() and path.stat().st_size == row['bytes'] and sha(path) == row['sha256']):
            raise ValueError('Pinned external metadata/tool changed: ' + row['path'])
    deps = {field: actual[field] for field in ('treeSha256', 'regularFiles', 'regularBytes', 'symlinks', 'directories')}
    return packet, sha(packet_path), deps


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--preflight', action='store_true')
    parser.add_argument('--launch-receipt', type=Path)
    parser.add_argument('--receipt-sha256')
    args = parser.parse_args()
    if args.preflight == bool(args.launch_receipt):
        raise ValueError('Select pure preflight or exact root launch receipt')
    packet, packet_sha, before = checked()
    if args.preflight:
        print(json.dumps({'preflightOnly': True, 'packetSha256': packet_sha,
                          'sourceFiles': packet['sourceFileCount'], 'actualCoreCalls': 0,
                          'nativeCheckerCalls': 0, 'fabricationReady': False}))
        return 0
    if not re.fullmatch('[0-9a-f]{64}', args.receipt_sha256 or '') or sha(args.launch_receipt) != args.receipt_sha256:
        raise ValueError('Exact root receipt hash required')
    authority = json.loads(args.launch_receipt.read_bytes())
    if not (authority.get('authorizedByRoot') is True and
            authority.get('scope') == 'one-routing-disabled-pinned-core-v12e-three-rigid-x-props-forward-control' and
            authority.get('packetSha256') == packet_sha and authority.get('policy') == packet['policy'] and
            authority.get('layerPolicyProjectionBridgeAuthorized') is True and
            authority.get('layerPolicyAuthoritySha256') == packet['layerPolicyAuthority']['sha256'] and
            authority.get('baselineV12dInputSha256') == 'ff3de67bc83c036b7780561690806227b3981c9eee88920497c6a7e9889f56aa' and
            re.fullmatch('[0-9a-f]{32,128}', authority.get('approvalToken', ''))):
        raise ValueError('Root authority scope/packet differs')
    if (ROOT / 'run').exists() or (ROOT / 'output').exists():
        raise ValueError('One new actual source-forward run only')
    def before_spawn(memory):
        if memory['current'] + packet['policy']['rssBytes'] + packet['preforkReserveBytes'] >= packet['policy']['sharedBytes']:
            raise ValueError('Strict original prefork reserve required')
    execution = process_scope.run_guarded([sys.executable, '-B', str(ROOT / 'runner.py'),
            '--one-root-approved-source-forward'], str(ROOT), ROOT / 'run', packet['policy'],
            {'G350_TI_V12E_SOURCE_FORWARD_APPROVED': '1',
             'G350_TI_V12E_SOURCE_FORWARD_PACKET_SHA': packet_sha,
             'G350_TI_V12E_SOURCE_FORWARD_RECEIPT_PATH': str(args.launch_receipt.resolve()),
             'G350_TI_V12E_SOURCE_FORWARD_RECEIPT_SHA': args.receipt_sha256}, before_spawn=before_spawn)
    after_packet, after_sha, after = checked()
    result_path = ROOT / 'run/result.json'
    result = json.loads(result_path.read_bytes()) if result_path.is_file() else None
    passed = (execution['exitCode'] == 0 and execution['diagnosticStopped'] is False and
              execution.get('cleanupOwnedGroupEmpty') is True and not any(execution['oomDelta'].values()) and
              before == after and packet_sha == after_sha and result is not None and
              result['packetSha256'] == packet_sha and result['sourceBuildCount'] == 1 and
              result['actualSourceAndInputQualified'] is True and result['nativePhysicalErrors'] == 0 and
              result['nativePhysicalCheckCount'] == 17 and result['actualDdr49RouteProduced'] is False and
              result['explicitLayerPolicyProjectionBridgeUsed'] is True and
              result['wholeCohortAllocation'] == {'top':11,'inner1':26,'inner2':11,'bottom':1})
    post = {'packetSha256Before': packet_sha, 'packetSha256After': after_sha,
            'receiptSha256': args.receipt_sha256, 'execution': execution,
            'boardDependenciesBefore': before, 'boardDependenciesAfter': after,
            'resultSha256': sha(result_path) if result_path.is_file() else None,
            'actualSourceAndInputTrustEligible': passed, 'signalRoutingPerformed': False,
            'actualDdr49RouteProduced': False, 'accepted49': False, 'fabricationReady': False}
    with (ROOT / 'run/postflight.json').open('x') as handle:
        json.dump(post, handle, indent=2)
        handle.write('\n')
    print(json.dumps({'actualSourceAndInputTrustEligible': passed,
                      'actualDdr49RouteProduced': False, 'fabricationReady': False}))
    return 0 if passed else 2


if __name__ == '__main__':
    raise SystemExit(main())
