import fs from "node:fs"
import crypto from "node:crypto"
import assert from "node:assert/strict"
import { VectorScene, routeCopper, fixedCopper } from "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/vector-scene"
import { tuningPathIsSelfClear } from "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/length-tuning"
import { sharedPairSpacingReports } from "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/shared-pair-spacing"
import { exteriorPairSpacingReports } from "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/exterior-pair-spacing"
import { pairCouplingReports } from "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/pair-coupling"
import { pairLengthReports, busLengthReports, fixedRouteLength } from "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/route-lengths"
import { routeAnglesAreConventional } from "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/route-angle-validation"
import type { SimpleRouteJson, Trace } from "/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-runtime128-cpu34-active-observer-next/source/lib/types"
const [manifestPath,manifestSha,authorityPath,authoritySha,nativePath,outputPath,...extra]=process.argv.slice(2)
assert.ok(manifestPath&&manifestSha&&authorityPath&&authoritySha&&nativePath&&outputPath&&!extra.length&&!fs.existsSync(outputPath))
assert.equal(process.env.G350_STRICT18_FRESH_NATIVE_APPROVED,"1");assert.equal(process.versions.bun,"1.3.14")
const digest=(b:Buffer)=>crypto.createHash("sha256").update(b).digest("hex")
const load=(p:string,h?:string)=>{const b=fs.readFileSync(p);if(h)assert.equal(digest(b),h);return JSON.parse(b.toString())}
try {
const manifest=load(manifestPath,manifestSha),authority=load(authorityPath,authoritySha)
assert.equal(authority.authorizedByRoot,true);assert.equal(authority.packetSha256,manifestSha);assert.equal(authority.scope,manifest.scope)
for(const row of [...manifest.files,...manifest.externalFiles]){const st=fs.lstatSync(row.path);assert(st.isFile()&&!st.isSymbolicLink());const b=fs.readFileSync(row.path);assert.equal(b.length,row.bytes);assert.equal(st.mode&0o777,row.mode);assert.equal(digest(b),row.sha256)}
const artifacts=manifest.actualFreshArtifacts;assert.deepEqual(authority.freshArtifacts,artifacts)
const raw=fs.readFileSync(artifacts.actualCorePath);assert.equal(digest(raw),artifacts.actualCoreSha256)
const core=JSON.parse(raw.toString()) as Array<Record<string,any>>,native=load(nativePath)
assert.equal(native.packetSha256,manifestSha);assert.equal(native.actualCoreSha256,artifacts.actualCoreSha256)
assert.equal(native.checkCount,18);assert.equal(native.physicalErrors,0);assert.equal(native.physicalCpuRamConnectedCarrierCount,18);assert.equal(native.actualNativePairFindings.length,0)
const input=load(manifest.authorized49InputPath,manifest.authorized49InputSha256) as SimpleRouteJson
const static18=load(manifest.strict18Path,manifest.strict18Sha256)
const dqs1=load(manifest.dqs1SharedEvidencePath,manifest.dqs1SharedEvidenceSha256)
const clock=load(manifest.frozenV11CandidatePath,manifest.frozenV11CandidateSha256)
assert.equal(input.connections.length,49);assert.equal(input.traces!.length,261);assert.equal(input.obstacles.length,1298);assert.equal(input.layerCount,4)
assert.equal(input.differentialPairs!.length,3);assert(input.differentialPairs!.every(p=>p.lengthTolerance===.127&&p.traceGap===.12))
assert.equal(core.filter(r=>r.type==="pcb_via").length,225);assert.equal(core.filter(r=>r.type==="pcb_trace").length,279)
const signature=JSON.stringify(core),bindings=native.actualOwnershipProof.carriers
assert.equal(bindings.length,18)
const projections:Array<Record<string,any>>=[]
const traces:Trace[]=bindings.map((binding:Record<string,any>)=>{
 const direct=core.filter(r=>r.type==="pcb_trace"&&r.source_trace_id===binding.originalSourceTraceId)
 assert.equal(direct.length,3);assert.deepEqual(direct.map(t=>t.pcb_trace_id),binding.actualDirectPcbTraceIds)
 const body=direct.find(t=>t.pcb_trace_id===binding.actualCarrierPcbTraceId)!
 assert(body&&body.route.every((p:Record<string,any>)=>p.route_type==="wire"&&p.layer===binding.carrierLayer&&p.width===.1016))
 const record=static18.records.find((r:Record<string,any>)=>r.sourceTraceId===binding.originalSourceTraceId)!
 assert(record&&record.layer===binding.carrierLayer&&record.path.length===body.route.length)
 const delta=Math.max(...record.path.map((p:Record<string,any>,i:number)=>Math.hypot(p.x-body.route[i].x,p.y-body.route[i].y)))
 assert(delta<1e-9)
 let coupledSection=record.coupledSection
 if(["source_trace_15","source_trace_16"].includes(binding.originalSourceTraceId))assert.deepEqual(coupledSection,binding.originalSourceTraceId==="source_trace_15"?[1,18]:[1,17],"Exact normalized21316 DQS0 shared sections, no guessed interval")
 if(dqs1.candidates[binding.originalSourceTraceId]){const d=dqs1.candidates[binding.originalSourceTraceId];assert.equal(d.path.length,body.route.length);assert(d.path.every((p:Record<string,any>,i:number)=>Math.hypot(p.x-body.route[i].x,p.y-body.route[i].y)<1e-9));coupledSection=d.coupledSection}
 if(clock.coupledSections?.[binding.originalSourceTraceId])coupledSection=clock.coupledSections[binding.originalSourceTraceId]
 projections.push({originalSourceTraceId:binding.originalSourceTraceId,actualCarrierPcbTraceId:body.pcb_trace_id,actualDirectPcbTraceIds:binding.actualDirectPcbTraceIds,maximumCoordinateDeltaMm:delta,carrierLayer:binding.carrierLayer,coupledSection:coupledSection??null})
 return {...body,connection_name:binding.originalSourceTraceId,coupledSection} as Trace
})
// Geometry view names remain original49. Only endpoint layer/ID anchors for the
// actually completed18 are derived from their genuine fresh physical aliases.
const byName=new Map(bindings.map((b:Record<string,any>)=>[b.originalSourceTraceId,b]))
const apiInput:SimpleRouteJson={...input,connections:input.connections.map(c=>{
 const b=byName.get(c.name) as Record<string,any>|undefined;if(!b)return c
 const ids=[b.actualCpuCarrierLayerPcbPortId,b.actualRamCarrierLayerPcbPortId]
 return {...c,pointsToConnect:c.pointsToConnect.map((p,i)=>{
  const actualPort=core.find(r=>r.type==="pcb_port"&&r.pcb_port_id===ids[i])!
  assert(actualPort&&actualPort.layers.includes(b.carrierLayer),"Authentic physical carrier alias required")
  return {...p,x:actualPort.x,y:actualPort.y,layer:b.carrierLayer,pointId:actualPort.pcb_port_id,pcb_port_id:actualPort.pcb_port_id}
 })}
})}
const dataSignature=JSON.stringify({input,apiInput,static18,dqs1,clock,traces})
const fixed=fixedCopper(apiInput)
const continuity=traces.map(t=>{
 const c=apiInput.connections.find(c=>c.name===t.connection_name)!,b=byName.get(t.connection_name!) as Record<string,any>
 assert(c&&b.actualSourceOwnedPhysicalGraph.physicallyConnected)
 assert(Math.hypot(t.route[0].x-c.pointsToConnect[0].x,t.route[0].y-c.pointsToConnect[0].y)<1e-9)
 assert(Math.hypot(t.route.at(-1)!.x-c.pointsToConnect[1].x,t.route.at(-1)!.y-c.pointsToConnect[1].y)<1e-9)
 const others=traces.filter(other=>other!==t).flatMap(routeCopper)
 const scene=new VectorScene(apiInput,c,.1016,[...fixed,...others])
 return {connectionName:t.connection_name,actualCarrierPcbTraceId:t.pcb_trace_id,pathVisible:scene.pathVisible(t.route),segmentsVisible:t.route.slice(1).map((p,i)=>scene.visible(t.route[i],p)),selfClear:tuningPathIsSelfClear(t.route,.2032),conventionalAngles:routeAnglesAreConventional([t]),fixedPlanarLength:fixedRouteLength(apiInput,t.connection_name!),foreignActual18AndOriginalFixedCopperIncluded:true}
})
const shared=sharedPairSpacingReports(apiInput,traces),exterior=exteriorPairSpacingReports(apiInput,traces),coupling=pairCouplingReports(apiInput,traces),pairLengths=pairLengthReports(apiInput,traces)
assert.equal(shared.length,3);assert.equal(exterior.length,3);assert.equal(coupling.length,3);assert.equal(pairLengths.length,3)
const originalAll49BusReports=busLengthReports(apiInput,traces)
const completedNames=new Set(traces.map(t=>t.connection_name))
const cohortViews=apiInput.buses!.filter(b=>b.busId!=="DDR_RESET").map(b=>({...b,connectionNames:b.connectionNames.filter(n=>completedNames.has(n))}))
const loadedCohortBusReports=busLengthReports({...apiInput,buses:cohortViews},traces)
const byte1=loadedCohortBusReports.find(b=>b.busId==="DDR_BYTE1")!
assert.equal(byte1.lengths.length,11)
const held=signature===JSON.stringify(core)&&dataSignature===JSON.stringify({input,apiInput,static18,dqs1,clock,traces})
const report={scope:"ACTUAL_STRICT18_FRESH_CORE_ALL3_UNCHANGED_ORIGINAL_PRIVATE_API_DIAGNOSTIC",packetSha256:manifestSha,actualCorePath:artifacts.actualCorePath,actualCoreSha256:artifacts.actualCoreSha256,actualNativeReportPath:nativePath,actualNativeReportSha256:digest(fs.readFileSync(nativePath)),actualCarrierProjections:projections,actualNumericPhysicalGraphsRequired:true,actualClockGeometryUsed:true,originalPrivateContinuousApiImplementationsUnchanged:true,automaticCoreSrjUsed:false,original49Input:{path:manifest.authorized49InputPath,sha256:manifest.authorized49InputSha256},completeHardwareSignalsRequested:49,actualCompleteOriginalSignalCount:18,expectedMissingOriginalSignalCount:31,fullOriginalBusRostersAndConstraintsHeld:true,originalFullDifferentialPairArrayUnchanged:true,all3DifferentialPairsInvokedAgainstFreshCopper:true,actualLayerAndEndpointIdViewDerivedFromFreshPhysicalOwnedAliases:true,rawCoreOrAuthoritativeInputRetagged:false,exactMaterialHeld:held,continuity,shared,exterior,coupling,pairLengths,originalAll49BusReports,loadedCohortBusReports,loadedCohortViews:cohortViews,loadedCohortsExplicitlyPartial:{DDR_BYTE0:5,DDR_BYTE1:11,DDR_COMMAND_CLOCK:2},onlyByte1FullElevenPresent:true,originalFullByte0AndCaStillIncomplete:true,nativeManufacturingCheckerExecuted:false,coreRenderedByThisWorker:false,freshCadExecuted:false,originalGridOrPublicSolverExecuted:false,fullCohortTimingPassed:false,electricalDelayModelQualified:false,referenceQualified:false,complete18Accepted:false,accepted49:false,fabricationReady:false,allOriginalApiLoaded18ChecksPassed:held&&continuity.every(r=>r.pathVisible&&r.segmentsVisible.every(Boolean)&&r.selfClear&&r.conventionalAngles)&&shared.every(r=>r.matched)&&exterior.every(r=>r.matched)&&coupling.every(r=>r.matched)&&pairLengths.every(r=>r.matched)&&loadedCohortBusReports.every(r=>r.aboveMinimumLength&&r.withinLengthLimit&&r.matched)}
fs.writeFileSync(outputPath,`${JSON.stringify(report,null,2)}\n`,{flag:"wx",mode:0o600})
assert.equal(report.allOriginalApiLoaded18ChecksPassed,true,"Complete actual diagnostics retained before assertion; never relax a failed original API")
console.log(JSON.stringify({scope:report.scope,allOriginalApiLoaded18ChecksPassed:true,expectedMissingOriginalSignalCount:31,accepted49:false,outputPath}))

} catch(error) {
 if(!fs.existsSync(outputPath))fs.writeFileSync(outputPath,JSON.stringify({scope:"UNRESOLVED_STRICT18_ORIGINAL_API_PRECONDITION_OR_PROJECTION",passed:false,failure:String(error),actualRawCoreOrInputEdited:false,rawAndFailureDiagnosticPreserved:true,accepted49:false,referenceQualified:false,electricalTimingQualified:false,fabricationReady:false},null,2)+"\n",{flag:"wx",mode:0o600})
 throw error
}
