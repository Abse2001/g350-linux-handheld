/** Root-only Source26 capture. No Circuit construction, Core or circuit JSON edit. */
import { Children, Fragment, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { readFileSync, writeFileSync, existsSync, lstatSync } from "node:fs"
import { createHash } from "node:crypto"
import assert from "node:assert/strict"
import { buildOwnerMoved24Source } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-source24-joint-editable-source-stages-sourceonly-next/source24.circuit"
import { buildOwnerMoved26Source } from "./source26.circuit"
import proposal from "./source26-proposal.json"
const [output, diagnostic, ...extra] = process.argv.slice(2)
assert.equal(process.env.G350_RESET_SOURCE3_26_SOURCE_ROOT_GUARDED, "1")
assert.equal(process.versions.bun, "1.3.14")
assert.ok(output && diagnostic && extra.length === 0 && output !== diagnostic && !existsSync(output) && !existsSync(diagnostic))
const sha = (v: string | Buffer) => createHash("sha256").update(v).digest("hex")
assert.equal(proposal.parent176SourceBindings.length, 176)
for (const row of proposal.parent176SourceBindings) {
  const s = lstatSync(row.path); assert(s.isFile() && !s.isSymbolicLink()); assert.equal(s.size, row.bytes); assert.equal(s.mode & 0o777, row.mode)
  assert.equal(sha(readFileSync(row.path)), row.sha256)
}
for (const row of Object.values(proposal.inputBindings)) assert.equal(sha(readFileSync(row.path)), row.sha256)
assert.equal(sha(readFileSync(proposal.parent24Source.path)), proposal.parent24Source.sha256)
assert.equal(sha(readFileSync(proposal.sealedResetGeometry.path)), proposal.sealedResetGeometry.sha256)
assert.equal(sha(readFileSync(proposal.sealedSource3Geometry.path)), proposal.sealedSource3Geometry.sha256)
type Props = Record<string, unknown> & { children?: ReactNode }
type Row = { kind: "literal" | "fragment" | "primitive" | "unsupported"; type: string; key: string | null; props: Record<string, unknown>; children: Row[]; value?: unknown }
function identity(node: ReactNode): ReactNode {
  if (!isValidElement<Props>(node)) return node
  return cloneElement(node as ReactElement<Props>, { ...node.props }, ...Children.toArray(node.props.children).map(identity))
}
function snapshot(node: ReactNode): Row {
  if (!isValidElement<Props>(node)) {
    const allowed = node === null || node === undefined || ["boolean", "string", "number"].includes(typeof node)
    return { kind: allowed ? "primitive" : "unsupported", type: typeof node, key: null, value: node, props: {}, children: [] }
  }
  const { children, ...props } = node.props, actualType: unknown = node.type
  const kind = typeof actualType === "string" ? "literal" : actualType === Fragment ? "fragment" : "unsupported"
  return { kind, type: kind === "literal" ? actualType as string : kind === "fragment" ? "React.Fragment" : `${typeof actualType}:${String(actualType)}`, key: node.key, props, children: Children.toArray(children).map(snapshot) }
}
const flatten = (row: Row): Row[] => [row, ...row.children.flatMap(flatten)]
const clone = (row: Row): Row => ({ ...row, props: { ...row.props }, children: row.children.map(clone) })
function canonical(v: unknown): string {
  if (Array.isArray(v)) return `[${v.map(canonical).join(",")}]`
  if (v && typeof v === "object") return `{${Object.keys(v).sort().map(k => `${JSON.stringify(k)}:${canonical((v as Record<string, unknown>)[k])}`).join(",")}}`
  if (typeof v === "function") return `function:${v.toString()}`
  if (typeof v === "symbol") return `symbol:${String(v)}`
  return JSON.stringify(v) ?? "undefined"
}
const replacer = (_key: string, v: unknown) => typeof v === "function" ? { diagnosticFunction: v.name, sourceSha256: sha(v.toString()) }
  : typeof v === "symbol" ? { diagnosticSymbol: String(v), globalSymbolKey: Symbol.keyFor(v) ?? null } : v
const normalizedJson = (v: unknown) => JSON.parse(JSON.stringify(v, replacer))
const counts = (rows: Row[]) => ({ reactElements: rows.filter(r => r.kind === "literal" || r.kind === "fragment").length, literalStrings: rows.filter(r => r.kind === "literal").length, fragments: rows.filter(r => r.kind === "fragment").length, primitiveChildren: rows.filter(r => r.kind === "primitive").length, unsupported: rows.filter(r => r.kind === "unsupported").length })
const parent = buildOwnerMoved24Source(), source = buildOwnerMoved26Source()
const actualParent24 = snapshot(parent.element), before = snapshot(identity(parent.element)), after = snapshot(source.element)
const oldRows = flatten(before), newRows = flatten(after), plan = proposal.source26Delta
writeFileSync(diagnostic, JSON.stringify({ scope: "ACTUAL_SOURCE26_AND_PARENT24_BEFORE_INVERSE_ASSERTIONS", actualParent24Tree: actualParent24, keyNormalizedParent24Tree: before, actualProposedSource26Tree: after, beforeCounts: counts(oldRows), afterCounts: counts(newRows), inverseChecksExecuted: false, circuitConstructed: false, coreRendered: false, all49Accepted: false, fabricationReady: false }, replacer) + "\n", { flag: "wx", mode: 0o600 })
const parentCapture = JSON.parse(readFileSync(proposal.inputBindings.actualParent24Capture.path, "utf8"))
assert.equal(parentCapture.passed, true); assert.equal(parentCapture.fullInverseSourceTreePassed, true)
assert.equal(canonical(normalizedJson(actualParent24)), canonical(parentCapture.actualSourceTree), "Fresh Source24 evaluation equals genuine capture37")
assert.equal(counts(oldRows).unsupported, 0); assert.equal(counts(newRows).unsupported, 0)
assert.equal(counts(oldRows).reactElements, 2270); assert.equal(counts(newRows).reactElements, 2272)
assert.equal(counts(newRows).literalStrings - counts(oldRows).literalStrings, 2)
assert.equal(counts(newRows).fragments, counts(oldRows).fragments); assert.equal(counts(newRows).primitiveChildren, counts(oldRows).primitiveChildren)
const one = (rows: Row[], label: string) => { assert.equal(rows.length, 1, label); return rows[0] }
const named = (rows: Row[], name: string) => one(rows.filter(r => r.kind === "literal" && r.props.name === name), name)
const fields = ["pcbPath", "pcbPaths", "pcbPathRelativeTo"] as const
const omit = (props: Record<string, unknown>, keys: readonly string[]) => Object.fromEntries(Object.entries(props).filter(([key]) => !keys.includes(key)))
const movedBefore = named(oldRows, plan.movedVia.name), movedNow = named(newRows, plan.movedVia.name)
assert.equal(movedBefore.type, "via"); assert.equal(movedNow.type, "via")
const mm = (v: unknown) => typeof v === "string" ? Number(v.replace(/mm$/, "")) : v
assert.equal(mm(movedBefore.props.pcbX), plan.movedVia.before.x); assert.equal(mm(movedBefore.props.pcbY), plan.movedVia.before.y)
assert.equal(movedNow.props.pcbX, plan.movedVia.after.x); assert.equal(movedNow.props.pcbY, plan.movedVia.after.y)
assert.deepEqual(omit(movedNow.props, ["pcbX", "pcbY"]), omit(movedBefore.props, ["pcbX", "pcbY"]))
for (const change of plan.routeChanges) {
  const old = named(oldRows, change.logicalName), now = named(newRows, change.logicalName)
  assert.equal(now.type, "trace"); assert.deepEqual(omit(now.props, fields), omit(old.props, fields))
  assert.deepEqual(Object.fromEntries(fields.filter(k => old.props[k] !== undefined).map(k => [k, old.props[k]])), change.beforeRouteProps)
  assert.equal(now.props.pcbPath, undefined); assert.deepEqual(now.props.pcbPaths, change.after.newPcbPaths); assert.equal(now.props.pcbPathRelativeTo, change.after.newPcbPathRelativeTo)
}
for (const local of plan.localSuppressions) {
  const old = named(oldRows, local.traceName), now = named(newRows, local.traceName)
  assert.deepEqual(old.props.pcbPath, []); assert.equal(now.props.pcbPath, undefined)
  assert.deepEqual(omit(now.props, ["pcbPath"]), omit(old.props, ["pcbPath"]))
}
for (const requested of plan.newTwoInnerPorts) {
  const old = named(oldRows, requested.viaName), now = named(newRows, requested.viaName)
  assert.equal(old.children.length, 0); assert.equal(now.children.length, 1)
  const child = now.children[0]
  assert.equal(child.kind, "literal"); assert.equal(child.type, "port")
  assert.deepEqual(child.props, { name: requested.layer, layer: requested.layer }); assert.deepEqual(child.children, [])
}
const restored = clone(after), restoredRows = flatten(restored), untouched = canonical(after)
const restoreProps = (name: string, keys: readonly string[]) => {
  const row = named(restoredRows, name), old = named(oldRows, name)
  for (const field of keys) { delete row.props[field]; if (Object.prototype.hasOwnProperty.call(old.props, field)) row.props[field] = old.props[field] }
}
restoreProps(plan.movedVia.name, ["pcbX", "pcbY"])
for (const change of plan.routeChanges) restoreProps(change.logicalName, fields)
for (const local of plan.localSuppressions) restoreProps(local.traceName, ["pcbPath"])
for (const requested of plan.newTwoInnerPorts) named(restoredRows, requested.viaName).children = named(oldRows, requested.viaName).children.map(clone)
assert.equal(canonical(restored), canonical(before), "Full inverse holds every Source24 key/container/child/property outside one via move, two original paths, four local suppressions and two real Port children")
assert.equal(canonical(after), untouched, "Actual proposed tree not mutated by inverse")
for (const [type, expected] of [["via", 227], ["port", 40], ["trace", 1195], ["bus", 8]] as const) assert.equal(newRows.filter(r => r.kind === "literal" && r.type === type).length, expected)
for (const original of proposal.all49OriginalLogicalTraces) {
  const now = named(newRows, original.name); assert.equal(now.type, "trace"); assert.equal(now.props.from, original.from); assert.equal(now.props.to, original.to)
}
writeFileSync(output, JSON.stringify({ scope: "ACTUAL_ROOT_SOURCE26_CAPTURE_WITH_PARENT24_FULL_INVERSE", passed: true, fullInverseSourceTreePassed: true, actualParent24DeclarationsHeld: true, source24QualificationInherited: false, proposedReactElementCount: 2272, previousReactElementCount: 2270, genuineNewInnerPortCount: 40, exactNewPortDeclarations: 2, exactChangedOriginalRouteDeclarations: 2, exactChangedLocalSuppressions: 4, exactMovedExistingViaCount: 1, movedViaCapturedPriorIdProvenanceOnly: "pcb_via_135", movedViaName: plan.movedVia.name, expectedPhysicalVias: 227, expectedPhysicalTraces: 289, expectedCarrierPaths: 26, missingOriginal49RequestsExpected: 23, original49LogicalTracesHeld: true, original8Buses98Rails280PartsAndEveryConstraintMetadataHeldByFullInverse: true, sourceOnlyProposalSha256: sha(readFileSync(new URL("./source26-proposal.json", import.meta.url))), actualSourceTree: after, actualDiagnosticPath: diagnostic, actualDiagnosticSha256: sha(readFileSync(diagnostic)), pureSourceEvaluationExecuted: true, circuitConstructed: false, coreRendered: false, nativeExecuted: false, cadExecuted: false, automaticCoreSrjForThisForkMustNotBeUsed: true, bothDqs1CoupledViewsRequireFreshOriginalApi: true, singleCoupledSectionCoversBoth: false, referenceQualified: false, electricalTimingPassed: false, all49Accepted: false, fabricationReady: false }, replacer) + "\n", { flag: "wx", mode: 0o600 })
console.log(JSON.stringify({ scope: "ROOT_SOURCE26_CAPTURE_ONLY", passed: true, output, diagnostic, coreRendered: false, fabricationReady: false }))
