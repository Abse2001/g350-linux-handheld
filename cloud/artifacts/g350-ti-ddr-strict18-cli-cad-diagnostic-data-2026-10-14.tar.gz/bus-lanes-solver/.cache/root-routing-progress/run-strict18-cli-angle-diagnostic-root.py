"""Root-only bounded pinned CLI diagnostic after actual Native0/API1."""
import fcntl,importlib.util,json,secrets,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
s=importlib.util.spec_from_file_location('strict18_capture_stdlib_cli',ROOT/'run-strict18-source-capture-root.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
PACKET=c.BOARD/'.cloud-tools/ddr-strict18-fresh-json-cli-angle-diagnostic-successor-next'
SOURCE_SHA='0cb11e58347f30e8e810dc1f783b48a9225485e8157e7222ddda55dba394fb9a'
OUT=PACKET/'run-cli'
def main():
 assert len(sys.argv)==3
 receipt=Path(sys.argv[1]);assert c.sha(receipt)==sys.argv[2]
 nc,np,ne=c.guard.collected({'path':str(receipt),'sha256':sys.argv[2]})
 assert nc['toolSessionId']==54946 and nc['toolExitCode']==nc['toolWrapperExitCode']==2 and nc['passed'] is False
 assert nc['sourceManifestSha256']=='1e7dea55939ef59d1cf2873ad7ac8d27fc460897ed24430ec2e943b2b77c317c' and np['nativeCalls']==np['original3PairApiCalls']==1
 nr=c.read(np['resultPath']);assert nr['passed'] is False and [(r['phase'],r['exitCode'])for r in nr['commands']]==[('native',0),('original3pairAPI',1)] and nr['actualCoreSha256']=='81a72280365352ac9116563921536a2aced6f7ea2b65f330535927582537c76a'
 assert c.sha(PACKET/'SOURCE-manifest.json')==SOURCE_SHA
 m=c.read(PACKET/'SOURCE-manifest.json')
 def bindings():
  assert c.sha(PACKET/'SOURCE-manifest.json')==SOURCE_SHA
  for row in m['files']+m['externalFiles']:c.guard.source_guard.binding(row)
  for name in ('node_modules','.pnp.cjs','.pnp.loader.mjs','.yarn'):
   p=PACKET/name;assert not p.exists() and not p.is_symlink()
 bindings();_,ssha=c.bindings();_,oldsha,before,sbefore,_=c.guard.checked()
 prior=c.read(c.BOARD/'.cloud-tools/ddr-strict18-fresh-core-native-api-sourceonly-next/run-native/ROOT_AUTHORITY.json')['actualPriorCollectedRows']+[{'path':str(receipt),'sha256':sys.argv[2]}]
 def closed():
  for row in prior:assert c.guard.process_scope.owned(c.guard.collected(row)[2]['pgid'])==[]
 closed();assert not OUT.exists() and not OUT.is_symlink();OUT.mkdir();exports=OUT/'exports';exports.mkdir()
 authority=c.read(PACKET/'AUTHORITY_TEMPLATE_NO_AUTHORIZATION.json');authority.update(authorizedByRoot=True,sourceManifestSha256=SOURCE_SHA,actualPreviousScopesCollectedAndEmpty=True,noConcurrentRootWorker=True,rootFullWorkerReadPassed=True,outputDirectory=str(exports),actualNativeCollection={'path':str(receipt),'sha256':sys.argv[2]},actualNativeReport={'path':nr['actualNativeReportPath'],'sha256':nr['actualNativeReportSha256']},actualPriorCollectedRows=prior,approvalToken=secrets.token_hex(32))
 ap=OUT/'ROOT_AUTHORITY.json'
 with ap.open('x')as f:json.dump(authority,f,indent=2);f.write('\n')
 ap.chmod(0o600);ah=c.sha(ap)
 policy={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 def prefork(mem):
  closed();assert mem['current']+policy['rssBytes']+1073741824<policy['sharedBytes']
 execution=None;error=None
 with (ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  try:execution=c.guard.process_scope.run_guarded([sys.executable,'-B',str(PACKET/'export_fresh_json.py'),'--root-receipt',str(ap),'--root-receipt-sha256',ah,'--output-directory',str(exports)],str(c.BOARD),OUT/'owned',policy,{'G350_STRICT18_FRESH_JSON_CLI_ROOT_GUARDED':'1'},before_spawn=prefork)
  except BaseException as ex:
   error=type(ex).__name__+': '+str(ex)
   if (OUT/'owned/execution.json').is_file():execution=c.read(OUT/'owned/execution.json')
  after=None;safter=None;held=False;post_error=None
  try:
   _,nsha,after,safter,_=c.guard.checked();_,asource=c.bindings();closed();bindings()
   held=oldsha==nsha and ssha==asource and before==after and sbefore==safter and c.sha(receipt)==sys.argv[2] and c.sha(ap)==ah
  except BaseException as ex:post_error=type(ex).__name__+': '+str(ex)
  rp=exports/'cli-export-report.json';report=c.read(rp)if rp.is_file()else None
  passed=held and error is None and post_error is None and execution is not None and execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values()) and report is not None and report['exportPassed'] and report['actualSourceSegmentCount']==988
  files=[{'path':str(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':c.sha(p)}for p in sorted([*OUT.iterdir(),*exports.iterdir()])if p.is_file()and not p.is_symlink()]
  post={'scope':m['scope'],'sourceManifestSha256':SOURCE_SHA,'execution':execution,'sourceAndDependenciesHeld':held,'dependenciesBefore':before,'dependenciesAfter':after,'solverDependenciesBefore':sbefore,'solverDependenciesAfter':safter,'runFailure':error,'postverificationFailure':post_error,'outputFiles':files,'resultPath':str(rp),'resultSha256':c.sha(rp)if report else None,'passed':bool(passed),'cliCalls':1 if report else 0,'coreCalls':0,'nativeCalls':0,'cadCalls':0,'expectedMissingOriginalSignalCount':31,'apiAnglesFailed':True,'actualOriginalApiAngleFailures':['source_trace_15','source_trace_16','source_trace_28'],'nativeApiCombinedStagePassed':False,'complete18Accepted':False,'referenceQualified':False,'electricalTimingQualified':False,'accepted49':False,'fabricationReady':False}
  with (OUT/'POSTAUDIT.json').open('x')as f:json.dump(post,f,indent=2);f.write('\n')
  print(json.dumps({k:post[k]for k in ('passed','sourceAndDependenciesHeld','runFailure','postverificationFailure','execution')}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
