# Source-only package101 qualification proposal

Root owns all actual workers. These new ignored sources retain the accepted HS64 base `384628cd46c2b5cb5b32a94d442651eda3c604c8acf19bd85fc68b728f529769`, its 1,870 React elements (1,746 original plus 124 accepted HS additions), 280 real parts, 1,161 original contacts, all original links/source ports/nets and all 64 exact physical HS Bottom branches/barrels. The proposed source adds 65 canonical full-through vias and 101 distinct package Top branches: 166 literal elements, 2,036 total, 129 physical vias and 165 local traces. Seven canonical sites reuse accepted HS vias. DDR solver requests remain 49.

The exact bounded source-only RAM3 shortlist `e887bd6090242fd0b08d8e3be9de11ac5634366c00afd977c394d95a9c8cda08` selects RAM24's retained HS54 via `(1.2,9.8)`, RAM25's new GND via `(.4,8.975)`, and RAM26's new power via `(-.4,9.775)`. Their 0.15 mm Top paths measure 1.365685425, 0.555330086 and 1.340685425 mm, each within the held 1.524 mm local budget. The new GND land intentionally touches only registered original HS8 GND pad729/port730/source_port730 and old Bottom trace55/source_trace987. Its hole must be proved outside both original copper shapes. Record preservation and physical contact are separately checked; a source net label alone cannot authorize a manufacturing exemption.

The stages retain the tested leader guard, source/dependency hashing and cleanup/collection protocol. `process_scope.py` and `inventory.py` are unchanged copies; the exact existing compatible CPython3.12.14 imports NumPy2.3.5/Shapely2.1.2/GEOS3.13.1 from ignored `python-routing`. The six imported package trees are compared before and after. No package installation is needed. The inherited entire pinned board dependency tree and protected/full original source closure are held. Root binds the final child data/overlay/helpers and this packet by exact manifest hashes before running.

| Stage | Owned wall/RSS | Shared ceiling/reserve | Required work |
| --- | --- | --- | --- |
| capture | 60s /1GiB |24GiB /2GiB |Actual pure React comparison, exact1,870 retained props/elements and166 additions |
| types |120s /6GiB |31GiB /1GiB |Node4096MiB heap, existing TypeScript flags; syntax of all three new native modules |
| core |120s /3GiB |26GiB /2GiB |One direct pinned routing-disabled Core; strict accepted-base record/known foreign-antipad forward; numeric101+64 graphs; unchanged native17 plus strict privately registered via/trace/pad guard |

The exact live-memory prefork limits are 22,548,578,304 bytes for capture/Core and 25,769,803,776 bytes for types. The guard reads actual shared memory and refuses launch when the required owned cap plus reserve does not fit. It never treats elapsed time or an uncollected tool session as approval/collection. Core requires both earlier stages to have passed naturally and been collected with unchanged source/dependencies, zero cgroup OOM deltas and an empty owned group.

Root makes a fresh authority file from `AUTHORITY_TEMPLATE_NO_AUTHORIZATION.json`, changing the false/null fields only after checking actual source/resource state and preceding closed postaudit records. The authorized file must supply exact `phase`, stage `scope`, `packetSha256`, stage `policy`, hexadecimal `approvalToken`, `previousClosedPostaudits:[{path,sha256}]`, and truthful exclusivity/collection flags. For types add actual `captureRootCollectionPath`/`captureRootCollectionSha256`; for Core add both capture and types pairs. Actual collection records use the inherited `phase`, exact matching packet, `toolSessionCollected:true`, `toolWrapperExitCode`, actual `postauditPath` and `postauditSha256`. Each stage creates its own fresh exclusive `run-STAGE` directory.

```bash
source /workspace/g350-linux-handheld/cloud/env.sh
python3 -B /workspace/g350-linux-handheld/.cloud-tools/ddr-package101-core-qualification-source-next/guard.py --stage capture --root-receipt ABS_CAPTURE_AUTHORITY --root-receipt-sha256 EXACT_CAPTURE_AUTHORITY_HASH
python3 -B /workspace/g350-linux-handheld/.cloud-tools/ddr-package101-core-qualification-source-next/guard.py --stage types --root-receipt ABS_TYPES_AUTHORITY --root-receipt-sha256 EXACT_TYPES_AUTHORITY_HASH
python3 -B /workspace/g350-linux-handheld/.cloud-tools/ddr-package101-core-qualification-source-next/guard.py --stage core --root-receipt ABS_CORE_AUTHORITY --root-receipt-sha256 EXACT_CORE_AUTHORITY_HASH
```

No author runtime imports, typecheck, board/Core/native worker, autorouting, CLI, Docker or CAD export ran during preparation. The bounded standard-library geometry/data preparation is identified as a raw candidate. Existing canonical hardware/frozen evidence/locks/native patch remain untouched. Even an actual three-stage pass proves local package/HS approaches only: full supply distribution, four-layer custom adjacent filled reference coverage, transitions/returns, complete DDR49/timing and fresh independent CAD connectivity remain open. `referenceQualified=false`, `accepted49=false`, `fabricationReady=false`.
