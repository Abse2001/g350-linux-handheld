Source313:49 editable connected signal routes;35 fresh Core controls PASS.
Resume raw-core.json, core-controls.json, source-plan.json and source-capture.json here.
Candidate299 is in the required Model299 base increment; only Source24 body changed from286.
Both byte cohorts and all three pairs pass planar skew; CA16/26 meet minimum,10 remain short.
FullCA skew17.6628187566mm FAILS. WholeTI/electrical/default/fabrication are false.
Fresh314+316 complete all32 native checks:951 unfiltered findings,0 exceptions:
1 CA skew,70 missing source traces,718 unconnected ports,162 thickness warnings.
Current49 direct logical DDR owners have0 thickness warnings; broader findings are retained.
Fresh315 authenticates234 vias with0 ambiguity/identity/foreign-track violations.
All19 current pours remain UNQUALIFIED. Source272 CAD/earlier pour results are not inherited.
Restore209→228→248→257→272-v2→289→Model299, then this Source313 increment.
Only stdlib copying/archiving and restoration-only checks run in this helper; no SDK/CAD.
