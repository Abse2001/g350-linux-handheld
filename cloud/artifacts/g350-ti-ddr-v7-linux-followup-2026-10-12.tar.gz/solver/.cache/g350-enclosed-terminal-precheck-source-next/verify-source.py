from pathlib import Path
import json,hashlib,stat
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source'
MANIFEST=ROOT/'immutable-source-manifest.json'
EXPECTED="9670e70cc80a6633e13dd2f3f5a1c601abf78da7d73ded01d12fcc3c0e1bd9ff"
assert hashlib.sha256(MANIFEST.read_bytes()).hexdigest()==EXPECTED,'Manifest changed'
m=json.loads(MANIFEST.read_bytes());records=[]
for f in m['sourceFiles']:
 p=SOURCE/f['path'];s=p.lstat();assert stat.S_ISREG(s.st_mode),f['path'];b=p.read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path'];assert stat.S_IMODE(s.st_mode)==m['filesystemModes'][f['path']],f['path'];records.append(f)
assert len(records)==914
assert hashlib.sha256(json.dumps(records,sort_keys=True,separators=(',',':')).encode()).hexdigest()==m['sourceClosureSha256']
assert (SOURCE/'node_modules').is_symlink() and (SOURCE/'node_modules').resolve()==Path('/workspace/bus-lanes-solver/node_modules').resolve()
print(json.dumps({'verified':True,'sourceFiles':914,'sourceClosureSha256':m['sourceClosureSha256'],'runtimeImported':False,'solverExecuted':False}))
