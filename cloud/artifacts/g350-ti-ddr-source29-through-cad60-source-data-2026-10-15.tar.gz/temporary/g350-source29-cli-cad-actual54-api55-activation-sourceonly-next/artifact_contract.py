"""Finite stdlib future29 actual-artifact contract. No SDK/CAD imports.
The Root fills actual prerequisite hashes only after authentic collected0.
"""
import hashlib,json,math,re,stat
from pathlib import Path
BOARD=Path('/workspace/g350-linux-handheld');HERE=Path(__file__).parent
SOURCE_SHA='00421ca4aba188174b657a0787367231e19c7a4c2b1cade7e0f548378cbf1c5a'
NATIVE_SOURCE_SHA='68658658707e829c40916af9011adc909a8400ee84754a5268d65f0bdf3c7df8'
API_SOURCE_SHA='68658658707e829c40916af9011adc909a8400ee84754a5268d65f0bdf3c7df8'
SIGNAL_PROPOSAL=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-source29-joint7-ca6-ca18-reset-editable-source-stages-sourceonly-next/source29-proposal.json')
SIGNAL_SHA='34a35a2ef12829ac11303dfb98ce8c955efcf0c897fa133c79ddcd63d99cf86a'
RAW=CONTROLS=RAW_SHA=CONTROLS_SHA=ACTUAL_NATIVE_COLLECTION=ACTUAL_NATIVE_REPORT=ACTUAL_API_COLLECTION=ACTUAL_API=None
STATE=None
ACTUAL_API_BATCH_COLLECTION={'path': '/workspace/bus-lanes-solver/.cache/root-routing-progress/source29-api-20574-PASS-COLLECTED-root.json', 'sha256': '7a73b2608978f714c05be14432e8a5ca00ba2f2d1493ff5979a6304f14b4cd9d', 'bytes': 52659, 'mode': 384}
ACTUAL_NATIVE_COLLECTION_PIN={'path': '/workspace/bus-lanes-solver/.cache/root-routing-progress/source29-native-90477-PASS-COLLECTED-root.json', 'sha256': 'e415d9f59f13b7820f212e2fdce87dfab61caebe6de8e9db91055e58cb8fa44f', 'bytes': 28939, 'mode': 384}
ACTUAL_NATIVE_REPORT_PIN={'path': '/tmp/g350-source29-native-root-20261015-after53/output/native29-report.json', 'sha256': 'b64da2caabd897511dcb67116d7a1f8249d90214a72a13b461f13ccd4015d025', 'bytes': 253767, 'mode': 384}
API55_GUARD_SHA='076d11931721c5cfe9b0cbedcab11deb05c4e4b863ce6decb48173466f3041a6'
API55_TOOL_SESSION_ID=20574
API55_OWNED_GROUP_IDS=[503042, 503380]
ACTUAL_CORE_BATCH_COLLECTION={'path': '/workspace/bus-lanes-solver/.cache/root-routing-progress/source29-three-stage-36688-PASS-COLLECTED-root.json', 'sha256': '8495deacf6f81fc567f0bdb2616faba51b79caa4b529bb39451ac1fcdc5c143c', 'bytes': 50078, 'mode': 384}
def require(v,label):
 if not v:raise ValueError(label)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def regular(p):
 p=Path(p);require(p.is_absolute()and p.is_file()and not p.is_symlink(),'Absolute regular artifact');return p
def load(row):
 require(isinstance(row,dict)and isinstance(row.get('path'),str)and isinstance(row.get('sha256'),str)and re.fullmatch('[0-9a-f]{64}',row['sha256']),'Concrete actual binding, no placeholder')
 p=regular(row['path']);require(p.stat().st_size<=32*1024*1024 and sha(p)==row['sha256'],'Exact finite actual artifact');return json.loads(p.read_bytes())
def binding(row):
 p=regular(row['path']);require(p.stat().st_size==row['bytes']and stat.S_IMODE(p.stat().st_mode)==row['mode']and sha(p)==row['sha256'],'Exact Source binding')
def one(rows,label):
 require(len(rows)==1,label+'; matches='+str(len(rows)));return rows[0]
def near(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])<1e-8
def index(raw,kind):
 rows=[r for r in raw if r['type']==kind];out={r[kind+'_id']:r for r in rows};require(len(rows)==len(out),'Unique actual '+kind);return out
def collected(row):
 c=load(row);require(c.get('authorizedByRoot')is True and c.get('toolSessionCollected')is True and c.get('passed')is True and c.get('toolExitCode')==c.get('toolWrapperExitCode')==0 and isinstance(c.get('toolSessionId'),int),'Actual successful collected Root natural0')
 post=load({'path':c['postauditPath'],'sha256':c['postauditSha256']});e=post['execution'];require(c['execution']==e and e['exitCode']==0 and e['diagnosticStopped']is False and e['cleanupOwnedGroupEmpty']is True and not any(e['oomDelta'].values()),'Actual natural child0/closed/OOM0')
 require(c['sourceAndDependenciesHeld']is True and post['sourceAndDependenciesHeld']is True and post['passed']is True,'Source/SDK held0')
 for prefix,digest in [('dependencies','ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'),('solverDependencies','47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6')]:require(post[prefix+'Before']==post[prefix+'After']and post[prefix+'After']['treeSha256']==digest,'Complete ce3/476 held')
 require(any(k in post for k in ('accepted49','all49Accepted'))and all(post[k]is False for k in ('accepted49','all49Accepted')if k in post)and post['fabricationReady']is False,'Partial acceptance remains explicit')
 if post.get('scope')=='ROOT_SOURCE29_FRESH49_PROJECTION_AND_API131_WITH_AUTHENTIC_PRIOR_CLOSURES':
  pe=post['projectionExecution'];require(post['apiExecution']==e and pe['exitCode']==0 and pe['cleanupOwnedGroupEmpty']is True and pe['diagnosticStopped']is False and not pe['stopReasons']and not any(pe['oomDelta'].values()),'Actual serial projection child0/closed/OOM0')
  require(post['projectionOwnedChildWaitReturned']is post['projectionOwnedGroupEmptyActuallyObserved']is post['apiOwnedGroupEmptyActuallyObserved']is post['bothOwnedGroupsIndependentlyObservedEmpty']is post['projectionBeforeApiSeriallyEnforced']is True and pe['pgid']!=e['pgid']and pe['endedAt']<=e['startedAt'],'Both distinct owned children closed serially')
 return c,post
def produced(post,row):
 key='outputFiles';require(isinstance(post.get(key),list),'Current actual Core/Native/API outputFiles schema')
 require(any(r['path']==row['path']and r['sha256']==row['sha256']for r in post[key]),'Actual collected output required');return load(row)
def authority(row,manifest_sha,scope):
 global STATE,RAW,CONTROLS,RAW_SHA,CONTROLS_SHA,ACTUAL_NATIVE_COLLECTION,ACTUAL_NATIVE_REPORT,ACTUAL_API_COLLECTION,ACTUAL_API
 a=load(row);require(a.get('authorizedByRoot')is True and a.get('scope')==scope and a.get('sourceManifestSha256')==manifest_sha and a.get('actualPreviousScopesCollectedAndEmpty')is True and a.get('noConcurrentRootWorker')is True and a.get('rootFullWorkerReadPassed')is True,'Fresh Root serial/full-read authority')
 require(isinstance(NATIVE_SOURCE_SHA,str)and re.fullmatch('[0-9a-f]{64}',NATIVE_SOURCE_SHA)and isinstance(API_SOURCE_SHA,str)and re.fullmatch('[0-9a-f]{64}',API_SOURCE_SHA),'Future Native/API source pins remain unbound')
 require(isinstance(ACTUAL_NATIVE_COLLECTION_PIN,dict)and isinstance(ACTUAL_NATIVE_REPORT_PIN,dict)and isinstance(ACTUAL_API_BATCH_COLLECTION,dict)and isinstance(API55_GUARD_SHA,str)and re.fullmatch('[0-9a-f]{64}',API55_GUARD_SHA)and type(API55_TOOL_SESSION_ID)is int and API55_TOOL_SESSION_ID>0 and isinstance(API55_OWNED_GROUP_IDS,list)and len(API55_OWNED_GROUP_IDS)==len(set(API55_OWNED_GROUP_IDS))==2 and all(type(p)is int and p>1 for p in API55_OWNED_GROUP_IDS),'Future actual54 Native and actual55 projection/API remain unbound')
 require(a['actualNativeCollection']==ACTUAL_NATIVE_COLLECTION_PIN and a['actualNativeReport']==ACTUAL_NATIVE_REPORT_PIN and a['actualApiCollection']==ACTUAL_API_BATCH_COLLECTION,'Exact genuine future54/55 collection/report pins required')
 require(a['genuineSourceManifestSha256']==SOURCE_SHA and a['actualNativeSourceManifestSha256']==NATIVE_SOURCE_SHA and a['actualApiSourceManifestSha256']==API_SOURCE_SHA,'Exact fresh29 Source and reviewed separate Native/API source')
 for key in ['actualCoreCollection','actualCoreRaw','actualCoreControls','actualNativeCollection','actualNativeReport','actualApiCollection','actualOriginalApiReport','actualFresh49Model','actualFresh49ProjectionProof']:load(a[key])
 STATE=a;RAW=Path(a['actualCoreRaw']['path']);RAW_SHA=a['actualCoreRaw']['sha256'];CONTROLS=Path(a['actualCoreControls']['path']);CONTROLS_SHA=a['actualCoreControls']['sha256'];ACTUAL_NATIVE_COLLECTION=a['actualNativeCollection'];ACTUAL_NATIVE_REPORT=a['actualNativeReport'];ACTUAL_API_COLLECTION=a['actualApiCollection'];ACTUAL_API=a['actualOriginalApiReport'];return a
def core_batch53():
 # Actual53 is a collected batch with three per-phase POSTs; never invent execution.
 c=load(STATE['actualCoreCollection'])
 require({k:STATE['actualCoreCollection'][k]for k in ('path','sha256')}=={k:ACTUAL_CORE_BATCH_COLLECTION[k]for k in ('path','sha256')},'Exact genuine actual53 collected batch')
 require(c['authorizedByRoot']is c['toolSessionCollected']is c['passed']is True and c['toolSessionId']==36688 and c['toolExitCode']==c['toolWrapperExitCode']==0,'Actual53 Root collection natural0')
 post=load({'path':c['postauditPath'],'sha256':c['postauditSha256']})
 require(c['sourceManifestSha256']==post['sourceManifestSha256']==SOURCE_SHA and c['phase']==post['phase']=='capture-types-core-batch'and c['scope']==post['scope']=='ROOT_SOURCE29_THREE_SERIAL_CAPTURE_TYPES_CORE_WITH52_AUTHENTIC_PRIOR_CLOSURES','Actual53 Source29 batch scope')
 require(c['phases']==post['phases']and c['orderedPhaseNames']==post['orderedPhaseNames']==['capture','types','core']and c['expectedPhaseNames']==post['expectedPhaseNames']==['capture','types','core']and c['notAttemptedPhaseNames']==post['notAttemptedPhaseNames']==[],'All three attempted in exact order')
 for obj in (c,post):
  require(all(obj[k]is True for k in ['historyAuthenticatedOnceBeforeBatch','guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','allThreeChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passedMeansCaptureStrictTypesAndRawCore29Only','batchScopeContainsThreeSerialOwnedChildren']),'Actual53 complete held serial batch')
  require(obj['batchFailure']is obj['finalVerificationFailure']is None and obj['CoreCalls']==obj['CoreChildInvocations']==obj['captureChildInvocations']==obj['typesChildInvocations']==1,'One real Core invocation and each prerequisite child')
  require(all(obj[k]==0 for k in ['nativeCalls','originalApiCalls','cliCalls','cadCalls','newRoutesAdopted'])and all(obj[k]is False for k in ['Source29Accepted','all49Accepted','referenceQualified','electricalTimingPassed','fabricationReady']),'Batch only, all broader qualification withheld')
  for prefix,digest in [('dependencies','ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'),('solverDependencies','47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6')]:require(obj[prefix+'Before']==obj[prefix+'After']and obj[prefix+'After']['treeSha256']==digest,'Actual53 full SDK holdings')
 require(c['independentlyObservedAllOwnedGroupsEmpty']is c['independentlyObservedGuardAbsent']is True and c['independentProcReadErrors']==[]and c['independentlyObservedOwnedGroupMembers']=={'500361':[],'500419':[],'500510':[]},'Root actual53 independent closure observations')
 phases=post['phases'];require(len(phases)==3 and len({r['execution']['pgid']for r in phases})==3,'Three distinct owned children')
 prior_end=None
 for number,phase in enumerate(phases):
  require(phase['phase']==['capture','types','core'][number]and all(phase[k]is True for k in ['passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0']),'Actual53 per-phase success and owned closure')
  require(all(phase[k]is None for k in ['runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure']),'No phase failure')
  actual_post=load({'path':phase['postauditPath'],'sha256':phase['postauditSha256']});require(actual_post=={k:v for k,v in phase.items()if k not in ('postauditPath','postauditSha256')},'Every actual separate phase POST matches its final batch row')
  e=phase['execution'];require(e['exitCode']==0 and e['diagnosticStopped']is False and e['stopReasons']==[]and e['cleanupOwnedGroupEmpty']is True and not any(e['oomDelta'].values())and e['signalErrors']==[],'Every child natural0/no resource stop/OOM0/groupempty')
  require(e['command']==phase['command']and e['pgid']==e['pid']==[500361,500419,500510][number]and (prior_end is None or prior_end<=e['startedAt']),'Genuine exact commands and serial lifetimes');prior_end=e['endedAt']
  require(phase['guardIdentityBefore']==phase['guardIdentityAfter']==post['sameGuardIdentity']and e['currentGuardPid']==post['sameGuardIdentity']['pid'],'Same authenticated guard across all three children')
  require(phase['CoreCalls']==phase['CoreChildInvocations']==(1 if number==2 else 0)and all(phase[k]==0 for k in ['nativeCalls','originalApiCalls','cliCalls','cadCalls']),'Uppercase per-phase CoreCalls accounting')
  before=phase['phaseSnapshotsBefore'];after=phase['phaseSnapshotsAfter'];require(before==after and after['board']['treeSha256']=='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'and after['solver']['treeSha256']=='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6','Each phase SDK holdings exact')
 capture,types,core=phases
 require(capture['result']['fullSourceInversePassed']is True and capture['result']['CoreExecuted']is False and types['result']['strictNoEmitTypecheckNatural0']is True and types['result']['actualPriorCapturePin']==capture['result']['sourceCapturePin'],'Genuine capture inverse and strict types precede Core')
 for key in ['sourceCapturePin','sourceDiagnosticPin']:produced(capture,capture['result'][key])
 require(core['CoreCalls']==1 and core['result']['all29CorePredicatesPassed']is True and core['result']['actualCandidateCarrierCount']==29 and core['result']['nativeQualificationPerformed']is False,'Actual53 Core29/29 only')
 require(core['result']['rawCorePin']==STATE['actualCoreRaw']and core['result']['coreControlsPin']==STATE['actualCoreControls'],'Exact actual53 produced Core/control bindings')
 return c,post,core

def api_batch55():
 # Real actual55 is a two-child batch; neither a top-level execution nor outputFiles is invented.
 require(STATE is not None,'Actual Root bindings required first')
 require(STATE['actualApiCollection']==ACTUAL_API_BATCH_COLLECTION,'Exact genuine actual55 Root collection')
 c=load(ACTUAL_API_BATCH_COLLECTION);post=load({'path':c['postauditPath'],'sha256':c['postauditSha256']})
 require(c['authorizedByRoot']is c['toolSessionCollected']is c['passed']is True and c['toolSessionId']==API55_TOOL_SESSION_ID and c['toolExitCode']==c['toolWrapperExitCode']==0,'Actual55 Root collection natural0')
 require(c['phases']==post['phases']and c['projectionExecution']==post['projectionExecution']and c['apiExecution']==post['apiExecution'],'Actual55 phase rows and execution aliases exact')
 for obj in (c,post):
  require(obj['scope']=='ROOT_SOURCE29_FRESH49_PROJECTION_AND_ORIGINAL_API131_WITH54_AUTHENTIC_PRIOR_CLOSURES'and obj['phase']=='projection-api-batch'and obj['sourceManifestSha256']==API_SOURCE_SHA and obj['coreSourceManifestSha256']==SOURCE_SHA and obj['rootGuardProposalManifestSha256']==API55_GUARD_SHA,'Actual55 exact Source/API/guard scope')
  require(obj['orderedPhaseNames']==obj['expectedPhaseNames']==['projection','api']and obj['notAttemptedPhaseNames']==[]and len(obj['phases'])==2,'Exactly two real phases')
  require('execution'not in obj and 'outputFiles'not in obj and 'packetSha256'not in obj,'Do not synthesize standalone API receipt shape')
  require(all(obj[k]is True for k in ['guardIdentityHeldAcrossChildren','allOwnedGroupsIndependentlyObservedEmpty','eachAttemptedChildNaturallyCompleted','bothChildrenNaturallyCompleted','sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','passed','projectionPassed','apiPassed','projectionBeforeApiSeriallyEnforced','passedMeansFresh49ProjectionAndOriginalLoaded29Api131Only','hardwareAcceptanceCheckpointUnchanged']),'Actual55 complete serial held success')
  require(obj['batchFailure']is obj['finalVerificationFailure']is None and obj['originalApiBooleanPredicates']==131 and obj['originalApiCalls']is None and obj['originalApiMethodInvocationCountNotInstrumented']is True,'Actual131 predicates, method count not invented')
  require(all(obj[k]==0 for k in ['CoreCalls','nativeCalls','cliCalls','cadCalls','newRoutesAdopted'])and all(obj[k]is False for k in ['Source29Accepted','all49Accepted','accepted49','referenceQualified','electricalTimingPassed','fabricationReady']),'No broader adoption or application calls')
  require(obj['actualCorePath']==str(RAW)and obj['actualCoreSha256']==RAW_SHA and obj['actualNativeReport']==ACTUAL_NATIVE_REPORT and obj['actualFresh49Model']==STATE['actualFresh49Model']and obj['actualFresh49ProjectionProof']==STATE['actualFresh49ProjectionProof'],'Exact current29 data provenance')
  for prefix,digest in [('dependencies','ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'),('solverDependencies','47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6')]:require(obj[prefix+'Before']==obj[prefix+'After']and obj[prefix+'After']['treeSha256']==digest,'Actual55 full SDK holdings')
 require(c['independentlyObservedAllOwnedGroupsEmpty']is c['independentlyObservedGuardAbsent']is True and c['independentProcReadErrors']==[]and c['independentlyObservedOwnedGroupMembers']=={str(p):[]for p in API55_OWNED_GROUP_IDS},'Root actual55 independent closure observations')
 phases=post['phases'];require([r['execution']['pgid']for r in phases]==API55_OWNED_GROUP_IDS,'Two authentic owned groups')
 prior_end=None
 for number,phase in enumerate(phases):
  require(phase['phase']==['projection','api'][number]and all(phase[k]is True for k in ['passed','sourceAndDependenciesHeld','ownedGroupEmptyActuallyObserved','stageNaturallyCompleted','ownedChildNatural0']),'Every actual55 child passed and closed')
  require(all(phase[k]is None for k in ['runFailure','postverificationFailure','resultInspectionFailure','outputBindingFailure']),'No actual55 phase failure')
  require(load({'path':phase['postauditPath'],'sha256':phase['postauditSha256']})=={k:v for k,v in phase.items()if k not in ('postauditPath','postauditSha256')},'Separate actual phase POST exactly matches batch row')
  e=phase['execution'];require(e==post[['projectionExecution','apiExecution'][number]]and e['exitCode']==0 and e['diagnosticStopped']is False and e['stopReasons']==[]and e['cleanupOwnedGroupEmpty']is True and not any(e['oomDelta'].values())and e['signalErrors']==[],'Natural0/OOM0/no stop/ownedempty')
  require(e['command']==phase['command']and e['pid']==e['pgid']and(prior_end is None or prior_end<=e['startedAt']),'Exact commands and serialized lifetimes');prior_end=e['endedAt']
  require(e['policy']=={'wallSeconds':[60,90][number],'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5},'Original bounded phase policies')
  require(phase['guardIdentityBefore']==phase['guardIdentityAfter']==post['sameGuardIdentity']and e['currentGuardPid']==post['sameGuardIdentity']['pid'],'One held actual Root guard')
  require(phase['phaseSnapshotsBefore']==phase['phaseSnapshotsAfter']and phase['phaseSnapshotsAfter']['board']['treeSha256']=='ce3d0f533c76b34c74a1e3a349d79288fa2a97396d75c9515b36e7fcdacef4e2'and phase['phaseSnapshotsAfter']['solver']['treeSha256']=='47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6','Each phase full SDK held')
  require(all(phase[k]==0 for k in ['CoreCalls','nativeCalls','cliCalls','cadCalls']),'No Core/Native/CLI/CAD inside actual55')
 projection,api=phases
 require(projection['result']['actualFresh49Model']==STATE['actualFresh49Model']and projection['result']['actualFresh49ProjectionProof']==STATE['actualFresh49ProjectionProof']and projection['result']['source29FreshFull49ProjectionPassed']is projection['result']['zeroSelected29CarrierBodiesSeeded']is True,'Actual unseeded fresh29 model and proof')
 require([projection['result'][k]for k in ['actual49Requests','actualFixedTraces','actualHardObstacles','actualSignalViaEvents']]==[49,263,1298,98],'Original full49 current material')
 for key in ['actualFresh49Model','actualFresh49ProjectionProof']:produced(projection,STATE[key])
 require(api['result']['actualOriginalApiReportPin']==ACTUAL_API and api['result']['originalApiLoaded29ChecksPassed']is api['result']['bothDqs1CoupledViewsPassed']is True and api['result']['originalApiBooleanPredicates']==131 and api['result']['apiMethodInvocationCount']is None and api['result']['methodCountNotInstrumented']is True,'Actual131 API predicates and both real DQS1 views')
 require(api['result']['loadedCohortsExplicitlyPartial']=={'DDR_BYTE0':6,'DDR_BYTE1':11,'DDR_COMMAND_CLOCK':11},'Partial original cohorts remain explicit')
 require(c['actualOriginalApiReportPin']==ACTUAL_API and c['actualApiPacketPin']==api['packetPin'],'Root collector binds actual API report and packet metadata')
 return c,post,api

def actual_core():
 require(STATE is not None,'Actual Root bindings required first');c,post,core=core_batch53();require(c['CoreCalls']==core['CoreCalls']==1,'Actual uppercase CoreCalls==1 for genuine53 Core child')
 raw=produced(core,STATE['actualCoreRaw']);controls=produced(core,STATE['actualCoreControls']);require(controls['rawCorePath']==str(RAW)and controls['rawCoreSha256']==RAW_SHA and controls['freshCoreControlPassed']is True and len(controls['checks'])==29 and all(c['passed']is True for c in controls['checks']),'Actual all29 fresh Core controls')
 require(controls['sourceNumericAndPhysicalIdsDerivedWithoutAssignment']is True and controls['circuitJsonGeometryEdited']is False and controls['automaticCoreSrjForThisForkMustNotBeUsed']is True and controls['expectedOriginalCarrierCount']==29 and controls['expectedMissingOriginalSignalCount']==20,'Genuine29/manual fork/20 missing')
 return raw,controls
def native_outputs():
 # Native18 and API131 are separate actual Root scopes; never force them to share a packetsha.
 nc,np=collected(ACTUAL_NATIVE_COLLECTION);report=produced(np,ACTUAL_NATIVE_REPORT)
 ac,ap,api_phase=api_batch55();api=produced(api_phase,ACTUAL_API)
 require(nc['sourceManifestSha256']==np['sourceManifestSha256']==report['sourceManifestSha256']==NATIVE_SOURCE_SHA,'Actual reviewed Native29 source')
 require(ac['sourceManifestSha256']==ap['sourceManifestSha256']==API_SOURCE_SHA,'Actual reviewed API29 source')
 require(nc['packetSha256']==np['packetSha256']==report['packetSha256'] and api_phase['packetPin']['sha256']==api['packetSha256'],'Each report belongs to its own authentic collected packet')
 require(report['actualCoreSha256']==api['actualCoreSha256']==RAW_SHA and report['actualCoreControlsSha256']==CONTROLS_SHA,'Same actual fresh29 raw/control hashes')
 require(api['actualNativeReportPath']==ACTUAL_NATIVE_REPORT['path'] and api['actualNativeReportSha256']==ACTUAL_NATIVE_REPORT['sha256'],'API binds actual prior Native report')
 require(api['original49Input']=={k:STATE['actualFresh49Model'][k]for k in ('path','sha256')} and api['fresh49ProjectionProof']['path']==STATE['actualFresh49ProjectionProof']['path'] and api['fresh49ProjectionProof']['sha256']==STATE['actualFresh49ProjectionProof']['sha256'],'Fresh49 model/projection bindings')
 projection=load(STATE['actualFresh49ProjectionProof']);require(projection['actualCoreSha256']==RAW_SHA and projection['actualNativeReportSha256']==ACTUAL_NATIVE_REPORT['sha256'] and projection['constructorInputSha256']==STATE['actualFresh49Model']['sha256'],'Fresh49 derived from this actual29 Core and Native')
 require(projection['sourceManifestSha256']==SOURCE_SHA and projection['originalSource29ProposalSha256']==SIGNAL_SHA and projection['exactFullInverseToFresh29Parent']is True,'Exact same Source29 fresh49 inverse provenance')
 require(report['checkCount']==len(report['counts'])==18 and not any(report['counts'].values())and report['physicalErrors']==0 and report['actualNativePairFindings']==[]and report['physicalCpuRamConnectedCarrierCount']==29,'Native18/all3pair findings0/29 graphs')
 require(api['allOriginalApiLoaded26ChecksPassed']is True and api['exactMaterialHeld']is True and api['actualCompleteOriginalSignalCount']==29 and api['expectedMissingOriginalSignalCount']==20,'All actual original API predicates passed on29')
 require(api['fullOriginalBusRostersAndConstraintsHeld']is True and api['originalFullDifferentialPairArrayUnchanged']is True and api['originalPrivateContinuousApiImplementationsUnchanged']is True,'All original49 rules held')
 for key in ['shared','exterior','coupling','pairLengths']:require(len(api[key])==3 and all(r['matched']is True for r in api[key]),'All3 original '+key+' predicates')
 require(len(api['continuity'])==29 and all(r['pathVisible']and r['selfClear']and r['conventionalAngles']and r['segmentsVisible']and all(r['segmentsVisible'])for r in api['continuity']),'All29 continuous/self/angle predicates')
 second=api['secondaryDqs1View'];require(second['name']=='early_reflected_meander'and second['geometryAndEndpointsUnchanged']is True and second['passed']is True,'Both real DQS1 shared meanders checked')
 for key in ['shared','exterior','coupling']:require(len(second[key])==1 and all(r['matched']is True for r in second[key]),'Second actual DQS1 '+key)
 require(api['checkInventory']['primaryBooleanPredicates']==128 and api['checkInventory']['secondaryDqs1BooleanPredicates']==3 and api['checkInventory']['primaryPlusSecondaryBooleanPredicates']==131,'All primary128 plus secondary3 preserved')
 require(len(api['loadedCohortBusReports'])==3 and all(r['aboveMinimumLength']and r['withinLengthLimit']and r['matched']for r in api['loadedCohortBusReports']),'All original loaded-cohort bounds')
 for obj in [report,api]:require(obj['accepted49']is False and obj['fabricationReady']is False and obj['referenceQualified']is False,'No broader qualification')
 return report,np
def derive_owned(raw,controls,proposal):
 report,_=native_outputs();proof=report['actualOwnershipProof'];kinds=['pcb_via','pcb_trace','pcb_port','source_port','pcb_component','source_component','source_trace','source_manually_placed_via'];ix={k:index(raw,k)for k in kinds}
 require([len(ix[k])for k in ['pcb_via','pcb_trace','pcb_component','source_component','pcb_port']]==[227,292,507,280,1661],'Exact fresh227/292/507/280/1661')
 signals=proof['signalMappings'];carriers=proof['carriers'];require(len(signals)==98 and len(carriers)==29 and len(proof['referenceMappings'])==165,'Native authentic98/29/165 proofs')
 require(len({s['actualViaId']for s in signals})==98 and len({s['actualPcbTraceId']for s in signals})==98,'Unique actual signal barrels/stubs')
 for s in signals:
  owner=one([o for o in proposal['all98NumericOwnedSignalBranches']if o['viaName']==s['sourceViaName']],'Actual Source named via branch')
  numeric=ix['pcb_port'][s['actualNumericPcbPortId']];sp=ix['source_port'][numeric['source_port_id']];part=ix['source_component'][sp['source_component_id']]
  require(part['name']+'.pin'+str(sp['pin_number'])==owner['numericSelector']and near(numeric,owner['padXY']),'Real numeric package/pad')
  via=ix['pcb_via'][s['actualViaId']];top=ix['pcb_port'][s['actualTopPcbPortId']];trace=ix['pcb_trace'][s['actualPcbTraceId']]
  require(near(via,owner['viaXY'])and via['layers']==['top','inner1','inner2','bottom']and via['outer_diameter']==.4572 and via['hole_diameter']==.254 and via['from_layer']=='top'and via['to_layer']=='bottom','Real fullspan barrel')
  require(top['pcb_port_id']in via['pcb_port_ids']and top['layers']==['top']and near(top,via)and ix['source_port'][top['source_port_id']]['source_component_id']==s['sourceViaOwnerId'],'Actual same-owner alias')
  expected=owner['topStub'];wire=trace['route'];long=s['originalSourceTraceId']=='source_trace_14'and s['side']==1;moved_cpu3=s['originalSourceTraceId']=='source_trace_3'and s['side']==0;moved_ram7=s['originalSourceTraceId']=='source_trace_7'and s['side']==1
  require(len(expected)==(11 if long else 4 if moved_cpu3 else 13 if moved_ram7 else 2)and len(wire)==len(expected),'Only actual moved14 RAM has11 and moved3 CPU has4 wirepoints; moved7 RAM has13; other95 have2')
  same=lambda points:all(near(p,q)for p,q in zip(points,expected))
  require(trace['source_trace_id']==s['actualPhysicalSourceTraceId']and all(p['route_type']=='wire'and p['layer']=='top'and p['width']==.1016 for p in wire)and(same(wire)or same(wire[::-1]))and {wire[0].get('start_pcb_port_id'),wire[-1].get('end_pcb_port_id')}=={numeric['pcb_port_id'],top['pcb_port_id']},'Actual full Topstub polyline/numeric ownership/geometry')
 for c in carriers:
  paths=[t for t in ix['pcb_trace'].values()if t['source_trace_id']==c['originalSourceTraceId']];require(len(paths)==3 and set(c['actualDirectPcbTraceIds'])=={t['pcb_trace_id']for t in paths},'Exactly3 actual Source-owned paths')
  d=one([d for d in proposal['selected29OriginalCarriers']if d['originalSourceTraceId']==c['originalSourceTraceId']],'Original selected Source carrier')
  body=ix['pcb_trace'][c['actualCarrierPcbTraceId']];require(c['carrierLayer']==d['carrierLayer']and len(body['route'])==len(d['expectedCarrierPath'])and all(p['route_type']=='wire'and p['layer']==c['carrierLayer']and p['width']==.1016 and near(p,q)for p,q in zip(body['route'],d['expectedCarrierPath'])),'Authentic complete carrier')
  require(body['route'][0].get('start_pcb_port_id')==c['actualCpuCarrierLayerPcbPortId']and body['route'][-1].get('end_pcb_port_id')==c['actualRamCarrierLayerPcbPortId'],'Genuine actual carrier endpoints')
  require(c['actualSourceOwnedPhysicalGraph']['physicallyConnected']is True and c['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is True,'Native proved real numeric physical graph')
  whole=sum(math.hypot(b['x']-a['x'],b['y']-a['y'])for t in paths for a,b in zip(t['route'],t['route'][1:]));require(abs(whole-c['wholePlanarLengthMm'])<1e-8 and abs(whole-d['expectedWholePlanarMm'])<1e-8,'Actual all3-path planar length')
 require(len({c['originalSourceTraceId']for c in carriers})==29,'29 distinct original signals')
 segments=sum(a['x']!=b['x']or a['y']!=b['y']for t in ix['pcb_trace'].values()for a,b in zip(t['route'],t['route'][1:]));require(segments==1053,'Exact Source29 current1053 nonzero segments');return ix,signals,carriers,segments
def native_prerequisite(authority,carriers):
 require(authority['actualNativeCollection']==ACTUAL_NATIVE_COLLECTION and authority['actualNativeReport']==ACTUAL_NATIVE_REPORT,'Same Root-bound Native prerequisite')
 report,post=native_outputs();require({c['originalSourceTraceId']for c in carriers}=={c['originalSourceTraceId']for c in report['actualOwnershipProof']['carriers']},'Same authentic29 proof');return report,post
