import {readFileSync, writeFileSync} from "node:fs"
import {createHash} from "node:crypto"
import {resolve} from "node:path"
import {buildV12cSource} from "./v12c-final-layer-overlay"
if (import.meta.main) {
  const [output, ...extra] = process.argv.slice(2)
  if (!output || extra.length) throw Error("Usage: bun --smol capture-v12c-authored-props.ts FRESH_OUTPUT_JSON")
  const bytes = readFileSync(resolve(import.meta.dir, "derived-final-authored-props.json"))
  const expected = JSON.parse(bytes.toString())
  const actual = buildV12cSource()
  for (const key of ["authoredPolicyProof", "referenceCopperCandidates", "referenceQualified", "TIplaneArrangement", "globalSignalLayerProjection", "naturallyDerivedGenericDefaultCap"] as const)
    if (JSON.stringify(actual[key]) !== JSON.stringify(expected[key])) throw Error("Actual final V12c props differ: " + key)
  writeFileSync(output, JSON.stringify({scope:"PURE_ACTUAL_V12C_FINAL_REACT_PROPS_REFERENCE_UNQUALIFIED",
    actualFinalReactTreeEvaluated:true, derivedProofSha256:createHash("sha256").update(bytes).digest("hex"),
    authoredPolicyProof:actual.authoredPolicyProof, referenceCopperCandidates:actual.referenceCopperCandidates,
    globalSignalLayerProjection:actual.globalSignalLayerProjection,
    naturallyDerivedGenericDefaultCap:actual.naturallyDerivedGenericDefaultCap,
    referenceQualified:false, TIplaneArrangement:false, coreRenderCalled:false,
    nativePlacementChecksInvoked:false, routingSolverInstantiated:false, accepted49:false, fabricationReady:false},null,2)+"\n",{flag:"wx",mode:0o600})
}
