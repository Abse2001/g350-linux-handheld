 def closed59():
  prior=closed58();assert prior['actualClosedScopeCount']==58
  for key in('actual59FailedCollectionPin','actual59PostauditPin','actual59ZoneExecutionPin','actual59CadExecutionPin','actual59ZonePinsPin','actual59WorkerFailureReportPin','actual59ResourcePin','actual59GuardManifestPin','actual59SnapshotWrapperPin'):assert isinstance(proposal[key],dict);binding(proposal[key])
  r=read(proposal['actual59FailedCollectionPin']['path']);p=read(proposal['actual59PostauditPin']['path']);v=read(proposal['actual59WorkerFailureReportPin']['path']);resource=read(proposal['actual59ResourcePin']['path']);zone=read(proposal['actual59ZonePinsPin']['path']);ze=r['zonePinsExecution'];ce=r['cadExecution']
  assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==31552 and r['toolWrapperExitCode']==r['toolExitCode']==2
  assert r['scope']==p['scope']=='ROOT_SOURCE29_FRESH_OFFLINE_CAD_WITH58_AUTHENTIC_PRIOR_CLOSURES'and r['phase']==p['phase']=='cad'
  assert r['sourceManifestSha256']==p['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==p['rootGuardProposalManifestSha256']==proposal['actual59GuardManifestPin']['sha256']
  assert r['postauditPath']==proposal['actual59PostauditPin']['path']and sha(r['postauditPath'])==r['postauditSha256']==proposal['actual59PostauditPin']['sha256']and r['actualClosedPriorScopes']==p['actualClosedPriorScopes']==prior
  assert read(proposal['actual59ZoneExecutionPin']['path'])==ze==p['zonePinsExecution']and read(proposal['actual59CadExecutionPin']['path'])==ce==p['cadExecution']==p['execution']==r['execution']
  for doc in(r,p):
   for key in('sourceAndDependenciesHeld','workspaceFreeBytesFloorHeld','gitMetadataHeld','hardwareAcceptanceCheckpointUnchanged','ownedGroupEmptyActuallyObserved','zonePinsOwnedGroupEmptyActuallyObserved','cadOwnedGroupEmptyActuallyObserved','bothOwnedGroupsIndependentlyObservedEmpty','zoneBeforeCadSeriallyEnforced','zonePinsChildNatural0'):assert doc[key]is True
   for key in('passed','resultPassed','stageNaturallyCompleted','cadChildNatural0','resourceGateBlockedBeforeContainer','Source29Accepted','referenceQualified','electricalTimingPassed','all49Accepted','accepted49','fabricationReady'):assert doc[key]is False
   assert doc['ownedContainerActuallyEmpty']is None and doc['actualCadApplicationCompletionUnknown']is True and doc['cadCalls']is None
   assert doc['runFailure']is doc['postverificationFailure']is None and doc['resultInspectionFailure']=='Resource receipt AssertionError: ; AssertionError: '
   assert doc['zonePinsChildInvocations']==1 and doc['CoreCalls']==doc['nativeCalls']==doc['originalApiCalls']==doc['cliCalls']==doc['newRoutesAdopted']==0
  assert p['dependenciesBefore']==p['dependenciesAfter']and p['solverDependenciesBefore']==p['solverDependenciesAfter']and p['dependenciesBefore']['treeSha256']==stage['boardSdkTreeSha256']and p['solverDependenciesBefore']['treeSha256']==stage['solverSdkTreeSha256'];h.held_inventory_post(p)
  h.finite(ze,0);h.finite(ce,2);assert ze['policy']==cad29_contract['zonePinsPolicy']and ce['policy']==cad29_contract['cadPolicy']and ze['endedAt']<=ce['startedAt']
  assert ze['pid']==ze['pgid']==508276 and ce['pid']==ce['pgid']==508277 and ze['currentGuardPid']==ce['currentGuardPid']==508271
  assert c.guard.process_scope.owned(508276)==c.guard.process_scope.owned(508277)==[]and not Path('/proc/508271').exists()
  assert r['independentlyObservedAllActuallySpawnedOwnedGroupsEmpty']is r['independentlyObservedGuardAbsent']is True and r['independentlyObservedOwnedGroupMembers']=={'508276':[],'508277':[]}and r['independentProcReadErrors']==[]
  assert r['cadWrapperSpawned']is r['containerInvocationPerformed']is r['cadDiagnosticWorkerInvoked']is r['workerFailedBeforeCadBoardLoad']is True
  assert r['actualKiCadLoadBoardPerformed']is r['actualConnectivityDiagnosticPerformed']is False and r['diagnosticFailure']==v['failure']=='ValueError: Absolute regular artifact'
  # Root and the owned resource reporter establish absence separately; preserve the outer POST null.
  assert r['rootIndependentExactContainerPsWrapperExitCode']==0 and r['rootIndependentlyObservedOwnedContainerAbsent']is r['containerCleanupEvidenceActuallyEmpty']is r['outerPostContainerEmptyRemainsNull']is True
  assert resource==r['containerResourceObservations']==p['containerResourceObservations']and p['containerResourceObservationsBinding']==r['containerCleanupEvidenceBinding']==proposal['actual59ResourcePin']
  assert resource['scope']=='ROOT_OWNED_CAD_CHILD_ACTUAL_DOCKER_RESOURCES'and resource['imageId']==cli29_preparation['imageId']and resource['containerName']==r['ownedContainerName']==p['ownedContainerName']=='g350-source29-fresh-cad-26a8fb65e40f70d0-b128c08f004e8974'
  assert resource['cleanupStatusRecorded']is resource['ownedContainerActuallyEmpty']is True and resource['containerWorkerStatus']==2
  observations=resource['observations'];assert len(observations)==2 and [x['phase']for x in observations]==['BEFORE_CONTAINER','AFTER_CLEANUP']
  for x in observations:assert x['imageId']==cli29_preparation['imageId']and x['imageSizeBytes']==1519935209 and x['storageDriver']=='vfs'and x['dockerRootDir']=='/var/lib/docker'and x['requiredVfsBytes']==2*x['imageSizeBytes']+201326592 and x['actualVfsReserveSatisfiedAtObservation']is x['imageAlreadyPresent']is x['noImageLoadBuildPull']is True and x['freeBytesActuallyObserved']>=x['requiredVfsBytes']
  disk=ce['diskFreeGuard'];assert disk==p['diskFreeGuardActuallyObserved']and disk['path']=='/var/lib/docker'and disk['minimumFreeBytes']==134217728 and disk['sampleCount']>=2 and disk['readErrorCount']==0 and disk['lastReadErrorType']is None and all(disk[k]>=134217728 for k in('beforeAvailableBytes','minimumAvailableBytesObserved','lastAvailableBytes'))
  assert ce['command'][1]==proposal['actual59SnapshotWrapperPin']['path']and ce['command'][3]==resource['containerName']and ce['command'][6]==cad29_contract['cadWorkerPin']['path']
  assert zone['actualCoreRawSha256']==r['actualCoreSha256']==p['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and zone['actualExportPath']==proposal['actual56ExportPin']['path']and zone['actualExportSha256']==proposal['actual56ExportPin']['sha256']and zone['actualSourceKeepoutCount']==2
  assert r['reportPath']==p['reportPath']==proposal['actual59WorkerFailureReportPin']['path']and sha(r['reportPath'])==r['reportSha256']==p['reportSha256']==proposal['actual59WorkerFailureReportPin']['sha256']and r['cadWorkerFailureReportBinding']==proposal['actual59WorkerFailureReportPin']
  assert v['scope']==cli29_preparation['scope']and v['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and v['allInputBytesHeld']is True and v['status']=='FAILED_FRESH_KICAD_SOURCE29_NARROW_DIAGNOSTIC'
  assert v['passed']is v['diagnosticCompleted']is v['nativeAndOriginalApiStagesPassed']is v['complete29Accepted']is v['accepted49']is v['fabricationReady']is False
  assert v['actualOriginalApiReport']==proposal['actual55ApiReportPin']and v['actualNativeStageReport']==proposal['actual54ReportPin']and v['actualCollectedNativeToolWrapperExitCode']is v['actualNativePhysicalChildExitCode']is v['actualOriginalApiChildExitCode']is None
  for key in('apiAnglesFailed','geometryFixesPending','sourceRawOrSdkEdited','rawExportEdited','netRepairPerformed','saveBoardPerformed','refillPerformed','allRuleDrcPerformed','referenceQualified','electricalTimingQualified'):assert v[key]is False
  assert v['actualOriginalApiAngleFailures']==[]and v['expectedMissingOriginalSignalCount']==20 and r['currentCheckedConnections']==26 and r['currentMissingConnections']==23
  for row in p['outputFiles']:binding(row)
  prior['actual59ContainerWorkerPreconditionFailureCollectionPin']={k:proposal['actual59FailedCollectionPin'][k]for k in('path','sha256')};prior['actual59WorkerBeforePcbLoadFailedNoHardwareQualification']=True;prior['actual59OuterContainerEmptyNullAndCompletionUnknownPreserved']=True;prior['actualClosedScopeCount']=59
  return prior
