/** Local diagnostic only. No imports, constructor replacement or solver calls. */
"use strict"

const LIMITS = Object.freeze({ records: 1, attempts: 1, expandedThreshold: 100000, totalBytes: 2 * 1024 * 1024,
  copyNodes: 100000, copyDepth: 48, stringBytes: 1536 * 1024 })
const bytes = value => new TextEncoder().encode(value).byteLength
const own = (object, key, optional = false) => {
  if (!object || typeof object !== "object") throw Error("Own data object required")
  const descriptor = Object.getOwnPropertyDescriptor(object, key)
  if (!descriptor && optional) return undefined
  if (!descriptor || !("value" in descriptor)) throw Error("Own data field required: " + key)
  return descriptor.value
}
const number = value => {
  if (typeof value !== "number" || !Number.isFinite(value)) throw Error("Finite number required")
  return value
}
const point = value => [number(own(value, "x")), number(own(value, "y"))]
const samePoint = (a, b) => {
  const p = point(a), q = point(b)
  return p[0] === q[0] && p[1] === q[1]
}

// Preserve own undefined fields through JSON by recording paths. No getter,
// toJSON, typed-array, Set/Map, solver method or geometry predicate is invoked.
function copyData(value, budget, undefinedPaths, path = [], depth = 0) {
  if (++budget.nodes > LIMITS.copyNodes || depth > LIMITS.copyDepth) throw Error("Copy bound")
  if (value === undefined) { undefinedPaths.push(path); return null }
  if (value === null || typeof value === "boolean") return value
  if (typeof value === "number") return number(value)
  if (typeof value === "string") {
    budget.strings += bytes(value)
    if (budget.strings > LIMITS.stringBytes) throw Error("String bound")
    return value
  }
  if (typeof value !== "object") throw Error("JSON data required")
  const prototype = Object.getPrototypeOf(value)
  const array = Array.isArray(value)
  if (array ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null)
    throw Error("Plain data required")
  if (budget.active.has(value)) throw Error("Cyclic data")
  budget.active.add(value)
  const result = array ? [] : Object.create(null)
  const keys = Reflect.ownKeys(value)
  if (array && keys.length !== own(value, "length") + 1) throw Error("Dense array required")
  for (const key of keys) {
    if (array && key === "length") continue
    if (typeof key !== "string" || key === "__proto__") throw Error("Plain string key required")
    const descriptor = Object.getOwnPropertyDescriptor(value, key)
    if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) throw Error("Enumerable own data required")
    if (array && !/^(0|[1-9][0-9]*)$/.test(key)) throw Error("Plain array required")
    result[key] = copyData(descriptor.value, budget, undefinedPaths, [...path, key], depth + 1)
  }
  if (array && result.length !== own(value, "length")) throw Error("Dense array required")
  budget.active.delete(value)
  return result
}

function restoreOwnUndefined(record) {
  for (const path of record.undefinedPaths) {
    if (!Array.isArray(path) || !path.length) throw Error("Recorded path required")
    let target = record.data
    for (const key of path.slice(0, -1)) target = own(target, key)
    const key = path.at(-1)
    if (own(target, key) !== null) throw Error("Undefined placeholder required")
    Object.defineProperty(target, key, { value: undefined, writable: true, configurable: true, enumerable: true })
  }
  return record.data
}

/** Install AFTER the existing Stage observer; restore BEFORE that observer.
 * publish receives only bounded serialized data. It must synchronously publish
 * to a new ignored local file. Sink exceptions never change original behavior.
 * Root's existing owned-process controller decides when to stop; this hook does
 * not cancel a Grid, signal a process or claim solver success.
 */
function installClockHardSceneCapture(prototype, publish, sourceBindings, expectedClockSceneInput, verifyClockGroupProjection) {
  const descriptor = Object.getOwnPropertyDescriptor(prototype, "step")
  if (!descriptor || !("value" in descriptor) || typeof descriptor.value !== "function" || !descriptor.writable)
    throw Error("Original writable step descriptor required")
  if (typeof publish !== "function") throw Error("Sink required")
  // Caller supplies immutable JSON identifiers only; no receiver graph retained.
  const bindingUndefined = []
  const bindings = copyData(sourceBindings, { nodes: 0, strings: 0, active: new Set() }, bindingUndefined)
  if (bindingUndefined.length) throw Error("Complete source bindings required")
  for (const name of ["callerSha256", "gridSha256", "publicInputSha256", "stageObserverSha256"])
    if (typeof bindings[name] !== "string" || !/^[0-9a-f]{64}$/.test(bindings[name]))
      throw Error("Exact source hash binding required: " + name)
  if (bindings.precheckEnclosedTerminals !== true) throw Error("Frozen caller reachability option required")
  if (typeof verifyClockGroupProjection !== "function") throw Error("Bound exact projection verifier required")
  const expectedUndefined = []
  const expectedData = copyData(expectedClockSceneInput, { nodes: 0, strings: 0, active: new Set() }, expectedUndefined)
  const expected = restoreOwnUndefined({ data: expectedData, undefinedPaths: expectedUndefined })
  const expectedConnections = own(expected, "connections")
  if (!Array.isArray(expectedConnections)) throw Error("Complete expected connection array required")
  let expectedClockConnection
  for (let i = 0; i < own(expectedConnections, "length"); i++) {
    const candidate = own(expectedConnections, String(i))
    if (own(candidate, "name") === "source_trace_34") {
      if (expectedClockConnection !== undefined) throw Error("Unique expected clock descriptor required")
      expectedClockConnection = candidate
    }
  }
  if (expectedClockConnection === undefined) throw Error("Expected clock descriptor required")
  const original = descriptor.value
  const expectedWidth = number(own(expected, "minTraceWidth"))
  const expectedMargin = expectedWidth / 2 + number(own(expected, "minTraceToPadEdgeClearance", true)
    ?? own(expected, "defaultObstacleMargin", true) ?? .075)
  let record = null, copyAttempted = false, captureDisabled = false, restored = false
  let errors = 0, published = 0, lastBytes = 0
  function captureAfterOriginalStep(receiver) {
    if (record || copyAttempted || captureDisabled) return
    const expanded = number(own(receiver, "expanded"))
    const solved = own(receiver, "solved"), failed = own(receiver, "failed")
    if (!Number.isSafeInteger(expanded) || expanded < 0 || typeof solved !== "boolean" || typeof failed !== "boolean")
      throw Error("Original finite nonnegative expansion and boolean state required")
    if (expanded < LIMITS.expandedThreshold || solved || failed) return
    const scene = own(receiver, "scene"), connection = own(scene, "connection")
    if (own(connection, "name") !== "source_trace_34") return
    const terminals = own(connection, "pointsToConnect")
    if (own(own(terminals, "0"), "layer") !== "inner1" || own(own(terminals, "1"), "layer") !== "inner1") return
    const start = own(receiver, "start"), end = own(receiver, "end")
    if (!samePoint(start, own(terminals, "0"))) return
    const width = number(own(scene, "width")), margin = number(own(scene, "margin"))
    const step = number(own(receiver, "stepSize"))
    if (width <= 0 || margin < 0 || step <= 0 || width !== expectedWidth || margin !== expectedMargin)
      throw Error("Frozen source width and margin required")
    const kind = Math.abs(step - width / 2) < 1e-12 ? "original-coarse"
      : Math.abs(step - Math.max(.01, width / 10)) < 1e-12 ? "original-fine" : null
    if (!kind) return
    const copper = own(scene, "copper")
    if (!Array.isArray(copper)) throw Error("Own copper array required")
    let hasReservedTail = false
    for (let i = 0; i < own(copper, "length") && !hasReservedTail; i++) {
      const owners = own(own(copper, String(i)), "owners")
      if (!Array.isArray(owners)) throw Error("Own copper owners required")
      for (let j = 0; j < own(owners, "length"); j++)
        if (own(owners, String(j)) === "reserved_pair_tail") hasReservedTail = true
    }
    if (!hasReservedTail) return
    const alternateAttachments = own(receiver, "alternateAttachments")
    if (typeof alternateAttachments !== "boolean") throw Error("Original alternate-attachment flag required")
    if (own(receiver, "penalty") !== 0 || own(receiver, "history", true) !== undefined
      || own(receiver, "hasSoftCopper") !== false || own(receiver, "softBuckets", true) !== undefined
      || own(receiver, "maxLength") !== Infinity || own(receiver, "lengthFrontier", true) !== undefined)
      throw Error("Unsupported history, soft copper or length mode")
    if (own(receiver, "gridOffsetX") !== 0 || own(receiver, "gridOffsetY") !== 0)
      throw Error("Unsupported cropped grid phase")
    const bounds = own(receiver, "gridBounds"), origin = own(receiver, "origin")
    const nx = number(own(receiver, "nx")), ny = number(own(receiver, "ny"))
    const minX = number(own(bounds, "minX")), maxX = number(own(bounds, "maxX"))
    const minY = number(own(bounds, "minY")), maxY = number(own(bounds, "maxY"))
    if (!Number.isSafeInteger(nx) || !Number.isSafeInteger(ny) || nx < 1 || ny < 1
      || maxX < minX || maxY < minY || point(origin)[0] !== minX || point(origin)[1] !== minY
      || nx !== Math.ceil((maxX - minX) / step) + 1
      || ny !== Math.ceil((maxY - minY) / step) + 1)
      throw Error("Effective grid phase mismatch")
    // One eligible detached copy attempt only. A failed copy or sink cannot
    // trigger repeated large copies, and success stops all later eligibility work.
    copyAttempted = true
    const raw = { input: own(scene, "input"), connection, width, hardCopper: copper,
      margin, start, end, grid: { step, bounds, checkReachability: true },
      stateAfterOriginalStep: { expanded, solved, failed, nx, ny, origin, alternateAttachments,
        startAttachments: own(receiver, "startAttachments"), endAttachments: own(receiver, "endAttachments"),
        startPath: own(receiver, "startPath"), endPath: own(receiver, "endPath"), goal: own(receiver, "goal") } }
    const undefinedPaths = []
    const data = copyData(raw, { nodes: 0, strings: 0, active: new Set() }, undefinedPaths)
    const candidateInput = copyData(data.input, { nodes: 0, strings: 0, active: new Set() }, [])
    restoreOwnUndefined({ data: candidateInput,
      undefinedPaths: undefinedPaths.filter(path => path[0] === "input").map(path => path.slice(1)) })
    if (verifyClockGroupProjection(candidateInput, expected) !== true) throw Error("Exact derived clock input mismatch")
    const candidateConnection = copyData(data.connection, { nodes: 0, strings: 0, active: new Set() }, [])
    restoreOwnUndefined({ data: candidateConnection,
      undefinedPaths: undefinedPaths.filter(path => path[0] === "connection").map(path => path.slice(1)) })
    if (verifyClockGroupProjection(candidateConnection, expectedClockConnection) !== true)
      throw Error("Exact derived clock descriptor mismatch")
    const candidate = { id: 1, kind, startTerminalIndex: 0, data, undefinedPaths,
      captureAt: "after-original-step-return-at-active-cpu-threshold",
      outcome: { kind: "ACTIVE_DIAGNOSTIC", expanded, solved, failed,
        observedAt: "after-original-step-return", originalStepReturned: true },
      constructorOptionsProvenance: "frozen runtime128 pair escape caller with precheckEnclosedTerminals=true; detached constructor geometry and actual post-step scalar state",
      frontierCaptured: false, fullFrontierReplayClaimed: false,
      exactTargetTakenFromReceiver: true, constructorOrSolverMethodsCalled: 0 }
    const serialized = JSON.stringify({ diagnosticOnly: true, activeDiagnosticOnly: true,
      actualFailureCaptured: false, accepted49: false, fabricationReady: false,
      limits: LIMITS, bindings, captureAt: "after-original-step-return-at-active-cpu-threshold",
      threshold: LIMITS.expandedThreshold, complete: true, observedAttempts: 1, persistedAttempts: 1,
      persistedActiveScenes: 1, persistedFailingScenes: 0, records: [candidate] }) + "\n"
    const size = bytes(serialized)
    if (size > LIMITS.totalBytes) throw Error("Serialized total exceeds bound")
    if (publish(serialized) !== undefined) throw Error("Synchronous void sink required")
    // Commit only after a successful synchronous void sink. No live scene,
    // receiver, solver heap or frontier is retained by this observer.
    record = candidate;lastBytes = size;published = 1
  }
  const wrapper = function(...args) {
    const result = Reflect.apply(original, this, args)
    try { captureAfterOriginalStep(this) }
    catch { captureDisabled = true;errors++ }
    return result
  }
  Object.defineProperty(prototype, "step", { ...descriptor, value: wrapper })
  return {
    snapshot: () => ({ records: Number(record !== null), published, errors,
      observedAttempts: Number(copyAttempted), persistedAttempts: Number(record !== null),
      eligibleCopyAttempts: Number(copyAttempted), captureDisabled, serializedBytes: lastBytes,
      complete: record !== null, persistedActiveScenes: Number(record !== null), persistedFailingScenes: 0,
      retainedLiveGeometry: false, additionalSolverCalls: 0, frontierCaptured: false,
      fullFrontierReplayClaimed: false, actualFailureCaptured: false, activeDiagnosticOnly: true,
      accepted49: false, fabricationReady: false, diagnosticOnly: true }),
    restore() {
      if (restored) throw Error("Restore once")
      if (Object.getOwnPropertyDescriptor(prototype, "step")?.value !== wrapper) throw Error("Wrapper changed")
      Object.defineProperty(prototype, "step", descriptor)
      restored = true;return true
    },
  }
}

module.exports = { installClockHardSceneCapture, restoreOwnUndefined, LIMITS }
