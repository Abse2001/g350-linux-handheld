"""Future Root-owned stdlib controls then separate Native18 and original APIs."""
import hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
from pathlib import Path
from projection_controls import verify,adversarial
ROOT=Path(__file__).resolve().parent
BOARD=Path('/workspace/g350-linux-handheld')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
def require(v,label):
 if not v:raise ValueError(label)
def main():
 m=read(ROOT/'PREPARED-manifest.json');packet=sha(ROOT/'PREPARED-manifest.json');authority=Path(os.environ['G350_CLOCK_FRESH_NATIVE_ROOT_RECEIPT']);authority_sha=os.environ['G350_CLOCK_FRESH_NATIVE_ROOT_RECEIPT_SHA'];a=read(authority)
 require(packet==os.environ['G350_CLOCK_FRESH_NATIVE_PACKET_SHA'] and sha(authority)==authority_sha and a['authorizedByRoot'] is True and a['scope']==m['scope'] and a['packetSha256']==packet,'Exact actual Root Native authority required')
 run=ROOT/'run-native';require(run.is_dir(),'Owned process output required');r={'scope':m['scope'],'packetSha256':packet,'commands':[],'nativeCalls':0,'clockApiCalls':0,'coreCalls':0,'cliCalls':0,'cadCalls':0,'passed':False,'accepted49':False,'fabricationReady':False}
 def save():(run/'result.json').write_text(json.dumps(r,indent=2)+'\n')
 def command(name,argv,env=None):
  started=time.monotonic()
  with (run/(name+'.log')).open('xb') as output:p=subprocess.run(argv,cwd=BOARD,env={**os.environ,**(env or {})},stdout=output,stderr=subprocess.STDOUT,check=False)
  r['commands'].append({'name':name,'argv':argv,'exitCode':p.returncode,'seconds':time.monotonic()-started});save();require(p.returncode==0,'Actual guarded command failed: '+name)
 save()
 try:
  f=a['freshArtifacts'];require(sha(f['actualCorePath'])==f['actualCoreSha256'] and sha(f['coreControlsPath'])==f['coreControlsSha256'],'Actual fresh artifact hashes changed')
  raw=read(f['actualCorePath']);control=read(f['coreControlsPath']);old=read(m['baselineCorePath']);signal=read(m['signalProposalPath']);clock=read(m['clockProposalPath'])
  proof=verify(raw,control,old,signal,clock);negative=adversarial(raw,control,old,signal,clock)
  controls=run/'stdlib-projection-controls.json'
  with controls.open('x') as out:json.dump({'actualFreshCorePath':f['actualCorePath'],'actualFreshCoreSha256':f['actualCoreSha256'],'proof':proof,'adversarialControls':negative,'allFiniteControlsPassed':True,'nativeExecuted':False,'accepted49':False,'fabricationReady':False},out,indent=2);out.write('\n')
  r.update(stdlibControlsPath=str(controls),stdlibControlsSha256=sha(controls));save()
  native=run/'native18-report.json';r['nativeCalls']=1
  command('actual-fresh-native18',[m['bun'],'--smol',str(ROOT/'qualify-fresh-native.mjs'),str(ROOT/'PREPARED-manifest.json'),packet,str(authority),authority_sha,str(native)],{'G350_CLOCK_FRESH_NATIVE_APPROVED':'1'})
  n=read(native);require(n['physicalErrors']==0 and n['actualClockNativeFindings']==[] and n['rawCircuitUnmodified'] is True and n['actualCoreSha256']==f['actualCoreSha256'],'Actual Native18 or original pair aggregation failed')
  api=run/'actual-original-clock-api.json';r['clockApiCalls']=1
  command('actual-copper-original-clock-api',[m['bun'],'--smol',str(ROOT/'check-fresh-original-clock-api.ts'),m['combinedCaInputPath'],m['frozenV11CandidatePath'],f['actualCorePath'],str(api)])
  q=read(api);require(q['allOriginalApiClockChecksPassed'] is True and q['actualClockGeometryUsed'] is True and q['actualCoreSha256']==f['actualCoreSha256'],'Original unmodified continuous/coupling APIs failed actual copper')
  require(sha(f['actualCorePath'])==f['actualCoreSha256'] and sha(f['coreControlsPath'])==f['coreControlsSha256'],'Actual fresh bytes changed')
  r.update(nativeReportPath=str(native),nativeReportSha256=sha(native),clockApiReportPath=str(api),clockApiReportSha256=sha(api),passed=True);save();print(json.dumps({'passed':True,'native18PhysicalErrors':0,'actualClockOriginalApiPassed':True,'full49Unfinished':True,'accepted49':False}));return 0
 except BaseException as error:
  r['failure']=type(error).__name__+': '+str(error)
  for label,name in [('native','native18-report.json'),('clockApi','actual-original-clock-api.json'),('stdlibControls','stdlib-projection-controls.json')]:
   p=run/name
   if p.is_file():r[label+'RetainedPath']=str(p);r[label+'RetainedSha256']=sha(p)
  save();raise
if __name__=='__main__':raise SystemExit(main())
