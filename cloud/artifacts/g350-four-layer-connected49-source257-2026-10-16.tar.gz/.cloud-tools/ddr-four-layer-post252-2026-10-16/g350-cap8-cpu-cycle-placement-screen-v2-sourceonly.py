"""Root-authorized stdlib-only geometry and deterministic placement screen, no runtime."""
from pathlib import Path
import json,math,hashlib,copy
exec(Path('/tmp/g350-generic-focus-static-helper.py').read_text())
scene='/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json';pin='cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720';g=focus(35,scene,pin)
cp='/tmp/g350-current243-cpu-cycle42A16-11SW-2NE-joint-planning-screen-report.json';b=Path(cp).read_bytes();assert hashlib.sha256(b).hexdigest()=='4737965e5e21b45f642bde94a47c3dfc81150d649dbfd45b1f3a7c06267326ec';cycle=json.loads(b)
p=g['p'];f=g['f'];objects=g['objects'];own=g['owner'];bbox=g['bbox'];mats=g['mats'];sd=g['sd'];pd=g['pd'];srect=g['segmentRect'];prect=g['pointRect'];L=g['L'];wc=g['wireContacts'];vc=g['viaContacts']
removeids={'pcb_smtpad_729','pcb_smtpad_730','pcb_trace_156','pcb_trace_157'}
for k in ('body42Inverse','body11Inverse','body2Inverse'):removeids.add(cycle[k]['before']['pcb_trace_id'])
for r in cycle['cpuFanoutInverses']:removeids.add(r['before']['pcb_trace_id'])
objects[:]=[o for o in objects if o['id'] not in removeids]
def append(t):
 for m in mats(t):
  o={**m,'owner':own(t),'id':t['pcb_trace_id']};o['bbox']=bbox(o);objects.append(o)
for r in cycle['cpuFanoutInverses']:
 append(r['after'])
 vs=[q for q in r['after']['route'] if q['route_type']=='via'];assert len(vs)==1
 v=vs[0]
 for o in objects:
  if o['id']==v['pcb_via_id']:
   o['p']={**o['p'],'x':v['x'],'y':v['y']};o['bbox']=bbox(o)
for k in ('body42Inverse','body11Inverse','body2Inverse'):append(cycle[k]['after'])
new35=copy.deepcopy(cycle['body35Inverse']['after'])
# An explicitly optional narrow relocation of the upper35 wall opens a real cap bay.
if globals().get('SHIFT_UPPER35',False):
 for i in (3,4):new35['route'][i]['x']-=.04;new35['route'][i]['y']+=.04
append(new35)
D={'type':'pcb_trace','pcb_trace_id':'planned_D12_head_cap_screen','source_trace_id':'source_trace_26','connection_name':'source_trace_26','route':[]}
for j,(layer,pts) in enumerate(cycle['d12PlannedPaths']):
 if j:
  x,y=pts[0];prev=cycle['d12PlannedPaths'][j-1][0];D['route'].append({'route_type':'via','x':x,'y':y,'from_layer':prev,'to_layer':layer,'layers':L,'via_diameter':.4572,'via_hole_diameter':.254})
 for x,y in pts:D['route'].append({'route_type':'wire','x':x,'y':y,'layer':layer,'width':.1016})
# Last current uncommitted portal is an actual fullspan item for clearance.
x,y=cycle['d12PlannedFullspanViaSites'][-1];D['route'].append({'route_type':'via','x':x,'y':y,'from_layer':'inner2','to_layer':'inner1','layers':L,'via_diameter':.4572,'via_hole_diameter':.254});append(D)

def rect_contacts(q):
 out=[];q['radius']=max(q['width'],q['height'])/2;bb=bbox(q)
 for o in objects:
  if 'bottom' not in o['layers']:continue
  ob=o['bbox'];r=.4
  if bb[1]<ob[0]-r or bb[0]>ob[1]+r or bb[3]<ob[2]-r or bb[2]>ob[3]+r:continue
  if o['kind']=='wire':d=srect(o['a'],o['b'],q);need=o['radius']+.1016
  elif o['kind']=='via' or o.get('shape')=='circle':d=prect(o['p'],q);need=o['radius']+.1016
  else:
   d=math.hypot(max(0,abs(o['p']['x']-q['p']['x'])-(o['width']+q['width'])/2),max(0,abs(o['p']['y']-q['p']['y'])-(o['height']+q['height'])/2));need=.15
  if d<need-1e-8:out.append({'owner':o['owner'],'id':o['id'],'kind':o['kind'],'distance':d,'required':need,'shortfall':need-d})
 return out

def pads(cx,cy,rot):
 angle=math.radians(rot);dx=.420116*math.cos(angle);dy=.420116*math.sin(angle);w=.499999 if rot%180==0 else .540004;h=.540004 if rot%180==0 else .499999
 return [{'p':{'x':cx+dx,'y':cy+dy},'kind':'obstacle','shape':'rect','width':w,'height':h,'layers':['bottom'],'id':'pcb_smtpad_730','port':'pcb_port_729','rail':'VDD'},{'p':{'x':cx-dx,'y':cy-dy},'kind':'obstacle','shape':'rect','width':w,'height':h,'layers':['bottom'],'id':'pcb_smtpad_729','port':'pcb_port_730','rail':'GND'}]
if __name__=='__main__':
 candidates=[]
 for i in range(-30,31):
  for j in range(70,146):
   for rot in (0,90,180,270):
    pp=pads(i/10,j/10,rot);cons=[rect_contacts(q) for q in pp]
    if not any(cons):candidates.append({'center':[i/10,j/10],'rotation':rot,'pads':pp,'distanceFromOriginal':math.hypot(i/10-1.2,j/10-9.8)})
 candidates.sort(key=lambda c:c['distanceFromOriginal'])
 R={'scope':'PURE_STDLIB_CAP8_PAD_PLACEMENT_PROBES_NOT_REFERENCE_ROUTE_OR_NATIVE_ACCEPTANCE','scene':scene,'sceneSha256':pin,'cycleReport':cp,'cycleSha256':hashlib.sha256(b).hexdigest(),'source35UpperWallShift':globals().get('SHIFT_UPPER35',False),'source35Body':new35,'candidates':candidates,'referenceRoutesPending':True,'all49Accepted':False,'fabricationReady':False}
 out='/tmp/g350-cap8-cpu-cycle-placement-screen'+('-shift35' if globals().get('SHIFT_UPPER35',False) else '')+'-report.json';Path(out).write_text(json.dumps(R,indent=2)+'\n');print(out,'valid',len(candidates));print(json.dumps(candidates[:20],indent=2));print('sha',hashlib.sha256(Path(out).read_bytes()).hexdigest())
