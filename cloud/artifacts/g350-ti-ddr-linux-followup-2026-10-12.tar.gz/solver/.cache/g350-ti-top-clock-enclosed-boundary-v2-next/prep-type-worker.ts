import { strict as assert } from "node:assert"
assert.deepEqual(process.argv.slice(2), ["--type-only"])
const result = Bun.spawnSync(
  [
    "/workspace/bus-lanes-solver/node_modules/.bin/tsc",
    "--noEmit",
    "--strict",
    "--target",
    "esnext",
    "--module",
    "esnext",
    "--moduleResolution",
    "bundler",
    "--skipLibCheck",
    "--types",
    "bun",
    "runner.ts",
    "grid-telemetry.ts",
    "grid-telemetry.test.ts",
    "recipe.ts",
    "boundary-capture.ts",
    "boundary-control.ts",
    "boundary.test.ts",
  ],
  { cwd: import.meta.dir, stdout: "inherit", stderr: "inherit" },
)
process.exitCode = result.exitCode
