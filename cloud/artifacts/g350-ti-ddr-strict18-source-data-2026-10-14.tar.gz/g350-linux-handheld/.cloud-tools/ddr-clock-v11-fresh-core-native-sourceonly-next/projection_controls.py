"""Independent stdlib controls of actual fresh rows; never import applications.
No fake fresh Core fixture is accepted. Adversarial cases run only after Root
supplies the actual successful raw Core and its collected controls.
"""
import copy,json,math
EPS=1e-9
LAYERS=['top','inner1','inner2','bottom']
def require(v,label):
 if not v:raise ValueError(label)
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'))
def logical(r):return {k:v for k,v in r.items() if k!='subcircuit_connectivity_map_key'}
def near(a,b):return all(isinstance(p.get(k),(int,float)) and math.isfinite(p[k]) for p in (a,b) for k in ('x','y')) and math.hypot(a['x']-b['x'],a['y']-b['y'])<EPS
def one(rows,label):
 require(len(rows)==1,label);return rows[0]
def shape(r,keys):return {k:r[k] for k in keys if k in r}
def route_shape(route):return [{k:v for k,v in p.items() if k not in ('start_pcb_port_id','end_pcb_port_id')} for p in route]
def index(c):
 require(isinstance(c,list),'Actual raw array required');types={}
 for r in c:
  require(isinstance(r,dict) and isinstance(r.get('type'),str),'Actual row type');types.setdefault(r['type'],[]).append(r)
 def rows(t):return types.get(t,[])
 maps={}
 def by(t,id):
  if t not in maps:
   maps[t]={}
   for r in rows(t):
    rid=r.get(t+'_id');require(isinstance(rid,str) and rid not in maps[t],'Duplicate/missing actual ID');maps[t][rid]=r
  require(id in maps[t],'Missing actual '+t+' '+str(id));return maps[t][id]
 return rows,by
def numeric(actual,old,sid):
 rows,by=actual;orows,oby=old;sp=by('source_port',sid);prior=oby('source_port',sid)
 require(logical(sp)==logical(prior),'Numeric Source identity/owner changed')
 part=by('source_component',sp['source_component_id']);require(logical(part)==logical(oby('source_component',prior['source_component_id'])),'Numeric real part changed')
 p=one([r for r in rows('pcb_port') if r.get('source_port_id')==sid],'Actual numeric PCB port once');op=one([r for r in orows('pcb_port') if r.get('source_port_id')==sid],'Old numeric PCB port once')
 require({k:v for k,v in p.items() if k!='pcb_port_id'}=={k:v for k,v in op.items() if k!='pcb_port_id'},'Numeric PCB geometry/layer/owner')
 pad=one([r for r in rows('pcb_smtpad') if r.get('pcb_port_id')==p['pcb_port_id']],'Actual numeric land once');oldpad=one([r for r in orows('pcb_smtpad') if r.get('pcb_port_id')==op['pcb_port_id']],'Old numeric land once')
 require({k:v for k,v in pad.items() if k not in ('pcb_smtpad_id','pcb_port_id')}=={k:v for k,v in oldpad.items() if k not in ('pcb_smtpad_id','pcb_port_id')},'Numeric land geometry')
 return sp,part,p,pad
def alias(actual,v,layer):
 rows,by=actual;p=one([by('pcb_port',id) for id in v['pcb_port_ids'] if by('pcb_port',id).get('layers')==[layer]],'Actual owned layer alias once');require(near(p,v),'Alias is not at its own barrel')
 s=by('source_port',p['source_port_id']);require(s.get('name')==layer,'Actual layer Source alias name')
 owner=by('source_manually_placed_via',s['source_component_id']);component=by('pcb_component',p['pcb_component_id'])
 require(component.get('source_component_id')==owner['source_manually_placed_via_id'] and near(component['center'],v),'Actual alias Source Via ownership')
 require(owner.get('source_net_id')==v.get('source_net_id'),'Alias rail retagging')
 return p,s,owner
def endpoints(t,wanted):
 ids=[p[k] for p in (t['route'][0],t['route'][-1]) for k in ('start_pcb_port_id','end_pcb_port_id') if k in p]
 require(sorted(ids)==sorted(wanted),'Actual wire endpoint ownership')
 require(not any('start_pcb_port_id' in p or 'end_pcb_port_id' in p for p in t['route'][1:-1]),'Interior counterfeit endpoint')
def clock_physical_graph(paths,vias,cpu,ram):
 """Independent actual copper graph: three wires plus exactly two real barrels.
 Numeric source connectivity alone cannot satisfy this control.
 """
 graph={};edges=set();length=0.0
 def key(p,layer):return (round(p['x'],6),round(p['y'],6),layer)
 def add(a,b,wire):
  nonlocal length
  require(a!=b,'Zero physical edge');edge=tuple(sorted((a,b)));require(edge not in edges,'Duplicate physical edge');edges.add(edge)
  graph.setdefault(a,set()).add(b);graph.setdefault(b,set()).add(a)
  if wire:length+=math.hypot(a[0]-b[0],a[1]-b[1])
 for t in paths:
  for a,b in zip(t['route'],t['route'][1:]):
   require(a.get('route_type')==b.get('route_type')=='wire' and a.get('layer')==b.get('layer'),'Actual wire layer continuity')
   add(key(a,a['layer']),key(b,b['layer']),True)
 for v in vias:
  require(v['layers']==LAYERS and v['from_layer']=='top' and v['to_layer']=='bottom','Physical barrel span')
  a,b=key(v,'top'),key(v,'inner1');require(a in graph and b in graph,'A real barrel must join actual Top and Inner1 wires');add(a,b,False)
 start,end=key(cpu,'top'),key(ram,'top');require(start in graph and end in graph and start!=end,'Actual numeric terminals')
 require(all(len(n)==(1 if k in (start,end) else 2) for k,n in graph.items()),'Complete unbranched physical clock graph')
 visited=set();stack=[start]
 while stack:
  k=stack.pop()
  if k in visited:continue
  visited.add(k);stack.extend(graph[k]-visited)
 require(end in visited and len(visited)==len(graph),'Physical numeric CPU/RAM connection and no detached loop')
 return {'actualPhysicalGraphNodes':len(graph),'actualPhysicalGraphEdges':len(edges),'physicalThroughBarrels':len(vias),'numericCpuRamPhysicallyConnected':True,'roundedGraphWireLengthMm':length}
def verify(fresh,controls,oldcore,signal,clock):
 actual=index(fresh);old=index(oldcore);rows,by=actual;orows,oby=old
 require(controls.get('freshCoreControlPassed') is True and all(r.get('passed') is True for r in controls['checks']),'Actual successful Core controls')
 for t,n in [('pcb_via',225),('pcb_trace',263),('pcb_port',1615),('pcb_smtpad',1161),('source_component',280),('source_net',98),('source_bus',8),('pcb_hole',2),('pcb_plated_hole',4)]:require(len(rows(t))==n,'Actual count '+t)
 remaining_buses=list(rows('source_bus'))
 for r in orows('source_bus'):
  semantic=lambda x:{k:v for k,v in x.items() if k!='source_bus_id'}
  n=one([n for n in remaining_buses if n.get('name')==r.get('name') and semantic(n)==semantic(r)],'Original exact bus name/ordered members/constraints')
  remaining_buses.remove(n)
 require(not remaining_buses,'Extra Source buses')
 for r in orows('source_net'):require(logical(by('source_net',r['source_net_id']))==logical(r),'Named rail changed')
 for r in orows('source_trace'):
  if r['source_trace_id'].startswith('source_trace_') and r['source_trace_id'][13:].isdigit() and int(r['source_trace_id'][13:])<49:require(logical(by('source_trace',r['source_trace_id']))==logical(r),'Original49 numeric Source trace changed')
 via_keys=['x','y','hole_diameter','outer_diameter','layers','from_layer','to_layer','tented_on_top','tented_on_bottom','source_net_id'];used_vias=set();used_traces=set();reference_vias={};reference_traces={};signals=[]
 for oldv in orows('pcb_via'):
  v=one([r for r in rows('pcb_via') if shape(r,via_keys)==shape(oldv,via_keys)],'Authentic old barrel physical bijection');require(v['pcb_via_id'] not in used_vias,'Old barrels overlap mapping');used_vias.add(v['pcb_via_id']);reference_vias[oldv['pcb_via_id']]=v
  require(len(v['pcb_port_ids'])==2,'Reference aliases exact')
  for layer in ('top','bottom'):
   p,s,owner=alias(actual,v,layer);op,os,oo=alias(old,oldv,layer)
   require(logical(s)==logical(os) and logical(owner)==logical(oo),'Authentic reference Source alias/owner')
 for ot in orows('pcb_trace'):
  t=one([r for r in rows('pcb_trace') if r.get('source_trace_id')==ot['source_trace_id'] and route_shape(r['route'])==route_shape(ot['route'])],'Authentic old trace geometry and Source owner');require(t['pcb_trace_id'] not in used_traces,'Reference path duplicate mapping');used_traces.add(t['pcb_trace_id']);reference_traces[ot['pcb_trace_id']]=t
  require(logical(by('source_trace',t['source_trace_id']))==logical(oby('source_trace',ot['source_trace_id'])),'Reference logical Source changed')
  old_ends=[p[k] for p in (ot['route'][0],ot['route'][-1]) for k in ('start_pcb_port_id','end_pcb_port_id') if k in p]
  require(len(old_ends)==2,'Authentic reference endpoint IDs')
  actual_ends=[]
  for old_id in old_ends:
   old_port=oby('pcb_port',old_id)
   port=one([r for r in rows('pcb_port') if r.get('source_port_id')==old_port['source_port_id']],'Actual reference endpoint Source alias')
   require(near(port,old_port) and port['layers']==old_port['layers'],'Actual reference endpoint geometry/layer')
   actual_ends.append(port['pcb_port_id'])
  endpoints(t,actual_ends)
 require([(r['originalPcbTraceId'],r['actualPcbTraceId']) for r in controls['originalReference165GeometryProjection']]==[(id,r['pcb_trace_id']) for id,r in reference_traces.items()],'Forged reference trace control projection')
 require([(r['originalViaId'],r['actualViaId']) for r in controls['original129ReferenceBarrelProjection']]==[(id,r['pcb_via_id']) for id,r in reference_vias.items()],'Forged reference via control projection')
 for o in signal['owners']:
  sp,part,p,pad=numeric(actual,old,o['originalSourcePortId']);require(part['name']==o['package'] and sp['pin_number']==o['numericPin'] and near(p,o['padXY']),'Actual package numeric owner')
  v=one([r for r in rows('pcb_via') if r['pcb_via_id'] not in used_vias and near(r,o['viaXY'])],'Actual signal barrel once');require(shape(v,['outer_diameter','hole_diameter','layers','from_layer','to_layer','tented_on_top','tented_on_bottom'])=={'outer_diameter':.4572,'hole_diameter':.254,'layers':LAYERS,'from_layer':'top','to_layer':'bottom','tented_on_top':True,'tented_on_bottom':True} and 'source_net_id' not in v,'Unretagged signal full barrel')
  top,top_source,owner=alias(actual,v,'top');bottom,bottom_source,bottom_owner=alias(actual,v,'bottom');require(owner['source_manually_placed_via_id']==bottom_owner['source_manually_placed_via_id'],'Signal aliases belong to same real Source Via')
  local=one([r for r in rows('source_trace') if r.get('name')==o['traceName']],'Exact actual local branch name');require(sorted(local['connected_source_port_ids'])==sorted([sp['source_port_id'],top_source['source_port_id']]) and local['connected_source_net_ids']==[] and local['min_trace_thickness']==.1016,'Actual local branch numeric/Top owner')
  require(local['display_name'] in [o['package']+'.pin'+str(o['numericPin'])+' to .'+o['viaName']+' > port.top','.'+o['viaName']+' > port.top to '+o['package']+'.pin'+str(o['numericPin'])],'Source named via selector binding')
  is_clock=o['originalSourceTraceId'] in ('source_trace_33','source_trace_34');sid=o['originalSourceTraceId'] if is_clock else local['source_trace_id']
  require(len(v['pcb_port_ids'])==(3 if is_clock else 2),'Signal exact real aliases')
  if is_clock:alias(actual,v,'inner1')
  def match(t):
   r=t['route'];return len(r)==2 and all(p.get('route_type')=='wire' and p.get('layer')=='top' and p.get('width')==.1016 for p in r) and (all(near(a,b) for a,b in zip(r,o['topStub'])) or all(near(a,b) for a,b in zip(r,reversed(o['topStub']))))
  t=one([r for r in rows('pcb_trace') if r['pcb_trace_id'] not in used_traces and r.get('source_trace_id')==sid and match(r)],'Signal exact source-owned Top copper');endpoints(t,[p['pcb_port_id'],top['pcb_port_id']])
  if is_clock:require(not any(r.get('source_trace_id')==local['source_trace_id'] for r in rows('pcb_trace')),'No duplicate local clock copper')
  used_vias.add(v['pcb_via_id']);used_traces.add(t['pcb_trace_id']);signals.append({'proposal':o,'via':v,'numeric':p,'top':top,'source':local,'trace':t})
 require([(r['sourceViaName'],r['actualViaId']) for r in controls['original96SignalBarrelProjection']]==[(r['proposal']['viaName'],r['via']['pcb_via_id']) for r in signals],'Forged signal barrel control projection')
 clock_reports=[]
 for c in clock['clockCarriers']:
  paths=[r for r in rows('pcb_trace') if r.get('source_trace_id')==c['originalSourceTraceId']];require(len(paths)==3,'Native direct original clock must contain all3 paths')
  ends=[one([r for r in signals if r['proposal']['originalSourcePortId']==o['originalSourcePortId'] and r['proposal']['originalSourceTraceId']==o['originalSourceTraceId']],'Actual clock endpoint ownership') for o in (c['cpu'],c['ram'])]
  inner=one([r for r in paths if all(p.get('route_type')=='wire' and p.get('layer')=='inner1' and p.get('width')==.1016 for p in r['route'])],'Actual one Inner1 carrier')
  require(inner['pcb_trace_id'] not in used_traces and len(inner['route'])==len(c['expectedInner1PhysicalRoute']) and all(near(a,b) for a,b in zip(inner['route'],c['expectedInner1PhysicalRoute'])),'Frozen V11 actual carrier geometry')
  inner_ports=[alias(actual,r['via'],'inner1')[0] for r in ends];endpoints(inner,[r['pcb_port_id'] for r in inner_ports]);used_traces.add(inner['pcb_trace_id'])
  graph=clock_physical_graph(paths,[r['via'] for r in ends],ends[0]['numeric'],ends[1]['numeric'])
  planar=sum(math.hypot(b['x']-a['x'],b['y']-a['y']) for t in paths for a,b in zip(t['route'],t['route'][1:]));require(abs(planar-c['originalV11WholePlanarLength'])<EPS,'Actual full clock length includes both Top stubs')
  clock_reports.append({'originalSourceTraceId':c['originalSourceTraceId'],'actualDirectPcbTraceIds':[r['pcb_trace_id'] for r in paths],'wholePlanarLengthMm':planar,**graph})
 require(len(used_vias)==225 and len(used_traces)==263,'Every physical barrel/path owned exactly once')
 # Independent authentic contact geometry from actual rows and original owners.
 strip=reference_traces['pcb_trace_55'];require(strip['source_trace_id']=='source_trace_987','HS8 strip owner substitution')
 sp,part,p,pad=numeric(actual,old,'source_port_730');require(part['name']=='C_DDR_RAM_8' and sp['pin_number']==2 and pad['layer']=='bottom','HS8 numeric pin identity')
 ram25sp=one([r for r in rows('source_port') if r.get('pin_number')==25 and by('source_component',r['source_component_id']).get('name')=='U_RAM'],'Real RAM25 source')
 ram25branch=one([r for r in rows('source_trace') if r.get('name')=='TI_PKG_U_RAM_PIN25_GND'],'Real RAM25 package branch')
 require(ram25sp['source_port_id'] in ram25branch['connected_source_port_ids'] and ram25branch['connected_source_net_ids']==['source_net_0'],'RAM25 known rail branch')
 v=one([r for r in reference_vias.values() if near(r,{'x':.4,'y':8.975})],'Only authorized RAM25 junction barrel');require(v['source_net_id']=='source_net_0','Junction rail')
 top=alias(actual,v,'top')[1];require(top['source_port_id'] in ram25branch['connected_source_port_ids'],'RAM25 junction own real alias')
 require(len(strip['route'])==2 and all(r.get('route_type')=='wire' and r.get('layer')=='bottom' and r.get('width')==.2 and not r.get('width_interpolation_mode') for r in strip['route']),'Finite exact HS8 strip')
 a,b=strip['route'];dx,dy=b['x']-a['x'],b['y']-a['y'];length=math.hypot(dx,dy);along=((v['x']-a['x'])*dx+(v['y']-a['y'])*dy)/length;distance=abs(dx*(v['y']-a['y'])-dy*(v['x']-a['x']))/length;R=v['outer_diameter']/2;h=v['hole_diameter']/2;nearest=max(0,distance-.1);require(nearest<R,'Annulus/strip contact');half=math.sqrt(R*R-nearest*nearest);require(2*half>=.1016 and along-half>1e-8 and along+half<length-1e-8 and distance-.1>h,'Entire positive strip chord and drill clearance')
 require(pad['shape']=='rect' and pad.get('ccw_rotation',0)==0,'Authentic HS8 rectangle');px=max(pad['x']-pad['width']/2,min(v['x'],pad['x']+pad['width']/2));py=max(pad['y']-pad['height']/2,min(v['y'],pad['y']+pad['height']/2));pd=math.hypot(v['x']-px,v['y']-py);require(h<pd<R and R-h>=.1016-2.220446049250313e-16,'Connected authentic annulus/pad patch outside drill')
 return {'scope':'STDLIB_ACTUAL_FRESH_CORE_PROJECTION_AND_NUMERIC_PHYSICAL_GRAPH','referenceBarrels':129,'referencePaths':165,'signalBarrels':96,'signalTopStubs':96,'clocks':clock_reports,'registeredRam25Hs8Junction':{'actualViaId':v['pcb_via_id'],'actualHs8StripId':strip['pcb_trace_id'],'actualHs8PadId':pad['pcb_smtpad_id'],'actualChordMm':2*half,'actualPadDistanceMm':pd},'rawRowsEdited':False,'nativeExecuted':False,'accepted49':False,'fabricationReady':False}
def adversarial(fresh,controls,old,signal,clock):
 """Finite negatives against actual future fresh output, not a mock PASS fixture."""
 cases=[]
 def case(name,change):
  f=copy.deepcopy(fresh);c=copy.deepcopy(controls);change(f,c)
  try:verify(f,c,old,signal,clock)
  except (ValueError,KeyError,TypeError,ZeroDivisionError) as e:cases.append({'name':name,'rejected':True,'actualRejection':type(e).__name__+': '+str(e)});return
  raise ValueError('Adversarial alteration was accepted: '+name)
 clock_t=lambda f:one([r for r in f if r['type']=='pcb_trace' and r.get('source_trace_id')=='source_trace_33' and r['route'][0].get('layer')=='inner1'],'Clock carrier')
 case('clock-width-weakened',lambda f,c:clock_t(f)['route'][1].update(width=.09))
 case('clock-direct-source-owner-substituted',lambda f,c:clock_t(f).update(source_trace_id='source_trace_34'))
 case('clock-endpoint-port-substituted',lambda f,c:clock_t(f)['route'][0].update(start_pcb_port_id='pcb_port_730'))
 case('clock-nonwire-fake-via-marker',lambda f,c:clock_t(f)['route'][1].update(route_type='via'))
 case('clock-carrier-point-moved',lambda f,c:clock_t(f)['route'][2].update(x=clock_t(f)['route'][2]['x']+.01))
 case('clock-detached-extra-loop',lambda f,c:f.append(copy.deepcopy(clock_t(f))))
 case('forged-reference-control-id',lambda f,c:c['originalReference165GeometryProjection'][0].update(actualPcbTraceId='pcb_trace_forged'))
 case('forged-signal-control-id',lambda f,c:c['original96SignalBarrelProjection'][0].update(actualViaId='pcb_via_forged'))
 case('HS8-physical-endpoint-substituted',lambda f,c:one([r for r in f if r['type']=='pcb_trace' and r.get('source_trace_id')=='source_trace_987'],'HS8')['route'][0].update(start_pcb_port_id='pcb_port_21'))
 case('HS8-strip-owner-substituted',lambda f,c:one([r for r in f if r['type']=='pcb_trace' and r.get('source_trace_id')=='source_trace_987'],'HS8').update(source_trace_id='source_trace_986'))
 case('reference-barrel-moved',lambda f,c:one([r for r in f if r['type']=='pcb_via' and near(r,{'x':.4,'y':8.975})],'Junction').update(x=.41))
 case('numeric-RAM-source-owner-substituted',lambda f,c:one([r for r in f if r['type']=='source_port' and r.get('source_port_id')=='source_port_380'],'RAM numeric').update(source_component_id='source_component_132'))
 case('extra-physical-hole',lambda f,c:f.append({**copy.deepcopy(one([r for r in f if r['type']=='pcb_via' and near(r,signal['owners'][0]['viaXY'])],'Signal')),'pcb_via_id':'pcb_via_extra'}))
 case('signal-source-net-fabricated',lambda f,c:one([r for r in f if r['type']=='pcb_via' and near(r,signal['owners'][0]['viaXY'])],'Signal').update(source_net_id='source_net_0'))
 require(len(cases)==14 and all(r['rejected'] for r in cases),'All finite adverse controls must reject')
 return cases
