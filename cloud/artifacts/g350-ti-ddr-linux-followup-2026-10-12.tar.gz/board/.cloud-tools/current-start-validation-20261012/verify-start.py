import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
SOLVER = Path('/workspace/bus-lanes-solver')
PINNED = SOLVER / '.cache/g350-d0-two-blocker-hard-reroute-next'
POLICY = {'wallSeconds': 300, 'rssBytes': 4 * 1024**3,
          'sharedBytes': 24 * 1024**3, 'sampleSeconds': .25,
          'termGraceSeconds': 5}

def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def snapshot(repo):
    names = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'],
        cwd=repo).split(b'\0')
    files = {}
    for raw in names:
        if not raw:
            continue
        name = os.fsdecode(raw)
        path = repo / name
        files[name] = (hashlib.sha256(os.readlink(path).encode()).hexdigest()
                       if path.is_symlink() else sha(path))
    return {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
            'branch': subprocess.check_output(['git', 'branch', '--show-current'], cwd=repo, text=True).strip(),
            'files': files}

assert not (ROOT / 'run').exists()
guard = module('pinned_guard', PINNED / 'guard.py')
manifest, packet = guard.checked_manifest()
assert packet == 'b0754fd0bc58d458c192003b49690300939a41abeea13f53e7b9c388cbde7a69'
dependencies_before = guard.checked_provenance(manifest)
before = {str(repo): snapshot(repo) for repo in [Path('/workspace/g350-linux-handheld'), SOLVER]}
(ROOT / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
scope = module('pinned_scope', PINNED / 'process_scope.py')
assert scope.memory()['current'] + POLICY['rssBytes'] + 2 * 1024**3 < POLICY['sharedBytes']
execution = scope.run_guarded(
    ['/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe',
     '--smol', str(ROOT / 'launcher.ts')], ROOT, ROOT / 'run', POLICY)
after = {str(repo): snapshot(repo) for repo in [Path('/workspace/g350-linux-handheld'), SOLVER]}
(ROOT / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
dependencies_after = guard.checked_provenance(manifest)
passed = (execution['exitCode'] == 0 and not execution['diagnosticStopped']
          and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values())
          and before == after and dependencies_before == dependencies_after)
report = {'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'passed': passed, 'execution': execution, 'sourceUnchanged': before == after,
          'sourceFileCounts': {name: len(value['files']) for name, value in before.items()},
          'dependencyBefore': dependencies_before, 'dependencyAfter': dependencies_after,
          'startScriptSha256': sha(ROOT / 'start.sh'), 'savedStartSha256': sha(ROOT / 'proposed-start.md'),
          'installScriptRerun': False, 'hardwareRoutingPerformed': False, 'accepted49': False}
(ROOT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ['passed', 'sourceUnchanged', 'sourceFileCounts', 'hardwareRoutingPerformed']}), flush=True)
raise SystemExit(0 if passed else 2)
