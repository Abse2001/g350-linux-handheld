Separate post209 routing evidence, through closed225.

Primary223 has47/49 current-scene physical paths; fresh225 critical6 and allfive
report APIs pass in both actual DQS1 views. Projector224 passes. D12/source26 and
DQM0/source30 remain pending. Fresh Source/Core and board-native checks are pending.
Original matching/electrical/reference/CAD/fabrication qualification remains false.
The accepted default board remains32; the last fully checked partial Source is20946.

Restore prior Source32 prerequisites and immutable Source209 archive first, as
documented in cloud/DDR_FOUR_LAYER_MANUAL_ROUTING_2026-10-16.md. Then run:

python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post209-2026-10-16 --restore
python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post209-2026-10-16

The existing helper verifies local saved hashes/modes and refuses differing targets;
it does not interpret the extra baseArchiveDependency metadata, so restore order
is a caller precondition. No SDK is executed by this collector or restoration.
Closed failures216/217 are retained with their logs and no invented qualification.
The qualified reference-overlay219 is a separate branch; it does not alter223.
Live226 is excluded. No archive, commit or push is performed.
