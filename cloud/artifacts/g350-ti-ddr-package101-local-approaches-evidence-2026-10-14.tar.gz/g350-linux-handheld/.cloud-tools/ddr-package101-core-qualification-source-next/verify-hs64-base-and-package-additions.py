"""Source-only proposal: strict actual Core forward, run only by Root.

This compares the accepted64-HS Core, including all original hardware/net/pad
records, against one future actual Core. Only declared source branches, alias
records, barrels and their exact foreign-reference antipads are permitted.
"""
from pathlib import Path
import collections, hashlib, json, math, sys

BOARD=Path('/workspace/g350-linux-handheld')
BASE=BOARD/'.cloud-tools/ddr-hs-all32-capture-first-type4096-root-successor-next/run-core/fresh-core.circuit.json'
PROPOSAL=BOARD/'.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/grouped-proposal.json'
BASE_SHA='384628cd46c2b5cb5b32a94d442651eda3c604c8acf19bd85fc68b728f529769'
TOLERANCE=1e-7

def require(value,message):
    if not value:raise ValueError(message)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def key(row):
    field=row['type']+'_id';require(field in row,'Missing concrete row identity')
    return row['type'],row[field]

def equivalent(a,b,label):
    if isinstance(a,dict) and isinstance(b,dict):
        require(a.keys()==b.keys(),'Original fields changed: '+label)
        for k in a:equivalent(a[k],b[k],label+'.'+k)
    elif isinstance(a,list) and isinstance(b,list):
        require(len(a)==len(b),'Original list inventory changed: '+label)
        for i,(x,y) in enumerate(zip(a,b)):equivalent(x,y,label+':'+str(i))
    elif type(a) in (int,float) and type(b) in (int,float):
        require(math.isfinite(a) and math.isfinite(b) and abs(a-b)<=TOLERANCE,'Original numeric geometry changed: '+label)
    else:require(type(a)==type(b) and a==b,'Original value/type changed: '+label)

def main():
    require(len(sys.argv)==4,'Fresh actual Core/hash/output required')
    actual_path,expected,output=Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3])
    require(not output.exists() and sha(actual_path)==expected,'Fresh exclusive exact actual output required')
    require(sha(BASE)==BASE_SHA,'Accepted HS64 Core changed')
    old,actual=json.loads(BASE.read_bytes()),json.loads(actual_path.read_bytes())
    proposal=json.loads(PROPOSAL.read_bytes())
    owners,groups=proposal['owners'],proposal['viaGroups']
    new_groups=[g for g in groups if g['reuseAcceptedHsViaId'] is None]
    require(len(owners)==101 and len(groups)==72 and len(new_groups)==65,'Exact101/72/65 proposal required')
    require(len({o['ownerKey'] for o in owners})==101 and len({g['key'] for g in groups})==72,'Duplicate numeric owner/canonical group')
    old_rows=[r for r in old if r['type']!='source_project_metadata']
    new_rows=[r for r in actual if r['type']!='source_project_metadata']
    before={key(r):r for r in old_rows};after={key(r):r for r in new_rows}
    require(len(before)==len(old_rows) and len(after)==len(new_rows),'Duplicate concrete identity')
    require(before.keys()<=after.keys(),'Original row removed')
    added=after.keys()-before.keys()
    allowed={'source_manually_placed_via':65,'source_port':130,'pcb_component':65,'pcb_port':130,'source_trace':101,'pcb_trace':101,'pcb_via':65}
    require(collections.Counter(k[0] for k in added)==collections.Counter(allowed),'Undeclared new physical/source record')
    require(sum(r['type']=='source_project_metadata' for r in actual)<=1,'Unexpected generated filesystem metadata')
    pours=[]
    for ident,b in before.items():
        a=after[ident]
        if b['type']!='pcb_copper_pour':
            equivalent(b,a,'original.'+str(ident));continue
        original_brep,new_brep=b['brep_shape'],a['brep_shape']
        pb,pa=dict(b),dict(a);del pb['brep_shape'];del pa['brep_shape']
        equivalent(pb,pa,'retained-reference-owner')
        require(original_brep['outer_ring']==new_brep['outer_ring'],'Original reference outline changed')
        import shapely
        from shapely.geometry import Polygon
        from shapely.ops import unary_union
        require(shapely.__version__=='2.1.2','Pinned Shapely required')
        def polygon(brep):
            shape=Polygon([(p['x'],p['y']) for p in brep['outer_ring']['vertices']],[[ (p['x'],p['y']) for p in ring['vertices']] for ring in brep['inner_rings']])
            require(shape.is_valid and not shape.is_empty,'Invalid source reference BREP; no repair allowed')
            return shape
        old_shape,new_shape=polygon(original_brep),polygon(new_brep)
        foreign=[g for g in new_groups if g['source_net_id']!=b['source_net_id']]
        require(all(g['source_net_id'] in ('source_net_0','source_net_5') for g in foreign),'Unknown new reference owner')
        cuts=[Polygon([(round(g['x']+.3486*math.sin(i*math.pi/16),6),round(g['y']-.3486*math.cos(i*math.pi/16),6)) for i in range(32)]) for g in foreign]
        expected_shape=old_shape.difference(unary_union(cuts))
        require(expected_shape.is_valid and not expected_shape.is_empty,'Explicit owned cut union invalid')
        require(new_shape.boundary.hausdorff_distance(expected_shape.boundary)<=1e-6,'Unowned new reference boundary change')
        require(new_shape.symmetric_difference(expected_shape).area<=1e-6*(new_shape.length+expected_shape.length),'Copper change outside exact new owned antipads')
        pours.append({'pcb_copper_pour_id':b['pcb_copper_pour_id'],'source_net_id':b['source_net_id'],'layer':b['layer'],'newForeignOwnedViaCuts':len(foreign),'outerRingExact':True,'originalCopperMinusOnlyDeclaredNewAntipads':True,'serializationBoundaryToleranceMm':1e-6})
    for kind in ('pcb_trace','pcb_via'):
        held=[r for r in old if r['type']==kind]
        require(len(held)==64 and all(after[key(r)]==r for r in held),'Accepted HS64 physical records must be exact')
    for kind,count in [('source_component',280),('pcb_smtpad',1161),('source_net',98),('source_bus',8),('pcb_trace',165),('pcb_via',129)]:
        require(sum(r['type']==kind for r in actual)==count,'Unexpected actual inventory: '+kind)
    # The accepted64 base already proves frozen original0e/217 board links.
    # Every one of its source/pad/net/trace records is retained here, not reduced
    # to an incorrect assertion that newly authored branches total217 traces.
    report={'scope':'STRICT_ACCEPTED_HS64_CORE_PLUS101_DECLARED_PACKAGE_TOP_BRANCHES_AND65_CANONICAL_VIAS','actualCoreSha256':expected,'acceptedHsCoreSha256':BASE_SHA,'proposalSha256':sha(PROPOSAL),'sourceForwardPassed':True,'allAcceptedHs64PhysicalRecordsExact':True,'original217BoardLinksHeldThroughExactAcceptedSourceRecords':True,'allOriginalHardwareAndSourcePortsHeld':True,'original280Parts1161ContactsHeld':True,'newSourceBranchesAreAdditionalConnectionsToExistingRails':True,'addedRecordCounts':dict(collections.Counter(k[0] for k in added)),'retainedReferenceCutProofs':pours,'registeredHs8GroundPadAndStripGeometryRecordsHeld':True,'noPhysicalPreservationClaimForAnyIntentionalNewDrillContact':True,'freshNumericGraphNativeManufacturingAndCadStillRequired':True,'referenceQualified':False,'accepted49':False,'fabricationReady':False}
    with output.open('x') as file:json.dump(report,file,indent=2);file.write('\n')
    print(json.dumps({'sourceForwardPassed':True,'allAcceptedHs64PhysicalRecordsExact':True,'newPackageBranches':101,'newCanonicalVias':65,'accepted49':False}))

if __name__=='__main__':main()
