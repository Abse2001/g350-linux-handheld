"""Pure exact V5→V6 single-cap physical delta and placement-distance checks."""
import copy
import math
from validate_layout import GEOMETRY, LOGIC, by_id, equivalent, expected_geometry, typed
from validate_reference_bypass import validate as reference_validate


def require(value, message):
    if not value:
        raise ValueError(message)


def courtyard_box(row):
    if 'outline' in row:
        points = row['outline']
        return (min(p['x'] for p in points), max(p['x'] for p in points),
                min(p['y'] for p in points), max(p['y'] for p in points))
    center = row['center']
    width = row.get('width', row.get('radius', 0) * 2)
    height = row.get('height', row.get('radius', 0) * 2)
    require(width > 0 and height > 0, 'Unsupported courtyard geometry')
    return (center['x'] - width / 2, center['x'] + width / 2,
            center['y'] - height / 2, center['y'] + height / 2)


def placement_metrics(circuit):
    sources = by_id(circuit, 'source_component')
    components = {sources[e['source_component_id']]['name']: e
                  for e in typed(circuit, 'pcb_component') if e['source_component_id'] in sources}
    ports = by_id(circuit, 'source_port')
    nets = {e['name']: e.get('subcircuit_connectivity_map_key') for e in typed(circuit, 'source_net')}
    rows = []
    for chip, name, count, limit in [('CPU', 'U_SOC', 20, 10.16), ('RAM', 'U_RAM', 12, 3.81)]:
        device = components[name]
        pads = [e for e in typed(circuit, 'pcb_port') if e['pcb_component_id'] == device['pcb_component_id']]
        targets = {net: [e for e in pads if ports[e['source_port_id']].get('subcircuit_connectivity_map_key') == nets[net]]
                   for net in ['DDR_1V5', 'GND']}
        require(all(targets.values()), 'Actual supply/ground ball ownership missing')
        for index in range(1, count + 1):
            capacitor = f'C_DDR_{chip}_{index}'
            center = components[capacitor]['center']
            row = {'capacitor': capacitor, 'limitMm': limit}
            for net, metric in [('DDR_1V5', 'supply'), ('GND', 'ground')]:
                distance, ball = min((math.hypot(center['x'] - p['x'], center['y'] - p['y']),
                                      ports[p['source_port_id']]['name']) for p in targets[net])
                require(math.isfinite(distance) and distance <= limit, 'TI capacitor distance failed: ' + capacitor)
                row[metric + 'DistanceMm'] = distance
                row[metric + 'Ball'] = ball
            rows.append(row)
    cap = components['C_DDR_CPU_13']
    courts = [e for e in circuit if e['type'].startswith('pcb_courtyard_')]
    own = [e for e in courts if e['pcb_component_id'] == cap['pcb_component_id']]
    require(len(own) == 1, 'Exact CPU13 courtyard required')
    a = courtyard_box(own[0])
    margins = []
    for other in courts:
        if other.get('layer') != cap['layer'] or other['pcb_component_id'] == cap['pcb_component_id']:
            continue
        b = courtyard_box(other)
        dx = max(a[0] - b[1], b[0] - a[1], 0)
        dy = max(a[2] - b[3], b[2] - a[3], 0)
        gap = math.hypot(dx, dy)
        require(gap >= .05 - 1e-9, 'CPU13 same-layer courtyard below .05 mm margin')
        margins.append((gap, other['pcb_component_id']))
    require(margins, 'Other same-layer courtyards missing')
    nearest = min(margins)
    nearest_name = next(name for name, e in components.items() if e['pcb_component_id'] == nearest[1])
    return {'all32CapacitorDistancesQualified': True, 'rows': rows,
            'cpu13': next(row for row in rows if row['capacitor'] == 'C_DDR_CPU_13'),
            'cpu13CourtyardGapMm': nearest[0], 'nearestSameLayerCourtyard': nearest_name,
            'requiredCourtyardGapMm': .05, 'scope': 'Geometric placement only; no routed PDN/loop/timing qualification'}


def validate(base, v5, compiled, table, declarations):
    # Unchanged established inventory/reference validator, now with exact new table.
    original = reference_validate(base, compiled, table, declarations)
    for kind in LOGIC:
        require(typed(v5, kind) == typed(compiled, kind), 'V5 logical records changed: ' + kind)
    old_components = by_id(v5, 'pcb_component')
    sources = by_id(v5, 'source_component')
    names = {pid: sources[e['source_component_id']]['name'] for pid, e in old_components.items()
             if e['source_component_id'] in sources}
    moved_ids = {pid for pid, name in names.items() if name == 'C_DDR_CPU_13'}
    require(len(moved_ids) == 1, 'Exact original CPU13 component required')
    moved_id = next(iter(moved_ids))
    cap = old_components[moved_id]
    require(cap['center'] == {'x': -4.5, 'y': 16.8} and cap['layer'] == 'bottom' and cap['rotation'] == 0,
            'Original CPU13 source pose differs')
    new_pose = {'pcbX': -4.48, 'pcbY': 16.8, 'layer': 'bottom', 'pcbRotation': 0}
    require(table['C_DDR_CPU_13'] == new_pose, 'Exact20um CPU13 movement required')
    changed = []
    for kind in GEOMETRY:
        before, after = by_id(v5, kind), by_id(compiled, kind)
        require(set(before) == set(after), 'V5 geometry IDs changed: ' + kind)
        for ident, row in before.items():
            expected = expected_geometry(row, cap, new_pose) if row.get('pcb_component_id') == moved_id else row
            equivalent(expected, after[ident], ident)
            if row != after[ident]:
                changed.append({'type': kind, 'id': ident, 'belongsToMovedCap': row.get('pcb_component_id') == moved_id})
    equivalent(typed(v5, 'pcb_board'), typed(compiled, 'pcb_board'), 'unchangedBoard')
    equivalent(typed(v5, 'pcb_trace'), typed(compiled, 'pcb_trace'), 'unchanged2ReferenceTraces')
    equivalent(typed(v5, 'pcb_via'), typed(compiled, 'pcb_via'), 'unchanged2ReferenceVias')
    require(all(row['belongsToMovedCap'] for row in changed), 'Unplanned geometry movement')
    metrics = placement_metrics(compiled)
    return {'passed': True, 'originalInventoryAndReferenceValidation': original,
            'v5LogicalRecordsExact': True, 'onlyCpu13OwnedGeometryMoved': True,
            'otherEightMovedCapCentersUnchanged': True, 'cpuRamPosesUnchanged': True,
            'changedGeometry': changed, 'placementMetrics': metrics,
            'originalParts': 280, 'originalPhysicalContacts': 1161,
            'ddrSignals': 49, 'fixedPhysicalReferences': 2,
            'signalRoutingPerformed': False, 'accepted49': False, 'fabricationReady': False}
