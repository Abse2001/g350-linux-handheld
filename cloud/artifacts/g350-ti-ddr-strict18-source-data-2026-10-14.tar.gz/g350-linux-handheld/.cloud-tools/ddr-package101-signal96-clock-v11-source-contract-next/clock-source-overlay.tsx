import { Children, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import { buildCombinedLocalSource } from "/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-signal96-joint-native-sourceonly-next/combined-source-overlay"
import proposal from "./clock-source-proposal.json"

type Props = Record<string, unknown> & { name?: string; children?: ReactNode }
type XY = { x: number; y: number }
const clocks = proposal.clockCarriers

/** Append actual source-layer ports and carriers. No geometry or original
 * property is rewritten. Root must register each new port's real Via match
 * after circuit.add(element) and before the first render. */
export function buildCombinedClockV11Source() {
  if (proposal.preservedLiteralElements !== 2228 || proposal.proposedLiteralElements !== 2234 || clocks.length !== 2)
    throw Error("Exact measured reference/signal source and two clocks required")
  const owners = clocks.flatMap(c => [c.cpu, c.ram])
  const base = buildCombinedLocalSource()
  let boards = 0, addedPorts = 0, addedTraces = 0
  const matchedNames = new Set<string>()
  function append(node: ReactNode): ReactNode {
    if (!isValidElement<Props>(node)) return node
    const props = { ...node.props }
    const children = Children.toArray(props.children).map(append)
    const owner = owners.find(o => o.viaName === props.name)
    if (owner) {
      if (node.type !== "via" || props.pcbX !== owner.viaXY.x || props.pcbY !== owner.viaXY.y
        || props.fromLayer !== "top" || props.toLayer !== "bottom" || props.outerDiameter !== .4572 || props.holeDiameter !== .254
        || owner.carrierLayer !== "inner1" || children.length !== 0 || matchedNames.has(owner.viaName))
        throw Error("Exactly four unchanged standard clock barrels and empty literal child lists required")
      matchedNames.add(owner.viaName)
      // A real source Port; no counterfeit pcb_port record or ownership patch.
      children.push(<port name="inner1" layer="inner1" />)
      addedPorts++
    }
    if (node.type === "board") {
      boards++
      if (props.layers !== 4 || props.routeRemaining !== false || (props.pcbX ?? 0) !== 0 || (props.pcbY ?? 0) !== 0 || (props.pcbRotation ?? 0) !== 0)
        throw Error("Original routing-disabled identity-frame four-layer board required")
      for (const clock of clocks) {
        const cpu = clock.cpu.viaXY, ram = clock.ram.viaXY
        const path = clock.expectedInner1PhysicalRoute
        if (path.length < 2 || path.some(p => p.route_type !== "wire" || p.layer !== "inner1" || p.width !== .1016)
          || path[0].x !== cpu.x || path[0].y !== cpu.y || path.at(-1)!.x !== ram.x || path.at(-1)!.y !== ram.y
          || clock.sourcePortPath[0] !== clock.realCpuLayerPortSelector || clock.sourcePortPath[1] !== clock.realRamLayerPortSelector)
          throw Error("Actual CPU/RAM barrels and constant-width Inner1 wire carrier required")
        // First two real ports define the physical endpoints. The four actual
        // numeric/Top selectors join the original logical request and fanout aliases.
        children.push(<trace name={clock.carrierTraceName} path={clock.sourcePortPath} thickness={.1016}
          pcbPathRelativeTo={clock.pcbPathRelativeTo} pcbPath={clock.relativeInteriorPath} />)
        addedTraces++
      }
    }
    return cloneElement(node as ReactElement<Props>, props, ...children)
  }
  const element = append(base.element)
  if (boards !== 1 || addedPorts !== 4 || addedTraces !== 2 || matchedNames.size !== 4)
    throw Error("Exactly four real layer ports and two carrier trace elements required")
  return { ...base, element, clockSourceProposal: { ...proposal, sourceExecuted: false, typesExecuted: false, coreExecuted: false } }
}

type MatchableVia = { componentName: string; props: Props; pcb_via_id?: string | null }
type MatchablePort = {
  componentName: string; props: Props; parent: unknown; matchedComponents: unknown[]
  source_port_id?: string | null; pcb_port_id?: string | null
  registerMatch(component: unknown): void
  getAvailablePcbLayers(): string[]
}
type CircuitPortMatcher = {
  _hasRenderedAtleastOnce?: boolean; schematicDisabled?: boolean
  selectOne(selector: string, options?: { type?: string }): unknown
}
/** Use Core's public match registration on actual instantiated Port/Via objects.
 * No soup edits, fake ports, extra barrels or native ownership exceptions. */
export function registerClockInnerPorts(circuitUnknown: unknown) {
  const circuit = circuitUnknown as CircuitPortMatcher
  if (circuit._hasRenderedAtleastOnce || circuit.schematicDisabled !== true)
    throw Error("Register real clock ports before first PCB-only Core render")
  const registrations: Array<{ viaName: string; layer: "inner1"; originalNumericPin: string; xy: XY }> = []
  for (const clock of clocks) for (const owner of [clock.cpu, clock.ram]) {
    const via = circuit.selectOne(`.${owner.viaName}`) as MatchableVia | null
    const port = circuit.selectOne(`.${owner.viaName} > port.inner1`, { type: "port" }) as MatchablePort | null
    if (!via || via.componentName !== "Via" || via.props.name !== owner.viaName || via.props.pcbX !== owner.viaXY.x || via.props.pcbY !== owner.viaXY.y
      || via.props.fromLayer !== "top" || via.props.toLayer !== "bottom" || via.props.outerDiameter !== .4572 || via.props.holeDiameter !== .254
      || !port || port.componentName !== "Port" || port.parent !== via || port.props.name !== "inner1" || port.props.layer !== "inner1"
      || port.source_port_id || port.pcb_port_id || via.pcb_via_id
      || port.getAvailablePcbLayers().join(",") !== "inner1" || port.matchedComponents.some(c => c !== via))
      throw Error("Actual unrendered owned Via and explicit Inner1 Port required")
    if (!port.matchedComponents.includes(via)) port.registerMatch(via)
    if (port.matchedComponents.length !== 1 || port.matchedComponents[0] !== via)
      throw Error("The real layer port must match exactly its one existing physical barrel")
    registrations.push({ viaName: owner.viaName, layer: "inner1", originalNumericPin: `${owner.package}.pin${owner.numericPin}`, xy: owner.viaXY })
  }
  if (registrations.length !== 4) throw Error("Exactly four real port-to-barrel registrations required")
  return { registrations, sourceExecuted: false, coreRendered: false, nativeExecuted: false, physicalViaAdded: false }
}

export default () => buildCombinedClockV11Source().element
