"""Own stdlib finite Bottom0 RAM component and shortest octile north path; noSDK."""
ns={'__name__':'own_actual299_helper'};exec(open('/tmp/g350-actual299-source22-finite-helper-sourceonly.py').read(),ns);globals().update({k:v for k,v in ns.items() if not k.startswith('__')})
import heapq
from collections import Counter
P37='/tmp/g350-actual299-source37-same-two-vias-I1-finite-trombones-v3-three-width-bank-report.json';S37='c70a69a2c9e1eb13bf470fed9e0cde30574fc4c82ce8faf50890458e37cd531c';bb=Path(P37).read_bytes();assert hashlib.sha256(bb).hexdigest()==S37;j=json.loads(bb);assert j['bodyInverse']['before']==B['source_trace_37'];by={**B,'source_trace_37':j['bodyInverse']['after']};objects=list(FOUNDATION)
for n,t in by.items():
 if n!='source_trace_0':objects.extend(bodyobjects(t))
ss=Scene(objects);step=.05;bounds=(-60,140,160,360);start=(8,220);northY=340;dirs=[(1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1)];dist={start:0.};parents={start:None};heap=[(0.,start)];ec={};boundary=Counter();witness={};firstNorth=None;expanded=0

def wire(a,b):return {'pcb_trace_id':'source0_RAM_Bottom_frontier_not_final_route','connection_name':'source_trace_0','route':[{'route_type':'wire','x':a[0]*step,'y':a[1]*step,'layer':'bottom','width':.1016},{'route_type':'wire','x':b[0]*step,'y':b[1]*step,'layer':'bottom','width':.1016}]}
while heap:
 d,a=heapq.heappop(heap)
 if d>dist[a]+1e-10:continue
 expanded+=1;assert expanded<=41000
 if firstNorth is None and a[1]>=northY:firstNorth=a
 for dx,dy in dirs:
  b=(a[0]+dx,a[1]+dy)
  if not(bounds[0]<=b[0]<=bounds[1] and bounds[2]<=b[1]<=bounds[3]):continue
  nd=d+step*(math.sqrt(2) if dx and dy else 1)
  if nd>=dist.get(b,math.inf)-1e-10:continue
  k=tuple(sorted([a,b]))
  if k not in ec:ec[k]=ss.contacts(wire(a,b))
  cs=ec[k]
  if cs:
   for z in cs:
    key=(z['otherOwner'],z['otherId']);boundary[key]+=1
    if key not in witness:witness[key]={'from':[a[0]*step,a[1]*step],'to':[b[0]*step,b[1]*step],'contact':z}
   continue
  dist[b]=nd;parents[b]=a;heapq.heappush(heap,(nd,b))
path=[]
if firstNorth is not None:
 a=firstNorth
 while a is not None:path.append(a);a=parents[a]
 path.reverse()
 compressed=[]
 for i,a in enumerate(path):
  if i in [0,len(path)-1]or (a[0]-path[i-1][0],a[1]-path[i-1][1])!=(path[i+1][0]-a[0],path[i+1][1]-a[1]):compressed.append(a)
 diagnostic=wire(start,start);diagnostic['route']=[{'route_type':'wire','x':a[0]*step,'y':a[1]*step,'layer':'bottom','width':.1016}for a in compressed];contacts=ss.contacts(diagnostic);assert not contacts
 physicalLength=sum(math.hypot(b[0]-a[0],b[1]-a[1])*step for a,b in zip(compressed,compressed[1:]));assert abs(physicalLength-dist[firstNorth])<1e-8
else:compressed=[];diagnostic=None;contacts=[];physicalLength=None
xy=[(a[0]*step,a[1]*step)for a in dist];bbox={'x':[min(x for x,y in xy),max(x for x,y in xy)],'y':[min(y for x,y in xy),max(y for x,y in xy)]};clipped=any(a[0]in[bounds[0],bounds[1]]or a[1]in[bounds[2],bounds[3]]for a in dist)
source13B=[(i,a,b)for i,(a,b)in enumerate(zip(by['source_trace_13']['route'],by['source_trace_13']['route'][1:]))if a['route_type']==b['route_type']=='wire'and a['layer']==b['layer']=='bottom']
R={'scope':'OWN_STDLIB_LITERAL_ACTUAL299_PLUS_MATCHED37_RAM0_BOTTOM_FINITE_COMPONENT_AND_SHORTEST_OCTILE_NORTH_FRONTIER_NOT_ROUTE_ACCEPTANCE','inputPath':P299,'inputSha256':S299,'proposed37':{'path':P37,'sha256':S37},'roi':{'x':[-3,7],'y':[8,18],'stepMm':step},'ram0AuthenticWorkingBarrel':[.4,11],'ram0ActualTopBall':[0,10.6],'bothSource0WorkingBarrelsAndPadsHeld':True,'source0OldCarrierOnlyOmittedAsReplacementPlanning':True,'noNewPortalsAssumed':True,'allOther48BodiesLiteral299ExceptExactMatched37':True,'allFoundation129ReferenceVias165ReferencesCapsTwoPdnCriticalSixAndNumericIdentitiesHeld':True,'requested18NarrowUNotIncludedNoBottomEffectAssumed':True,'wireWidthMm':.1016,'nativeTracePadGapMm':.1016,'relaxedTurnAndSelfStateForTopologyOnly':True,'componentNodeCount':len(dist),'componentBounds':bbox,'roiBoundaryReached':clipped,'northY17Reached':firstNorth is not None,'selectedNorthSampleXY':None if firstNorth is None else [firstNorth[0]*step,firstNorth[1]*step],'shortestOctileGeometricLengthMmToAnyReachedNorthSample':physicalLength,'shortestGridPath':[list(a)for a in path],'compressedDiagnosticTrace':diagnostic,'compressedDiagnosticForeignContacts':contacts,'boundaryColliderRows':[{'owner':n,'id':pid,'contactCount':c,'witness':witness[(n,pid)]}for(n,pid),c in boundary.most_common()],'source13BottomSegmentRoster':[{'index':i,'a':a,'b':b}for i,a,b in source13B],'componentGridPoints':xy,'finiteGridNotContinuousShortestOrGlobalInfeasibilityProof':True,'noNativeSignalHeadingOwnInlineViaOrSelfAcceptanceInferred':True,'nativeExecuted':False,'sourceCoreDerived':False,'cadExecuted':False,'all49Accepted':False,'timingPassed':False,'fabricationReady':False};out=Path('/tmp/g350-actual299-plus-matched37-source0-RAM-Bottom-north-frontier-report.json');out.open('x').write(json.dumps(R,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'sourceSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'nodes':len(dist),'bbox':bbox,'northReached':firstNorth is not None,'northSample':R['selectedNorthSampleXY'],'lengthMm':physicalLength,'compressedXY':None if diagnostic is None else [[v['x'],v['y']]for v in diagnostic['route']],'topBoundary':[(z['owner'],z['id'],z['contactCount'])for z in R['boundaryColliderRows'][:8]]},indent=2))
