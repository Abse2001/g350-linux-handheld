const fs = require("node:fs")
const path = require("node:path")
const crypto = require("node:crypto")
const assert = require("node:assert/strict")
const ts = require("/workspace/bus-lanes-solver/node_modules/typescript")
const esbuild = require("/workspace/bus-lanes-solver/node_modules/esbuild")
const root = __dirname
const trustedRoot = "/workspace/bus-lanes-solver/node_modules"
const fanoutCopyRoot = path.join(root, "fanout-source")
const compilerOptions = { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true, sourceMap: false, removeComments: false }
const transformed = new Map()
const externals = new Set()
const externalBindings = new Map()
const hash = bytes => crypto.createHash("sha256").update(bytes).digest("hex")
const plugin = {
  name: "bound-commonjs-fixture-and-trusted-fanout",
  setup(build) {
    build.onResolve({ filter: /^bun:test$/ }, args => {
      const pure = args.importer.endsWith("public-pipeline-protocol.test.ts.cjs") || args.importer.endsWith("natural-public-output.test.ts.cjs")
      const native = args.importer.endsWith("native-controls.ts.cjs") || args.importer.endsWith("common-via-latest-core-recovery.ts.cjs") || args.importer.endsWith("native-site-bank-replay.ts.cjs") || args.importer.endsWith("caller-selection-controls.ts.cjs")
      assert.ok(pure || native, "Bun imports allowed only in exact copied control fixtures and their wrapper")
      return { path: path.join(root, pure ? "api-test-adapter.ts.cjs" : "spy-adapter.ts.cjs"), namespace: "qualified-commonjs" }
    })
    build.onResolve({ filter: /^(\.|\/)/ }, async args => {
      if (args.pluginData?.qualifiedResolution) return undefined
      const resolved = await build.resolve(args.path, { resolveDir: args.resolveDir || root, importer: args.importer, kind: args.kind, pluginData: { qualifiedResolution: true } })
      assert.equal(resolved.errors.length, 0, JSON.stringify(resolved.errors))
      // Preserve the original dependency's esbuild TS loader and export semantics.
      if (resolved.path.startsWith(fanoutCopyRoot + "/")) return { path: resolved.path }
      if (resolved.path.startsWith(root + "/") && resolved.path.endsWith(".ts")) return { path: resolved.path + ".cjs", namespace: "qualified-commonjs" }
      return undefined
    })
    build.onResolve({ filter: /^(https?:|data:)/ }, args => { throw Error(`Network/resource imports forbidden: ${args.path}`) })
    build.onResolve({ filter: /^[^./]/ }, async args => {
      if (args.pluginData?.trustedImportEntry) return undefined
      if (args.path === "@tscircuit/fanout-solver") return { path: path.join(fanoutCopyRoot, "lib/index.ts") }
      externals.add(args.path)
      if (args.path.startsWith("node:")) return { path: args.path, external: true }
      const resolved = await build.resolve(args.path, { resolveDir: args.resolveDir, importer: args.importer, kind: "import-statement", pluginData: { trustedImportEntry: true } })
      assert.equal(resolved.errors.length, 0, JSON.stringify(resolved.errors))
      const real = fs.realpathSync(resolved.path)
      assert.ok(real.startsWith(trustedRoot + "/"), `Trusted compiled dependency required: ${real}`)
      assert.ok(/\.[cm]?js$/.test(real), `External dependency must be compiled JavaScript: ${real}`)
      externalBindings.set(`${args.importer}|${args.path}`, { importer: args.importer, requested: args.path, realpath: real, sha256: hash(fs.readFileSync(real)), mode: fs.statSync(real).mode & 0o777 })
      return { path: real, external: true }
    })
    build.onLoad({ filter: /\.ts\.cjs$/, namespace: "qualified-commonjs" }, args => {
      const originalPath = args.path.slice(0, -4)
      assert.ok(originalPath.startsWith(root + path.sep))
      const raw = fs.readFileSync(originalPath)
      const result = ts.transpileModule(raw.toString(), { compilerOptions, fileName: originalPath, reportDiagnostics: true })
      const errors = (result.diagnostics || []).filter(item => item.category === ts.DiagnosticCategory.Error)
      assert.equal(errors.length, 0, JSON.stringify(errors))
      transformed.set(originalPath, { sourceSha256: hash(raw), generatedSha256: hash(result.outputText), generatedBytes: Buffer.byteLength(result.outputText) })
      return { contents: result.outputText, loader: "js", resolveDir: path.dirname(originalPath) }
    })
  },
}
async function main() {
  const opts = { absWorkingDir: root, entryPoints: ["runner.ts"], outfile: path.join(root, "runner.cjs"), bundle: true, platform: "node", format: "cjs", target: "node25", minify: false, treeShaking: true, metafile: true, write: false, plugins: [plugin], logLevel: "silent" }
  const first = await esbuild.build(opts)
  const second = await esbuild.build(opts)
  assert.equal(first.outputFiles.length, 1)
  assert.equal(second.outputFiles.length, 1)
  assert.deepEqual(first.outputFiles[0].contents, second.outputFiles[0].contents)
  assert.deepEqual(first.metafile, second.metafile)
  fs.writeFileSync(path.join(root, "runner.cjs"), first.outputFiles[0].contents, { flag: "wx" })
  fs.writeFileSync(path.join(root, "bundle-metafile.json"), JSON.stringify(first.metafile, null, 2) + "\n", { flag: "wx" })
  const inputBindings = Object.keys(first.metafile.inputs).map(name => {
    const original = name.startsWith("qualified-commonjs:") ? name.slice("qualified-commonjs:".length, -4) : path.resolve(root, name)
    const real = fs.realpathSync(original), raw = fs.readFileSync(real)
    assert.ok(real.startsWith(root + "/") || real.startsWith(trustedRoot + "/"))
    return { path: name, realpath: real, bytes: raw.length, sha256: hash(raw), mode: fs.statSync(real).mode & 0o777 }
  })
  const privateMatcher = path.join(fanoutCopyRoot, "lib/match-component-dogbone-via-sites.ts")
  const privateIndex = path.join(fanoutCopyRoot, "lib/index.ts")
  const included = new Set(inputBindings.map(binding => binding.realpath))
  assert.ok(included.has(privateMatcher) && included.has(privateIndex), "Private patched fanout must be in the actual bundle")
  assert.ok(!inputBindings.some(binding => binding.realpath.startsWith(path.join(trustedRoot, "@tscircuit/fanout-solver/lib") + "/")), "Original fanout implementation must not shadow the private copy")
  const fanoutOverride = { copiedPackageVersion: JSON.parse(fs.readFileSync(path.join(fanoutCopyRoot,"package.json"))).version, privateMatcherSha256: hash(fs.readFileSync(privateMatcher)), privateIndexSha256: hash(fs.readFileSync(privateIndex)), privateMatcherInBundle: true, originalInstalledFanoutLibBundled: false, installedDependenciesEdited: false }
  const report = { typescript: ts.version, esbuild: esbuild.version, options: { ...opts, plugins: [plugin.name] }, compilerOptions, deterministicTwoBuilds: true, sourceTransforms: [...transformed].map(([path, binding]) => ({ path, ...binding })), inputBindings, externalImports: [...externals].sort(), externalBindings: [...externalBindings.values()], bundleBytes: first.outputFiles[0].contents.byteLength, bundleSha256: hash(first.outputFiles[0].contents), productionBusSourceEdited: false, privateFanoutSourceChanged: true, fanoutOverride, productionEntryEngine: "Node25.6.1", pureHelperControlsSharedAcrossEngines: true }
  fs.writeFileSync(path.join(root, "build-receipt.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" })
  const errorOpts = { ...opts, entryPoints: ["error-fields-controls.ts"], outfile: path.join(root, "error-fields-controls.cjs") }
  const control1 = await esbuild.build(errorOpts), control2 = await esbuild.build(errorOpts)
  assert.deepEqual(control1.outputFiles[0].contents, control2.outputFiles[0].contents)
  assert.deepEqual(control1.metafile, control2.metafile)
  fs.writeFileSync(path.join(root, "error-fields-controls.cjs"), control1.outputFiles[0].contents, { flag: "wx" })
  fs.writeFileSync(path.join(root, "error-fields-controls-metafile.json"), JSON.stringify(control1.metafile, null, 2) + "\n", { flag: "wx" })
  fs.writeFileSync(path.join(root, "error-fields-controls-build-receipt.json"), JSON.stringify({ deterministicTwoBuilds: true, artifactSha256: hash(control1.outputFiles[0].contents), runtimeImports: false }, null, 2) + "\n", { flag: "wx" })
  console.log(JSON.stringify({ deterministicTwoBuilds: true, bundleBytes: report.bundleBytes, bundleSha256: report.bundleSha256, inputs: inputBindings.length, errorFieldsControlsSha256: hash(control1.outputFiles[0].contents) }))
}
main().catch(error => { console.error(error); process.exitCode = 1 })
