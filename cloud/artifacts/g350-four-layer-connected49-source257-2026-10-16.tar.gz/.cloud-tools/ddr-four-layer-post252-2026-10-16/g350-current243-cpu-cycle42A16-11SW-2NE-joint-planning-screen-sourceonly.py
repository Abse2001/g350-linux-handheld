"""Pure stdlib public-JSON planning geometry. No SDK/native/Core execution.

This is a conditional ordinary fanout/body proposal, never an accepted board.
Cap8 material stays authentic and its known refill collisions are reported.
"""
exec(open('/tmp/g350-generic-focus-static-helper.py').read())
P='/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json'
PIN='cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720'
assert hashlib.sha256(Path(P).read_bytes()).hexdigest()==PIN
p=json.loads(Path(P).read_text());f=p['full49FanoutInput'];own=lambda t:t.get('connection_name') or t.get('source_trace_id');xy=lambda a:dict(zip(('x','y'),a))
oldbody={n:next(t for t in p['ordinaryCarrierTraces'] if own(t)=='source_trace_'+str(n)) for n in (2,11,35,42)}
oldcpu={n:next(t for t in f['traces'] if own(t)=='source_trace_'+str(n) and t['pcb_trace_id']==id) for n,id in ((2,'pcb_trace_3'),(11,'pcb_trace_30'))}
paths42=[('inner1',[(3.2,13.6),(2.8,14),(2,14),(1.6,14.4)]),('bottom',[(1.6,14.4),(1.2,14),(.61224,14),(.41224,13.8),(.41224,11.78256)]),('top',[(.41224,11.78256),(-.1,11.78256),(-.3,11.58256),(-.3,11.5),(-.1,11.3),(.1,11.3),(.2,11.4),(1.6,11.4),(2,11),(2,9.4)])]
vias42=[(1.6,14.4),(.41224,11.78256)]
R11='/tmp/g350-current243-source11-SW-lowered-ridge148-static.json';r11=json.load(open(R11));assert r11['inputSha256']==PIN
paths11=[('inner2',r11['proposedPath'])]
paths2=[('bottom',[(.8,13.6),(1.2,13.2),(1.2,12.4),(1.6,12),(1.6,10.1),(1.2,9.7),(1.2,9.4)]),('inner2',[(1.2,9.4),(1.6,9),(1.6,8.6),(2.4328,7.7672),(2.8964,7.7672),(4.8776,5.786),(7.214,5.786),(7.6,5.4)])]
R35='/tmp/g350-current243-source35-left04-raised02-pending-cap8-static.json';r35=json.load(open(R35));assert hashlib.sha256(Path(R35).read_bytes()).hexdigest()=='bd92324dfc9bc416f96db97f126e282a0d14a58f29088afd979e25d8cf66a0fb'
new35=r35.get('bodyInverse',r35.get('inverse',{})).get('after')
if new35 is None:
 def findafter(v):
  if isinstance(v,dict):
   if 'after' in v and isinstance(v['after'],dict) and v['after'].get('route'):return v['after']
   for q in v.values():
    r=findafter(q)
    if r:return r
  return None
 new35=findafter(r35)
assert new35 and own(new35)=='source_trace_35'
paths35=[('bottom',[(q['x'],q['y']) for q in new35['route']])]
cpu2=[(.4,13.2),(.8,13.6)];cpu11=[(.4,14),(0,13.6)]
d12head=[(0,15.2),(-.4134,14.7866),(-.4134,12.6634),(0,12.25)]
d12i2=[(0,12.25),(.25,12.25),(.8,12.8)]
plans={42:(paths42,vias42),11:([('top',cpu11),*paths11],[(0,13.6)]),2:([('top',cpu2),*paths2],[(.8,13.6),(1.2,9.4)]),35:(paths35,[]),26:([('inner1',d12head),('inner2',d12i2)],[(0,12.25),(.8,12.8)])}
removedIds={t['pcb_trace_id'] for t in [*oldbody.values(),*oldcpu.values()]}
def add(g,n,paths,vias):
 for layer,ps in paths:
  for i,(a,b) in enumerate(zip(ps,ps[1:])):
   o={'kind':'wire','a':xy(a),'b':xy(b),'radius':.0508,'layers':[layer],'index':i,'owner':'source_trace_'+str(n),'id':'planned_'+str(n)+'_'+layer};o['bbox']=g['bbox'](o);g['objects'].append(o)
 for i,point in enumerate(vias):
  o={'kind':'via','p':xy(point),'radius':.2286,'holeRadius':.127,'layers':g['L'],'index':i,'owner':'source_trace_'+str(n),'id':'planned_'+str(n)+'_fullspan'};o['bbox']=g['bbox'](o);g['objects'].append(o)
def scene(n):
 g=focus(n,P,PIN);g['objects'][:]=[o for o in g['objects'] if o['id'] not in removedIds]
 for m,(ps,vs) in plans.items():
  if m!=n:add(g,m,ps,vs)
 return g
def screen(n):
 g=scene(n);ps,vs=plans[n];w=[]
 for l,path in ps:
  for i,(a,b) in enumerate(zip(path,path[1:])):
   hs=g['wireContacts'](xy(a),xy(b),l)
   if hs:w.append({'layer':l,'index':i,'a':a,'b':b,'blockers':sorted(set((o['owner'],o['id'],o.get('index',-1)) for o in hs))})
 v=[{'point':q,'blockers':sorted(set((o['owner'],o['id'],o.get('index',-1)) for o in g['viaContacts'](xy(q))))} for q in vs]
 return {'owner':'source_trace_'+str(n),'foreignWireContacts':w,'foreignViaContacts':v,'allScreenedContactsZero':not w and not any(q['blockers'] for q in v)}
def body(n,paths):
 route=[]
 for i,(l,ps) in enumerate(paths):
  if i:route.append({'route_type':'via','x':ps[0][0],'y':ps[0][1],'from_layer':paths[i-1][0],'to_layer':l,'layers':['top','inner1','inner2','bottom'],'via_diameter':.4572,'via_hole_diameter':.254})
  route += [{'route_type':'wire','x':q[0],'y':q[1],'layer':l,'width':.1016} for q in ps]
 return {'type':'pcb_trace','pcb_trace_id':'planned_cpu_cycle_source_trace_'+str(n),'connection_name':'source_trace_'+str(n),'source_trace_id':'source_trace_'+str(n),'route':route}
def cpu(n,ps,layer):
 after=json.loads(json.dumps(oldcpu[n]));assert len(after['route'])==4 and [q['route_type'] for q in after['route']]==['wire','wire','via','wire']
 assert math.dist((after['route'][0]['x'],after['route'][0]['y']),ps[0])<1e-8
 for q in after['route'][1:]:q['x'],q['y']=ps[1]
 after['route'][2]['to_layer']=layer
 after['route'][3]['layer']=layer
 return {'owner':'source_trace_'+str(n),'before':oldcpu[n],'after':after,'authenticNumericFirstPointUnchanged':True,'logicalSignalAndAllPortIdsUnchanged':True}
def length(paths):return sum(math.dist(a,b) for _,ps in paths for a,b in zip(ps,ps[1:]))
whole42=2*math.sqrt(.32)+length(paths42);whole2=2*math.sqrt(.32)+length(paths2);whole11=2*math.sqrt(.32)+length(paths11)
heads=[]
for n,paths in ((42,paths42),(2,paths2),(11,paths11)):
 for l,ps in paths:
  angles=[math.degrees(math.atan2(b[1]-a[1],b[0]-a[0])) for a,b in zip(ps,ps[1:])];turns=[abs((b-a+180)%360-180) for a,b in zip(angles,angles[1:])]
  assert all(abs(x/45-round(x/45))<1e-7 for x in angles) and all(x<=45+1e-7 for x in turns)
  heads.append({'owner':n,'layer':l,'angles':angles,'maximumTurnDegrees':max(turns)})
reports=[screen(n) for n in (42,11,2,35,26)]
out={'scope':'PURE_STDLIB_CONDITIONAL_CPU42_PORTAL11SW2NE_CYCLE_PLUS_D12_P_TO_OLD2_PORTAL_REQUIRES_AUTHENTIC_CAP8_MOVE_NO_SDK_NO_ACCEPTANCE','inputPath':P,'inputSha256':PIN,'body42Paths':paths42,'body42NewFullspanViaSites':vias42,'body42WholeMm':whole42,'body42DerivedWindowMm':[10.948732633289541,11.8],'body42MinimumMatched':whole42>=10.948732633289541,'body42MaximumSatisfied':whole42<=11.8,'body42Inverse':{'before':oldbody[42],'after':body(42,paths42)},'cpuFanoutInverses':[cpu(2,cpu2,'bottom'),cpu(11,cpu11,'inner2')],'body11Inverse':{'before':oldbody[11],'after':body(11,paths11)},'body2Inverse':{'before':oldbody[2],'after':body(2,paths2)},'body35Inverse':{'before':oldbody[35],'after':new35},'body2WholeMm':whole2,'body11WholeMm':whole11,'body2And11DerivedWindowMm':[12.907653789032027,14.177653789032021],'d12PlannedPaths':plans[26][0],'d12PlannedFullspanViaSites':plans[26][1],'reports':reports,'body42HeadingReports':heads,'cap8PlacementDeltaNotYetAuthored':True,'allOtherHardwareAndReferenceGeometryHeld':True,'ownSelfTerminalNativeC31AndSourceChecksPending':True,'partialTopologyOnly':True,'all49Accepted':False,'fabricationReady':False}
O='/tmp/g350-current243-cpu-cycle42A16-11SW-2NE-joint-planning-screen-report.json';Path(O).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'output':O,'sha256':hashlib.sha256(Path(O).read_bytes()).hexdigest(),'whole42':whole42,'whole2':whole2,'whole11':whole11,'reports':reports},indent=2))
