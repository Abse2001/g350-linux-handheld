import { strict as assert } from "node:assert"
import type { Connection, SimpleRouteJson, Trace } from "./source/lib/types"
export type InitialResult = { connections: Connection[]; traces: Trace[] }
export function deriveFreshAllocation(
  native: SimpleRouteJson,
  result: InitialResult,
) {
  assert.equal(result.connections.length, 49)
  assert.deepEqual(
    result.connections.map((c) => c.name),
    native.connections.map((c) => c.name),
  )
  const escapes: Trace[] = result.traces.map((trace) => ({
    ...trace,
    source_trace_id:
      native.connections.find((c) => c.name === trace.connection_name)
        ?.source_trace_id ?? trace.connection_name,
  }))
  const physical = ["top", "inner1", "inner2", "bottom"]
  const layers = physical.filter((layer) =>
    native.allowedLayers?.includes(layer),
  )
  const terminalLayers = new Map<string, string[]>()
  for (const connection of native.connections) {
    const vias = escapes
      .filter((trace) => trace.connection_name === connection.name)
      .flatMap((trace) =>
        trace.route.filter((point) => point.route_type === "via"),
      )
    if (vias.length !== 2) continue
    const available = layers.filter(
      (layer) =>
        (native.buses ?? []).every(
          (bus) =>
            !bus.connectionNames.includes(connection.name) ||
            !bus.allowedLayers ||
            bus.allowedLayers.includes(layer),
        ) &&
        vias.every(
          (via) =>
            (layer !== via.from_layer ||
              native.allowedLayers?.includes(layer)) &&
            (
              via.layers ??
              physical.slice(
                Math.min(
                  physical.indexOf(via.from_layer),
                  physical.indexOf(via.to_layer),
                ),
                Math.max(
                  physical.indexOf(via.from_layer),
                  physical.indexOf(via.to_layer),
                ) + 1,
              )
            ).includes(layer),
        ),
    )
    if (available.length > 1) terminalLayers.set(connection.name, available)
  }
  // Every original request is timing-scoped here, including the RESET bus.
  const timingNames = new Set(native.buses?.flatMap((b) => b.connectionNames))
  for (const pair of native.differentialPairs ?? [])
    if (pair.connectionNames.some((name) => timingNames.has(name)))
      for (const name of pair.connectionNames) timingNames.add(name)
  assert.equal(timingNames.size, 49)
  const pairNames = new Set(
    native.differentialPairs?.flatMap((pair) => pair.connectionNames),
  )
  const allocation: SimpleRouteJson = {
    ...native,
    connections: result.connections,
    traces: [
      ...(native.traces ?? []),
      ...escapes.filter((trace) => pairNames.has(trace.connection_name!)),
    ],
  }
  return { allocation, escapes, terminalLayers }
}
