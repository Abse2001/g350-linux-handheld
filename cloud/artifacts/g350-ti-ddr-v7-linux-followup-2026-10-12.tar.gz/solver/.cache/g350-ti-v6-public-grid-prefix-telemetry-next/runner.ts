/** Passive source914 public V6 prefix; no search limits or routing inputs are changed. */
import { strict as assert } from "node:assert"
import { createHash } from "node:crypto"
import fs from "node:fs"
import path from "node:path"
import { mock } from "bun:test"
import {
  createPublicPipeline,
  runPublicSteps,
} from "./public-pipeline-protocol"
import { sameHardware } from "./input-parity"
import { installGridPrefixTelemetry } from "./grid-prefix-telemetry"
import type { SimpleRouteJson } from "./source/lib/types"

const ROOT = import.meta.dir
const sha = (raw: string | Uint8Array) =>
  createHash("sha256").update(raw).digest("hex")
const atomic = (name: string, raw: string) => {
  const target = path.join(ROOT, "run", name)
  fs.writeFileSync(`${target}.tmp`, raw)
  fs.renameSync(`${target}.tmp`, target)
}

export async function main() {
  assert.deepEqual(process.argv.slice(2), ["--run-one-approved"])
  assert.equal(process.env.G350_COMBINED_PUBLIC_PIPELINE_APPROVED, "1")
  const packetRaw = fs.readFileSync(path.join(ROOT, "packet-manifest.json"))
  const packet = JSON.parse(packetRaw.toString())
  const packetSha256 = sha(packetRaw)
  const receiptPath = process.env.G350_COMBINED_PUBLIC_RECEIPT_PATH
  const receiptSha = process.env.G350_COMBINED_PUBLIC_RECEIPT_SHA256
  assert.ok(
    receiptPath && receiptSha,
    "Exact root receipt path and SHA required",
  )
  const receiptRaw = fs.readFileSync(receiptPath)
  assert.equal(sha(receiptRaw), receiptSha)
  const receipt = JSON.parse(receiptRaw.toString())
  assert.equal(receipt.authorizedByRoot, true)
  assert.equal(receipt.scope, "one-source914-ti-v6-passive-grid-prefix-control")
  assert.equal(receipt.packetSha256, packetSha256)
  assert.deepEqual(receipt.policy, packet.policy)
  assert.match(receipt.approvalToken, /^[0-9a-f]{32,128}$/)
  assert.ok(fs.existsSync(path.join(ROOT, "run")))
  for (const name of [
    "result.json",
    "latest-grid-telemetry.json",
    "public-progress.jsonl",
  ]) {
    assert.equal(
      fs.existsSync(path.join(ROOT, "run", name)),
      false,
      "Fresh output paths required",
    )
  }
  const inputRaw = fs.readFileSync(path.join(ROOT, "input.json"))
  const originalRaw = fs.readFileSync(
    path.join(ROOT, "original-unrestricted-input.json"),
  )
  assert.equal(sha(inputRaw), packet.inputBindings["input.json"].sha256)
  assert.equal(
    sha(originalRaw),
    packet.inputBindings["original-unrestricted-input.json"].sha256,
  )
  const input = JSON.parse(inputRaw.toString()) as SimpleRouteJson
  const original = JSON.parse(originalRaw.toString()) as SimpleRouteJson
  assert.ok(sameHardware(input, original), "Original physical inputs differ")
  assert.equal(input.connections.length, 49)
  assert.equal(input.traces?.length, 2)
  const inputBefore = JSON.stringify(input)
  const fixedBefore = sha(JSON.stringify(input.traces))
  const gridPath = new URL("./source/lib/grid-visibility.ts", import.meta.url)
    .pathname
  // Imports are below root authority/input checks. Importing this module constructs no Grid.
  const grid = await import("./source/lib/grid-visibility")
  const originals = { ...grid }
  const Search = grid.GridVisibilitySearch
  const Projector = grid.GridHistoryProjector
  const stepDescriptor = Object.getOwnPropertyDescriptor(
    Search.prototype,
    "step",
  )!
  const cancelDescriptor = Object.getOwnPropertyDescriptor(
    Search.prototype,
    "cancel",
  )!
  const limits = { grid: 96 * 1024, progress: 24 * 1024, result: 8 * 1024 }
  let writes = 0,
    writeErrors = 0,
    gridBytes = 0,
    progressBytes = 0,
    progressRows = 0,
    droppedProgress = 0
  const publish = (snapshot: unknown) => {
    try {
      const raw = `${JSON.stringify({ diagnosticOnly: true, accepted49: false, packetSha256, sourceManifestSha256: packet.sourceManifestSha256, inputSha256: sha(inputRaw), snapshot })}\n`
      if (Buffer.byteLength(raw) > limits.grid) {
        writeErrors++
        return
      }
      atomic("latest-grid-telemetry.json", raw)
      gridBytes = Buffer.byteLength(raw)
      writes++
    } catch {
      writeErrors++
    }
  }
  const profile = installGridPrefixTelemetry(grid, publish, (exports) =>
    mock.module(gridPath, () => exports),
  )
  let solver: any, terminal: ReturnType<typeof runPublicSteps> | undefined
  let originalException: string | null = null,
    bindingsRestored = false
  const started = performance.now()
  let phase: string | null = null
  let lastBucket = -1
  try {
    const active = await import("./source/lib/grid-visibility")
    assert.notEqual(active.GridVisibilitySearch, Search)
    assert.notEqual(active.GridHistoryProjector, Projector)
    assert.equal(active.GridVisibilitySearch.prototype, Search.prototype)
    assert.equal(active.GridHistoryProjector.prototype, Projector.prototype)
    const { BusLanesPipelineSolver } = await import("./source/lib")
    solver = createPublicPipeline(BusLanesPipelineSolver, input)
    assert.equal(solver.MAX_ITERATIONS, 8_000_000)
    assert.equal(solver.options.goal, undefined)
    assert.equal(solver.options.maxSearchIterations, undefined)
    assert.equal(solver.options.maxBusViaCountSkew, 0)
    assert.equal(solver.options.maxPairViaCountSkew, 0)
    assert.equal(solver.options.precheckEnclosedTerminals, true)
    terminal = runPublicSteps(solver, (row) => {
      const bucket = Math.floor(row.publicSteps / 5000)
      if (
        row.phase === phase &&
        bucket === lastBucket &&
        !row.solved &&
        !row.failed
      )
        return
      phase = row.phase
      lastBucket = bucket
      try {
        const raw = `${JSON.stringify({ ...row, elapsedMs: performance.now() - started })}\n`
        const bytes = Buffer.byteLength(raw)
        if (progressRows < 64 && progressBytes + bytes <= limits.progress) {
          fs.appendFileSync(
            path.join(ROOT, "run", "public-progress.jsonl"),
            raw,
          )
          progressRows++
          progressBytes += bytes
        } else droppedProgress++
      } catch {
        writeErrors++
      }
    })
  } catch (error) {
    originalException = String(error).slice(0, 1024)
  } finally {
    profile.restore()
    const restored = await import("./source/lib/grid-visibility")
    bindingsRestored =
      restored.GridVisibilitySearch === Search &&
      restored.GridHistoryProjector === Projector &&
      Object.getOwnPropertyDescriptor(Search.prototype, "step")!.value ===
        stepDescriptor.value &&
      Object.getOwnPropertyDescriptor(Search.prototype, "cancel")!.value ===
        cancelDescriptor.value
    assert.equal(Object.keys(restored).length, Object.keys(originals).length)
    publish(profile.snapshot())
  }
  const telemetry = profile.snapshot()
  const inputUnchanged =
    JSON.stringify(input) === inputBefore &&
    sha(fs.readFileSync(path.join(ROOT, "input.json"))) === sha(inputRaw)
  const fixedReferencesHeld =
    solver !== undefined &&
    sha(JSON.stringify(solver.input.traces)) === fixedBefore
  const telemetryBounded =
    gridBytes <= limits.grid &&
    progressBytes <= limits.progress &&
    progressRows <= 64
  const result = {
    diagnosticOnly: true,
    diagnosticQualified:
      terminal !== undefined &&
      originalException === null &&
      inputUnchanged &&
      fixedReferencesHeld &&
      bindingsRestored &&
      telemetry.observationErrors === 0 &&
      writeErrors === 0 &&
      telemetryBounded,
    packetSha256,
    sourceCommit: null,
    sourceRevisionLabel: packet.sourceRevision,
    sourceManifestSha256: packet.sourceManifestSha256,
    libraryManifestSha256: packet.libraryManifestSha256,
    sourceClosureSha256: packet.sourceClosureSha256,
    libTree: null,
    sourceFileCount: 914,
    inputSha256: sha(inputRaw),
    originalInputSha256: sha(originalRaw),
    requestedOptions: packet.requestedOptions,
    publicPipelineExecuted: solver !== undefined,
    originalDefaultCap: solver?.MAX_ITERATIONS ?? null,
    capUnchanged: solver?.MAX_ITERATIONS === 8_000_000,
    terminal: terminal ?? null,
    originalException,
    inputUnchanged,
    fullHardwareHeld: sameHardware(input, original),
    fixedReferencesHeld,
    suppliedPhysicalReferences: 2,
    telemetryBindingsRestored: bindingsRestored,
    observationErrors: telemetry.observationErrors + writeErrors,
    telemetryBounded,
    writes,
    progressRows,
    droppedProgress,
    artifactBytes: { latestGrid: gridBytes, publicProgress: progressBytes },
    actualSolverState: solver
      ? {
          iterations: solver.iterations,
          phase: solver.phase,
          solved: solver.solved,
          failed: solver.failed,
          actualTraceCount: solver.traces.length,
        }
      : null,
    totalChildSeconds: (performance.now() - started) / 1000,
    accepted49: false,
    tiEligibleBoard: false,
    fabricationReady: false,
    scope:
      "Passive prefix only; resource interruption and unfinished cancellation do not prove physical infeasibility. No accepted route output is produced.",
  }
  const raw = `${JSON.stringify(result, null, 2)}\n`
  assert.ok(
    Buffer.byteLength(raw) <= limits.result,
    "Bounded scalar result required",
  )
  atomic("result.json", raw)
  console.log(
    JSON.stringify({
      diagnosticQualified: result.diagnosticQualified,
      accepted49: false,
    }),
  )
  return result.diagnosticQualified ? 0 : 2
}

if (import.meta.main) process.exitCode = await main()
