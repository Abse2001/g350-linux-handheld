"""Independent finite stdlib geometry planning; never imports application code."""
import collections, hashlib, heapq, json, math, pathlib, time

ROOT=pathlib.Path('/tmp/g350-source24-remaining-nonpair-peer-planner-next')
PROJ=pathlib.Path('/tmp/g350-source24-api-root-20261015-0345/output/projection')
PINS={
 'core':('/tmp/g350-source24-core-root-20261015-0310/output/raw-core.json','85c99a617ee1bbaeb88046e3ce37bfa420f86affb4dd897ef7db685ea72b72f0'),
 'controls':('/tmp/g350-source24-core-root-20261015-0310/output/core-controls.json','877de1281cb1e49757051e4df576f8b5806c916ee78e023aa1b7df6a6ec68c2f'),
 'native':('/tmp/g350-source24-native-root-20261015-0324/output/native24-report.json','601a7eadcf1fb773d3d457c614f61eee41f3de7969847171e817aa11487a347d'),
 'nativeReceipt':('/workspace/bus-lanes-solver/.cache/root-routing-progress/source24-native-80755-PASS-COLLECTED-root.json','0deff5c9ead7a10360e94d75e7a063a0b2a3fbbe8f03c839657f4ab195764a35'),
 'model':(str(PROJ/'GENUINE_CURRENT_CORE49_CONSTRUCTOR_INPUT.json'),'f0c49b1f37477658533607da2f52b473870f6d75d241a4556014913df429748a'),
 'inverse':(str(PROJ/'CURRENT_VIA_EVENT_AND_NPTH_INVERSE_PROOF.json'),'77041c27adf52c56a5aa246433cf9629aadb6695540199d76555e250008ea1d1'),
 'parent':(str(PROJ/'GENUINE_CORE24_FULL49_UNSEEDED_PUBLIC_INPUT.json'),'ec7d4275ff17da14f1007a740a1aa0165ee97697cb96a1418d0b81e8110ac5eb'),
}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def readpin(k):
 p,h=PINS[k];assert sha(p)==h
 return json.loads(pathlib.Path(p).read_text())
DATA={k:readpin(k) for k in PINS}
MODEL,CORE,NATIVE,CONTROL=DATA['model'],DATA['core'],DATA['native'],DATA['controls']
proof=DATA['inverse'];assert proof['constructorInputSha256']==PINS['model'][1] and proof['parentInputSha256']==PINS['parent'][1]
assert proof['actualCoreSha256']==PINS['core'][1] and proof['actualNativeReportSha256']==PINS['native'][1]
assert NATIVE['actualCoreSha256']==PINS['core'][1] and NATIVE['actualCoreControlsSha256']==PINS['controls'][1]
assert CONTROL['rawCoreSha256']==PINS['core'][1] and CONTROL['freshCoreControlPassed'] and len(CONTROL['checks'])==29
assert NATIVE['physicalErrors']==0 and NATIVE['checkCount']==18 and NATIVE['physicalCpuRamConnectedCarrierCount']==24
assert DATA['nativeReceipt']['passed'] and DATA['nativeReceipt']['reportSha256']==PINS['native'][1]
inverse=json.loads(json.dumps(MODEL))
for c in inverse['connections']:
 for p in c['pointsToConnect']:p['layers']=['top','inner1','inner2','bottom']
bytrace={t['pcb_trace_id']:t for t in inverse['traces']}
for change in proof['viaEvents98']:bytrace[change['actualPcbTraceId']]['route']=change['rawWireRoute']
obs={o['obstacleId']:o for o in inverse['obstacles']}
obs.update({o['obstacleId']:o for o in proof['removedDuplicateSignalViaObstacles98']})
obs.update({r['actualHoleId']:r['beforeObstacle'] for r in proof['npthConservativeMarginProjection']})
inverse['obstacles']=[obs[o['obstacleId']] for o in DATA['parent']['obstacles']]
assert inverse==DATA['parent'] and proof['exactFullInverseToFresh24Parent']
assert len(MODEL['connections'])==49 and len(MODEL['traces'])==263 and len(MODEL['obstacles'])==1298
assert sum(p['route_type']=='via' for t in MODEL['traces'] for p in t['route'])==98

LAYERS=['top','inner1','inner2','bottom'];WIDTH=.1016;GAP=MODEL['minTraceToPadEdgeClearance'];MARGIN=WIDTH/2+GAP
DONE={c['originalSourceTraceId'] for c in CONTROL['carriers']}
PAIRS={n for p in MODEL['differentialPairs'] for n in p['connectionNames']}
CONNECTIONS={c['name']:c for c in MODEL['connections']}
STUB_OWNER={r['actualPcbTraceId']:r['originalSourceTraceId'] for r in NATIVE['actualOwnershipProof']['signalMappings']}
BARREL_OWNER={r['actualViaId']:r['originalSourceTraceId'] for r in NATIVE['actualOwnershipProof']['signalMappings']}
STUB_LENGTH=collections.defaultdict(float)
def xy(p):return p['x'],p['y']
def plen(points):return sum(math.dist(a,b) for a,b in zip(points,points[1:]))
for row in CORE:
 if row['type']=='pcb_trace' and row['pcb_trace_id'] in STUB_OWNER:STUB_LENGTH[STUB_OWNER[row['pcb_trace_id']]]+=plen([xy(p) for p in row['route']])

def point_segment(p,a,b):
 dx,dy=b[0]-a[0],b[1]-a[1];n=dx*dx+dy*dy
 if not n:return math.dist(p,a)
 t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/n))
 return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def segdist(a,b,c,d):
 if max(min(a[0],b[0]),min(c[0],d[0]))<=min(max(a[0],b[0]),max(c[0],d[0]))+1e-12 and max(min(a[1],b[1]),min(c[1],d[1]))<=min(max(a[1],b[1]),max(c[1],d[1]))+1e-12 and cross(a,b,c)*cross(a,b,d)<=0 and cross(c,d,a)*cross(c,d,b)<=0:return 0.
 return min(point_segment(a,c,d),point_segment(b,c,d),point_segment(c,a,b),point_segment(d,a,b))
def rectdist(a,b,p):
 # Translate/rotate the segment into the exact rectangle's local coordinates.
 cx,cy,hx,hy,co,si=p
 def local(q):
  x,y=q[0]-cx,q[1]-cy
  return x*co+y*si,-x*si+y*co
 a,b=local(a),local(b)
 if any(abs(q[0])<=hx and abs(q[1])<=hy for q in(a,b)):return 0.
 corners=[(-hx,-hy),(hx,-hy),(hx,hy),(-hx,hy)]
 return min(segdist(a,b,corners[i],corners[(i+1)%4])for i in range(4))

PRIMITIVES=[]
def add(kind,geom,rad,layers,owners,identity,bbox):
 PRIMITIVES.append(dict(kind=kind,geom=geom,rad=rad,layers=layers,owners=set(owners),id=identity,bbox=bbox))
for o in MODEL['obstacles']:
 cx,cy=xy(o['center']);w,h=o['width'],o['height'];owners=o['connectedTo']
 if o.get('shape')=='circle':add('circle',(cx,cy),w/2,o['layers'],owners,o['obstacleId'],(cx-w/2,cy-w/2,cx+w/2,cy+w/2))
 else:
  theta=math.radians(o.get('ccwRotationDegrees',0));co,si=math.cos(theta),math.sin(theta);ex=abs(co)*w/2+abs(si)*h/2;ey=abs(si)*w/2+abs(co)*h/2
  add('rect',(cx,cy,w/2,h/2,co,si),0,o['layers'],owners,o['obstacleId'],(cx-ex,cy-ey,cx+ex,cy+ey))
# The projection removes 98 signal-barrel obstacle duplicates; restore their
# physical circular occupancy from the authenticated event roster, once each.
vias={r['pcb_via_id']:r for r in CORE if r['type']=='pcb_via'}
for vid,owner in BARREL_OWNER.items():
 v=vias[vid];cx,cy=v['x'],v['y'];radius=v['outer_diameter']/2
 add('circle',(cx,cy),radius,v['layers'],[owner,vid],vid,(cx-radius,cy-radius,cx+radius,cy+radius))
# Include ALL 287 actual physical traces: in particular the 24 carrier bodies
# intentionally absent from the unseeded public constructor input.
for row in CORE:
 if row['type']!='pcb_trace':continue
 owner=STUB_OWNER.get(row['pcb_trace_id'],row['source_trace_id'])
 for i,(p,q)in enumerate(zip(row['route'],row['route'][1:])):
  assert p['route_type']==q['route_type']=='wire' and p['layer']==q['layer']
  a,b=xy(p),xy(q);radius=max(p['width'],q['width'])/2
  add('segment',(a,b),radius,[p['layer']],[owner],row['pcb_trace_id']+':'+str(i),(min(a[0],b[0])-radius,min(a[1],b[1])-radius,max(a[0],b[0])+radius,max(a[1],b[1])+radius))

BUCKETS=collections.defaultdict(list);CELL=1.
for i,p in enumerate(PRIMITIVES):
 x0,y0,x1,y1=p['bbox']
 for layer in p['layers']:
  for x in range(math.floor((x0-MARGIN)/CELL),math.floor((x1+MARGIN)/CELL)+1):
   for y in range(math.floor((y0-MARGIN)/CELL),math.floor((y1+MARGIN)/CELL)+1):BUCKETS[layer,x,y].append(i)
def candidates(a,b,layer):
 ids=set()
 for x in range(math.floor(min(a[0],b[0])/CELL),math.floor(max(a[0],b[0])/CELL)+1):
  for y in range(math.floor(min(a[1],b[1])/CELL),math.floor(max(a[1],b[1])/CELL)+1):ids.update(BUCKETS.get((layer,x,y),()))
 return ids
def slack(a,b,p):
 if p['kind']=='circle':d=point_segment(p['geom'],a,b)
 elif p['kind']=='segment':d=segdist(a,b,*p['geom'])
 else:d=rectdist(a,b,p['geom'])
 return d-p['rad']-MARGIN
def clear(a,b,layer,name,epsilon=1e-8):
 for i in candidates(a,b,layer):
  p=PRIMITIVES[i]
  if name not in p['owners'] and slack(a,b,p)<epsilon:return False
 return True
def proof_route(points,layer,name):
 rows=[]
 for a,b in zip(points,points[1:]):
  # Audit every foreign primitive on this layer, independent of the search index.
  nearest=min((slack(a,b,p),p['id'])for p in PRIMITIVES if layer in p['layers']and name not in p['owners'])
  rows.append(dict(a=a,b=b,minimumSlackMm=nearest[0],limitingPrimitive=nearest[1]))
 return rows
def simplify(points):
 result=[]
 for p in points:
  if result and math.dist(result[-1],p)<1e-10:continue
  if len(result)>1 and abs(cross(result[-2],result[-1],p))<1e-10 and (result[-1][0]-result[-2][0])*(p[0]-result[-1][0])+(result[-1][1]-result[-2][1])*(p[1]-result[-1][1])>=0:result[-1]=p
  else:result.append(p)
 return result

def search(name,layer,step=.1,cap=120000):
 ends=CONNECTIONS[name]['pointsToConnect'];start,goal=map(xy,ends)
 def node(p):return round(p[0]/step),round(p[1]/step)
 def point(n):return n[0]*step,n[1]*step
 a,z=node(start),node(goal);assert math.dist(start,point(a))<1e-8 and math.dist(goal,point(z))<1e-8
 if not clear(start,start,layer,name)or not clear(goal,goal,layer,name):return dict(termination='ENDPOINT_BLOCKED',expanded=0)
 def heuristic(n):
  dx,dy=abs(n[0]-z[0]),abs(n[1]-z[1]);return step*(max(dx,dy)+(math.sqrt(2)-1)*min(dx,dy))
 heap=[(heuristic(a),0,a)];cost={a:0.};parent={};edge_cache={};expanded=0;beg=time.monotonic()
 while heap and expanded<cap:
  _,g,n=heapq.heappop(heap)
  if g!=cost.get(n):continue
  if n==z:
   path=[goal];q=n
   while q!=a:q=parent[q];path.append(point(q))
   path[-1]=start;path.reverse();path=simplify(path)
   return dict(termination='FOUND',expanded=expanded,seconds=time.monotonic()-beg,layer=layer,points=path,carrierLengthMm=plen(path),wholePlanarLengthMm=plen(path)+STUB_LENGTH[name])
  expanded+=1
  for dx,dy in((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
   nxt=n[0]+dx,n[1]+dy
   if not(-120<=nxt[0]<=120 and 10<=nxt[1]<=200):continue
   ng=g+step*(math.sqrt(2)if dx and dy else 1)
   if ng>=cost.get(nxt,math.inf)-1e-12:continue
   key=tuple(sorted((n,nxt)))
   valid=edge_cache.get(key)
   if valid is None:valid=clear(point(n),point(nxt),layer,name);edge_cache[key]=valid
   if not valid:continue
   cost[nxt]=ng;parent[nxt]=n;heapq.heappush(heap,(ng+heuristic(nxt),ng,nxt))
 return dict(termination='CELL_CAP'if heap else'EXHAUSTED_LOCAL_GRID',expanded=expanded,seconds=time.monotonic()-beg)

def save(name,v):
 p=ROOT/name
 with p.open('x')as f:json.dump(v,f,indent=2);f.write('\n')
 p.chmod(0o600)

if __name__=='__main__':
 ranking=[]
 for name in ['source_trace_3','source_trace_17','source_trace_30','source_trace_32','source_trace_42','source_trace_43']:
  assert name not in DONE and name not in PAIRS and name!='source_trace_10'
  for layer in ['bottom','inner2','inner1','top']:
   row=dict(name=name,stubLengthMm=STUB_LENGTH[name],**search(name,layer))
   if row['termination']=='FOUND':row['wholeTargetRangeMm']=[12.560455230226653,13.2]
   ranking.append(row);print(json.dumps({k:v for k,v in row.items()if k!='points'}),flush=True)
 save('INITIAL_SHORTEST_RANKING.json',dict(scope='OWN_STDLIB_SCALAR_LOCAL_GRID_CANDIDATES_NOT_SDK',pins=PINS,independentFullInversePassed=True,existing24CarrierCopperIncluded=True,ranking=ranking,prospectiveResetExcluded=True,all49Accepted=False,fabricationReady=False))
