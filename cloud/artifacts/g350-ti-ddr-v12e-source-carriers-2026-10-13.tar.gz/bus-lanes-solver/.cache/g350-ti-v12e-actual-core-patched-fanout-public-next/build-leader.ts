import fs from "node:fs"
import assert from "node:assert/strict"
const argv = JSON.parse(fs.readFileSync(process.argv[2]!, "utf8")) as string[]
function identity(pid: number) {
  let raw: string
  try { raw = fs.readFileSync(`/proc/${pid}/stat`, "utf8") }
  catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT" || (error as NodeJS.ErrnoException).code === "ESRCH") return null; throw error }
  const tail = raw.slice(raw.lastIndexOf(")") + 2).split(" ")
  return { pid, group: Number(tail[2]), session: Number(tail[3]), start: tail[19] }
}
const own = identity(process.pid)!
assert.equal(own.group, process.pid)
assert.equal(own.session, process.pid)
const child = Bun.spawn(argv, { stdout: "inherit", stderr: "inherit" })
const exitCode = await child.exited
// Keep this reserved leader alive while the unchanged subreaper reaps only
// descendants in our original session/group. Never signal or wait foreign PIDs.
const deadline = performance.now() + 5000
let polls = 0
for (;;) {
  assert.deepEqual(identity(process.pid), own)
  const members = fs.readdirSync("/proc").filter(name => /^[0-9]+$/.test(name))
    .map(name => identity(Number(name))).filter(row => row !== null && row.pid !== own.pid && row.group === own.group && row.session === own.session)
  if (members.length === 0) break
  if (performance.now() >= deadline) throw Error("Build owned-session descendants did not drain within 5000ms")
  polls++
  await Bun.sleep(25)
}
console.log(JSON.stringify({ buildLeaderOwnedDescendantsDrained: true, childExitCode: exitCode, cleanupPolls: polls, cleanupBoundMs: 5000, signalsSent: 0 }))
process.exitCode = exitCode
