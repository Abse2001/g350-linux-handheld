import { strict as assert } from "node:assert"
import { readFileSync } from "node:fs"
import { test } from "bun:test"
import { referenceOwners } from "./partial-native"
import { checkRealComponentEndpointNegative } from "./real-endpoint-control"
import type { SimpleRouteJson } from "./source/lib/types"
const load = (name: string) =>
  JSON.parse(readFileSync(`${import.meta.dir}/${name}`, "utf8"))
test("reference registration preserves allcontacts but marks only genuine cap pins as checker terminals", () => {
  const native = load("native-input.json"),
    registry = load("physical-reference-registry.json"),
    before = JSON.stringify({ native, registry }),
    owners = referenceOwners(native, registry)
  assert.ok(JSON.stringify({ native, registry }) === before)
  assert.ok(
    owners.every(
      (owner: any) =>
        owner.providedCopperOwnerOnly &&
        owner.pointsToConnect.length === 1 &&
        owner.sourceContacts.length === 2 &&
        owner.viaAliasContacts.length === 1,
    ),
  )
  assert.ok(
    owners[0].pointsToConnect[0].pcb_port_id === "pcb_port_727" &&
      owners[1].pointsToConnect[0].pcb_port_id === "pcb_port_728",
  )
  assert.ok(
    owners[0].viaAliasContacts[0].pcb_port_id === "pcb_port_1162" &&
      owners[1].viaAliasContacts[0].pcb_port_id === "pcb_port_1164",
  )
  const invalid = structuredClone(registry)
  invalid.pcbPorts[0].pcb_component_id = "pcb_component_280"
  assert.throws(() => referenceOwners(native, invalid), /Actual capacitor/)
})
test("planned real-component negative goes to unchanged DRC seam with complete hardware; no mock success can bypass rejection", () => {
  const native: SimpleRouteJson = load("native-input.json"),
    positive = {
      additionalPhysicalReferenceOwners: referenceOwners(
        native,
        load("physical-reference-registry.json"),
      ),
      joinedNativePaths: [],
      retainedUnfinishedApproaches: load("all-owned-approaches.json"),
    },
    before = JSON.stringify({ native, positive })
  let params: any
  const api: any = {
    validateRoutedCopperDrc(value: any) {
      params = value
      return {
        valid: false,
        issues: [
          {
            code: "via-at-endpoint",
            traceId: "pcb_trace_0",
            connectionName: "source_trace_932",
          },
        ],
      }
    },
  }
  const result = checkRealComponentEndpointNegative(native, positive, api)
  assert.ok(result.realComponentEndpointRulePreserved)
  assert.equal(params.inputSrj.obstacles.length, 856)
  assert.equal(params.inputSrj.connections.length, 51)
  assert.equal(params.routedSrj.traces.length, 26)
  const trace = params.routedSrj.traces[0],
    point = params.inputSrj.connections[49].pointsToConnect[0]
  assert.ok(trace.route[1].x === point.x && trace.route[1].y === point.y)
  assert.ok(JSON.stringify({ native, positive }) === before)
  api.validateRoutedCopperDrc = () => ({ valid: true, issues: [] })
  assert.throws(
    () => checkRealComponentEndpointNegative(native, positive, api),
    /must reject/,
  )
})
