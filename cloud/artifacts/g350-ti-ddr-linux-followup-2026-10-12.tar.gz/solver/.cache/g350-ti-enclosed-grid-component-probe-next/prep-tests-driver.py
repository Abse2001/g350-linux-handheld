"""Bounded preparation-only tests; never call original source APIs."""
from pathlib import Path
import subprocess,json,hashlib,time,resource
ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/bus-lanes-solver')
BUN='/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
BIO=str((REPO/'node_modules/.bin/biome').resolve())
NAMES=['grid-probe.ts','grid-probe.test.ts','runner.ts']
logs=ROOT/'prep-validation'
for name in NAMES:
 path=ROOT/name;r=subprocess.run([BIO,'format','--stdin-file-path','lib/'+name],input=path.read_bytes(),capture_output=True,timeout=5);assert r.returncode==0;path.write_bytes(r.stdout)
checks=[('grid-probe-mocks',[BUN,'test',str(ROOT/'grid-probe.test.ts')],5),('grid-probe-guard',['python3',str(ROOT/'guard.test.py')],5),('grid-probe-types',[str(REPO/'node_modules/.bin/tsc'),'--noEmit','--strict','--skipLibCheck','--target','ESNext','--module','ESNext','--moduleResolution','Bundler','--esModuleInterop','--resolveJsonModule','--types','bun',*[str(ROOT/name) for name in NAMES]],25)]
records=[]
for name,cmd,bound in checks:
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=bound);out=logs/(name+'.log');out.write_bytes(r.stdout+r.stderr);row={'name':name,'command':cmd,'actualExitCode':r.returncode,'seconds':time.monotonic()-start,'timeoutSeconds':bound,'log':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()};records.append(row);print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
(logs/'grid-probe-checks.json').write_text(json.dumps(records,indent=2)+'\n')
rows=[]
for name in NAMES:
 raw=(ROOT/name).read_bytes();r=subprocess.run([BIO,'format','--stdin-file-path','lib/'+name],input=raw,capture_output=True,timeout=5);assert r.returncode==0 and r.stdout==raw;rows.append({'file':name,'sha256':hashlib.sha256(raw).hexdigest(),'actualExitCode':0,'unchanged':True})
(logs/'grid-probe-format.json').write_text(json.dumps(rows,indent=2)+'\n')
