"""Root-only bounded pinned CLI after actual smooth Native0/API0."""
import fcntl,importlib.util,json,secrets,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
s=importlib.util.spec_from_file_location('strict18_capture_stdlib_cli',ROOT/'run-strict18-source-capture-root.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
PACKET=c.BOARD/'.cloud-tools/ddr-strict18-smooth-fresh-json-cli-zone-aware-successor-next'
SOURCE_SHA='c17242bf82c924041569a8b0aa52a1f7ce9e38598c4e92c4ab54284752a1b84c'
OUT=PACKET/'run-cli'
def main():
 assert len(sys.argv)==5
 receipt=Path(sys.argv[1]);assert c.sha(receipt)==sys.argv[2]
 nc,np,ne=c.guard.collected({'path':str(receipt),'sha256':sys.argv[2]})
 assert nc['toolSessionId']==44382 and nc['toolExitCode']==nc['toolWrapperExitCode']==0 and nc['passed'] is True
 assert nc['sourceManifestSha256']=='3f43f30bfa47c4d1e0696c20f9411f8bd2a1f56119b04fa18f0336d16cea12aa' and np['nativeCalls']==np['original3PairApiCalls']==1
 nr=c.read(np['resultPath']);assert nr['passed'] is True and [(r['phase'],r['exitCode'])for r in nr['commands']]==[('native',0),('original3pairAPI',0)] and nr['actualCoreSha256']=='371744f3b7ca4ce52e251ec91baacb850768a04e734aef396676439cd0637c54'
 peer_path=Path(sys.argv[3]);assert c.sha(peer_path)==sys.argv[4]
 peer=c.read(peer_path);assert peer['sourceManifestSha256']==SOURCE_SHA and peer['decision'].startswith('GO_')
 assert c.sha(PACKET/'SOURCE-manifest.json')==SOURCE_SHA
 m=c.read(PACKET/'SOURCE-manifest.json')
 def bindings():
  assert c.sha(PACKET/'SOURCE-manifest.json')==SOURCE_SHA
  for row in m['files']+m['externalFiles']:c.guard.source_guard.binding(row)
  for manifest in [c.BOARD/'.cloud-tools/ddr-strict18-smooth-manual-source-core-successor-next/SOURCE-manifest.json',c.BOARD/'.cloud-tools/ddr-strict18-smooth-manual-source-core-successor-next/CORE-manifest.json']:
   cm=c.read(manifest)
   for row in cm['files']+cm['externalFiles']:c.guard.source_guard.binding(row)
  for name in ('node_modules','.pnp.cjs','.pnp.loader.mjs','.yarn'):
   p=PACKET/name;assert not p.exists() and not p.is_symlink()
 bindings();_,ssha=c.bindings();_,oldsha,before,sbefore,_=c.guard.checked()
 prior=c.read(c.BOARD/'.cloud-tools/ddr-strict18-smooth-fresh-native-api-sourceonly-next/run-native/ROOT_AUTHORITY.json')['actualPriorCollectedRows']+[{'path':str(receipt),'sha256':sys.argv[2]}]
 def closed():
  for row in prior:assert c.guard.process_scope.owned(c.guard.collected(row)[2]['pgid'])==[]
 closed();assert not OUT.exists() and not OUT.is_symlink();OUT.mkdir();exports=OUT/'exports';exports.mkdir()
 authority=c.read(PACKET/'AUTHORITY_TEMPLATE_NO_AUTHORIZATION.json');authority.update(authorizedByRoot=True,sourceManifestSha256=SOURCE_SHA,actualPreviousScopesCollectedAndEmpty=True,noConcurrentRootWorker=True,rootFullWorkerReadPassed=True,finiteIndependentSourcePeer={'path':str(peer_path),'sha256':sys.argv[4]},outputDirectory=str(exports),actualNativeCollection={'path':str(receipt),'sha256':sys.argv[2]},actualNativeReport={'path':nr['actualNativeReportPath'],'sha256':nr['actualNativeReportSha256']},actualPriorCollectedRows=prior,approvalToken=secrets.token_hex(32))
 ap=OUT/'ROOT_AUTHORITY.json'
 with ap.open('x')as f:json.dump(authority,f,indent=2);f.write('\n')
 ap.chmod(0o600);ah=c.sha(ap)
 policy={'wallSeconds':90,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
 def prefork(mem):
  closed();assert mem['current']+policy['rssBytes']+1073741824<policy['sharedBytes']
 execution=None;error=None
 with (ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  try:execution=c.guard.process_scope.run_guarded([sys.executable,'-B',str(PACKET/'export_fresh_json.py'),'--root-receipt',str(ap),'--root-receipt-sha256',ah,'--output-directory',str(exports)],str(c.BOARD),OUT/'owned',policy,{'G350_STRICT18_FRESH_JSON_CLI_ROOT_GUARDED':'1'},before_spawn=prefork)
  except BaseException as ex:
   error=type(ex).__name__+': '+str(ex)
   if (OUT/'owned/execution.json').is_file():execution=c.read(OUT/'owned/execution.json')
  after=None;safter=None;held=False;post_error=None
  try:
   _,nsha,after,safter,_=c.guard.checked();_,asource=c.bindings();closed();bindings()
   held=oldsha==nsha and ssha==asource and before==after and sbefore==safter and c.sha(receipt)==sys.argv[2] and c.sha(ap)==ah
  except BaseException as ex:post_error=type(ex).__name__+': '+str(ex)
  rp=exports/'cli-export-report.json';report=c.read(rp)if rp.is_file()else None
  passed=held and error is None and post_error is None and execution is not None and execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values()) and report is not None and report['exportPassed'] and report['actualSourceSegmentCount']==1058 and report['nativeApiCombinedStagePassed'] is True and report['apiAnglesFailed'] is False
  files=[{'path':str(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':c.sha(p)}for p in sorted([*OUT.iterdir(),*exports.iterdir()])if p.is_file()and not p.is_symlink()]
  post={'scope':m['scope'],'sourceManifestSha256':SOURCE_SHA,'execution':execution,'sourceAndDependenciesHeld':held,'dependenciesBefore':before,'dependenciesAfter':after,'solverDependenciesBefore':sbefore,'solverDependenciesAfter':safter,'runFailure':error,'postverificationFailure':post_error,'outputFiles':files,'resultPath':str(rp),'resultSha256':c.sha(rp)if report else None,'passed':bool(passed),'cliCalls':1 if report else 0,'coreCalls':0,'nativeCalls':0,'cadCalls':0,'expectedMissingOriginalSignalCount':31,'apiAnglesFailed':False,'actualOriginalApiAngleFailures':[],'nativeApiCombinedStagePassed':True,'complete18Accepted':False,'referenceQualified':False,'electricalTimingQualified':False,'accepted49':False,'fabricationReady':False}
  with (OUT/'POSTAUDIT.json').open('x')as f:json.dump(post,f,indent=2);f.write('\n')
  print(json.dumps({k:post[k]for k in ('passed','sourceAndDependenciesHeld','runFailure','postverificationFailure','execution')}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
