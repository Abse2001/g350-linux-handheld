"""Own stdlib independent legacy/new guidance classification; no SDK."""
exec(open('/tmp/g350-actual318-four-body20-23-25-36-independent-pure-peer-sourceonly.py').read().rsplit('\nreport=',1)[0])
legacy20=[];new20=[];n='source_trace_20';changed=newedges(n)
for a in mats(after[n]):
 if a['kind']!='wire':continue
 for o in foreignwire:
  if o['owner']==n or not(set(a['layers'])&set(o['layers'])):continue
  need=.3048 if classes[n]==classes[o['owner']]else .4064;d=sd(a['a'],a['b'],o['a'],o['b'])
  if d<need-1e-8:
   row={'candidateSegment':a['index'],'foreignOwner':o['owner'],'foreignSegment':o.get('index'),'distanceMm':d,'requiredMm':need,'candidateEdgeNew':a['index']in changed}
   (new20 if row['candidateEdgeNew']else legacy20).append(row)
assert not new20 and len(legacy20)==pr['whole20GuidanceClassification']['retainedOldEdgeFailureCount']
legacy36=[];new36=[];n='source_trace_36'
for run in split(after[n]):
 s=self_math([q for i,q in run],.3048)
 for z in s['failures']:
  a,b=z['segments'];inds=[run[k][0]for k in[a,a+1,b,b+1]];held=all(strict(after[n]['route'][k],before[n]['route'][k])for k in inds);row={'segments':z['segments'],'wholeRouteIndices':inds,'distanceMm':z.get('distance'),'allFourEndpointObjectsHeldLiteral':held}
  (legacy36 if held else new36).append(row)
assert not new36 and len(legacy36)==len(pr['source36InheritedPreferredSelfFailuresClassified'])
R={'scope':'INDEPENDENT_STDLIB_CURRENT318_FOUR_BODY_PROOF_LEGACY_GUIDANCE_CLASSIFICATION_NOT_FULLTI','proofPath':PR,'proofSha256':PS,'purePeerPath':'/tmp/g350-actual318-four-body20-23-25-36-independent-pure-peer-report.json','purePeerSha256':'d255b5356e5878c4d7910b5866ace80658c15c5a5e3f68bfe3835f38e8d857b6','source20WholeGuidanceRetainedCount':len(legacy20),'source20IntroducedNewEdgeFailures':new20,'source20RetainedGuidanceRows':legacy20,'source36RetainedThreeWidthSelfFailureCount':len(legacy36),'source36IntroducedThreeWidthSelfFailures':new36,'source36RetainedSelfFailureRows':legacy36,'fullBoardTIQualification':False,'SDKExecuted':False,'sourceCoreDerived':False,'fabricationReady':False,'independentLegacyNewClassificationPassed':True}
out=Path('/tmp/g350-actual318-four-body20-23-25-36-independent-legacy-classification-peer-report.json');out.open('x').write(json.dumps(R,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'retained20Guidance':len(legacy20),'new20Guidance':len(new20),'retained36StrongSelf':len(legacy36),'introduced36StrongSelf':len(new36)}))
