"""One bounded pure successor parity proof over completed Core/native records."""
import argparse,hashlib,importlib.util,json,re,stat,sys
from pathlib import Path
import process_scope
ROOT=Path(__file__).resolve().parent
CORE=Path('/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-ram7-reference-right-actual-source-control-next')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def require(v,s):
 if not v:raise ValueError(s)
def checked():
 m=load(ROOT/'CONTROL-manifest.json')
 for key,base in [('files',ROOT),('externalFiles',None)]:
  for row in m[key]:
   p=base/row['path'] if base else Path(row['path'])
   require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Exact frozen member changed: '+str(p))
 packet=load(CORE/'CONTROL-manifest.json');packet_sha=sha(CORE/'CONTROL-manifest.json')
 require(packet_sha==m['originalCoreControlSha256'],'Original failed Core control packet changed')
 # Pure Python uses only the already closed actual JSON/data records; it does
 # not import Core/native/installed JS dependencies. Bind all original source
 # and direct tool/dependency pins without another 16975-file installed-tree
 # audit. The complete dependency inventory remains the prior actual record.
 for key,base in [('files',CORE),('externalBindings',None)]:
  for row in packet[key]:
   path=base/row['path'] if base else Path(row['path'])
   require(path.is_file() and not path.is_symlink() and path.stat().st_size==row['bytes'] and sha(path)==row['sha256'] and stat.S_IMODE(path.stat().st_mode)==row['mode'],'Original source/direct pin changed: '+str(path))
 prior=load(CORE/'run/postflight.json');result=load(CORE/'run/result.json');execution=prior['execution'];native=load(CORE/'run/native-physical.json')
 require(prior['packetSha256Before']==prior['packetSha256After']==packet_sha and prior['boardDependenciesBefore']==prior['boardDependenciesAfter'] and prior['actualSourceAndInputTrustEligible'] is False,'Original strict last-step failure and held sources/deps required')
 require(execution['exitCode']==1 and execution['diagnosticStopped'] is False and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values()),'Original actual Core/native run must be cleanly closed, without diagnostic stop/OOM')
 require(result['sourceBuildCount']==1 and result['actualSourceAndInputQualified'] is False and [(c['name'],c['exitCode']) for c in result['commands']]==[('actual-source-build',0),('actual-core-projection',0),('actual-native-placement',0),('actual-forward-proof',1)] and result['originalFailure']=='Actual source-forward stage failed: actual-forward-proof','Exact completed three stages and strict proof failure required')
 require(native['physicalErrors']==0 and native['checkCount']==17 and len(native['counts'])==17 and all(v==0 for v in native['counts'].values()),'All17 original actual native placement/reference checks must remain zero')
 require(native['sourceSha256']==m['actualCircuitSha256']==sha(CORE/'run/fresh-layout.circuit.json') and native['checkerSha256']=='1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc','Actual source and reviewed native patch must remain exact')
 require(not (CORE/'run/validated-input').exists(),'Original failed comparison must not have published validated input')
 return m,sha(ROOT/'CONTROL-manifest.json'),prior['boardDependenciesAfter']

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--preflight',action='store_true');parser.add_argument('--launch-receipt',type=Path);parser.add_argument('--receipt-sha256');args=parser.parse_args()
 require(args.preflight!=bool(args.launch_receipt),'Select pure preflight or exact Root launch receipt')
 m,manifest_sha,before=checked()
 if args.preflight:print(json.dumps({'preflightOnly':True,'packetSha256':manifest_sha,'priorActualNativeChecks':17,'priorActualNativeErrors':0,'newCoreOrNativeCalls':0}));return 0
 require(re.fullmatch('[0-9a-f]{64}',args.receipt_sha256 or '') and sha(args.launch_receipt)==args.receipt_sha256,'Exact Root launch receipt hash required')
 authority=load(args.launch_receipt)
 require(authority.get('authorizedByRoot') is True and authority.get('scope')==m['authorityScope'] and authority.get('packetSha256')==manifest_sha and authority.get('policy')==m['policy'] and re.fullmatch('[0-9a-f]{32,128}',authority.get('approvalToken','')),'Exact Root pure successor scope/packet/policy required')
 require(not (ROOT/'run').exists(),'One fresh exclusive pure successor only')
 output=ROOT/'run/validated-input'
 def before_spawn(memory):require(memory['current']+m['policy']['rssBytes']+m['preforkReserveBytes']<m['policy']['sharedBytes'],'Strict original prefork reserve required')
 execution=process_scope.run_guarded([sys.executable,'-B',str(ROOT/'verify_actual_core.py'),'--actual-circuit',str(CORE/'run/fresh-layout.circuit.json'),'--actual-circuit-sha256',m['actualCircuitSha256'],'--actual-ddr-input',str(CORE/'output/ddr-input.json'),'--output',str(output)],str(ROOT),ROOT/'run',m['policy'],{},before_spawn=before_spawn)
 after_m,after_sha,after=checked();proof_path=output/'actual-source-validation.json';proof=load(proof_path) if proof_path.is_file() else None
 passed=(execution['exitCode']==0 and execution['diagnosticStopped'] is False and execution.get('cleanupOwnedGroupEmpty') is True and not any(execution['oomDelta'].values()) and before==after and manifest_sha==after_sha and proof is not None)
 if passed:
  passed=(proof['actualCircuitSha256']==m['actualCircuitSha256'] and proof['emittedValidatedInputsUseActualRawCoreGeometry'] is True and proof['validatedInputRawBytesCopiedWithoutReserialization'] is True and len(proof['changedPhysicalRows'])==30 and len(proof['derivedCopperPourCutoutRows'])==2 and len(proof['preservedAssetUrlResolutionChanges'])==2 and proof['allExistingAssetBytesAndResolvedFilesExactlyHeld'] is True and proof['onlyExistingOwnedForeignViaAntipadRingsMovedRigidly'] is True and proof['allOtherPhysicalAndLogicalSourceFieldsExactlyHeldWithinOriginalTolerance'] is True and proof['allOriginal280Parts1161Contacts217LogicalConnectionsHeld'] is True and proof['all49OriginalCpuRamNumericContactIdsHeld'] is True and proof['accepted49'] is False and proof['fabricationReady'] is False and (output/'input.json').read_bytes()==(CORE/'output/ddr-input.json').read_bytes())
 report={'scope':m['authorityScope'],'passed':passed,'sourceManifestSha256':manifest_sha,'execution':execution,'sourceHeld':manifest_sha==after_sha,'priorActualCompleteBoardDependencyInventoryBefore':before,'priorActualCompleteBoardDependencyInventoryAfter':after,'newFullInstalledDependencyTreeAuditPerformed':False,'originalSourceAndDirectDependencyPinsRechecked':True,'originalActualCoreControlPreserved':True,'originalActualCoreStrictParityExit':1,'priorActualNativeCheckCount':17,'priorActualNativeErrors':0,'actualSourceAndInputCombinedTrustEligible':passed,'sourceProofSha256':sha(proof_path) if proof_path.is_file() else None,'inputSha256':sha(output/'input.json') if (output/'input.json').is_file() else None,'newCoreOrNativeOrRouterApiCalls':0,'referenceQualified':False,'TIplaneArrangement':False,'accepted49':False,'fabricationReady':False}
 with (ROOT/'run/RECEIPT.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
 print(json.dumps({'passed':passed,'actualSourceAndInputCombinedTrustEligible':passed,'inputSha256':report['inputSha256'],'newCoreOrNativeOrRouterApiCalls':0}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
