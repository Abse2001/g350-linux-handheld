#!/usr/bin/env python3
"""Persist closed233..238 public evidence using own stdlib only; no SDK.

Writes only the new post232 saved directory. Frozen Source209/228 archives and
saved workspaces are dependencies, never copied, rewritten, or promoted.
"""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat

ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post232-2026-10-16'
BASE228 = ROOT / '.cloud-tools/ddr-four-layer-post209-2026-10-16'
BASE209 = ROOT / '.cloud-tools/ddr-four-layer-manual-2026-10-16'
BASE228_PINS = {
    'WORKSPACE_HASH_INDEX.json': '809a4437af0306c37aa759044131fbaa9939032244284705c31a3910d339a83d',
    'WORKSPACE_RESTORE_MANIFEST.json': 'd8a8ebdc11a3900affe120fdd70c946403c4e26bf9b7b02bd9a1088a98369cef',
    'PROGRESS.json': 'fac4424b0ca0fe1b74fc640687a0567b7b3264267a65da5acfff5eb9091b5ef0',
}
ARCHIVES = [
    {'manifest': 'cloud/artifacts/g350-four-layer-partial46-source209-2026-10-16.manifest.json',
     'manifestSha256': '09b834bb43d98f55d98e9c87652d28c74ae9230b2c10bfb2f0a1d97d83f96832',
     'sha256': 'c4cfe7d590a67368586ef49a6178dbc6b6519576a654a690d8f5ef91be0b9178'},
    {'manifest': 'cloud/artifacts/g350-four-layer-partial47-source228-2026-10-16.manifest.json',
     'manifestSha256': 'cfeff46232c9afdbab49186f3e115c725862fb5a5695f3955ffb9e8dcfc5026e',
     'sha256': '4fff876a140edbd45cffdc445bd82d7b45a5abcedc630b8ea5633a4d1d9937f1'},
]
RUNS = {
    233: ('CA_MERGE233_TIMING_IMPROVED47', '/tmp/g350-ca-merge47-root-20261016-run233'),
    234: ('PROJECTOR234_MERGED47', '/tmp/g350-ca-merged47-projector-root-20261016-run234'),
    235: ('CAPTURE235_MERGED47', '/tmp/g350-ca-merged47-capture-root-20261016-run235'),
    236: ('CORE236_MERGED47', '/tmp/g350-ca-merged47-core-root-20261016-run236'),
    237: ('NATIVE237_MERGED47', '/tmp/g350-ca-merged47-native-root-20261016-run237'),
    238: ('AUTH238_MERGED47', '/tmp/g350-ca-merged47-via-track-root-20261016-run238'),
}
PINS = {
    '/tmp/g350-ti-current233-source236-assessment.md': '206f1b85f5dc9e2e093f0cbc90bf1aa42cec73dac282a73cc80f817d2b497aa3',
    '/tmp/g350-ti-current233-source236-geometry-controls.json': '6395aa03105ce2d56824d9c1a62e2505cf9bcbf0abf14633a4167531cb98bd80',
    '/tmp/g350-ti-current233-source236-pure-screen.json': 'c32aaa631fa59be73ce2fc88ef5608077ce23f490e49092583f9cb4c19e4f811',
    '/tmp/g350-ti-current233-source236-pure-screen.py': '20b222fed66bb6493e798b4c200a36f25b52678ec2760ded27afd4ab1aa8b5b2',
    '/tmp/g350-ti-current233-source236-reference-controls.json': 'cb53be9a3f7eb31dddcfd56b94f3b5cac8c702f39f164dc2853398eda55aaec1',
    '/tmp/g350-ti-current233-source236-reference-crossing-witness.json': '573719b9af0ca2e81cbe7698505ee02923485df6190384d4c1c549c1280b1a86',
    '/tmp/g350-ti-current233-source236-reference-crossing-witness.py': 'c5c6f2ecf230ca25929bc9df2468cedcf598e485a241a22c3550c2b762d700f3',
    '/tmp/g350-ca-merge47-root-20261016-run233/byte0-result.candidate.json': '71bbec7babdeabda657ba1b2be75d35f5d7210d5a53d55cd2fc2b279ffb0d17b',
    '/tmp/g350-ca-merge47-root-20261016-run233/byte0-result.json': '219dd3820c753901f8a6accbc63b0076d1109566ba5b89c2fcd937e792d15332',
    '/tmp/g350-ca-merged47-projector-root-20261016-run234/byte0-result.json': '0e3757ae6e367158090a2f14dbaf20f9f57422576d89ee2ca1acfa6c77ef1707',
    '/tmp/g350-ca-merged47-core-root-20261016-run236/byte0-result.json': 'b618de34ab2c681f53f9422cd06916471db95fda97772e16754a814541546563',
    '/tmp/g350-ca-merged47-core236-raw.json': 'd49c3d6f8661527cf007d3676d6cdae7f9fcec99535373997c6adda8705dc18d',
    '/tmp/g350-ca-merged47-native-root-20261016-run237/byte0-result.json': 'f91df8e8342ecbe591ab48f17f533dc83118090292734e343e0bf22d1fe7f2a5',
    '/tmp/g350-ca-merged47-via-track-root-20261016-run238/byte0-result.json': '05ef57bc48db7d5cb2bcc012fa584143d037fdecbf1f6fb55d89be57da0f9997',
    '/tmp/g350-current223-ca204-merge-pure-screen.json': '264d62a858d2db2636f773a1f42b67a97a01042cc67cdd5978e9a04efb86fccb',
    '/tmp/g350-current223-ca204-maximal_clear-planning.json': 'ad252b05aa6a5fc47a208028b34e3194e6144566fcbb9334295622cae123a833',
    '/tmp/g350-current223-ca204-merge-all47-preflight-v2-sourceonly.ts': '2cb695a7e5e030acbcbaa96e2ef0ef58267ed73972cece4cc4e09681dd2f07c9',
    '/tmp/g350-partial47-plan234-focused-native-checks-sourceonly.ts': '7bbad1c8622a25f1b6b3aca07bc982d1367a787c8784e27c652ce2e82527190c',
    '/tmp/g350-partial47-plan234-manual-via-track-manufacturing-sourceonly.ts': 'dfcf0acec57982e71d2f85bc9df04b9adb7e80c769386200347423be2dbdc0f8',
}


def require(value, message):
    if not value:
        raise ValueError(message)


def drop(fd):
    if hasattr(os, 'posix_fadvise'):
        os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
        drop(stream.fileno())
    return h.hexdigest()


def read(p):
    with p.open('rb') as stream:
        value = json.load(stream)
        drop(stream.fileno())
    return value


def regular(p):
    return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)


def safe_public(p):
    text = str(p)
    denied = ('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT', 'AUTHORITY_PACKET')
    return text.startswith('/tmp/g350-') and p.is_absolute() and p.resolve().is_relative_to('/tmp') and not any(x in text.upper() for x in denied)


def write_json(p, value):
    with p.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def verify_frozen228():
    for name, pin in BASE228_PINS.items():
        require(digest(BASE228 / name) == pin, 'Frozen post209 metadata changed: ' + name)
    for row in read(BASE228 / 'WORKSPACE_HASH_INDEX.json')['files']:
        p = BASE228 / row['path']
        require(regular(p) and p.stat().st_size == row['bytes'] and digest(p) == row['sha256']
                and stat.S_IMODE(p.stat().st_mode) == row['mode'], 'Frozen post209 payload changed: ' + row['path'])


def main():
    verify_frozen228()
    require(not (SAVED / 'WORKSPACE_RESTORE_MANIFEST.json').exists(), 'Use a separate append collector for closed later scopes')
    SAVED.mkdir(parents=True, exist_ok=True)
    for name, pin in PINS.items():
        require(regular(Path(name)) and digest(Path(name)) == pin, 'Pinned closed input changed: ' + name)
    dependencies, base_targets = [], {}
    for saved in (BASE209, BASE228):
        for row in read(saved / 'WORKSPACE_RESTORE_MANIFEST.json')['files']:
            base_targets[row['restorePath']] = {'baseSavedDirectory': saved.relative_to(ROOT).as_posix(), **row}
    for entry in ARCHIVES:
        manifest_path = ROOT / entry['manifest']
        require(digest(manifest_path) == entry['manifestSha256'], 'Frozen base archive manifest changed')
        manifest = read(manifest_path)
        require(manifest['archive']['sha256'] == entry['sha256'], 'Exact base archive dependency required')
        require((ROOT / manifest['archive']['path']).stat().st_size == manifest['archive']['bytes'], 'Base archive byte count')
        dependencies.append({**copy.deepcopy(manifest['archive']), 'manifest': entry['manifest'],
                             'manifestSha256': entry['manifestSha256'], 'mustBeRestoredFirst': True,
                             'payloadCopiedByThisCollector': False, 'priorDependencies': copy.deepcopy(manifest.get('baseArchiveDependency'))})
    targets, payloads, dependencies_used, input_pins = {}, {}, {}, {}
    alias_rows, observations, private_literals, sources = {}, [], [], set()

    def save(source, name=None, force=False):
        source = Path(source)
        require(safe_public(source) and regular(source), 'Only regular public /tmp source files: ' + str(source))
        before = source.stat()
        h, mode, size = digest(source), stat.S_IMODE(before.st_mode), before.st_size
        input_pins[str(source)] = (h, size, mode)
        if str(source) in targets:
            return targets[str(source)]
        base_row = base_targets.get(str(source))
        if not force and base_row and (base_row['sha256'], base_row['bytes'], base_row.get('mode')) == (h, size, mode):
            dependencies_used[str(source)] = copy.deepcopy(base_row)
            return {'baseDependencyOnly': True, **base_row}
        dest = SAVED / (name or source.name)
        require(dest.parent == SAVED, 'Flat safe saved file names only')
        if dest.exists() and (digest(dest) != h or stat.S_IMODE(dest.stat().st_mode) != mode):
            dest = dest.with_name(dest.stem + '__' + h[:16] + dest.suffix)
        if not dest.exists():
            with source.open('rb') as reader, dest.open('xb') as writer:
                shutil.copyfileobj(reader, writer, 1024 * 1024)
                os.fchmod(writer.fileno(), mode)
                drop(reader.fileno())
        after = source.stat()
        require((before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
                (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'Source changed while copying')
        require(digest(dest) == h and dest.stat().st_size == size and stat.S_IMODE(dest.stat().st_mode) == mode, 'Saved payload mismatch')
        row = {'savedPath': dest.name, 'restorePath': str(source), 'bytes': size, 'sha256': h, 'mode': mode}
        targets[str(source)] = row
        payloads[dest.name] = row
        return row

    for scope, (label, folder_text) in RUNS.items():
        folder = Path(folder_text)
        collection = read(folder / 'COLLECTED.json')
        require(collection.get('closedAt') and collection['scope'] == scope
                and collection.get('execution', {}).get('exitCode') == 0, 'Only successful closed public scopes233..238')
        save(folder / 'COLLECTED.json', label + '_COLLECTED.json', True)
        for p in sorted(folder.glob('byte0-result*.json')):
            save(p, label + '_' + p.name, True)
        for name in ('child.log', 'execution.json', 'memory.jsonl'):
            p = folder / 'owned' / name
            if regular(p):
                save(p, label + '_owned_' + name, True)
        command = collection['execution']['command']
        worker = Path(command[1])
        save(worker, force=True)
        sources.add(worker)
        for value in command[2:]:
            p = Path(value)
            if value.startswith('/tmp/g350-') and regular(p):
                save(p, 'INPUT_' + label + '_' + p.parent.name + '_' + p.name)
                if p.suffix in ('.py', '.ts', '.tsx', '.mjs'):
                    sources.add(p)
                for sibling in ('proof.json', 'contacts.json'):
                    q = p.parent / sibling
                    if regular(q):
                        save(q, 'INPUT_' + label + '_' + q.parent.name + '_' + q.name)
        observations.append({'scope': scope, 'label': label, 'closedAt': collection['closedAt'],
                             'exitCode': collection['execution']['exitCode'], 'terminalOutcome': read(folder / 'byte0-result.json').get('terminalOutcome'),
                             'defaultBoardPromoted': False, 'all49Accepted': False})

    explicit = [Path(p) for p in PINS] + [Path(__file__),
        Path('/tmp/g350-current223-ca204-merge-pure-screen.py'),
        Path('/tmp/g350-current223-ca204-merge-all47-preflight-sourceonly.ts'),
        Path('/tmp/g350-ca-merged47-raw236-root-input237/input.json'),
        Path('/tmp/g350-ca-merged47-raw236-root-input237/proof.json')]
    for p in explicit:
        save(p, force=True)
        if p.suffix in ('.py', '.ts', '.tsx', '.mjs'):
            sources.add(p)
    visited = set()
    for _ in range(4):
        next_sources = set()
        for source in sorted(sources - visited):
            visited.add(source)
            for literal in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]", source.read_text()):
                p = Path(literal)
                if not safe_public(p):
                    private_literals.append(str(p)); continue
                if regular(p):
                    save(p)
                    if p.suffix in ('.py', '.ts', '.tsx', '.mjs', '.sh'):
                        next_sources.add(p)
        sources |= next_sources
    manifest_path = Path('/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/SOURCE-manifest.json')
    require(digest(manifest_path) == 'b9700a9a44c9be5f661fd38c37ca9ff6c2f012983e49a750fecea3c8d75e19e0', 'Exact solver Source120 manifest')
    save(manifest_path)
    for row in read(manifest_path)['solverSourceFiles']:
        p = Path(row['path'])
        require(digest(p) == row['sha256'] and p.stat().st_size == row['bytes']
                and stat.S_IMODE(p.stat().st_mode) == row['mode'], 'Exact pinned solver Source120 bytes/modes')
        save(p)

    candidate = read(Path(RUNS[233][1]) / 'byte0-result.candidate.json')
    report233 = read(Path(RUNS[233][1]) / 'byte0-result.json')
    plan = read(Path(RUNS[234][1]) / 'byte0-result.json')
    capture = read(Path(RUNS[235][1]) / 'byte0-result.json')
    controls = read(Path(RUNS[236][1]) / 'byte0-result.json')
    native = read(Path(RUNS[237][1]) / 'byte0-result.json')
    auth = read(Path(RUNS[238][1]) / 'byte0-result.json')
    require(len(candidate['carrierTraces']) == 47 and len(candidate['heldCarrierTraces']) == 6
            and candidate['allSavedCarriersCurrentSceneQualified'] is True
            and candidate['caMinimumPassingCount'] == 13 and candidate['allDerivedMaximumBoundsSatisfied'] is True,
            'Actual233 physical47 and retained CA13/26/derived maxima proof')
    require(report233['currentScenePhysicalAndCriticalAssertionsFreshlyQualified'] is True
            and len(report233['criticalValidationViews']) == 2 and all(v['passed'] for v in report233['criticalValidationViews']), 'Actual233 fresh critical views')
    require(plan['inputBindings']['candidate']['sha256'] == PINS[str(Path(RUNS[233][1]) / 'byte0-result.candidate.json')], 'Source234 exact233 binding')
    require(capture['passed'] is True and capture['fullInverseSourceTreePassed'] is True
            and capture['parentNormalizationInversePassed'] is True, 'Actual235 full Source inverse/capture')
    require(controls['planSha256'] == PINS[str(Path(RUNS[234][1]) / 'byte0-result.json')]
            and controls['rawCoreSha256'] == PINS['/tmp/g350-ca-merged47-core236-raw.json']
            and controls['partialCoreControlPassed'] is True and len(controls['checks']) == 35
            and all(c['passed'] for c in controls['checks']), 'Actual236 all35 fresh controls')
    native_results = {r['name']: r for r in native['results']}
    require(native['completed'] is True and len(native_results) == 16
            and all(native_results[n]['state'] == 'completed' and not native_results[n]['findings'] for n in native['physical10'])
            and len(native_results['checkPcbBusLengthSkew']['findings']) == 3
            and all(not r['findings'] for n, r in native_results.items() if n != 'checkPcbBusLengthSkew'), 'Actual237 physical10/other geometry zero, three bus-skew findings retained')
    require(auth['complete'] is True and auth['actualViaCount'] == 227 and auth['foreignViaTrackCopperClearancePassed'] is True
            and not auth['violations'] and not auth['ambiguousVias'] and auth['exactInputFilesUnchanged'] is True, 'Actual238 fresh227 authenticated clearance proof')
    require(auth['inputBindings']['raw']['sha256'] == controls['rawCoreSha256']
            and auth['inputBindings']['controls']['sha256'] == PINS[str(Path(RUNS[236][1]) / 'byte0-result.json')]
            and auth['inputBindings']['plan']['sha256'] == PINS[str(Path(RUNS[234][1]) / 'byte0-result.json')]
            and auth['inputBindings']['mergedCandidate']['sha256'] == PINS[str(Path(RUNS[233][1]) / 'byte0-result.candidate.json')],
            'Actual238 full raw/control/plan/merged-candidate binding')
    require(native['inputBindings']['raw']['sha256'] == controls['rawCoreSha256']
            and native['inputBindings']['controls']['sha256'] == PINS[str(Path(RUNS[236][1]) / 'byte0-result.json')]
            and native['inputBindings']['reviewedSourcePlan234']['sha256'] == controls['planSha256'],
            'Actual237 full raw/control/plan binding')
    fresh_raw = read(Path('/tmp/g350-ca-merged47-core236-raw.json'))
    fresh_pour_ids = [r['pcb_copper_pour_id'] for r in fresh_raw if r.get('type') == 'pcb_copper_pour']
    require(len(fresh_pour_ids) == 15 and len(set(fresh_pour_ids)) == 15, 'Actual23615-pour inventory; no inherited22814-pour roster')

    alias_sources = {
        'byte0-result.candidate.json': Path(RUNS[233][1]) / 'byte0-result.candidate.json',
        'byte0-result.json': Path(RUNS[233][1]) / 'byte0-result.json',
        'route-plan.json': Path(RUNS[234][1]) / 'byte0-result.json',
        'source-capture.json': Path(RUNS[235][1]) / 'byte0-result.json',
        'core-controls.json': Path(RUNS[236][1]) / 'byte0-result.json',
        'raw-core.json': Path('/tmp/g350-ca-merged47-core236-raw.json'),
        'native-focused16.json': Path(RUNS[237][1]) / 'byte0-result.json',
        'via-owner227.json': Path(RUNS[238][1]) / 'byte0-result.json',
        'ca-merge-pure-screen.json': Path('/tmp/g350-current223-ca204-merge-pure-screen.json'),
        'ca-merge-planning.json': Path('/tmp/g350-current223-ca204-maximal_clear-planning.json'),
    }
    for name, source in alias_sources.items():
        row = targets[str(source)]
        p = SAVED / name
        require(not p.exists(), 'Alias must be fresh')
        with (SAVED / row['savedPath']).open('rb') as reader, p.open('xb') as writer:
            shutil.copyfileobj(reader, writer, 1024 * 1024); os.fchmod(writer.fileno(), row['mode'])
        require(digest(p) == row['sha256'], 'Alias bytes mismatch')
        alias_rows[name] = {'canonicalSavedPath': row['savedPath'], 'restorePath': str(source), 'sha256': row['sha256'], 'bytes': row['bytes'], 'mode': row['mode']}
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    primary = {'candidateSha256': PINS[str(Path(RUNS[233][1]) / 'byte0-result.candidate.json')],
               'savedCandidate': 'byte0-result.candidate.json', 'routedOwners': 47, 'pendingOwnerIds': ['source_trace_26', 'source_trace_30'],
               'all47PhysicalAndNumericJoinedPassed': True, 'bothCriticalDqs1ViewsPassed': True, 'allDerivedHardMaximaSatisfied': True,
               'caMinimumPassingCount': 13, 'caMemberCount': 26, 'caObservedSkewMm': 15.81859992152097,
               'freshSource236All35Passed': True, 'freshNative237Focused16Completed': True, 'freshPhysical10Findings': 0,
               'freshNative237BusSkewFindingCount': 3, 'freshAuth238All227Passed': True,
               'freshCoreExpectedCounts': copy.deepcopy(controls['expectedCounts']),
               'freshLiteralPourCount': 15, 'freshLiteralPourIds': fresh_pour_ids,
               'literalPourClearanceQualified': False, 'literalPourAuditPending': True, 'prior228PourPassInherited': False,
               'fullTimingPassed': False, 'electricalTimingQualified': False, 'defaultBoardPromoted': False,
               'all49Accepted': False, 'cadQualified': False, 'fabricationReady': False}
    ti_analysis = {'analysisOnly': True, 'sdkExecutedByCollector': False, 'tiQualified': False,
                   'referencePlaneContinuityQualified': False,
                   'referenceGapWitnessesPreserved': True,
                   'retainedOriginalSourceCAMinimumMm': 20.95,
                   'currentPlacementPureTICAMinimumMm': 19.75,
                   'stricterRetainedSourceMinimumUnchanged': True,
                   'allFourSignalLayerGeometryIsNotDocumentedSignalGroundPowerSignalStackQualification': True,
                   'files': [copy.deepcopy(targets[name]) for name in sorted(PINS)
                             if Path(name).name.startswith('g350-ti-current233-source236-')]}
    require(len(ti_analysis['files']) == 7 and all(row['mode'] == 0o600 for row in ti_analysis['files']),
            'All seven frozen TI analysis files and exact modes required')
    restore_manifest = {'scope': 'Post232 merged233 partial47 Source236 evidence; no board promotion', 'updatedAt': now,
                        'solverSourceRoot': '/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib',
                        'baseArchiveDependency': dependencies[-1], 'baseArchiveDependenciesInRestoreOrder': dependencies,
                        'baseDependencyRestoreFiles': sorted(dependencies_used.values(), key=lambda r: r['restorePath']),
                        'files': sorted(targets.values(), key=lambda r: r['restorePath']), 'aliases': alias_rows,
                        'primaryCandidate': primary, 'tiPureAnalysis': ti_analysis, 'all49Accepted': False, 'fabricationReady': False}
    progress = {'scope': 'Separate post232 evidence collection, closed233..238; all source/native outputs are Root runtime evidence',
                'updatedAt': now, 'latestClosedScopeIncluded': 238, 'closedExperiments': observations, 'primaryCandidate': primary,
                'baseArchiveDependenciesInRestoreOrder': dependencies, 'baseDependenciesCopied': False, 'aliases': alias_rows,
                'tiPureAnalysis': ti_analysis,
                'publicBaseRestoreDependencies': sorted(dependencies_used.values(), key=lambda r: r['restorePath']),
                'privateAuthorityAndContextBodiesExcluded': True, 'excludedPrivateNamedLiterals': sorted(set(private_literals)),
                'collectorUsesOnlyOwnPythonStdlib': True, 'sdkExecutedByCollector': False, 'existingRestoreHelperExecutedByCollector': False,
                'archiveCreated': False, 'commitCreated': False, 'cloudDocumentEdited': False,
                'oldPost209FrozenMetadataPins': BASE228_PINS, 'all49Accepted': False, 'fabricationReady': False}
    write_json(SAVED / 'WORKSPACE_RESTORE_MANIFEST.json', restore_manifest)
    readme = """Merged233 partial47 evidence, closed233–238.

This separate collection preserves current223's data-route progress and exact204
CA tuning bodies: 47/49 physical paths, with D12/source26 and DQM0/source30 still
pending. Root233 requalified all47 bodies and numeric joins, both actual DQS1
critical views/all five APIs, and all derived hard maxima. Only13/26 CA owners
meet20.95mm; CA spread15.8186mm and three fresh native bus-skew findings remain.
Full timing, electrical readiness, TI qualification, CAD, default promotion,
all49 acceptance and fabrication readiness are FALSE.

Source234 projection, capture235/full inverse and fresh Core236/all35 controls
passed. Native237 reran focused16 checks: physical10 and other requested geometry
checks returned zero findings; all3 bus-skew findings are retained. Other16 native
checks were not rerun, and prior185 full32 results are historical only. Auth238
authenticated all227 manual vias and found no foreign via-to-track violations.

LITERAL15-POUR CLEARANCE IS NOT YET QUALIFIED. The Source228 all14-pour pass is a
base dependency only and is NOT inherited for the new Source236 copper geometry.
No new pour pass, own-net reentry proof, complete routing or fabrication claim is
made by this collector.

The seven frozen g350-ti-current233-source236-* report/script/control files are
included with exact hashes and modes as ANALYSIS ONLY. Their literal reference-
material gap witnesses are retained. TI/reference-plane/electrical qualification
is not established by this review; all-four-signal routing is not proof of the
documented signal/GND/power/signal stack. The original Source CA minimum20.95mm
remains unchanged and stricter than the current-placement pure TI arithmetic
minimum19.75mm. The assessment does not relax any retained routing requirement.

Restore Source209 and its documented prior prerequisites first, then the frozen
Source228 archive. Their exact archive/manifest hashes are recorded in
WORKSPACE_RESTORE_MANIFEST.json. They are dependencies and were not copied or
rewritten here. The helper does not enforce dependency order; that is a caller
precondition. Then verify/restore this new saved workspace using:

python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post232-2026-10-16
python3 scripts/restore-g350-four-layer-routing-workspace.py --saved-directory .cloud-tools/ddr-four-layer-post232-2026-10-16 --restore

The existing helper rejects different bytes/modes instead of replacing local
work. Only public regular files are saved; private authority/context bodies are
excluded. No SDK, Bun/Node, application import, archive creation or commit is
performed by the collector. Prior post209 metadata and payloads remain frozen.
"""
    with (SAVED / 'README.md').open('x') as stream:
        stream.write(readme)
    excluded = {'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
    progress['artifacts'] = [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': digest(p), 'mode': stat.S_IMODE(p.stat().st_mode)}
                             for p in sorted(SAVED.iterdir()) if regular(p) and p.name not in excluded]
    write_json(SAVED / 'PROGRESS.json', progress)
    index_rows = [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': digest(p), 'mode': stat.S_IMODE(p.stat().st_mode)}
                  for p in sorted(SAVED.iterdir()) if regular(p) and p.name != 'WORKSPACE_HASH_INDEX.json']
    for name, (h, size, mode) in input_pins.items():
        p = Path(name)
        require(digest(p) == h and p.stat().st_size == size and stat.S_IMODE(p.stat().st_mode) == mode, 'Collected public input changed: ' + name)
    verify_frozen228()
    write_json(SAVED / 'WORKSPACE_HASH_INDEX.json', {'scope': 'Post232 Source236 merged partial47; literal pours pending, no board acceptance',
                'updatedAt': now, 'files': index_rows, 'selfExcluded': True, 'all49Accepted': False, 'fabricationReady': False})
    # Own read-only equivalent of the helper's mode/hash destination validation.
    for row in restore_manifest['files']:
        source, target = SAVED / row['savedPath'], Path(row['restorePath'])
        require(digest(source) == row['sha256'] and source.stat().st_size == row['bytes'], 'Saved restore bytes')
        require(regular(target) and digest(target) == row['sha256'] and stat.S_IMODE(target.stat().st_mode) == row['mode'], 'Current restore target bytes/mode')
    print(json.dumps({'savedDirectory': str(SAVED), 'restoreTargets': len(targets), 'baseDependencyTargets': len(dependencies_used),
                      'indexedFiles': len(index_rows), 'primaryCandidateSha256': primary['candidateSha256'],
                      'literalPoursQualified': False, 'all49Accepted': False, 'archiveCreated': False}))


if __name__ == '__main__':
    main()
