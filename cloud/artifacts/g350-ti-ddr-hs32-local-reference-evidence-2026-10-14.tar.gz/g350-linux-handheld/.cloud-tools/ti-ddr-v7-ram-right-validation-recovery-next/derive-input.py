"""Pure fresh V7 Core/native endpoint audit and TI-derived limits; no router."""
from pathlib import Path
import copy,hashlib,json,math
from validate_layout import equivalent
from validate_v7 import MOVED
ROOT=Path(__file__).resolve().parent
raw=(ROOT/'output/ddr-input.json').read_bytes();data=json.loads(raw);v6=json.loads((ROOT/'inputs/v6-core-ddr-input.json').read_bytes());expected=copy.deepcopy(v6)
for c in expected['connections']:
 points=c['pointsToConnect'];assert len(points)==2 and points[0]['port_selector'].startswith('U_SOC.') and points[1]['port_selector'].startswith('U_RAM.');points[1]['x']+=1.2
moved=[]
for o in expected['obstacles']:
 meta=o.get('circuitJsonMetadata',{})
 if meta.get('source_component_name') in MOVED or meta.get('pcb_via_id') in ['pcb_via_0','pcb_via_1']:
  o['center']['x']+=1.2;moved.append({'identity':meta,'newCenter':o['center']})
for t in expected['traces']:
 for p in t['route']:p['x']+=1.2
assert len(moved)==132
for key in expected:equivalent(expected[key],data[key],'freshCoreRigidTranslation.'+key)
assert set(data)==set(v6) and len(data['connections'])==49 and len(data['obstacles'])==856 and len(data['traces'])==2
by={c['name']:c for c in data['connections']};assert len(by)==49
handoff=json.loads((ROOT/'inputs/v7-translation-handoff.json').read_bytes())
for row in handoff['nativeEndpointProjection']:
 c=by[row['name']];equivalent(row['CPU'],c['pointsToConnect'][0],'freshCpuPin.'+row['name']);equivalent(row['proposedRAM'],c['pointsToConnect'][1],'freshRamPin.'+row['name'])
maxima={}
for b in data['buses']:
 lengths=[]
 for name in b['connectionNames']:
  p,q=by[name]['pointsToConnect'];lengths.append((abs(q['x']-p['x'])+abs(q['y']-p['y']),name))
 maximum=max(v for v,n in lengths);maxima[b['busId']]={'maximumManhattanMm':maximum,'maximalNames':[n for v,n in lengths if abs(v-maximum)<1e-7]}
assert abs(maxima['DDR_BYTE0']['maximumManhattanMm']-13.2)<1e-7
assert abs(maxima['DDR_BYTE1']['maximumManhattanMm']-15.6)<1e-7
assert abs(maxima['DDR_COMMAND_CLOCK']['maximumManhattanMm']-14.8)<1e-7
caclm=maxima['DDR_COMMAND_CLOCK']['maximumManhattanMm']+7.62
minimum=caclm-1.27;maximum=caclm+1.27
assert abs(caclm-22.42)<1e-7 and abs(minimum-21.15)<1e-7 and abs(maximum-23.69)<1e-7
for b in data['buses']:
 if b['busId']=='DDR_BYTE0':b['maxLength']=13.2
 elif b['busId']=='DDR_BYTE1':b['maxLength']=14.4
 elif b['busId']=='DDR_COMMAND_CLOCK':b.update(minLength=round(minimum,9),maxLength=round(maximum,9))
assert data['allowedLayers']==['top','bottom'] and all(b['allowedLayers']==['top','bottom'] and b['preferredLayers']==['bottom','top'] for b in data['buses'])
unrestricted=copy.deepcopy(data);classes={'DDR_RESET':'bottom','DDR_BYTE0':'top','DDR_BYTE1':'top','DDR_COMMAND_CLOCK':'bottom'}
for b in data['buses']:b['allowedLayers']=[classes[b['busId']]];b['preferredLayers']=[classes[b['busId']]]
hashes={}
for name,value in [('original-unrestricted-input.json',unrestricted),('input.json',data)]:
 value_raw=(json.dumps(value,indent=2)+'\n').encode();(ROOT/'run'/name).write_bytes(value_raw);hashes[name]=hashlib.sha256(value_raw).hexdigest()
report={'scope':'Actual fresh pinned V7 Core projection, exact rigid physical delta, fresh TI endpoint audit, then declared layer policy; no initializer/routing','coreInputSha256':hashlib.sha256(raw).hexdigest(),'hashes':hashes,'connections':49,'obstacles':856,'originalPads':854,'referenceViaObstacles':2,'fixedReferences':2,'translatedPadAndViaObstacles':132,'all49ExactCpuRamPinAndEndpointIdentitiesPreserved':True,'actualFreshCpuPointsUnchangedAndRamXPlus1_2Verified':True,'allOtherPadGeometryAndOwnersExact':True,'fixedReferenceGeometryTranslatedRigidlyAndOwnersExact':True,'freshEndpointMaxima':maxima,'caclmMm':caclm,'commandTotalPlanarRangeMm':[round(minimum,9),round(maximum,9)],'byte0MaximumTotalPlanarMm':13.2,'byte1MaximumTotalPlanarMm':14.4,'byte1DerivedDqlmMm':15.6,'byte1RetainsStricterLimit':True,'busSkewMm':.635,'pairSkewMm':.127,'layerPolicy':classes,'topMembers':22,'bottomMembers':27,'newPlacementRequiresIndependentV7RoutingQualification':True,'sourceInitializerCalled':False,'signalRoutingPerformed':False,'accepted49':False,'referenceContinuityQualified':False,'fabricationReady':False}
(ROOT/'run/input-derivation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'freshEndpointAuditPassed':True,'inputSha256':hashes['input.json'],'unrestrictedInputSha256':hashes['original-unrestricted-input.json'],'byte0MaxMm':13.2,'byte1MaxMm':14.4,'commandMinMaxMm':[round(minimum,9),round(maximum,9)],'initializerCalls':0}))
