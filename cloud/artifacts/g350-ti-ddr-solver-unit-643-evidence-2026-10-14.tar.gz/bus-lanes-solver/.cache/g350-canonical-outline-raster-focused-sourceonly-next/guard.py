from pathlib import Path
import argparse, hashlib, importlib.util, json, os, re, stat, sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'g350-count-conditioned-site-recovery-next'
REPOSITORY = Path('/workspace/bus-lanes-solver')
POLICY = {'wallSeconds': 60, 'rssBytes': 2*1024**3, 'sharedBytes': 26*1024**3,
          'sampleSeconds': .05, 'termGraceSeconds': 5}
RESERVE = 2*1024**3

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''): h.update(block)
    return h.hexdigest()

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec); spec.loader.exec_module(loaded)
    return loaded

def verify():
    raw = (ROOT / 'PREPARED.json').read_bytes(); packet = json.loads(raw)
    for row in packet['files'] + packet['externalFiles']:
        path = Path(row['path'])
        assert path.is_file() and not path.is_symlink() and sha(path) == row['sha256']
        assert path.stat().st_size == row['bytes'] and stat.S_IMODE(path.stat().st_mode) == row['mode']
    source = ROOT / 'source'
    actual = {str(p.relative_to(source)) for p in source.rglob('*') if p.is_file() and not p.is_symlink()}
    assert actual == set(packet['sourceFiles'])
    links = {str(p.relative_to(source)): os.readlink(p) for p in source.rglob('*') if p.is_symlink()}
    assert links == {'node_modules': str(REPOSITORY / 'node_modules')}
    assert packet['baseCommit'] == 'c1151212be7b9de4b34b07436d135d874e6c0466'
    assert packet['cardinalitySourceSha256'] == '36ce7fa6d89fe6513c3f881d4426ab1a8ff6b1a0c0cca82102f873186db8b210'
    assert packet['newAdoptionPaths'] == ['lib/board-outline.ts', 'lib/grid-visibility.ts', 'tests/board-outline-raster-scalar.test.ts']
    assert packet['outlineProposalSha256'] == '37b0bec02c5ac22d8d6f1efd960972cd796c6dcbdf3e4890ea82ff10d1667920'
    assert packet['boardOutlineSourceSha256'] == '33d12ec69e910e0b8d089804b07054b70d7f8488fe2369d2a6a801f78c738731'
    assert packet['gridVisibilitySourceSha256'] == 'f9718174f712bf6f298bfc0829b4352be5e0dbca445881b100d772ebc2427754'
    assert packet['pointRectangleProposalSha256'] == '12d6957e17d38d06570a75a0650dae3a007dd2240403d6ae813a4fa2b8f300ed'
    assert packet['vectorSceneSourceSha256'] == '638c70ed7ffa42b389495157689f955420015fc6d527ddd49ee72e84e4fb6bd0'
    assert packet['policy'] == POLICY and packet['preforkReserveBytes'] == RESERVE
    return packet, hashlib.sha256(raw).hexdigest()

def dependencies():
    verifier = module('canonical_handoff_trusted_dependency_verifier', BASE / 'verify-installed-dependencies.py')
    result = verifier.verify(BASE / 'dependencies/archive-receipt.json',
        '1a49a60909258b542c7f4899e6378fa9f10c1cea08ef1aaf4b5366480dbf71b7',
        BASE / 'audit-installed-dependencies.py')
    assert result['treeSha256'] == '47633d41b2b4d3f88c83a220327912b59445cdc4f301e4235393a6d5c910e9b6'
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--root-receipt'); parser.add_argument('--root-receipt-sha256')
    args = parser.parse_args(); packet, digest = verify()
    if args.preflight_only:
        print(json.dumps({'preflightPassed': True, 'packetSha256': digest, 'sourceOnly': True})); return 0
    assert args.run and args.root_receipt and args.root_receipt_sha256
    authority = json.loads(Path(args.root_receipt).read_bytes())
    assert sha(args.root_receipt) == args.root_receipt_sha256
    assert authority['authorizedByRoot'] is True and authority['scope'] == packet['scope']
    assert authority['packetSha256'] == digest and authority['policy'] == POLICY
    assert re.fullmatch('[0-9a-f]{32,128}', authority['approvalToken'])
    previous_path = Path(authority['previousClosedPostauditPath'])
    assert sha(previous_path) == authority['previousClosedPostauditSha256']
    previous = json.loads(previous_path.read_bytes()); execution = previous['execution']
    assert execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values())
    assert execution['pgid'] == authority['previousOwnedPgid']
    assert previous.get('sourceAndArtifactHeld', previous.get('sourceAndArtifactsHeld')) is True
    assert previous['dependenciesBefore'] == previous['dependenciesAfter']
    scope = module('canonical_handoff_original_owned_scope', BASE / 'process_scope.py')
    assert not scope.owned(execution['pgid']) and not (ROOT / 'run').exists()
    before = dependencies(); baseline = scope.memory()
    def gate(now):
        assert now['current'] + POLICY['rssBytes'] + RESERVE < POLICY['sharedBytes'], 'Strict prefork reserve required'
        assert all(now['events'][k] == baseline['events'][k] for k in scope.OOM_KEYS)
    actual = scope.run_guarded([sys.executable, str(ROOT / 'leader.py')],
        ROOT, ROOT / 'run', POLICY, {'G350_OUTLINE_SCALAR_FOCUSED_APPROVED': '1', 'GIT_OPTIONAL_LOCKS': '0'}, before_spawn=gate)
    verify(); after = dependencies(); assert before == after
    result_path = ROOT / 'run/result.json'
    result = json.loads(result_path.read_bytes()) if result_path.is_file() else None
    log_path = ROOT / 'run/child.log'
    log = log_path.read_text(errors='replace') if log_path.is_file() else ''
    pass_rows = re.findall(r'^\s*(\d+) pass\s*$', log, re.M)
    fail_rows = re.findall(r'^\s*(\d+) fail\s*$', log, re.M)
    summaries = re.findall(r'^Ran (\d+) tests across (\d+) files?\.', log, re.M)
    counts = {'pass': int(pass_rows[-1]) if pass_rows else None,
              'fail': int(fail_rows[-1]) if fail_rows else None,
              'tests': int(summaries[-1][0]) if summaries else None,
              'files': int(summaries[-1][1]) if summaries else None}
    passed = (actual['exitCode'] == 0 and not actual['diagnosticStopped']
        and actual['cleanupOwnedGroupEmpty'] and not any(actual['oomDelta'].values())
        and result is not None and result['passed'] is True and counts == {'pass': 28, 'fail': 0, 'tests': 28, 'files': 8})
    receipt = {'execution': actual, 'dependenciesBefore': before, 'dependenciesAfter': after,
        'sourceAndArtifactsHeld': True, 'packetSha256': digest, 'outlineScalarFocusedQualificationPassed': passed,
        'actualCounters': counts, 'resultSha256': sha(result_path) if result is not None else None,
        'accepted49': False, 'wholeSuiteExecuted': False, 'allElevenBenchmarksExecuted': False}
    (ROOT / 'EXECUTION-postaudit.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'outlineScalarFocusedQualificationPassed': passed, 'actualCounters': counts,
                     'resultSha256': receipt['resultSha256']}))
    return 0 if passed else 2

if __name__ == '__main__': raise SystemExit(main())
