import datetime,hashlib,importlib.util,json,os
from pathlib import Path
import secrets,subprocess,sys
ROOT=Path(__file__).resolve().parent
BUN='/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
HELPERS=Path('/workspace/bus-lanes-solver/.cache/g350-ti-top-clock-stage-telemetry-v3-next')
POLICY={'wallSeconds':120,'rssBytes':2*1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);sys.modules[name]=value;spec.loader.exec_module(value);return value
def source():
 return subprocess.check_output([sys.executable,str(ROOT/'verify-source.py')],text=True)
def headroom(current):
 assert current['current']+POLICY['rssBytes']+2*1024**3<POLICY['sharedBytes'],'fresh shared headroom insufficient'
assert os.environ.get('G350_914_PACKAGE_VERIFICATION_DELEGATED')=='1','root delegated scope missing'
assert not (ROOT/'run').exists(),'exclusive run directory already exists'
prep=json.loads((ROOT/'preparation.json').read_bytes());prep_sha=sha(ROOT/'preparation.json')
for record in prep['externalFiles']:
 assert sha(Path(record['path']))==record['sha256'],'external binding differs'
source_before=source()
verifier=module('trusted_dependency_verify',HELPERS/'verify-installed-dependencies.py')
receipt=HELPERS/'dependencies/archive-receipt.json'
dependency_before=verifier.verify(receipt,'1a49a60909258b542c7f4899e6378fa9f10c1cea08ef1aaf4b5366480dbf71b7',HELPERS/'audit-installed-dependencies.py')
scope=module('owned_scope',ROOT/'process_scope.py');headroom(scope.memory())
launch={'authorizedByRoot':True,'delegatedExecutor':'/root/carrier_search_review','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'approvalToken':secrets.token_hex(32),'scope':'one NEW914 typecheck, read-only format, local-tar-only Node/browser/TypeScript package validation','preparationSha256':prep_sha,'policy':POLICY,'sourceManifestSha256':prep['sourceManifestSha256'],'libraryManifestSha256':prep['libraryManifestSha256'],'controllerOutputTreeOnly':True,'routingExecuted':False,'fullSuiteExecuted':False}
(ROOT/'delegated-launch-receipt.json').write_text(json.dumps(launch,indent=2)+'\n')
execution=scope.run_guarded([BUN,'--smol',str(ROOT/'root-check-launcher-v2.ts')],ROOT,ROOT/'run',POLICY,{'G350_FULL_SOURCE_CHECKS_APPROVED':'1','G350_FULLCHECK_PYTHON':sys.executable,'G350_CHECK_PREPARATION_SHA':prep_sha},before_spawn=headroom)
source_after=source();dependency_after=verifier.verify(receipt,'1a49a60909258b542c7f4899e6378fa9f10c1cea08ef1aaf4b5366480dbf71b7',HELPERS/'audit-installed-dependencies.py')
result_path=ROOT/'run/result.json';result=json.loads(result_path.read_bytes()) if result_path.exists() else None
trusted=bool(execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values()) and source_before==source_after and dependency_before==dependency_after and result and result['allPassed'] and sha(ROOT/'preparation.json')==prep_sha)
post={'execution':execution,'sourceBefore':json.loads(source_before),'sourceAfter':json.loads(source_after),'dependencyBefore':dependency_before,'dependencyAfter':dependency_after,'resultTrustEligible':trusted,'resultSha256':sha(result_path) if result else None,'launchReceiptSha256':sha(ROOT/'delegated-launch-receipt.json'),'accepted49':False,'routingExecuted':False,'fullSuiteExecuted':False}
(ROOT/'run/postflight.json').write_text(json.dumps(post,indent=2)+'\n')
print(json.dumps({'resultTrustEligible':trusted,'checks':result['checks'] if result else None}),flush=True)
raise SystemExit(0 if trusted else 2)
