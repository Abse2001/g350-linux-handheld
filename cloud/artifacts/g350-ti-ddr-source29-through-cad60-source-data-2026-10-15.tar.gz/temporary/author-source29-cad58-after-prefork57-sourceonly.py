from pathlib import Path
import ast,json,hashlib,stat,difflib
P=Path('/tmp/g350-source29-cad57-authentic56-root-guard-sourceonly-next');O=Path('/tmp/g350-source29-cad58-after-truthful-prefork57-sourceonly-next');assert not O.exists();O.mkdir(mode=0o700)
H=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 p=Path(p);st=p.stat();assert p.is_file()and not p.is_symlink();return dict(path=str(p),sha256=H(p.read_bytes()),bytes=st.st_size,mode=stat.S_IMODE(st.st_mode))
def put(n,s):
 p=O/n;p.write_text(s);p.chmod(0o600)
pm=json.loads((P/'SOURCE-manifest.json').read_text());assert pin(P/'SOURCE-manifest.json')['sha256']=='bcaee0d1991635f39e2b587655c146facef22564cd320fcde7f3b122011a6c53'
fpath=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress/source29-cad-98055-PREFORK-REJECTED-POSTAUDIT-CRASH-COLLECTED-root.json');fr=pin(fpath);assert fr['sha256']=='82597a14e833c17e8fefa329a1fee9871f6ca9850f31e1c76e8e60beb3dba6aa';f=json.loads(fpath.read_text())
for k in ['zonePinsExecutionPin','cadAttemptExecutionPin','actualSourceZonePins']:assert pin(f[k]['path'])==f[k]
copy=json.loads(Path(pm['cad29SnapshotCopyInputsPin']['path']).read_text());oldcopy=copy.copy();copy['scope']='SOURCE_ONLY_AUTHENTIC56_SOURCE29_CAD58_EXACT38_SPARSE_COPY_INPUT';copy['runRoot']='/tmp/g350-source29-cad-root-20261015-after57';copy['snapshotRoot']=copy['snapshotRoot'].replace('after56','after57')
for item in copy['snapshots']:
 item['snapshotPath']=item['snapshotPath'].replace('/tmp/g350-source29-cad-root-20261015-after56/','/tmp/g350-source29-cad-root-20261015-after57/')
assert copy['requiredSparseFileCount']==38 and copy['requiredSparseBytes']==24380686 and all(pin(r['original']['path'])==r['original']for r in copy['snapshots']);put('SNAPSHOT_COPY_INPUTS.json',json.dumps(copy,indent=2)+'\n');copy_pin=pin(O/'SNAPSHOT_COPY_INPUTS.json')
consumer='''def closed57():
 prior=closed56();assert prior['actualClosedScopeCount']==56
 for key in('actual57FailedCollectionPin','actual57ZoneExecutionPin','actual57UnspawnedCadExecutionPin','actual57ZonePinsPin','actual57GuardManifestPin'):binding(proposal[key])
 r=read(proposal['actual57FailedCollectionPin']['path']);zone=read(proposal['actual57ZoneExecutionPin']['path']);attempt=read(proposal['actual57UnspawnedCadExecutionPin']['path'])
 assert r['authorizedByRoot']is r['toolSessionCollected']is True and r['toolSessionId']==98055 and r['toolExitCode']==r['toolWrapperExitCode']==1 and r['passed']is False
 assert r['scope']=='ROOT_SOURCE29_CAD57_ZONE_ONLY_CAD_PREFORK_REJECTED_POSTAUDIT_CRASH_RECOVERY'and r['phase']=='cad-prefork-failure'
 assert r['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and r['rootGuardProposalManifestSha256']==proposal['actual57GuardManifestPin']['sha256']and r['actualClosedPriorScopes']==prior
 assert r['zonePinsExecutionPin']==proposal['actual57ZoneExecutionPin']and r['cadAttemptExecutionPin']==proposal['actual57UnspawnedCadExecutionPin']and r['actualSourceZonePins']==proposal['actual57ZonePinsPin']
 assert r['zonePinsExecution']==zone and r['unspawnedCadAttemptExecution']==attempt
 h.finite(zone,0);assert zone['policy']==cad29_contract['zonePinsPolicy']and zone['pid']==zone['pgid']==506788 and zone['currentGuardPid']==506698 and c.guard.process_scope.owned(506788)==[]and not Path('/proc/506698').exists()
 assert 'pid'not in attempt and 'pgid'not in attempt and attempt['exitCode']is None and attempt['cleanupOwnedGroupEmpty']is None and attempt['diagnosticStopped']is True and attempt['guardError']=='AssertionError'and attempt['stopReasons']==[]
 assert attempt['policy']==cad29_contract['cadPolicy']and attempt['currentGuardPid']==506698 and not any(attempt['oomDelta'].values())and attempt['signalErrors']==[]and attempt['diskFreeGuard']['sampleCount']==0
 assert r['originalCadExitCode']is r['originalCadCleanupOwnedGroupEmpty']is r['completeSdkPostauditHeld']is None
 for key in('zonePinsChildNatural0','actualCadApplicationCompletionUnknown','memoryAdmissionGateWouldRejectObservedSnapshot','resourceReceiptAbsent','outputDirectoryEmpty','completeSdkPostauditUnavailableBecauseGuardCrashed','independentlyObservedAllActuallySpawnedOwnedGroupsEmpty','independentlyObservedGuardAbsent'):assert r[key]is True
 for key in('cadChildPidOrPgidAllocated','cadWrapperSpawned','cadApplicationInvoked','containerInvocationPerformed','originalPostauditProduced','Source29Accepted','accepted49','fabricationReady','referenceQualified','electricalTimingPassed'):assert r[key]is False
 assert r['guardPostauditFailure']=='KeyError: pgid in zoneBeforeCadSeriallyEnforced expression'and r['observedMemoryBeforeBytes']==attempt['memoryBefore']['current']==27931193344 and r['requiredProcessContainerAndSafetyReserveBytes']==4294967296 and r['sharedCapBytes']==32212254720 and r['observedAdmissionExcessBytes']==13905920
 assert r['observedMemoryBeforeBytes']+r['requiredProcessContainerAndSafetyReserveBytes']-r['sharedCapBytes']==r['observedAdmissionExcessBytes']and r['diskSamples']==0
 assert r['independentlyObservedOwnedGroupMembers']=={'506788':[]}and r['independentProcReadErrors']==[]and r['actualClosedScopeCount']==57
 assert not Path(proposal['original57RunRoot'],'POSTAUDIT.json').exists()and not Path(proposal['original57RunRoot'],'cad-resource-observations.json').exists()and not any(Path(proposal['original57RunRoot'],'output').iterdir())
 z=read(proposal['actual57ZonePinsPin']['path']);assert z['actualCoreRawSha256']==proposal['actual53CoreRawPin']['sha256']and z['actualExportSha256']==proposal['actual56ExportPin']['sha256']and z['actualSourceKeepoutCount']==2
 prior['actual57ZoneOnlyCadPreforkRefusalPostauditCrashCollectionPin']={k:proposal['actual57FailedCollectionPin'][k]for k in('path','sha256')};prior['actual57CadNeverSpawnedOriginalExitAndSdkPostUnknown']=True;prior['actualClosedScopeCount']=57
 return prior
'''
ast.parse(consumer);put('CLOSED57_PREFORK_REFUSAL_POSTAUDIT_CRASH_SOURCE_ONLY.py',consumer)
oldtail=Path(pm['cad29MainTailPin']['path']).read_text();tail=oldtail
for x,y in [('run_cad57_tail','run_cad58_tail'),('closed56','closed57'),('==56','==57'),('WITH56_AUTHENTIC_PRIOR_CLOSURES','WITH57_AUTHENTIC_PRIOR_CLOSURES')]:tail=tail.replace(x,y)
tail=tail.replace('COPY_SHA='+repr(pm['cad29SnapshotCopyInputsPin']['sha256']),'COPY_SHA='+repr(copy_pin['sha256']))
needle="zone_natural and isinstance(cad_execution,dict)and zone_execution['pgid']!=cad_execution['pgid']";assert tail.count(needle)==1;tail=tail.replace(needle,"zone_natural and isinstance(cad_execution,dict)and type(cad_execution.get('pgid'))is int and cad_execution['pgid']>0 and zone_execution['pgid']!=cad_execution['pgid']")
ast.parse(tail);put('cad58_main_tail.py',tail)
old=Path(pm['guardPin']['path']).read_text();guard=old.replace(str(P),str(O)).replace('AUTHOR_DONE_SOURCE29_CAD57_AFTER_AUTHENTIC56_ROOT_REVIEW_REQUIRED_UNRUN','AUTHOR_DONE_SOURCE29_CAD58_AFTER_TRUTHFUL57_ROOT_REVIEW_REQUIRED_UNRUN')
anchor=" proposal=read(PACKET/'SOURCE-manifest.json')\n";assert guard.count(anchor)==1
intro=" assert proposal['actual57FailedSealed']is True\n for key in('actual57FailedCollectionPin','actual57ZoneExecutionPin','actual57UnspawnedCadExecutionPin','actual57ZonePinsPin','actual57GuardManifestPin'):assert isinstance(proposal[key],dict)\n"
guard=guard.replace(anchor,anchor+intro)
# New retry contract is same policies, required history count57. No old contract/policy redefinition.
guard=guard.replace("cad29_contract['requiredPriorScopeCount']==56","cad29_contract['requiredPriorScopeCount']==57")
anchor=" binding(proposal['cad29MainTailPin'])\n";assert guard.count(anchor)==1;guard=guard.replace(anchor,'\n'+'\n'.join(' '+line if line else''for line in consumer.splitlines())+'\n\n'+anchor)
guard=guard.replace('cad_tail.run_cad57_tail(','cad_tail.run_cad58_tail(').replace('closed56=closed56,git_inventory','closed57=closed57,git_inventory');ast.parse(guard);put('run-source29-cad58-root.proposal.py',guard)
def closeds(src):
 ma=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)and n.name=='main');return {n.name:ast.get_source_segment(src,n)for n in ma.body if isinstance(n,ast.FunctionDef)and n.name.startswith('closed')}
a,b=closeds(old),closeds(guard);assert all(b[k]==v for k,v in a.items())
contract=json.loads(Path(pm['cad29StageContractPin']['path']).read_text());contract.update(scope='SOURCE_ONLY_SOURCE29_CAD58_RETRY_AFTER_TRUTHFUL_PREFORK57',requiredPriorScopeCount=57,expectedPeerDecision='GO_SOURCE_ONLY_TO_ROOT_SOURCE29_KICAD58_RETRY_AFTER_TRUTHFUL_PREFORK57',actual57FailedCollectionPin=fr,actualSparseFileCount=38,actualSparseBytes=24380686);put('CAD29_STAGE_CONTRACT.json',json.dumps(contract,indent=2)+'\n')
precopy=Path(pm['rootPrecopyScriptPin']['path']).read_text().replace(str(P),str(O)).replace(pm['cad29SnapshotCopyInputsPin']['sha256'],copy_pin['sha256']).replace('/tmp/g350-source29-cad-root-20261015-after56','/tmp/g350-source29-cad-root-20261015-after57').replace('g350-source29-cad57-root-precopy-report.json','g350-source29-cad58-root-precopy-report.json').replace('G350_SOURCE29_CAD57_PRECOPY_ROOT_APPROVED','G350_SOURCE29_CAD58_PRECOPY_ROOT_APPROVED').replace('SOURCE29_CAD57_EXACT38_PRECOPY','SOURCE29_CAD58_EXACT38_PRECOPY');ast.parse(precopy);put('root-precopy-exact38-SOURCEONLY.py',precopy)
put('EXACT_CAD57_TO_CAD58_FAILURE_CONSUMER_AND_NULL_PID_POST_DELTA.json',json.dumps(dict(parent=pin(P/'SOURCE-manifest.json'),allClosedThrough56ByteExact=list(a),tailPatch=''.join(difflib.unified_diff(oldtail.splitlines(True),tail.splitlines(True))),guardPatch=''.join(difflib.unified_diff(old.splitlines(True),guard.splitlines(True))),newFailed57Consumer=pin(O/'CLOSED57_PREFORK_REFUSAL_POSTAUDIT_CRASH_SOURCE_ONLY.py'),original57PostSdkHeldAndCadExitRemainNull=True,allCapsAndResourcePoliciesUnchanged=True,same38OriginalPublicFiles=True,RootAuthorityCreated=False,helperOrSdkOrAppsEvaluated=False,workspaceWrites=False),indent=2)+'\n')
put('README.md','Source-only CAD58 retry after authenticfailed57. Original57zonepassed/CADpreforkrejected,noCADpid/exit orPOST/completeSDKpost; allunknownspreserved. Same0b22 fiveworkers,7a7dwrapper/resourcehelper,38publicinputs,exactcaps. OnlypostserialcomparisonnowchecksgenuinepositiveCADpgid beforeindexeduse. Freshafter57run/snapshotcopies required. Rootalone mayperformseparatereadonlyverifiedarchivecacheadvice; nofiledeletion orcapchange embedded. No SDK/apps/helpers/copies/WSwritesbyauthor.\n')
m=dict(pm);m.update(scope='SOURCE_ONLY_SOURCE29_CAD58_RETRY_AFTER_TRUTHFUL57',status='AUTHOR_DONE_SOURCE29_CAD58_AFTER_TRUTHFUL57_ROOT_REVIEW_REQUIRED_UNRUN',guardPin=pin(O/'run-source29-cad58-root.proposal.py'),files=[pin(p)for p in sorted(O.iterdir())],cad29MainTailPin=pin(O/'cad58_main_tail.py'),cad29StageContractPin=pin(O/'CAD29_STAGE_CONTRACT.json'),cad29SnapshotCopyInputsPin=copy_pin,cad29SnapshotRoot=copy['snapshotRoot'],rootPrecopyScriptPin=pin(O/'root-precopy-exact38-SOURCEONLY.py'),cad29RootPrecopyReportPin=None,requiredPriorScopeCount=57,actual57FailedSealed=True,actual57FailedCollectionPin=fr,actual57ZoneExecutionPin=f['zonePinsExecutionPin'],actual57UnspawnedCadExecutionPin=f['cadAttemptExecutionPin'],actual57ZonePinsPin=f['actualSourceZonePins'],actual57GuardManifestPin=pin(P/'SOURCE-manifest.json'),original57RunRoot='/tmp/g350-source29-cad-root-20261015-after56',closed57FailedConsumerPin=pin(O/'CLOSED57_PREFORK_REFUSAL_POSTAUDIT_CRASH_SOURCE_ONLY.py'),historicalFailed57GuardPin=pm['guardPin'],actualCad58RootReceipt=None,actualCad58Report=None)
for row in [pin(P/'SOURCE-manifest.json'),fr,f['zonePinsExecutionPin'],f['cadAttemptExecutionPin'],f['actualSourceZonePins']]:
 if row not in m['externalFiles']:m['externalFiles'].append(row)
m['ownFileCountExcludingManifest']=len(m['files']);m['externalFileCount']=len(m['externalFiles']);put('SOURCE-manifest.json',json.dumps(m,indent=2)+'\n');print(json.dumps(pin(O/'SOURCE-manifest.json')));print(json.dumps(copy_pin));print(json.dumps(m['guardPin']));print(json.dumps(m['rootPrecopyScriptPin']))
