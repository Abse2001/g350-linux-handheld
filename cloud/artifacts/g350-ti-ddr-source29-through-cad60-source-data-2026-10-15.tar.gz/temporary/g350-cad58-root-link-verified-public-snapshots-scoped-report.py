"""Root-only reuse of immutable public snapshot copies; no SDK imports."""
import hashlib, json, os, stat
from pathlib import Path

assert os.environ.get("G350_SOURCE29_CAD58_SNAPSHOT_ROOT_APPROVED") == "1"
OLD = Path("/tmp/g350-source29-cad57-authentic56-root-guard-sourceonly-next/SNAPSHOT_COPY_INPUTS.json")
NEW = Path("/tmp/g350-source29-cad58-after-truthful-prefork57-sourceonly-next/SNAPSHOT_COPY_INPUTS.json")
REPORT = Path("/tmp/g350-source29-cad58-root-linked-precopy-report.json")

def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()

assert sha(OLD) == "cc66242f5aeba1ba5218cc6bfe26e656b01cde2331af671a3ff8b8baa22c687a"
assert sha(NEW) == "82b2d22dad138666b4aef82d6cd2eb4d60b1ca1570d41549f6cb3602a1d77521"
old, new = [json.loads(p.read_bytes()) for p in (OLD, NEW)]
run = Path(new["runRoot"])
assert run == Path("/tmp/g350-source29-cad-root-20261015-after57")
assert not run.exists() and not run.is_symlink() and not REPORT.exists()
old_root, new_root = [Path(d["snapshotRoot"]) for d in (old, new)]
assert old_root.parent == Path(old["runRoot"]) / "snapshots"
assert new_root.parent == run / "snapshots" and new_root.resolve() == new_root
assert len(old["snapshots"]) == len(new["snapshots"]) == 38
assert old["requiredSparseBytes"] == new["requiredSparseBytes"] == 24380686
old_rows = {r["original"]["path"]: r for r in old["snapshots"]}
assert len(old_rows) == 38

def verified(path, pin):
    assert path.is_absolute() and path.resolve() == path
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode)
        assert before.st_size == pin["bytes"] and stat.S_IMODE(before.st_mode) == pin["mode"]
        h = hashlib.sha256()
        while True:
            chunk = os.read(fd, 1048576)
            if not chunk:
                break
            h.update(chunk)
        assert h.hexdigest() == pin["sha256"]
        return before
    finally:
        os.close(fd)

prepared = []
for item in new["snapshots"]:
    pin = item["original"]
    previous = old_rows[pin["path"]]
    assert previous["original"] == pin
    source = Path(pin["path"])
    prior = Path(previous["snapshotPath"])
    target = Path(item["snapshotPath"])
    assert prior == old_root / previous["snapshotRelativePath"] and prior.is_relative_to(old_root)
    assert target == new_root / item["snapshotRelativePath"] and target.is_relative_to(new_root)
    assert item["containerTargetPath"] == str(source)
    a, b = verified(source, pin), verified(prior, pin)
    assert (a.st_dev, a.st_ino) != (b.st_dev, b.st_ino), "Never hardlink original Source or hardware"
    prepared.append((pin, source, prior, target, a, b))
assert len({str(r[3]) for r in prepared}) == 38
run.mkdir(mode=0o700)
for pin, source, prior, target, a, b in prepared:
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    assert target.parent.resolve() == target.parent
    os.link(prior, target, follow_symlinks=False)
    now = verified(target, pin)
    assert (now.st_dev, now.st_ino) == (b.st_dev, b.st_ino)
    assert now.st_mtime_ns == b.st_mtime_ns
for pin, source, prior, target, a, b in prepared:
    sa, sb, sc = [verified(p, pin) for p in (source, prior, target)]
    assert (sa.st_dev, sa.st_ino, sa.st_mtime_ns, sa.st_ctime_ns, sa.st_nlink) == (a.st_dev, a.st_ino, a.st_mtime_ns, a.st_ctime_ns, a.st_nlink)
    assert sb.st_ino == sc.st_ino == b.st_ino and sb.st_dev == sc.st_dev == b.st_dev
    assert sb.st_mtime_ns == sc.st_mtime_ns == b.st_mtime_ns
    assert sb.st_nlink == sc.st_nlink == b.st_nlink + 1
value = dict(scope="ROOT_ACTUAL_CAD58_VERIFIED_PUBLIC_SNAPSHOT_HARDLINK_REUSE", copiedFiles=38,
             copiedBytes=24380686, method="Hardlink only verified prior read-only snapshot copies",
             copyInputsPath=str(NEW), copyInputsSha256=sha(NEW), runRoot=str(run), snapshotRoot=str(new_root),
             allOriginalBytesModesMtimeCtimeAndLinksHeld=True, allSnapshotBytesModesMtimeHeld=True,
             snapshotLinkCountsIncrementedByOne=True, snapshotCtimeMayChangeAsExpected=True,
             originalSourceOrHardwareHardlinked=False, filesDeleted=False, snapshotFileBytesWritten=False,
             all38TargetsRemainReadOnlyContainerInputs=True, RootAuthorityBodiesCopied=0,
             SDKOrAppsImported=False, workspaceWrites=False, fabricationReady=False)
with REPORT.open("x") as stream:
    json.dump(value, stream, indent=2)
    stream.write("\n")
REPORT.chmod(0o600)
print(json.dumps(dict(passed=True, reportPath=str(REPORT), reportSha256=sha(REPORT), method=value["method"])))
