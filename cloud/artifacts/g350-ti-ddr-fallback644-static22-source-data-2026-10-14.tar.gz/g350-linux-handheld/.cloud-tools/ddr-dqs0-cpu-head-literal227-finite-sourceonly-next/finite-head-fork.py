"""One finite stdlib DQS0 CPU-head family on the exact227/new40 epoch."""
from pathlib import Path
import ast,copy,hashlib,importlib.util,json,math,sys,time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
EP=BASE/'ddr-source31-canonical227-one-epoch-sourceonly-next/exact-canonical227-scene.py'
assert sha(EP)=='1fe0beefde7c332a4b0ef5f4d88131960ed9663af2cbf8be691e0dbd6a7b879c'
ec=module('literal227_head_scene',EP);q=ec.z
HARD=BASE/'ddr-source40-canonical227-matched-b1-sourceonly-next/NORMALIZED_LITERAL227_MATCHED_B1_ALL11_NEW40_INNER1_OVERHEAD_CLOCK2_HARD13_05.json'
PAIR=BASE/'ddr-dqs0-cap19-context12-coupled-growth-sourceonly-next/NORMALIZED_ATOMIC_DQS0_CONTEXT12_MATCHED_ANGLE82.json'
assert sha(HARD)=='74ad14743579a144a582b544862fd642e07ce14d448d3776c3db03e1d600a8cf'
assert sha(PAIR)=='d12b51f9d7b2855b16c60282a6f98d5f864d994f6acea78eccd744561f671fbd'
hard,rawHard=q.normalize(json.loads(HARD.read_text()));pair,rawPair=q.normalize(json.loads(PAIR.read_text()));assert len(hard)==13
S=BASE/'ddr-cpu19-cap-and-owned32-corner-sourceonly-next/material-context-cap19-owned32-owned4.py'
u=module('head_angle_self',S)
SOURCE=BASE/'ddr-dqs0-cap19-context12-coupled-growth-sourceonly-next/seal-coupled-alternatives.py'
assert sha(SOURCE)=='155017a07427c1735ed7995cfa48ec0b8b7dd2c724a0e473cd6e1bf4b0a3753f'
# Only two already-reviewed original-derived pure geometric function bodies;
# never import this historical writer or execute its source-level orchestration.
tree=ast.parse(SOURCE.read_text());selected=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name in ['outside','coupling']]
assert len(selected)==2
names=['source_trace_15','source_trace_16'];width=.1016
boxes=[[-7.2632,7.2632,12.3082,27.2632],[-5.2732,8.0918,3.3082,11.4918]]
allowed=(width+.12)/math.cos(math.pi/8)-width+.002
ns={'math':math,'q':q,'boxes':boxes,'allowed':allowed};exec(compile(ast.Module(body=selected,type_ignores=[]),str(SOURCE),'exec'),ns)
def rounded(poly,radius=.11):
 out=[poly[0]]
 for i in range(1,len(poly)-1):
  a,b,c=poly[i-1:i+2];l1=math.dist(a,b);l2=math.dist(b,c)
  v=((b[0]-a[0])/l1,(b[1]-a[1])/l1);w=((c[0]-b[0])/l2,(c[1]-b[1])/l2)
  angle=math.acos(max(-1,min(1,v[0]*w[0]+v[1]*w[1])))
  if angle<1e-8:out.append(b);continue
  assert angle<math.pi-1e-8
  d=min(radius*math.tan(angle/2),l1*.4,l2*.4);r=d/math.tan(angle/2)
  left=v[0]*w[1]-v[1]*w[0]>0;sgn=1 if left else -1
  entry=(b[0]-v[0]*d,b[1]-v[1]*d);center=(entry[0]-sgn*v[1]*r,entry[1]+sgn*v[0]*r)
  out.append(entry);start=math.atan2(entry[1]-center[1],entry[0]-center[0]);steps=max(1,math.ceil(angle/(math.pi/16)))
  for k in range(1,steps+1):out.append((center[0]+r*math.cos(start+sgn*angle*k/steps),center[1]+r*math.sin(start+sgn*angle*k/steps)))
 out.append(poly[-1]);return [p for i,p in enumerate(out)if i==0 or math.dist(p,out[i-1])>1e-10]
def positive(xbay,yhigh):
 # Preserve the final approach arc (old9..18), all shared copper, and RAM.
 old=pair[names[0]]['path'];g=rounded([old[0],(4.4,yhigh),(xbay,yhigh),(xbay,12.8),(4.415,12.5156)])
 return g+old[10:]
def negative(xleft):
 old=pair[names[1]]['path']
 if xleft==3.6:return old[:]
 # Preserve old compensated lower approach, shared copper and RAM.
 return rounded([old[0],(xleft,13.2),(xleft,12.705454816866),(3.6,12.655454816866014)],.105)+old[3:]
def right_negative(xbay):
 old=pair[names[1]]['path'];prefix=rounded([old[0],(xbay,13.6),(xbay,12.7),old[10]],.11)
 return prefix+old[11:]
def section(n,path):
 old=pair[n]['path'];s,e=rawPair[n]['coupledSection'];suffix=old[s:]
 assert path[-len(suffix):]==suffix
 return [len(path)-len(suffix),len(path)-len(suffix)+e-s]
def check(paths,label,params):
 rr={n:{'layer':'inner1','path':paths[n]}for n in names};joined={**hard,**rr};checks={};sections={}
 for n,r in rr.items():
  old=pair[n]['path'];sections[n]=section(n,r['path']);assert r['path'][0]==old[0]and r['path'][-1]==old[-1]
  scene=ec.Scene('inner1',joined,n);cert=scene.certificate(r['path'],n)
  selftest=u.ns['selfcheck']([u.P(*p)for p in r['path']]);angles=u.angles(r['path']);whole=q.g.length(r['path'])+q.q.fixed[n]
  checks[n]={'physical':cert,'self':selftest,'angles':angles,'wholePlanarLengthMm':whole,'coupledSection':sections[n],'maximumLengthMm':13.2}
  checks[n]['basicPass']=cert['violationCount']==0 and selftest['clear']and angles['allOriginalDirectionDotsPass']and whole<=13.2+1e-9
 skew=abs(checks[names[0]]['wholePlanarLengthMm']-checks[names[1]]['wholePlanarLengthMm']);eligible=all(r['basicPass']for r in checks.values())and skew<=.127+1e-9
 result={'label':label,'parameters':params,'checks':checks,'pairSkewMm':skew,'basicPhysicalSelfAnglesLengthAndPairPass':eligible,'records':[{'sourceTraceId':n,'role':'DDR_BYTE0','class':'DQS0','layer':'inner1','path':[{'x':p[0],'y':p[1]}for p in paths[n]],'coupledSection':sections[n]}for n in names]}
 if eligible:
  coupled={n:ns['coupling'](rr[n]['path'],rr[names[1]if n==names[0]else names[0]]['path'],sections[n])for n in names}
  result['originalDerivedSharedExteriorCoupling']=coupled
  own={n:ec.Scene('inner1',joined,n).exposure(rr[n]['path'],n)for n in names}
  result['ownWholeWireMeters']=own
  result['specializedPairAndOwnMetersPass']=all(v['entireIntervalBoundedPass']for r in coupled.values()for v in r.values())and all(r['absoluteTICapPass']and r['noResetOrIntrinsicPairSpacingException']for r in own.values())
 return result
started=time.monotonic();trials=[]
# The baseline is freshly checked on227/new40, not transplanted225 proof.
trials.append(check({n:pair[n]['path']for n in names},'heldAtomic82Fresh227Baseline',{}))
for x in [4.55,4.65,4.75,4.85]:
 for y in [13.2,13.3]:
  for left in [3.6,3.595]:
   trials.append(check({names[0]:positive(x,y),names[1]:negative(left)},'rightBayPositiveAndLeftNegativeAtomicHead',{'positiveBayX':x,'positiveHighY':y,'negativeColumnX':left}))
for x in [4.6,4.8,5.0]:
 trials.append(check({names[0]:pair[names[0]]['path'],names[1]:right_negative(x)},'bothRightDiagnosticWithFrozenSharedEntry',{'negativeBayX':x}))
good=[t for t in trials[1:]if t.get('specializedPairAndOwnMetersPass')]
report={'scope':'SOURCE_ONLY_ONE_FINITE_ATOMIC_DQS0_CPU_HEAD_FAMILY_LITERAL227_NEW40','materialContextPin':{'path':str(q.CONTEXT),'sha256':sha(q.CONTEXT)},'numericInputPin':q.context['full49NumericInputPin'],'carrierInputPin':q.context['full49CarrierInputPin'],'nativeContextPin':q.context['fullNativeContextPin'],'hard13Pin':{'path':str(HARD),'sha256':sha(HARD)},'frozenAtomic82Pin':{'path':str(PAIR),'sha256':sha(PAIR)},'sceneHelperPin':{'path':str(EP),'sha256':sha(EP)},'originalDerivedFunctionBodySourcePin':{'path':str(SOURCE),'sha256':sha(SOURCE)},'trialCount':len(trials),'trials':trials,'usableChangedAtomicHeadCandidateCount':len(good),'hard13UnchangedAndSource31OtherB0Variables':True,'sharedAndRamPathsHeldExactWithRemappedIndices':True,'all225OriginalPlusReset2Total227MaterialHeld':True,'allActualNumericContactsTopstubsAndTwoOwnedBarrelsHeld':True,'bothCpuAislesClearedClaimed':False,'fullByte0JointOrCohortMatchingClaimed':False,'fullReciprocalHard13AuditPending':True,'referenceReturnAndPlaneCoverageHold':True,'stdlibSeconds':time.monotonic()-started,'SDKSourceCoreNativeApiCadExecuted':False,'all49Accepted':False,'referenceQualified':False,'electricalTimingPassed':False,'fabricationReady':False}
out=HERE/'FINITE_ATOMIC_CPU_HEAD_FORK_REPORT01.json'
with out.open('x')as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'path':str(out),'sha256':sha(out),'trialCount':len(trials),'goodCount':len(good),'wallSeconds':report['stdlibSeconds'],'summary':[{'label':t['label'],'params':t['parameters'],'pass':t.get('specializedPairAndOwnMetersPass',False),'skew':t['pairSkewMm'],'whole':{n:r['wholePlanarLengthMm']for n,r in t['checks'].items()},'rejects':{n:{'physical':r['physical']['violationCount'],'closest':r['physical']['closest'],'self':r['self']['clear'],'angles':r['angles']['allOriginalDirectionDotsPass']}for n,r in t['checks'].items()}}for t in trials]}))
