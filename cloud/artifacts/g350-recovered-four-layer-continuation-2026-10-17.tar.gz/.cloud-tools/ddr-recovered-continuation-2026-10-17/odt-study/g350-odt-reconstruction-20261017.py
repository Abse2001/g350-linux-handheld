"""Fresh standalone stdlib reconstruction, not SDK/source or board acceptance.
Exact input Model328, original numeric pads retained. Reports unresolved geometry.
"""
import copy, json, math, hashlib, collections, pathlib, time
P=pathlib.Path('/tmp/g350-four-body-ca18-strong-self-root-20261017-run328/byte0-result.candidate.json')
PIN='056cac41c6a654b417f6c088d871b8aab41bdaf1bfd42f570acd9dd42d7a09c8'
assert hashlib.sha256(P.read_bytes()).hexdigest()==PIN
BASE=json.loads(P.read_bytes()); p=copy.deepcopy(BASE); f=p['full49FanoutInput']; by={t['connection_name']:t for t in p['carrierTraces']}; L=['top','inner1','inner2','bottom']; start=time.monotonic()
def wire(x,y,layer): return dict(route_type='wire',x=x,y=y,layer=layer,width=.1016)
def via(x,y,a,b): return dict(route_type='via',x=x,y=y,from_layer=a,to_layer=b,layers=L,via_diameter=.4572,via_hole_diameter=.254)
def owner(t):return t.get('connection_name',t.get('source_trace_id',''))
def segments(t):
 return [(i,a,b) for i,(a,b) in enumerate(zip(t['route'],t['route'][1:])) if a['route_type']==b['route_type']=='wire' and a['layer']==b['layer']]
def length(t):return sum(math.hypot(b['x']-a['x'],b['y']-a['y'])for i,a,b in segments(t))
def pt(q):return (q['x'],q['y'])
def pd(q,a,b):
 dx=b[0]-a[0];dy=b[1]-a[1];s=dx*dx+dy*dy;t=0 if not s else max(0,min(1,((q[0]-a[0])*dx+(q[1]-a[1])*dy)/s));return math.hypot(q[0]-a[0]-t*dx,q[1]-a[1]-t*dy)
def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def sd(a,b,c,d):
 if cross(a,b,c)*cross(a,b,d)<-1e-20 and cross(c,d,a)*cross(c,d,b)<-1e-20:return 0.
 return min(pd(a,c,d),pd(b,c,d),pd(c,a,b),pd(d,a,b))
def rectdist(a,b,o):
 x,y=o['center']['x'],o['center']['y'];w,h=o['width']/2,o['height']/2;cs=[(x-w,y-h),(x+w,y-h),(x+w,y+h),(x-w,y+h)]
 if any(x-w<=q[0]<=x+w and y-h<=q[1]<=y+h for q in[a,b]):return 0.
 return min(sd(a,b,cs[i],cs[(i+1)%4])for i in range(4))
def mats(t):
 n=owner(t);z=[]
 for i,a,b in segments(t):z.append(dict(kind='wire',owner=n,id=t['pcb_trace_id'],index=i,layers=[a['layer']],a=pt(a),b=pt(b),r=max(a['width'],b['width'])/2))
 for i,q in enumerate(t['route']):
  if q['route_type']=='via':z.append(dict(kind='via',owner=n,id=t['pcb_trace_id'],index=i,layers=q['layers'],a=pt(q),b=pt(q),r=q['via_diameter']/2,hole=q['via_hole_diameter']/2))
 return z
oldby={n:copy.deepcopy(t)for n,t in by.items()}; oldf=copy.deepcopy(f)
by['source_trace_0']['route']=[wire(x,y,'inner1')for x,y in[(-1.6,12.8),(-1.2,13.2),(-1.2,16.2),(-1,16.4),(-.6,16.4),(-.4,16.6),(-.4,20.2),(-.2,20.4),(1,20.4),(1.2,20.2),(1.2,16.4),(1.58,16.02)]]+[via(1.58,16.02,'inner1','inner2')]+[wire(x,y,'inner2')for x,y in[(1.58,16.02),(1.19,15.63),(1.19,14.79),(1.58,14.4)]]+[via(1.58,14.4,'inner2','bottom')]+[wire(x,y,'bottom')for x,y in[(1.58,14.4),(1.194,14.014),(.6012,14.014),(.3872,13.8),(.3872,11.0628),(.4,11.05)]]
by['source_trace_18']['route']=copy.deepcopy(oldby['source_trace_18']['route'][:1])+[wire(x,y,'inner1')for x,y in[(-1.6,18.4),(-1.2,18.8),(-1.2,19.6),(-1.58,19.98),(-1.58,20.95),(-1.78,21.15),(-1.8176,21.15),(-2.0176,20.95)]]+copy.deepcopy(oldby['source_trace_18']['route'][5:])
t=by['source_trace_11'];t['route']=t['route'][:2]+[wire(.95,14.0156,'inner2'),wire(.98,13.9856,'inner2'),wire(1.7624,13.9856,'inner2')]+t['route'][3:]
t=by['source_trace_2'];t['route'][5]['x']=1.22;t['route'][5]['y']=9.72;t['route'][6]['x']=1.22;t['route'][7]['x']=1.22;t['route'][8]['x']=1.22;t['route'][9]['y']=9.02;t['route'][10]['y']=8.48;t['route'][11]['x']=2.3128
branchInverses=[]
for n in [0,42]:
 t=next(t for t in f['traces']if t['pcb_trace_id']==f'local_dogbone_source_trace_{n}_1');before=copy.deepcopy(t)
 if n==0:
  t['route']=t['route'][:2]+[wire(.4,11.05,'top'),via(.4,11.05,'top','bottom'),wire(.4,11.05,'bottom')]
 else:
  t['route']=[wire(1.6,9,'top'),wire(1.625,9,'top'),wire(2.025,8.6,'top'),via(2.025,8.6,'top','bottom'),wire(2.025,8.6,'bottom')]
 branchInverses.append(dict(owner=f'source_trace_{n}',before=before,after=copy.deepcopy(t)))
 c=next(c for c in f['connections']if c['name']==f'source_trace_{n}');c['pointsToConnect'][1]={'x':.4 if n==0 else 2.025,'y':11.05 if n==0 else 8.6,'layer':'bottom'}
def buildobjects(excluded_bodies=(),excluded_refs=(),excluded_obstacles=()):
 out=[]
 for t in [*by.values(),*f['traces']]:
  if owner(t) in excluded_bodies and t in by.values():continue
  if t['pcb_trace_id'] in excluded_refs:continue
  out+=mats(t)
 for o in f['obstacles']:
  if o['obstacleId']in excluded_obstacles:continue
  ns=[n for n in o.get('connectedTo',[])if n.startswith('source_trace_')];n=','.join(ns);a=pt(o['center']);z=dict(kind='circle'if o.get('shape')=='circle'else'rect',owner=n,id=o['obstacleId'],index=None,layers=o['layers'],a=a,b=a,r=o['width']/2,obstacle=o)
  if o['obstacleId'].startswith('pcb_via_'):z['kind']='via';z['hole']=.127
  out.append(z)
 for o in out:
  o['bbox']=(min(o['a'][0],o['b'][0])-o['r'],max(o['a'][0],o['b'][0])+o['r'],min(o['a'][1],o['b'][1])-o['r'],max(o['a'][1],o['b'][1])+o['r']) if o['kind']!='rect'else(o['a'][0]-o['obstacle']['width']/2,o['a'][0]+o['obstacle']['width']/2,o['a'][1]-o['obstacle']['height']/2,o['a'][1]+o['obstacle']['height']/2)
 return out
def contacts(t,objects,guidance=False):
 out=[];n=owner(t);classes={n:b['busId']for b in f['buses']for n in b['connectionNames']}
 for a in mats(t):
  for o in objects:
   if o['owner'] and n in o['owner'].split(','):continue
   if not set(a['layers']).intersection(o['layers']):continue
   if guidance:
    if a['kind']!='wire'or o['kind']!='wire'or o['owner']not in classes:continue
    need=.3048 if classes[n]==classes[o['owner']]else.4064
   else:need=a['r']+o['r']+.1016
   bb=o['bbox'];pad=need+max(0,a['r']);
   if min(a['a'][0],a['b'][0])-pad>bb[1]or max(a['a'][0],a['b'][0])+pad<bb[0]or min(a['a'][1],a['b'][1])-pad>bb[3]or max(a['a'][1],a['b'][1])+pad<bb[2]:continue
   if o['kind']=='rect':d=rectdist(a['a'],a['b'],o['obstacle'])+o['r']
   else:d=sd(a['a'],a['b'],o['a'],o['b'])
   if not guidance:
    # Honor recorded .2 trace-to-drill boundary as well as .1016 copper spacing.
    if o.get('hole') and a['kind']=='wire':need=max(need,a['r']+o['hole']+.2)
    if a.get('hole') and o['kind']=='wire':need=max(need,o['r']+a['hole']+.2)
   if d<need-1e-8:out.append(dict(segment=a['index'],kind=a['kind'],layerIntersection=sorted(set(a['layers']).intersection(o['layers'])),otherOwner=o['owner'],otherId=o['id'],otherIndex=o['index'],otherKind=o['kind'],centerDistanceMm=d,requiredMm=need,shortfallMm=need-d))
 return out
def runs(t):
 out=[];cur=[]
 for q in t['route']:
  if q['route_type']=='wire':
   if cur and q['layer']!=cur[-1]['layer']:out.append(cur);cur=[]
   cur.append(q)
  else:
   if len(cur)>1:out.append(cur)
   cur=[]
 if len(cur)>1:out.append(cur)
 return out
def self_math(ps,required=.2032):
 cumulative=[0];turning=[0];unsafe=[0];bad=[];near=[]
 for i in range(1,len(ps)-1):
  a=(ps[i]['x']-ps[i-1]['x'],ps[i]['y']-ps[i-1]['y']);b=(ps[i+1]['x']-ps[i]['x'],ps[i+1]['y']-ps[i]['y']);cr=abs(a[0]*b[1]-a[1]*b[0]);angle=abs(math.atan2(a[0]*b[1]-a[1]*b[0],a[0]*b[0]+a[1]*b[1]));radius=math.inf if cr<1e-12 else math.hypot(*a)*math.hypot(*b)*math.dist(pt(ps[i-1]),pt(ps[i+1]))/(2*cr);turning.append(turning[-1]+angle);unsafe.append(unsafe[-1]+int(angle>math.pi/8+1e-8 or radius<required/2-1e-8))
 for a,b in zip(ps,ps[1:]):cumulative.append(cumulative[-1]+math.dist(pt(a),pt(b)))
 for i in range(len(ps)-1):
  for j in range(i+2,len(ps)-1):
   a,b,c,d=ps[i],ps[i+1],ps[j],ps[j+1];sep=sd(pt(a),pt(b),pt(c),pt(d))
   if sep>=required-1e-8:continue
   gap=cumulative[j]-cumulative[i+1];row={'segments':[i,j],'separationMm':sep,'gapMm':gap}
   if sep<1e-9 and gap>1e-8:row['reason']='nonadjacent_intersection';bad.append(row);continue
   if gap<=math.pi*required+1e-8 and(turning[j]-turning[i]<=math.pi/2+1e-8 or(turning[j]-turning[i]<=math.pi+1e-8 and unsafe[j]==unsafe[i])):row['reason']='contiguous_corner';near.append(row);continue
   sx=sy=0;okay=True
   for k in range(i,j+1):
    dx=ps[k+1]['x']-ps[k]['x'];dy=ps[k+1]['y']-ps[k]['y']
    for delta,axis in[(dx,'x'),(dy,'y')]:
     if abs(delta)<=1e-8:continue
     sign=1 if delta>0 else -1
     if axis=='x':
      if sx and sx!=sign:okay=False
      sx=sign
     else:
      if sy and sy!=sign:okay=False
      sy=sign
   row['reason']='monotone_contiguous_copper'if okay else'returning_arm_too_close';(near if okay else bad).append(row)
 return dict(requiredCenterlineMm=required,passedPureMath=not bad,failures=bad,allowedCloseLocalCornerPairs=near)
def newguidance(t,rows):
 old=oldby.get(owner(t));oldkeys={json.dumps([a,b],sort_keys=True)for i,a,b in segments(old)}if old else set()
 newindices={i for i,a,b in segments(t)if json.dumps([a,b],sort_keys=True)not in oldkeys}
 return [r for r in rows if r['segment']in newindices]
def report():
 objects=buildobjects();changed=[0,18,2,11];rows=[]
 for n in changed:
  t=by[f'source_trace_{n}'];g=contacts(t,objects,True);rows.append(dict(owner=owner(t),bodyMm=length(t),wholeMm=length(t)+sum(length(x)for x in f['traces']if owner(x)==owner(t)),contacts=contacts(t,objects),guidance=g,newWireGuidanceContacts=newguidance(t,g),selfReports=[dict(layer=run[0]['layer'],native=self_math(run),preferred3W=self_math(run,.3048))for run in runs(t)]))
 branches=[]
 for iv in branchInverses:branches.append(dict(owner=iv['owner'],contacts=contacts(iv['after'],objects),guidance=contacts(iv['after'],objects,True)))
 cohorts=[]
 for bus in f['buses']:
  vals=[dict(owner=n,wholeMm=length(by[n])+sum(length(t)for t in f['traces']if owner(t)==n))for n in bus['connectionNames']];cohorts.append(dict(busId=bus['busId'],values=vals,skewMm=max(v['wholeMm']for v in vals)-min(v['wholeMm']for v in vals)))
 partialObjects=buildobjects(excluded_bodies=['source_trace_42'],excluded_refs=['pcb_trace_134','pcb_trace_135','pcb_trace_215'],excluded_obstacles=['pcb_via_32'])
 partialRows=[dict(owner=owner(by[f'source_trace_{n}']),contacts=contacts(by[f'source_trace_{n}'],partialObjects),newWireGuidanceContacts=newguidance(by[f'source_trace_{n}'],contacts(by[f'source_trace_{n}'],partialObjects,True)))for n in changed]
 R=dict(scope='FRESH_MODEL328_RECONSTRUCTED_0_18_2_11_AND_RAM0_RAM42_INVERSES_UNACCEPTED_INCOMPLETE42_NO_SDK',inputPath=str(P),inputSha256=PIN,bodyInverses=[dict(owner=f'source_trace_{n}',before=oldby[f'source_trace_{n}'],after=by[f'source_trace_{n}'])for n in changed],branchInverses=branchInverses,requestInverses=[dict(owner=c['name'],before=next(a for a in oldf['connections']if a['name']==c['name']),after=c)for c in f['connections']if c!=next(a for a in oldf['connections']if a['name']==c['name'])],bodyRows=rows,branchRows=branches,cohorts=cohorts,partialHypotheticalScene=dict(explicitlyOmittedBodyOwners=['source_trace_42'],explicitlyOmittedPdnBarrel='pcb_via_32',explicitlyOmittedReferenceIds=['pcb_trace_134','pcb_trace_135','pcb_trace_215'],rows=partialRows,notComplete49AndNotAccepted=True),source42OriginalBodyStillPresentButIncompatibleNewEndpoint=True,all49Accepted=False,sourceCoreDerived=False,nativeExecuted=False,timingPassed=False,fabricationReady=False,elapsedSeconds=time.monotonic()-start)
 O=pathlib.Path('/tmp/g350-odt-reconstruction-20261017-report.json');O.write_text(json.dumps(R,indent=2)+'\n');print(json.dumps(dict(path=str(O),sha256=hashlib.sha256(O.read_bytes()).hexdigest(),rows=[dict(owner=z['owner'],wholeMm=z['wholeMm'],nativeContacts=len(z['contacts']),guidanceContacts=len(z['guidance']),foreignOwners=collections.Counter(x['otherOwner']for x in z['contacts']))for z in rows],branches=[dict(owner=z['owner'],contacts=len(z['contacts']),owners=collections.Counter(x['otherOwner']for x in z['contacts']))for z in branches],cohorts=[dict(busId=z['busId'],skewMm=z['skewMm'])for z in cohorts],elapsedSeconds=R['elapsedSeconds'])))
 return R
if __name__=='__main__':report()
