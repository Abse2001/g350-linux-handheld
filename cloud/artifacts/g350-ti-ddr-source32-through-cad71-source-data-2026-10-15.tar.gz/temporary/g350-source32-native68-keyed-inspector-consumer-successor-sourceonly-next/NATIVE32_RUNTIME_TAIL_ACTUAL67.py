 assert out.parent==Path('/tmp')and out.name.startswith('g350-source32-native-root-')and out.resolve()==out and not out.exists()and not out.is_symlink()
 with(ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  prior=closed67();assert prior['actualClosedScopeCount']==native32_contract['requiredPriorScopeCount']==67
  identity_before=guard_identity();_,native_before,board_before,solver_before,_=c.guard.checked();native32_bindings();git_before=git_inventory();assert git_before==base['gitMetadataFiles']
  assert board_before['treeSha256']==stage['boardSdkTreeSha256']and solver_before['treeSha256']==stage['solverSdkTreeSha256']
  workspace_floor=shutil.disk_usage('/workspace').free;out.mkdir(mode=0o700);(out/'bun-cache').mkdir(mode=0o700);(out/'tmp').mkdir(mode=0o700);output=out/'output';output.mkdir(mode=0o700)
  report=output/'native32-report.json';bound_path=out/'BOUND-manifest.json';ap=out/'ROOT_AUTHORITY.json'
  artifacts=dict(actualCorePath=proposal['actual67CoreRawPin']['path'],actualCoreSha256=proposal['actual67CoreRawPin']['sha256'],coreControlsPath=proposal['actual67CoreControlsPin']['path'],coreControlsSha256=proposal['actual67CoreControlsPin']['sha256'])
  manifest=json.loads(json.dumps(native32_template));manifest.update(coreSourceManifestSha256=proposal['promoted32ManifestPin']['sha256'],genuineSource32ManifestSha256=proposal['promoted32ManifestPin']['sha256'],source32ProposalPath=proposal['promoted32ProposalPin']['path'],source32ProposalSha256=proposal['promoted32ProposalPin']['sha256'],originalSource32ProposalSha256=proposal['promoted32ProposalPin']['sha256'],scope='ROOT_ONE_ACTUAL_SOURCE32_CORE297_NATIVE18_AFTER_THREE_STAGE_BATCH67',status='ROOT_BOUND_ACTUAL_SOURCE32_NATIVE18_STAGE',sourceManifestSha256=proposal['native32PreparationPin']['sha256'],actualFreshArtifacts=artifacts,actualSource32BatchRootCollection=proposal['actual67CollectionPin'],actualSource32BatchPostaudit=proposal['actual67PostauditPin'])
  verified={}
  for doc in(proposal,native32_preparation,native32_template,promoted32,data32,read(proposal['actual67CollectionPin']['path']),read(proposal['actual67PostauditPin']['path'])):
   for row in rows(doc):
    row={k:row[k]for k in('path','sha256','bytes','mode')};assert row['path']not in verified or verified[row['path']]==row;binding(row);verified[row['path']]=row
  for row in promoted32['expandedHeldSourceAndControllerClosure']:assert row['path']in verified
  local={row['path']for row in native32_template['files']};assert len(local)==3 and native32_contract['workerPin']['path']in local
  manifest['files']=[verified[row['path']]for row in native32_template['files']];manifest['externalFiles']=[verified[p]for p in sorted(verified)if p not in local]
  assert manifest['coreSourceManifestSha256']==proposal['promoted32ManifestPin']['sha256']and manifest['source32ProposalSha256']==proposal['promoted32ProposalPin']['sha256']
  write(bound_path,manifest);bound_sha=sha(bound_path)
  authority=dict(authorizedByRoot=True,scope=manifest['scope'],packetSha256=bound_sha,rootFullGuardReadPassed=True,noConcurrentRootWorker=True,sourceManifestSha256=proposal['native32PreparationPin']['sha256'],coreSourceManifestSha256=proposal['promoted32ManifestPin']['sha256'],freshArtifacts=artifacts,rootGuardProposalManifestSha256=source_sha,peerReviewPath=str(peer_path),peerReviewSha256=peer_sha,actualClosedPriorScopes=prior,actualSource32BatchRootCollection=proposal['actual67CollectionPin'],policy=policy32,nonce=secrets.token_hex(32),Source32Accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingQualified=False,fabricationReady=False)
  write(ap,authority);authority_sha=sha(ap)
  command=[str(c.BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),'--smol',native32_contract['workerPin']['path'],str(bound_path),bound_sha,str(ap),authority_sha,str(report)]
  environment={'NO_COLOR':'1','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(out/'bun-cache'),'TMPDIR':str(out/'tmp'),'G350_SOURCE20_SOURCE21_AND45_INTERMEDIATE_32_FRESH_NATIVE_APPROVED':'1'}
  def invariant_check():
   native32_bindings();no_git_redirects();assert closed67()==prior and guard_identity()==identity_before and sha(ap)==authority_sha and sha(bound_path)==bound_sha and git_inventory()==git_before and shutil.disk_usage('/workspace').free>=workspace_floor
  def prefork(memory):
   invariant_check();assert memory['current']+policy32['rssBytes']+1073741824<policy32['sharedBytes']and shutil.disk_usage('/tmp').free>=536870912
  execution=None;run_error=post_error=inspection_error=None;native_after=board_after=solver_after=None;result=None;result_passed=False;empty=None
  try:execution=focused_process_runner.run_guarded(command,str(c.BOARD),out/'owned',policy32,environment,before_spawn=prefork)
  except BaseException as error:
   run_error=type(error).__name__+': '+str(error)
   try:
    if(out/'owned/execution.json').is_file():execution=read(out/'owned/execution.json')
   except BaseException as parse_error:run_error+='; execution recovery '+type(parse_error).__name__+': '+str(parse_error)
  try:
   _,native_after,board_after,solver_after,_=c.guard.checked();invariant_check();assert native_before==native_after and board_before==board_after and solver_before==solver_after
  except BaseException as error:post_error=type(error).__name__+': '+str(error)
  held=post_error is None and native_before==native_after and board_before==board_after and solver_before==solver_after
  try:
   assert isinstance(execution,dict);pgid=execution['pgid'];empty=c.guard.process_scope.owned(pgid)==[]
  except BaseException as error:inspection_error='Owned scope '+type(error).__name__+': '+str(error)
  natural=bool(isinstance(execution,dict)and type(execution.get('exitCode'))is int and execution['exitCode']>=0 and execution.get('diagnosticStopped')is False and not execution.get('stopReasons')and execution.get('cleanupOwnedGroupEmpty')is True and isinstance(execution.get('oomDelta'),dict)and bool(execution['oomDelta'])and not any(execution['oomDelta'].values())and empty is True)
  try:
   assert held and run_error is post_error is inspection_error is None and natural and execution['exitCode']in(0,1);h.finite(execution,execution['exitCode']);assert execution['policy']==policy32 and execution['command']==command and execution['currentGuardPid']==identity_before['pid']and guard_identity()==identity_before and 'guardError'not in execution
   assert {p.name for p in output.iterdir()}=={'native32-report.json'};result=read_bounded(report,16777216)
   assert result['scope']=='ACTUAL_FRESH_SOURCE32_CORE297_NATIVE18_WITH_TWO_EXPLICIT_CARRIER_VIAS'and result['packetSha256']==bound_sha and result['sourceManifestSha256']==proposal['native32PreparationPin']['sha256']
   assert result['actualCorePath']==artifacts['actualCorePath']and result['actualCoreSha256']==artifacts['actualCoreSha256']and result['actualCoreControlsSha256']==artifacts['coreControlsSha256']and result['coreSourceManifestSha256']==proposal['promoted32ManifestPin']['sha256']and result['originalSource32ProposalSha256']==proposal['promoted32ProposalPin']['sha256']
   assert result['checkCount']==len(result['counts'])==18 and not any(result['counts'].values())and result['physicalErrors']==0 and result['actualNativePairFindings']==[]and result['physicalCpuRamConnectedCarrierCount']==32 and result['expectedMissingOriginalSignalCount']==17
   proof=result['actualOwnershipProof'];assert len(proof['signalMappings'])==98 and len(proof['referenceMappings'])==165 and len(proof['carriers'])==32 and all(x['actualSourceOwnedPhysicalGraph']['physicallyConnected']is x['actualSourceOwnedPhysicalGraph']['logicalMapAloneNotUsed']is True for x in proof['carriers'])
   assert len(proof['intermediateCarrierMappings'])==2 and {x['originalSourceTraceId']for x in proof['intermediateCarrierMappings']}=={'source_trace_20','source_trace_21'}
   for key in('all165ReferencePathsPreserved','all129ReferenceBarrelsPreserved','all98SignalBarrelsAndSource32TopStubsProved','source14RamBarrelAndTopStubChangedOnlyAsExplicitlyProposed','source3CpuBarrelAndFourPointTopStubChangedOnlyAsExplicitlyProposed','source27And28CarriersChangedOnlyAsExplicitlyProposed','source7RamBarrelAndThirteenPointTopStubChangedOnlyAsExplicitlyProposed','resetEightVertexCarrierRepairExplicit','all25OtherParent26CarriersExact','all49OriginalLogicalNumericRequestsPreserved','rawCircuitUnmodified','onlyAuthenticRam25Hs8PadAndStripContactRegistered','originalAll3CouplingApisAgainstActualGeometryRequiredSeparately','noCoreRenderPerformed','noRoutingPerformed','noCliOrCadPerformed','full49RoutesUnfinished','source45AdditionalThreePathCarrierStrictlyProved','onlySource20And21FourPathGraphsProved','newTwoIntermediateViasPrivatelyRegisteredAfterGraphProof','raw229PhysicalBarrelsAccounted'):assert result[key]is True
   for key in('circuitJsonGeometryOrIdentitiesEdited','sourceNetFabricationPerformed','globalSameNetManufacturingExemption','fullCohortTimingPassed','electricalTimingQualified','referenceQualified','complete32Accepted','accepted49','fabricationReady'):assert result[key]is False
   result_passed=bool(natural and execution['exitCode']==0)
  except BaseException as error:inspection_error=(inspection_error+'; 'if inspection_error else'')+type(error).__name__+': '+str(error)
  files=[]
  for path in sorted([*out.iterdir(),*output.iterdir()]):
   if path.is_file()and not path.is_symlink():files.append(file_row(path))
  post=dict(scope='ROOT_SOURCE32_NATIVE18_WITH_AUTHENTIC_67_THREE_STAGE_PRIOR_CLOSURES',phase='native',sourceManifestSha256=proposal['native32PreparationPin']['sha256'],rootGuardProposalManifestSha256=source_sha,packetSha256=bound_sha,execution=execution,actualClosedPriorScopes=prior,sourceAndDependenciesHeld=held,dependenciesBefore=board_before,dependenciesAfter=board_after,solverDependenciesBefore=solver_before,solverDependenciesAfter=solver_after,runFailure=run_error,postverificationFailure=post_error,resultInspectionFailure=inspection_error,ownedGroupEmptyActuallyObserved=empty,stageNaturallyCompleted=natural,ownedChildNatural0=natural and execution['exitCode']==0,resultPassed=result_passed,passed=result_passed,passedMeansNative18AndActual32NumericPhysicalGraphsOnly=True,coreSourceManifestSha256=proposal['promoted32ManifestPin']['sha256'],actualCorePath=artifacts['actualCorePath'],actualCoreSha256=artifacts['actualCoreSha256'],actualCoreControlsPath=artifacts['coreControlsPath'],actualCoreControlsSha256=artifacts['coreControlsSha256'],reportPath=str(report),reportSha256=sha(report)if report.is_file()and not report.is_symlink()else None,boundManifestPath=str(bound_path),boundManifestSha256=bound_sha,baseline169SourceHeld=held,expandedSourceWorkerControllerClosureCount=191,CoreCalls=0,nativeCalls=18 if isinstance(result,dict)and result.get('checkCount')==18 else None,originalApiCalls=0,cliCalls=0,cadCalls=0,typesExecuted=False,coreRendered=False,nativeExecuted=isinstance(execution,dict)and type(execution.get('pgid'))is int,Source32Accepted=False,newRoutesAdopted=0,hardwareAcceptanceCheckpointUnchanged=True,referenceQualified=False,electricalTimingPassed=False,fixReleaseQualificationPassed=False,originalAll11AcceptanceClaimed=False,all49Accepted=False,accepted49=False,fabricationReady=False,workspaceFreeBytesBefore=workspace_floor,workspaceFreeBytesFloorHeld=post_error is None,gitMetadataHeld=post_error is None,outputFiles=files,toolSessionCollected=False)
  pp=out/'POSTAUDIT.json';write(pp,post);print(json.dumps(dict(passed=result_passed,phase='native',postauditPath=str(pp),postauditSha256=sha(pp),execution=execution)))
 return 0 if result_passed else 2

if __name__=='__main__':raise SystemExit(main())
