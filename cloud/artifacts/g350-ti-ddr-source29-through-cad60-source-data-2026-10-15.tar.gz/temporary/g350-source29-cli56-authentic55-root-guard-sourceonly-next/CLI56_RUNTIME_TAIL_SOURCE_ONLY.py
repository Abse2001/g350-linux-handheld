 assert out.parent==Path('/tmp')and out.name.startswith('g350-source29-cli-root-')and out.resolve()==out and not out.exists()and not out.is_symlink()
 with(ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  prior=closed55();assert prior['actualClosedScopeCount']==cli29_contract['requiredPriorScopeCount']==55
  identity_before=guard_identity();_,native_before,board_before,solver_before,_=c.guard.checked();bindings();git_before=git_inventory();assert git_before==base['gitMetadataFiles']
  assert board_before['treeSha256']==stage['boardSdkTreeSha256']and solver_before['treeSha256']==stage['solverSdkTreeSha256']
  workspace_floor=shutil.disk_usage('/workspace').free;out.mkdir(mode=0o700);(out/'bun-cache').mkdir(mode=0o700);(out/'tmp').mkdir(mode=0o700);output=out/'output';output.mkdir(mode=0o700)
  authority={**cli29_preparation['actualPrerequisites'],'authorizedByRoot':True,'scope':cli29_preparation['scope'],'sourceManifestSha256':proposal['cli29PreparationPin']['sha256'],'genuineSourceManifestSha256':proposal['promoted29ManifestPin']['sha256'],'actualNativeSourceManifestSha256':proposal['native29PreparationPin']['sha256'],'actualApiSourceManifestSha256':proposal['native29PreparationPin']['sha256'],'actualPreviousScopesCollectedAndEmpty':True,'noConcurrentRootWorker':True,'rootFullWorkerReadPassed':True,'rootGuardProposalManifestSha256':source_sha,'actualClosedPriorScopes':prior,'outputDirectory':str(output),'policy':cli29_policy,'nonce':secrets.token_hex(32),'all49Accepted':False,'fabricationReady':False}
  ap=out/'ROOT_AUTHORITY.json';write(ap,authority);authority_sha=sha(ap)
  command=[cli29_contract['pythonInterpreterPin']['path'],'-B',cli29_contract['cliWorkerPin']['path'],'--root-receipt',str(ap),'--root-receipt-sha256',authority_sha,'--output-directory',str(output)]
  environment={'NO_COLOR':'1','GIT_OPTIONAL_LOCKS':'0','GIT_NO_REPLACE_OBJECTS':'1','BUN_RUNTIME_TRANSPILER_CACHE_PATH':str(out/'bun-cache'),'TMPDIR':str(out/'tmp'),'G350_SOURCE29_FRESH_JSON_CLI_ROOT_GUARDED':'1'}
  def invariant_check():
   bindings();no_git_redirects();assert closed55()==prior and guard_identity()==identity_before and sha(ap)==authority_sha and git_inventory()==git_before and shutil.disk_usage('/workspace').free>=workspace_floor
  def prefork(memory):
   invariant_check();assert memory['current']+cli29_policy['rssBytes']+1073741824<cli29_policy['sharedBytes']and shutil.disk_usage('/tmp').free>=536870912
  execution=None;run_error=post_error=inspection_error=None;native_after=board_after=solver_after=None;result=None;result_passed=False;empty=None
  try:execution=process_runner.run_guarded(command,str(c.BOARD),out/'owned',cli29_policy,environment,before_spawn=prefork)
  except BaseException as error:
   run_error=type(error).__name__+': '+str(error)
   try:
    if(out/'owned/execution.json').is_file():execution=read(out/'owned/execution.json')
   except BaseException as parse_error:run_error+='; execution recovery '+type(parse_error).__name__+': '+str(parse_error)
  try:
   _,native_after,board_after,solver_after,_=c.guard.checked();invariant_check();assert native_before==native_after and board_before==board_after and solver_before==solver_after
  except BaseException as error:post_error=type(error).__name__+': '+str(error)
  held=post_error is None and native_before==native_after and board_before==board_after and solver_before==solver_after
  try:
   assert isinstance(execution,dict);empty=c.guard.process_scope.owned(execution['pgid'])==[]
  except BaseException as error:inspection_error='Owned scope '+type(error).__name__+': '+str(error)
  natural=bool(isinstance(execution,dict)and type(execution.get('exitCode'))is int and execution['exitCode']>=0 and execution.get('diagnosticStopped')is False and not execution.get('stopReasons')and execution.get('cleanupOwnedGroupEmpty')is True and isinstance(execution.get('oomDelta'),dict)and bool(execution['oomDelta'])and not any(execution['oomDelta'].values())and empty is True)
  report=output/'cli-export-report.json';export=output/'g350-source29.kicad_pcb'
  try:
   assert held and run_error is post_error is inspection_error is None and natural and execution['exitCode']in(0,1,2);h.finite(execution,execution['exitCode']);assert execution['policy']==cli29_policy and execution['command']==command and execution['currentGuardPid']==identity_before['pid']and guard_identity()==identity_before and 'guardError'not in execution
   assert {p.name for p in output.iterdir()}=={'fresh-source29.circuit.json','g350-source29.kicad_pcb','pinned-cli.log','cli-export-report.json'}
   for path,limit in((report,4194304),(export,33554432),(output/'fresh-source29.circuit.json',16777216),(output/'pinned-cli.log',4194304)):assert path.is_file()and not path.is_symlink()and 0<=path.stat().st_size<=limit
   result=read(report);assert result['scope']==cli29_preparation['scope']and result['sourceManifestSha256']==proposal['cli29PreparationPin']['sha256']and result['actualCoreSha256']==proposal['actual53CoreRawPin']['sha256']and result['coreControlsSha256']==proposal['actual53CoreControlsPin']['sha256']
   assert result['exportPassed']is True and result['cliExitCode']==0 and result['byteIdenticalCopyOnly']is True and result['recognizedCircuitJsonSha256']==proposal['actual53CoreRawPin']['sha256']and sha(output/'fresh-source29.circuit.json')==proposal['actual53CoreRawPin']['sha256']
   assert result['outputPath']==str(export)and result['outputSha256']==sha(export)and export.stat().st_size>0 and result['actualSourceSegmentCount']==1053 and result['actualSourceOwnedCarrierCount']==29 and result['actualPhysicalViaCount']==227 and result['actualPhysicalTraceCount']==292 and result['sourceOnlyMissingRoutes']==20
   assert result['nativeAndOriginalApiStagesPassed']is True and result['actualNativeReport']==cli29_preparation['actualPrerequisites']['actualNativeReport']==proposal['actual54ReportPin']and result['actualOriginalApiReport']==cli29_preparation['actualPrerequisites']['actualOriginalApiReport']==proposal['actual55ApiReportPin']
   assert result['argv']==[cli29_preparation['bun'],'--smol',cli29_preparation['cliMainPath'],'export',str(output/'fresh-source29.circuit.json'),'--format','kicad_pcb','--output',str(export),'--disable-parts-engine']
   for key in('originalRawEdited','sourceModuleEvaluated','sourcePortHookReplayedByCli','automaticCoreSrjUsed','complete29Accepted','referenceQualified','electricalTimingQualified','accepted49','fabricationReady'):assert result[key]is False
   result_passed=bool(natural and execution['exitCode']==0)
  except BaseException as error:inspection_error=(inspection_error+'; 'if inspection_error else'')+type(error).__name__+': '+str(error)
  files=[file_row(p)for p in sorted([*out.iterdir(),*output.iterdir()])if p.is_file()and not p.is_symlink()]
  post=dict(scope='ROOT_SOURCE29_FRESH_PINNED_CLI_WITH55_AUTHENTIC_PRIOR_CLOSURES',phase='cli',sourceManifestSha256=proposal['cli29PreparationPin']['sha256'],rootGuardProposalManifestSha256=source_sha,execution=execution,actualClosedPriorScopes=prior,sourceAndDependenciesHeld=held,dependenciesBefore=board_before,dependenciesAfter=board_after,solverDependenciesBefore=solver_before,solverDependenciesAfter=solver_after,runFailure=run_error,postverificationFailure=post_error,resultInspectionFailure=inspection_error,ownedGroupEmptyActuallyObserved=empty,stageNaturallyCompleted=natural,ownedChildNatural0=natural and execution['exitCode']==0,resultPassed=result_passed,passed=result_passed,reportPath=str(report),reportSha256=sha(report)if report.is_file()and not report.is_symlink()else None,exportPath=str(export),exportSha256=sha(export)if export.is_file()and not export.is_symlink()else None,actualCoreSha256=proposal['actual53CoreRawPin']['sha256'],actualCoreControlsSha256=proposal['actual53CoreControlsPin']['sha256'],CoreCalls=0,nativeCalls=0,originalApiCalls=0,cliCalls=1 if isinstance(result,dict)else None,cadCalls=0,Source29Accepted=False,hardwareAcceptanceCheckpointUnchanged=True,newRoutesAdopted=0,referenceQualified=False,electricalTimingPassed=False,all49Accepted=False,accepted49=False,fabricationReady=False,workspaceFreeBytesBefore=workspace_floor,workspaceFreeBytesFloorHeld=post_error is None,gitMetadataHeld=post_error is None,outputFiles=files,toolSessionCollected=False)
  pp=out/'POSTAUDIT.json';write(pp,post);print(json.dumps(dict(passed=result_passed,phase='cli',postauditPath=str(pp),postauditSha256=sha(pp),execution=execution)))
 return 0 if result_passed else 2

if __name__=='__main__':raise SystemExit(main())
