"""Root-only readonly correction of a failed outer metadata count assumption."""
import argparse,hashlib,json,re,stat,sys
from pathlib import Path
import inventory,process_scope,python_inventory
ROOT=Path(__file__).resolve().parent
BOARD=Path('/workspace/g350-linux-handheld')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def require(v,s):
 if not v:raise ValueError(s)
def checked():
 m=read(ROOT/'PREPARED-manifest.json')
 for key,base in [('files',ROOT),('externalFiles',None)]:
  for row in m[key]:
   p=base/row['path'] if base else Path(row['path'])
   require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Frozen member changed: '+str(p))
 resolver=ROOT/'source/node_modules';require(resolver.is_symlink() and str(resolver.readlink())==str(BOARD/'node_modules'),'Exact pinned resolver required')
 listed={r['path'] for r in m['files']}
 for name in ('.pnp.cjs','.pnp.loader.mjs','.yarn','node_modules'):
  child=Path(m['all101SourceDirectory'])/name
  require(not child.exists() and not child.is_symlink(),'Unexpected package101 resolver shadow')
 for p in (ROOT/'source').rglob('*'):
  if p.is_symlink():require(p==resolver,'Unexpected source symlink');continue
  if p.is_file():require(p.relative_to(ROOT).as_posix() in listed,'Unexpected source mutation/artifact')
 for base in (ROOT,ROOT.parent,ROOT/'source'):
  for name in ('.pnp.cjs','.pnp.loader.mjs','.yarn'):require(not(base/name).exists() and not(base/name).is_symlink(),'Unexpected resolver shadow')
 require(not(ROOT/'node_modules').exists() and not(ROOT/'node_modules').is_symlink(),'Unexpected local resolver')
 deps=inventory.tree(BOARD/'node_modules');small={k:deps[k] for k in ('treeSha256','regularFiles','regularBytes','symlinks','directories')}
 require(small==m['boardDependencyInventory'],'Complete pinned dependency tree changed')
 numerical=python_inventory.snapshot(m['pythonTarget']);require(numerical==m['pinnedPythonInventory'],'Existing pinned numerical/geometry trees changed')
 return m,sha(ROOT/'PREPARED-manifest.json'),small,numerical

def collected_cad(m):
 c=read(m['actualCadRootCollectionPath'])
 require(sha(m['actualCadRootCollectionPath'])==m['actualCadRootCollectionSha256'],'Original collected CAD receipt changed')
 require(c['authorizedByRoot'] is True and c['phase']=='cad' and c['packetSha256']==m['originalCadPacketSha256'] and c['toolSessionCollected'] is True and c['toolWrapperExitCode']==2 and c['originalGuardPassed'] is False,'Preserve original failed outer wrapper exactly')
 require(c['independentCadApplicationPassed'] is True and c['independentCadApplicationExitCode']==0 and c['sourceAndDependenciesHeld'] is True and c['dockerImageAndContainerLifecycleHeld'] is True,'Require actual successful independent CAD application and held source/Docker')
 require(c['nativeReportPath']==m['actualCadReportPath'] and c['nativeReportSha256']==m['actualCadReportSha256'] and c['expectedSegmentCount']==168 and c['actualSourceMappedSegmentCount']==169 and c['metadataCorrectionPending'] is True,'Only the documented count metadata correction is authorized')
 require(c['postauditPath']==m['originalCadPostauditPath'] and c['postauditSha256']==m['originalCadPostauditSha256'],'Original CAD postaudit identity differs')
 p=read(c['postauditPath']);e=p['execution'];r=read(m['originalCadResultPath'])
 require(p['passed'] is False and p['sourceAndDependenciesHeld'] is True and p['dockerImageAndContainerLifecycleHeld'] is True and p['dockerBefore']==p['dockerAfter'] and not p['dockerAfter']['sameImageContainerIds'] and p['containerNetwork']=='none','Original held offline failed wrapper scope differs')
 require(e==c['execution'] and e['exitCode']==1 and e['diagnosticStopped'] is False and e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()),'Original failed wrapper was not naturally closed without OOM')
 require(p['resultSha256']==sha(m['originalCadResultPath']),'Original failed result hash differs')
 require(r['phase']=='cad' and r['packetSha256']==m['originalCadPacketSha256'] and r['passed'] is False and r['failure']=='Independent actual local CAD/geometry/zone-free graph gate failed' and r['coreBuildCount']==r['cliCalls']==r['routingCalls']==0 and r['cadCalls']==1,'Original failed runner scope differs')
 require(len(r['commands'])==1 and r['commands'][0]['name']=='one-offline-kicad10-local101-plus64-physical-connectivity' and r['commands'][0]['exitCode']==0,'Require the one actual successful offline native command')

def main():
 p=argparse.ArgumentParser();p.add_argument('--stage',dest='phase',choices=['readonly'],required=True);p.add_argument('--preflight',action='store_true');p.add_argument('--root-receipt',type=Path);p.add_argument('--root-receipt-sha256');args=p.parse_args()
 require(args.preflight!=bool(args.root_receipt),'Select preflight or exact Root authority')
 m,packet_sha,before,python_before=checked();phase=args.phase;policy=m['stages'][phase]['policy'];collected_cad(m)
 if args.preflight:print(json.dumps({'preflightOnly':True,'phase':phase,'packetSha256':packet_sha,'runtimeCalls':0}));return 0
 require(re.fullmatch('[0-9a-f]{64}',args.root_receipt_sha256 or '') and sha(args.root_receipt)==args.root_receipt_sha256,'Exact Root authority hash required')
 a=read(args.root_receipt)
 require(a.get('authorizedByRoot') is True and a.get('phase')==phase and a.get('scope')==m['stages'][phase]['scope'] and a.get('packetSha256')==packet_sha and a.get('policy')==policy and a.get('allPreviousRootWorkersCollected') is True and a.get('noConcurrentRootWorker') is True and re.fullmatch('[0-9a-f]{32,128}',a.get('approvalToken','')),'Root scope/policy/exclusive collection authority differs')
 closed=a.get('previousClosedPostaudits',[]);require(closed,'At least latest actual closed Root scope required')
 for r in closed:
  require(re.fullmatch('[0-9a-f]{64}',r.get('sha256','')) and sha(r['path'])==r['sha256'],'Previous closed postaudit hash differs')
  old=read(r['path']);e=old['execution'];require(e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()),'Previous owned group not cleanly empty')
 run=ROOT/('run-'+phase);require(not run.exists(),'One fresh staged run only')
 def before_spawn(mem):require(mem['current']+policy['rssBytes']+m['stages'][phase]['preforkReserveBytes']<policy['sharedBytes'],'Exact shared byte prefork reserve fails')
 execution=process_scope.run_guarded([sys.executable,'-B',str(ROOT/'run_stage.py'),phase],str(ROOT),run,policy,{'G350_DERIVED_CAD_STAGE':phase,'G350_DERIVED_CAD_PACKET_SHA':packet_sha,'G350_DERIVED_CAD_ROOT_RECEIPT':str(args.root_receipt.resolve()),'G350_DERIVED_CAD_ROOT_RECEIPT_SHA':args.root_receipt_sha256},before_spawn=before_spawn)
 after_m,after_sha,after,python_after=checked();collected_cad(after_m);result_path=run/'result.json';r=read(result_path) if result_path.is_file() else None
 clean=execution['exitCode']==0 and execution['diagnosticStopped'] is False and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values())
 held=packet_sha==after_sha and before==after and python_before==python_after
 passed=clean and held and r is not None and r['passed'] is True and r['phase']==phase and r['packetSha256']==packet_sha and r['coreBuildCount']==r['routingCalls']==r['cliCalls']==r['cadCalls']==r['dockerCalls']==0
 post={'phase':phase,'packetSha256Before':packet_sha,'packetSha256After':after_sha,'rootReceiptSha256':args.root_receipt_sha256,'execution':execution,'dependenciesBefore':before,'dependenciesAfter':after,'pinnedPythonBefore':python_before,'pinnedPythonAfter':python_after,'sourceAndDependenciesHeld':held,'resultSha256':sha(result_path) if result_path.is_file() else None,'passed':passed,'originalFailedWrapperPreserved':True,'reusesOriginalActualCadApplication':True,'newCliCadDockerCoreCalls':0,'referenceQualified':False,'accepted49':False,'fabricationReady':False}
 with (run/'POSTAUDIT.json').open('x') as f:json.dump(post,f,indent=2);f.write('\n')
 print(json.dumps({'phase':phase,'passed':passed,'newCadCalls':0,'accepted49':False}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
