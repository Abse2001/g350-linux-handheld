import { expect, test } from "bun:test"
import { captureOneOriginalJob } from "./control"

test("original receiver/args/result identity is forwarded once", () => {
  const args = [{ input: true }, { pair: true }, [], { variant: 0 }],
    result = [{ route: "same" }]
  const module: any = {
    routeCoupledPair(...actual: any[]) {
      expect(this).toBe(undefined)
      expect(actual).toEqual(args)
      return (function* () {
        yield
        return result
      })()
    },
  }
  const state = captureOneOriginalJob(module, args)
  expect(state.originalFactories).toBe(1)
  expect(state.originalNextCalls).toBe(2)
  expect(state.originalReturnCalls).toBe(0)
  expect(state.chargedYields).toBe(1)
  expect(state.naturalCompletion).toBe(true)
  expect(state.rawResult).toBe(result)
})
test("original6000 budget charges6000 and closes6001-next unfinished producer once", () => {
  let closed = 0
  const module = {
    routeCoupledPair: function* () {
      try {
        while (true) yield
      } finally {
        closed++
      }
    },
  }
  const state = captureOneOriginalJob(module, [])
  expect(state.originalNextCalls).toBe(6001)
  expect(state.chargedYields).toBe(6000)
  expect(state.originalReturnCalls).toBe(1)
  expect(state.originalTerminalMethod).toBe("return")
  expect(state.naturalCompletion).toBe(false)
  expect(state.rawResult).toBe(null)
  expect(closed).toBe(1)
})
test("original producer exception is not converted to null", () => {
  const failure = new Error("original-error")
  const module = {
    routeCoupledPair: function* () {
      throw failure
    },
  }
  let received: unknown
  try {
    captureOneOriginalJob(module, [])
  } catch (error) {
    received = error
  }
  expect(received).toBe(failure)
})
