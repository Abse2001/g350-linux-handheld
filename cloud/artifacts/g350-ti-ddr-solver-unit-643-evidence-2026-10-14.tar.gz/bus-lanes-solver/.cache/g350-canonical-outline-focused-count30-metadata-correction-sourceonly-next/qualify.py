from pathlib import Path
import argparse, hashlib, json, os, re, stat

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root-receipt', required=True)
    parser.add_argument('--root-receipt-sha256', required=True)
    args = parser.parse_args()
    raw = (ROOT / 'PREPARED.json').read_bytes(); packet = json.loads(raw)
    for row in packet['files'] + packet['externalFiles']:
        path = Path(row['path'])
        assert path.is_file() and not path.is_symlink() and sha(path) == row['sha256']
        assert path.stat().st_size == row['bytes'] and stat.S_IMODE(path.stat().st_mode) == row['mode']
    assert sha(args.root_receipt) == args.root_receipt_sha256
    authority = json.loads(Path(args.root_receipt).read_bytes())
    assert authority['authorizedByRoot'] is True and authority['scope'] == packet['scope']
    assert authority['packetSha256'] == hashlib.sha256(raw).hexdigest()
    assert re.fullmatch('[0-9a-f]{32,128}', authority['approvalToken'])
    old = json.loads(Path(packet['originalPostauditPath']).read_bytes())
    original_root = json.loads(Path(packet['originalRootCollectionPath']).read_bytes())
    result = json.loads(Path(packet['originalResultPath']).read_bytes())
    assert original_root['toolExitCode'] == 2
    assert original_root['outlineScalarFocusedQualificationPassed'] is False
    assert original_root['sourceAndDependenciesHeld'] is True
    assert original_root['postauditPath'] == packet['originalPostauditPath']
    assert original_root['postauditSha256'] == sha(packet['originalPostauditPath'])
    assert old['outlineScalarFocusedQualificationPassed'] is False
    assert old['packetSha256'] == packet['originalFocusedPacketSha256']
    assert old['sourceAndArtifactsHeld'] is True and old['dependenciesBefore'] == old['dependenciesAfter']
    execution = old['execution']
    assert execution['exitCode'] == 0 and execution['diagnosticStopped'] is False
    assert execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values())
    assert sha(packet['originalResultPath']) == old['resultSha256']
    assert result['passed'] is True and result['typecheckPassed'] is True
    assert [step['name'] for step in result['steps']] == ['typecheck', 'three-outline-scalar-tests-and-existing-outline-grid-regressions']
    assert all(step['exitCode'] == 0 for step in result['steps'])
    text = Path(packet['originalLogPath']).read_text(errors='replace')
    summaries = re.findall(r'^Ran (\d+) tests across (\d+) files?\.', text, re.M)
    passes = re.findall(r'^\s*(\d+) pass\s*$', text, re.M)
    failures = re.findall(r'^\s*(\d+) fail\s*$', text, re.M)
    assert summaries[-1] == ('30', '8') and int(passes[-1]) == 30 and int(failures[-1]) == 0
    actual = {}; filename = None
    for line in text.splitlines():
        if re.fullmatch(r'\s*\d+ tests? failed:\s*', line): break
        if line.startswith('tests/') and line.endswith(':'): filename = line[:-1]
        if re.match(r'^\((?:pass|fail)\) ', line):
            assert line.startswith('(pass) ') and filename is not None
            actual[filename] = actual.get(filename, 0) + 1
    assert actual == packet['actualExpectedCaseCountsByFile']
    assert sum(actual.values()) == 30 and len(actual) == 8
    assert old['actualCounters'] == {'pass': 30, 'fail': 0, 'tests': 30, 'files': 8}
    prepared = json.loads(Path(packet['originalPreparedPath']).read_bytes())
    assert prepared['expectedFocusedTests'] == 28 and prepared['expectedFocusedFiles'] == 8
    assert prepared['sourceDirectory'] == packet['sourceDirectory']
    # This receipt interprets the same genuine closed child0. It does not
    # replace the failed original guard, invent a new test execution or tool0.
    corrected = {**old, 'outlineScalarFocusedQualificationPassed': True,
        'derivedCountCorrectionQualified': True, 'derivedMetadataOnly': True,
        'originalGuardToolExitCode': 2, 'originalGuardQualified': False,
        'originalGuardExpectedTests': 28, 'correctedExpectedTests': 30,
        'actualCaseCountsByFile': actual,
        'countCorrectionPreparedSha256': hashlib.sha256(raw).hexdigest(),
        'originalPostauditPath': packet['originalPostauditPath'],
        'originalPostauditSha256': sha(packet['originalPostauditPath']),
        'originalRootCollectionPath': packet['originalRootCollectionPath'],
        'originalRootCollectionSha256': sha(packet['originalRootCollectionPath']),
        'newApplicationExecution': False, 'newRoutingImportsOrWorkers': 0}
    output = ROOT / 'COUNT-CORRECTED-postaudit.json'
    assert not output.exists()
    output.write_text(json.dumps(corrected, indent=2) + '\n')
    print(json.dumps({'derivedCountCorrectionQualified': True,
        'originalGuardToolExitCode': 2, 'originalGuardQualified': False,
        'genuineOriginalApplicationExitCode': execution['exitCode'],
        'actualCounters': corrected['actualCounters'],
        'countCorrectedPostauditPath': str(output), 'countCorrectedPostauditSha256': sha(output),
        'newApplicationExecution': False}))
    return 0

if __name__ == '__main__': raise SystemExit(main())
