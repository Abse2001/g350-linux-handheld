Prepared only. This fixture loads exact measured joint local fanouts
2a8d5723... and actual authored C input786455...; it retains all physical
obstacles, two references and 96 local traces. It does not merge individual
fanout assignments. Root recovered the ended joint child with exit0 and an
empty group; the tool session was lost and wrapper exit remains unknown.

The probe is an explicitly diagnostic Inner1 path between the actual RAM
through-vias from trace18 and trace42 at y7.4. Coordinates and dimensions come
from the raw joint object. It is not an authored DDR net or hardware port.
Four real canonical Grid controls use fewer than1000cells each: old coarse,
unaligned pitch-step counterexample, phase-aligned intermediate, old fine.
Copied pinned fanout0.0.76 native DRC records its full local baseline. The
fixture asserts no additional probe-related native issues, retaining every
baseline issue; it never claims complete board/native acceptance.

The pure retry helper is unadopted and defaultOFF. It derives step
pitch/ceil(pitch/coarseStep), rounds the small retry bounds outward relative to
the measured gap midpoint phase, and refuses expansion outside board bounds.
It neither moves copper nor relaxes clearance. No production call site or
public solver option is changed. A later integration would attempt this retry
only after the original coarse search failed and before the unchanged fine
fallback. The extra attempt may consume more internal attempts/public steps
and change the chosen route; retain the original500000expanded-search limit,
original800000public cap and1200s/5GiB overall scope, and qualify regressions
before adoption. The small standalone fixture is not a performance claim
about the complete G350 pair search, whose direct-connector fast path is
deliberately bypassed here.

Only Root may run guard.py after peer review and collecting any intervening
workers. Original fixture scope60s/1GiB/24GiB+2GiB reserve. Preparing these
files did not import Grid/native modules, rasterize, execute tests or workers.
