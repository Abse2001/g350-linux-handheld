"""Root-only stdlib data derivation after a real collected pinnedCLI0.

Produces authenticated Source↔raw zone byte pins, never CAD/SDK execution or
authorization. New CAD authority must independently bind the produced hash.
"""
import argparse,importlib.util,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('smooth_artifact_contract',ROOT/'artifact_contract.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--root-receipt',type=Path,required=True);parser.add_argument('--root-receipt-sha256',required=True);parser.add_argument('--cli-collection',type=Path,required=True);parser.add_argument('--cli-collection-sha256',required=True);parser.add_argument('--cli-report',type=Path,required=True);parser.add_argument('--cli-report-sha256',required=True);parser.add_argument('--output-pins',type=Path,required=True);args=parser.parse_args()
 a.require(os.environ.get('G350_SOURCE26_ZONE_PINS_ROOT_GUARDED')=='1','Root-owned stdlib data derivation only')
 m=json.loads((ROOT/'SOURCE-manifest.json').read_bytes())
 for row in m['files']+m['externalFiles']:a.binding(row)
 a.authority({'path':str(args.root_receipt),'sha256':args.root_receipt_sha256},a.sha(ROOT/'SOURCE-manifest.json'),m['scope'])
 raw,controls=a.actual_core();signal=a.load({'path':str(a.SIGNAL_PROPOSAL),'sha256':a.SIGNAL_SHA});_,_,carriers,_=a.derive_owned(raw,controls,signal)
 a.native_prerequisite({'actualNativeCollection':a.ACTUAL_NATIVE_COLLECTION,'actualNativeReport':a.ACTUAL_NATIVE_REPORT},carriers)
 _,post=a.collected({'path':str(args.cli_collection),'sha256':args.cli_collection_sha256});cli=a.produced(post,{'path':str(args.cli_report),'sha256':args.cli_report_sha256})
 a.require(cli['exportPassed'] is True and cli['cliExitCode']==0 and cli['sourceManifestSha256']==a.sha(ROOT/'SOURCE-manifest.json') and cli['actualCoreSha256']==a.RAW_SHA and cli['coreControlsSha256']==a.CONTROLS_SHA and cli['apiAnglesFailed'] is False and cli['nativeAndOriginalApiStagesPassed'] is True and cli['actualOriginalApiReport']==a.ACTUAL_API,'Actual current normalCLI0/Native0/API0 prerequisite')
 export=a.regular(cli['outputPath']);a.require(a.sha(export)==cli['outputSha256'] and any(r['path']==str(export) and r['sha256']==cli['outputSha256'] for r in post['outputFiles']),'Exact actual collected CLI export')
 helper_path=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-package101-cad-source-next/child/inspect-local101-hs64.py');sp=importlib.util.spec_from_file_location('source_kicad_parser',helper_path);h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
 sp=importlib.util.spec_from_file_location('source_zone_projection',ROOT/'zone_contract.py');z=importlib.util.module_from_spec(sp);sp.loader.exec_module(z)
 data=export.read_bytes();tree=h.parse_sexpressions(data);nodes=h.children(tree,'zone');sources=[r for r in raw if r['type'] in ['pcb_copper_pour','pcb_keepout']];pins=[]
 for source in sources:
  ident=source[source['type']+'_id'];uid=h.converter_uuid(('zone:' if source['type']=='pcb_copper_pour' else 'keepout:')+ident);node=z.one([n for n in nodes if h.values(n,'uuid')==[uid]],'Actual authentic Source zone');body=data[node.start:node.end]
  pins.append({'sourceId':ident,'sourceCanonicalSha256':z.canonical(source),'rawZoneUuid':uid,'rawZoneSha256':z.digest(body),'rawZoneBytes':len(body)})
 value={'actualCoreRawSha256':a.RAW_SHA,'actualExportPath':str(export),'actualExportSha256':cli['outputSha256'],'actualSourceZoneRowsCanonicalSha256':z.canonical(sources),'actualSourceCopperPourCount':sum(r['type']=='pcb_copper_pour' for r in sources),'actualSourceKeepoutCount':sum(r['type']=='pcb_keepout' for r in sources),'zones':pins,'actualCliCollection':{'path':str(args.cli_collection),'sha256':args.cli_collection_sha256},'actualCliReport':{'path':str(args.cli_report),'sha256':args.cli_report_sha256},'sourceOnlyDataNotAuthorization':True,'sdkOrCadOrApplicationImported':False}
 _,proof=z.map_zones(raw,data,h,value);a.require(proof['actualSourceCopperPourCount']==sum(r['type']=='pcb_copper_pour' for r in raw) and proof['actualSourceKeepoutCount']==2,'Fresh source-derived copper pour count and2 genuine keepouts')
 output=args.output_pins;a.require(output.is_absolute() and output.parent.is_dir() and not output.parent.is_symlink() and not output.exists() and not output.is_symlink(),'Fresh exclusive Root-owned zone-pin data path')
 with output.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
 output.chmod(0o600);print(json.dumps({'path':str(output),'sha256':a.sha(output),'actualSourceCopperPourCount':proof['actualSourceCopperPourCount'],'actualSourceKeepoutCount':2,'applicationCalls':0,'authorizedByThisHelper':False}));return 0
if __name__=='__main__':raise SystemExit(main())
