"""Freeze copiedV5+exact20umCPU13/V6wrapper source-only packet; no Circuit execution."""
from pathlib import Path
import json,os,stat
from inventory import sha,tree
ROOT=Path(__file__).resolve().parent;BOARD=Path('/workspace/g350-linux-handheld');OLD=BOARD/'.cloud-tools/ti-ddr-v5-reference-export-next'
ENTRY='experiments/am3352-g350-ti-top-bottom-ddr-v6-alternate-layout.circuit.tsx'
POLICY={'wallSeconds':60,'rssBytes':2*1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
assert not(ROOT/'packet-manifest.json').exists() and not(ROOT/'run').exists()
old=json.loads((OLD/'packet-manifest.json').read_bytes())
old_paths={r['path']:r for r in old['files'] if r['path'].startswith('source/')}
changed=[]
for name,row in old_paths.items():
 assert sha(OLD/name)==row['sha256']
 if sha(ROOT/name)!=row['sha256']:changed.append(name)
assert changed==['source/lib/am3352/placement/g350-ti-top-bottom-ddr-v5.json']
before=json.loads((OLD/changed[0]).read_bytes());after=json.loads((ROOT/changed[0]).read_bytes());after['C_DDR_CPU_13']['pcbX']=-4.5;assert before==after
assert sha(ROOT/'process_scope.py')=='7bdc74b15af3ba5b2c306d34a816b48cf8b9d68479b0c06a57f43787d4a4a993'
def item(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
external=list(old['externalFiles'])
for p in [OLD/'packet-manifest.json',OLD/'run/fresh-layout.circuit.json',OLD/'run/postflight.json',Path('/workspace/bus-lanes-solver/.cache/g350-ti-bounds-v5-first-three-pairs-next/capture-v5.ts'),Path('/workspace/bus-lanes-solver/.cache/g350-ti-bounds-v5-first-three-pairs-next/output/ddr-input.json'),Path('/workspace/bus-lanes-solver/.cache/g350-ti-v5-public-cohort-init-next/original-unrestricted-input.json'),BOARD/'scripts/lib/g350-ddr-physical-checks.mjs',BOARD/'.git/index']:
 external.append(item(p))
for p in [BOARD/'.cloud-tools/node/bin/node',BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe',BOARD/'node_modules/@tscircuit/checks/dist/index.js',BOARD/'node_modules/@tscircuit/core/dist/index.js',Path('/workspace/bus-lanes-solver/tests/fixtures/g350-am3352/metadata.json')]:external.append(item(p))
# Whole board tree must equal pinnedV5; no install or runtime mutation.
deps=tree(BOARD/'node_modules')
for k in ['treeSha256','regularFiles','regularBytes','symlinks','directories']:assert deps[k]==old['dependencyTree'][k],k
(ROOT/'dependency-tree.json').write_text(json.dumps(deps,indent=2)+'\n')
resolver=[p.replace(str(OLD),str(ROOT)) for p in old['resolverMustRemainAbsent']]
resolver.extend([str(ROOT/'source/scripts/lib/node_modules'),str(ROOT/'node_modules')])
for name in resolver:assert not(Path(name).exists() or Path(name).is_symlink())
files=[]
for current,dirs,names in os.walk(ROOT,followlinks=False):
 dirs[:]=[d for d in dirs if d!='__pycache__' and not(Path(current)/d).is_symlink()]
 for name in names:
  p=Path(current)/name
  if p.is_symlink():continue
  assert stat.S_ISREG(p.lstat().st_mode)
  files.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p),'mode':stat.S_IMODE(p.stat().st_mode)})
files.sort(key=lambda r:r['path'])
manifest={'schemaVersion':1,'scope':'one-ti-v6-alternate-cohort-source-only-no-router-no-cad','policy':POLICY,'sourceEntry':ENTRY,'sourceFileCount':len([r for r in files if r['path'].startswith('source/')]),'originalCommand':[str(BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'),str(BOARD/'node_modules/tscircuit/cli.mjs'),'build',ENTRY,'--routing-disabled','--disable-parts-engine'],'freshOutput':'source/dist/experiments/am3352-g350-ti-top-bottom-ddr-v6-alternate-layout/circuit.json','planeDeclarations':old['planeDeclarations'],'pinnedVersions':old['pinnedVersions'],'pinnedRuntimeVersions':old['pinnedRuntimeVersions'],'nativeChecksPatchSha256':old['nativeChecksPatchSha256'],'dependencyTree':{k:v for k,v in deps.items() if k!='items'},'dependencyTreeManifestSha256':sha(ROOT/'dependency-tree.json'),'files':files,'externalFiles':external,'resolverMustRemainAbsent':sorted(set(resolver)),'baseV5PacketSha256':sha(OLD/'packet-manifest.json'),'one20umCpu13Move':True,'alternateClassPolicy':{'DDR_BYTE0':'top','DDR_BYTE1':'top','DDR_COMMAND_CLOCK':'bottom','DDR_RESET':'bottom'},'topMembers':22,'bottomMembers':27,'actualCircuitExecuted':False,'cadRequested':False,'autoroutingRequested':False,'rootDelegatedOneSourceBuild':True,'fabricationReady':False}
(ROOT/'packet-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'packetSha256':sha(ROOT/'packet-manifest.json'),'sourceFileCount':manifest['sourceFileCount'],'files':len(files),'external':len(external),'dependencyTreeSha256':deps['treeSha256'],'actualCircuitExecuted':False}))
