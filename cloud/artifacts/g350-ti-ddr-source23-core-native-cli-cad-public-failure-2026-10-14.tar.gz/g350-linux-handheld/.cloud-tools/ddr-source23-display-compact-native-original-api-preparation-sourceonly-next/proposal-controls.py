"""Finite pure-data/schema controls; no SDK, app, worker import/evaluation."""
import ast,copy,hashlib,json,math,re,stat
from pathlib import Path
HERE=Path(__file__).parent
SOURCE=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-owner23-display-offset-compact-source-successor-next')
def require(v,m):
 if not v:raise ValueError(m)
def load(p):return json.loads(Path(p).read_bytes())
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def validate_proposal(p):
 require(p['expectedCounts']['carrierPaths']==23 and p['expectedCounts']['physicalVias']==227 and p['expectedCounts']['physicalTraces']==286 and p['expectedCounts']['remainingOriginal49Requests']==26,'23/227/286/26 proposal contract')
 require(len(p['all98NumericOwnedSignalBranches'])==98 and len({o['viaName'] for o in p['all98NumericOwnedSignalBranches']})==98,'98 genuine distinct owned branch literals')
 require(len(p['selected23OriginalCarriers'])==23 and len({c['originalSourceTraceId'] for c in p['selected23OriginalCarriers']})==23,'23 original distinct carriers')
 normalized=load(p['inputBindings']['preferred23Normalized']['path']);require(digest(p['inputBindings']['preferred23Normalized']['path'])==p['inputBindings']['preferred23Normalized']['sha256'],'Exact preferred normalized23')
 by={r['sourceTraceId']:r for r in normalized['records']};pairs={'source_trace_15','source_trace_16','source_trace_27','source_trace_28','source_trace_33','source_trace_34'}
 for c in p['selected23OriginalCarriers']:
  require(c['originalSourceTraceId'] in by and c['carrierLayer'] in ['top','inner1','inner2','bottom'],'Authentic carrier roster/layer')
  r=by[c['originalSourceTraceId']];require(c['carrierLayer']==r['layer'] and c['expectedCarrierPath']==r['path'],'Complete full carrier geometry bound')
  require(len(c['expectedCarrierPath'])>=2 and c['expectedWholePlanarMm']==r['wholePlanarLengthMm'],'Full actual candidate path/whole length')
  for o in [c['cpu'],c['ram']]:
   require(len(o['topStub'])==2 and all(q['route_type']=='wire' and q['layer']=='top' and q['width']==.1016 for q in o['topStub']),'Real Top dogbone branch unchanged width')
   require(o['topStub'][0]['x']==o['padXY']['x'] and o['topStub'][0]['y']==o['padXY']['y'] and o['topStub'][-1]['x']==o['viaXY']['x'] and o['topStub'][-1]['y']==o['viaXY']['y'],'Real pad-to-via dogbone geometry')
  if c['originalSourceTraceId'] in pairs:
   q=c['coupledSection'];require(isinstance(q,list) and len(q)==2 and all(type(v)==int for v in q) and 0<=q[0]<q[1]<len(c['expectedCarrierPath']),'All6 authentic full-path coupling section indices')
 require(pairs.issubset({c['originalSourceTraceId'] for c in p['selected23OriginalCarriers']}),'All3 original differential pairs')
 return {'genuineSource23ProposalAuthenticated':True,'all6AuthoredCouplingSectionsInBounds':True,'actualCoreOrApiQualification':False}
def main():
 proposal=load(SOURCE/'source23-proposal.json');positive=validate_proposal(proposal);negative=[]
 def bad(name,edit):
  x=copy.deepcopy(proposal);edit(x)
  try:validate_proposal(x)
  except(ValueError,KeyError,TypeError):negative.append({'name':name,'refused':True})
  else:raise ValueError('Bad proposal accepted '+name)
 bad('wrong_carrier_count',lambda x:x['expectedCounts'].update(carrierPaths=49))
 bad('wrong_via_count',lambda x:x['expectedCounts'].update(physicalVias=225))
 bad('false_missing_zero',lambda x:x['expectedCounts'].update(remainingOriginal49Requests=0))
 bad('missing_signal_owner',lambda x:x['all98NumericOwnedSignalBranches'].pop())
 bad('duplicate_signal_owner',lambda x:x['all98NumericOwnedSignalBranches'][0].update(viaName=x['all98NumericOwnedSignalBranches'][1]['viaName']))
 bad('missing_carrier',lambda x:x['selected23OriginalCarriers'].pop())
 bad('wrong_carrier_layer',lambda x:x['selected23OriginalCarriers'][0].update(carrierLayer='inner1'))
 bad('changed_complete_body_geometry',lambda x:x['selected23OriginalCarriers'][0]['expectedCarrierPath'][2].update(x=99))
 bad('changed_whole_length',lambda x:x['selected23OriginalCarriers'][0].update(expectedWholePlanarMm=0))
 bad('too_thin_top_dogbone',lambda x:x['selected23OriginalCarriers'][0]['cpu']['topStub'][0].update(width=.075))
 bad('dogbone_misses_barrel',lambda x:x['selected23OriginalCarriers'][0]['cpu']['topStub'][-1].update(x=99))
 first=next(i for i,c in enumerate(proposal['selected23OriginalCarriers'])if c['coupledSection'])
 bad('missing_pair_coupling_section',lambda x:x['selected23OriginalCarriers'][first].update(coupledSection=None))
 bad('out_of_bounds_pair_section',lambda x:x['selected23OriginalCarriers'][first].update(coupledSection=[0,99999]))
 bad('reversed_pair_section',lambda x:x['selected23OriginalCarriers'][first].update(coupledSection=[2,1]))
 # Parse and invoke only the stdlib validator definitions, not the app workers.
 tree=ast.parse((HERE/'validate-root-prerequisites.py').read_text());env={'Path':Path,'hashlib':hashlib,'json':json,'re':re,'stat':stat}
 for n in tree.body:
  if isinstance(n,(ast.Assign,ast.FunctionDef)):exec(compile(ast.Module(body=[n],type_ignores=[]),'pure-future23-prerequisite-defs','exec'),env)
 try:env['validate_binding'](load(HERE/'BOUND_MANIFEST_TEMPLATE_NO_AUTHORIZATION.json'),load(HERE/'ROOT_AUTHORITY_TEMPLATE_NO_AUTHORIZATION.json'),'0'*64)
 except ValueError:negative.append({'name':'unbound_templates_cannot_authorize','refused':True})
 else:raise ValueError('Unbound future templates authorized')
 for phase,name in [('capture','strict18-smooth-capture-16609-COLLECTED-root.json'),('types','strict18-smooth-types-99816-COLLECTED-root.json'),('core','strict18-smooth-core-56795-COLLECTED-root.json')]:
  c=load('/workspace/bus-lanes-solver/.cache/root-routing-progress/'+name);post=load(c['postauditPath']);meta={'phase':phase,'tool':c['toolSessionId'],'scope':c['scope']}
  try:env['validate_collection'](c,post,phase,meta,'f'*64)
  except ValueError:negative.append({'name':'old18_'+phase+'_cannot_qualify_genuine23','refused':True})
  else:raise ValueError('Old18 receipt qualified23')
 for f in HERE.glob('*.py'):ast.parse(f.read_text())
 original=Path('/workspace/g350-linux-handheld/.cloud-tools/ddr-strict18-smooth-fresh-native-api-sourceonly-next/fresh-via-branch-manufacturing-clearance.mjs')
 require((HERE/'fresh-via-branch-manufacturing-clearance.mjs').read_bytes()==original.read_bytes(),'Manufacturing helper entire body unchanged')
 result={'scope':'FINITE_STDLIB_FUTURE_SOURCE23_NATIVE_API_PREPARATION_CONTROLS','proposalSha256':digest(SOURCE/'source23-proposal.json'),'positiveProposalControls':positive,'negativeControls':negative,'negativeCount':len(negative),'manufacturingHelperByteIdenticalToActual44382':True,'pythonSourceAstParsed':True,'appWorkersImportedOrEvaluated':False,'typescriptOrJavascriptSyntaxCheckExecuted':False,'actualFresh23CoreRead':False,'nativeExecuted':False,'originalApisExecuted':False,'RootAuthorityCreated':False,'accepted49':False,'fabricationReady':False}
 with(HERE/'STDLIB_CONTROLS_EXACT_ROOT_SCHEMA.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 (HERE/'STDLIB_CONTROLS_EXACT_ROOT_SCHEMA.json').chmod(0o600);print(json.dumps({'negativeCount':len(negative),'sha256':digest(HERE/'STDLIB_CONTROLS_EXACT_ROOT_SCHEMA.json')}))
if __name__=='__main__':main()
