import hashlib
import importlib.util
import json
import os
import secrets
import stat
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
BOARD = Path('/workspace/g350-linux-handheld')
PACKET = BOARD / '.cloud-tools/ddr-clock-v11-fresh-json-cli-export-sourceonly-next'
NATIVE = BOARD / '.cloud-tools/ddr-clock-v11-fresh-core-native-sourceonly-next'
OUT = ROOT / 'clock-v11-fresh-cli-owned-next'
POLICY = {'wallSeconds': 90, 'rssBytes': 2147483648, 'sharedBytes': 32212254720, 'sampleSeconds': 0.05, 'termGraceSeconds': 5}

def read(path):
    return json.loads(Path(path).read_bytes())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

native_guard = load('clock_cli_native_guard_library', NATIVE / 'guard.py')
worker = load('clock_cli_worker_library', PACKET / 'export_fresh_json.py')

def main():
    assert len(sys.argv) == 3
    peer_path = Path(sys.argv[1])
    assert sha(peer_path) == sys.argv[2]
    peer = read(peer_path)
    assert peer['sourceManifestSha256'] == sha(PACKET / 'SOURCE-manifest.json')
    assert peer['decision'] == 'GO_SOURCE_ONLY_TO_ROOT_OWNED_CLI_EXPORT'
    assert not OUT.exists()
    m = read(PACKET / 'SOURCE-manifest.json')
    for row in m['files'] + m['externalFiles']:
        worker.binding(row)
    _, native_packet_sha, board_before, solver_before, _ = native_guard.checked()
    assert native_packet_sha == m['nativePreparedManifestSha256']
    native_receipt = ROOT / 'clock-v11-fresh-native-42626-COLLECTED-root.json'
    collection, native_post, _ = native_guard.collected({'path': str(native_receipt), 'sha256': sha(native_receipt)}, positive=True)
    original_authority = read(ROOT / 'clock-v11-fresh-native-root.json')
    previous = [original_authority['requiredActual42982Collection'], *original_authority['additionalPreviousRootCollections'], *original_authority['successfulPriorStages'].values(), original_authority['successfulCoreCollection'], {'path': str(native_receipt), 'sha256': sha(native_receipt)}]
    for row in previous:
        _, _, execution = native_guard.collected(row)
        assert native_guard.process_scope.owned(execution['pgid']) == []
    authority = {'authorizedByRoot': True, 'scope': m['scope'], 'sourceManifestSha256': sha(PACKET / 'SOURCE-manifest.json'), 'actualPreviousScopesCollectedAndEmpty': True, 'noConcurrentRootWorker': True, 'rootFullWorkerReadPassed': True, 'approvalToken': secrets.token_hex(32), 'actualNativeCollection': {'path': str(native_receipt), 'sha256': sha(native_receipt)}, 'freshArtifacts': native_post['actualFreshCoreArtifacts'], 'policy': POLICY, 'sourcePeerReviewPath': str(peer_path), 'sourcePeerReviewSha256': sha(peer_path), 'accepted49': False, 'fabricationReady': False}
    assert worker.core_from_actual_native(authority, m) == authority['freshArtifacts']
    authority_path = ROOT / 'clock-v11-fresh-cli-root.json'
    with authority_path.open('x') as file:
        json.dump(authority, file, indent=2)
        file.write('\n')
    authority_sha = sha(authority_path)
    OUT.mkdir()
    exports = OUT / 'exports'
    exports.mkdir()
    def before_spawn(mem):
        assert mem['current'] + POLICY['rssBytes'] + 1073741824 < POLICY['sharedBytes']
        for row in previous:
            _, _, execution = native_guard.collected(row)
            assert native_guard.process_scope.owned(execution['pgid']) == []
    argv = [sys.executable, '-B', str(PACKET / 'export_fresh_json.py'), '--root-receipt', str(authority_path), '--root-receipt-sha256', authority_sha, '--output-directory', str(exports)]
    execution = native_guard.process_scope.run_guarded(argv, str(BOARD), OUT / 'owned', POLICY, {'G350_CLOCK_FRESH_JSON_CLI_ROOT_GUARDED': '1'}, before_spawn=before_spawn)
    _, after_packet_sha, board_after, solver_after, _ = native_guard.checked()
    for row in m['files'] + m['externalFiles']:
        worker.binding(row)
    held = native_packet_sha == after_packet_sha and board_before == board_after and solver_before == solver_after and sha(authority_path) == authority_sha and sha(peer_path) == sys.argv[2]
    held = held and worker.core_from_actual_native(authority, m) == authority['freshArtifacts']
    report_path = exports / 'cli-export-report.json'
    report = read(report_path) if report_path.is_file() else None
    passed = held and execution['exitCode'] == 0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values()) and report is not None and report['exportPassed'] is True
    outputs = [{'path': str(path), 'bytes': path.stat().st_size, 'mode': stat.S_IMODE(path.stat().st_mode), 'sha256': sha(path)} for path in sorted(exports.iterdir()) if path.is_file()]
    post = {'scope': m['scope'], 'sourceManifestSha256': sha(PACKET / 'SOURCE-manifest.json'), 'execution': execution, 'dependenciesBefore': board_before, 'dependenciesAfter': board_after, 'solverDependenciesBefore': solver_before, 'solverDependenciesAfter': solver_after, 'sourceAndDependenciesHeld': held, 'rootAuthorityPath': str(authority_path), 'rootAuthoritySha256': authority_sha, 'actualFreshCoreArtifacts': authority['freshArtifacts'], 'reportPath': str(report_path), 'reportSha256': sha(report_path) if report_path.is_file() else None, 'outputFiles': outputs, 'passed': passed, 'coreCalls': 0, 'cliCalls': 1, 'cadCalls': 0, 'accepted49': False, 'fabricationReady': False}
    with (OUT / 'POSTAUDIT.json').open('x') as file:
        json.dump(post, file, indent=2)
        file.write('\n')
    print(json.dumps({'passed': passed, 'sourceAndDependenciesHeld': held, 'execution': execution, 'outputFiles': outputs}))
    return 0 if passed else 2

if __name__ == '__main__':
    raise SystemExit(main())
