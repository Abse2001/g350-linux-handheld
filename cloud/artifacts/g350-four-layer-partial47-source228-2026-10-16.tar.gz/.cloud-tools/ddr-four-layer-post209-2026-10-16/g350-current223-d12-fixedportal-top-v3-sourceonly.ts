// SOURCE ONLY. Root executes; no source/native/timing/fabrication acceptance.
// Fixed real D12 CPU barrel -> Inner1 head -> fullspan (0,12.2) -> Top ->
// genuine RAM numeric pad. Only its owned RAM working branch is removed,
// with a complete inverse. Current223 new13/new12, D5/D7, 31/35 and critical6 stay hard.
// Source4 is the exact194 refill. Source42 is released ONLY if it is an
// actual fixed-head collider and removing that body clears the entire head.
// bun THIS.ts --output FRESH.json [--budget-ms 165000] [--case-ms 15000]
import fs from 'node:fs'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {pathToFileURL} from 'node:url'
type R=Record<string,any>
const ROOT='/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib/'
const CURRENT='/tmp/g350-deterministic-manual47-root-20261016-run223/byte0-result.candidate.json',CURRENT_SHA='ddaa4efd8d20f16cefca89b9166e834a956113194beed6f0f13903e346e36ea0'
const ALT='/tmp/g350-d12-pad-rule-root-20261016-run194/byte0-result.candidate.json',ALT_SHA='24835d892c7c76a0f20f6358ebb45d5b6bd9eb1c60d3d4b1b12dc1c891fb7c61'
const CRITICAL='/tmp/g350-clock33-shorten-root-20261016-run169/byte0-result.candidate.json',CRITICAL_SHA='157b33c88108d5315ad3630ea4f0666ebfb5db0a00376d545299026f05939683'
const RAW='/tmp/g350-source33b-three-stage-root-20261015-after86/core/output/raw-core.json',RAW_SHA='d2f5ef917710ac953fec6791b55ccfc5acd3f39bc37847d2563e5afd007f5607'
const ENDPOINTS='/tmp/g350-native-top-or-barrel-endpoints-ripup-sourceonly.ts',ENDPOINTS_SHA='f737af519a0dbc4bde8edeced01fc5526284b16affa6949e973eb609c9fe8a45'
const QUALIFIER='/tmp/g350-mixed-carrier-physical-four-vias-sourceonly.ts',QUALIFIER_SHA='cdea6326a318b332ba98bb74bb1c8fd52c3b757bde34d75402558bd6dc86623f'
const W=.1016,VD=.4572,HD=.254,L=['top','inner1','inner2','bottom'],N='source_trace_26',CAP=14.177653789032021
const req=(v:any,m:string)=>{if(!v)throw Error(m)},clone=<T>(v:T):T=>structuredClone(v),same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b),own=(t:R)=>t.connection_name??t.source_trace_id,near=(a:R,b:R)=>Math.hypot(a.x-b.x,a.y-b.y)<1e-8
const sha=(b:any)=>createHash('sha256').update(b).digest('hex'),read=(p:string,h:string)=>{const b=fs.readFileSync(p);req(sha(b)===h,'Public input hash changed '+p);return JSON.parse(b.toString())}
const planar=(t:R)=>t.route.slice(1).reduce((s:number,b:R,i:number)=>{const a=t.route[i];return s+(a.route_type==='wire'&&b.route_type==='wire'&&a.layer===b.layer?Math.hypot(a.x-b.x,a.y-b.y):0)},0)
const args=new Map<string,string>();for(let i=2;i<process.argv.length;i+=2){const k=process.argv[i],v=process.argv[i+1];req(['--output','--budget-ms','--case-ms','--max-expansions'].includes(k)&&v&&!args.has(k),'Invalid CLI '+k);args.set(k,v)}
const out=path.resolve(args.get('--output')??''),budget=Number(args.get('--budget-ms')??165000),caseMs=Number(args.get('--case-ms')??15000),maxExpanded=Number(args.get('--max-expansions')??1500000)
req(args.has('--output')&&!fs.existsSync(out)&&!fs.existsSync(out.replace(/\.json$/,'')+'.candidate.json'),'Fresh output and candidate required');req(budget>=1000&&budget<=170000&&caseMs>=100&&caseMs<=25000&&Number.isInteger(maxExpanded)&&maxExpanded>=1000&&maxExpanded<=2000000,'Finite limits')
const packet=read(CURRENT,CURRENT_SHA),alt=read(ALT,ALT_SHA),criticalPacket=read(CRITICAL,CRITICAL_SHA),raw:R[]=read(RAW,RAW_SHA)
for(const [p,h] of [[ENDPOINTS,ENDPOINTS_SHA],[QUALIFIER,QUALIFIER_SHA]])req(sha(fs.readFileSync(p))===h,'Reviewed helper hash '+p)
const base:R=clone(packet.full49FanoutInput),held:R[]=clone(packet.heldCarrierTraces),oldOrdinary:R[]=clone(packet.ordinaryCarrierTraces),frozen=JSON.stringify({base,held,oldOrdinary})
req(base.connections.length===49&&base.traces.length===263&&base.obstacles.length===1298&&held.length===6&&oldOrdinary.length===41&&packet.carrierTraces.length===47&&packet.allSavedCarriersCurrentSceneQualified===true,'Exact current223 physically qualified inventory')
req(same(held,criticalPacket.heldCarrierTraces)&&same(base.buses,criticalPacket.full49FanoutInput.buses)&&same(base.differentialPairs,criticalPacket.full49FanoutInput.differentialPairs),'All169 critical6 and original49 rules unchanged')
req(base.layerCount===4&&same(base.allowedLayers,L)&&base.allowBlindAndBuriedVias===false&&base.minTraceWidth===W&&base.minTraceToPadEdgeClearance===W&&base.minViaDiameter===VD&&base.minViaHoleDiameter===HD&&base.minViaEdgeToPadEdgeClearance===W,'Original four-layer dimensions and actual via-pad rule')
req(same(base.connections.filter((c:R)=>!packet.carrierTraces.some((t:R)=>own(t)===c.name)).map((c:R)=>c.name),[N,'source_trace_30']),'Exact223 missing26/30')
const flags={all49Accepted:false,wholeMixedC31Supported:false,matched:false,timingPassed:false,electricalTimingQualified:false,nativeExecuted:false,cadExecuted:false,fabricationReady:false,freshSource:false,freshSourceCoreDerived:false}
const started=performance.now(),stem=out.replace(/\.json$/,''),report:R={scope:'CURRENT223_FIXED_D12_INNER1_PORTAL_TO_AUTHENTIC_RAM_TOP_DIAGNOSTIC',inputBindings:{current:{path:CURRENT,sha256:CURRENT_SHA},source4Alternative:{path:ALT,sha256:ALT_SHA},critical:{path:CRITICAL,sha256:CRITICAL_SHA},rawCore:{path:RAW,sha256:RAW_SHA}},maximumWholeD12Mm:CAP,new13AndReshaped12HeldBytewise:true,attempts:[],finalScenePhysicalReports:[],criticalValidationViews:[],allSavedCarriersCurrentSceneQualified:false,...flags}
fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,'',{flag:'wx'})
const save=()=>{report.elapsedMs=performance.now()-started;fs.writeFileSync(out+'.tmp',JSON.stringify(report,null,2)+'\n');fs.renameSync(out+'.tmp',out)};save()
try{
 const imp=(n:string)=>import(pathToFileURL(ROOT+n+'.ts').href)
 const {GridVisibilitySearch}=await imp('grid-visibility'),{VectorScene,fixedCopper,clearanceToCopper}=await imp('vector-scene'),{reduceOrdinaryTurns}=await imp('reduce-ordinary-turns'),{chamferOrdinaryCorners}=await imp('chamfer-ordinary-corners')
 const {nativeSignalGeometryIsValid}=await imp('native-signal-geometry'),{tuningPathIsSelfClear}=await imp('length-tuning'),{pointSegmentDistanceToPoints,segmentDistance}=await imp('geometry'),{boardOutlineViolations}=await imp('board-outline'),{BusLanesSolver}=await imp('bus-lanes-solver')
 const {retargetGeneratedEscape}=await imp('retarget-generated-escape'),{joinSignalEscapes}=await imp('join-signal-escapes'),lengths=await imp('route-lengths'),sh=await imp('shared-pair-spacing'),co=await imp('pair-coupling'),ex=await imp('exterior-pair-spacing')
 const {createEndpointMenus,applyEndpointSelection}=await import(pathToFileURL(ENDPOINTS).href),{qualifyMixedCarrier}=await import(pathToFileURL(QUALIFIER).href)
 const H={VectorScene,fixedCopper,clearanceToCopper,pointSegmentDistanceToPoints,segmentDistance,nativeSignalGeometryIsValid,tuningPathIsSelfClear,boardOutlineViolations,BusLanesSolver}
 const extraHoles=(input:R)=>{
  const h:R[]=[];for(const t of input.traces)for(const p of t.route)if(p.route_type==='via'){req(Number.isFinite(p.via_hole_diameter),'Actual route drill');h.push({x:p.x,y:p.y,diameter:p.via_hole_diameter,plated:true,owner:own(t),physicalId:t.pcb_trace_id})}
  for(const o of input.obstacles){const m=o.circuitJsonMetadata??{},id=m.pcb_via_id??m.pcb_hole_id??m.pcb_plated_hole_id;if(!id)continue;const r=raw.find((r:R)=>(r.type==='pcb_via'&&r.pcb_via_id===id)||(r.type==='pcb_hole'&&r.pcb_hole_id===id)||(r.type==='pcb_plated_hole'&&r.pcb_plated_hole_id===id));req(r&&near(r,o.center),'Actual unchanged fixed drill '+id);const d=r.hole_diameter??Math.hypot(r.hole_width,r.hole_height);req(Number.isFinite(d)&&d>0,'Actual fixed hole dimensions');h.push({x:o.center.x,y:o.center.y,diameter:d,plated:r.type!=='pcb_hole',physicalId:id,owners:o.connectedTo,conservativeCircumscribedSlot:r.hole_shape!=='circle'&&r.shape==='pill'})}return h
 }
 const nativeLands=(t:R,input:R)=>{
  const sites=[...input.traces.filter((r:R)=>own(r)!==own(t)).flatMap((r:R)=>r.route.filter((p:R)=>p.route_type==='via').map((p:R)=>({x:p.x,y:p.y,diameter:p.via_diameter,owner:own(r),physicalId:r.pcb_trace_id}))),...input.obstacles.filter((o:R)=>o.circuitJsonMetadata?.pcb_via_id&&!o.connectedTo?.includes(own(t))).map((o:R)=>({x:o.center.x,y:o.center.y,diameter:Math.max(o.width,o.height),physicalId:o.circuitJsonMetadata.pcb_via_id}))]
  const rows=t.route.filter((p:R)=>p.route_type==='via').map((p:R)=>({via:clone(p),violations:sites.flatMap((v:R)=>{req(Number.isFinite(v.diameter),'Actual foreign land diameter');const actual=Math.hypot(p.x-v.x,p.y-v.y),required=p.via_diameter/2+v.diameter/2+.15;return actual<required-1e-8?[{...v,actualCenterDistanceMm:actual,requiredCenterDistanceMm:required}]:[]})}));return {passed:rows.every((r:R)=>!r.violations.length),minimumForeignViaLandGapMm:.15,rows,allBoardNativeChecksExecuted:false}
 }
 let working=clone(base)
 const c4=working.connections.find((c:R)=>c.name==='source_trace_4'),old4=oldOrdinary.find(t=>own(t)==='source_trace_4'),new4=clone(alt.carrierTraces.find((t:R)=>own(t)==='source_trace_4'));req(c4&&old4&&new4,'Unique actual194 source4 refill')
 const menu4=createEndpointMenus(working,c4,{retargetGeneratedEscape,fixedRouteLength:lengths.fixedRouteLength}),selection4=applyEndpointSelection(working,c4,new4,menu4,{retargetGeneratedEscape,fixedRouteLength:lengths.fixedRouteLength});working=selection4.foundation
 req(planar(new4)+lengths.fixedRouteLength(working,'source_trace_4')<=11.8+1e-7,'Source4 hard maximum')
 report.source4Overlay={body:{before:clone(old4),after:clone(new4)},endpointInverse:selection4.inverse,sourcePacketSha256:ALT_SHA,otherMaterialUnchanged:true}
 let ordinary=oldOrdinary.map(t=>own(t)==='source_trace_4'?clone(new4):clone(t))
 const wire=(x:number,y:number,layer:string)=>({route_type:'wire',x,y,layer,width:W}),head:R[]=[wire(0,15.2,'inner1'),wire(-.4134,14.7866,'inner1'),wire(-.4134,12.6134,'inner1'),wire(0,12.2,'inner1')],portal=head.at(-1)!
 const originalC=working.connections.find((c:R)=>c.name===N),menus=createEndpointMenus(working,originalC,{retargetGeneratedEscape,fixedRouteLength:lengths.fixedRouteLength}),ramTop=clone(menus.byLayer.top.pointsToConnect[1]);req(near(head[0],menus.byLayer.inner1.pointsToConnect[0])&&near(ramTop,{x:4.8,y:5.8})&&ramTop.pcb_port_id==='pcb_port_375','Authentic CPU179 and RAM numeric375 identity')
 const via={route_type:'via',x:portal.x,y:portal.y,from_layer:'inner1',to_layer:'top',layers:clone(L),via_diameter:VD,via_hole_diameter:HD}
 const shell:R={type:'pcb_trace',pcb_trace_id:'current223_fixed_d12_inner1_top_portal',connection_name:N,source_trace_id:N,route:[...clone(head),clone(via),wire(portal.x,portal.y,'top'),{...ramTop,route_type:'wire',width:W}]}
 const selected=applyEndpointSelection(working,originalC,shell,menus,{retargetGeneratedEscape,fixedRouteLength:lengths.fixedRouteLength});working=selected.foundation
 const connection=working.connections.find((c:R)=>c.name===N),fanout=lengths.fixedRouteLength(working,N),headLength=planar({route:head}),suffixBudget=CAP-fanout-headLength
 report.authenticEndpointSelection={menus:clone(menus),inverse:selected.inverse,wholeCapMm:CAP,retainedCPUFanoutMm:fanout,removedRAMFanoutMm:menus.byLayer.bottom.fanoutMm[1],fixedHeadMm:headLength,topSuffixMaximumMm:suffixBudget,fixedHeadChargedExactlyOnce:true,oldWorkingRAMBarrelReleasedExplicitly:true};req(fanout>0&&suffixBudget>0,'Positive exact remaining length budget')
 const walls=(others:R[])=>({...clone(working),traces:[...working.traces,...held,...others]})
 const headVisible=(others:R[])=>{const input=walls(others),local={...connection,pointsToConnect:[clone(head[0]),clone(head.at(-1))]};return new VectorScene(input,local,W,fixedCopper(input)).pathVisible(head)}
 const headBefore=headVisible(ordinary),fortyTwo=ordinary.find(t=>own(t)==='source_trace_42'),collisions:R[]=[]
 if(fortyTwo)for(let i=1;i<fortyTwo.route.length;i++){const a=fortyTwo.route[i-1],b=fortyTwo.route[i];if(a.route_type!=='wire'||b.route_type!=='wire'||a.layer!=='inner1'||b.layer!=='inner1')continue;for(let j=1;j<head.length;j++){const actual=segmentDistance([a,b],[head[j-1],head[j]]),required=W+working.minTraceToPadEdgeClearance;if(actual<required-1e-8)collisions.push({owner:'source_trace_42',bodySegment:[i-1,i],headSegment:[j-1,j],actualCenterlineDistanceMm:actual,requiredMm:required})}}
 const releasedBodies:R[]=[]
 if(!headBefore){req(fortyTwo&&collisions.length>0,'Fixed head obstructed by material other than authorized conditional42');const next=ordinary.filter(t=>own(t)!=='source_trace_42');req(headVisible(next),'Removing actual42 collider must clear complete fixed head');ordinary=next;releasedBodies.push(clone(fortyTwo))}
 report.fixedHeadPreflight={passed:headVisible(ordinary),clearWithAll223Bodies:headBefore,source42GeometricCollisions:collisions,releasedBodyOwners:releasedBodies.map(own),releasedBodies:clone(releasedBodies),source42FoundationBranchesRetained:true,allOtherBodiesHard:true};save();req(report.fixedHeadPreflight.passed,'Fixed head foreign clearance')
 const input=walls(ordinary),local={...clone(connection),pointsToConnect:[wire(0,12.2,'top'),clone(ramTop)]},one={...input,connections:[local],buses:[],differentialPairs:[]},scene=new VectorScene(one,local,W,fixedCopper(one))
 const normalize=(points:R[])=>{const reduced=reduceOrdinaryTurns(points,scene).map((p:R)=>({...p,route_type:'wire',layer:'top',width:W})),t={type:'pcb_trace',pcb_trace_id:'d12_top_run',connection_name:N,source_trace_id:N,route:reduced};return chamferOrdinaryCorners(one,[t])[0]}
 const join=(t:R,foundation:R)=>{const branches=foundation.traces.filter((r:R)=>own(r)===own(t)).map((r:R)=>{const end=r.route.at(-1),p=near(end,t.route[0])?t.route[0]:near(end,t.route.at(-1))?t.route.at(-1):null;req(p,'Actual branch endpoint binding '+own(t));return retargetGeneratedEscape(clone(r),p.layer)}),j=joinSignalEscapes(t,branches);req(branches.length===2&&[j.route[0],j.route.at(-1)].every((p:R)=>p.route_type==='wire'&&p.layer==='top'&&foundation.obstacles.some((o:R)=>o.circuitJsonMetadata?.pcb_port_id&&o.connectedTo?.includes(own(t))&&near(p,o.center))),'Joined actual numeric Top pad endpoints');return j}
 // Analyze the exact prefix against the same actual portal event that will
 // be in the final carrier. This local view adds no port identity or output
 // material: the proposed fullspan barrel is fixed only for its incident
 // head-run check, then the complete mixed carrier is qualified afresh.
 const actualPortalTrace={type:'pcb_trace',pcb_trace_id:'analysis_actual_d12_portal_event',connection_name:N,source_trace_id:N,route:[wire(portal.x,portal.y,'inner1'),clone(via),wire(portal.x,portal.y,'top')]}
 const headInput={...input,traces:[...input.traces,actualPortalTrace]},headConnection={...clone(connection),pointsToConnect:[clone(connection.pointsToConnect[0]),wire(portal.x,portal.y,'inner1')]},headTrace={...clone(shell),pcb_trace_id:'analysis_actual_d12_inner1_head',route:clone(head)}
 const headPhysical=qualifyMixedCarrier({...headInput,extraPhysicalHoles:extraHoles(headInput)},headConnection,headTrace,H)
 const portalHoles=extraHoles(input),holeGap=Math.max(input.minViaHoleEdgeToViaHoleEdgeClearance??0,input.minPlatedHoleDrillEdgeToDrillEdgeClearance??0),portalLandViolations=fixedCopper(input).flatMap((c:R)=>{const gap=clearanceToCopper(portal,portal,c),required=VD/2+(input.minViaEdgeToPadEdgeClearance??W);return L.includes(c.layer)&&gap<required-1e-8?[{layer:c.layer,owners:c.owners,actualDistanceToCopperMm:gap,requiredMm:required}]:[]}),portalDrillViolations=portalHoles.flatMap((h:R)=>{const actual=Math.hypot(portal.x-h.x,portal.y-h.y),required=HD/2+h.diameter/2+holeGap;return actual<required-1e-8?[{...h,actualCenterDistanceMm:actual,requiredCenterDistanceMm:required}]:[]}),portalNativeViaLands=nativeLands(actualPortalTrace,input),portalOutlineViolations=boardOutlineViolations(input,[actualPortalTrace])
 const portalPhysical={passed:!portalLandViolations.length&&!portalDrillViolations.length&&portalNativeViaLands.passed&&!portalOutlineViolations.length,allFourLayersChecked:true,actualVia:clone(via),landViolations:portalLandViolations,drillViolations:portalDrillViolations,nativeForeignViaLands:portalNativeViaLands,outlineViolations:portalOutlineViolations}
 const fourInput={...working,traces:[...working.traces,...held,...ordinary.filter(t=>own(t)!=='source_trace_4')]},fourConnection=working.connections.find((c:R)=>c.name==='source_trace_4'),fourPhysical=qualifyMixedCarrier({...fourInput,extraPhysicalHoles:extraHoles(fourInput)},fourConnection,new4,H),fourNative=nativeLands(new4,fourInput),fourJoinedNative=nativeSignalGeometryIsValid(join(new4,working))
 report.beforeSearchPhysicalPreflight={passed:headPhysical.passed&&portalPhysical.passed&&fourPhysical.passed&&fourNative.passed&&fourJoinedNative,head:{actualPortalMaterial:clone(actualPortalTrace),actualHeadConnection:clone(headConnection),analysisViewOnly:true,...headPhysical},portal:portalPhysical,source4:{...fourPhysical,nativeForeignViaLands:fourNative,joinedNativeGeometryPassed:fourJoinedNative},allSourceFlagsRemainFalse:true};save();req(report.beforeSearchPhysicalPreflight.passed,'Actual head/portal/source4 preflight failed before Top search')
 let saved:R|undefined
 const variants=[{step:.04064,halo:1},{step:.02032,halo:1},{step:.01016,halo:1},{step:.02032,halo:2},{step:.01016,halo:2}]
 for(const cfg of variants){
  if(saved||performance.now()-started>budget-35000)break
  const bounds={minX:Math.max(working.bounds.minX,-cfg.halo),maxX:Math.min(working.bounds.maxX,ramTop.x+cfg.halo),minY:Math.max(working.bounds.minY,ramTop.y-cfg.halo),maxY:Math.min(working.bounds.maxY,portal.y+cfg.halo)},record:R={...cfg,bounds,topSuffixMaximumMm:suffixBudget,maximumExpanded:maxExpanded};report.attempts.push(record);save()
  let search:any
  try{
   search=new GridVisibilitySearch(scene,local.pointsToConnect[0],local.pointsToConnect[1],[],0,undefined,{step:cfg.step,bounds,maxLength:suffixBudget,allTerminalAttachments:true,checkReachability:false,paretoLength:false});const begin=performance.now()
   while(!search.solved&&!search.failed&&search.expanded<maxExpanded&&performance.now()-begin<caseMs&&performance.now()-started<budget-35000){search.step();if((search.expanded&8191)===0){record.expanded=search.expanded;save()}}
   record.expanded=search.expanded;record.solved=search.solved;record.failed=search.failed;record.elapsedMs=performance.now()-begin
   if(!search.solved){record.outcome='BOUNDED_TOP_SEARCH_NO_ROUTE_NO_INFEASIBILITY_CLAIM';continue}
   const rawTop={type:'pcb_trace',pcb_trace_id:'raw_d12_top',connection_name:N,source_trace_id:N,route:search.result.map((p:R)=>({...p,route_type:'wire',layer:'top',width:W}))},proposals:R[]=[]
   try{proposals.push(normalize(search.result))}catch(e){record.normalizationError=String(e)}proposals.push(rawTop)
   for(const top of proposals){
    const t:R={...clone(shell),route:[...clone(head),clone(via),...clone(top.route)]};if(top.curvedSegments?.length)t.curvedSegments=top.curvedSegments.map((i:number)=>head.length+1+i)
    const whole=fanout+planar(t),numeric=join(t,working),q=qualifyMixedCarrier({...input,extraPhysicalHoles:extraHoles(input)},connection,t,H),lands=nativeLands(t,input),nativeJoined=nativeSignalGeometryIsValid(numeric)
    const row={carrierTrace:t,joinedNumericPadTrace:numeric,wholeLengthMm:whole,maximumWholeMm:CAP,maximumSatisfied:whole<=CAP+1e-7,physicalQualification:q,nativeForeignViaLands:lands,joinedNativeGeometryPassed:nativeJoined,qualified:q.passed&&lands.passed&&nativeJoined&&whole<=CAP+1e-7,...flags};record.proposals??=[];record.proposals.push(row);fs.writeFileSync(stem+'.raw-candidates.json',JSON.stringify({scope:'DIAGNOSTIC_PROPOSALS_NOT_SOURCE_QUALIFIED',attempts:report.attempts,...flags},null,2)+'\n');save()
    if(row.qualified){saved=clone(t);report.selectedWholeD12Mm=whole;record.outcome='D12_INDEPENDENT_MIXED_PHYSICAL_CHECKS_PASSED';break}
   }
  }catch(e){record.outcome='SEARCH_OR_PROPOSAL_EXCEPTION';record.error=e instanceof Error?e.stack:String(e)}finally{search?.cancel();(globalThis as any).Bun?.gc?.(true);save()}
 }
 if(saved){
  const all=[...held,...ordinary,saved];report.finalScenePhysicalReports=[]
  for(const t of [saved,new4,...all.filter(t=>![N,'source_trace_4'].includes(own(t)))]){
   req(performance.now()-started<budget,'Full scene physical check budget');const x={...working,traces:[...working.traces,...all.filter(r=>own(r)!==own(t))]},c=working.connections.find((c:R)=>c.name===own(t)),q=qualifyMixedCarrier({...x,extraPhysicalHoles:extraHoles(x)},c,t,H),lands=nativeLands(t,x),numeric=join(t,working),nativeJoined=nativeSignalGeometryIsValid(numeric);report.finalScenePhysicalReports.push({owner:own(t),...q,nativeForeignViaLandGap:lands,joinedNativeGeometryPassed:nativeJoined,passed:q.passed&&lands.passed&&nativeJoined});save()
  }
  const names=new Set(held.map(own)),criticalBase={...clone(working),traces:[...working.traces,...ordinary,saved],connections:working.connections.filter((c:R)=>names.has(c.name)),buses:working.buses.map((b:R)=>({...clone(b),connectionNames:b.connectionNames.filter((n:string)=>names.has(n))})).filter((b:R)=>b.connectionNames.length)}
  for(const view of [{name:'DQS1_LOWER_U_SHARED_VIEW',sections:{source_trace_27:[24,28],source_trace_28:[30,34]}},{name:'DQS1_EARLY_MEANDER_SHARED_VIEW',sections:{source_trace_27:[5,12],source_trace_28:[3,10]}}]){
   req(performance.now()-started<budget,'Both critical views budget');const traces=held.map(t=>(view.sections as R)[own(t)]?{...clone(t),coupledSection:clone((view.sections as R)[own(t)])}:clone(t)),x={...clone(criticalBase),differentialPairs:clone(working.differentialPairs)},reports={bus:lengths.busLengthReports(x,traces),pair:lengths.pairLengthReports(x,traces),shared:sh.sharedPairSpacingReports(x,traces),coupling:co.pairCouplingReports(x,traces),exterior:ex.exteriorPairSpacingReports(x,traces)},v=BusLanesSolver.forValidation(x,traces,{smoothTuning:true,denseSearch:true,maxSearchIterations:2000000});for(let k=0;k<8&&!v.failed&&!v.solved;k++)v.step();report.criticalValidationViews.push({scope:view.name,actualDQS1SharedSections:clone(view.sections),reports,c31:{solved:v.solved,error:v.error,failureCode:v.failureCode},passed:v.solved&&Object.values(reports).every((rs:any)=>rs.length===3&&rs.every((r:R)=>r.matched&&r.aboveMinimumLength!==false&&r.withinLengthLimit!==false))});save()
  }
  report.allSavedCarriersCurrentSceneQualified=report.finalScenePhysicalReports.length===all.length&&report.finalScenePhysicalReports.every((r:R)=>r.passed)&&report.criticalValidationViews.length===2&&report.criticalValidationViews.every((r:R)=>r.passed)
  const numeric=all.map(t=>join(t,working)),missing=working.connections.filter((c:R)=>!all.some(t=>own(t)===c.name)).map((c:R)=>c.name)
  const wholeByOwner=new Map<string,number>(all.map(t=>[own(t),lengths.fixedRouteLength(working,own(t))+planar(t)]))
  const originalBusConstraintObservations=working.buses.map((rule:R)=>{
   const present=rule.connectionNames.filter((n:string)=>wholeByOwner.has(n)).map((n:string)=>({owner:n,wholePlanarLengthMm:wholeByOwner.get(n)!})),missingOwners=rule.connectionNames.filter((n:string)=>!wholeByOwner.has(n)),values=present.map((p:R)=>p.wholePlanarLengthMm),observedSkewMm=values.length>=2?Math.max(...values)-Math.min(...values):null,violations:R[]=[]
   for(const p of present){if(rule.minLength!==undefined&&p.wholePlanarLengthMm<rule.minLength-1e-7)violations.push({kind:'ORIGINAL_MIN_LENGTH',owner:p.owner,actualMm:p.wholePlanarLengthMm,requiredMm:rule.minLength});if(rule.maxLength!==undefined&&p.wholePlanarLengthMm>rule.maxLength+1e-7)violations.push({kind:'ORIGINAL_MAX_LENGTH',owner:p.owner,actualMm:p.wholePlanarLengthMm,requiredMm:rule.maxLength})}
   if(rule.maxLengthSkew!==undefined&&observedSkewMm!==null&&observedSkewMm>rule.maxLengthSkew+1e-7)violations.push({kind:'ORIGINAL_MAX_LENGTH_SKEW',actualMm:observedSkewMm,requiredMm:rule.maxLengthSkew})
   return {originalRule:clone(rule),measurement:'WHOLE_PLANAR_XY_CENTERLINE_MM_FANOUTS_PLUS_CARRIER',present,missingOwners,allMembersPresent:missingOwners.length===0,observedSkewMm,violations,observedPlanarConstraintsPassed:missingOwners.length===0&&violations.length===0,electricalTimingQualified:false}
  })
  const originalPairConstraintObservations=working.differentialPairs.map((rule:R)=>{
   const missingOwners=rule.connectionNames.filter((n:string)=>!wholeByOwner.has(n)),values=rule.connectionNames.filter((n:string)=>wholeByOwner.has(n)).map((n:string)=>({owner:n,wholePlanarLengthMm:wholeByOwner.get(n)!})),observedLengthSkewMm=values.length===2?Math.abs(values[0].wholePlanarLengthMm-values[1].wholePlanarLengthMm):null
   return {originalRule:clone(rule),values,missingOwners,observedLengthSkewMm,lengthToleranceSatisfied:observedLengthSkewMm===null?null:observedLengthSkewMm<=rule.lengthTolerance+1e-7,spacingCouplingGeometryExecutedByThisObservation:false,electricalTimingQualified:false}
  })
  const observations=[...ordinary,saved].map(t=>{
   const name=own(t),wholeLengthMm=wholeByOwner.get(name)!,rs=working.buses.filter((b:R)=>b.connectionNames.includes(name));req(rs.length===1,'One original ordinary bus rule per owner');const r=rs[0],pairAnchors=held.filter(h=>r.connectionNames.includes(own(h))).map(h=>({owner:own(h),wholePlanarLengthMm:wholeByOwner.get(own(h))!})),anchorLengths=pairAnchors.map(h=>h.wholePlanarLengthMm),anchorBounded=anchorLengths.length>0&&r.maxLengthSkew!==undefined,derivedLo=Math.max(r.minLength??-Infinity,anchorBounded?Math.max(...anchorLengths)-r.maxLengthSkew:-Infinity),derivedHi=Math.min(r.maxLength??Infinity,anchorBounded?Math.min(...anchorLengths)+r.maxLengthSkew:Infinity),lo=Number.isFinite(derivedLo)?derivedLo:null,hi=Number.isFinite(derivedHi)?derivedHi:null,minimumMatched=lo===null?null:wholeLengthMm>=lo-1e-7
   if(name===N)req(hi!==null&&Math.abs(hi-CAP)<1e-7,'D12 explicit hard cap must equal exact held-pair-derived window')
   return {owner:name,wholeLengthMm,wholePlanarLengthMm:wholeLengthMm,originalBusRule:clone(r),actualHeldPairAnchors:pairAnchors,derivedWholeWindowMm:[lo,hi],minimumBoundPresent:lo!==null,maximumBoundPresent:hi!==null,minimumMatched,maximumSatisfied:hi===null?null:wholeLengthMm<=hi+1e-7,belowMinimumNeedsLengthTuning:minimumMatched===false,physicalConnectivityStageOnly:true,matched:false,timingPassed:false}
  })
  report.ordinaryMinimumLengthObservations=clone(observations);report.minimumLengthFailuresRetained=observations.filter(r=>r.minimumMatched===false).map(r=>r.owner);report.originalBusConstraintObservations=clone(originalBusConstraintObservations);report.originalPairConstraintObservations=clone(originalPairConstraintObservations)
  const candidate={
   ...clone(packet),scope:report.scope+'_CANDIDATE',inputBindings:clone(report.inputBindings),inheritedQualificationEvidence:{finalScenePhysicalReports:clone(packet.finalScenePhysicalReports),criticalValidationViews:clone(packet.criticalValidationViews)},planningOnly:false,
   full49FanoutInput:working,heldCarrierTraces:held,ordinaryCarrierTraces:[...ordinary,saved],carrierTraces:all,joinedNumericPadTraces:numeric,finalScenePhysicalReports:report.finalScenePhysicalReports,criticalValidationViews:report.criticalValidationViews,
   physicalRunReports:report.finalScenePhysicalReports.flatMap((r:R)=>(r.physicalRunReports??[]).map((q:R)=>({owner:r.owner,...q}))),newViaReports:report.finalScenePhysicalReports.flatMap((r:R)=>(r.newViaReports??[]).map((q:R)=>({owner:r.owner,...q}))),
   allSavedCarriersCurrentSceneQualified:report.allSavedCarriersCurrentSceneQualified,originalRulesPreservedLiteral:true,ordinaryMinimumLengthObservations:observations,originalBusConstraintObservations,originalPairConstraintObservations,minimumMatched:observations.filter(r=>r.minimumBoundPresent).every(r=>r.minimumMatched===true),minimumLengthFailuresRetained:clone(report.minimumLengthFailuresRetained),physicalConnectivityStage:'PARTIAL_CONNECTED_TOPOLOGY_UNMATCHED_TIMING_PENDING',
   fixedPortalD12:clone(report.authenticEndpointSelection),source4Overlay:clone(report.source4Overlay),controlledOrdinaryBodyRelease:clone(report.fixedHeadPreflight),
   ordinaryBodyInverses:[...clone(packet.ordinaryBodyInverses??[]),{owner:'source_trace_4',before:clone(old4),after:clone(new4)},...releasedBodies.map(t=>({owner:own(t),before:clone(t),after:null,reason:'PROVEN_FIXED_D12_INNER1_PREFIX_COLLISION'}))],
   atomicFanoutInverses:[...clone(packet.atomicFanoutInverses??[]),selection4.inverse,selected.inverse],releasedWorkingBranchMaterial:[...clone(packet.releasedWorkingBranchMaterial??[]),selection4.inverse,selected.inverse],
   workingChanges:[...clone(packet.workingChanges??[]),{type:'CURRENT223_D12_FIXED_PORTAL_TO_TRUE_RAM_TOP',source4Overlay:clone(report.source4Overlay),endpointInverse:selected.inverse,releasedBodyOwners:releasedBodies.map(own)}],
   dormantWorkingBarrels:[],capturedMixedOwners:ordinary.filter(t=>t.route.some((p:R)=>p.route_type==='via')).map(own),retainedMixedOwners:[N],newViaEventCount:all.reduce((s,t)=>s+t.route.filter((p:R)=>p.route_type==='via').length,0),missingOwnerIds:missing,all49Connected:all.length===49,...flags
  }
  fs.writeFileSync(stem+'.candidate.json',JSON.stringify(candidate,null,2)+'\n',{flag:'wx'});report.candidatePath=stem+'.candidate.json';report.connectedCount=all.length;report.remaining=missing;report.terminalOutcome=report.allSavedCarriersCurrentSceneQualified?'FRESH_COMBINED_PHYSICAL_AND_BOTH_CRITICAL_VIEWS_PASSED_PARTIAL_TOPOLOGY_UNMATCHED':'CANDIDATE_SAVED_COMBINED_PHYSICAL_REPAIR_REQUIRED'
 }else report.terminalOutcome='FINITE_TOP_PORTAL_SEARCH_NO_QUALIFIED_D12_NO_BOARD_INFEASIBILITY_CLAIM'
 req(JSON.stringify({base,held,oldOrdinary})===frozen,'Frozen source materials mutated')
}catch(e){report.terminalOutcome='EXCEPTION_NO_ACCEPTANCE';report.error=e instanceof Error?e.stack:String(e);process.exitCode=2}finally{save()}
console.log(JSON.stringify({out,outcome:report.terminalOutcome,candidatePath:report.candidatePath,allSavedCarriersCurrentSceneQualified:report.allSavedCarriersCurrentSceneQualified,all49Accepted:false}))
