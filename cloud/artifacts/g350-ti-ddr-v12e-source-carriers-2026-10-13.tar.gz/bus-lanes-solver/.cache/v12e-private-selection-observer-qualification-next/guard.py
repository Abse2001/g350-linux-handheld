from pathlib import Path
import hashlib,json,importlib.util,argparse,re,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent/'g350-ti-v12e-actual-core-patched-fanout-public-next'
BASE=ROOT.parent/'g350-count-conditioned-site-recovery-next'
POLICY={'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5}
BUN='/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'
NODE='/workspace/g350-linux-handheld/.cloud-tools/node/bin/node'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def verify():
 raw=(ROOT/'SOURCE-manifest.json').read_bytes();m=json.loads(raw)
 for r in m['files']+m['externalFiles']:
  p=Path(r['path']);assert p.is_file() and not p.is_symlink() and sha(p)==r['sha256'] and p.stat().st_size==r['bytes'] and p.stat().st_mode&511==r['mode'],str(p)
 parent=module('private_observer_held_public',PARENT/'global-selection-guard.py');parent.prepared()
 closed=json.loads(Path(m['previousPublicRecoveredClosurePath']).read_bytes());assert closed['sessionId']==36822 and closed['terminalRecoveredFromCompleteGuardPostaudit'] is True and closed['naturalOutputPresent'] is False
 e=closed['execution'];assert e['cleanupOwnedGroupEmpty'] is True and e['pgid']==286872 and e['diagnosticStopped'] is True and e['stopReasons']==['WALL_STOP'] and not any(e['oomDelta'].values())
 assert closed['postauditSha256']==sha(PARENT/'EXECUTION-postaudit.json') and closed['sourceAndDependenciesHeld'] is True
 scope=module('private_observer_original_owned_scope',BASE/'process_scope.py');assert not scope.owned(286872)
 return m,hashlib.sha256(raw).hexdigest(),parent,scope
def main():
 p=argparse.ArgumentParser();p.add_argument('--preflight-only',action='store_true');p.add_argument('--run-three-controls',action='store_true');p.add_argument('--root-receipt');p.add_argument('--root-receipt-sha256');a=p.parse_args();m,digest,parent,scope=verify()
 if a.preflight_only:print(json.dumps({'sourceOnlyPreflightPassed':True,'packetSha256':digest,'workerStarted':False}));return 0
 assert a.run_three_controls and a.root_receipt and a.root_receipt_sha256
 auth=json.loads(Path(a.root_receipt).read_bytes());assert sha(a.root_receipt)==a.root_receipt_sha256 and auth['authorizedByRoot'] is True and auth['scope']==m['scope'] and auth['packetSha256']==digest and auth['policy']==POLICY and re.fullmatch('[0-9a-f]{32,128}',auth['approvalToken'])
 assert not (ROOT/'run').exists() and not (ROOT/'controls.cjs').exists();before=parent.dependency_check();(ROOT/'run').mkdir(mode=0o700)
 argv=[NODE,str(ROOT/'build.cjs')];(ROOT/'run/build-argv.json').write_text(json.dumps(argv)+'\n')
 commands=[('build',[BUN,'--smol',str(ROOT/'build-leader.ts'),str(ROOT/'run/build-argv.json')]),('node-controls',[NODE,str(ROOT/'controls.cjs'),'--run-one-approved']),('bun-controls',[BUN,'--smol',str(ROOT/'controls.ts'),'--run-one-approved'])]
 executions=[]
 for name,cmd in commands:
  baseline=scope.memory()
  def gate(now):
   assert now['current']+POLICY['rssBytes']+2*1024**3<POLICY['sharedBytes'],'Strict original reserve required'
   assert all(now['events'][k]==baseline['events'][k] for k in scope.OOM_KEYS)
  e=scope.run_guarded(cmd,ROOT,ROOT/'run'/name,POLICY,{'G350_PRIVATE_SELECTION_CONTROL_APPROVED':'1','G350_PRIVATE_SELECTION_CONTROL_ROOT':str(ROOT/'run')},before_spawn=gate);executions.append({'name':name,'execution':e});verify()
  if e['exitCode']!=0 or e['diagnosticStopped'] or not e['cleanupOwnedGroupEmpty'] or any(e['oomDelta'].values()):break
 after=parent.dependency_check();assert before==after;results={name:json.loads((ROOT/'run'/('result-'+name+'.json')).read_bytes()) for name in ['node','bun'] if (ROOT/'run'/('result-'+name+'.json')).exists()}
 good=len(executions)==3 and all(x['execution']['exitCode']==0 and not x['execution']['diagnosticStopped'] and x['execution']['cleanupOwnedGroupEmpty'] and not any(x['execution']['oomDelta'].values()) for x in executions) and len(results)==2 and all(r['passed'] is True and r['actualClassDescriptorAndSelectCachedSeam'] is True and r['noGridOrNativeChecker'] is True and r['actualBoardRoutingPerformed'] is False and r['futureProducerModuleOriginQualified'] is False for r in results.values())
 if len(results)==2:assert {k:v for k,v in results['node'].items() if k not in ['engine','overhead']}=={k:v for k,v in results['bun'].items() if k not in ['engine','overhead']}
 receipt={'passed':good,'executions':executions,'results':results,'dependenciesBefore':before,'dependenciesAfter':after,'sourceHeld':True,'packetSha256':digest,'observerSourceSha256':sha(ROOT/'private-selection-primitives.ts'),'controlsSourceSha256':sha(ROOT/'controls.ts'),'futureProducerModuleOriginQualified':False,'originalPhysicsBudgetOrCacheChanged':False,'actualBoardRoutingPerformed':False,'accepted49':False,'fabricationReady':False}
 (ROOT/'QUALIFICATION-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'passed':good,'receiptSha256':sha(ROOT/'QUALIFICATION-receipt.json'),'executedScopes':len(executions),'futureProducerModuleOriginQualified':False}));return 0 if good else 2
if __name__=='__main__':raise SystemExit(main())
