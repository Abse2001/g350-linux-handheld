"""Own source-only finite scalar proof. No application/SDK imports or calls."""
import json,pathlib,sys,math,hashlib,stat
sys.path.insert(0,str(pathlib.Path(__file__).parent));import joint31_plan as p
sys.path.insert(0,'/tmp/g350-joint-route-progress-beyond28-stdlib-next');import probe_ca6_inner2_detours as own
q,g=p.q,p.g;NAME='source_trace_45';ROOT=pathlib.Path(__file__).parent
PARENT=pathlib.Path('/tmp/g350-source31-explicit-nested-roster-type-successor-sourceonly-next/SOURCE-manifest.json');assert g.sha(PARENT)=='2ec57fbb34c4d86009b89d637868a465ab0b25e321e3e391dbd038bc53aafac1'
parent=json.loads((PARENT.parent/'source31-proposal.json').read_text());assert NAME not in p.SELECTED
choices=json.loads((ROOT/'CA45_TUNED21_4_FINITE_OPTIONS.json').read_text());chosen=choices['results'][1];assert chosen['left']==-10 and chosen['foreignClear'] and chosen['self'][0]
path=[tuple(v)for v in chosen['points']];cpu=p.BRANCHES[NAME,0];ram=p.BRANCHES[NAME,1]
cp=[g.xy(v)for v in cpu['topStub']];rp=[g.xy(v)for v in reversed(ram['topStub'])]
assert math.dist(cp[-1],path[0])<1e-12 and math.dist(path[-1],rp[0])<1e-12
pieces=[dict(role='held_cpu_numeric_to_barrel_stub',layer='top',points=cp),dict(role='new_existing_cpu_to_ram_carrier',layer='inner2',points=path),dict(role='held_ram_barrel_to_numeric_stub',layer='top',points=rp)]
whole=sum(g.plen(c['points'])for c in pieces);assert abs(whole-21.4)<1e-12
foreign=[o for o in q.PRIMS if NAME not in o['owners']];rows=[]
for c in pieces:
 for o in foreign:
  if c['layer']not in o['layers']:continue
  d=min(q.distance(a,b,o)for a,b in zip(c['points'],c['points'][1:]));need=q.required(o,NAME)
  rows.append(dict(role=c['role'],layer=c['layer'],primitive=o['id'],owners=sorted(o['owners']),minimumCenterDistanceMm=d,requiredCenterMm=need,hardSurplusMm=d-o['rad']-g.MARGIN,hardAndClassSurplusMm=d-need))
assert min(r['hardAndClassSurplusMm']for r in rows)>-1e-10
selfResult=own.selfcheck(path);assert selfResult[0]
angles=[]
for a,b,c in zip(path,path[1:],path[2:]):
 u=math.atan2(b[1]-a[1],b[0]-a[0]);v=math.atan2(c[1]-b[1],c[0]-b[0]);angles.append(abs(math.degrees(math.atan2(math.sin(v-u),math.cos(v-u)))))
assert max(angles)<=45+1e-8
stubSelf=min(g.segdist(a,b,c,d)for a,b in zip(cp,cp[1:])for c,d in zip(rp,rp[1:]));assert stubSelf>=3*g.WIDTH
rawpath=pathlib.Path('/tmp/g350-source26-three-stage-root-20261015-after47/core/output/raw-core.json');assert g.sha(rawpath)=='b3c8fedd01b49143ba5edff44e83ae97d20ee1412b0afe450ea0bc2e9783cc64';raw=json.loads(rawpath.read_text())
modelpath=pathlib.Path('/tmp/g350-source26-api-root-20261015-after49/projection/output/GENUINE_CURRENT_CORE49_CONSTRUCTOR_INPUT.json');assert g.sha(modelpath)=='05488bde3f81c13f6deb81350dda26c0b2941491f10f0eaeb807453be62d51e6';model=json.loads(modelpath.read_text())
# Explicit current227 via positions include joint29's moved RAM144; two new fullspan vias are added separately.
existing=[dict(r)for r in raw if r['type']=='pcb_via'];assert len(existing)==227
for v in existing:
 if v['pcb_via_id']=='pcb_via_144':v.update(x=-7.4,y=7.8)
viaRows=[]
for v in existing:
 for piece in pieces:
  if NAME in next((o['owners']for o in q.PRIMS if o['id']==v['pcb_via_id']),set()):continue
  d=min(g.point_segment((v['x'],v['y']),a,b)for a,b in zip(piece['points'],piece['points'][1:]));need=g.WIDTH/2+v['hole_diameter']/2+model['minTraceToHoleEdgeClearance']
  viaRows.append(dict(via=v['pcb_via_id'],role=piece['role'],minimumCenterDistanceMm=d,requiredDrillToTraceCenterMm=need,surplusMm=d-need))
# Original actual numeric endpoint barrels are intentionally joined by the new carrier and held stubs.
ownedNames={cpu['viaName'],ram['viaName']}
controls=json.loads(pathlib.Path('/tmp/g350-source26-three-stage-root-20261015-after47/core/output/core-controls.json').read_text())
ownedIds={r['actualViaId']for r in controls['viaProjection']if r['sourceViaName']in ownedNames}
viaRows=[r for r in viaRows if r['via']not in ownedIds]
for candidate in p.DATA[1:]:
 xy=g.xy(candidate['newStandardThroughVia']['xy'])
 for piece in pieces:
  d=min(g.point_segment(xy,a,b)for a,b in zip(piece['points'],piece['points'][1:]));need=g.WIDTH/2+.127+model['minTraceToHoleEdgeClearance'];viaRows.append(dict(via=candidate['newStandardThroughVia']['proposedSourceLiteralName'],role=piece['role'],minimumCenterDistanceMm=d,requiredDrillToTraceCenterMm=need,surplusMm=d-need))
assert min(r['surplusMm']for r in viaRows)>0
holeRows=[]
for h in raw:
 if h['type']not in('pcb_hole','pcb_plated_hole'):continue
 radius=h['hole_diameter']/2 if h['type']=='pcb_hole' else max(h['hole_width'],h['hole_height'])/2
 for c in pieces:
  d=min(g.point_segment((h['x'],h['y']),a,b)for a,b in zip(c['points'],c['points'][1:]));holeRows.append(dict(hole=h.get('pcb_hole_id',h.get('pcb_plated_hole_id')),holeKind=h['type'],role=c['role'],surplusMm=d-g.WIDTH/2-radius-model['minTraceToHoleEdgeClearance'],conservativeEnclosingCircleForPill=h['type']=='pcb_plated_hole'))
assert min(r['surplusMm']for r in holeRows)>0
keepoutRows=[]
for ko in(r for r in raw if r['type']=='pcb_keepout'):
 rect=(ko['center']['x'],ko['center']['y'],ko['width']/2,ko['height']/2,1.,0.)
 for c in pieces:
  if c['layer']in ko['layers']:keepoutRows.append(dict(keepout=ko['pcb_keepout_id'],role=c['role'],surplusMm=min(g.rectdist(a,b,rect)for a,b in zip(c['points'],c['points'][1:]))-g.WIDTH/2-g.GAP))
assert min(r['surplusMm']for r in keepoutRows)>0
board=next(r for r in raw if r['type']=='pcb_board');outline=[g.xy(v)for v in board['outline']];edges=list(zip(outline,outline[1:]+outline[:1]))
def inside(point):
 x,y=point;odd=False
 for a,b in edges:
  if(a[1]>y)!=(b[1]>y)and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:odd=not odd
 return odd
assert all(inside(v)for c in pieces for v in c['points'])
boardMargin=min(g.segdist(a,b,c,d)-g.WIDTH/2-model['minBoardEdgeClearance']for part in pieces for a,b in zip(part['points'],part['points'][1:])for c,d in edges);assert boardMargin>0
bus=next(b for b in model['buses']if NAME in b['connectionNames']);lengths={c['originalSourceTraceId']:c['expectedWholePlanarMm']for c in parent['selected31OriginalCarriers']if c['originalSourceTraceId']in bus['connectionNames']};lengths[NAME]=whole;span=max(lengths.values())-min(lengths.values());assert bus['minLength']<=whole<=bus['maxLength']and span<=bus['maxLengthSkew']
D=pathlib.Path('/tmp/g350-source45-inner2-west-perimeter-joint31-geometry-sourceonly-next');D.mkdir(mode=0o700,exist_ok=False)
def pin(path):
 path=pathlib.Path(path);b=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),mode=stat.S_IMODE(path.stat().st_mode))
def save(name,obj):
 path=D/name;path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n');path.chmod(0o600);return pin(path)
proposal=dict(scope='UNACCEPTED_SOURCE45_INNER2_WITH_EXISTING_BARRELS_OVER_PROSPECTIVE_JOINT31',originalSourceTraceId=NAME,originalLogicalDeclaration=next(c for c in parent['all49OriginalLogicalTraces']if c['originalSourceTraceId']==NAME),widthMm=g.WIDTH,carrierLayer='inner2',newInner2CarrierPoints=path,pieces=pieces,existingEndpointBranches=dict(cpu=cpu,ram=ram),wholePlanarMm=whole,carrierPlanarMm=g.plen(path),allOriginal49RequestAndBusMetadataHeld=True,originalConnectionAndBus=dict(connection=next(c for c in model['connections']if c['name']==NAME),bus=bus),allPrior31CarriersAnd229BarrelsHeld=True,newVias=0,movedVias=0,changedTopStubs=0,requiredGenuineAdditionalInnerPorts=[dict(viaName=b['viaName'],layer='inner2',numericSelector=b['numericSelector'],viaXY=b['viaXY'])for b in(cpu,ram)],prospectiveOnly=dict(routedOriginalSignals=32,missingOriginal49=17,physicalVias=229,physicalBodyPaths=34,physicalTraces=297,newNonzeroCarrierSegments=len(path)-1),actualParent31Stages=None,futureFreshCoreIds=None,source38Unapplied=True,sourceAccepted=False,all49Accepted=False,referenceQualified=False,electricalTimingPassed=False,fabricationReady=False)
pp=save('SOURCE45_INNER2_GEOMETRY_PROPOSAL.json',proposal)
summary=dict(wholePlanarMm=whole,carrierPlanarMm=g.plen(path),minimumHardTraceSurplusMm=min(r['hardSurplusMm']for r in rows),minimumHardAndClassTraceSurplusMm=min(r['hardAndClassSurplusMm']for r in rows),carrierNonlocalSelfCenterMm=selfResult[1],minimumSelfRequired3Wmm=3*g.WIDTH,maximumOrdinaryTurnDegrees=max(angles),heldTwoTopStubsMutualCenterMm=stubSelf,minimumForeign229DrillTraceSurplusMm=min(r['surplusMm']for r in viaRows),minimumHoleTraceSurplusMm=min(r['surplusMm']for r in holeRows),minimumKeepoutSurplusMm=min(r['surplusMm']for r in keepoutRows),boardEdgeSurplusMm=boardMargin,loadedCaWholePlanarLengthsMm=lengths,loadedCaSpanMm=span,caMinMm=bus['minLength'],caMaxMm=bus['maxLength'],caSkewMaxMm=bus['maxLengthSkew'],allPrior31GeometryPreserved=True,newBarrels=0,endpointBarrelMoves=0,referenceBarrelMoves=0,topStubEdits=0,foreignPrimitiveCount=len(foreign),traceRows=len(rows),drillRows=len(viaRows))
proof=save('SOURCE45_INNER2_FULL_JOINT_SCALAR_PROOF.json',dict(scope='OWN_STDLIB_SCALAR_GEOMETRY_ONLY_NOT_NATIVE_API_OR_ELECTRICAL_QUALIFICATION',proposalPin=pp,summary=summary,traceClearanceRows=rows,foreignViaDrillTraceRows=viaRows,holeRows=holeRows,keepoutRows=keepoutRows,originalViaRosterExplicitJoint29Adjustment=dict(actual26Id='pcb_via_144',afterXY=[-7.4,7.8]),ownedViaJoinIds=sorted(ownedIds),ordinaryJoinedBendRule='Only total turn <=90 degrees and intervening contour <=pi*(width+hardGap) are contour-local; all intersections rejected; every other nonadjacent same-layer pair >=3W.',original49AndJoint31ConstraintsHeld=True,discoveryLimits=dict(boundsMm=[-12,2,6.5,21.8],stepMm=.1,headingStateCap=110000),noGlobalInfeasibilityClaim=True,referencePlaneAndElectricalDelayQualified=False,fabricationReady=False))
manifest=dict(scope='SOURCE_ONLY_SOURCE45_EXISTING_BARREL_INNER2_CANDIDATE_OVER_JOINT31',status='UNACCEPTED_AWAITING_INDEPENDENT_NUMERICAL_REVIEW_AND_FRESH_SOURCE_QUALIFICATION',files=[pp,proof],externalFiles=[pin(__file__),pin(ROOT/'joint31_plan.py'),pin(ROOT/'CA45_EXPANDED_BOUNDS_INNER2_ORIENTED_DISCOVERY.json'),pin(ROOT/'CA45_TUNED21_4_FINITE_OPTIONS.json'),pin('/tmp/g350-joint-route-progress-beyond28-stdlib-next/own_oriented_scalar_grid.py'),pin('/tmp/g350-joint-route-progress-beyond28-stdlib-next/probe_ca6_inner2_detours.py'),pin(PARENT),pin(PARENT.parent/'source31-proposal.json'),pin('/tmp/g350-source31-declaration-capture-core-independent-peer.json'),pin('/tmp/g350-source20-source21-joint29-combined-independent-numerical-peer-next/PEER_REVIEW.json'),pin(rawpath),pin(modelpath)]+[pin(x)for x in p.PINS],summary=summary,noSDKOrAppsOrHelpersOrProcessInspection=True,workspaceWrites=False,sourceOrPipelineAuthored=False,accepted=False,all49Accepted=False,referenceQualified=False,electricalTimingPassed=False,fabricationReady=False)
mp=save('SOURCE-manifest.json',manifest);print(json.dumps(dict(manifest=mp,proposal=pp,proof=proof,summary=summary),indent=2))
