"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/public-failure-fields.ts.cjs
var require_public_failure_fields_ts = __commonJS({
  "qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/public-failure-fields.ts.cjs"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ownPublicFailureFields = ownPublicFailureFields;
    function field(value, key) {
      if (typeof value !== "object" && typeof value !== "function" || value === null)
        return { value: null, kind: "absent", truncated: false };
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor)
        return { value: null, kind: "absent", truncated: false };
      if (!("value" in descriptor))
        return { value: null, kind: "accessor", truncated: false };
      if (descriptor.value === null)
        return { value: null, kind: "null", truncated: false };
      if (typeof descriptor.value !== "string")
        return { value: null, kind: "unsupported", truncated: false };
      return { value: descriptor.value.slice(0, 1024), kind: "string", truncated: descriptor.value.length > 1024 };
    }
    function ownPublicFailureFields(value) {
      const error = field(value, "error"), code = field(value, "failureCode");
      return {
        error: error.value,
        failureCode: code.value,
        errorFieldKind: error.kind,
        failureCodeFieldKind: code.kind,
        errorTruncated: error.truncated,
        failureCodeTruncated: code.truncated
      };
    }
  }
});

// qualified-commonjs:/workspace/bus-lanes-solver/.cache/g350-ti-v12e-c-handoff-length-prune-runtime128-public-next/error-fields-controls.ts.cjs
var __importDefault = exports && exports.__importDefault || function(mod) {
  return mod && mod.__esModule ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var strict_1 = __importDefault(require("node:assert/strict"));
var public_failure_fields_1 = require_public_failure_fields_ts();
var assertions = 0;
var getterCalls = 0;
var coercionCalls = 0;
var check = (value, expected2) => {
  strict_1.default.deepEqual((0, public_failure_fields_1.ownPublicFailureFields)(value), expected2);
  assertions++;
};
var expected = (error, failureCode, errorFieldKind = "string", failureCodeFieldKind = "string", errorTruncated = false, failureCodeTruncated = false) => ({ error, failureCode, errorFieldKind, failureCodeFieldKind, errorTruncated, failureCodeTruncated });
var healthy = { error: null, failureCode: null };
check(healthy, expected(null, null, "null", "null"));
check({ error: "Cannot route original dogbone", failureCode: "local_dogbone_failed" }, expected("Cannot route original dogbone", "local_dogbone_failed"));
check({ error: "e".repeat(1025), failureCode: "f".repeat(1024) }, expected("e".repeat(1024), "f".repeat(1024), "string", "string", true));
var accessor = Object.defineProperties({}, { error: { get() {
  getterCalls++;
  throw Error("Getter must remain uncalled");
} }, failureCode: { get() {
  getterCalls++;
  return "wrong";
} } });
check(accessor, expected(null, null, "accessor", "accessor"));
check(/* @__PURE__ */ Object.create({ error: "inherited", failureCode: "inherited" }), expected(null, null, "absent", "absent"));
check({ error: { toString() {
  coercionCalls++;
  throw Error("Coercion must remain uncalled");
} }, failureCode: false }, expected(null, null, "unsupported", "unsupported"));
check(null, expected(null, null, "absent", "absent"));
check(void 0, expected(null, null, "absent", "absent"));
strict_1.default.equal(getterCalls, 0);
assertions++;
strict_1.default.equal(coercionCalls, 0);
assertions++;
strict_1.default.deepEqual(healthy, { error: null, failureCode: null });
assertions++;
console.log(JSON.stringify({ passed: true, assertions, getterCalls, coercionCalls, solverCalls: 0, nativeCalls: 0, runtimeImports: 0, maximumFieldCharacters: 1024 }));
