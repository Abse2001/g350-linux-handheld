V12e source-only placement proposal and pure React capture control.

Exactly C_DDR_RAM_7, V_TI_RAM7_POWER and V_TI_RAM7_GROUND move rigidly +1.4 mm in X. CPU/RAM pads, all other source props, relative manual reference paths, four physical layers, four signal-class carrier policies and every limit remain exact. The capture compares every original/final tree element, type, key, child and prop, exempting only those three X values.

The proposed-native-input-not-core-forwarded.json is a hypothesis, not actual Core geometry. A separate fresh pinned Core build and all 17 native placement/reference checks must qualify the changed geometry before any full routing attempt. Reference pours remain unqualified for all-four-layer DDR. No routing, export, timing, acceptance or fabrication readiness is claimed.

Run the guard only with a Root-authored exact packet-bound receipt. Policy: 60 seconds, 1 GiB owned RSS, 24 GiB shared cap and 2 GiB prefork reserve. process_scope.py is the unchanged original guard.
