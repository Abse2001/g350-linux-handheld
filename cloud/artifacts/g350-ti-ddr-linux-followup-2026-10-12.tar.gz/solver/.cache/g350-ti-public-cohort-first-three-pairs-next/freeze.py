"""Freeze tools/fresh native data and exact c115177; no runtime calls."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import stat

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/bus-lanes-solver')
ORIGINAL_PREPARED = REPO/'.cache/topology-default-c115121-smol-14400/prepared-manifest.json'
DONOR = REPO/'.cache/g350-c115-byte1-top-first-three-pairs-next'
def item(path, relative=False):
    data=path.read_bytes()
    return {'path':str(path.relative_to(ROOT)) if relative else str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':stat.S_IMODE(path.stat().st_mode)}
assert not (ROOT/'run').exists() and not (ROOT/'run').is_symlink()
assert not (ROOT/'root-launch-receipt.json').exists() and not (ROOT/'root-launch-receipt.json').is_symlink()
prepared=json.loads(ORIGINAL_PREPARED.read_bytes())
assert len(prepared['sourceHashes']) == 177
members=[]
for name, expected in prepared['sourceHashes'].items():
    copied=item(ROOT/'source'/name,True)
    assert copied['sha256']==expected
    assert item(ORIGINAL_PREPARED.parent/'frozen'/name)['sha256']==expected
    assert item(REPO/name)['sha256']==expected
    members.append(copied)
(ROOT/'source-freeze.json').write_text(json.dumps({'sourceCommit':'c1151212be7b9de4b34b07436d135d874e6c0466','libTree':'6c2f08dac7b248f94c2fd1125545031eeaa01e13','sourceFiles':members},indent=2)+'\n')
donor=json.loads((DONOR/'packet-manifest.json').read_bytes())
PUBLIC=REPO/'.cache/g350-ti-v5-public-cohort-init-next'
assert item(PUBLIC/'packet-manifest.json')['sha256']=='2eb569ad473660aba49107efdfb5e9952f49ed76a3b2f31f645d37ff4d4bf152'
for copy,origin in {'input.json':'input.json','original-unrestricted-input.json':'original-unrestricted-input.json','parent-result.json':'run/result.json','parent-postflight.json':'run/postflight.json','parent-actual-public-initial-input.json':'run/actual-public-initial-input.json','parent-actual-public-initial-options.json':'run/actual-public-initial-options.json','parent-actual-public-initial-result.json':'run/actual-public-initial-result.json'}.items():
    assert item(ROOT/copy)['sha256']==item(PUBLIC/origin)['sha256']
assert item(ROOT/'parent-result.json')['sha256']=='9b4520affde162ff27d22111b487295a545d331082f4e1be9370bf2147c285d3'
external=[ORIGINAL_PREPARED,REPO/'package.json',REPO/'tsconfig.json',REPO/'bunfig.toml',Path('/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe'),PUBLIC/'packet-manifest.json',PUBLIC/'input.json',PUBLIC/'original-unrestricted-input.json',PUBLIC/'run/result.json',PUBLIC/'run/postflight.json',PUBLIC/'run/actual-public-initial-input.json',PUBLIC/'run/actual-public-initial-options.json',PUBLIC/'run/actual-public-initial-result.json']
absent=[name.replace(str(DONOR),str(ROOT)) for name in donor['requiredAbsentRuntimeFiles']]
for name in absent: assert not Path(name).exists() and not Path(name).is_symlink(),name
files=[]
for path in sorted(ROOT.rglob('*')):
    if path.is_symlink() or not path.is_file(): continue
    if any(part in ['run','__pycache__','prep-validation'] for part in path.relative_to(ROOT).parts): continue
    if path.name=='packet-manifest.json': continue
    files.append(item(path,True))
manifest={'schemaVersion':1,'preparedUtc':datetime.now(timezone.utc).isoformat(),'sourceRevision':'c1151212be7b9de4b34b07436d135d874e6c0466','libTree':'6c2f08dac7b248f94c2fd1125545031eeaa01e13','originalPreparedPath':str(ORIGINAL_PREPARED),'originalSourceMemberCount':177,'files':files,'externalFiles':[item(path) for path in external],'requiredAbsentRuntimeFiles':absent,'policy':{'wallSeconds':60,'rssBytes':1024**3,'sharedBytes':24*1024**3,'sampleSeconds':.05,'termGraceSeconds':5},'maximumOriginalFactories':3,'producerCaps':{'nativeSiteSteps':4000,'pairedDomainYields':6000,'maxTopologyVariants':2},'publicCaps':{'pipelineIterations':8000000,'nativeSiteSteps':4000,'pairedDomainYields':6000,'guideEvents':24},'captureLimits':{'perArtifactBytes':16*1024**2,'aggregateBytes':64*1024**2},'dependencyReceiptSha256':donor['dependencyReceiptSha256'],'dependencyTreeSha256':donor['dependencyTreeSha256'],'dependencyArchiveSha256':donor['dependencyArchiveSha256'],'inputBindings':{name:item(ROOT/name,True) for name in ['input.json','original-unrestricted-input.json','parent-actual-public-initial-input.json','parent-actual-public-initial-options.json','parent-actual-public-initial-result.json','parent-result.json','parent-postflight.json']},'sourceCaller':'Direct original priorityPairPlans prefix continuing TRUSTED ACTUAL public initialization2eb569/ROOT8582; no new initializer call; original producer source/budgets','allocationPolicy':'PublicsingletonbusAllowedPreferred:BYTE0RESETBottom/BYTE1CMDTop;actual37Top12Bottom24escapes;stricterproducerpolicy;originalunrestricted7e4validationrequired','stop':'First tuple offer or before fourth original routeCoupledPair factory; finally close/restore','previousCopperConsumed':False,'previousClockConsumed':False,'temporaryGuidanceCopperConsumed':False,'originalOrdinaryFactories':0,'algorithmCapsChanged':False,'authorityPathExcludedAndAbsentAtFreeze':True,'actualInitializerRoutingLaunchCount':0,'newCoreCaptureCalls':0,'newInitializerCalls':0,'parentActualPublicInitializationCalls':1,'parentPublicInitializationPacketSha256':'2eb569ad473660aba49107efdfb5e9952f49ed76a3b2f31f645d37ff4d4bf152','parentPublicInitializationResultSha256':'9b4520affde162ff27d22111b487295a545d331082f4e1be9370bf2147c285d3','correctedJobIdAndFullPairIdentityAssociation':True,'checkpointCounts':{'ownedApproaches':24,'bottomRequests':12,'topRequests':37,'pairedOwnedApproaches':4,'terminalAlternatives':0,'pairLayers':['bottom','top','top']},'hardPhysicalReferenceContext':{'basePadObstacles':854,'referenceViaObstacles':2,'serializedViaReferences':2,'uniquePhysicalViaIds':['pcb_via_0','pcb_via_1'],'uniquePhysicalViaCount':2,'originalManualStubRecords':2,'geometryPreservingOnly':True},'rootActualGoRequired':True,'accepted49':False,'tiEligibleBoard':False,'powerPlaneQualified':False,'fabricationReady':False}
(ROOT/'packet-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'packetSha256':item(ROOT/'packet-manifest.json')['sha256'],'localFiles':len(files),'externalFiles':len(external),'sourceMembers':len(members),'inputSha256':manifest['inputBindings']['input.json']['sha256']}))
