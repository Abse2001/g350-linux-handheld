"""Verify a new diagnostic archive and isolated restoration without touching source evidence."""
from pathlib import Path
import hashlib,json,subprocess,sys
project=Path('/workspace/g350-linux-handheld')
manifest=Path(sys.argv[1]).resolve()
output=Path(sys.argv[2]).resolve()
assert output.is_relative_to(project/'.cloud-tools') and not output.exists()
output.mkdir()
restored=output/'restored'
rows=json.loads(manifest.read_text())['files']
results=[]
command=[sys.executable,str(project/'scripts/restore-g350-routing-evidence.py'),str(manifest)]
for label,extra in [('archive-only',['--verify-archive']),('fresh',['--destination',str(restored)]),('repeat',['--destination',str(restored)])]:
 result=subprocess.run(command+extra,text=True,capture_output=True)
 (output/(label+'.log')).write_text(result.stdout+result.stderr)
 assert result.returncode==0,label
 results.append({'stage':label,'exitCode':result.returncode,'stdout':result.stdout.strip()})
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as src:
  for block in iter(lambda:src.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
for r in rows:
 p=restored/r['path'];assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],r['path']
# The existing evidence helper restores bytes only. Explicitly apply the indexed
# modes in this isolated reconstruction, and verify them separately.
for r in rows:
 p=restored/r['path'];p.chmod(r['mode']);assert p.stat().st_mode&0o7777==r['mode']
selected=next(r for r in rows if r['path'].startswith('report/') and r['bytes']<100000)
changed=restored/selected['path'];original=changed.read_bytes();changed.write_bytes(original+b'\nlocal edit refusal control\n')
changed_hash=sha(changed)
result=subprocess.run(command+['--destination',str(restored)],text=True,capture_output=True)
(output/'edited-refusal.log').write_text(result.stdout+result.stderr)
assert result.returncode!=0 and sha(changed)==changed_hash
assert 'Preserving differing local evidence:' in result.stderr and str(changed) in result.stderr
results.append({'stage':'edited-file-refusal','exitCode':result.returncode,'editedBytesPreserved':True,'member':selected['path']})
changed.write_bytes(original)
for r in rows:
 assert sha(restored/r['path'])==r['sha256'] and (restored/r['path']).stat().st_mode&0o7777==r['mode']
report={'manifest':str(manifest.relative_to(project)),'indexedMembers':len(rows),'checks':results,'allRestoredBytesAndAppliedModesVerified':True,'restorerAppliesModes':False,'diagnosticOnly':True,'accepted49':False,'fabricationReady':False}
(output/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'allChecksPassed':True,'indexedMembers':len(rows),'accepted49':False,'fabricationReady':False}))
