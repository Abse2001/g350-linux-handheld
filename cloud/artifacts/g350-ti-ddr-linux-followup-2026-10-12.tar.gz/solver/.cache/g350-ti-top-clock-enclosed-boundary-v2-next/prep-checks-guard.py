"""Only tiny PREP mocks/type controls under the exact future owned policy."""
from pathlib import Path
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("boundary_prep_scope", ROOT / "process_scope.py")
scope = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scope)
POLICY = {"wallSeconds": 30, "rssBytes": 768 * 1024 ** 2, "sharedBytes": 24 * 1024 ** 3,
          "sampleSeconds": .05, "termGraceSeconds": 5}
BUN = "/workspace/g350-linux-handheld/.cloud-tools/bun/node_modules/bun/bin/bun.exe"
mode = sys.argv[1]
commands = {"normal": [BUN, "test", "boundary.test.ts", "grid-telemetry.test.ts"],
            "smol": [BUN, "--smol", "test", "boundary.test.ts", "grid-telemetry.test.ts"],
            "type": [BUN, str(ROOT / "prep-type-worker.ts"), "--type-only"],
            "guard-mocks": ["python", str(ROOT / "guard.test.py")]}


def headroom(current):
    if current["current"] + POLICY["rssBytes"] + 2 * 1024 ** 3 >= POLICY["sharedBytes"]:
        raise ValueError("Strict shared launch headroom unavailable")


execution = scope.run_guarded(commands[mode], ROOT, ROOT / "checks" / ("guarded-v2-" + mode),
                              POLICY, {}, before_spawn=headroom)
print(json.dumps(execution))
raise SystemExit(0 if execution["exitCode"] == 0 and not execution["diagnosticStopped"]
                 and execution["cleanupOwnedGroupEmpty"] else 2)
