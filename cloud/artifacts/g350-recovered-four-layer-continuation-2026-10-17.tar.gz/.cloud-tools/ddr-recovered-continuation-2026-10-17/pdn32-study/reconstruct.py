#!/usr/bin/env python3
"""Finite, stdlib-only G350 PDN32/C16 proposal. Never edits accepted evidence.

Only changed copper is screened. This is not SDK, native DRC, plane, complete
board, source-replay or fabrication qualification. Every inverse is explicit.
"""
import copy
import hashlib
import json
import math
from pathlib import Path
import resource
import signal
import time

resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
resource.setrlimit(resource.RLIMIT_CPU, (55, 55))
signal.alarm(58)
START = time.monotonic()
OUT = Path(__file__).resolve().parent
MODEL = Path('/tmp/g350-four-body-ca18-strong-self-root-20261017-run328/byte0-result.candidate.json')
RAW = Path('/tmp/g350-both-bytes-ca18-model328-core333-raw.json')
CAPTURE = Path('/tmp/g350-both-bytes-ca18-model328-capture-root-20261017-run332/byte0-result.json')
PINS = {
    str(MODEL): '056cac41c6a654b417f6c088d871b8aab41bdaf1bfd42f570acd9dd42d7a09c8',
    str(RAW): 'fcb39e6bb43d972f8d511671ffe30b40819d53aeaeb48fd05d8017f30667990d',
    str(CAPTURE): 'a164a7b04c44096c8d0f9cdcc33fd09d0d4a2e37047f699aebd38aa527cc4237',
}
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p, h in PINS.items():
    assert sha(p) == h, p
model = json.loads(MODEL.read_text())
raw = json.loads(RAW.read_text())
capture = json.loads(CAPTURE.read_text())
scene = model['full49FanoutInput']
assert len(model['joinedNumericPadTraces']) == 49
assert len(scene['traces']) == 263 and len(scene['obstacles']) == 1300
assert scene['layerCount'] == 4
LAYERS = ['top', 'inner1', 'inner2', 'bottom']
assert scene['allowedLayers'] == LAYERS
typed = {(r['type'], r.get(r['type']+'_id')): r for r in raw}
source_traces = {r['source_trace_id']: r for r in raw if r['type']=='source_trace'}
ports = {r['pcb_port_id']: r for r in raw if r['type']=='pcb_port'}
source_ports = {r['source_port_id']: r for r in raw if r['type']=='source_port'}
vias = {r['pcb_via_id']: r for r in raw if r['type']=='pcb_via'}
def trace_net(s):
    return source_traces[s]['subcircuit_connectivity_map_key']
def port_net(s):
    return source_ports[ports[s]['source_port_id']].get('subcircuit_connectivity_map_key')
POWER = trace_net('source_trace_964')
GROUND = trace_net('source_trace_965')
assert trace_net('source_trace_1045') == POWER
assert POWER != GROUND
assert typed['source_manually_placed_via','source_manually_placed_via_32']['source_net_id']=='source_net_5'
assert typed['source_component','source_component_118']['name']=='C_DDR_CPU_16'
assert ports['pcb_port_701']['source_port_id']=='source_port_701'
assert ports['pcb_port_702']['source_port_id']=='source_port_702'
assert source_ports['source_port_82']['pin_number']==83
assert source_ports['source_port_701']['pin_number']==1
assert source_ports['source_port_702']['pin_number']==2
assert vias['pcb_via_32']['pcb_port_ids']==['pcb_port_1225','pcb_port_1226']
assert vias['pcb_via_32']['source_net_id']=='source_net_5'
assert vias['pcb_via_32']['layers']==LAYERS
assert (vias['pcb_via_32']['x'], vias['pcb_via_32']['y'])==(1.6,16)
assert (vias['pcb_via_33']['x'], vias['pcb_via_33']['y'])==(-.8,16.8)
assert len([v for v in vias.values() if int(v['pcb_via_id'].split('_')[-1])<129])==129
assert [(vias['pcb_via_234']['x'],vias['pcb_via_234']['y'],vias['pcb_via_234']['source_net_id']),
        (vias['pcb_via_235']['x'],vias['pcb_via_235']['y'],vias['pcb_via_235']['source_net_id'])]==[(.4,7.2,'source_net_5'),(-1.6,7.4,'source_net_0')]

def point(p): return (p['x'],p['y'])
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def plen(a):return math.hypot(*a)
def dist(a,b):return plen(sub(a,b))
def pseg(p,a,b):
    v=sub(b,a); d=dot(v,v)
    t=max(0,min(1,dot(sub(p,a),v)/d)) if d else 0
    return dist(p,(a[0]+t*v[0],a[1]+t*v[1]))
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def segdist(a,b,c,d):
    ab=sub(b,a);cd=sub(d,c);den=cross(ab,cd)
    if abs(den)>1e-20:
        u=cross(sub(c,a),cd)/den;v=cross(sub(c,a),ab)/den
        if -1e-12<=u<=1+1e-12 and -1e-12<=v<=1+1e-12:return 0.
    return min(pseg(a,c,d),pseg(b,c,d),pseg(c,a,b),pseg(d,a,b))
def local(p,o):
    dx=p[0]-o['center']['x'];dy=p[1]-o['center']['y']
    angle=-math.radians(o.get('ccwRotationDegrees',0));c=math.cos(angle);s=math.sin(angle)
    return (dx*c-dy*s,dx*s+dy*c)
def point_rect(p,o):
    x,y=local(p,o)
    return math.hypot(max(abs(x)-o['width']/2,0),max(abs(y)-o['height']/2,0))
def seg_rect(a,b,o):
    a,b=local(a,o),local(b,o);hx=o['width']/2;hy=o['height']/2
    if any(abs(p[0])<=hx and abs(p[1])<=hy for p in [a,b]):return 0.
    v=[(-hx,-hy),(hx,-hy),(hx,hy),(-hx,hy)]
    return min(segdist(a,b,v[i],v[(i+1)%4]) for i in range(4))
def ob_net(o):
    refs=[s for s in o.get('connectedTo',[])if s in source_traces]
    nets={trace_net(s)for s in refs}
    pids=[p for p in o.get('connectedTo',[])if p in ports]
    nets.update(port_net(p)for p in pids if port_net(p))
    if len(nets)>1: raise AssertionError(('ambiguous obstacle net',o['obstacleId'],nets))
    return next(iter(nets),None)
def wire_segments(t):
    route=t['route'];net=trace_net(t['source_trace_id']);out=[]
    for i,(a,b)in enumerate(zip(route,route[1:])):
        if a.get('route_type')=='wire'and b.get('route_type')=='wire'and a['layer']==b['layer']and dist(point(a),point(b))>1e-10:
            out.append({'trace':t['source_trace_id'],'physicalTrace':t['pcb_trace_id'],'segment':i,'a':point(a),'b':point(b),'width':max(a['width'],b['width']),'layer':a['layer'],'net':net})
    return out
def w(p,layer):return {'route_type':'wire','x':p[0],'y':p[1],'width':.2,'layer':layer}
def route_for(s,coords,layer):
    t=copy.deepcopy(next(t for t in scene['traces']if t['source_trace_id']==s))
    t['route']=[w(p,layer)for p in coords]
    # Source endpoint IDs remain their true aliases; physical order is explicit.
    alias={'source_trace_964':('pcb_port_1226','pcb_port_701'),'source_trace_965':('pcb_port_1228','pcb_port_702'),'source_trace_1045':('pcb_port_1225','pcb_port_82')}[s]
    t['route'][0]['start_pcb_port_id']=alias[0];t['route'][-1]['end_pcb_port_id']=alias[1]
    t['trace_length']=sum(dist(a,b)for a,b in zip(coords,coords[1:]))
    return t
newrefs={
 'source_trace_964':route_for('source_trace_964',[(.8,16.84),(.8,16.309884),(.720116,16.23)],'bottom'),
 'source_trace_1045':route_for('source_trace_1045',[(.8,16.84),(.8,16.8),(1.2,16.4)],'top'),
}
ground_options={
 'A':route_for('source_trace_965',[(-.8,16.8),(-.690116,16.8),(-.120116,16.23)],'bottom'),
 'B':route_for('source_trace_965',[(-.8,16.8),(-.23,16.23),(-.120116,16.23)],'bottom'),
}
obstacles=copy.deepcopy(scene['obstacles']);ob_inverses=[]
for i,o in enumerate(obstacles):
    before=copy.deepcopy(o)
    if o['obstacleId']=='pcb_via_32':o['center']={'x':.8,'y':16.84}
    if o.get('componentId')=='pcb_component_118':o['center']['y']-=.07
    if o!=before:ob_inverses.append({'index':i,'before':before,'after':copy.deepcopy(o)})
assert [i['index']for i in ob_inverses]==[701,702,1201]
byob={o['obstacleId']:o for o in obstacles}
assert all(abs(byob[s]['center']['y']-16.23)<1e-10 for s in ['pcb_smtpad_701','pcb_smtpad_702'])
changedpads=[byob['pcb_smtpad_701'],byob['pcb_smtpad_702']]
changedvia=byob['pcb_via_32']
changedvia['net']=POWER
all_segments=[]
for t in model['joinedNumericPadTraces']:all_segments+=wire_segments(t)
held_refs=[t for t in scene['traces']if t['source_trace_id']not in newrefs and t['source_trace_id']!='source_trace_965']
for t in held_refs:all_segments+=wire_segments(t)
assert len({t['source_trace_id']for t in model['joinedNumericPadTraces']})==49
# The working obstacle catalogue includes package barrels. Include body-inline
# fullspan vias too, rather than assuming they appear in that catalogue.
extra_vias=[]
for t in model['joinedNumericPadTraces']:
 for i,p in enumerate(t['route']):
    if p.get('route_type')=='via':
        assert p.get('layers')==LAYERS and p['via_diameter']==.4572 and p['via_hole_diameter']==.254
        extra_vias.append({'type':'rect','shape':'circle','obstacleId':f"{t['source_trace_id']}:viaEvent:{i}",'layers':LAYERS,'center':{'x':p['x'],'y':p['y']},'width':p['via_diameter'],'height':p['via_diameter'],'net':trace_net(t['source_trace_id']),'isBarrel':True})
all_obs=[]
for o in obstacles:
    q=copy.deepcopy(o);q['net']=ob_net(o);q['isBarrel']=o.get('shape')=='circle'and len(o['layers'])==4
    all_obs.append(q)
all_obs+=extra_vias
newref_segments=[]
for t in newrefs.values():newref_segments+=wire_segments(t)
audits={}
def audit(name,items):
    findings=[];minimum=None;count=0
    for d in items:
        count+=1
        if minimum is None or d['margin']<minimum['margin']:minimum=d
        if d['margin']< -1e-8:findings.append(d)
    audits[name]={'comparisons':count,'findingCount':len(findings),'minimum':minimum,'findings':findings}
def line_obs(seg,o):
    if o.get('shape')=='circle':return pseg(point(o['center']),seg['a'],seg['b'])-o['width']/2-seg['width']/2
    return seg_rect(seg['a'],seg['b'],o)-seg['width']/2
def changed_reference_checks(refs):
    segs=[s for t in refs.values()for s in wire_segments(t)]
    for s in segs:
        for other in all_segments:
            if s['net']==other['net']or s['layer']!=other['layer']:continue
            gap=segdist(s['a'],s['b'],other['a'],other['b'])-(s['width']+other['width'])/2
            yield {'changed':s['trace'],'segment':s['segment'],'other':other['trace'],'otherPhysical':other['physicalTrace'],'otherSegment':other['segment'],'layer':s['layer'],'edgeGap':gap,'required':.1016,'margin':gap-.1016,'kind':'foreign_track'}
        for o in all_obs:
            if s['net']==o['net']or s['layer']not in o['layers']:continue
            gap=line_obs(s,o)
            yield {'changed':s['trace'],'segment':s['segment'],'other':o['obstacleId'],'layer':s['layer'],'edgeGap':gap,'required':.1016,'margin':gap-.1016,'kind':'foreign_obstacle'}
    for i,s in enumerate(segs):
        for o in segs[i+1:]:
            if s['net']==o['net']or s['layer']!=o['layer']:continue
            gap=segdist(s['a'],s['b'],o['a'],o['b'])-(s['width']+o['width'])/2
            yield {'changed':s['trace'],'segment':s['segment'],'other':o['trace'],'otherSegment':o['segment'],'layer':s['layer'],'edgeGap':gap,'required':.1016,'margin':gap-.1016,'kind':'other_changed_reference'}
for option,t in ground_options.items():audit('reference_option_'+option,changed_reference_checks({**newrefs,'source_trace_965':t}))
def via_checks():
    v=changedvia;c=point(v['center']);r=.2286
    for s in all_segments:
        if s['net']==POWER:continue
        gap=pseg(c,s['a'],s['b'])-r-s['width']/2
        yield {'other':s['trace'],'otherPhysical':s['physicalTrace'],'otherSegment':s['segment'],'layer':s['layer'],'edgeGap':gap,'required':.1016,'margin':gap-.1016,'kind':'foreign_track_to_barrel'}
    for o in all_obs:
        if o['obstacleId']=='pcb_via_32':continue
        if o['isBarrel']:
            gap=dist(c,point(o['center']))-.254
            yield {'other':o['obstacleId'],'layers':LAYERS,'drillEdgeGap':gap,'required':.254,'margin':gap-.254,'kind':'drill_to_drill'}
        if o['net']==POWER:continue
        gap=dist(c,point(o['center']))-r-o['width']/2 if o.get('shape')=='circle'else point_rect(c,o)-r
        yield {'other':o['obstacleId'],'layers':o['layers'],'edgeGap':gap,'required':.1016,'margin':gap-.1016,'kind':'foreign_copper_to_barrel'}
audit('moved_via32',via_checks())
def pads_checks():
    for p in changedpads:
        pn=ob_net(p)
        for s in all_segments+newref_segments:
            if s['net']==pn or s['layer']not in p['layers']:continue
            gap=seg_rect(s['a'],s['b'],p)-s['width']/2
            yield {'changed':p['obstacleId'],'other':s['trace'],'otherSegment':s['segment'],'edgeGap':gap,'required':.1016,'margin':gap-.1016,'kind':'pad_to_foreign_track'}
        for o in all_obs:
            if o['obstacleId']==p['obstacleId']or o['net']==pn or not set(o['layers'])&set(p['layers']):continue
            if o.get('shape')=='circle':gap=point_rect(point(o['center']),p)-o['width']/2;req=.1016
            else:
                assert abs(p.get('ccwRotationDegrees',0))<1e-10
                # Exact axis-aligned target rect; obtain distance to all four
                # edges of p from the potentially rotated other rectangle.
                hx=p['width']/2;hy=p['height']/2;cx,cy=point(p['center'])
                cs=[(cx-hx,cy-hy),(cx+hx,cy-hy),(cx+hx,cy+hy),(cx-hx,cy+hy)]
                gap=min(seg_rect(cs[i],cs[(i+1)%4],o)for i in range(4));req=.15
                if point_rect(point(o['center']),p)<1e-12 or point_rect(point(p['center']),o)<1e-12:gap=0.
            yield {'changed':p['obstacleId'],'other':o['obstacleId'],'edgeGap':gap,'required':req,'margin':gap-req,'kind':'pad_to_foreign_obstacle'}
audit('moved_cap16_pads',pads_checks())

def own_circle_intervals(coords,c,r):
    out=[];offset=0
    for a,b in zip(coords,coords[1:]):
        v=sub(b,a);length=plen(v);q=sub(a,c);aa=dot(v,v);bb=2*dot(q,v);cc=dot(q,q)-r*r
        disc=bb*bb-4*aa*cc
        if disc>=-1e-12:
            disc=max(0,disc);u=max(0,(-bb-math.sqrt(disc))/(2*aa));z=min(1,(-bb+math.sqrt(disc))/(2*aa))
            if u<=z:out.append((offset+u*length,offset+z*length))
        offset+=length
    merged=[]
    for a,b in out:
        if merged and a<=merged[-1][1]+1e-8:merged[-1][1]=max(b,merged[-1][1])
        else:merged.append([a,b])
    return {'intervals':merged,'pathLength':offset,'passed':len(merged)==1 and abs(merged[0][0])<1e-8}
own_exits={}
for option,g in ground_options.items():
 for sid,t in {**newrefs,'source_trace_965':g}.items():
    coords=[point(p)for p in t['route']];c=(.8,16.84)if sid!='source_trace_965'else(-.8,16.8)
    own_exits[option+':'+sid]=own_circle_intervals(coords,c,.2286+.1)
assert all(a['passed']for a in own_exits.values())
def own_expanded_rect_intervals(coords,o,expansion):
    # An expanded axis-aligned rectangle conservatively contains the exact
    # rounded rectangle. A single initial contact interval therefore proves
    # no later reentry into the actual pad/trace Minkowski boundary.
    assert abs(o.get('ccwRotationDegrees',0))<1e-10
    c=point(o['center']);hx=o['width']/2+expansion;hy=o['height']/2+expansion
    intervals=[];offset=0
    for a,b in zip(coords,coords[1:]):
        a,b=sub(a,c),sub(b,c);v=sub(b,a);lo,hi=0.,1.;length=plen(v)
        for start,delta,bound in [(a[0],v[0],hx),(a[1],v[1],hy)]:
            if abs(delta)<1e-20:
                if abs(start)>bound:lo,hi=1.,0.;break
            else:
                u,z=sorted(((-bound-start)/delta,(bound-start)/delta));lo=max(lo,u);hi=min(hi,z)
        if lo<=hi:
            u,z=offset+lo*length,offset+hi*length
            if intervals and u<=intervals[-1][1]+1e-8:intervals[-1][1]=max(z,intervals[-1][1])
            else:intervals.append([u,z])
        offset+=length
    return {'intervalsFromRealTerminal':intervals,'pathLength':offset,'passed':len(intervals)==1 and abs(intervals[0][0])<1e-8,'shape':'conservative_expanded_rectangle'}
own_pad_exits={}
for option,g in ground_options.items():
 for sid,t in {**newrefs,'source_trace_965':g}.items():
    coords=list(reversed([point(p)for p in t['route']]))
    if sid=='source_trace_1045':
        pad=byob['pcb_smtpad_82'];assert point(pad['center'])==(1.2,16.4)
        own_pad_exits[option+':'+sid]=own_circle_intervals(coords,point(pad['center']),pad['width']/2+.1)
    else:
        pad=byob['pcb_smtpad_702'if sid=='source_trace_964'else'pcb_smtpad_701']
        assert dist(coords[0],point(pad['center']))<1e-10
        own_pad_exits[option+':'+sid]=own_expanded_rect_intervals(coords,pad,.1)
assert all(a['passed']for a in own_pad_exits.values())

# Typed raw inverses describe prospective regeneration; no frozen/raw file is
# rewritten. All C16-derived visual/courtyard/CAD rows translate with the pose.
typed_inverses=[]
def translate_row(row,dy):
    after=copy.deepcopy(row)
    for field in ['center','anchor_position','position']:
        if field in after:after[field]['y']+=dy
    if 'y'in after:after['y']+=dy
    if 'display_offset_y'in after:after['display_offset_y']+=dy
    for field in ['route','outline']:
        for p in after.get(field,[]):p['y']+=dy
    return after
for i,row in enumerate(raw):
    after=None
    if row.get('pcb_component_id')=='pcb_component_118':after=translate_row(row,-.07)
    elif row['type']=='pcb_port'and row.get('source_port_id')in ['source_port_701','source_port_702']:after=translate_row(row,-.07)
    elif (row['type']=='pcb_component'and row.get('source_component_id')=='source_manually_placed_via_32')or(row['type']=='pcb_port'and row.get('source_port_id')in ['source_port_1225','source_port_1226'])or row['type']=='pcb_via'and row.get('pcb_via_id')=='pcb_via_32':
        after=copy.deepcopy(row)
        if 'center'in after:after['center']={'x':.8,'y':16.84}
        if 'x'in after:after['x']=.8;after['y']=16.84
    if after is not None and after!=row:typed_inverses.append({'rawIndex':i,'before':row,'after':after})

source_nodes=[]
def walk(n,path=()):
    if isinstance(n,dict):
        if 'props'in n and 'type'in n:source_nodes.append((path,n))
        for k,v in n.items():
            if k!='props':walk(v,path+(k,))
    elif isinstance(n,list):
        for i,v in enumerate(n):walk(v,path+(i,))
walk(capture['actualSourceTree'])
def one_node(name):
    found=[(p,n)for p,n in source_nodes if n['props'].get('name')==name];assert len(found)==1,name
    return found[0]
source_inverses=[]
for name,changes in [('C_DDR_CPU_16',{'pcbY':16.23}),('V_TI_HS_C_DDR_CPU_16_POWER',{'pcbX':.8,'pcbY':16.84})]:
    path,n=one_node(name);after=copy.deepcopy(n);after['props'].update(changes)
    source_inverses.append({'path':path,'before':n,'after':after})
source_trace_options={}
for option,g in ground_options.items():
    out=[]
    for sid,t in {**newrefs,'source_trace_965':g}.items():
        name=source_traces[sid]['name'];path,n=one_node(name);after=copy.deepcopy(n);p=after['props'];ref=p['to']
        assert sid!='source_trace_1045'or p['from']=='U_SOC.pin83'
        assert p['thickness']==.2
        anchor=(.8,16.84)if sid!='source_trace_965'else(-.8,16.8)
        # Logical source from/to are preserved. The single middle point is
        # identical under physical route reversal (only three vertices).
        mid=t['route'][1]
        p['pcbPathRelativeTo']=ref
        p['pcbPath']=[{'x':mid['x']-anchor[0],'y':mid['y']-anchor[1]}]
        out.append({'sourceTraceId':sid,'path':path,'before':n,'after':after,'geometry':t,'logicalSourceDirectionPreserved':True,'physicalGeometryOrder':'via_to_real_terminal'})
    source_trace_options[option]=out
def inside_ring(p,vertices):
    inside=False
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        if (a['y']>p[1])!=(b['y']>p[1]):
            x=a['x']+(p[1]-a['y'])*(b['x']-a['x'])/(b['y']-a['y'])
            if p[0]<x:inside=not inside
    return inside
old_pour_containment=[]
for row in raw:
    if row['type']!='pcb_copper_pour':continue
    assert row['shape']=='brep'
    shape=row['brep_shape'];center=(.8,16.84)
    if inside_ring(center,shape['outer_ring']['vertices'])and not any(inside_ring(center,r['vertices'])for r in shape.get('inner_rings',[])):
        old_pour_containment.append({'pourId':row['pcb_copper_pour_id'],'layer':row['layer'],'sourceNetId':row['source_net_id'],'newViaCenterInsideOldCopper':True,'oldGeometryCanQualifyNewPose':False})
assert {p['pourId']for p in old_pour_containment}=={'pcb_copper_pour_0','pcb_copper_pour_49'}
packet={'scope':'UNACCEPTED_STDLIB_ONLY_PDN32_CAP16_RECONSTRUCTION','planningOnly':True,'inputPins':PINS,'sourceInverseNodes':source_inverses,'sourceReferenceOptions':source_trace_options,'typedRawInverseRows':typed_inverses,'obstacleInverses':ob_inverses,'referenceInverses':[{'index':i,'before':t,'afterOptions':({o:ground_options[o]for o in ground_options}if t['source_trace_id']=='source_trace_965'else {'heldBothOptions':newrefs[t['source_trace_id']]})}for i,t in enumerate(scene['traces'])if t['source_trace_id']in ['source_trace_964','source_trace_965','source_trace_1045']],'heldOriginal129PdnViaIds':[f'pcb_via_{i}'for i in range(129)if i!=32],'heldAdditionalPdnViaIds':['pcb_via_234','pcb_via_235'],'originalPhysicalViasRemoved':[],'newPhysicalViasAdded':[],'numericPinsMoved':False,'valueRotationPinMappingChanged':False,'freshPoursRequired':True,'oldPourGeometryReusable':False,'nativeExecuted':False,'sdkExecuted':False,'sourceExecuted':False,'cadExecuted':False,'fabricationReady':False}
packet_path=OUT/'proposal.packet.json';packet_path.write_text(json.dumps(packet,indent=2)+'\n')
report={'scope':packet['scope'],'inputPins':PINS,'scriptSha256':sha(__file__),'packetSha256':sha(packet_path),'audits':audits,'ownViaFirstExitNoReentry':own_exits,'ownRealPadExitNoReentry':own_pad_exits,'sceneCounts':{'joinedDdrOwners':49,'heldFixedTraceBodies':len(held_refs),'heldSceneSegments':len(all_segments),'inputObstacles':len(obstacles),'additionalJoinedDdrViaEvents':len(extra_vias),'changedPadObstacles':2,'changedViaObstacles':1,'typedInverseRows':len(typed_inverses),'sourcePoseInverseNodes':len(source_inverses),'originalPdnBarrels':129,'heldNewCap8PdnBarrels':2},'all49ChangedGeometryPhysicalScreenPassed':all(a['findingCount']==0 for a in audits.values()),'planarDdrGeometryChanged':False,'referenceRouteLengths':{**{k:t['trace_length']for k,t in newrefs.items()},**{'source_trace_965_option'+o:t['trace_length']for o,t in ground_options.items()}},'qualificationLimits':['Changed-geometry finite stdlib screen only; accepted Model328 is unchanged.','Both ground choices evaluated separately against the same accepted49 scene.','Trace, copper, pad, drill checks retain physical widths and all four via layers.','Same-net obstacle exclusions use authenticated original source connectivity keys; drill separation never exempts same-net barrels.','No SDK/native checker execution or fresh source; source pcbPath projection requires Root verification.','No new pour fill; new Power32 position requires fresh GND/DDR_1V5 antipads.','Reference continuity, all-board physical DRC and electrical timing unqualified.'],'elapsedSeconds':time.monotonic()-START,'nativeExecuted':False,'sdkExecuted':False,'cadExecuted':False,'sourceExecuted':False,'fabricationReady':False}
report['oldPourContainmentAtNewViaCenter']=old_pour_containment
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(sha(p)==h for p,h in PINS.items()),'input mutation'
print(json.dumps({'report':str(OUT/'report.json'),'reportSha256':sha(OUT/'report.json'),'packetSha256':sha(packet_path),'audits':{k:{'findings':v['findingCount'],'minimum':v['minimum']}for k,v in audits.items()},'elapsedSeconds':report['elapsedSeconds']}))
