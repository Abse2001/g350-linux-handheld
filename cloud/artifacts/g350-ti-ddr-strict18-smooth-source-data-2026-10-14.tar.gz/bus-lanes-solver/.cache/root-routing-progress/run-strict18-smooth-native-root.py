"""Root serial fresh18 Native/API guard, preserving failed outputs."""
import fcntl,importlib.util,json,os,secrets,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
spec=importlib.util.spec_from_file_location('strict18_capture_stdlib',ROOT/'run-strict18-source-capture-root.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
PACKET=c.BOARD/'.cloud-tools/ddr-strict18-smooth-fresh-native-api-sourceonly-next'
SOURCE_SHA='3f43f30bfa47c4d1e0696c20f9411f8bd2a1f56119b04fa18f0336d16cea12aa'
OUT=PACKET/'run-native'
def main():
 assert len(sys.argv)==3
 peerpath=Path(sys.argv[1]);assert c.sha(peerpath)==sys.argv[2]
 peer=c.read(peerpath);assert peer['sourceManifestSha256']==SOURCE_SHA and peer['decision']=='GO_SOURCE_ONLY_TO_ROOT_READ_AND_GUARDED_SMOOTH_STRICT18_NATIVE_ALL3_APIS'
 assert c.sha(PACKET/'SOURCE-manifest.json')==SOURCE_SHA
 sm=c.read(PACKET/'SOURCE-manifest.json')
 for row in sm['files']+sm['externalFiles']:c.guard.source_guard.binding(row)
 for name in ('node_modules','.pnp.cjs','.pnp.loader.mjs','.yarn'):
  p=PACKET/name;assert not p.exists() and not p.is_symlink()
 _,source_sha=c.bindings();_,old_native_sha,before,sbefore,_=c.guard.checked()
 rows=c.read(c.BOARD/'.cloud-tools/ddr-strict18-smooth-manual-source-core-successor-next/run-core/ROOT_AUTHORITY.json')['actualPriorCollectedRows']+[{'path':r['path'],'sha256':r['sha256']} for r in sm['requiredActualCollections'].values()]
 rows=list({r['path']:r for r in rows}.values())
 def closed():
  for r in rows:assert c.guard.process_scope.owned(c.guard.collected(r)[2]['pgid'])==[]
 closed();assert not OUT.exists() and not OUT.is_symlink();OUT.mkdir()
 binding=c.read(PACKET/'BOUND_MANIFEST_TEMPLATE_NO_AUTHORIZATION.json');binding['sourceManifestSha256']=SOURCE_SHA;binding['files']=sm['files'];binding['externalFiles']=sm['externalFiles'];binding['status']='ROOT_BOUND_FOR_ONE_SERIAL_ACTUAL_NATIVE_API_SCOPE'
 bp=OUT/'BOUND-manifest.json'
 with bp.open('x')as f:json.dump(binding,f,indent=2);f.write('\n')
 bp.chmod(0o600);bh=c.sha(bp)
 authority=c.read(PACKET/'ROOT_AUTHORITY_TEMPLATE_NO_AUTHORIZATION.json')
 authority.update(authorizedByRoot=True,packetSha256=bh,sourceManifestSha256=SOURCE_SHA,rootFullGuardReadPassed=True,noConcurrentRootWorker=True,allPreviousRootWorkersCollected=True,approvalToken=secrets.token_hex(32),nativeSourcePeerReview={'path':str(peerpath),'sha256':sys.argv[2]},actualPriorCollectedRows=rows)
 ap=OUT/'ROOT_AUTHORITY.json'
 with ap.open('x')as f:json.dump(authority,f,indent=2);f.write('\n')
 ap.chmod(0o600);ah=c.sha(ap)
 vs=importlib.util.spec_from_file_location('strict18_binding_stdlib',PACKET/'validate-root-prerequisites.py');v=importlib.util.module_from_spec(vs);vs.loader.exec_module(v);v.validate_binding(binding,authority,bh)
 policy=binding['policy']
 def prefork(mem):
  closed();assert mem['current']+policy['rssBytes']+binding['preforkReserveBytes']<policy['sharedBytes']
 execution=None;error=None
 with (ROOT/'strict18-root-serial.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  try:execution=c.guard.process_scope.run_guarded([sys.executable,'-B',str(PACKET/'run_stage.py')],str(c.BOARD),OUT/'owned',policy,{'G350_STRICT18_NATIVE_BOUND_PATH':str(bp),'G350_STRICT18_NATIVE_BOUND_SHA':bh,'G350_STRICT18_NATIVE_ROOT_AUTHORITY':str(ap),'G350_STRICT18_NATIVE_ROOT_AUTHORITY_SHA':ah,'G350_STRICT18_NATIVE_OWNED_OUTPUT':str(OUT)},before_spawn=prefork)
  except BaseException as ex:
   error=type(ex).__name__+': '+str(ex)
   if (OUT/'owned/execution.json').is_file():execution=c.read(OUT/'owned/execution.json')
  post_error=None;after=None;safter=None;held=False
  try:
   _,nsha,after,safter,_=c.guard.checked();_,ssha=c.bindings();closed()
   for row in sm['files']+sm['externalFiles']:c.guard.source_guard.binding(row)
   v.validate_binding(binding,authority,bh)
   held=old_native_sha==nsha and source_sha==ssha and before==after and sbefore==safter and c.sha(peerpath)==sys.argv[2] and c.sha(PACKET/'SOURCE-manifest.json')==SOURCE_SHA and c.sha(bp)==bh and c.sha(ap)==ah
  except BaseException as ex:post_error=type(ex).__name__+': '+str(ex)
  result=c.read(OUT/'result.json')if (OUT/'result.json').is_file()else None
  passed=held and error is None and post_error is None and execution is not None and execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values()) and result is not None and result['passed']
  files=[{'path':str(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':c.sha(p)}for p in sorted(OUT.iterdir())if p.is_file()and not p.is_symlink()]
  post={'scope':binding['scope'],'sourceManifestSha256':SOURCE_SHA,'coreSourceManifestSha256':binding['coreSourceManifestSha256'],'packetSha256':bh,'execution':execution,'sourceAndDependenciesHeld':held,'dependenciesBefore':before,'dependenciesAfter':after,'solverDependenciesBefore':sbefore,'solverDependenciesAfter':safter,'runFailure':error,'postverificationFailure':post_error,'outputFiles':files,'resultPath':str(OUT/'result.json'),'resultSha256':c.sha(OUT/'result.json')if result else None,'passed':bool(passed),'nativeCalls':result.get('nativeCalls',0)if result else 0,'original3PairApiCalls':result.get('original3PairApiCalls',0)if result else 0,'coreCalls':0,'cliCalls':0,'cadCalls':0,'expectedMissingOriginalSignalCount':31,'referenceQualified':False,'electricalTimingQualified':False,'complete18Accepted':False,'accepted49':False,'fabricationReady':False}
  with (OUT/'POSTAUDIT.json').open('x')as f:json.dump(post,f,indent=2);f.write('\n')
  print(json.dumps({k:post[k]for k in ('passed','sourceAndDependenciesHeld','runFailure','postverificationFailure','nativeCalls','original3PairApiCalls','execution')}));return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
