"""Own pure stdlib transcription of published returning-arm geometry, never imports SDK."""
exec(open('/tmp/g350-actual253-plus-Byte1-static-helper.py').read())
INPUTS=[('/tmp/g350-actual253-plus-Byte1-source32-small-right-pocket-report.json','028e4a0bb4101816aee6503651489da9d865448e71a658e0624cdd19e685bfb5'),('/tmp/g350-actual253-plus-Byte1-source43-six-pocket-meander-left52-report.json','1cde9aaf3c5c99f9141ad8e941bd61f66223185ffdcd2cad5d64ede84b0f1f67'),('/tmp/g350-actual253-plus-Byte1-source14-inner2-new3portal119-matched-finite-v2-report.json','3313fa407ca978c8bcc9faeb71e2baf49ff05c1f30b34c36daaa59c05f0e6e4e')]
def self_math(ps,required=.2032):
 cumulative=[0];turning=[0];unsafe=[0];bad=[];near=[]
 for i in range(1,len(ps)-1):
  a=(ps[i]['x']-ps[i-1]['x'],ps[i]['y']-ps[i-1]['y']);b=(ps[i+1]['x']-ps[i]['x'],ps[i+1]['y']-ps[i]['y']);cr=abs(a[0]*b[1]-a[1]*b[0]);angle=abs(math.atan2(a[0]*b[1]-a[1]*b[0],a[0]*b[0]+a[1]*b[1]));radius=math.inf if cr<1e-12 else math.hypot(*a)*math.hypot(*b)*math.dist((ps[i-1]['x'],ps[i-1]['y']),(ps[i+1]['x'],ps[i+1]['y']))/(2*cr);turning.append(turning[-1]+angle);unsafe.append(unsafe[-1]+int(angle>math.pi/8+1e-8 or radius<required/2-1e-8))
 for a,b in zip(ps,ps[1:]):cumulative.append(cumulative[-1]+math.dist((a['x'],a['y']),(b['x'],b['y'])))
 for i in range(len(ps)-1):
  for j in range(i+2,len(ps)-1):
   a,b,c,d=ps[i],ps[i+1],ps[j],ps[j+1];sep=gbase['sd'](a,b,c,d)
   if sep>=required-1e-8:continue
   gap=cumulative[j]-cumulative[i+1];row={'segments':[i,j],'separationMm':sep,'gapMm':gap}
   if sep<1e-9 and gap>1e-8:row['reason']='nonadjacent_intersection';bad.append(row);continue
   if gap<=math.pi*required+1e-8 and (turning[j]-turning[i]<=math.pi/2+1e-8 or (turning[j]-turning[i]<=math.pi+1e-8 and unsafe[j]==unsafe[i])):row['reason']='contiguous_corner';near.append(row);continue
   sx=sy=0;okay=True
   for k in range(i,j+1):
    dx=ps[k+1]['x']-ps[k]['x'];dy=ps[k+1]['y']-ps[k]['y']
    for delta,axis in [(dx,'x'),(dy,'y')]:
     if abs(delta)<=1e-8:continue
     sign=1 if delta>0 else -1
     if axis=='x':
      if sx and sx!=sign:okay=False
      sx=sign
     else:
      if sy and sy!=sign:okay=False
      sy=sign
   row['reason']='monotone_contiguous_copper' if okay else 'returning_arm_too_close'
   (near if okay else bad).append(row)
 return {'requiredCenterlineMm':required,'passedPureMath':not bad,'failures':bad,'allowedCloseLocalCornerPairs':near,'actualNativeExecuted':False}
gbase=objectsFor(43);rows=[]
for p,sha in INPUTS:
 b=Path(p).read_bytes();assert hashlib.sha256(b).hexdigest()==sha;d=json.loads(b);t=d['bodyInverse']['after'];runs=[];current=[]
 for q in t['route']:
  if q['route_type']=='wire':
   if current and current[-1]['layer']!=q['layer']:runs.append(current);current=[]
   current.append(q)
  else:
   if len(current)>1:runs.append(current)
   current=[]
 if len(current)>1:runs.append(current)
 rows.append({'input':p,'sha256':sha,'owner':owner(t),'runSelfMath':[{'layer':r[0]['layer'],**self_math(r)} for r in runs]})
print(json.dumps([{'owner':r['owner'],'runs':[{'passed':x['passedPureMath'],'failures':x['failures']} for x in r['runSelfMath']]} for r in rows],indent=2))
O='/tmp/g350-actual253-plus-Byte1-byte0-local-self-math-report.json';out={'scope':'OWN_PURE_PYTHON_RETURNING_ARM_GEOMETRY_ONLY_NO_NATIVE_ACCEPTANCE','inputBindings':INPUTS,'rows':rows,'allPureReturningArmChecksPassed':all(r['passedPureMath'] for row in rows for r in row['runSelfMath']),'sdkOrNativeExecuted':False,'all49Accepted':False,'timingPassed':False,'electricalTimingQualified':False,'fabricationReady':False};Path(O).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'report':O,'sha256':hashlib.sha256(Path(O).read_bytes()).hexdigest(),'rows':[{'owner':r['owner'],'passed':all(x['passedPureMath'] for x in r['runSelfMath']),'localPairs':sum(len(x['allowedCloseLocalCornerPairs']) for x in r['runSelfMath'])} for r in rows]},indent=2))
