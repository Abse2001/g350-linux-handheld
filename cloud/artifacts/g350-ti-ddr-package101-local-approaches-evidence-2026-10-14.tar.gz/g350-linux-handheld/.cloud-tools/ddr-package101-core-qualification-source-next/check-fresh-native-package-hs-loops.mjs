// Source-only Root qualification: exact raw Core, native17, known-owner guard.
// Filled references, full power distribution, DDR49 and CAD remain separate.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import * as checks from '/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js'
import {g350DdrPhysicalChecks} from '/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v10-ca-top-bytes-bottom-prefork-successor-next/source/scripts/lib/g350-ddr-physical-checks.mjs'
import {proveSharedPackageLoops} from '/workspace/g350-linux-handheld/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/prove-shared-package-loops.mjs'
import {checkG350ProvedViaBranchManufacturingClearance} from '/workspace/g350-linux-handheld/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/g350-proved-via-branch-manufacturing-clearance.mjs'

const [input,expectedSourceSha,output,...extra]=process.argv.slice(2)
assert(input&&expectedSourceSha&&output&&extra.length===0&&!fs.existsSync(output))
assert.equal(process.versions.bun,'1.3.14')
const sha=raw=>createHash('sha256').update(raw).digest('hex'),raw=fs.readFileSync(input)
assert.equal(sha(raw),expectedSourceSha)
const checkerSha=sha(fs.readFileSync('/workspace/g350-linux-handheld/node_modules/@tscircuit/checks/dist/index.js'))
assert.equal(checkerSha,'1a8af4949af444b5c5488c554e1c1fef9efad0fe5e4c9497554038d0453788cc')
const oldRaw=fs.readFileSync('/workspace/g350-linux-handheld/.cloud-tools/ddr-hs-all32-capture-first-type4096-root-successor-next/run-core/fresh-core.circuit.json')
assert.equal(sha(oldRaw),'384628cd46c2b5cb5b32a94d442651eda3c604c8acf19bd85fc68b728f529769')
const oldNativeRaw=fs.readFileSync('/workspace/g350-linux-handheld/.cloud-tools/ddr-hs-all32-existing-core-pinned-python-readonly-next/run-readonly/native-loop-report.json')
assert.equal(sha(oldNativeRaw),'6d4aa76542317f1e1b4f06fc1e9e3600306fe35f4aa0902a53e2d268e0f17e6e')
const oldNative=JSON.parse(oldNativeRaw)
assert.equal(oldNative.sourceSha256,sha(oldRaw));assert.equal(oldNative.physicalErrors,0)
assert.equal(oldNative.checkCount,18);assert.equal(oldNative.hsTerminalLoops.length,64)
const proposalRaw=fs.readFileSync('/workspace/g350-linux-handheld/.cloud-tools/ddr-package-approaches-source-overlay-next/all101-source-candidate/grouped-proposal.json')
const proposal=JSON.parse(proposalRaw),circuit=JSON.parse(raw),goldenCore=JSON.parse(oldRaw)
assert.equal(proposal.owners.length,101);assert.equal(proposal.viaGroups.length,72)
assert.equal(proposal.viaGroups.filter(g=>g.reuseAcceptedHsViaId===null).length,65)
const signature=JSON.stringify(circuit)
// The proof binds actual numeric pads, actual source traces, known nets and
// alias/barrel ownership before any manufacturing exemption is available.
const proof=proveSharedPackageLoops({proposal,goldenCore,freshCore:circuit})
assert.equal(proof.retainedHsBranches,64);assert.equal(proof.packageBranches,101)
assert.equal(proof.newCanonicalVias,65);assert.equal(proof.reusedCanonicalSites,7)
const results={}
for(const name of [...g350DdrPhysicalChecks,'checkPadPadClearance','checkTracesAreContiguous','checkDanglingTraces','checkPcbTracesOutOfBoard','checkPcbCopperOverKeepout','checkPcbComponentOverlap','checkPcbComponentsOutOfBoard'])results[name]=checks[name](circuit)
assert.equal(Object.keys(results).length,17)
results.checkG350ProvedViaBranchManufacturingClearance=checkG350ProvedViaBranchManufacturingClearance(circuit,proof)
assert.equal(JSON.stringify(circuit),signature,'The proof and every checker must leave raw actual Core unchanged')
const packageRows=proof.branches.filter(b=>b.scope==='NEW_PACKAGE_TOP'),hsRows=proof.branches.filter(b=>b.scope==='RETAINED_ACTUAL_HS_BOTTOM')
assert.equal(packageRows.length,101);assert.equal(hsRows.length,64)
assert.equal(new Set(packageRows.map(b=>b.ownerKey)).size,101)
const physicalErrors=Object.values(results).flat().length
const report={scope:'FRESH_ACTUAL_CORE101_PACKAGE_TOP_AND64_RETAINED_HS_BOTTOM_KNOWN_RAIL_BRANCHES_NATIVE17_STRICT_OWNED_MANUFACTURING',sourceSha256:sha(raw),acceptedHsCoreSha256:sha(oldRaw),acceptedHsNative64ReceiptSha256:sha(oldNativeRaw),proposalSha256:sha(proposalRaw),checkerSha256:checkerSha,checkCount:18,counts:Object.fromEntries(Object.entries(results).map(([k,v])=>[k,v.length])),results,physicalErrors,packageTerminalLoops:packageRows,retainedHsTerminalLoops:hsRows,actualKnownNumericGraphAndOwnedBranchProof:proof,rawNative17InputUnmodified:true,noViaOrTraceForeignOwnerRewritten:true,registeredHs8OnlyIntentionalPadStripContact:true,cadConnectivityStillRequired:true,all165BranchesPhysicallyJoinedToFilledReferences:false,filledReferencesQualified:false,referenceQualified:false,accepted49:false,fabricationReady:false}
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600})
process.exitCode=physicalErrors?1:0
