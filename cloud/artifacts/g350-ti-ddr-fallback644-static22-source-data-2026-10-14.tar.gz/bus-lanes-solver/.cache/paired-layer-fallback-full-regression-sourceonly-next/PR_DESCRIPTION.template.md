Try every reachable layer when routing a coupled pair

When a pair's first common terminal layer is blocked, the router currently returns no_planar_route without trying another reachable layer. This change tries those layers in the existing cost order and commits the first complete atomic pair. All-failed restoration, original routing budgets and pair/output checks remain.

Four regression cases cover blocked-first fallback, clear-only success, every-layer-blocked refusal and unchanged first-layer success. The original implementation failed the minimal blocked-Top/clear-Inner1 fixture; the proposed implementation and exact first-success parity control passed Root96120.

Full default suite: UNRUN (expected644). Eleven original AM3352 benchmarks: UNRUN. Replace these lines only with actual collected results and disclose any failure. Source-only stage and old baseline remain preserved. Historical wall timing is descriptive; no controlled performance pass is claimed.

No G350 all49/reference/electrical/fabrication qualification is implied. Any PR route gallery must contain only complete accepted benchmark routes and be individually inspected.
