import { Children, cloneElement, isValidElement, type ReactElement, type ReactNode } from "react"
import OriginalV7 from "./am3352-g350-ti-top-bottom-ddr-v7-ram-right-layout.circuit"
import translation from "../lib/am3352/placement/g350-ti-top-bottom-ddr-v9-y0_2-translation.json"
type Props = Record<string, unknown> & { name?: string; children?: ReactNode }
// NEW V9 proposal: original V7 RAM270 and its17 supports move +.2mmY.
// Source logic, CPU/CPU13, all numeric contact IDs and four layers are retained.
// RAM7's vias and capacitor both move, so both manual bypass stubs (including
// the existing relative ground-path midpoint) move rigidly with their owners.
function translateRamCohort(node: ReactNode): ReactNode {
  if (!isValidElement<Props>(node)) return node
  const props = { ...node.props }
  const move = (translation.parts as Record<string, Record<string, unknown>>)[props.name ?? ""]
  const reference = (translation.references as Record<string, Record<string, unknown>>)[props.name ?? ""]
  if (move) Object.assign(props, move)
  if (reference) Object.assign(props, reference)
  if (node.type === "board") props.routeRemaining = false
  return cloneElement(node as ReactElement<Props>, props, ...Children.toArray(node.props.children).map(translateRamCohort))
}
export default () => translateRamCohort(OriginalV7())
