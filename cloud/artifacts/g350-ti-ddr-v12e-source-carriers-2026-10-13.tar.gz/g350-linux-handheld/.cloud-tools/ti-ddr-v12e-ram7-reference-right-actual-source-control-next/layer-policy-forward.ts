import assert from "node:assert/strict"
import policy from "/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12d-byte0-top-reset-bottom-next/v12d-layer-policy.json"
/** Final authored four-carrier props bridge only: Core source_bus omits these fields. */
export function projectAuthoredLayerPolicy(full:any[],baseline:any,proof:any){
 assert.equal(proof.policyAppliedAfterAllV9Wrappers,true);assert.equal(proof.coreCircuitJsonOmitsLayerAndAbsoluteLengthFields,true)
 const traces=new Map(full.filter(r=>r.type==="source_trace").map(r=>[r.source_trace_id,r]))
 const buses=new Map(full.filter(r=>r.type==="source_bus").map(r=>[r.name,r]))
 assert.equal(baseline.connections.length,49);assert.equal(baseline.obstacles.length,856);assert.equal(baseline.traces.length,2);assert.equal(baseline.layerCount,4)
 assert.deepEqual(baseline.allowedLayers,["top","inner1","inner2","bottom"]);assert.equal(proof.groups.length,4);assert.equal(proof.pairs.length,3)
 const result=policy.groups.map((g,i)=>{
  const expected=g.nativeBus,source=buses.get(expected.busId);assert.ok(source);assert.deepEqual(baseline.buses[i],expected)
  assert.deepEqual(source.source_trace_ids,expected.connectionNames);assert.deepEqual(source.source_trace_ids.map((id:string)=>traces.get(id)?.name),g.logicalConnections);assert.equal(source.max_length_skew,expected.maxLengthSkew)
  for(const key of ["allowedLayers","allowed_layers","pcb_allowed_layers","preferredLayers","preferred_layers","minLength","maxLength","min_length","max_length"])assert.equal(source[key],undefined,"Pinned source_bus seam changed")
  const expectedProps:Record<string,unknown>={busId:expected.busId,connections:g.logicalConnections,pcbTraceWidth:expected.traceWidth,pcbAllowedLayers:expected.allowedLayers,preferredLayers:expected.preferredLayers}
  for(const key of ["maxLengthSkew","minLength","maxLength"] as const)if(expected[key]!==undefined)expectedProps[key]=expected[key]
  assert.deepEqual(proof.groups[i],expectedProps);return {...expected,connectionNames:[...source.source_trace_ids]}
 })
 const pairs=policy.pairs.map((g,i)=>{
  assert.deepEqual(g.nativePair,baseline.differentialPairs[i]);const source=buses.get(g.name);assert.ok(source);assert.deepEqual(source.source_trace_ids,g.nativePair.connectionNames);assert.equal(source.max_length_skew,g.nativePair.lengthTolerance)
  assert.deepEqual(source.source_trace_ids.map((id:string)=>traces.get(id)?.name),g.logicalConnections)
  assert.deepEqual(proof.pairs[i],{name:g.name,ownerBusId:g.ownerBusId,positiveConnection:g.logicalConnections[0],negativeConnection:g.logicalConnections[1],maxLengthSkew:g.nativePair.lengthTolerance,pcbTraceGap:g.nativePair.traceGap})
  const owner=result.find(r=>r.busId===g.ownerBusId);assert.ok(owner&&g.nativePair.connectionNames.every(id=>owner.connectionNames.includes(id)));return {...g.nativePair,connectionNames:[...source.source_trace_ids]}
 })
 const members=result.flatMap(b=>b.connectionNames);assert.equal(members.length,49);assert.equal(new Set(members).size,49);assert.deepEqual(new Set(members),new Set(baseline.connections.map((c:any)=>c.name)))
 return {buses:result,differentialPairs:pairs,report:{scope:"EXPLICIT_V12E_AUTHORED_FOUR_CARRIER_PROPS_TO_ACTUAL_CORE_SOURCE_BUS_BRIDGE",derivedMembershipAndSkewFromActualPinnedCoreSource:true,sourceBusDoesNotPersistLayersPreferencesOrAbsoluteWindows:true,finalAuthoredReactPropsUsedForLayerAndAbsoluteWindowBridge:true,policyAppliedAfterAllV9Wrappers:true,allocation:{top:11,inner1:26,inner2:11,bottom:1},allOriginalPairMembershipsSkewGapAndLengthWindowsHeld:true,authoredPolicyProof:proof,referenceQualified:false,TIplaneArrangement:false,accepted49:false,fabricationReady:false}}
}
