# Pending Source0 work: planning only

The accepted routing-model checkpoint is actual318, candidate SHA
`be1a7d412678c7942b3f3e22a8b4828826c3c90c806ff6257b74cbf528f7f731`.
Its Source37 is 21.2 mm and CA17/26 meet the original minimum. Both complete
eleven-signal byte cohorts remain matched. This note changes no candidate.

## Frozen evidence

- Source37 complete own pure proof: `/tmp/g350-actual299-source37-matched21p2-three-width-full49-own-audit-report.json`, SHA `3a1e219b8608cb68e2e4cd121cc267936f53e1f9ae6c723755651338f38dbfa4`.
- Independent Source37 proof: `/tmp/g350-actual299-source37-three-width-independent-peer-report.json`, SHA `ac458b29a383c9e44c7337c602c662e8059130c90edf1f15f411f76d4a0366ee`.
- Finite CPU0 four one-owner relaxations: `/tmp/g350-actual299-plus-matched37-source0-four-one-owner-frontier-controls-report.json`, SHA `3f297c78d8ca77717a9909162cd93df0d55d8fafa94fcaf49d0845173bf045ae`.
- Source18 native-clear partial north-header proposal: `/tmp/g350-actual299-plus-matched37-source18-narrow-U-opens0-north-head-planning-report.json`, SHA `76bdbd5f8179fd9d024c36d90ccbf3d28951fa6b2e753f29b2b690b9796329c9`.
- RAM0 Bottom negative: `/tmp/g350-actual299-plus-matched37-source0-RAM-Bottom-north-frontier-report.json`, SHA `d0e61f537e4ed1a9867cdaa49bdbb425b4ff9fe634123248808f0cb6cecbab73`.
- RAM0 Inner2 negative: `/tmp/g350-actual299-plus-matched37-source0-RAM-I2-canonical-portals-finite-report.json`, SHA `fd3204bac2303acff5bd9c9dfbbb34423716128018c4b8b1c11493c91c53f589`.
- Ground79 retirement/I2-to-I1 negative: `/tmp/g350-actual299-plus-matched37-ground79-retire-I1-transfer-component-report.json`, SHA `e7a5f2d256aacb9cf28e82672288afbea3ca68d314657333367b98d014b1ce4d`.

The actual299 plus exact proposed37 physical scene equals318 geometry. No
qualification of a future successor may be inherited from that equivalence.

## Findings

CPU0 uses the real fullspan working site (-1.6,12.8), actual Top ball (-2,13.2).
RAM0 uses the real fullspan working site (.4,11), actual Top ball (0,10.6).
Use literal packet objects and numeric IDs before authoring any route.

Removing only Source19 body has no effect. Relaxing Source18 or26 opens the
northern I1 area, but both are matched and require complete replacements.
CPU0's original northern dogbone column admits only one native-clear wire:
foreign barrels at x=-1.6 and-.8 leave a .038 mm wire-center window near
y=13.6/14.4. A same-layer outgoing/return pair cannot share that window.

The native-clear proposed18 narrow U retains all real endpoints/branches and
has whole21.478800683 mm. It opens a clear I1 CPU0 header through row16.4.
Its compact upper local corners FAIL the stronger3W self observation, which
is explicitly recorded. It is an unaccepted partial topology proposal.

RAM0 Bottom is enclosed by35/42/2/power54; RAM0 I2 is enclosed by39/26/GND89/42.
Neither currently reaches any northern portal. Existing129 reference vias,
two capacitor PDN vias and all165 reference traces were held in those tests.

The following canonical new signal portal sites were individually clear in
the proposed18-plus37 scene under fullspan .4572/.254, .15 via-via and actual
pad/drill geometry: (.8,19.2),(1.6,20.8),(2.4,16),(2.4,18.4),(2.4,19.2).
The I1 header to (2.4,16) is clear and7.414213562 mm long. None is reachable
from RAM0 on the tested other layers. They are not installed material.

## A finite next hypothesis, not a checked proposal

Instead of deleting references, consider a coordinated ordinary-signal-only
return-door redesign involving39,26 and42, preserving all true numeric nets:

1. Source39 I2 can potentially shift its vertical x=-.392 left only below
   the CPU working barrels. A full-column left shift is blocked by the real
   Source5/25 CPU barrels. Keep the old stem down to approximately y13.0,
   then shift to x=-.492. Its lower SE diagonal may need to descend by another
   .1 mm to maintain3W to the proposed0 path. Source39 is already matched;
   every change requires a whole-length and native/self proof.
2. Source26's first inline fullspan P(0,12.25) and its I1/I2 prefixes may
   potentially move to P(.25,12.2). Its I1 lead would end through
   (-.4134,12.8634)->P. This is NOT yet physically screened. Critical16's
   neighboring diagonal constrains this site; no critical exemption is allowed.
3. Source42's second inline fullspan B(.41224,11.78256) could potentially
   move to (.52,11.62), with a genuine Bottom/Top before/after inverse. The
   moved B must clear26's I2 path, so26 would need a coordinated small right
   bulge. A possible shape is P->(.6,12.2)->(1.15,11.65)->(1.15,11.55)
   ->(.8,11.2)->(.8,8.35), retaining its real lower R(1.2,7.95).

These are typed coordinate planning suggestions only. They have NOT been
run through the physical helper, all49 reciprocal checks, self checks, full
byte matching, or native/Core. They do not constitute an open RAM0 return.
Do not author an SDK worker until one complete0 route and all affected
connected/matched replacements have a concrete pure proof.

Any future proposed via event needs exact inverse records and honest planned
identity status until fresh Source assigns real ports/IDs. Preserve all
critical6, full49 roster, four layers and original literal rules. No bit or
pin swaps. Keep full TI/reference-plane/impedance/electrical/fabrication
qualification false until those separate gates actually pass.
