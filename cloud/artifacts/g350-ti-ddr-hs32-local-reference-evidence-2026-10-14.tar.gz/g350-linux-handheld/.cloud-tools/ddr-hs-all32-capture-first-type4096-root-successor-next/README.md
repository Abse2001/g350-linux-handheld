# Capture-first and separate full type qualification

No runtime imports, typecheck, Core/native, routing or export was run while preparing this successor. The two previous failed packets stay frozen. All source overlay/capture/Core harness/owner JSON/native assertions/fixtures are byte-identical to the prior packet; only stage orchestration, resource metadata and source-closure bindings change.

Root51287 exhausted V8's640MiB heap in5.3266s; Root75470 exhausted1280MiB in41.331s. Both guards collected exit2 with zero cgroup OOM deltas, clean empty groups and held source/dependencies. The unchanged native helper syntax passed. Neither prior attempt reached source capture or Core. Raising the RSS cap had not removed the V8 heap ceiling.

Static inspection, not an allocation profile, identifies a large inherited type closure: pinned Core declarations10,140,768 bytes/203,401 lines; props declarations11,369,696 bytes/248,852 lines; four historical routing JSON imports total7,380,463 bytes. Those caches remain imported even though the final layout disables routing. The new owner JSON is323,875 bytes and its64 rows have three regular field shapes; its owner arrays are explicitly cast before use. There is no evidence that this local JSON alone causes the OOM. The source JSON/module code stays unchanged; no old hardware typing is stubbed or ignored, and compiler flags/assertions are retained.

| Phase | Wall / owned RSS | Shared / reserve | Work |
| --- | --- | --- | --- |
| `capture` |60s /1GiB |24GiB /2GiB |Unchanged exact1746-original/124-added React capture first |
| `types` |120s /6GiB |31GiB /1GiB |Unchanged native-helper syntax check and actual-source TypeScript flags; Node heap4096MiB |
| `core` |120s /3GiB |26GiB /2GiB |Unchanged one directCore render, strict original0e parity, native17/64 graphs/manufacturing |

Exact current-memory prefork thresholds are22,548,578,304 bytes for capture/Core and25,769,803,776 bytes for types. Node heap is a V8 limit inside the6GiB owned-group sampled guard, not a new unchecked memory allowance. The tested pidfd/WNOWAIT/subreaper helper and installed dependency inventory are unchanged.

Root must collect capture before launching types. A collected failed capture may allow type diagnosis, but Core always requires **both capture and type stages to have naturally passed and been collected**, with held source/dependencies, zero OOM deltas and empty owned groups. No CLI, Docker, CAD export or autorouting is permitted in these stages. DirectCore retains schematic/routing-disabled flags. Hardware/source/Circuit JSON assertions and the ownership-only manufacturing projection stay exact.

Root receipt schema remains `authorizedByRoot:true`, `phase`, `scope`, exact `packetSha256`/`policy`, `allPreviousRootWorkersCollected:true`, `noConcurrentRootWorker:true`, hex `approvalToken`, and nonempty `previousClosedPostaudits:[{path,sha256}]`. Each subsequent stage receipt also binds actual Root collection records as `captureRootCollectionPath`/`captureRootCollectionSha256`, and for Core `typesRootCollectionPath`/`typesRootCollectionSha256`. Collection records contain `authorizedByRoot:true`, stage `phase`, matching `packetSha256`, `toolSessionCollected:true`, actual `toolWrapperExitCode`, exact postaudit path and hash. Never invent an exit for a lost session.

```bash
source /workspace/g350-linux-handheld/cloud/env.sh
python3 -B /workspace/g350-linux-handheld/.cloud-tools/ddr-hs-all32-capture-first-type4096-root-successor-next/guard.py --phase capture --root-receipt ABS_CAPTURE_AUTHORITY --root-receipt-sha256 EXACT_HASH
python3 -B /workspace/g350-linux-handheld/.cloud-tools/ddr-hs-all32-capture-first-type4096-root-successor-next/guard.py --phase types --root-receipt ABS_TYPES_AUTHORITY --root-receipt-sha256 EXACT_HASH
python3 -B /workspace/g350-linux-handheld/.cloud-tools/ddr-hs-all32-capture-first-type4096-root-successor-next/guard.py --phase core --root-receipt ABS_CORE_AUTHORITY --root-receipt-sha256 EXACT_HASH
```

Each phase uses a fresh exclusive `run-PHASE` directory. Capture/type ordering does not waive either gate. Prior failures, original217 logical links,280 real parts/1161 original contacts,64 actual local cap-to-owned-via graphs, exact RAM7 physical records and all physical/native assertions remain required. No passing stage qualifies filled reference planes,49 DDR interconnects, impedance/PDN/electrical timing or fabrication. `fabricationReady=false`.
