import assert from "node:assert/strict"

/** Exact public output only after normal completion; this is not physical acceptance. */
export function originalNaturalPublicOutput(
  solver: {
    solved: boolean
    failed: boolean
    traces: Array<{ connection_name?: string; source_trace_id?: string }>
    getOutput(): unknown
  },
  terminal: { termination: string } | undefined,
  input: {
    connections: Array<{ name: string }>
    traces?: unknown[]
  },
): { raw: Buffer; output: unknown } | null {
  if (terminal?.termination !== "NATURAL_SOLVED") return null
  assert.equal(solver.solved, true)
  assert.equal(solver.failed, false)
  assert.equal(input.connections.length, 49)
  assert.equal(input.traces?.length, 2)
  const names = solver.traces.map((t) => t.connection_name ?? t.source_trace_id)
  const expectedNames = new Set(input.connections.map((c) => c.name))
  assert.equal(solver.traces.length, 49)
  assert.equal(expectedNames.size, 49)
  assert.equal(new Set(names).size, 49)
  assert(
    names.every((name) => typeof name === "string" && expectedNames.has(name)),
  )
  // Original receiver, no arguments, exactly one original public call.
  const output = solver.getOutput()
  assert(output !== null && typeof output === "object")
  const actual = output as { traces?: unknown[] }
  assert(Array.isArray(actual.traces))
  assert.equal(actual.traces.length, 51)
  assert.equal(
    JSON.stringify(actual.traces.slice(0, 2)),
    JSON.stringify(input.traces),
  )
  assert.equal(
    JSON.stringify(actual.traces.slice(2)),
    JSON.stringify(solver.traces),
  )
  const serialized = JSON.stringify(output)
  assert.equal(
    serialized,
    JSON.stringify({ ...input, traces: [...input.traces!, ...solver.traces] }),
  )
  return { raw: Buffer.from(`${serialized}\n`), output }
}
