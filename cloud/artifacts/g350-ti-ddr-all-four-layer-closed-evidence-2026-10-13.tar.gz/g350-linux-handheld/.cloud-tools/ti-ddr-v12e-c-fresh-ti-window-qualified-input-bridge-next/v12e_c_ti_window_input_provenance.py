"""Fresh actual C TI CA length metadata over unchanged measured E geometry."""
from pathlib import Path
import copy,hashlib,importlib.util,json,stat,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PARENT=Path('/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-c-cohort-qualified-input-bridge-next')
LAYERS=['top','inner1','inner2','bottom']
CARRIERS={'DDR_RESET':'top','DDR_BYTE0':'bottom','DDR_BYTE1':'inner2','DDR_COMMAND_CLOCK':'inner1'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def require(v,s):
 if not v:raise ValueError(s)
def verify_rows(base,rows):
 for row in rows:
  p=base/row['path'] if base else Path(row['path'])
  require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Frozen member changed: '+str(p))
def verify(expected_manifest_sha256):
 require(sha(ROOT/'SOURCE-INPUT-manifest.json')==expected_manifest_sha256,'Exact fresh TI bridge manifest required')
 m=load(ROOT/'SOURCE-INPUT-manifest.json');verify_rows(ROOT,m['files']);verify_rows(None,m['externalFiles'])
 spec=importlib.util.spec_from_file_location('g350_fresh_ti_parent_c_provenance',PARENT/'v12e_c_input_provenance.py');parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent)
 inherited=parent.verify(m['parentBridgeManifestSha256'])
 require(inherited['freshCircuitSha256']==m['reusedActualCoreGeometrySha256']=='0e2ce064e896db1d087474716d2e82b86155dbe28eecf28ce1727e73a466fee1' and inherited['nativePlacementChecks']==17 and inherited['nativePlacementErrors']==0,'Original measured E Core/native17 required')
 source=Path(m['sourceDirectory']);packet=load(source/'CAPTURE-manifest.json')
 require(sha(source/'CAPTURE-manifest.json')==m['capturePacketSha256'],'Actual fresh TI capture packet changed');verify_rows(source,packet['files']);verify_rows(None,packet['externalFiles'])
 spec=importlib.util.spec_from_file_location('g350_fresh_ti_pure_json_endpoint_audit',source/'audit_ti_endpoints.py');audit_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit_module);audit=audit_module.audit()
 require(audit['freshCAWindowMm']==[20.95,23.49] and audit['caclmMm']==22.22 and audit['caToleranceMm']==1.27 and abs(audit['maximumManhattanMm']['DDR_COMMAND_CLOCK']-14.6)<1e-7,'Fresh actual C pad endpoints and TI formula required')
 require(sha(source/'endpoint-ti-audit.json')==m['endpointAuditSha256'],'Exact endpoint audit required')
 actual=load(source/'run/actual-final-props.json');receipt=load(source/'run/RECEIPT.json');e=receipt['execution'];derived=load(source/'derived-final-authored-props.json');root_collection=load(m['rootCollectedReceiptPath'])
 require(sha(source/'run/actual-final-props.json')==m['actualCaptureSha256'] and sha(source/'run/RECEIPT.json')==m['actualCaptureReceiptSha256'] and sha(m['rootCollectedReceiptPath'])==m['rootCollectedReceiptSha256'],'Exact actual capture and outside Root collection required')
 require(root_collection['sessionId']==69934 and root_collection['toolExitCode']==0 and root_collection['receiptSha256']==m['actualCaptureReceiptSha256'] and root_collection['receipt']==receipt,'Original Root69934 completed capture must remain exact')
 require(receipt['passed'] is True and receipt['sourceHeld'] is True and receipt['sourceManifestSha256']==m['capturePacketSha256'] and receipt['captureSha256']==m['actualCaptureSha256'] and e['exitCode']==0 and e['diagnosticStopped'] is False and e['cleanupOwnedGroupEmpty'] is True and not any(e['oomDelta'].values()) and receipt['boardDependenciesBefore']==receipt['boardDependenciesAfter'],'Actual source/dependency-held fresh TI pure capture required')
 require(actual['scope']=='PURE_ACTUAL_V12E_C_FRESH_TI_CA_TWO_LENGTH_PROPS_ONLY' and actual['actualFinalReactTreeEvaluated'] is True and actual['comparedElements']==1746 and actual['allOtherTreePropsTypesKeysChildrenExactlyHeld'] is True and actual['changedLengthProps']==packet['twoLengthPropChanges'],'Exactly two actual CA length props changed')
 for key in ['placementProposal','authoredPolicyProof','referenceCopperCandidates','globalSignalLayerProjection','naturallyDerivedGenericDefaultCap']:require(actual[key]==derived[key],'Actual fresh TI authored metadata differs: '+key)
 for key in ['newCoreBuildPerformed','newNativePlacementCheckPerformed','referenceQualified','TIplaneArrangement','coreRenderCalled','nativePlacementChecksInvoked','routingSolverInstantiated','accepted49','fabricationReady']:require(actual[key] is False,'No new physics/routing/reference pass may be claimed: '+key)
 old_actual=load(Path(load(PARENT/'SOURCE-INPUT-manifest.json')['sourceDirectory'])/'run/actual-final-props.json')
 old_proof=copy.deepcopy(actual['authoredPolicyProof'])
 for group in old_proof['groups']:
  if group['busId']=='DDR_COMMAND_CLOCK':group.update(minLength=21.15,maxLength=23.69)
 require(old_proof==old_actual['authoredPolicyProof'],'Only two CA proof fields may change')
 for key in ['placementProposal','referenceCopperCandidates','globalSignalLayerProjection','naturallyDerivedGenericDefaultCap']:require(actual[key]==old_actual[key],'Original physical C metadata held: '+key)
 for name in ['input.json','original-unrestricted-input.json']:
  expected=load(PARENT/name);ca=next(b for b in expected['buses'] if b['busId']=='DDR_COMMAND_CLOCK');require(ca['minLength']==21.15 and ca['maxLength']==23.69,'Original carried CA window required');ca.update(minLength=20.95,maxLength=23.49)
  require(load(ROOT/name)==expected and (ROOT/name).read_bytes()==(source/name).read_bytes(),'Native sidecar may change only two CA fields: '+name)
 require(sha(ROOT/'input.json')==m['inputSha256'] and sha(ROOT/'original-unrestricted-input.json')==m['unrestrictedInputSha256'],'Exact fresh TI native sidecars required')
 current=load(ROOT/'input.json')
 for bus in current['buses']:
  group=next(g for g in actual['authoredPolicyProof']['groups'] if g['busId']==bus['busId'])
  require(group['pcbAllowedLayers']==bus['allowedLayers'] and group['preferredLayers']==bus['preferredLayers'] and group['pcbTraceWidth']==bus['traceWidth'],'Layer/width metadata must match actual authored source')
  for key in ['minLength','maxLength','maxLengthSkew']:require(group.get(key)==bus.get(key),'Length metadata must match actual authored source: '+key)
 require(current['allowedLayers']==LAYERS and current['layerCount']==4 and len(current['connections'])==49 and len(current['obstacles'])==856 and len(current['traces'])==2 and actual['globalSignalLayerProjection']==LAYERS and actual['naturallyDerivedGenericDefaultCap']==800000,'Original four physical layers/49/856/2/default800k required')
 closed=load(m['previousRuntime128ClosedPostauditPath']);ce=closed['execution']
 require(sha(m['previousRuntime128ClosedPostauditPath'])==m['previousRuntime128ClosedPostauditSha256'] and ce['exitCode']==-15 and ce['diagnosticStopped'] is True and ce['stopReasons']==['WALL_STOP'] and ce['cleanupOwnedGroupEmpty'] is True and not any(ce['oomDelta'].values()) and closed['sourceAndArtifactHeld'] is True and closed['result'] is None and closed['accepted49'] is False and closed['fabricationReady'] is False,'Previous runtime128 wall stop/no-output must remain preserved')
 return {**inherited,'scope':'ACTUAL_FINAL_C_FRESH_TI_CA_METADATA_OVER_UNCHANGED_MEASURED_E_GEOMETRY','inputSha256':m['inputSha256'],'unrestrictedInputSha256':m['unrestrictedInputSha256'],'actualCaptureSha256':m['actualCaptureSha256'],'actualFinalReactTreeEvaluated':True,'sourceInputParityQualified':True,'freshTiEndpointAuditQualified':True,'freshMaximumCommandManhattanMm':14.6,'caclmMm':22.22,'commandTotalPlanarRangeMm':[20.95,23.49],'changedCAFieldsOnly':2,'metadataDerivedFromActualAuthoredProps':True,'originalRuntime128WallStopPreserved':True,'nativePlacementChecksInheritedNotRerun':True,'newCoreBuildPerformed':False,'newNativePlacementCheckPerformed':False,'nativeCoreOrRouterApiInvoked':False,'referenceQualified':False,'TIplaneArrangement':False,'accepted49':False,'fabricationReady':False}
def verify_producer_inputs(producer_directory,expected_manifest_sha256):
 result=verify(expected_manifest_sha256);p=Path(producer_directory);require(sha(p/'input.json')==result['inputSha256'] and sha(p/'original-unrestricted-input.json')==result['unrestrictedInputSha256'],'Producer must use exact fresh TI C sidecars');return result
def verify_actual_authored_props(path):
 m=load(ROOT/'SOURCE-INPUT-manifest.json');canonical=Path(m['sourceDirectory'])/'run/actual-final-props.json';require(sha(path)==sha(canonical) and load(path)==load(canonical),'Exact fresh TI actual final React props required')
 return {'actualFinalReactTreeEvaluated':True,'captureSha256':sha(path),'signalLayersAllowed':LAYERS,'cohortCarrierConstraints':CARRIERS,'naturallyDerivedGenericDefaultCap':800000,'freshTiEndpointAuditQualified':True,'commandTotalPlanarRangeMm':[20.95,23.49],'referenceQualified':False,'TIplaneArrangement':False,'newCoreBuildPerformed':False,'newNativePlacementCheckPerformed':False,'nativePlacementChecksInheritedNotRerun':True,'accepted49':False,'fabricationReady':False}
