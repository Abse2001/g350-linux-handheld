"""Pure V12d BYTE0/RESET swap within singleton-cohort layer bridge. Existing geometry and actual V12c
final props are reused. No Core/native/router/CAD call or reference qualification.
"""
from pathlib import Path
import hashlib, json, stat, copy, importlib.util, sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PARENT=Path('/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12c-distinct-cohort-carriers-next')
PARENT_MANIFEST='92117e50bb14ae71ece5894f27979227be5cb1baf193b59b8db4fb082e8894f2'
PARENT_MODULE='45b6a4434e5aed4813318c21875b4bff0fca4f9d6fa29609d0560a1b3ce58a40'
CAPTURE=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress/v12c-actual-react-next/actual-final-props.json')
CAPTURE_SHA='2df7cffda85a052b9d3c0333d0e6bc9201d2af9ff827aee4b48208c893ff837c'
RECEIPT=CAPTURE.parent/'RECEIPT.json'
RECEIPT_SHA='e10e0c3abc23b6589ff2ad69a9647c97cf9269e6d6dd7a539d2d59a649a40276'
INPUT_SHA='ff3de67bc83c036b7780561690806227b3981c9eee88920497c6a7e9889f56aa'
BROAD_SHA='06a81bc88e38c7967545a77317c9f3b480b64865a2323fd1a305a2e481f3cb31'
LAYERS=['top','inner1','inner2','bottom']
CARRIERS={'DDR_RESET':'bottom','DDR_BYTE0':'top','DDR_BYTE1':'inner2','DDR_COMMAND_CLOCK':'inner1'}
def require(v,s):
    if not v: raise ValueError(s)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
def verify_rows(base,rows):
    for row in rows:
        p=Path(row['path']) if base is None else base/row['path']
        require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'],'Binding changed: '+str(p))
def verify(expected_manifest_sha256):
    require(sha(ROOT/'SOURCE-INPUT-manifest.json')==expected_manifest_sha256,'Exact frozen V12d source/input manifest required')
    m=load(ROOT/'SOURCE-INPUT-manifest.json');verify_rows(ROOT,m['files']);verify_rows(None,m['externalFiles'])
    require(sha(PARENT/'v12c_input_provenance.py')==PARENT_MODULE,'Frozen independent parent binder changed')
    spec=importlib.util.spec_from_file_location('g350_frozen_v12c_source_bridge',PARENT/'v12c_input_provenance.py');parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent)
    inherited=parent.verify(PARENT_MANIFEST)
    require(sha(CAPTURE)==CAPTURE_SHA and sha(RECEIPT)==RECEIPT_SHA,'Actual V12c final props/root receipt changed')
    actual_parent=parent.verify_actual_authored_props(CAPTURE);receipt=load(RECEIPT);execution=receipt['execution']
    require(receipt['passed'] is True and receipt['sourceHeld'] is True and receipt['sourceManifestSha256']==PARENT_MANIFEST and receipt['proof']==actual_parent and execution['exitCode']==0 and execution['diagnosticStopped'] is False and execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values()),'Actual clean source-held V12c React evaluation required')
    require(sha(ROOT/'input.json')==INPUT_SHA and sha(ROOT/'original-unrestricted-input.json')==BROAD_SHA and sha(PARENT/'input.json')=='8ec0070e5b11712cd75a00d1c3cb5b332b3da9587429385d0bb468e9c2715010','Exact new singleton input and frozen all4 broad counterpart required')
    broad=load(ROOT/'original-unrestricted-input.json');expected=copy.deepcopy(load(PARENT/'input.json'))
    for b in expected['buses']:b['allowedLayers']=[CARRIERS[b['busId']]];b['preferredLayers']=[CARRIERS[b['busId']]]
    actual=load(ROOT/'input.json');require(actual==expected,'Only perbus allowed/preferred layer lists may change')
    require(actual['allowedLayers']==LAYERS and actual['layerCount']==4 and len(actual['connections'])==49 and len(actual['obstacles'])==856 and len(actual['traces'])==2,'Original fourlayer49/856/2 physical inventory/global allowance required')
    policy=load(ROOT/'v12d-layer-policy.json');require(actual['buses']==[g['nativeBus'] for g in policy['groups']] and policy['globalSignalLayers']==LAYERS,'Source policy must exactly match native singleton cohorts/global4')
    require(policy['referenceQualified'] is False and policy['TIplaneArrangement'] is False and policy['naturalGenericDefaultCap']==800000,'Reference compatibility/defaultcap must not be promoted')
    before=load(CAPTURE);expected_props=copy.deepcopy(before['authoredPolicyProof'])
    for g in expected_props['groups']:g['pcbAllowedLayers']=[CARRIERS[g['busId']]];g['preferredLayers']=[CARRIERS[g['busId']]]
    derived=load(ROOT/'derived-final-authored-props.json');require(derived['authoredPolicyProof']==expected_props and derived['actualV12cFinalPropsCaptureSha256']==CAPTURE_SHA and derived['referenceCopperCandidates']==before['referenceCopperCandidates'],'Only final cohort layer props change from actual V12c tree; reference candidates remain exact')
    require(derived['physicalGeometrySourceSha256']==inherited['freshCircuitSha256'] and derived['globalSignalLayerProjection']==LAYERS and derived['naturallyDerivedGenericDefaultCap']==800000,'Existing physical2312 geometry/global4/default800k held')
    for field in ['referenceQualified','TIplaneArrangement','actualV12ReactEvaluationPerformed','newCoreBuildPerformed','newNativePlacementCheckPerformed','accepted49','fabricationReady']:require(derived[field] is False,'Pure derivation/readiness flag must remain false: '+field)
    return {'scope':'PURE_V12D_BYTE0_TOP_RESET_BOTTOM_SOURCE_BRIDGE_REFERENCE_PENDING','inputSha256':INPUT_SHA,'unrestrictedInputSha256':BROAD_SHA,'freshCircuitSha256':inherited['freshCircuitSha256'],'physicalInputExactlyHeld':True,'onlyLayerListsChanged':True,'nativePlacementChecks':17,'nativePlacementErrors':0,'nativePlacementChecksInheritedNotRerun':True,'routingRequests':49,'obstacles':856,'fixedReferences':2,'signalLayersAllowed':LAYERS,'cohortCarrierConstraints':CARRIERS,'naturallyDerivedGenericDefaultCap':800000,'explicitSearchCapSupplied':False,'referenceQualified':False,'TIplaneArrangement':False,'referenceRedesignStillRequired':True,'actualFinalReactEvaluationRequiredBeforeMain':True,'captureScript':str(ROOT/'capture-v12d-authored-props.ts'),'newCoreBuildPerformed':False,'nativeCoreOrRouterApiInvoked':False,'accepted49':False,'fabricationReady':False}
def verify_producer_inputs(producer_directory,expected_manifest_sha256):
    result=verify(expected_manifest_sha256);p=Path(producer_directory)
    require(sha(p/'input.json')==INPUT_SHA and sha(p/'original-unrestricted-input.json')==BROAD_SHA,'Producer inputs must match exact singleton cohort/broad source bridge')
    return result
def verify_actual_authored_props(path):
    d=load(ROOT/'derived-final-authored-props.json')
    expected={'scope':'PURE_ACTUAL_V12D_FINAL_REACT_PROPS_REFERENCE_UNQUALIFIED','actualFinalReactTreeEvaluated':True,'derivedProofSha256':sha(ROOT/'derived-final-authored-props.json'),'authoredPolicyProof':d['authoredPolicyProof'],'referenceCopperCandidates':d['referenceCopperCandidates'],'globalSignalLayerProjection':LAYERS,'naturallyDerivedGenericDefaultCap':800000,'referenceQualified':False,'TIplaneArrangement':False,'coreRenderCalled':False,'nativePlacementChecksInvoked':False,'routingSolverInstantiated':False,'accepted49':False,'fabricationReady':False}
    require(load(path)==expected,'Actual final V12d props differ from exact singleton cohort/reference-pending source bridge')
    return {'actualFinalReactTreeEvaluated':True,'captureSha256':sha(path),'derivedProofSha256':expected['derivedProofSha256'],'signalLayersAllowed':LAYERS,'cohortCarrierConstraints':CARRIERS,'naturallyDerivedGenericDefaultCap':800000,'referenceQualified':False,'TIplaneArrangement':False,'newCoreBuildPerformed':False,'newNativePlacementCheckPerformed':False,'accepted49':False,'fabricationReady':False}
