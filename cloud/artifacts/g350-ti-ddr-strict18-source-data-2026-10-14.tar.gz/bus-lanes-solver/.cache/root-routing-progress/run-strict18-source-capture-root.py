import hashlib, importlib.util, json, os, secrets, stat, sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/bus-lanes-solver/.cache/root-routing-progress')
BOARD=Path('/workspace/g350-linux-handheld')
PACKET=BOARD/'.cloud-tools/ddr-strict18-manual-source-integration-sourceonly-next'
OUT=PACKET/'run-capture'
POLICY={'wallSeconds':60,'rssBytes':1073741824,'sharedBytes':32212254720,'sampleSeconds':.05,'termGraceSeconds':5}
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
guard=load('strict18_parent_guard_library',BOARD/'.cloud-tools/ddr-clock-v11-fresh-core-native-sourceonly-next/guard.py')
def bindings():
 m=read(PACKET/'SOURCE-manifest.json')
 assert m['status']=='AUTHOR_DONE_UNEXECUTED_REQUIRES_PEER_AND_ROOT_SERIAL_CAPTURE_TYPES_CORE_NATIVE_CAD'
 assert len(m['files'])==7 and len(m['original144LexicalSourceImportClosure'])==144 and len(m['lexicalLocalSourceImportClosure'])==147
 for row in m['files']+m['original144LexicalSourceImportClosure']+m['lexicalLocalSourceImportClosure']+m['externalActualInputBindings']:
  guard.source_guard.binding(row)
 assert sha(m['originalManualSourceManifestPath'])==m['originalManualSourceManifestSha256']
 for name in ('node_modules','.pnp.cjs','.pnp.loader.mjs','.yarn'):
  p=PACKET/name;assert not p.exists() and not p.is_symlink()
 return m,sha(PACKET/'SOURCE-manifest.json')
def main():
 assert len(sys.argv)==3
 peerpath=Path(sys.argv[1]);assert sha(peerpath)==sys.argv[2]
 peer=read(peerpath);m,packet=bindings()
 assert packet=='be1969ab1a99af7e823213c44166505eaf765048e6809fcd5f2fbd6aea5bd15e'
 assert peer['sourceManifestSha256']==packet and peer['decision']=='GO_SOURCE_ONLY_TO_ROOT_OWNED_CAPTURE'
 _,native_sha,board_before,solver_before,_=guard.checked()
 a=read(ROOT/'clock-v11-fresh-native-root.json')
 rows=[a['requiredActual42982Collection'],*a['additionalPreviousRootCollections'],*a['successfulPriorStages'].values(),a['successfulCoreCollection']]
 for f in ('clock-v11-fresh-native-42626-COLLECTED-root.json','clock-v11-fresh-cli-87907-COLLECTED-root.json','clock-v11-baseline-cad-94957-COLLECTED-root.json','d7-default-committed-suite-25380-COLLECTED-root.json'):
  p=ROOT/f;rows.append({'path':str(p),'sha256':sha(p)})
 def closed():
  for row in rows:assert guard.process_scope.owned(guard.collected(row)[2]['pgid'])==[]
 closed();assert not OUT.exists();OUT.mkdir()
 bun=BOARD/'.cloud-tools/bun/node_modules/bun/bin/bun.exe'
 parent=read(m['originalManualSourceManifestPath'])
 bunrow=next(r for r in parent['runtimeAndOriginFiles'] if r['path']==str(bun));guard.source_guard.binding(bunrow)
 auth={'authorizedByRoot':True,'sourceManifestSha256':packet,'peerReviewPath':str(peerpath),'peerReviewSha256':sha(peerpath),'rootFullCaptureAndOverlayReadPassed':True,'noConcurrentRootWorker':True,'actualPriorCollectedRows':rows,'policy':POLICY,'approvalToken':secrets.token_hex(32),'coreCalls':0,'accepted49':False,'fabricationReady':False}
 ap=OUT/'ROOT_AUTHORITY.json'
 with ap.open('x')as f:json.dump(auth,f,indent=2);f.write('\n')
 ah=sha(ap)
 def prefork(mem):
  closed();assert mem['current']+POLICY['rssBytes']+1073741824<POLICY['sharedBytes']
 capture=OUT/'source-capture.json';diagnostic=OUT/'source-tree-diagnostic.json'
 argv=[str(bun),'--smol',str(PACKET/'capture-strict18-source.ts'),str(capture),str(diagnostic)]
 execution=guard.process_scope.run_guarded(argv,str(BOARD),OUT/'owned',POLICY,{'G350_STRICT18_SOURCE_ROOT_GUARDED':'1'},before_spawn=prefork)
 _,after_native,board_after,solver_after,_=guard.checked();_,after_packet=bindings();closed()
 held=native_sha==after_native and packet==after_packet and board_before==board_after and solver_before==solver_after and sha(peerpath)==sys.argv[2] and sha(ap)==ah
 result=read(capture)if capture.is_file()else None
 passed=held and execution['exitCode']==0 and not execution['diagnosticStopped'] and execution['cleanupOwnedGroupEmpty'] and not any(execution['oomDelta'].values()) and result is not None and result['passed'] and result['fullInverseSourceTreePassed'] and result['routingInputLayerForkInversePassed'] and result['genuineNewInnerLayerPorts']==24 and result['newOriginalThreePathDeclarations']==16 and result['duplicateLocalPcbRenderSuppressions']==32 and result['explicitAuthorizedBusAllowedLayerChanges']==4 and result['coreRendered'] is False and sha(diagnostic)==result['actualDiagnosticSha256']
 outputs=[{'path':str(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':sha(p)}for p in sorted(OUT.iterdir())if p.is_file()]
 post={'scope':'ACTUAL_STRICT18_MANUAL_SOURCE_CAPTURE','sourceManifestSha256':packet,'execution':execution,'sourceAndDependenciesHeld':held,'dependenciesBefore':board_before,'dependenciesAfter':board_after,'solverDependenciesBefore':solver_before,'solverDependenciesAfter':solver_after,'capturePath':str(capture),'captureSha256':sha(capture)if capture.is_file()else None,'diagnosticPath':str(diagnostic),'diagnosticSha256':sha(diagnostic)if diagnostic.is_file()else None,'outputFiles':outputs,'passed':bool(passed),'sourceCaptureCalls':1,'coreCalls':0,'nativeCalls':0,'cadCalls':0,'complete18Accepted':False,'accepted49':False,'fabricationReady':False}
 with (OUT/'POSTAUDIT.json').open('x')as f:json.dump(post,f,indent=2);f.write('\n')
 print(json.dumps({k:post[k]for k in ('passed','sourceAndDependenciesHeld','captureSha256','diagnosticSha256','execution')}))
 return 0 if passed else 2
if __name__=='__main__':raise SystemExit(main())
