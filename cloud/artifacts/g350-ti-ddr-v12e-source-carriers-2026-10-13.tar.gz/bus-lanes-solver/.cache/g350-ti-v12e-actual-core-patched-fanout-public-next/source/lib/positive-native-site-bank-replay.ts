/** Exact, call-local replay of completed positive native site work. Geometry is
 * copied on both insertion and retrieval; raster/search objects are never kept. */
export class PositiveNativeSiteBankReplay<T> {
  private context: string | undefined
  private bytes = 0
  private readonly entries = new Map<
    string,
    { key: string; value: T; bytes: number }
  >()
  private readonly maxEntries: number
  private readonly maxBytes: number

  constructor(options: { maxEntries?: number; maxBytes?: number } = {}) {
    this.maxEntries = options.maxEntries ?? 64
    this.maxBytes = options.maxBytes ?? 8 * 1024 * 1024
    if (
      !Number.isInteger(this.maxEntries) ||
      this.maxEntries < 0 ||
      !Number.isInteger(this.maxBytes) ||
      this.maxBytes < 0
    )
      throw Error(
        "Positive native-bank replay bounds must be nonnegative integers",
      )
  }

  begin(context: unknown) {
    const key = exactKey(context)
    if (key !== this.context) this.clear()
    // The bound covers serialized retained context, keys and geometry. An
    // oversized/unsupported context simply leaves the normal search in place.
    if (key === undefined || byteLength(key) > this.maxBytes) {
      this.clear()
      return
    }
    this.context = key
  }

  get(connectionName: string, context: unknown): T | undefined {
    if (this.context === undefined) return undefined
    const key = exactKey(context)
    const entry = this.entries.get(connectionName)
    if (key === undefined || entry?.key !== key) return undefined
    try {
      return structuredClone(entry.value)
    } catch {
      this.bytes -= entry.bytes
      this.entries.delete(connectionName)
      return undefined
    }
  }

  put(connectionName: string, context: unknown, value: T): boolean {
    if (this.context === undefined) return false
    const key = exactKey(context)
    const encoded = exactKey(value)
    if (key === undefined || encoded === undefined) return false
    const bytes =
      byteLength(connectionName) + byteLength(key) + byteLength(encoded)
    const contextBytes = byteLength(this.context)
    if (this.maxEntries < 1 || contextBytes + bytes > this.maxBytes)
      return false
    let copy: T
    try {
      copy = structuredClone(value)
    } catch {
      return false
    }
    const previous = this.entries.get(connectionName)
    if (previous) {
      this.bytes -= previous.bytes
      this.entries.delete(connectionName)
    }
    while (
      this.entries.size >= this.maxEntries ||
      contextBytes + this.bytes + bytes > this.maxBytes
    ) {
      const oldest = this.entries.keys().next().value
      if (oldest === undefined) break
      this.bytes -= this.entries.get(oldest)!.bytes
      this.entries.delete(oldest)
    }
    this.entries.set(connectionName, {
      key,
      value: copy,
      bytes,
    })
    this.bytes += bytes
    return true
  }

  clear() {
    this.entries.clear()
    this.bytes = 0
    this.context = undefined
  }
}

const byteLength = (text: string) => new TextEncoder().encode(text).byteLength

/** Tagged values preserve undefined, null, nonfinite numbers and negative zero.
 * Only data records are supported; a cyclic/class/function context recomputes. */
function exactKey(value: unknown): string | undefined {
  const active = new Set<object>()
  const visit = (entry: unknown): unknown => {
    if (entry === undefined) return ["undefined"]
    if (entry === null) return ["null"]
    if (typeof entry === "number")
      return [
        "number",
        Number.isNaN(entry)
          ? "NaN"
          : entry === Infinity
            ? "+Infinity"
            : entry === -Infinity
              ? "-Infinity"
              : Object.is(entry, -0)
                ? "-0"
                : entry,
      ]
    if (typeof entry === "string" || typeof entry === "boolean")
      return [typeof entry, entry]
    if (typeof entry !== "object" || active.has(entry)) throw Error()
    const prototype = Object.getPrototypeOf(entry)
    if (
      Object.getOwnPropertySymbols(entry).length ||
      (Array.isArray(entry) && prototype !== Array.prototype) ||
      (!Array.isArray(entry) &&
        prototype !== Object.prototype &&
        prototype !== null)
    )
      throw Error()
    const descriptors = Object.getOwnPropertyDescriptors(entry)
    for (const [key, descriptor] of Object.entries(descriptors)) {
      if (Array.isArray(entry) && key === "length") continue
      if (
        !Object.hasOwn(descriptor, "value") ||
        !descriptor.enumerable ||
        (Array.isArray(entry) &&
          (!/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= entry.length))
      )
        throw Error()
    }
    active.add(entry)
    try {
      return Array.isArray(entry)
        ? [
            "array",
            Array.from({ length: entry.length }, (_, index) =>
              Object.hasOwn(entry, index) ? visit(entry[index]) : ["hole"],
            ),
          ]
        : [
            "object",
            Object.keys(entry)
              .sort()
              .map((key) => [
                key,
                visit((entry as Record<string, unknown>)[key]),
              ]),
          ]
    } finally {
      active.delete(entry)
    }
  }
  try {
    return JSON.stringify(visit(value))
  } catch {
    return undefined
  }
}
