"""Pure source materialization after a frozen, naturally solved public output.

No solver, Core, exporter, native checker or CAD process is imported or run.
The generated replay transports the original signal objects without remapping.
This is a source template, not physical or electrical acceptance.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import shutil
import stat
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BOARD = ROOT.parent.parent
NATIVE_SHA = 'dc67beee6b0e901f914835cd0fe27fad0060066e3213001574a98eefb8c44fa8'
BOARD_SHA = '0e2ce064e896db1d087474716d2e82b86155dbe28eecf28ce1727e73a466fee1'
LAYERS = ['top', 'inner1', 'inner2', 'bottom']
HARDWARE_TYPES = ['source_component', 'source_port', 'source_trace', 'source_net',
    'source_bus', 'source_board', 'source_manually_placed_via', 'pcb_component',
    'pcb_board', 'pcb_smtpad', 'pcb_port', 'pcb_hole', 'pcb_plated_hole',
    'pcb_keepout', 'pcb_copper_pour']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(), parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def write_json(path, value):
    with Path(path).open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write('\n')


def verify_prepared():
    prepared = read_json(ROOT / 'PREPARED-manifest.json')
    for row in prepared['files']:
        path = ROOT / row['path']
        require(path.is_file() and not path.is_symlink(), 'Prepared source missing or symlinked: ' + row['path'])
        require(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'] and
                stat.S_IMODE(path.stat().st_mode) == row['mode'], 'Prepared source changed: ' + row['path'])
    require(sha(ROOT / 'inputs/original-board.circuit.json') == BOARD_SHA, 'Original board bytes changed')
    require(sha(ROOT / 'inputs/native-input.json') == NATIVE_SHA, 'Original native input changed')
    for row in prepared['externalFiles']:
        path = Path(row['path'])
        require(path.is_file() and not path.is_symlink() and path.stat().st_size == row['bytes'] and
                sha(path) == row['sha256'] and stat.S_IMODE(path.stat().st_mode) == row['mode'],
                'Frozen external source/policy changed: ' + row['path'])
    require(read_json(ROOT / 'inputs/native-input.json')['allowedLayers'] == LAYERS,
            'Exactly the authorized four physical signal layers required')
    bridge=Path('/workspace/g350-linux-handheld/.cloud-tools/ti-ddr-v12e-qualified-input-bridge-next')
    spec=importlib.util.spec_from_file_location('g350_materialize_actual_v12e_bridge',bridge/'v12e_input_provenance.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    proof=module.verify('982198893435f9ea4150f80bbaeee91b25bad733eff97e223da187b3cd0dd815')
    require(proof['actualCoreInputQualified'] is True and proof['sourceInputParityQualified'] is True and proof['exactAll49SourceConnectionsQualified'] is True and proof['proposedThreeRigidXMotionsExactlyHeld'] is True and proof['nativePlacementChecks']==17 and proof['nativePlacementErrors']==0 and proof['freshCircuitSha256']==BOARD_SHA and proof['inputSha256']==NATIVE_SHA,'Exact actual V12e source/input/native17 bridge required')
    return prepared


def validate_natural(run_dir, output_sha, result_sha, postaudit_sha):
    run_dir = run_dir.resolve()
    require(run_dir.name == 'run', 'Use the original public controller run directory')
    output_path = run_dir / 'natural-public-output.json'
    result_path = run_dir / 'result.json'
    audit_path = run_dir.parent / 'EXECUTION-postaudit.json'
    require(output_path.is_file() and result_path.is_file() and audit_path.is_file(),
            'Materialization requires complete original natural49 output, result and postflight; missing artifacts are refused')
    require(sha(output_path) == output_sha and sha(result_path) == result_sha and
            sha(audit_path) == postaudit_sha, 'Explicit frozen result hashes differ')
    require(output_path.stat().st_size <= 16 * 1024 * 1024, 'Natural output exceeds original 16 MiB bound')
    result, audit = read_json(result_path), read_json(audit_path)
    require(audit.get('diagnosticTrustEligible') is True and audit.get('sourceAndArtifactHeld') is True,
            'Original public postflight is not trust eligible')
    require(audit.get('result') == result and audit.get('dependenciesBefore') == audit.get('dependenciesAfter'),
            'Original result/dependencies differ from postflight')
    execution = audit.get('execution', {})
    require(execution.get('exitCode') == 0 and execution.get('diagnosticStopped') is False and
            execution.get('cleanupOwnedGroupEmpty') is True and not any(execution.get('oomDelta', {}).values()) and
            not any(audit.get('postflightOomDelta', {}).values()), 'Original controlled process did not finish cleanly')
    require(audit.get('trustConjuncts') == {
            'identityHeld': True, 'physicalInputAndCapHeld': True, 'originalTerminalHeld': True,
            'naturalOutputGateHeld': True, 'boundedOriginalMethodObservationsHeld': True,
            'boundedBankObservationsHeld': True, 'boundedStagePrimitiveObservationsHeld': True,
            'boundedStepBoundTelemetryHeld': True, 'boundedGlobalSelectionObserved': True,
            'boundedOwnDataPublicFailureFieldsHeld': True},
            'Original postflight conjunct failed')
    require(result.get('diagnosticQualified') is True and result.get('originalException') is None and
            result.get('terminal', {}).get('termination') == 'NATURAL_SOLVED', 'Natural completion required')
    require(result.get('terminal', {}).get('defaultCap') == 800_000 and
            result.get('actualSolverState', {}).get('solved') is True and
            result.get('actualSolverState', {}).get('failed') is False and
            result.get('actualSolverState', {}).get('actualTraceCount') == 49, 'Exact original solved state required')
    require(result.get('inputSha256') == NATIVE_SHA and result.get('inputUnchanged') is True and
            result.get('fullHardwareHeld') is True and result.get('fixedReferencesHeld') is True and
            result.get('naturalOutputGateHeld') is True and result.get('capUnchanged') is True and
            result.get('requestedOptionsHeld') is True, 'Original physical/provenance gates failed')
    require(result.get('accepted49') is False and result.get('fabricationReady') is False,
            'Public completion must remain separate from acceptance')
    item = result.get('publicOutput', {})
    require(item == {'path': 'natural-public-output.json', 'bytes': output_path.stat().st_size, 'sha256': output_sha},
            'Original output binding differs')
    require(sha(run_dir.parent / 'input.json') == NATIVE_SHA, 'Original controller input bytes differ')
    packet_path = run_dir.parent / 'FINAL-manifest.json'
    require(sha(packet_path) == result.get('packetSha256'), 'Original final packet/result binding differs')
    packet = read_json(packet_path)
    require(packet.get('nodeArtifactQualified') is True and
            packet.get('sourceManifestSha256') == result.get('sourceManifestSha256') and
            packet.get('sourceClosureSha256') == result.get('sourceClosureSha256') and
            packet.get('nodeArtifactSha256') == result.get('nodeArtifactSha256'), 'Original runtime/artifact bindings differ')
    require(run_dir.parent == Path('/workspace/bus-lanes-solver/.cache/g350-ti-v12e-actual-core-patched-fanout-public-next') and
            sha(packet_path) == '7a8aa663c5b00cb372cc0b754d6aaa5375997132fbe03a40b6c0b5755d948c2a',
            'Exact original V12e actual-Core/private-fanout qualified public producer required')
    require(result.get('observationMode') == 'PRIMITIVE_GRID_REPLAY_STATS_AND_PUBLIC_STEP_ONLY' and
            result.get('originalDefaultCap') == 800_000 and result.get('signalLayersAllowed') == LAYERS and
            result.get('referenceQualified') is False and result.get('TIplaneArrangement') is False,
            'Natural generic four-signal-layer policy/reference-pending result required')
    require(packet.get('naturallyDerivedGenericDefaultCap') == 800_000 and packet.get('explicitBudgetSupplied') is False and
            packet.get('referenceQualified') is False and packet.get('TIplaneArrangement') is False,
            'Do not substitute surface budget or reference-plane acceptance')
    require(packet.get('actualCoreInputQualified') is True and packet.get('actualCoreNativePlacementChecks')==17 and packet.get('actualCoreNativePlacementErrorCount')==0 and packet.get('actualInputAndSourceParityQualified') is True and packet.get('exactAll49SourceConnectionsQualified') is True and packet.get('actualPrivateFanoutBundleQualified') is True and packet.get('v12eBridgeManifestSha256')=='982198893435f9ea4150f80bbaeee91b25bad733eff97e223da187b3cd0dd815','V12e actual Core/native/49 parity/private matcher producer gates required')
    native, output = read_json(ROOT / 'inputs/native-input.json'), read_json(output_path)
    require({k: v for k, v in output.items() if k != 'traces'} ==
            {k: v for k, v in native.items() if k != 'traces'}, 'Output changed native input fields')
    require(isinstance(output.get('traces'), list) and len(output['traces']) == 51 and
            output['traces'][:2] == native['traces'], 'Exactly 49 signals plus two original references required')
    return native, output, result, audit, [output_path, result_path, audit_path, packet_path]


def validate_paths(native, output):
    board = read_json(ROOT / 'inputs/original-board.circuit.json')
    identities = read_json(ROOT / 'inputs/identity-contract.json')
    names = identities['ddrIds']
    connections = {c['name']: c for c in native['connections']}
    require(len(connections) == 49 and list(connections) == names, 'Original 49 connection order differs')
    signals = output['traces'][2:]
    actual_names = [t.get('connection_name', t.get('source_trace_id')) for t in signals]
    require(len(set(actual_names)) == 49 and set(actual_names) == set(names), 'Signal ownership is not exact 49')
    ids = [t.get('pcb_trace_id') for t in output['traces']]
    require(all(isinstance(i, str) and i for i in ids) and len(set(ids)) == 51, 'Output PCB trace IDs collide')
    ports = {p['pcb_port_id']: p for p in board if p['type'] == 'pcb_port'}
    source_ports = {p['source_port_id']: p for p in board if p['type'] == 'source_port'}
    components = {c['source_component_id']: c for c in board if c['type'] == 'source_component'}
    source_traces = {t['source_trace_id']: t for t in board if t['type'] == 'source_trace'}
    pads = {p['pcb_port_id']: p for p in board if p['type'] == 'pcb_smtpad'}
    details = []
    for trace in signals:
        name = trace.get('connection_name', trace.get('source_trace_id'))
        require(trace.get('type') == 'pcb_trace' and trace.get('source_trace_id') == name and
                trace.get('connection_name', name) == name, 'No source-ID remapping is allowed')
        connection = connections[name]
        route = trace.get('route')
        require(isinstance(route, list) and len(route) >= 2, 'Missing signal route')
        require(all(isinstance(p, dict) and finite(p.get('x')) and finite(p.get('y')) for p in route),
                'Nonfinite route coordinate')
        for point in route:
            if point.get('route_type') == 'wire':
                require(point.get('layer') in LAYERS and point.get('width') == connection['width'],
                        'Signal layer/width differs from original native connection')
            else:
                require(point.get('route_type') == 'via' and
                        point.get('from_layer') in LAYERS and point.get('to_layer') in LAYERS and
                        point.get('from_layer') != point.get('to_layer') and
                        point.get('layers') == LAYERS and
                        point.get('via_diameter') == native['minViaPadDiameter'] and
                        point.get('via_hole_diameter') == native['minViaHoleDiameter'],
                        'Signal via must retain original standard full-depth four-layer dimensions')
        if 'curvedSegments' in trace:
            curve = trace['curvedSegments']
            require(isinstance(curve, list) and len(set(curve)) == len(curve) and
                    all(type(i) is int and 1 <= i < len(route) for i in curve), 'Malformed curve ending annotations')
        endpoints = connection['pointsToConnect']
        require(len(endpoints) == 2 and route[0]['route_type'] == route[-1]['route_type'] == 'wire',
                'Complete native endpoint wires required')
        owners = []
        for point in endpoints:
            port = ports[point['pcb_port_id']]
            source = source_ports[port['source_port_id']]
            component = components[source['source_component_id']]
            pad = pads[port['pcb_port_id']]
            selector = component['name'] + '.' + source['name']
            require(source['source_port_id'] in source_traces[name]['connected_source_port_ids'] and
                    point['port_selector'] == selector and type(source.get('pin_number')) is int and
                    pad['x'] == point['x'] and pad['y'] == point['y'] and pad['layer'] == point['layer'] and
                    port['x'] == point['x'] and port['y'] == point['y'], 'Original numeric CPU/RAM contact differs')
            require(any(end['layer'] == point['layer'] and
                        math.hypot(end['x'] - point['x'], end['y'] - point['y']) <= 1e-9
                        for end in (route[0], route[-1])), 'Output route fails original native contact')
            owners.append({'selector': selector, 'pinNumber': source['pin_number'],
                           'sourcePortId': source['source_port_id'], 'pcbPortId': port['pcb_port_id']})
        require({x['selector'].split('.')[0] for x in owners} == {'U_SOC', 'U_RAM'}, 'Wrong signal owner')
        details.append({'sourceTraceId': name, 'logicalName': source_traces[name]['name'],
                        'originalContacts': owners, 'routeFingerprint': fingerprint(trace),
                        'curveAnnotationFingerprint': fingerprint(trace.get('curvedSegments')),
                        'routeVertexCount': len(route),
                        'viaCount': sum(p['route_type'] == 'via' for p in route)})
    return signals, details


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--natural-run', type=Path, required=True)
    parser.add_argument('--natural-output-sha256', required=True)
    parser.add_argument('--result-sha256', required=True)
    parser.add_argument('--postaudit-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--root-collected', type=Path, required=True)
    parser.add_argument('--root-collected-sha256', required=True)
    args = parser.parse_args()
    prepared = verify_prepared()
    native, output, result, audit, original_paths = validate_natural(
        args.natural_run, args.natural_output_sha256, args.result_sha256, args.postaudit_sha256)
    collection_path = args.root_collected.resolve()
    require(collection_path.parent == Path('/workspace/bus-lanes-solver/.cache/root-routing-progress') and
            sha(collection_path) == args.root_collected_sha256, 'Explicit outside root collection hash required')
    collected = read_json(collection_path)
    require(collected.get('sessionId') == 36822 and collected.get('collectedExitCode') == 0 and
            collected.get('execution') == audit['execution'] and collected.get('postauditSha256') == args.postaudit_sha256 and
            collected.get('rootStoppedForUserLayerSteering') is False and collected.get('naturalFailure') is False and
            collected.get('accepted49') is False and collected.get('fabricationReady') is False,
            'Root must collect this exact clean natural completion before materialization')
    signals, paths = validate_paths(native, output)
    require(collected.get('producerFinalSha256')=='7a8aa663c5b00cb372cc0b754d6aaa5375997132fbe03a40b6c0b5755d948c2a' and collected.get('inputSha256')==NATIVE_SHA,'Root collection must bind exact V12e producer/input')
    destination = args.output.resolve()
    require(destination.parent == ROOT and not destination.exists(), 'New direct child output directory required')
    destination.mkdir(mode=0o700)
    for directory in ('source', 'inputs', 'checks'):
        (destination / directory).mkdir(mode=0o700)
    for row in prepared['sourceMembers']:
        old = ROOT / row['path']
        new = destination / row['path']
        new.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(old, new)
    for path in original_paths:
        shutil.copy2(path, destination / 'inputs' / path.name)
    shutil.copy2(ROOT / 'inputs/original-board.circuit.json', destination / 'inputs/original-board.circuit.json')
    shutil.copy2(ROOT / 'inputs/native-input.json', destination / 'inputs/native-input.json')
    shutil.copy2(ROOT / 'inputs/identity-contract.json', destination / 'source/full49-replay/identity-contract.json')
    write_json(destination / 'source/full49-replay/natural-signals.json', signals)
    raw_signal_sha = sha(destination / 'source/full49-replay/natural-signals.json')
    require(read_json(destination / 'source/full49-replay/natural-signals.json') == output['traces'][2:],
            'Signal delivery objects changed')
    write_json(destination / 'source/full49-replay/replay-bindings.json', {
        'nativeInputSha256': NATIVE_SHA, 'naturalOutputSha256': args.natural_output_sha256,
        'originalBoardSha256': BOARD_SHA, 'signalArraySha256': raw_signal_sha,
        'signalsObjectFingerprint': fingerprint(signals), 'curveAnnotationCount':
            sum(len(t.get('curvedSegments', [])) for t in signals),
        'resultSha256': args.result_sha256, 'postauditSha256': args.postaudit_sha256,
        'physicalAcceptance': False, 'timingReady': False, 'fabricationReady': False,
        'referenceQualified': False, 'TIplaneArrangement': False, 'rootCollectedSha256': args.root_collected_sha256})
    (destination / 'source/node_modules').symlink_to(BOARD / 'node_modules', target_is_directory=True)
    write_json(destination / 'MATERIALIZED-source-only.json', {
        'scope': 'ORIGINAL_NATURAL49_SIGNAL_ARRAY_SOURCE_REPLAY_PREPARATION_ONLY',
        'preparedManifestSha256': sha(ROOT / 'PREPARED-manifest.json'),
        'naturalOutputSha256': args.natural_output_sha256,
        'originalBoardSha256': BOARD_SHA, 'nativeInputSha256': NATIVE_SHA,
        'originalSourceMembersHeldByExternalClosure': prepared['originalSourceMemberCount'],
        'copiedReplaySupportFiles': len(prepared['sourceMembers']),
        'originalInventory': prepared['inventory'], 'paths': paths,
        'all49OriginalNumericCpuRamContactsHeld': True, 'signalIdsRemapped': False,
        'signalObjectsOrCurveAnnotationsChanged': False,
        'originalTwoReferenceIdentitiesDeliveredAtQualifiedV12eCoordinates': True,
        'routerCalled': False, 'coreCalled': False, 'exporterCalled': False,
        'nativePhysicalValid': False, 'accepted49': False, 'timingReady': False,
        'candidateForConnectivityAndTimingChecksOnly': True, 'referenceQualified': False,
        'TIplaneArrangement': False, 'rootCollectedSha256': args.root_collected_sha256,
        'fabricationReady': False,
        'limitations': 'Source-only V12e materialization. Rest-board168 signals are deliberately unrouted;217 source identity is not217 connectivity. New wrapper dispatch/type/serializer controls, actual Core replay, native checks, strict source/pour verification and fresh CAD export still required.'})
    print(json.dumps({'materialized': str(destination), 'sourceOnly': True,
                      'signalCount': 49, 'accepted49': False, 'fabricationReady': False}))


if __name__ == '__main__':
    main()
