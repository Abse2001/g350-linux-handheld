from pathlib import Path
import argparse, hashlib, importlib.util, json, os, re, stat, sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent / 'g350-canonical-c115-original-native-grid-isolated-diagnostic-next'
SOURCE = PARENT / 'source'
ORIGINAL = ROOT.parent / 'g350-coupled-handoff-length-prune-canonical-fullsuite-normal-2g-successor-next'
BASE = ROOT.parent / 'g350-count-conditioned-site-recovery-next'
POLICY = {'wallSeconds': 60, 'rssBytes': 2*1024**3, 'sharedBytes': 26*1024**3,
          'sampleSeconds': .05, 'termGraceSeconds': 5}
RESERVE = 2*1024**3

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''): h.update(block)
    return h.hexdigest()

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec); spec.loader.exec_module(loaded)
    return loaded

def verify():
    raw = (ROOT / 'PREPARED.json').read_bytes(); packet = json.loads(raw)
    for row in packet['files'] + packet['externalFiles']:
        path = Path(row['path'])
        assert path.is_file() and not path.is_symlink() and sha(path) == row['sha256']
        assert path.stat().st_size == row['bytes'] and stat.S_IMODE(path.stat().st_mode) == row['mode']
    actual_files = {str(q.relative_to(SOURCE)) for q in (SOURCE).rglob('*') if q.is_file() and not q.is_symlink()}
    assert actual_files == set(packet['sourceFiles'])
    links = {str(q.relative_to(SOURCE)): os.readlink(q) for q in (SOURCE).rglob('*') if q.is_symlink()}
    assert links == {'node_modules': '/workspace/bus-lanes-solver/node_modules'}
    original = module('canonical_handoff_held_fullsuite_guard', ORIGINAL / 'guard.py')
    old_packet, old_digest, canonical_guard, scope = original.verify()
    assert old_digest == packet['originalPacketSha256'] == '2b6ab700b74ed3493f1e94a4a9bed53ce281417e60e9842cfa13034a96e28e16'
    
    assert old_packet['policy'] == {**POLICY, 'wallSeconds': 300, 'sharedBytes': 24*1024**3}
    assert packet['policy'] == POLICY
    assert old_packet['preforkReserveBytes'] == packet['preforkReserveBytes'] == RESERVE
    assert old_packet['discoveredTestFileCount'] == 186
    assert packet['discoveredTestFileCount'] == 1
    assert packet['command'] == [old_packet['command'][0], 'test', 'tests/grid-native-length-bounds.test.ts']
    previous = json.loads((ORIGINAL / 'EXECUTION-postaudit.json').read_bytes())
    execution = previous['execution']
    assert previous['fullSuitePassed'] is False and previous['sourceAndArtifactsHeld'] is True
    assert previous['dependenciesBefore'] == previous['dependenciesAfter']
    assert previous['actualCounters'] == {'pass': None, 'fail': None, 'tests': None, 'files': None}
    assert execution['pgid'] == 307631 and execution['exitCode'] == -15
    assert execution['diagnosticStopped'] is True and execution['stopReasons'] == ['OWNED_RSS_STOP']
    assert execution['cleanupOwnedGroupEmpty'] is True and not any(execution['oomDelta'].values())
    collection = json.loads(Path(packet['originalRootCollectionPath']).read_bytes())
    assert collection['sessionId'] == 11082 and collection['toolExitCode'] == 2
    scope = module('canonical_handoff_original_owned_scope', BASE / 'process_scope.py')
    assert not scope.owned(307631)
    parent_guard = module('canonical_original_grid_frozen_metadata_guard', PARENT / 'guard.py')
    _, parent_digest, _, _ = parent_guard.verify()
    assert parent_digest == packet['frozenParentPacketSha256'] == '80e940db64bf6d453222be3b8956baf3a422c4aeb05ca2eb5839ab1fe02b7d4d'
    prior = json.loads((PARENT / 'EXECUTION-postaudit.json').read_bytes())
    assert prior['naturalClosedDiagnostic'] is True and prior['isolatedOriginalGridTestsPassed'] is False
    assert prior['actualCounters'] == {'pass': 5, 'fail': 1, 'tests': 6, 'files': 1}
    assert prior['execution']['cleanupOwnedGroupEmpty'] is True and not any(prior['execution']['oomDelta'].values())
    assert prior['dependenciesBefore'] == prior['dependenciesAfter']
    baseline_collection = json.loads(Path(packet['baselineRootCollectionPath']).read_bytes())
    assert baseline_collection['sessionId'] == 49187 and baseline_collection['toolExitCode'] == 0
    assert baseline_collection['originalGuardPacketHeld'] is False
    assert baseline_collection['guardMetadataChangedDuringWorker'] is True
    assert baseline_collection['sourceBoundDiagnosticQualified'] is False
    assert not scope.owned(prior['execution']['pgid'])
    failed_prefork = json.loads(Path(packet['preforkFailurePath']).read_bytes())
    assert 'pid' not in failed_prefork and 'pgid' not in failed_prefork
    assert failed_prefork['guardError'] == 'AssertionError'
    assert failed_prefork['policy'] == {**POLICY, 'sharedBytes': 24*1024**3}
    assert failed_prefork['memoryBefore']['current'] + POLICY['rssBytes'] + RESERVE >= 24*1024**3
    return packet, hashlib.sha256(raw).hexdigest(), canonical_guard, scope

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--root-receipt'); parser.add_argument('--root-receipt-sha256')
    args = parser.parse_args(); packet, digest, original, scope = verify()
    if args.preflight_only:
        print(json.dumps({'preflightPassed': True, 'packetSha256': digest, 'sourceOnly': True})); return 0
    assert args.run and args.root_receipt and args.root_receipt_sha256
    authority = json.loads(Path(args.root_receipt).read_bytes())
    assert sha(args.root_receipt) == args.root_receipt_sha256
    assert authority['authorizedByRoot'] is True and authority['scope'] == packet['scope']
    assert authority['packetSha256'] == digest and authority['policy'] == POLICY
    assert re.fullmatch('[0-9a-f]{32,128}', authority['approvalToken'])
    assert not (ROOT / 'run').exists()
    before = original.dependencies(); baseline = scope.memory()
    def gate(now):
        assert now['current'] + POLICY['rssBytes'] + RESERVE < POLICY['sharedBytes'], 'Strict prefork reserve required'
        assert all(now['events'][k] == baseline['events'][k] for k in scope.OOM_KEYS)
    actual = scope.run_guarded(packet['command'], Path(packet['sourceDirectory']), ROOT / 'run',
        POLICY, {'GIT_OPTIONAL_LOCKS': '0'}, before_spawn=gate)
    verify(); after = original.dependencies(); assert before == after
    log_path = ROOT / 'run/child.log'
    log = log_path.read_text(errors='replace') if log_path.is_file() else ''
    summaries = re.findall(r'^Ran (\d+) tests across (\d+) files?\.', log, re.M)
    passes = re.findall(r'^\s*(\d+) pass\s*$', log, re.M)
    failures = re.findall(r'^\s*(\d+) fail\s*$', log, re.M)
    counts = {'pass': int(passes[-1]) if passes else None,
              'fail': int(failures[-1]) if failures else None,
              'tests': int(summaries[-1][0]) if summaries else None,
              'files': int(summaries[-1][1]) if summaries else None}
    passed = (actual['exitCode'] == 0 and not actual['diagnosticStopped']
        and actual['cleanupOwnedGroupEmpty'] and not any(actual['oomDelta'].values())
        and counts['tests'] is not None and counts['tests'] > 0
        and counts['pass'] == counts['tests'] and counts['fail'] == 0
        and counts['files'] == packet['discoveredTestFileCount'] and counts['tests'] == 6)
    valid = (actual['exitCode'] in (0, 1) and not actual['diagnosticStopped']
        and actual['cleanupOwnedGroupEmpty'] and not any(actual['oomDelta'].values())
        and counts['tests'] == 6 and counts['files'] == 1
        and counts['pass'] is not None and counts['fail'] is not None
        and counts['pass'] + counts['fail'] == 6)
    receipt = {'execution': actual, 'dependenciesBefore': before, 'dependenciesAfter': after,
        'sourceAndArtifactsHeld': True, 'packetSha256': digest, 'isolatedOriginalGridTestsPassed': passed, 'naturalClosedDiagnostic': valid,
        'actualCounters': counts, 'childLogSha256': sha(log_path),
        'originalRssStoppedOutcomePreserved': True, 'originalSmolTimeoutFailurePreserved': True, 'byteExactOriginalCanonicalGridTestAndRuntime': True,
        'typecheckRepeated': False, 'wholeSuiteExecuted': False, 'accepted49': False,
        'allElevenBenchmarksExecuted': False}
    (ROOT / 'EXECUTION-postaudit.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'isolatedOriginalGridTestsPassed': passed, 'naturalClosedDiagnostic': valid, 'actualCounters': counts}))
    return 0 if valid else 2

if __name__ == '__main__': raise SystemExit(main())
