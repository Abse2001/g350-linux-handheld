"""Own stdlib finite geometry hypothesis; no SDK or actual source changes."""
exec(open('/tmp/g350-actual260-ca233-compatibility-sourceonly.py').read().split('if __name__')[0])
import time
P299='/tmp/g350-source24-TI3W-foreign34W-matched49-finite1g-root-20261016-run299/byte0-result.candidate.json'
S299='8abef05761375014f8a310f9cfcab92d7a5b7da978598fe4a49b1c118658d34d'
P37='/tmp/g350-actual299-source37-matched21p2-three-width-full49-own-audit-report.json'
S37='3a1e219b8608cb68e2e4cd121cc267936f53e1f9ae6c723755651338f38dbfa4'
def pinned(path,pin):
 b=Path(path).read_bytes();assert hashlib.sha256(b).hexdigest()==pin;return json.loads(b)
packet=pinned(P299,S299);j37=pinned(P37,S37);foundation=packet['full49FanoutInput'];by={owner(t):t for t in packet['carrierTraces']};assert by['source_trace_37']==j37['bodyInverse']['before'];by['source_trace_37']=j37['bodyInverse']['after']
assert foundation==f
oldids={t['pcb_trace_id']for t in p['carrierTraces']}
objects=[o for o in BASE if o['id'] not in oldids and o['id'] not in {'pcb_via_79','pcb_trace_173'}]
for n,t in by.items():
 if n!='source_trace_0':objects.extend(bodyobjects(t))
# Only a declared, not yet adopted, same-ground reference retarget is modeled.
ref=next(t for t in foundation['traces']if t['pcb_trace_id']=='pcb_trace_173')
newref=copy.deepcopy(ref);newref['route']=[{'route_type':'wire','layer':'top','width':.2,'x':-1.2,'y':10.2},{'route_type':'wire','layer':'top','width':.2,'x':-1.5999999999999994,'y':10.600000000000001}]
objects.extend(bodyobjects(newref));scene=Scene(objects)
name='source_trace_0';wire=lambda points,layer:{'pcb_trace_id':'ANALYSIS0_GROUND79_TRANSFER','connection_name':name,'route':[{'route_type':'wire','layer':layer,'width':.1016,'x':x,'y':y}for x,y in points]}
prefix=wire([(-1.6,12.8),(-1.6,11.2)],'inner2');via={'route_type':'via','x':-1.6,'y':11.2,'from_layer':'inner2','to_layer':'inner1','layers':list(L),'via_diameter':.4572,'via_hole_diameter':.254}
portal={'pcb_trace_id':'ANALYSIS0_GROUND79_TRANSFER','connection_name':name,'route':[prefix['route'][-1],via,{'route_type':'wire','layer':'inner1','width':.1016,'x':-1.6,'y':11.2}]}
prefix_contacts=scene.contacts(prefix);portal_contacts=scene.contacts(portal)
step=.05;roi=(-80,60,140,280);root=(-32,224);queue=collections.deque([root]);seen={root};boundary=collections.Counter();beg=time.monotonic();parents={}
while queue:
 a=queue.popleft()
 for dx,dy in [(1,0),(1,1),(0,1),(-1,1),(-1,0),(-1,-1),(0,-1),(1,-1)]:
  b=(a[0]+dx,a[1]+dy)
  if b in seen or not(roi[0]<=b[0]<=roi[1]and roi[2]<=b[1]<=roi[3]):continue
  cs=scene.contacts(wire([(a[0]*step,a[1]*step),(b[0]*step,b[1]*step)],'inner1'))
  if cs:boundary.update((c['otherOwner'],c['otherId'])for c in cs);continue
  seen.add(b);parents[b]=a;queue.append(b)
rows=[]
for y in sorted({y for x,y in seen}):
 if y%2:continue
 xs=sorted(x for x,yy in seen if yy==y);runs=[]
 for x in xs:
  if runs and x==runs[-1][-1]+1:runs[-1].append(x)
  else:runs.append([x])
 rows.append({'y':y*step,'intervals':[[min(z)*step,max(z)*step]for z in runs]})
report={'scope':'PURE_FINITE_I1_REGION_ROOTED_AT_DECLARED_SIGNAL0_TRANSFER_IN_VACATED_AUTHENTIC_GROUND79_SITE_NOT_ACCEPTED','inputBindings':{'actual299':{'path':P299,'sha256':S299},'matched37':{'path':P37,'sha256':S37}},'hypotheticalRemovedMaterial':['pcb_via_79','pcb_trace_173',by['source_trace_0']['pcb_trace_id']],'authenticSameGroundRetarget':{'sourceTrace':'source_trace_1003','fromPcbPort':'pcb_port_1319','toPcbPort':'pcb_port_1271','numericRamPortHeld':'pcb_port_335','newTrace':newref},'prefixInner2Contacts':prefix_contacts,'newSignal0FullspanContacts':portal_contacts,'gridStepMm':step,'roiMm':[-4,3,7,14],'reachablePointCount':len(seen),'boundsMm':[min(x for x,y in seen)*step,max(x for x,y in seen)*step,min(y for x,y in seen)*step,max(y for x,y in seen)*step],'sampleAreaMm2':len(seen)*step*step,'rows':rows,'boundaryObjects':[{'owner':n,'id':i,'blockedEdgeCount':c}for (n,i),c in boundary.most_common()],'gridPoints':sorted(seen),'elapsedSeconds':time.monotonic()-beg,'allOriginalRulesHeld':True,'sourceCoreDerived':False,'nativeExecuted':False,'all49Accepted':False,'timingPassed':False,'fabricationReady':False}
out=Path('/tmp/g350-actual299-plus-matched37-ground79-retire-I1-transfer-component-report.json');out.open('x').write(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'prefixContacts':len(prefix_contacts),'portalContacts':len(portal_contacts),'points':len(seen),'bounds':report['boundsMm'],'area':report['sampleAreaMm2'],'boundary':report['boundaryObjects'][:8],'elapsedSeconds':report['elapsedSeconds']}))
