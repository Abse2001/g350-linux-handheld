#!/usr/bin/env python3
"""Append closed241..243 and the exact Source23615-pour aggregate, stdlib only.

No SDK or application imports. Mutations are confined to the NEW post232 saved
directory; the initial collection and all older saved workspaces stay verifiable.
Source23347 stays the Source-verified fallback. Source24348 is a separate model
milestone with fresh critical companion and Source/Core/native checks pending.
"""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat

ROOT = Path('/workspace/g350-linux-handheld')
SAVED = ROOT / '.cloud-tools/ddr-four-layer-post232-2026-10-16'
OLD = ROOT / '.cloud-tools/ddr-four-layer-post209-2026-10-16'
INITIAL = {
    'README.md': '9e9059ab256987b2688646b8afbb332300b8d7d4d51b4dff4434402495926cd4',
    'PROGRESS.json': 'bae9cda2aaea6c01a526dba82a7dbc3bb1322166cfaa9e702957d7840738d402',
    'WORKSPACE_RESTORE_MANIFEST.json': '0ca6f626e5339abdeb288ab0e66b22bc319a663f5c918752b3b0f5ce951610fe',
    'WORKSPACE_HASH_INDEX.json': '6ebc6bb84fc61f0b49a1df6c7ef061e5a3886111371508eefd0d1d36875d9fc2',
}
OLD_PINS = {
    'WORKSPACE_HASH_INDEX.json': '809a4437af0306c37aa759044131fbaa9939032244284705c31a3910d339a83d',
    'WORKSPACE_RESTORE_MANIFEST.json': 'd8a8ebdc11a3900affe120fdd70c946403c4e26bf9b7b02bd9a1088a98369cef',
    'PROGRESS.json': 'fac4424b0ca0fe1b74fc640687a0567b7b3264267a65da5acfff5eb9091b5ef0',
}
PINS = {
    '/tmp/g350-joint48-cap12-root-20261016-run241/COLLECTED.json': '59ba97141dd644ec6d931126b77248cf33319c1e7b02c6219771ad57d9b0f220',
    '/tmp/g350-joint48-cap12-root-20261016-run242/COLLECTED.json': '843fa8bea45addca184ef35db9a9a0db0fc3292a7be7d782cdab0958bce9a5d3',
    '/tmp/g350-joint48-cap12-root-20261016-run242/byte0-result.json': '3abe22b3daea2bc8a385939f23980fbffc6a9fb457b943aede8bc03a8dc16e4e',
    '/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.json': '3745a26adbe3b1123cdcff161a39cd4a589c2baba0f55b74515a1925afaad237',
    '/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json': 'cf4808ac8cfd61832979cfd95bec76e22605bfc43d3d0138bbbf5086cfe59720',
    '/tmp/g350-source236-all15-literal-pour-margin-root-aggregate-20261016.json': 'de4e08e71a5de9503b1050b4e920086e9c2c1ed0211a57d2fed826a1decc6f1f',
    '/tmp/g350-source236-literal-pour-coverage-combiner-sourceonly.py': '380af3ff31fc7169e9912185f021a5994eb5066cad587c3887aef14496252501',
    '/tmp/g350-joint48-cap12-root-20261016-run239/COLLECTED.json': '652bb40c56261fda2718ba9d277804002e3983b5a6a19812ee60eae3a0af0f65',
    '/tmp/g350-joint48-cap12-root-20261016-run240/COLLECTED.json': 'c9b4b6223a3f837eae351f2493a656b2e021a273022610e12f430f949ecf03b7',
    '/tmp/g350-joint48-cap12-root-20261016-run240/byte0-result.json': '579a0c8b3dbe6b3a174d1913a83750406f326d01204107ba2bc0258f7d1bc151',
    '/tmp/g350-actual223-deterministic48-joint1-30-cap12point79-twoRAM14-32-v2-topology-sourceonly.ts': '65850dd86fc9f4a7f6b499ff616c1d94b4849b3640561b4d86682a6974224f50',
    '/tmp/g350-actual223-deterministic48-joint1-30-cap12point79-twoRAM14-32-v3-topology-sourceonly.ts': '485a4c5b924070365450c1b9f2987c6f23784b0ef43110b299d59365e76600c0',
    '/tmp/g350-actual223-deterministic48-joint1-30-cap12point79-twoRAM14-32-v3a-topology-sourceonly.ts': '2a18fac18cfb3751ff388e6b7a484ec0042e87796b91ee9c56b9e275ada867a6',
    '/tmp/g350-source236-all15-literal-pour-margin-root-20261016.json': '0e2f67dc304884dd334001464303e6e2155665f119df9c8909d2b38f691745ab',
    '/tmp/g350-source236-selected94-literal-pour-margin-root-20261016.json': '0f6d3eb46af29e0eeccea14ce138e75a3db98ad17220653b60f392008f470aa9',
    '/tmp/g350-partial47-plan234-source236-literal-selected-pour-clearance-audit-sourceonly.py': '68d33314f2a984e1c260d4f2bca7b04eb9b7370135a5ff1befd354b1604878d5',
}
RAW_SHA = 'd49c3d6f8661527cf007d3676d6cdae7f9fcec99535373997c6adda8705dc18d'
CTRL_SHA = 'b618de34ab2c681f53f9422cd06916471db95fda97772e16754a814541546563'
AUTH_SHA = '05ef57bc48db7d5cb2bcc012fa584143d037fdecbf1f6fb55d89be57da0f9997'
PLAN_SHA = '0e3757ae6e367158090a2f14dbaf20f9f57422576d89ee2ca1acfa6c77ef1707'
POURS = ['pcb_copper_pour_' + str(i) for i in (0,22,23,30,37,38,39,48,71,74,80,81,83,87,94)]


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
        if hasattr(os, 'posix_fadvise'):
            os.posix_fadvise(stream.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return h.hexdigest()


def read(p):
    with p.open('rb') as stream:
        return json.load(stream)


def regular(p):
    return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)


def safe(p):
    denied = ('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'CONTEXT_BODY', 'BOUND_CONTEXT', 'AUTHORITY_PACKET')
    return (p.is_absolute() and str(p).startswith('/tmp/g350-') and p.resolve().is_relative_to('/tmp')
            and not any(part in str(p).upper() for part in denied))


def metadata(p):
    s = p.stat()
    return {'bytes': s.st_size, 'sha256': digest(p), 'mode': stat.S_IMODE(s.st_mode)}


def verify_rows(folder, rows):
    for row in rows:
        p = folder / row['path']
        require(regular(p) and metadata(p) == {k: row[k] for k in ('bytes', 'sha256', 'mode')}, 'Saved bytes/mode changed: ' + str(p))


def verify_old():
    for name, pin in OLD_PINS.items():
        require(digest(OLD / name) == pin, 'Frozen post209 metadata changed')
    verify_rows(OLD, read(OLD / 'WORKSPACE_HASH_INDEX.json')['files'])


def atomic_json(name, value):
    p = SAVED / name
    temp = SAVED / ('.append243-' + name + '.tmp')
    with temp.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        os.fchmod(stream.fileno(), 0o600)
    os.replace(temp, p)


def main():
    require(SAVED.is_dir() and not SAVED.is_symlink(), 'Existing new post232 directory required')
    for name, pin in INITIAL.items():
        require(digest(SAVED / name) == pin, 'Expected immutable through240 metadata')
    before_index = read(SAVED / 'WORKSPACE_HASH_INDEX.json')
    verify_rows(SAVED, before_index['files'])
    verify_old()
    for name, pin in PINS.items():
        require(safe(Path(name)) and regular(Path(name)) and digest(Path(name)) == pin, 'Exact closed public input required: ' + name)
    manifest = read(SAVED / 'WORKSPACE_RESTORE_MANIFEST.json')
    progress = read(SAVED / 'PROGRESS.json')
    require(progress['latestClosedScopeIncluded'] == 240 and progress['primaryCandidate']['routedOwners'] == 47
            and progress['primaryCandidate']['candidateSha256'] == '71bbec7babdeabda657ba1b2be75d35f5d7210d5a53d55cd2fc2b279ffb0d17b', 'Exact current23347 snapshot required')
    primary = copy.deepcopy(progress['primaryCandidate'])
    require(primary['literalPourAuditPending'] is True and primary['literalPourClearanceQualified'] is False
            and primary['prior228PourPassInherited'] is False, 'No existing combined pour qualification')
    # Preserve all four exact initial metadata files as history before replacing
    # the appendable metadata. No original payload is overwritten.
    for name in INITIAL:
        dest = SAVED / ('HISTORY_THROUGH240_' + name)
        require(not dest.exists(), 'Append history must be fresh')
        with (SAVED / name).open('rb') as reader, dest.open('xb') as writer:
            shutil.copyfileobj(reader, writer, 1024 * 1024)
            os.fchmod(writer.fileno(), stat.S_IMODE((SAVED / name).stat().st_mode))
        require(digest(dest) == INITIAL[name], 'Exact initial metadata history')
    targets = {r['restorePath']: copy.deepcopy(r) for r in manifest['files']}
    bases = {r['restorePath']: copy.deepcopy(r) for r in manifest['baseDependencyRestoreFiles']}
    base_catalog = {}
    for folder in (ROOT / '.cloud-tools/ddr-four-layer-manual-2026-10-16', OLD):
        for r in read(folder / 'WORKSPACE_RESTORE_MANIFEST.json')['files']:
            base_catalog[r['restorePath']] = {'baseSavedDirectory': folder.relative_to(ROOT).as_posix(), **r}
    inputs = {}

    def save(p, name=None, force=False):
        p = Path(p)
        require(safe(p) and regular(p), 'Only public regular sources: ' + str(p))
        s = p.stat()
        rowdata = metadata(p)
        inputs[str(p)] = rowdata
        if str(p) in targets:
            require(rowdata == {k: targets[str(p)][k] for k in rowdata}, 'Existing restore target changed')
            return targets[str(p)]
        old = base_catalog.get(str(p))
        if not force and old and rowdata == {k: old[k] for k in rowdata}:
            bases[str(p)] = copy.deepcopy(old)
            return old
        dest = SAVED / (name or p.name)
        require(dest.parent == SAVED, 'Flat safe saved filename')
        if dest.exists() and metadata(dest) != rowdata:
            dest = dest.with_name(dest.stem + '__' + rowdata['sha256'][:16] + dest.suffix)
        if not dest.exists():
            with p.open('rb') as reader, dest.open('xb') as writer:
                shutil.copyfileobj(reader, writer, 1024 * 1024)
                os.fchmod(writer.fileno(), rowdata['mode'])
        require(metadata(dest) == rowdata, 'Saved source bytes/mode')
        after = p.stat()
        require((s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns) ==
                (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'Public source changed during copy')
        r = {'savedPath': dest.name, 'restorePath': str(p), **rowdata}
        targets[str(p)] = r
        return r

    additions = []
    sources = set()
    for scope in (241, 242, 243):
        folder = Path('/tmp/g350-joint48-cap12-root-20261016-run' + str(scope))
        c = read(folder / 'COLLECTED.json')
        e = read(folder / 'owned/execution.json')
        require(c['scope'] == scope and c.get('closedAt') and c['sourcePinsUnchanged'] is True
                and c['protectedFilesUnchanged'] is True and c['all49Accepted'] is False, 'Exact closed nonaccepting scope')
        if scope == 241:
            require(c['execution'] is None and e['exitCode'] is None and e['diagnosticStopped'] is True
                    and e.get('guardError') == 'AssertionError' and 'pid' not in e, '241 stopped at memory admission; no runtime')
            outcome = 'MEMORY_ADMISSION_REFUSED_NO_CHILD_RUNTIME'
        elif scope == 242:
            r = read(folder / 'byte0-result.json')
            require(c['execution']['exitCode'] == 2 and r['terminalOutcome'] == 'EXCEPTION_NO_ACCEPTANCE'
                    and r['attempts'] == [] and r['retained'] == []
                    and 'Changed carrier before/after/native/max control failed source_trace_1' in r['error']
                    and len(r['atomicFanoutPhysicalReports']) == 2
                    and all(v['passed'] is True for v in r['atomicFanoutPhysicalReports'])
                    and r['changedBodyBeforeAfter'][0]['owner'] == 'source_trace_1'
                    and r['changedBodyBeforeAfter'][0]['afterQualification']['passed'] is False,
                    '242 passed schema/fanouts but failed Source1 changed-body physical gate')
            outcome = 'SCHEMA_AND_TWO_FANOUTS_PASSED_SOURCE1_NONCONVENTIONAL_CORNER_REJECTED'
        else:
            r = read(folder / 'byte0-result.json')
            candidate = read(folder / 'byte0-result.candidate.json')
            require(c['execution']['exitCode'] == 0 and len(candidate['carrierTraces']) == 48
                    and len(candidate['heldCarrierTraces']) == 6
                    and candidate['allSavedCarriersCurrentSceneQualified'] is True
                    and len(candidate['joinedNumericPadTraces']) == 48
                    and len(candidate['finalScenePhysicalReports']) == 48
                    and all(v['passed'] is True for v in candidate['finalScenePhysicalReports'])
                    and len(candidate['powerReferencePhysicalReports']) == 2
                    and all(v['passed'] is True for v in candidate['powerReferencePhysicalReports'])
                    and len(candidate['atomicFanoutPhysicalReports']) == 2
                    and all(v['passed'] is True for v in candidate['atomicFanoutPhysicalReports'])
                    and candidate['all49Accepted'] is False
                    and candidate['criticalCompanionQualificationInherited'] is False,
                    '24348 actual model physical milestone, not full-board acceptance')
            delta = candidate['cap12PlacementInverse']
            require(delta == candidate['requiredSourceHardwarePlacementDelta']
                    and delta['name'] == 'C_DDR_RAM_12'
                    and delta['before']['center'] == {'x': 6, 'y': 4.7}
                    and delta['after']['center'] == {'x': 6.79, 'y': 4.7}
                    and delta['other279ComponentPlacementsLiteral'] is True
                    and delta['sourcePlacementAppliedByThisWorker'] is False
                    and len(delta['typedSmtPadInverses']) == len(delta['typedPcbPortInverses']) == 2
                    and len(delta['padObstacleInverses']) == len(delta['powerReferenceInverses']) == 2,
                    '243 exact named cap12 and two typed pad/port/reference inverse ledger')
            outcome = 'MODEL48_PHYSICAL_NUMERIC_NATIVE15_PASSED_CRITICAL_COMPANION_AND_SOURCE_PENDING'
        label = 'CAP12_TOPOLOGY' + str(scope) + ('_MODEL48' if scope == 243 else '_NO_NEW_QUALIFIED_CANDIDATE')
        save(folder / 'COLLECTED.json', label + '_COLLECTED.json', True)
        for p in sorted(folder.glob('byte0-result*.json')):
            save(p, label + '_' + p.name, True)
        for filename in ('child.log', 'execution.json', 'memory.jsonl'):
            p = folder / 'owned' / filename
            if regular(p):
                save(p, label + '_owned_' + filename, True)
        worker = Path(e['command'][1])
        save(worker, force=True)
        sources.add(worker)
        for arg in e['command'][2:]:
            p = Path(arg)
            if str(arg).startswith('/tmp/g350-') and regular(p):
                save(p, 'INPUT_' + label + '_' + p.parent.name + '_' + p.name)
                for sibling in ('proof.json', 'contacts.json'):
                    q = p.parent / sibling
                    if regular(q):
                        save(q, 'INPUT_' + label + '_' + q.parent.name + '_' + q.name)
        additions.append({'scope': scope, 'closedAt': c['closedAt'], 'terminalOutcome': outcome,
                          'exitCode': e['exitCode'], 'childRuntimeExecuted': scope != 241,
                          'geometryRoutingExecuted': scope == 243, 'inheritedDiagnosticArraysAreFreshEvidence': False,
                          'newConnectedOwnerCount': 48 if scope == 243 else None,
                          'sourceCoreNativeCadFreshForThisModel': False,
                          'all49Accepted': False, 'fabricationReady': False})
    for name in PINS:
        row = save(Path(name), force=True)
        if Path(name).suffix in ('.py', '.ts', '.tsx'):
            sources.add(Path(name))
    save(Path(__file__), force=True)
    visited = set()
    for _ in range(3):
        next_sources = set()
        for p in sorted(sources - visited):
            visited.add(p)
            for value in re.findall(r"['\"](/tmp/g350-[^'\"\n]+)['\"]", p.read_text()):
                q = Path(value)
                if safe(q) and regular(q):
                    save(q)
                    if q.suffix in ('.py', '.ts', '.tsx', '.mjs'):
                        next_sources.add(q)
        sources |= next_sources
    first = read(Path('/tmp/g350-source236-all15-literal-pour-margin-root-20261016.json'))
    retry = read(Path('/tmp/g350-source236-selected94-literal-pour-margin-root-20261016.json'))
    for d in (first, retry):
        require(d['auditSourceSha256'] == PINS['/tmp/g350-partial47-plan234-source236-literal-selected-pour-clearance-audit-sourceonly.py']
                and d['inputBindings']['raw']['sha256'] == RAW_SHA
                and d['inputBindings']['controls']['sha256'] == CTRL_SHA
                and d['inputBindings']['current227Ownership']['sha256'] == AUTH_SHA
                and d['inputBindings']['reviewedSourcePlan234']['sha256'] == PLAN_SHA
                and d['actualRawPourIds'] == POURS and d['wireScope'] == 'all-routed'
                and len(d['wireOriginalOwners']) == 47 and d['actualViaCount'] == 227
                and d['inputFilesUnchanged'] is True and not d['violations']
                and not d['globalIdentityFailures'] and not d['viaIdentityFailures'], 'Exact Source236 same-scene bounded pour reports')
    require(first['completed'] is False and len(first['pourReports']) == 15
            and [r['pcbCopperPourId'] for r in first['pourReports'] if r['state'] == 'COMPLETED'] == POURS[:-1]
            and first['pourReports'][-1]['state'] == 'BOUNDED_PARTIAL', 'First report14 completed/last94 bounded')
    require(retry['completed'] is True and retry['selectedPourIds'] == [POURS[-1]]
            and retry['literalForeignPourMarginClear'] is True and len(retry['pourReports']) == 1
            and retry['pourReports'][0]['state'] == 'COMPLETED', 'Selected94 retry completed independently')
    evidence = {'scope': 'TWO_SAME_SCENE_BOUNDED_REPORTS_COVERAGE_COMBINER_PENDING',
                'auditSource': copy.deepcopy(targets['/tmp/g350-partial47-plan234-source236-literal-selected-pour-clearance-audit-sourceonly.py']),
                'firstReport': copy.deepcopy(targets['/tmp/g350-source236-all15-literal-pour-margin-root-20261016.json']),
                'selected94Retry': copy.deepcopy(targets['/tmp/g350-source236-selected94-literal-pour-margin-root-20261016.json']),
                'firstCompletedPourIds': POURS[:-1], 'retryCompletedPourIds': POURS[-1:],
                'wholeCoverageCombinerPassed': False, 'literalPourClearanceQualified': False,
                'prior228PourPassInherited': False, 'all49Accepted': False, 'fabricationReady': False}
    aggregate = read(Path('/tmp/g350-source236-all15-literal-pour-margin-root-aggregate-20261016.json'))
    require(aggregate['scope'] == 'SOURCE236_ALL15_LITERAL_POURS_COMPLETED_COVERAGE_AGGREGATE_NOT_BOARD_QUALIFICATION'
            and aggregate['completed'] is True and aggregate['literalForeignPourMarginClear'] is True
            and aggregate['completedPourIds'] == POURS and aggregate['completedPourCount'] == 15
            and aggregate['actualRawPourCount'] == 15 and aggregate['actualViaCount'] == 227
            and aggregate['wireSegmentCount'] == 7456 and aggregate['wireOwnerCount'] == 47
            and aggregate['mergedCandidateSha256'] == primary['candidateSha256']
            and aggregate['allCompletedComparisonRostersReconstructedFromExactRaw'] is True
            and aggregate['sameExactRawControlsAuthAcrossBothContributions'] is True
            and aggregate['inputFilesUnchanged'] is True and aggregate['violations'] == []
            and aggregate['identityFailures'] == [] and aggregate['unsupportedGeometry'] == []
            and all(aggregate[k] is False for k in ('all49Accepted', 'fullBoardPassed', 'electricalTimingQualified',
                    'referenceQualified', 'ownNetReentryQualified', 'referenceWireGeometryIncluded',
                    'nativeExecuted', 'cadExecuted', 'fabricationReady')),
            'Exact scoped Source236 aggregate pass; all other qualification boundaries false')
    require(aggregate['inputBindings']['input']['sha256'] == RAW_SHA
            and aggregate['inputBindings']['controls']['sha256'] == CTRL_SHA
            and aggregate['inputBindings']['auth']['sha256'] == AUTH_SHA
            and aggregate['inputBindings']['reviewedSourcePlan234']['sha256'] == PLAN_SHA
            and aggregate['inputBindings']['partial']['sha256'] == PINS['/tmp/g350-source236-all15-literal-pour-margin-root-20261016.json']
            and aggregate['inputBindings']['subset']['sha256'] == PINS['/tmp/g350-source236-selected94-literal-pour-margin-root-20261016.json']
            and len(aggregate['excludedBoundedPartialReports']) == 1
            and aggregate['excludedBoundedPartialReports'][0]['pcbCopperPourId'] == POURS[-1],
            'Aggregate exact six-input binding and excluded partial94')
    scoped_pass = {'scope': aggregate['scope'],
                   'report': copy.deepcopy(targets['/tmp/g350-source236-all15-literal-pour-margin-root-aggregate-20261016.json']),
                   'combinerSource': copy.deepcopy(targets['/tmp/g350-source236-literal-pour-coverage-combiner-sourceonly.py']),
                   'completedPourIds': POURS, 'completedPourCount': 15, 'actualViaCount': 227,
                   'wireSegmentCount': 7456, 'wireOwnerCount': 47,
                   'requiredForeignEdgeClearanceMm': .1016,
                   'minimumForeignEdgeGapMm': aggregate['minimumForeignEdgeGapMm'],
                   'literalForeignPourMarginClear': True, 'prior228PourPassInherited': False,
                   'referenceContinuityQualified': False, 'ownNetReentryQualified': False,
                   'all49Accepted': False, 'fabricationReady': False}
    current243 = read(Path('/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json'))
    names = {t['connection_name'] for t in current243['carrierTraces']}
    require(len(names) == 48 and {f'source_trace_{i}' for i in range(49)} - names == {'source_trace_26'}, '243 only source26 pending')
    model_milestone = {'scope': 'ROOT243_CAP12_PLUS_X0P79_MODEL48_NOT_SOURCE_VERIFIED',
                       'candidate': copy.deepcopy(targets['/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.candidate.json']),
                       'report': copy.deepcopy(targets['/tmp/g350-joint48-cap12-root-20261016-run243/byte0-result.json']),
                       'routedOwners': 48, 'pendingOwnerIds': ['source_trace_26'],
                       'all48ModelPhysicalAndNumericJoinedPassed': True,
                       'nativePoint15ViaLandSupplementPassed': True,
                       'hardwareChange': 'C_DDR_RAM_12_X_PLUS_0P79_AND_TWO_EXACT_POINT2_BOTTOM_REFERENCE_REROUTES',
                       'fullHardwareInverseLedgerInCandidate': True,
                       'allCriticalApisFreshForModel': False, 'criticalCompanionPending': True,
                       'freshSourceCaptureCorePending': True, 'allBoardNativeChecksPending': True,
                       'merged233CAGeometryOrTimingPassInherited': False, 'source236PourPassInherited': False,
                       'fullTimingPassed': False, 'tiQualified': False, 'cadQualified': False,
                       'defaultBoardPromoted': False, 'all49Accepted': False, 'fabricationReady': False}
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    progress['updatedAt'] = now
    progress['scope'] = 'Separate post232 through243; Source23347 fallback with scoped15-pour pass; separate cap12 MODEL48'
    progress['latestClosedScopeIncluded'] = 243
    progress['closedExperiments'].extend(additions)
    evidence.update({'scope': 'TWO_SAME_SCENE_BOUNDED_REPORTS_EXACT_AGGREGATE_PASSED',
                     'wholeCoverageCombinerPassed': True, 'literalPourClearanceQualified': True,
                     'aggregateBinding': copy.deepcopy(scoped_pass['report'])})
    progress['literalPourBoundedEvidence'] = evidence
    progress['literalPourCoverageAggregate'] = scoped_pass
    progress['separateModelMilestones'] = [model_milestone]
    progress['correctedTopologySourcesSavedWithoutRuntimeClosure'] = [copy.deepcopy(targets[n]) for n in PINS if '-v3-topology' in n]
    progress['appendCollector'] = str(Path(__file__))
    progress['through240MetadataPins'] = INITIAL
    require(progress['primaryCandidate'] == primary, 'Current23347 primary before scoped pour update unchanged')
    primary.update({'literalPourClearanceQualified': True, 'literalPourAuditPending': False,
                    'literalPourQualificationScope': scoped_pass['scope'],
                    'literalPourAggregateSha256': scoped_pass['report']['sha256']})
    progress['primaryCandidate'] = primary
    manifest['updatedAt'] = now
    manifest['files'] = sorted(targets.values(), key=lambda r: r['restorePath'])
    manifest['baseDependencyRestoreFiles'] = sorted(bases.values(), key=lambda r: r['restorePath'])
    manifest['literalPourBoundedEvidence'] = evidence
    manifest['literalPourCoverageAggregate'] = scoped_pass
    manifest['separateModelMilestones'] = [model_milestone]
    manifest['primaryCandidate'] = copy.deepcopy(primary)
    progress['publicBaseRestoreDependencies'] = copy.deepcopy(manifest['baseDependencyRestoreFiles'])
    for name, rowdata in inputs.items():
        require(metadata(Path(name)) == rowdata, 'Collected public input changed')
    for name, pin in PINS.items():
        require(digest(Path(name)) == pin, 'Pinned input changed at closure')
    # Verify original immutable payloads, excluding just the three appendable
    # metadata files and README, before updating the metadata index.
    verify_rows(SAVED, [r for r in before_index['files'] if r['path'] not in INITIAL])
    verify_old()
    atomic_json('WORKSPACE_RESTORE_MANIFEST.json', manifest)
    readme = (SAVED / 'README.md').read_text()
    old_status = """LITERAL15-POUR CLEARANCE IS NOT YET QUALIFIED. The Source228 all14-pour pass is a
base dependency only and is NOT inherited for the new Source236 copper geometry.
No new pour pass, own-net reentry proof, complete routing or fabrication claim is
made by this collector."""
    require(old_status in readme, 'Exact old pending paragraph must be present')
    readme = readme.replace(old_status, """SOURCE236 LITERAL15-POUR FOREIGN CLEARANCE HAS A SCOPED PASS. The exact pinned
coverage combiner reconstructs227 via and7456 routed-wire object identities and
foreign comparison/exemption sets for all15 fresh BREP pours. The bounded94
contribution is excluded and replaced by the separately completed94 retry.
Minimum measured foreign edge gap is0.11832052949719676mm against0.1016mm.
This does not establish reference continuity, own-net reentry, complete routing,
TI/electrical readiness or fabrication qualification. No Source228 pass is
inherited.""")
    readme = readme.replace('Append through closed240:', 'Historical append through closed240:')
    readme = """CURRENT THROUGH243: Source-verified merged23347 is the fallback primary. Its
Source236 exact15-pour foreign-margin aggregate passed. A SEPARATE cap12+.79
MODEL243 has48 physical/numeric-joined routes, pending26, with critical companion,
fresh editable Source/Core, full native and CAD qualification still pending.
The48 model does NOT inherit merged233CA13 timing progress or Source236 pours.

""" + readme
    readme += """

Append through243:241 was refused at shared-memory admission without a child.
242 passed the hardware schema and two fanout checks but rejected the changed
Source1 body for a nonconventional corner.243 passed the model all48 body/numeric
and native0.15via-land gates with one named capacitor translated+X0.79 and two
exact0.2mm Bottom reference reroutes. Its original critical-pair geometry stays
held, but fresh critical API/capture/Core/native/CAD companion checks are pending.
The Source23347 primary and its full CA13 timing-improvement geometry remain a
separate fallback. No48 Source-verified, full timing, TI, electrical, default or
fabrication acceptance is claimed. Old pending wording in the historical
through240 append is superseded by the scoped aggregate status above.
Initial through238 and through240 metadata remain exact HISTORY_THROUGH*_ files.
"""
    temp = SAVED / '.append243-README.tmp'
    with temp.open('x') as stream:
        stream.write(readme)
        os.fchmod(stream.fileno(), 0o600)
    os.replace(temp, SAVED / 'README.md')
    excluded = {'PROGRESS.json', 'WORKSPACE_RESTORE_MANIFEST.json', 'WORKSPACE_HASH_INDEX.json'}
    progress['artifacts'] = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir()) if regular(p) and p.name not in excluded]
    atomic_json('PROGRESS.json', progress)
    rows = [{'path': p.name, **metadata(p)} for p in sorted(SAVED.iterdir()) if regular(p) and p.name != 'WORKSPACE_HASH_INDEX.json']
    atomic_json('WORKSPACE_HASH_INDEX.json', {'scope': 'Post232 through243; Source23347 scoped-pour pass plus separate MODEL24348',
                'updatedAt': now, 'files': rows, 'selfExcluded': True, 'all49Accepted': False, 'fabricationReady': False})
    verify_rows(SAVED, rows)
    for r in manifest['files']:
        require(metadata(SAVED / r['savedPath']) == {k: r[k] for k in ('bytes', 'sha256', 'mode')}, 'Restore payload mismatch')
        require(metadata(Path(r['restorePath'])) == {k: r[k] for k in ('bytes', 'sha256', 'mode')}, 'Restore target mismatch')
    verify_old()
    print(json.dumps({'savedDirectory': str(SAVED), 'savedFiles': len(list(SAVED.iterdir())),
          'indexedFiles': len(rows), 'restoreTargets': len(manifest['files']),
          'baseDependencies': len(manifest['baseDependencyRestoreFiles']), 'latestClosedScope': 243,
          'sourceVerifiedFallbackRoutedOwners': 47, 'separateModelRoutedOwners': 48,
          'source236ScopedLiteralPourPass': True, 'model243SourceAndCriticalCompanionPending': True, 'all49Accepted': False,
          'metadataHashes': {n: digest(SAVED / n) for n in INITIAL}}, indent=2))


if __name__ == '__main__':
    main()
