// Plain-source candidate. Authoring does not import or execute this module.
// Root must bind the passed golden Core384 and fresh actual Core before calling.
import assert from 'node:assert/strict'
import { getFullConnectivityMapFromCircuitJson } from 'circuit-json-to-connectivity-map'

const EPSILON_MM = 1e-8
const PHYSICAL_LAYERS = ['top', 'inner1', 'inner2', 'bottom']
const proofStates = new WeakMap()
const near = (a, b) => Number.isFinite(a) && Number.isFinite(b) && Math.abs(a - b) < EPSILON_MM
const at = (a, b) => a && b && near(a.x, b.x) && near(a.y, b.y)
const exactRecord = (actual, old, context) => assert.equal(JSON.stringify(actual), JSON.stringify(old), context)

function index(circuit) {
  assert(Array.isArray(circuit))
  const types = new Map()
  for (const row of circuit) {
    assert(row && typeof row.type === 'string')
    if (!types.has(row.type)) types.set(row.type, [])
    types.get(row.type).push(row)
  }
  const rows = type => types.get(type) ?? []
  const idMaps = new Map()
  const byId = type => {
    if (idMaps.has(type)) return idMaps.get(type)
    const result = new Map()
    for (const row of rows(type)) {
      const id = row[type + '_id']
      assert.equal(typeof id, 'string', 'Known row identity required: ' + type)
      assert(!result.has(id), 'Duplicate actual identity: ' + id)
      result.set(id, row)
    }
    idMaps.set(type, result)
    return result
  }
  return { rows, byId }
}

function one(values, message) {
  assert.equal(values.length, 1, message)
  return values[0]
}

function requireVia(via, netId) {
  assert(via && via.source_net_id === netId, 'Full-through via must retain exact known rail')
  assert.equal(via.outer_diameter, .4572)
  assert.equal(via.hole_diameter, .254)
  assert.deepEqual(via.layers, PHYSICAL_LAYERS)
  assert.equal(via.from_layer, 'top')
  assert.equal(via.to_layer, 'bottom')
  assert.equal(via.tented_on_top, true)
  assert.equal(via.tented_on_bottom, true)
  assert(Array.isArray(via.pcb_port_ids) && via.pcb_port_ids.length === 2)
}

function aliasForVia(via, layer, actual) {
  const ports = actual.byId('pcb_port')
  const sourcePorts = actual.byId('source_port')
  const top = one(via.pcb_port_ids.map(id => ports.get(id)).filter(p => p && p.layers?.length === 1 && p.layers[0] === layer), 'Exactly one actual ' + layer + ' via alias required')
  assert(at(top, via), 'Actual via alias must coincide with own physical barrel')
  const source = sourcePorts.get(top.source_port_id)
  assert(source && source.name === layer, 'Actual layer alias source port required')
  const owner = actual.byId('source_manually_placed_via').get(source.source_component_id)
  assert(owner && owner.source_net_id === via.source_net_id, 'Actual alias must belong to own authored via and rail')
  const placeholder = actual.byId('pcb_component').get(top.pcb_component_id)
  assert(placeholder && placeholder.source_component_id === owner.source_manually_placed_via_id && at(placeholder.center, via), 'Via alias placeholder must identify the same authored barrel')
  return { pcb: top, source, owner }
}

function endpointIds(trace, first, second) {
  const ends = [trace.route[0], trace.route.at(-1)]
  const ids = ends.flatMap(p => [p.start_pcb_port_id, p.end_pcb_port_id].filter(Boolean))
  assert.equal(ids.length, 2, 'Only the two actual endpoint PCB ports are expected')
  assert.deepEqual([...ids].sort(), [first, second].sort(), 'Trace endpoint IDs must bind numeric pad and actual via alias')
}

function graphProof(connectivity, trace, sourceTrace, padId, aliasId, viaId, netId) {
  for (const pair of [[padId, trace.pcb_trace_id], [aliasId, trace.pcb_trace_id], [padId, viaId], [aliasId, viaId], [sourceTrace.source_trace_id, viaId], [netId, viaId]]) {
    assert(connectivity.areIdsConnected(...pair), 'Actual known-net Circuit JSON graph missing link: ' + pair.join(' / '))
  }
}

function frozen(value) {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) frozen(child)
    Object.freeze(value)
  }
  return value
}

export function proveSharedPackageLoops({ proposal, goldenCore, freshCore }) {
  assert(proposal && Array.isArray(proposal.owners) && Array.isArray(proposal.viaGroups))
  const old = index(goldenCore), actual = index(freshCore)
  const oldVias = old.rows('pcb_via'), oldTraces = old.rows('pcb_trace')
  assert.equal(oldVias.length, 64, 'Passed golden HS64 Core required')
  assert.equal(oldTraces.length, 64, 'Passed golden HS64 local copper required')
  const actualVias = actual.byId('pcb_via'), actualTraces = actual.byId('pcb_trace')
  for (const before of [...oldVias, ...oldTraces]) exactRecord((before.type === 'pcb_via' ? actualVias : actualTraces).get(before[before.type + '_id']), before, 'Every retained HS64 barrel/stub must remain byte-structure exact')
  const sourceTraces = actual.byId('source_trace')
  for (const before of old.rows('source_trace')) exactRecord(sourceTraces.get(before.source_trace_id), before, 'Original source trace identity/logic must remain exact')
  assert.equal(actual.rows('source_net').length, old.rows('source_net').length)
  for (const before of old.rows('source_net')) exactRecord(actual.byId('source_net').get(before.source_net_id), before, 'Original named rail identities must remain exact')
  const connectivity = getFullConnectivityMapFromCircuitJson(freshCore)
  const state = new Map(), branches = [], groups = [], ownerKeys = new Set(), intentionalContacts = [], intentionalPadContacts = [], padRegistry = new Map()

  const register = (via, trace) => {
    if (!state.has(via.pcb_via_id)) state.set(via.pcb_via_id, { via, sourceTraceIds: new Set(), pcbTraceIds: new Set() })
    const entry = state.get(via.pcb_via_id)
    assert.equal(entry.via.source_net_id, via.source_net_id)
    entry.sourceTraceIds.add(trace.source_trace_id)
    entry.pcbTraceIds.add(trace.pcb_trace_id)
  }

  // All retained branches are proved from the unchanged actual physical rows.
  // This also preserves the old Bottom branch at each reused HS via.
  for (const via of oldVias) {
    const current = actualVias.get(via.pcb_via_id)
    requireVia(current, via.source_net_id)
    const bottom = aliasForVia(current, 'bottom', actual)
    const trace = one(oldTraces.filter(t => t.route.some(p => p.route_type === 'wire' && p.layer === 'bottom' && at(p, via))), 'Exactly one retained HS Bottom stub per barrel required')
    assert(trace.route.length >= 2 && trace.route.every(p => p.route_type === 'wire' && p.layer === 'bottom' && p.width === .2))
    const source = sourceTraces.get(trace.source_trace_id)
    assert(source && source.connected_source_net_ids?.includes(via.source_net_id) && source.connected_source_port_ids?.includes(bottom.source.source_port_id))
    const capSourceId = one(source.connected_source_port_ids.filter(id => id !== bottom.source.source_port_id), 'Retained HS numeric pad owner required')
    const capSource = actual.byId('source_port').get(capSourceId)
    const cap = one(actual.rows('pcb_port').filter(p => p.source_port_id === capSourceId), 'Retained HS actual numeric PCB port required')
    const component = actual.byId('source_component').get(capSource?.source_component_id)
    assert(component?.name?.startsWith('C_DDR_') && Number.isInteger(capSource.pin_number) && [1, 2].includes(capSource.pin_number))
    exactRecord(capSource, old.byId('source_port').get(capSourceId), 'Retained HS numeric source terminal must remain exact')
    exactRecord(cap, old.byId('pcb_port').get(cap.pcb_port_id), 'Retained HS numeric PCB terminal must remain exact')
    exactRecord(component, old.byId('source_component').get(component.source_component_id), 'Retained HS real part identity must remain exact')
    const hsRail = one(actual.rows('source_net').filter(n => n.name === (capSource.pin_number === 1 ? 'DDR_1V5' : 'GND')), 'Retained capacitor numeric terminal rail required')
    assert.equal(via.source_net_id, hsRail.source_net_id)
    assert.deepEqual(cap.layers, ['bottom'])
    const pad = one(actual.rows('pcb_smtpad').filter(p => p.pcb_port_id === cap.pcb_port_id), 'Retained HS numeric copper pad required')
    assert(pad.layer === 'bottom' && at(pad, cap))
    exactRecord(pad, old.byId('pcb_smtpad').get(pad.pcb_smtpad_id), 'Retained HS numeric copper pad must remain exact')
    endpointIds(trace, cap.pcb_port_id, bottom.pcb.pcb_port_id)
    assert([trace.route[0], trace.route.at(-1)].some(p => at(p, cap)) && [trace.route[0], trace.route.at(-1)].some(p => at(p, current)))
    graphProof(connectivity, trace, source, cap.pcb_port_id, bottom.pcb.pcb_port_id, current.pcb_via_id, current.source_net_id)
    register(current, trace)
    branches.push({ scope: 'RETAINED_ACTUAL_HS_BOTTOM', pcb_via_id: current.pcb_via_id, pcb_trace_id: trace.pcb_trace_id, source_trace_id: trace.source_trace_id, pcb_port_id: cap.pcb_port_id, source_port_id: capSourceId, source_net_id: current.source_net_id })
  }

  const groupByKey = new Map()
  const usedActualVias = new Set(), newViaNames = new Set(), newTraceNames = new Set()
  for (const group of proposal.viaGroups) {
    assert(group && typeof group.key === 'string' && !groupByKey.has(group.key))
    assert(typeof group.viaName === 'string' && group.viaName && Array.isArray(group.ownerKeys) && group.ownerKeys.length > 0)
    assert(['GND', 'DDR_1V5'].includes(group.referenceNet))
    const net = one(actual.rows('source_net').filter(n => n.name === group.referenceNet), 'Actual canonical rail required')
    assert.equal(group.source_net_id, net.source_net_id)
    const via = one(actual.rows('pcb_via').filter(v => at(v, group)), 'Canonical site must identify exactly one actual barrel')
    requireVia(via, group.source_net_id)
    assert(!usedActualVias.has(via.pcb_via_id), 'Multiple proposal groups cannot own the same physical site/barrel')
    usedActualVias.add(via.pcb_via_id)
    if (group.reuseAcceptedHsViaId !== null) {
      assert.equal(via.pcb_via_id, group.reuseAcceptedHsViaId)
      assert(old.byId('pcb_via').has(via.pcb_via_id), 'Reused group must name an accepted HS64 barrel')
    } else {
      assert(!old.byId('pcb_via').has(via.pcb_via_id), 'New group must produce a new owned barrel')
      assert(!newViaNames.has(group.viaName), 'New canonical source via names must be unique')
      newViaNames.add(group.viaName)
    }
    const top = aliasForVia(via, 'top', actual)
    groupByKey.set(group.key, { group, via, top, matchedOwners: [] })
  }

  for (const owner of proposal.owners) {
    assert(owner && typeof owner.ownerKey === 'string' && !ownerKeys.has(owner.ownerKey))
    ownerKeys.add(owner.ownerKey)
    assert.equal(owner.ownerKey, `${owner.package}:pin${owner.numericPin}`)
    assert(['U_SOC', 'U_RAM'].includes(owner.package) && Number.isInteger(owner.numericPin))
    const resolved = groupByKey.get(owner.viaGroupKey)
    assert(resolved && resolved.group.ownerKeys.includes(owner.ownerKey))
    const { group, via, top } = resolved
    assert.equal(owner.referenceNet, group.referenceNet)
    assert.equal(owner.source_net_id, group.source_net_id)
    assert(at(owner.viaXY, via))
    const component = one(actual.rows('source_component').filter(c => c.name === owner.package), 'Exact actual package component required')
    const oldComponent = one(old.rows('source_component').filter(c => c.name === owner.package), 'Exact golden package required')
    exactRecord(component, oldComponent, 'Original real package identity must remain exact')
    const sourcePort = actual.byId('source_port').get(owner.source_port_id)
    assert(sourcePort && sourcePort.source_component_id === component.source_component_id && sourcePort.pin_number === owner.numericPin)
    exactRecord(sourcePort, old.byId('source_port').get(owner.source_port_id), 'Original numeric source pin must remain exact')
    const originalRails = new Set(old.rows('source_trace').filter(t => t.connected_source_port_ids?.includes(owner.source_port_id)).flatMap(t => t.connected_source_net_ids ?? []))
    assert.deepEqual([...originalRails], [owner.source_net_id], 'Package branch cannot retag or join the original numeric pin rail')
    const pcbPort = actual.byId('pcb_port').get(owner.pcb_port_id)
    assert(pcbPort && pcbPort.source_port_id === sourcePort.source_port_id && at(pcbPort, owner.padXY))
    exactRecord(pcbPort, old.byId('pcb_port').get(owner.pcb_port_id), 'Original numeric PCB pin must remain exact')
    assert.deepEqual(pcbPort.layers, ['top'])
    const pad = one(actual.rows('pcb_smtpad').filter(p => p.pcb_port_id === pcbPort.pcb_port_id), 'One actual numeric Top copper land required')
    assert(pad.layer === 'top' && at(pad, owner.padXY))
    exactRecord(pad, old.byId('pcb_smtpad').get(pad.pcb_smtpad_id), 'Original package copper pad must remain exact')
    assert(typeof owner.traceName === 'string' && owner.traceName && !newTraceNames.has(owner.traceName))
    assert(!old.rows('source_trace').some(t => t.name === owner.traceName), 'Package branch name cannot alias an existing source trace')
    newTraceNames.add(owner.traceName)
    const sourceTrace = one(actual.rows('source_trace').filter(t => t.name === owner.traceName), 'Unique actual package branch source trace required')
    assert.deepEqual([...sourceTrace.connected_source_port_ids].sort(), [sourcePort.source_port_id, top.source.source_port_id].sort())
    assert.deepEqual(sourceTrace.connected_source_net_ids, [owner.source_net_id])
    const pinSelector = `${owner.package}.pin${owner.numericPin}`, viaSelector = `.${group.viaName} > port.top`
    assert([`${pinSelector} to ${viaSelector}`, `${viaSelector} to ${pinSelector}`].includes(sourceTrace.display_name), 'Exact canonical source selectors must survive Core in their authored direction')
    const trace = one(actual.rows('pcb_trace').filter(t => t.source_trace_id === sourceTrace.source_trace_id), 'One actual physical package branch required')
    const expected = owner.topStub
    assert(Array.isArray(expected) && expected.length >= 2 && at(expected[0], owner.padXY) && at(expected.at(-1), owner.viaXY))
    for (const p of expected) assert(p.route_type === 'wire' && p.layer === 'top' && Number.isFinite(p.width) && p.width >= .1016)
    assert.equal(trace.route.length, expected.length)
    const same = (point, wanted) => point.route_type === 'wire' && point.layer === 'top' && point.width === wanted.width && at(point, wanted)
    assert(trace.route.every((p, i) => same(p, expected[i])) || trace.route.every((p, i) => same(p, expected[expected.length - 1 - i])), 'Actual Top centerline and every declared width must reproduce exactly')
    endpointIds(trace, pcbPort.pcb_port_id, top.pcb.pcb_port_id)
    graphProof(connectivity, trace, sourceTrace, pcbPort.pcb_port_id, top.pcb.pcb_port_id, via.pcb_via_id, owner.source_net_id)
    const length = trace.route.slice(1).reduce((sum, b, i) => sum + Math.hypot(b.x - trace.route[i].x, b.y - trace.route[i].y), 0)
    assert(Number.isFinite(owner.stubLengthMm) && near(length, owner.stubLengthMm), 'Declared length must equal actual copper centerline length')
    // Classify from retained actual source-port function aliases. Special
    // VSS domains and analog/control ties have only a proposal radius here.
    const hints = sourcePort.port_hints ?? []
    const literalCpuPower = hints.some(h => /^VDDS_DDR[0-9]*$/.test(h))
    const literalCpuGround = hints.some(h => /^VSS[0-9]*$/.test(h))
    const ramPower = hints.some(h => /^VDDQ?[0-9]*$/.test(h))
    const ramGround = hints.some(h => /^VSSQ?[0-9]*$/.test(h))
    if (owner.package === 'U_RAM') {
      assert(ramPower || ramGround, 'RAM candidate must identify a real power/ground numeric terminal')
      assert.equal(owner.referenceNet, ramPower ? 'DDR_1V5' : 'GND')
      assert.equal(owner.routeToViaLimitMm, 1.524)
    } else if (literalCpuPower || literalCpuGround) {
      assert.equal(owner.referenceNet, literalCpuPower ? 'DDR_1V5' : 'GND')
      assert.equal(owner.routeToViaLimitMm, 1.778)
    } else {
      assert.equal(owner.referenceNet, 'GND', 'Only preserved non-DDR ground ties are included')
      assert.equal(owner.routeToViaLimitMm, null, 'Special domains/ties have no TI DDR length claim')
    }
    const limit = owner.routeToViaLimitMm ?? 2.54
    assert(length <= limit + EPSILON_MM, 'Actual package copper exceeds declared applicable bound')
    register(via, trace)
    resolved.matchedOwners.push(owner.ownerKey)
    branches.push({ scope: 'NEW_PACKAGE_TOP', ownerKey: owner.ownerKey, package: owner.package, numericPin: owner.numericPin, pcb_port_id: pcbPort.pcb_port_id, source_port_id: sourcePort.source_port_id, pcb_via_id: via.pcb_via_id, pcb_trace_id: trace.pcb_trace_id, source_trace_id: sourceTrace.source_trace_id, source_net_id: owner.source_net_id, viaGroupKey: group.key, actualCopperLengthMm: length, appliedLimitMm: limit, tiLengthClaim: owner.routeToViaLimitMm !== null })
  }
  const contactRequests = proposal.intentionalExistingTraceContacts ?? []
  assert(Array.isArray(contactRequests) && contactRequests.length <= 1, 'Only the explicitly authorized retained HS8 contact is supported')
  const padContactRequests = proposal.intentionalExistingPadContacts ?? []
  assert(Array.isArray(padContactRequests) && padContactRequests.length === contactRequests.length, 'The one declared HS8 pad/strip junction requires both explicit requests')
  for (const request of contactRequests) {
    assert(request && request.pcb_trace_id === 'pcb_trace_55' && request.source_trace_id === 'source_trace_987' && request.source_net_id === 'source_net_0' && request.layer === 'bottom', 'Intentional contact cannot authorize another old trace, rail or layer')
    assert.equal(request.minimumContactChordMm, .1016, 'The explicit minimum contact chord cannot be weakened')
    const resolved = groupByKey.get(request.viaGroupKey)
    assert(resolved && resolved.group.reuseAcceptedHsViaId === null && resolved.matchedOwners.length > 0, 'Contact must use a new canonical via with an already proved package branch')
    const { group, via } = resolved
    assert(group.referenceNet === 'GND' && via.source_net_id === request.source_net_id && at(via, { x: .4, y: 8.975 }), 'Only the corrected explicitly authorized GND site is supported')
    assert.deepEqual([...resolved.matchedOwners].sort(), ['U_RAM:pin25'], 'This junction is authorized only for the proved RAM25 package branch')
    assert(!old.byId('pcb_via').has(via.pcb_via_id) && via.layers.includes(request.layer))
    const oldTrace = old.byId('pcb_trace').get(request.pcb_trace_id)
    const oldSourceTrace = old.byId('source_trace').get(request.source_trace_id)
    const trace = actualTraces.get(request.pcb_trace_id)
    const sourceTrace = sourceTraces.get(request.source_trace_id)
    assert(oldTrace && oldSourceTrace && oldTrace.source_trace_id === request.source_trace_id)
    exactRecord(trace, oldTrace, 'Authorized HS8 strip must remain byte-structure exact')
    exactRecord(sourceTrace, oldSourceTrace, 'Authorized HS8 source ownership must remain exact')
    assert(sourceTrace.connected_source_net_ids?.includes(request.source_net_id))
    const retainedBranch = one(branches.filter(b => b.scope === 'RETAINED_ACTUAL_HS_BOTTOM' && b.pcb_trace_id === request.pcb_trace_id && b.source_trace_id === request.source_trace_id), 'Old HS8 numeric cap/alias/owned-via graph must already be proved')
    assert.equal(retainedBranch.source_net_id, request.source_net_id)
    const oldOwnedVia = actualVias.get(retainedBranch.pcb_via_id)
    assert(oldOwnedVia && oldOwnedVia.pcb_via_id !== via.pcb_via_id && old.byId('pcb_via').has(oldOwnedVia.pcb_via_id))
    assert(state.get(oldOwnedVia.pcb_via_id)?.sourceTraceIds.has(request.source_trace_id))
    const oldBottomAlias = aliasForVia(oldOwnedVia, 'bottom', actual)
    graphProof(connectivity, trace, sourceTrace, retainedBranch.pcb_port_id, oldBottomAlias.pcb.pcb_port_id, oldOwnedVia.pcb_via_id, request.source_net_id)
    assert(connectivity.areIdsConnected(trace.pcb_trace_id, via.pcb_via_id) && connectivity.areIdsConnected(sourceTrace.source_trace_id, via.pcb_via_id) && connectivity.areIdsConnected(oldOwnedVia.pcb_via_id, via.pcb_via_id), 'Same-rail actual old-cap/old-via/new-via graph is necessary but is not the physical contact proof')
    assert.equal(trace.route.length, 2, 'The one authorized retained strip is a single actual straight segment')
    const [a, b] = trace.route
    assert(a.route_type === 'wire' && b.route_type === 'wire' && a.layer === request.layer && b.layer === request.layer && a.width === .2 && b.width === .2)
    assert(!a.width_interpolation_mode && !b.width_interpolation_mode, 'A constant-width actual strip is required')
    const dx = b.x - a.x, dy = b.y - a.y, segmentLength = Math.hypot(dx, dy)
    assert(segmentLength > EPSILON_MM)
    const along = ((via.x - a.x) * dx + (via.y - a.y) * dy) / segmentLength
    const centerlineDistance = Math.abs(dx * (via.y - a.y) - dy * (via.x - a.x)) / segmentLength
    const landRadius = via.outer_diameter / 2, stripHalfWidth = a.width / 2
    const nearestStripSliceDistance = Math.max(0, centerlineDistance - stripHalfWidth)
    assert(nearestStripSliceDistance < landRadius, 'The actual full-depth land must overlap the actual strip with positive contact')
    const halfChord = Math.sqrt(landRadius * landRadius - nearestStripSliceDistance * nearestStripSliceDistance)
    const contactChordMm = 2 * halfChord
    assert(contactChordMm >= request.minimumContactChordMm, 'Actual land/strip contact chord is too narrow')
    // This chord lies on a line within the actual rectangular strip. Both of
    // its ends must be inside the finite segment; no endpoint-circle guess.
    assert(along - halfChord > EPSILON_MM && along + halfChord < segmentLength - EPSILON_MM, 'The entire contact chord must be interior to the actual finite straight strip')
    assert(centerlineDistance - stripHalfWidth > via.hole_diameter / 2, 'The new drill must not cut the preserved strip')
    const padRequest = one(padContactRequests.filter(p => p.viaGroupKey === request.viaGroupKey), 'The same canonical via must identify the explicit retained HS8 pad')
    assert(padRequest.pcb_smtpad_id === 'pcb_smtpad_729' && padRequest.pcb_port_id === 'pcb_port_730' && padRequest.source_port_id === 'source_port_730' && padRequest.source_component_id === 'source_component_132' && padRequest.source_net_id === 'source_net_0' && padRequest.layer === 'bottom' && padRequest.originalHsNumericPin === 2, 'No other retained pad, numeric pin, rail or layer is authorized')
    const pad = actual.byId('pcb_smtpad').get(padRequest.pcb_smtpad_id)
    const oldPad = old.byId('pcb_smtpad').get(padRequest.pcb_smtpad_id)
    const padPort = actual.byId('pcb_port').get(padRequest.pcb_port_id)
    const padSource = actual.byId('source_port').get(padRequest.source_port_id)
    const padPart = actual.byId('source_component').get(padRequest.source_component_id)
    exactRecord(pad, oldPad, 'Authorized HS8 pad geometry must remain exact')
    exactRecord(padPort, old.byId('pcb_port').get(padRequest.pcb_port_id), 'Authorized HS8 numeric PCB port must remain exact')
    exactRecord(padSource, old.byId('source_port').get(padRequest.source_port_id), 'Authorized HS8 numeric source port must remain exact')
    exactRecord(padPart, old.byId('source_component').get(padRequest.source_component_id), 'Authorized HS8 real part must remain exact')
    assert(pad && pad.shape === 'rect' && pad.layer === 'bottom' && pad.pcb_port_id === padRequest.pcb_port_id && Number.isFinite(pad.width) && pad.width > 0 && Number.isFinite(pad.height) && pad.height > 0 && (pad.ccw_rotation ?? 0) === 0)
    assert(padPort && padPort.source_port_id === padRequest.source_port_id && at(padPort, pad))
    assert(padSource && padSource.source_component_id === padRequest.source_component_id && padSource.pin_number === 2 && padPart?.name === 'C_DDR_RAM_8')
    assert(retainedBranch.pcb_port_id === padRequest.pcb_port_id && retainedBranch.source_port_id === padRequest.source_port_id, 'Pad junction must be on the same already proved HS8 Bottom cap/stub/owned-via graph')
    const left = pad.x - pad.width / 2, right = pad.x + pad.width / 2
    const bottom = pad.y - pad.height / 2, top = pad.y + pad.height / 2
    const closestX = Math.max(left, Math.min(via.x, right)), closestY = Math.max(bottom, Math.min(via.y, top))
    const padDistance = Math.hypot(via.x - closestX, via.y - closestY)
    assert(padDistance < landRadius && padDistance > via.hole_diameter / 2, 'Actual pad must have positive land overlap and stay wholly outside the new drill')
    assert(connectivity.areIdsConnected(pad.pcb_smtpad_id, via.pcb_via_id) && connectivity.areIdsConnected(padPort.pcb_port_id, via.pcb_via_id) && connectivity.areIdsConnected(padSource.source_port_id, via.pcb_via_id), 'Known numeric HS8 cap/new-via graph must accompany physical contact')
    // Rectangle and finite straight-strip copper are each convex. Strict
    // closest-distance <R gives positive disk intersection. Their complete
    // separation from the drill means subtracting that disk changes neither
    // contact patch. Both patches remain connected on the actual annulus.
    // They need not be represented by an invented source trace or net label.
    assert(landRadius - via.hole_diameter / 2 >= .1016 - Number.EPSILON, 'Actual standard annulus radial copper cannot be weakened')
    padRegistry.set(via.pcb_via_id, new Set([pad.pcb_smtpad_id]))
    intentionalPadContacts.push({ viaGroupKey: group.key, pcb_via_id: via.pcb_via_id, pcb_smtpad_id: pad.pcb_smtpad_id, pcb_port_id: padPort.pcb_port_id, source_port_id: padSource.source_port_id, source_component_id: padPart.source_component_id, source_net_id: via.source_net_id, originalHsNumericPin: 2, layer: 'bottom', actualPadRectangle: { left, right, bottom, top }, actualClosestPadDistanceMm: padDistance, actualLandRadiusMm: landRadius, actualHoleRadiusMm: via.hole_diameter / 2, positiveLandPadContact: true, oldPadAndNumericOwnersExact: true, padEntirelyOutsideDrill: true, annulusPadContactPatchConnected: true, oldStripEntirelyOutsideDrill: true, annulusStripContactPatchConnected: true, actualOldCapStripAndNewPackageKnownRailGraphsProved: true, priorHsNativeProofMustBeHashBoundByCaller: true, referenceQualified: false })
    register(via, trace)
    intentionalContacts.push({ viaGroupKey: group.key, pcb_via_id: via.pcb_via_id, source_net_id: request.source_net_id, pcb_trace_id: trace.pcb_trace_id, source_trace_id: sourceTrace.source_trace_id, layer: request.layer, existingCapPcbPortId: retainedBranch.pcb_port_id, existingCapSourcePortId: retainedBranch.source_port_id, existingOwnedHsViaId: oldOwnedVia.pcb_via_id, existingOwnedHsBottomAliasId: oldBottomAlias.pcb.pcb_port_id, provedPackageOwnerKeys: [...resolved.matchedOwners], segmentStart: { x: a.x, y: a.y }, segmentEnd: { x: b.x, y: b.y }, actualLandRadiusMm: landRadius, actualStripHalfWidthMm: stripHalfWidth, centerlineDistanceMm: centerlineDistance, nearestStripSliceDistanceMm: nearestStripSliceDistance, segmentLengthMm: segmentLength, projectionDistanceFromStartMm: along, contactChordMm, minimumContactChordMm: request.minimumContactChordMm, fullChordInteriorToActualStrip: true, actualHoleClearOfPreservedStrip: true, retainedHsStripAndSourceExact: true, actualOldAndNewKnownRailGraphsProved: true, physicalSameRailContactProved: true, referenceQualified: false })
  }
  for (const { group, via, matchedOwners } of groupByKey.values()) {
    assert.deepEqual([...matchedOwners].sort(), [...group.ownerKeys].sort(), 'Every declared shared owner must have an actually proved branch')
    assert.equal(new Set(group.ownerKeys).size, group.ownerKeys.length)
    const perPackage = proposal.owners.filter(o => o.viaGroupKey === group.key)
    assert(perPackage.filter(o => o.package === 'U_RAM').length <= 2, 'DDR device candidate sharing exceeds TI note9 bound')
    assert(perPackage.filter(o => o.package === 'U_SOC').length <= 4, 'CPU sharing exceeds conservative proposal policy; not a TI exception proof')
    groups.push({ key: group.key, viaName: group.viaName, pcb_via_id: via.pcb_via_id, source_net_id: via.source_net_id, reuseAcceptedHsViaId: group.reuseAcceptedHsViaId, ownerKeys: [...matchedOwners], registeredSourceTraceIds: [...state.get(via.pcb_via_id).sourceTraceIds].sort() })
  }
  const newGroupCount = proposal.viaGroups.filter(g => g.reuseAcceptedHsViaId === null).length
  assert.equal(actual.rows('pcb_via').length, 64 + newGroupCount, 'Only retained and declared canonical package barrels are allowed')
  assert.equal(actual.rows('pcb_trace').length, 64 + proposal.owners.length, 'Only retained and declared package branches are allowed')
  assert.equal(state.size, actual.rows('pcb_via').length, 'Every physical via needs a proved branch set')
  for (const entry of state.values()) {
    assert(entry.sourceTraceIds.size > 0)
    if (entry.via.pcb_trace_id !== undefined) assert(entry.pcbTraceIds.has(entry.via.pcb_trace_id), 'Existing foreign pcb_trace_id cannot be ignored or rewritten')
  }
  const proof = frozen({ scope: 'ACTUAL_NUMERIC_KNOWN_RAIL_PACKAGE_BRANCH_SETS_AND_EXACT_RETAINED_HS64', retainedHsBranches: 64, packageBranches: proposal.owners.length, newCanonicalVias: newGroupCount, reusedCanonicalSites: proposal.viaGroups.length - newGroupCount, groups, branches, intentionalExistingTraceContacts: intentionalContacts, intentionalExistingPadContacts: intentionalPadContacts, rawCircuitUnmodified: true, cpuSharingPolicyOnly: true, filledReferencesQualified: false, referenceQualified: false, accepted49: false, fabricationReady: false })
  proofStates.set(proof, { circuit: freshCore, signature: JSON.stringify(freshCore), registry: state, padRegistry })
  return proof
}

// Only a proof produced above is usable; loose maps/same-net labels are refused.
export function getProvedViaBranchRegistry(proof, circuit) {
  const state = proofStates.get(proof)
  assert(state && state.circuit === circuit, 'Manufacturing requires this module\'s proof of this exact raw Core object')
  assert.equal(JSON.stringify(circuit), state.signature, 'Raw Core changed after branch ownership proof')
  return new Map([...state.registry].map(([id, entry]) => [id, new Set(entry.sourceTraceIds)]))
}

// Internal consumer accessor: only the exact privately proved pad contact.
export function getProvedIntentionalPadContactRegistry(proof, circuit) {
  const state = proofStates.get(proof)
  assert(state && state.circuit === circuit, 'Pad guard requires this module\'s proof of this exact raw Core object')
  assert.equal(JSON.stringify(circuit), state.signature, 'Raw Core changed after numeric pad/annulus contact proof')
  return new Map([...state.padRegistry].map(([id, pads]) => [id, new Set(pads)]))
}
