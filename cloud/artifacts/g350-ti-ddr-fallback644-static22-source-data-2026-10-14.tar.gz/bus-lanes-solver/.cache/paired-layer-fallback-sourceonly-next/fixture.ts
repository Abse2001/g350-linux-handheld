import type { SimpleRouteJson } from "./lib/types"

/** Synthetic public-API regression, not a G350 hardware source projection. */
export const makeFixture = (blockedLayers: string[] = ["top"]): SimpleRouteJson => ({
  layerCount: 4,
  allowedLayers: ["top", "inner1"],
  minTraceWidth: 0.1,
  minTraceToPadEdgeClearance: 0.1,
  bounds: { minX: -6, maxX: 6, minY: -3, maxY: 3 },
  obstacles: [{
    center: { x: 0, y: 0 },
    width: 0.3,
    height: 7,
    layers: blockedLayers,
    connectedTo: [],
  }],
  connections: [-0.11, 0.11].map((y, i) => ({
    name: i ? "N" : "P",
    pointsToConnect: [-4, 4].map((x) => ({ x, y, layer: "top" })),
  })),
  differentialPairs: [{
    connectionNames: ["P", "N"],
    traceGap: 0.12,
    lengthTolerance: 0.127,
    maxUncoupledLength: 0.01,
  }],
})

export const terminalLayers = () => new Map([
  ["P", ["top", "inner1"]],
  ["N", ["top", "inner1"]],
])

// A proof witness only: these paths are never supplied to the solver.
export const clearLayerWitness = [
  { name: "P", layer: "inner1", path: [{ x: -4, y: -0.11 }, { x: 4, y: -0.11 }] },
  { name: "N", layer: "inner1", path: [{ x: -4, y: 0.11 }, { x: 4, y: 0.11 }] },
]
