from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, sys, time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
assert os.environ.get('G350_TIMEOUT_COMPARATOR_APPROVED') == '1'
packet = json.loads((ROOT / 'PREPARED.json').read_bytes())
spec = importlib.util.spec_from_file_location('comparator_owned_scope', packet['processScopePath'])
scope = importlib.util.module_from_spec(spec); spec.loader.exec_module(scope)

def environment_record():
    return {name: {'present': name in os.environ,
                  'valueSha256': hashlib.sha256(os.environ[name].encode()).hexdigest()
                  if name in os.environ else None}
            for name in packet['environmentNames']}

def cpu_record():
    path = Path('/sys/fs/cgroup/cpu.stat')
    return {name: int(value) for name, value in
            (line.split() for line in path.read_text().splitlines())} if path.is_file() else None

from log_parser import parse_log, parser_controls

controls = parser_controls(packet['parserActualLogs'])
(ROOT / 'run/parser-controls.json').write_text(json.dumps(controls, indent=2) + '\n')

environment = environment_record(); steps = []
for item in packet['stages']:
    assert environment_record() == environment
    assert not [p for p in scope.owned(os.getpgrp()) if p['pid'] != os.getpid()]
    log_path = ROOT / 'run' / (item['name'] + '-child.log')
    (ROOT / 'run/phase.json').write_text(json.dumps({'phase': item['name'], 'completed': steps}) + '\n')
    before_cpu = cpu_record(); started = time.monotonic()
    with log_path.open('wb') as output:
        child = subprocess.Popen(item['command'], cwd=item['sourceDirectory'],
                                 stdout=output, stderr=subprocess.STDOUT, shell=False)
        _, status, usage = os.wait4(child.pid, 0)
        child.returncode = os.waitstatus_to_exitcode(status)
    elapsed = time.monotonic() - started
    counts, cases = parse_log(log_path)
    row = {'name': item['name'], 'command': item['command'],
           'sourceDirectory': item['sourceDirectory'], 'exitCode': child.returncode,
           'wallSeconds': elapsed, 'userCpuSeconds': usage.ru_utime,
           'systemCpuSeconds': usage.ru_stime, 'peakChildRssBytes': usage.ru_maxrss * 1024,
           'minorFaults': usage.ru_minflt, 'majorFaults': usage.ru_majflt,
           'voluntaryContextSwitches': usage.ru_nvcsw,
           'involuntaryContextSwitches': usage.ru_nivcsw,
           'cgroupCpuBefore': before_cpu, 'cgroupCpuAfter': cpu_record(),
           'environmentPresenceAndHashes': environment, 'logPath': str(log_path),
           'logSha256': hashlib.sha256(log_path.read_bytes()).hexdigest(),
           'actualCounters': counts, 'cases': cases,
           'testsPassed': child.returncode == 0 and counts['pass'] == 9
                          and counts['fail'] == 0 and counts['tests'] == 9
                          and counts['files'] == 2 and len(cases) == 9}
    steps.append(row)
    (ROOT / 'run/steps.json').write_text(json.dumps(steps, indent=2) + '\n')
    print(json.dumps({'stage': row['name'], 'exitCode': row['exitCode'],
                      'wallSeconds': elapsed, 'actualCounters': counts,
                      'testsPassed': row['testsPassed']}), flush=True)
    assert not [p for p in scope.owned(os.getpgrp()) if p['pid'] != os.getpid()]
assert environment_record() == environment
(ROOT / 'run/result.json').write_text(json.dumps({
    'diagnosticStagesCompleted': len(steps) == 2, 'steps': steps,
    'parserControlsPassed': True, 'parserControls': controls,
    'oldTestsPassed': steps[0]['testsPassed'], 'newTestsPassed': steps[1]['testsPassed'],
    'wholeSuiteExecuted': False, 'allElevenBenchmarksExecuted': False,
    'accepted49': False, 'fabricationReady': False}, indent=2) + '\n')
# Diagnostic collection succeeds even when an original test reports failure.
# Each original child exit and timeout is retained above; no passing claim follows.
