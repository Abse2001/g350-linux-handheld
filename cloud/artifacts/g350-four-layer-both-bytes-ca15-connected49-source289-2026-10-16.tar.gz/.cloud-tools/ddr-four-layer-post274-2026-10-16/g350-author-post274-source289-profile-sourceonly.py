#!/usr/bin/env python3
"""SOURCE ONLY. Root-run own-stdlib public evidence catalog; no SDK/application import.
Writes only one fresh /tmp profile. Does not collect/stage workspace payloads.
"""
import argparse,hashlib,json,os,re,stat
from pathlib import Path
BOARD=Path('/workspace/g350-linux-handheld')
BASE=BOARD/'.cloud-tools/ddr-four-layer-post259-v2-2026-10-16'
CURRENT={
 'candidate':('/tmp/g350-source42-bottom-matching49-finite1g-root-20261016-run286/byte0-result.candidate.json','adf4821e147029e694dffe97f5894fe060e9607d9510867e20a9e9b7f6fd621e'),
 'plan':('/tmp/g350-both-bytes-ca15-matched49-projector-root-20261016-run287/byte0-result.json','373d1400453ebe44ea8ea0fc56b7f45be71f4720f60248d779c8cc8c224f045d'),
 'capture':('/tmp/g350-both-bytes-ca15-matched49-capture-root-20261016-run288/byte0-result.json','a1ddeb337c0974920fef34947bd76e44d563738a9b7745d623a898ba5a575edb'),
 'raw':('/tmp/g350-both-bytes-ca15-matched49-core289-raw.json','b7809be35568d45e117abf239edc290b2c379f9e02ec9427206798b0e60a567e'),
 'controls':('/tmp/g350-both-bytes-ca15-matched49-core-smol-root-20261016-run289/byte0-result.json','4a4df2d96e926d1a4770324875127d8b4d373bcb86ccf2d46477b6723ab08217'),
 'native16':('/tmp/g350-both-bytes-ca15-matched49-native-root-20261016-run290/byte0-result.json','30f0ab71705cef55d3bab9beef405603e4c735182b968826847b0fe269e5a877'),
 'auth':('/tmp/g350-both-bytes-ca15-matched49-via-track-root-20261016-run291/byte0-result.json','a0f291527001b6918310032ab72cb81880401e2487592fbc7854ae2e3d99b6ae'),
 'nativeComplement16':('/tmp/g350-both-bytes-ca15-matched49-native-complement-root-20261016-run294/byte0-result.json','e5654635f91360ef3bae93defcfeb608bc55727b770143b21609ab676e355599'),
 'native32Summary':('/tmp/g350-native32-source289-coverage-summary-root-20261016.json','96954fcb55f97959e4436954d722002668e2e428aeacda91f2dd1182353bff76')}
RUN_NAMES=['g350-ca12-retimed49-root-20261016-run275','g350-ca12-retimed49-finite1g-root-20261016-run276','g350-ca12-retimed49-finite1g-root-20261016-run277','g350-ca12-retimed49-curves-finite1g-root-20261016-run278','g350-both-bytes-ca12-matched49-projector-root-20261016-run279','g350-both-bytes-ca12-matched49-capture-root-20261016-run280','g350-both-bytes-ca12-matched49-core-smol-root-20261016-run281','g350-both-bytes-ca12-matched49-native-root-20261016-run282','g350-both-bytes-ca12-matched49-via-track-root-20261016-run283','g350-ca15-retimed49-finite1g-root-20261016-run284','g350-source272-kicad-export-root-20261016-run285','g350-source42-bottom-matching49-finite1g-root-20261016-run286','g350-both-bytes-ca15-matched49-projector-root-20261016-run287','g350-both-bytes-ca15-matched49-capture-root-20261016-run288','g350-both-bytes-ca15-matched49-core-smol-root-20261016-run289','g350-both-bytes-ca15-matched49-native-root-20261016-run290','g350-both-bytes-ca15-matched49-via-track-root-20261016-run291','g350-kicad10-proot-prereq-bounded-root-20261016-run292','g350-kicad10-single-rootfs-bounded-root-20261016-run293','g350-both-bytes-ca15-matched49-native-complement-root-20261016-run294']
DENIED=('ROOT_AUTHORITY','PRIVATE_CONTEXT','CONTEXT_BODY','BOUND_CONTEXT','AUTHORITY_PACKET')
def need(v,m):
 if not v:raise ValueError(m)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
  if hasattr(os,'posix_fadvise'):os.posix_fadvise(f.fileno(),0,0,os.POSIX_FADV_DONTNEED)
 return h.hexdigest()
def regular(p):return p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
def allowed(p):return (str(p).startswith('/tmp/g350-') and p.resolve().is_relative_to('/tmp')) or p.is_relative_to(BOARD/'dist/g350-source272-kicad49-root-20261016') or p.name=='ROOTFS.json' and p.parent==BOARD/'.cloud-tools/kicad10-single-rootfs-root-20261016'
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--output',type=Path,default=Path('/tmp/g350-post274-source289-checkpoint-profile-sourceonly.json'));args=a.parse_args()
 need(str(args.output).startswith('/tmp/g350-') and args.output.parent==Path('/tmp') and not args.output.exists(),'Fresh owned profile only')
 rows={};external={};runs=[];queue=[];base_refs={};catalog={}
 for name in ['ddr-four-layer-manual-2026-10-16','ddr-four-layer-post209-2026-10-16','ddr-four-layer-post232-2026-10-16','ddr-four-layer-post252-2026-10-16','ddr-four-layer-post259-v2-2026-10-16']:
  folder=BOARD/'.cloud-tools'/name;mf=json.loads((folder/'WORKSPACE_RESTORE_MANIFEST.json').read_bytes())
  for r in mf.get('baseDependencyRestoreFiles',[]):catalog[r['restorePath']]=r
  for r in mf['files']:catalog[r['restorePath']]={'baseSavedDirectory':folder.relative_to(BOARD).as_posix(),**r}
 def add(p,role,recursive=True):
  p=Path(p)
  if any(w in str(p).upper() for w in DENIED):return
  if not allowed(p) or not regular(p):return
  if p.stat().st_size>64*1024**2:
   external[str(p)]={'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p),'payloadCopied':False};return
  if str(p) in rows or str(p) in base_refs:return
  old=catalog.get(str(p))
  if old and old['bytes']==p.stat().st_size and old.get('mode',stat.S_IMODE(p.stat().st_mode))==stat.S_IMODE(p.stat().st_mode) and digest(p)==old['sha256']:
   base_refs[str(p)]=old;return
  rows[str(p)]={'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p),'mode':stat.S_IMODE(p.stat().st_mode),'role':role}
  if recursive and p.suffix in ('.json','.py','.ts','.tsx','.mjs','.sh'):queue.append(p)
 for key,(p,h) in CURRENT.items():need(regular(Path(p)) and digest(Path(p))==h,'Exact current '+key);add(p,'CURRENT_SOURCE289_'+key)
 for n,name in enumerate(RUN_NAMES,275):
  folder=Path('/tmp')/name;c=json.loads((folder/'COLLECTED.json').read_bytes());need(c['scope']==n and c.get('closedAt'),'Exact closed scope')
  execution=c.get('execution')
  if execution is None and (folder/'owned/execution.json').is_file():execution=json.loads((folder/'owned/execution.json').read_bytes())
  runs.append({'scope':n,'folder':str(folder),'exitCode':execution.get('exitCode') if execution else None,'executionWasNullInClosure':c.get('execution') is None})
  for p in folder.iterdir():
   if regular(p) and (p.name=='COLLECTED.json' or p.name.startswith('byte0-result') and p.suffix=='.json'):add(p,'CLOSED_SCOPE_'+str(n))
  for rel in ('owned/child.log','owned/execution.json','owned/memory.jsonl'):
   p=folder/rel
   if regular(p):add(p,'CLOSED_SCOPE_'+str(n)+'_PUBLIC_OWNED_RECEIPT')
  if execution:
   for v in execution.get('command',[]):
    if isinstance(v,str) and v.startswith('/'):add(v,'ACTUAL_RECORDED_COMMAND_ARGUMENT')
 def scan(d):
  if isinstance(d,dict):
   if isinstance(d.get('path'),str) and d['path'].startswith('/') and ('sha256' in d or 'bytes' in d):add(d['path'],'PINNED_PUBLIC_DATA_REFERENCE')
   for k,v in d.items():
    if k in ('inputBindings','candidatePath','rawCorePath','planPath','actualCapturePath','exportOutput','originalRawByteIdenticalCopy','exportRepresentation','expectedCatalog','prootExecutable','runtimeLibraries','packages','probe','imageArchive'):
     if isinstance(v,str) and v.startswith('/'):add(v,'PUBLIC_DECLARED_INPUT_OR_OUTPUT')
     else:scan(v)
    elif k not in ('entries','links','finalScenePhysicalReports','physicalRunReports','newViaReports','circuitJson','rawCircuitJson'):scan(v)
  elif isinstance(d,list):
   for v in d:scan(v)
 while queue:
  p=queue.pop(0)
  if p.suffix=='.json':
   try:scan(json.loads(p.read_bytes()))
   except (json.JSONDecodeError,UnicodeDecodeError):pass
  else:
   text=p.read_text()
   for name in re.findall(r'/tmp/g350-[A-Za-z0-9_./+\-]+',text):
    q=Path(name.rstrip('.'));add(q,'LITERAL_PUBLIC_SOURCE_REFERENCE')
 for p in [Path('/tmp/g350-kicad10-proot-prereq-root-20261016/PROBE.json'),BOARD/'.cloud-tools/kicad10-single-rootfs-root-20261016/ROOTFS.json']:
  add(p,'SEPARATE_ROOTFS_TOOLING_PREREQUISITE_NOT_CAD',False)
  d=json.loads(p.read_bytes());scan({k:d[k] for k in ('probe','prootExecutable','runtimeLibraries','packages') if k in d})
 for p in [Path('/tmp/g350-source272-stock-cli-export-bounded-root-sourceonly.py'),Path('/tmp/g350-reviewed-python-utility-bounded-root-20261016.py')]:add(p,'REVIEWED_OPERATIONAL_GUARD_SOURCE',False)
 profile={'scope':'POST274_SOURCE289_CONNECTED49_BOTH_BYTES_PASS_CA15_OF26_NO_CURRENT_POUR_OR_CAD_PASS_PROFILE',
 'latestClosedScopeIncluded':294,'frozenCheckpointIntended':True,'current':{k:{'path':p,'sha256':h} for k,(p,h) in CURRENT.items()},'runs':runs,
 'artifacts':sorted(rows.values(),key=lambda r:r['path']),'baseDependencyReferences':list(base_refs.values()),'externalLargeToolInputs':list(external.values()),
 'plannedCopiedArtifactBytes':sum(r['bytes'] for r in rows.values()),'plannedArtifactCount':len(rows),
 'workspaceEvidencePathsNotLegacyTmpRestoreTargets':[r['path'] for r in rows.values() if r['path'].startswith('/workspace/')],
 'source289CurrentPoursQualified':False,'source272PoursNotInherited':True,'source272CadExportIndependent':True,
 'source289Native32CompletedWith951Findings':True,'all49Accepted':False,'fabricationReady':False}
 with args.output.open('x') as f:json.dump(profile,f,indent=2,allow_nan=False);f.write('\n');os.fchmod(f.fileno(),0o600)
 print(json.dumps({'profile':str(args.output),'sha256':digest(args.output),'artifacts':len(rows),'closedScopes':len(runs),'payloadsStaged':False,'sdkExecuted':False}))
if __name__=='__main__':main()
