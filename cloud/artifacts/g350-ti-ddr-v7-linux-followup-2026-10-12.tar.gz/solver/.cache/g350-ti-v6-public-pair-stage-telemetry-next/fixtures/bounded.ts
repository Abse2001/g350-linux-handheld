export const boundedExtra = Symbol("bounded original export")
// Exact original algorithm, operating only on supplied fake generators.
export function* runBoundedRouting<T>(
  generator: Generator<unknown, T>,
  limit: number,
): Generator<void, T | null> {
  let state = generator.next()
  let steps = 0
  try {
    while (!state.done && steps++ < limit) {
      yield
      state = generator.next()
    }
    return state.done ? state.value : null
  } finally {
    if (!state.done) generator.return(null as T)
  }
}
