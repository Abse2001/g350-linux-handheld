Source313 scoped pour evidence: all19 actual pours/234 vias/5623 routed segments/49 signal owners PASS foreign .1016mm edge margin.
Whole bounded325 report is retained:16 completed pours,93 partial with0 checks,98/99 not started.
Whole326 retry completes93/98/99; exact327 aggregate excludes only the bounded partial rows.
No own-net reentry, reference-wire, PDN island continuity, TI, whole-board, CAD or fabrication qualification.
Base is editable Source313 with220 targets, not the separate Model318 branch.
Restore209→228→248→257→272-v2→289→Model299→Source313 before this increment.
Collection and archive smoke execute stdlib/restoration only; no SDK or geometry helpers.
