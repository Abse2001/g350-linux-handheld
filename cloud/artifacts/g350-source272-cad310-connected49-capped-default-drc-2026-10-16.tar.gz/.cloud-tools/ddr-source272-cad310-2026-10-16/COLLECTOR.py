#!/usr/bin/env python3
"""Root-run stdlib evidence collection only; no SDK, KiCad, archive or repo writes.

The new tmp snapshot is a portable-evidence input, not a runnable rootfs. Its
workspace CAD copies are data-only. Source289 and its five base archives remain
read-only dependencies; no Source289/Model299 CAD qualification is inherited.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat

BOARD = Path('/workspace/g350-linux-handheld')
STAGE = BOARD / 'dist/g350-source272-kicad49-root-20261016'
PROFILE = Path('/tmp/g350-source272-cad310-evidence-profile-sourceonly.json')
PROFILE_SHA = '55ab397949627f989cecc429c9cb5e8e7e224e0717e360ae1c9842a153b8ab02'
SAVED = Path('/tmp/g350-source272-cad310-checkpoint-20261016')
SAVED_REL = '.cloud-tools/ddr-source272-cad310-2026-10-16'
BASE = Path('/tmp/g350-source289-post274-checkpoint-20261016')
BASE_REL = '.cloud-tools/ddr-four-layer-post274-2026-10-16'
BASE_STEM = 'g350-four-layer-both-bytes-ca15-connected49-source289-2026-10-16'
FALSE = dict(all49Accepted=False, fullBoardPassed=False, fullTimingPassed=False,
             electricalTimingQualified=False, tiQualified=False,
             referenceContinuityQualified=False, cadManufacturingQualified=False,
             defaultBoardPromoted=False, fabricationReady=False)

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
        if hasattr(os, 'posix_fadvise'):
            os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return h.hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def metadata(path):
    s = path.lstat()
    need(stat.S_ISREG(s.st_mode) and not path.is_symlink(), 'Regular file only: ' + str(path))
    return dict(bytes=s.st_size, sha256=sha(path), mode=stat.S_IMODE(s.st_mode))

def exact(path, row):
    need(metadata(path) == {k: row[k] for k in ('bytes', 'sha256', 'mode')}, 'Exact input: ' + str(path))

def relative(value):
    p = PurePosixPath(value)
    need(not p.is_absolute() and p.parts and '..' not in p.parts and str(p) == value
         and '\\' not in value and not any(s in value.upper() for s in
         ('ROOT_AUTHORITY', 'PRIVATE_CONTEXT', 'BOUND_CONTEXT', 'CONTEXT_BODY')), 'Public canonical relative path')
    return Path(*p.parts)

def write(path, value):
    with path.open('x') as f:
        os.fchmod(f.fileno(), 0o600)
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source289-archive-sha', required=True)
    ap.add_argument('--source289-manifest-sha', required=True)
    args = ap.parse_args()
    need(not SAVED.exists() and not SAVED.is_symlink(), 'Fresh tmp snapshot only')
    for h in (args.source289_archive_sha, args.source289_manifest_sha):
        need(len(h) == 64 and all(c in '0123456789abcdef' for c in h), 'Explicit actual base SHA256')
    archive = BOARD / ('cloud/artifacts/' + BASE_STEM + '.tar.gz')
    manifest = archive.with_name(BASE_STEM + '.manifest.json')
    need(sha(PROFILE) == PROFILE_SHA and sha(archive) == args.source289_archive_sha
         and sha(manifest) == args.source289_manifest_sha, 'Pinned profile and published Source289 base')
    profile, base_archive = read(PROFILE), read(manifest)
    need(profile['scope'] == 'SOURCE_ONLY_SOURCE272_CAD310_COMPACT_EVIDENCE_PROFILE_DEFAULT_DRC_CAPPED_NOT_BOARD_QUALIFICATION'
         and len(profile['artifacts']) == profile['artifactCount'] == 58
         and profile['canonicalSavedDirectory'] == SAVED_REL
         and profile['tmpStagingDirectory'] == str(SAVED), 'Exact compact public roster')
    need(base_archive['scope'] == 'PORTABLE_POST274_BOTH_BYTES_CA15_CONNECTED49_SOURCE289_SOURCE_AND_DATA'
         and base_archive['archive']['sha256'] == args.source289_archive_sha
         and base_archive['archive']['bytes'] == archive.stat().st_size
         and len(base_archive['files']) == 156, 'Exact Source289 portable base')
    for member in base_archive['files']:
        prefix = BASE_REL + '/'
        need(member['path'].startswith(prefix), 'Source289 base member containment')
        exact(BASE / relative(member['path'][len(prefix):]), member)
    base_restore = read(BASE / 'WORKSPACE_RESTORE_MANIFEST.json')
    need(base_restore['solverSourceRoot'] == '/tmp/g350-c30-abort-doomed-escape-order-sourceonly-next/lib', 'Pinned solver import root')
    base_targets = base_restore['files'] + base_restore['baseDependencyRestoreFiles']
    need(len(base_targets) == len({r['restorePath'] for r in base_targets}) == 167, 'Exact base167 public targets')
    for r in base_targets:
        exact(Path(r['restorePath']), r)
    for r in profile['artifacts']:
        need(r['path'].startswith('/tmp/g350-') or Path(r['path']).parent == STAGE, 'No extra filesystem payload')
        relative(r['savedPath'])
        need(Path(r['savedPath']).name == r['savedPath'], 'Flat unique evidence member')
        exact(Path(r['path']), r)
    need(len({r['path'] for r in profile['artifacts']}) == 58
         and len({r['savedPath'] for r in profile['artifacts']}) == 58, 'No duplicate evidence')
    stage_rows = [r for r in profile['artifacts'] if r['workspaceDataOnly']]
    need(len(stage_rows) == 10 and {p.name for p in STAGE.iterdir()} == {Path(r['path']).name for r in stage_rows}, 'All and only current10 CAD-stage files')
    current = read(STAGE / 'SOURCE272_KICAD49_READ_ONLY_V3_FLAGS_REPORT.json')
    drc = read(STAGE / 'source272-full-unfiltered-drc.json')
    need(current['complete'] is True and current['scoped49GeometryAndConnectivityPassed'] is True
         and current['allInputsUnchanged'] is True and current['failures'] == []
         and current['fullUnfilteredDrc'] == drc and current['drcExitCode'] == 5, 'Actual310 complete connectivity with all returned303 DRC data')
    signals = current['signalResults']
    need(len(signals) == 49 and {r['originalSourceTraceId'] for r in signals} == {'source_trace_' + str(i) for i in range(49)}
         and all(all(r[k] is True for k in ('ownedNumericGraphConnected', 'nativeNumericPadToPadConnected',
             'everyOwnedGraphNodeConnected', 'everyOwnedItemNativeConnected')) for r in signals), 'All49 current independent/native/owned-item gates')
    need(current['nativeConnectivityApi']['flags'] == 0 and current['nativeConnectivityApi']['ignoreNetsEnabled'] is False
         and all(r['nativeTraversal']['apiFlags'] == 0 and r['nativeTraversal']['nativeNetCodeAndNameChecked'] is True
                 and r['nativeTraversal']['foreignItemsTraversed'] is False for r in signals), 'Actual KiCad10 flags0 and manual ownership filters')
    need(len(drc['violations']) == 2102 and len(drc['unconnected_items']) == 499
         and {r['key'] for r in drc['ignored_checks']} == set(profile['defaultDrc']['defaultIgnoredChecks']), 'Retained capped default DRC observations')
    for scope, directory, code in ((301, 'g350-source272-kicad-api-privatecache-root-20261016-run301', 0),
            (303, 'g350-source272-kicad-full-drc-prl-root-20261016-run303', 5),
            (304, 'g350-source272-kicad49-readonly-root-20261016-run304', 0),
            (310, 'g350-source272-kicad49-flags-readonly-root-20261016-run310', 0)):
        receipt = read(Path('/tmp') / directory / 'COLLECTED.json')
        need(receipt['scope'] == scope and receipt['execution']['exitCode'] == code
             and receipt['hostOwnedGroupEmpty'] is True and receipt['sourcePinsUnchanged'] is True
             and receipt['rootfsImageFileAndLinkMaterialUnchanged'] is True and receipt['errors'] == [], 'Exact closed operational evidence ' + str(scope))
    negative = read(STAGE / 'SOURCE272_KICAD49_READ_ONLY_REPORT.json')
    need(negative['complete'] is False and negative['scoped49GeometryAndConnectivityPassed'] is False
         and len(negative['failures']) == 1
         and negative['failures'][0]['type'] == 'TypeError', 'Failed304 API mismatch preserved')
    negative_receipt = read(Path('/tmp/g350-source272-kicad49-readonly-root-20261016-run304/COLLECTED.json'))
    need(negative_receipt['execution']['exitCode'] == negative_receipt['actualKiCadExitCode'] == 0,
         'Recorded304 zero process status is retained separately from semantic report failure')
    repair = read(Path('/tmp/g350-kicad10-fontcache-repair-root-20261016/REPAIR.json'))
    need(repair['passed'] is True and repair['everyBaselineCacheFileRestoredFromPinnedImage'] is True
         and repair['allNoncacheFileAndLinkMaterialExact'] is True
         and repair['afterAudit']['imageMaterialExactlyMatchesOriginal'] is True
         and repair['afterAudit']['expectedRegularFilesChecked'] == 18238
         and repair['afterAudit']['expectedLinksChecked'] == 2115 and repair['afterAudit']['changes'] == [], 'Exact frozen-cache recovery record')
    extras = [dict(path=str(PROFILE), savedPath='PROFILE.json', **metadata(PROFILE)),
              dict(path=str(Path(__file__).resolve()), savedPath='COLLECTOR.py', **metadata(Path(__file__).resolve()))]
    payload = profile['artifacts'] + extras
    size = sum(r['bytes'] for r in payload)
    need(size < 64 * 1024**2 and shutil.disk_usage('/tmp').free > size + 1024**3, 'Bounded tmp payload plus1GiB reserve')
    need(int(Path('/sys/fs/cgroup/memory.current').read_text()) + size + 1024**3 < 30 * 1024**3, 'Shared30GiB/+1GiB reserve')
    SAVED.mkdir(mode=0o700)
    local, workspace = [], []
    for r in payload:
        source, target = Path(r['path']), SAVED / relative(r['savedPath'])
        with source.open('rb') as f, target.open('xb') as g:
            shutil.copyfileobj(f, g, 1048576)
            os.fchmod(g.fileno(), r['mode'])
        exact(source, r); exact(target, r)
        row = dict(restorePath=str(source), savedPath=r['savedPath'], **{k: r[k] for k in ('bytes', 'sha256', 'mode')})
        if r.get('workspaceDataOnly', False):
            workspace.append(dict(**row, dataOnlyEvidenceCopy=True, legacyWorkspaceHelperRestoresThisFile=False))
        else:
            need(str(source).startswith('/tmp/g350-'), 'Legacy restore limited to public tmp evidence')
            local.append(row)
    own_paths = {r['restorePath'] for r in local}
    inherited = []
    for r in base_targets:
        if r['restorePath'] in own_paths:
            need(all(r[k] == next(q for q in local if q['restorePath'] == r['restorePath'])[k]
                     for k in ('bytes', 'sha256', 'mode')), 'No conflicting inherited restore target')
        else:
            inherited.append({'baseSavedDirectory': BASE_REL, **r})
    dependency = dict(**base_archive['archive'], manifest=manifest.relative_to(BOARD).as_posix(),
                      manifestSha256=args.source289_manifest_sha, mustBeRestoredFirst=True, payloadCopiedByThisCollector=False)
    dependencies = base_archive['baseArchiveDependenciesInRestoreOrder'] + [dependency]
    common = dict(scope='SOURCE272_CAD310_SCOPED49_CONNECTIVITY_DEFAULT_CAPPED_DRC_EVIDENCE_ONLY',
        frozenCheckpoint=True, canonicalArchiveSavedDirectory=SAVED_REL, actualTmpStagingDirectory=str(SAVED),
        workspaceCheckpointFolderCreated=False, sourceCoreScope=272, latestCadScope=310,
        scoped49CadConnectivityPassed=True, currentCadGeometryBelongsOnlyToSource272=True,
        negative304Evidence=dict(recordedProcessExitCode=0, recordedKiCadExitCode=0,
            semanticReportComplete=False, scoped49GeometryAndConnectivityPassed=False,
            reportFailureType='TypeError', zeroExitIsNotSemanticQualification=True),
        source289AndModel299CadQualificationInherited=False, reportedDrcViolations=2102, reportedDrcOpens=499,
        drcFindingCountsAreExhaustive=False, defaultIgnoredChecks=profile['defaultDrc']['defaultIgnoredChecks'],
        authenticatedSourceToCadProjectRulesPresent=False, hugeRootfsOrImagePayloadsIncluded=False,
        runtimePreparationRequiredForReexecution=True, baseArchiveDependency=dependency,
        baseArchiveDependenciesInRestoreOrder=dependencies, **FALSE)
    write(SAVED / 'WORKSPACE_RESTORE_MANIFEST.json', dict(**common, solverSourceRoot=base_restore['solverSourceRoot'],
        files=local, baseDependencyRestoreFiles=inherited, workspaceEvidenceCopies=workspace,
        immutableWorkspaceAssets=[], sdkExecuted=False))
    write(SAVED / 'PROGRESS.json', dict(**common, workspaceDataOnlyCopies=len(workspace), localRestoreTargets=len(local),
        baseRestoreReferences=len(inherited), plannedPayloadBytes=size, laterSource311PlusQualificationInherited=False))
    with (SAVED / 'README.md').open('x') as f:
        os.fchmod(f.fileno(), 0o600)
        f.write('Source272 CAD310:49 numeric signal graphs and exact geometry PASS.\n'
                'Default KiCad DRC returned2102 violations+499 opens under per-code caps; five checks ignored by defaults.\n'
                'All returned findings and failed304 are retained. No fullboard/TI/timing/fabrication pass.\n'
                'The304 receipt records exit0, but its incomplete checker report records TypeError; exit0 is not semantic qualification.\n'
                'Restore exact209→228→248→257→272-v2→289 archives first. This is a separate data increment.\n'
                'Workspace CAD copies are data-only and are never restored by the legacy helper.\n'
                'The huge rootfs/image is excluded; runtime recreation and any new CAD execution require a separate Root operation.\n')
    index = [dict(path=p.name, **metadata(p)) for p in sorted(SAVED.iterdir())]
    write(SAVED / 'WORKSPACE_HASH_INDEX.json', dict(scope=common['scope'], frozenCheckpoint=True, files=index, selfExcluded=True))
    for r in profile['artifacts']:
        exact(Path(r['path']), r)
    need(sha(PROFILE) == PROFILE_SHA and sha(archive) == args.source289_archive_sha
         and sha(manifest) == args.source289_manifest_sha, 'All inputs unchanged')
    for member in base_archive['files']:
        exact(BASE / relative(member['path'][len(BASE_REL) + 1:]), member)
    for r in base_targets:
        exact(Path(r['restorePath']), r)
    print(json.dumps(dict(saved=str(SAVED), members=len(index) + 1, localRestoreTargets=len(local),
        baseRestoreReferences=len(inherited), workspaceDataOnlyCopies=len(workspace), payloadBytes=size,
        sdkExecuted=False, archiveCreated=False, repositoryFilesWritten=False, **FALSE)))

if __name__ == '__main__':
    main()
