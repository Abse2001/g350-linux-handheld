#!/usr/bin/env python3
"""Combine exact Source236 completed14 + completed94 only; no geometry/SDK execution."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path

RAW_SHA = 'd49c3d6f8661527cf007d3676d6cdae7f9fcec99535373997c6adda8705dc18d'
CONTROLS_SHA = 'b618de34ab2c681f53f9422cd06916471db95fda97772e16754a814541546563'
AUTH_SHA = '05ef57bc48db7d5cb2bcc012fa584143d037fdecbf1f6fb55d89be57da0f9997'
PARTIAL_SHA = '0e2f67dc304884dd334001464303e6e2155665f119df9c8909d2b38f691745ab'
V1_SOURCE_SHA = '489d58532a46ced3aba011e4e571c2b0c3dbb31bc0d504357002addf3739939c'
V2_SOURCE_SHA = 'ffec7460e2ded1ce8b4a71c49481f292b362397cdab449e3ba92490c8c92b979'
MISSING_POURS = {'pcb_copper_pour_94'}
ACTUAL_POUR_IDS = ['pcb_copper_pour_' + str(i) for i in (0, 22, 23, 30, 37, 38, 39, 48, 71, 74, 80, 81, 83, 87, 94)]
PLAN_PATH = '/tmp/g350-ca-merged47-projector-root-20261016-run234/byte0-result.json'
PLAN_SHA = '0e3757ae6e367158090a2f14dbaf20f9f57422576d89ee2ca1acfa6c77ef1707'
CANDIDATE_SHA = '71bbec7babdeabda657ba1b2be75d35f5d7210d5a53d55cd2fc2b279ffb0d17b'
SUBSET_SHA = '0f6d3eb46af29e0eeccea14ce138e75a3db98ad17220653b60f392008f470aa9'
AUDIT_SOURCE_SHA = '68d33314f2a984e1c260d4f2bca7b04eb9b7370135a5ff1befd354b1604878d5'
PENDING = {'source_trace_26', 'source_trace_30'}
LAYERS, EPS, REQUIRED = ['top', 'inner1', 'inner2', 'bottom'], 1e-8, .1016

def require(condition, message):
    if not condition:
        raise ValueError(message)

def pin(path, expected):
    require(len(expected) == 64 and all(c in '0123456789abcdef' for c in expected), 'Explicit lowercase SHA256 required')
    with path.open('rb') as f:
        data = f.read()
        require(hashlib.sha256(data).hexdigest() == expected, 'Input hash mismatch: ' + str(path))
        value = json.loads(data)
        os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    return value

def index(rows, key):
    result = {}
    for row in rows:
        value = row.get(key)
        require(isinstance(value, str) and value not in result, 'Unique ' + key + ' required')
        result[value] = row
    return result

def numeric(value):
    return type(value) in (int, float) and math.isfinite(value)

def close(a, b):
    return numeric(a) and numeric(b) and abs(a - b) <= EPS

def xy(row):
    require(numeric(row.get('x')) and numeric(row.get('y')), 'Finite XY required')
    return [row['x'], row['y']]

class Uf:
    def __init__(self):
        self.parent = {}
    def add(self, value):
        self.parent.setdefault(value, value)
    def root(self, value):
        if value not in self.parent:
            return None
        if self.parent[value] != value:
            self.parent[value] = self.root(self.parent[value])
        return self.parent[value]
    def union(self, a, b):
        self.add(a); self.add(b)
        self.parent[self.root(b)] = self.root(a)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('input', 'controls', 'auth', 'partial', 'subset', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    for key in ('input-sha', 'controls-sha', 'auth-sha', 'partial-sha', 'subset-sha'):
        parser.add_argument('--' + key, required=True)
    parser.add_argument('--plan', type=Path, default=Path(PLAN_PATH))
    parser.add_argument('--plan-sha', default=PLAN_SHA)
    args = parser.parse_args()
    expected = {'input': RAW_SHA, 'controls': CONTROLS_SHA, 'auth': AUTH_SHA, 'partial': PARTIAL_SHA, 'subset': SUBSET_SHA, 'plan': PLAN_SHA}
    for name, digest in expected.items():
        require(getattr(args, name + '_sha') == digest, 'Exact Source236/238/completed-report/plan234 pin required: ' + name)
    require(not args.output.exists() and args.output.resolve() not in
            {getattr(args, name).resolve() for name in ('input', 'controls', 'auth', 'partial', 'subset', 'plan')}, 'Fresh separate output required')
    raw, controls, auth, partial, subset = [pin(getattr(args, name), getattr(args, name + '_sha'))
                                            for name in ('input', 'controls', 'auth', 'partial', 'subset')]
    plan = pin(args.plan, args.plan_sha)
    require(plan.get('inputBindings', {}).get('candidate', {}).get('sha256') == CANDIDATE_SHA and
            len(plan.get('newVias', [])) == 98 and len(plan.get('innerPortRegistrations', [])) == 82 and
            len(plan.get('auxiliaryLocalTraces', [])) == 4 and len(plan.get('projectedGeometry', [])) == 47 and
            len(plan.get('replacedOriginals', [])) == 49, 'Exact reviewed merged plan234 inventory and candidate233 binding required')
    require(isinstance(raw, list) and controls.get('rawCoreSha256') == RAW_SHA and
            controls.get('partialDiagnosticReplayControlsPassed') is True and controls.get('partialCoreControlPassed') is True and
            controls.get('planSha256') == PLAN_SHA and
            len(controls.get('checks', [])) == 35 and all(v.get('passed') is True for v in controls['checks']), 'All35 exact fresh Core controls required')
    routed = set(controls.get('routedOwnerIds', []))
    require(len(routed) == 47 and set(controls.get('pendingOwnerIds', [])) == PENDING and
            routed | PENDING == {'source_trace_' + str(i) for i in range(49)}, 'Exact47/2 graph partition required')
    graphs = index(controls.get('physicalGraphs', []), 'originalSourceTraceId')
    require(set(graphs) == routed | PENDING and all(graphs[s].get('physicallyConnectedByActualOwnedNumericIdGraph') is (s in routed)
            for s in graphs) and set(plan.get('routedOwnerIds', [])) == routed and set(plan.get('pendingOwnerIds', [])) == PENDING,
            'Exact49 current physical graphs and plan47/pending2 partition required')
    expected_counts = controls.get('expectedCounts', {})
    require(all(expected_counts.get(k) == v for k, v in {'newVias': 98, 'newInnerPorts': 82, 'auxiliaryLocalTraces': 4,
            'physicalVias': 227, 'routedOwners': 47, 'pendingOwners': 2, 'routedWireRuns': 141, 'physicalTraces': 310}.items()),
            'Exact current47 plan/Core counts required')
    require(auth.get('scope') == 'EXPLICITLY_PINNED_M47_PLAN234_MERGED_CA_AUTHENTICATED_227_MANUAL_VIA_TRACK_MANUFACTURING_DIAGNOSTIC' and
            auth.get('inputBindings', {}).get('plan', {}).get('sha256') == PLAN_SHA and
            auth.get('inputBindings', {}).get('mergedCandidate', {}).get('sha256') == CANDIDATE_SHA, 'Exact auth238 plan/candidate policy required')
    require(auth.get('complete') is True and auth.get('actualViaCount') == 227 and
            auth.get('completedViaCount') == 227 and auth.get('foreignViaTrackCopperClearancePassed') is True and
            auth.get('exactInputFilesUnchanged') is True and auth.get('requiredCopperEdgeClearanceMm') == REQUIRED,
            'Completed exact227 current ownership/foreign-track report required')
    for key in ('violations', 'ambiguousVias', 'identityFailures', 'invalidSegments', 'unresolvedSegmentOwners'):
        require(auth.get(key) == [], 'Authenticated ownership report retains failures: ' + key)
    require(auth['inputBindings']['raw']['sha256'] == RAW_SHA and
            auth['inputBindings']['controls']['sha256'] == CONTROLS_SHA, 'Auth input binding mismatch')
    rows = lambda kind: [r for r in raw if r.get('type') == kind]
    pours, vias = index(rows('pcb_copper_pour'), 'pcb_copper_pour_id'), index(rows('pcb_via'), 'pcb_via_id')
    require(list(pours) == ACTUAL_POUR_IDS and len(vias) == 227, 'Exact15 pours/227 vias required')
    sources = rows('source_trace')
    declarations = [{'sourceTraceId': r['source_trace_id'], 'connectedSourcePortIds': r.get('connected_source_port_ids', []),
                     'connectedSourceNetIds': r.get('connected_source_net_ids', [])} for r in sources]
    require(auth.get('declaredLogicalSources') == declarations, 'Exact actual Source-only declarations required')
    uf = Uf()
    for row in declarations:
        sid = row['sourceTraceId']; uf.add(sid)
        for value in row['connectedSourcePortIds'] + row['connectedSourceNetIds']:
            uf.union(sid, value)
    via_proofs = index(auth['viaReports'], 'pcbViaId')
    require(set(via_proofs) == set(vias), 'Exact via proof roster required')
    via_roots = {}
    for vid, proof in via_proofs.items():
        require(proof.get('aliasIdentityAuthenticated') is True and proof.get('logicalOwnerResolved') is True and
                proof.get('identityErrors') == [] and proof.get('unresolvedOwnerEvidence') == [] and
                len(proof.get('authenticatedLogicalRoots', [])) == 1 and
                proof.get('selectedLogicalRoot') in proof['authenticatedLogicalRoots'] and proof.get('violationCount') == 0,
                'Unresolved via identity: ' + vid)
        via_roots[vid] = proof['selectedLogicalRoot']
    projection = {r['actualSourceTraceId']: r['originalSourceTraceId'] for r in controls['logical49Projection']
                  if r['originalSourceTraceId'] in routed}
    wire_catalog = {}
    for trace in rows('pcb_trace'):
        sid = trace.get('source_trace_id')
        if sid not in projection:
            continue
        route = trace['route']
        for i, (a, b) in enumerate(zip(route, route[1:]), 1):
            if a.get('route_type') != 'wire' or b.get('route_type') != 'wire' or a.get('layer') != b.get('layer'):
                continue
            pa, pb = xy(a), xy(b)
            if math.dist(pa, pb) <= EPS:
                continue
            widths = [a.get('width'), b.get('width'), a.get('end_width', 0), b.get('end_width', 0)]
            require(a['layer'] in LAYERS and all(numeric(v) for v in widths) and max(widths) > 0, 'Unsupported current wire')
            key = trace['pcb_trace_id'] + ':' + str(i)
            require(key not in wire_catalog, 'Duplicate current wire identity')
            wire_catalog[key] = {'pcbTraceId': trace['pcb_trace_id'], 'actualSourceTraceId': sid,
                'originalOwner': projection[sid], 'segmentStartIndex': i - 1, 'segmentEndIndex': i,
                'a': pa, 'b': pb, 'layer': a['layer'], 'radius': max(widths) / 2, 'root': uf.root(sid)}
    require(len(wire_catalog) == 7456, 'Exact7456 real Source236 routed-wire segments required')
    bindings = {'raw': RAW_SHA, 'controls': CONTROLS_SHA, 'current227Ownership': AUTH_SHA, 'reviewedSourcePlan234': PLAN_SHA}
    for report in (partial, subset):
        require(all(report.get('inputBindings', {}).get(k, {}).get('sha256') == v for k, v in bindings.items()), 'Same exact raw/controls/auth required')
        require(report.get('inputFilesUnchanged') is True and report.get('wireScope') == 'all-routed' and
                set(report.get('wireOriginalOwners', [])) == routed and len(report.get('wireOriginalOwners', [])) == 47 and
                report.get('wireSegmentCount') == 7456 and report.get('actualViaCount') == 227 and
                report.get('requiredForeignViaPourEdgeMm') == REQUIRED and report.get('requiredForeignWirePourEdgeMm') == REQUIRED and
                report.get('coordinateToleranceMm') == EPS and report.get('sourceRuleBridge') == controls.get('sourceRuleBridge'),
                'Identical geometry scope/limits/Source bridge required')
        for key in ('globalIdentityFailures', 'viaIdentityFailures', 'unsupportedGeometry', 'unknownPourIdentities', 'violations'):
            require(report.get(key) == [], 'Report retains failures: ' + key)
        require(len(report.get('actualViaIdentities', [])) == 227 and
                all(v.get('failures') == [] for v in report['actualViaIdentities']), 'Complete unambiguous via identities required')
        require(all(report.get(k) is False for k in ('all49Accepted', 'full49Accepted', 'fullBoardPassed',
                'electricalTimingQualified', 'nativeExecuted', 'cadExecuted', 'fabricationReady')), 'Scope boundary flags must remain false')
    expected_roster = [{'pcbCopperPourId': r['pcb_copper_pour_id'], 'layer': r.get('layer'),
                        'sourceNetId': r.get('source_net_id'), 'shape': r.get('shape')} for r in pours.values()]
    for report in (partial, subset):
        require(report.get('scope') == 'PARTIAL47_SOURCE236_LITERAL_SELECTED_FRESH_BREP_POUR_MARGIN_DIAGNOSTIC' and
                report.get('originalAuditSourceSha256') == V1_SOURCE_SHA and report.get('selectedAuditV2SourceSha256') == V2_SOURCE_SHA and
                report.get('auditSourceSha256') == AUDIT_SOURCE_SHA and report.get('actualRawPourIds') == list(pours) and
                report.get('actualRawPourRoster') == expected_roster and report.get('allActualPoursCompleted') is False,
                'Exact same reviewed Source236 audit and literal15 roster required')
    require(partial.get('coverageScope') == 'EXPLICIT_ALL15_ACTUAL_POURS' and partial.get('selectedPourIds') == list(pours) and
            partial.get('omittedPourIds') == [] and partial.get('completed') is False and
            partial.get('literalForeignPourMarginClear') is False,
            'Retain bounded Source236 all15 audit status; it is not a whole pass')
    require(subset.get('coverageScope') == 'EXPLICIT_SELECTED_POURS_ONLY' and subset.get('completed') is True and
            subset.get('literalForeignPourMarginClear') is True and subset.get('selectedPourIds') == ['pcb_copper_pour_94'] and
            set(subset.get('omittedPourIds', [])) == set(pours) - MISSING_POURS and len(subset['omittedPourIds']) == 14,
            'Exact separate completed selected94 result required')
    require(partial['actualViaIdentities'] == subset['actualViaIdentities'] and
            partial['distanceModel'] == subset['distanceModel'] and partial['netExemptionPolicy'] == subset['netExemptionPolicy'],
            'Identical actual identities and geometry/exemption algorithm required')
    identity_rows = index(partial['actualViaIdentities'], 'pcbViaId')
    require(set(identity_rows) == set(vias), 'Identity roster mismatch')
    for vid, v in identity_rows.items():
        require(v['logicalRoot'] == via_roots[vid] and v['xy'] == xy(vias[vid]) and set(v['layers']) == set(LAYERS), 'Actual via identity mismatch')
    completed, excluded = {}, []
    for label, report in (('bounded236', partial), ('selected94', subset)):
        reports = index(report['pourReports'], 'pcbCopperPourId')
        exemptions = report['sameNetExemptions']
        for pid, pr in reports.items():
            require(pid in pours, 'Unknown reported pour')
            if pr.get('state') != 'COMPLETED':
                require(label == 'bounded236' and pid == 'pcb_copper_pour_94' and pr['state'] == 'BOUNDED_PARTIAL', 'Only actual bounded Source236 partial94 may be excluded')
                excluded.append({'report': label, 'pcbCopperPourId': pid, 'state': pr['state'],
                                 'viaChecksExcluded': len(pr['viaChecks']), 'wireChecksExcluded': len(pr['wireChecks'])})
                continue
            require(pid not in completed, 'Duplicate completed pour coverage')
            pour = pours[pid]; root = uf.root(pour['source_net_id']); layer = pour['layer']
            require(root is not None and pour['shape'] == 'brep' and pr['layer'] == layer and
                    pr['sourceNetId'] == pour['source_net_id'] and pr['logicalRoot'] == root and pr['violations'] == [], 'Completed pour metadata mismatch')
            require(pr['outerVertices'] == len(pour['brep_shape']['outer_ring']['vertices']) and
                    pr['innerRings'] == len(pour['brep_shape'].get('inner_rings', [])), 'Literal BREP roster mismatch')
            expected_vias = {k for k in vias if via_roots[k] != root}
            expected_wires = {k for k, v in wire_catalog.items() if v['layer'] == layer and v['root'] != root}
            own_vias = set(vias) - expected_vias
            own_wires = {k for k, v in wire_catalog.items() if v['layer'] == layer and v['root'] == root}
            via_checks, wire_checks = index(pr['viaChecks'], 'identity'), index(pr['wireChecks'], 'identity')
            require(set(via_checks) == expected_vias and set(wire_checks) == expected_wires, 'Exact per-pour foreign object coverage required')
            ex = [v for v in exemptions if v['pour'] == pid]
            via_ex = [v for v in ex if v['kind'] == 'via']; wire_ex = [v for v in ex if v['kind'] == 'wire']
            require(len(ex) == len(via_ex) + len(wire_ex) == pr['sameNetExemptionCount'] and
                    len(via_ex) == len(own_vias) and {v['identity'] for v in via_ex} == own_vias and
                    len(wire_ex) == len(own_wires) and {v['identity'] for v in wire_ex} == own_wires and
                    all(v['layer'] == layer and v['authenticatedLogicalRoot'] == root and v['ownNetReentryQualified'] is False for v in ex), 'Authenticated exact same-net exemption roster required')
            gaps = []
            for kind, checks in (('via', via_checks), ('wire', wire_checks)):
                for identity, check in checks.items():
                    require(check.get('kind') == kind and check.get('layer') == layer and check.get('passed') is True and
                            check.get('requiredMm') == REQUIRED and check.get('pourLogicalRoot') == root and
                            numeric(check.get('edgeClearanceMm')) and check['edgeClearanceMm'] >= REQUIRED - EPS and
                            check.get('overlap') is False and close(check.get('centerlineDistanceToFilledPourMm', float('nan')) - check.get('copperRadiusMm', float('nan')), check['edgeClearanceMm']),
                            'Every completed foreign comparison must pass its unchanged threshold')
                    if kind == 'via':
                        require(check['xy'] == xy(vias[identity]) and check['objectLogicalRoot'] == via_roots[identity] and
                                close(check['copperRadiusMm'], vias[identity]['outer_diameter'] / 2) and set(check['allPhysicalLayers']) == set(LAYERS), 'Via comparison geometry mismatch')
                    else:
                        v = wire_catalog[identity]
                        require(all(check.get(k) == value for k, value in v.items()) and check['objectLogicalRoot'] == v['root'] and
                                close(check['copperRadiusMm'], v['radius']), 'Wire comparison geometry mismatch')
                    gaps.append(check['edgeClearanceMm'])
            completed[pid] = {'pcbCopperPourId': pid, 'sourceReport': label, 'layer': layer, 'state': 'COMPLETED',
                              'foreignViaChecks': len(via_checks), 'foreignWireChecks': len(wire_checks),
                              'sameNetExemptions': len(ex), 'minimumForeignEdgeGapMm': min(gaps) if gaps else None,
                              'zeroViolations': True}
    require(len(excluded) == 1 and len(completed) == 15 and set(completed) == set(pours), 'Unique exact15 completed pours required')
    require({k for k, v in completed.items() if v['sourceReport'] == 'selected94'} == MISSING_POURS, 'Selected94 contribution mismatch')
    report = {'scope': 'SOURCE236_ALL15_LITERAL_POURS_COMPLETED_COVERAGE_AGGREGATE_NOT_BOARD_QUALIFICATION',
        'inputBindings': {name: {'path': str(getattr(args, name)), 'sha256': getattr(args, name + '_sha')}
                          for name in ('input', 'controls', 'auth', 'partial', 'subset')},
        'completedPourIds': list(pours), 'completedPourCount': 15, 'actualRawPourCount': 15,
        'completedPourReports': [completed[pid] for pid in pours], 'excludedBoundedPartialReports': excluded,
        'actualViaCount': 227, 'wireSegmentCount': 7456, 'wireOwnerCount': 47,
        'requiredForeignViaPourEdgeMm': REQUIRED, 'requiredForeignWirePourEdgeMm': REQUIRED,
        'coordinateToleranceMm': EPS, 'identityFailures': [], 'unsupportedGeometry': [], 'violations': [],
        'bounded236OriginalCompletedFlagRetained': partial['completed'],
        'allCompletedComparisonRostersReconstructedFromExactRaw': True,
        'sameExactRawControlsAuthAcrossBothContributions': True,
        'completed': True, 'literalForeignPourMarginClear': True,
        'minimumForeignEdgeGapMm': min(v['minimumForeignEdgeGapMm'] for v in completed.values() if v['minimumForeignEdgeGapMm'] is not None),
        'all49Accepted': False, 'fullBoardPassed': False, 'electricalTimingQualified': False,
        'referenceQualified': False, 'ownNetReentryQualified': False, 'referenceWireGeometryIncluded': False,
        'nativeExecuted': False, 'cadExecuted': False, 'fabricationReady': False,
        'scopeLimits': ['Only pinned Source236 227 vias and 7456 routed-owner wire segments against the exact15 fresh BREP pours.',
                        'Bounded Source236 partial94 and all its checks are excluded; the separate completed94 result replaces them.',
                        'No inherited other-scene result, full-board pass, return-path/reference, TI, delay, CAD, or fabrication qualification.']}
    def file_sha(path):
        digest = hashlib.sha256()
        with path.open('rb') as f:
            for block in iter(lambda: f.read(1024 * 1024), b''):
                digest.update(block)
        return digest.hexdigest()
    require(all(file_sha(getattr(args, name)) == getattr(args, name + '_sha')
                for name in ('input', 'controls', 'auth', 'partial', 'subset', 'plan')), 'All six pinned inputs must remain byte-identical')
    report['inputFilesUnchanged'] = True
    report['inputBindings']['reviewedSourcePlan234'] = {'path': str(args.plan), 'sha256': args.plan_sha}
    report['mergedCandidateSha256'] = CANDIDATE_SHA
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as f:
        json.dump(report, f, indent=2, allow_nan=False); f.write('\n')
    print(json.dumps({'completedPours': 15, 'literalForeignPourMarginClear': True, 'all49Accepted': False,
                      'fabricationReady': False, 'geometryExecutedByCombiner': False}))

if __name__ == '__main__':
    main()
