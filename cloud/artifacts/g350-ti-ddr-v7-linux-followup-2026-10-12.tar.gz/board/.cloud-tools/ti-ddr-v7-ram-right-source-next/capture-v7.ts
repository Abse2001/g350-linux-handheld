import { createHash } from "node:crypto"
import { readFileSync } from "node:fs"
import { dirname, resolve } from "node:path"
import { pathToFileURL } from "node:url"
import metadata from "/workspace/bus-lanes-solver/tests/fixtures/g350-am3352/metadata.json"

/** Re-capture through the board's pinned public Core adapter, independently of
 * the Bus Lanes implementation. This is optional; normal reproduction needs
 * only the committed fixtures and this repository's regular dependencies.
 */
if (import.meta.main) {
  const [coreArgument, sourceArgument, expectedSourceSha, ...extra] = process.argv.slice(2)
  if (!coreArgument || !sourceArgument || !/^[0-9a-f]{64}$/.test(expectedSourceSha ?? "") || extra.length)
    throw Error(
      "Usage: bun scripts/capture-g350-am3352.ts /path/to/core/dist/index.js [full-layout.circuit.json]",
    )
  const coreEntry = resolve(coreArgument)
  const corePackage = JSON.parse(
    readFileSync(resolve(dirname(coreEntry), "../package.json"), "utf8"),
  )
  if (
    corePackage.name !== "@tscircuit/core" ||
    corePackage.version !== metadata.capturedWith.core
  )
    throw Error("Use the recorded Core version to reproduce the capture")
  const root = resolve(import.meta.dir, "../tests/fixtures/g350-am3352")
  const sourcePath = sourceArgument
    ? resolve(sourceArgument)
    : resolve(root, "circuit.json")
  const bytes = readFileSync(sourcePath)
  if (
    sourceArgument &&
    createHash("sha256").update(bytes).digest("hex") !==
      expectedSourceSha
  )
    throw Error("Full source capture differs from the recorded G350 layout")
  const full = JSON.parse(bytes.toString()) as Array<Record<string, any>>
  const names = new Set(Object.values(metadata.componentNames))
  const netNames = new Set(Object.values(metadata.netNames))
  const sourceIds = new Set(
    full
      .filter((e) => e.type === "source_component" && names.has(e.name))
      .map((e) => e.source_component_id),
  )
  const viaSourceIds = new Set(full.filter((e) => e.type === "source_manually_placed_via").map((e) => e.source_manually_placed_via_id))
  if (viaSourceIds.size !== 2) throw Error("Exact two real reference vias required")
  const componentIds = new Set(
    full
      .filter(
        (e) =>
          e.type === "pcb_component" && (sourceIds.has(e.source_component_id) || viaSourceIds.has(e.source_component_id)),
      )
      .map((e) => e.pcb_component_id),
  )
  const portIds = new Set(
    full
      .filter(
        (e) => e.type === "source_port" && (sourceIds.has(e.source_component_id) || viaSourceIds.has(e.source_component_id)),
      )
      .map((e) => e.source_port_id),
  )
  const netIds = new Set(
    full
      .filter((e) => e.type === "source_net" && netNames.has(e.name))
      .map((e) => e.source_net_id),
  )
  const traceIds = new Set(
    full
      .filter(
        (e) =>
          e.type === "source_trace" &&
          e.connected_source_port_ids.length &&
          e.connected_source_port_ids.every((id: string) => portIds.has(id)) &&
          e.connected_source_net_ids.every((id: string) => netIds.has(id)),
      )
      .map((e) => e.source_trace_id),
  )
  const circuit = full.filter((e) => {
    if (["source_board", "source_group", "pcb_board"].includes(e.type))
      return true
    if (
      [
        "source_component",
        "source_port",
        "source_component_internal_connection",
      ].includes(e.type)
    )
      return sourceIds.has(e.source_component_id) || viaSourceIds.has(e.source_component_id)
    if (e.type === "source_manually_placed_via") return viaSourceIds.has(e.source_manually_placed_via_id)
    if (e.type === "pcb_via") return ["pcb_via_0", "pcb_via_1"].includes(e.pcb_via_id)
    if (e.type === "pcb_trace") return ["source_trace_932", "source_trace_933"].includes(e.source_trace_id)
    if (e.type === "source_net") return netIds.has(e.source_net_id)
    if (e.type === "source_trace") return traceIds.has(e.source_trace_id)
    if (e.type === "source_bus")
      return e.source_trace_ids.every((id: string) => traceIds.has(id))
    return (
      [
        "pcb_component",
        "pcb_port",
        "pcb_smtpad",
        "pcb_plated_hole",
        "pcb_courtyard_outline",
        "pcb_courtyard_circle",
        "pcb_courtyard_rect",
      ].includes(e.type) && componentIds.has(e.pcb_component_id)
    )
  })
  const { getSimpleRouteJsonFromCircuitJson } = await import(
    pathToFileURL(coreEntry).href
  )
  const { simpleRouteJson: complete } = getSimpleRouteJsonFromCircuitJson({
    circuitJson: circuit,
    minTraceWidth: 0.1016,
    nominalTraceWidth: 0.1016,
  })
  const connectionNames = new Set(complete.connections.map((c: any) => c.name))
  // Drop repeated off-board aliases while keeping ownership of every physical
  // pad by every captured net, as well as its pad/port identity. No geometry moves.
  for (const obstacle of complete.obstacles) {
    obstacle.connectedTo = [
      ...new Set<string>(
        obstacle.connectedTo.filter(
          (id: string) =>
            connectionNames.has(id) ||
            id.startsWith("source_net_") ||
            id === obstacle.circuitJsonMetadata?.pcb_port_id ||
            id === obstacle.circuitJsonMetadata?.pcb_smtpad_id ||
            id === obstacle.circuitJsonMetadata?.pcb_via_id ||
            ["source_trace_932", "source_trace_933", "pcb_port_1161", "pcb_port_1162", "pcb_port_1163", "pcb_port_1164"].includes(id),
        ),
      ),
    ].sort()
    delete obstacle.offBoardConnectsTo
    delete obstacle.netIsAssignable
  }
  const sourceBuses = circuit.filter((e) => e.type === "source_bus")
  complete.buses = sourceBuses
    .filter((b) =>
      ["DDR_RESET", "DDR_BYTE0", "DDR_BYTE1", "DDR_COMMAND_CLOCK"].includes(
        b.name,
      ),
    )
    .map((b) => ({
      busId: b.name,
      connectionNames: b.source_trace_ids,
      traceWidth: 0.1016,
      allowedLayers: ["top", "bottom"],
      preferredLayers: ["bottom", "top"],
      ...(b.max_length_skew === undefined
        ? {}
        : { maxLengthSkew: b.max_length_skew }),
    }))
  complete.differentialPairs = sourceBuses
    .filter((b) => b.name.endsWith("_PAIR"))
    .map((b) => ({
      connectionNames: b.source_trace_ids,
      lengthTolerance: b.max_length_skew,
      traceGap: metadata.pairTraceGapMm,
    }))
  const coreStubs = structuredClone(complete.traces ?? [])
  if (coreStubs.length !== 2) throw Error("Pinned Core did not retain exact two reference stubs")
  const sourceStubs = full.filter((e) => e.type === "pcb_trace")
  const physicalVias = full.filter((e) => e.type === "pcb_via")
  const provenance: any[] = []
  complete.traces = coreStubs.map((stub: any) => {
    const physicalStub = sourceStubs.find((trace) => trace.pcb_trace_id === stub.pcb_trace_id)
    if (!physicalStub || !["source_trace_932", "source_trace_933"].includes(physicalStub.source_trace_id)) throw Error("Foreign physical stub")
    const contact = physicalStub.route[0]
    const via = physicalVias.find((entry) => entry.pcb_port_ids.includes(contact.start_pcb_port_id))
    const owner = full.find((entry) => entry.type === "source_trace" && entry.source_trace_id === physicalStub.source_trace_id)
    if (!via || !owner || contact.layer !== "bottom" || contact.x !== via.x || contact.y !== via.y || !owner.connected_source_net_ids.includes(via.source_net_id) || JSON.stringify(via.layers) !== JSON.stringify(["top", "inner1", "inner2", "bottom"]) || via.outer_diameter !== 0.4572 || via.hole_diameter !== 0.254 || via.from_layer !== "top" || via.to_layer !== "bottom") throw Error("Real via/stub association differs")
    if (stub.source_trace_id !== physicalStub.source_trace_id || stub.connection_name !== physicalStub.source_trace_id || stub.route.some((point: any) => point.route_type !== "wire" || point.layer !== "bottom" || point.width !== 0.2)) throw Error("Core ownership or geometry differs")
    if (JSON.stringify(stub.route.map(({x,y,width,layer,route_type}:any) => ({x,y,width,layer,route_type}))) !== JSON.stringify(physicalStub.route.map(({x,y,width,layer,route_type}:any) => ({x,y,width,layer,route_type})))) throw Error("Core stub vertices moved")
    provenance.push({pcbViaId:via.pcb_via_id,pcbTraceId:physicalStub.pcb_trace_id,sourceTraceId:physicalStub.source_trace_id,sourceNetId:via.source_net_id,aliasPcbPortIds:via.pcb_port_ids,viaCenter:{x:via.x,y:via.y},originalStubVertices:physicalStub.route,physicalViaRecord:via})
    return {...stub, route:[{route_type:"wire",x:via.x,y:via.y,layer:"top",width:contact.width},{route_type:"via",x:via.x,y:via.y,from_layer:via.from_layer,to_layer:via.to_layer,layers:via.layers,via_diameter:via.outer_diameter,via_hole_diameter:via.hole_diameter,circuitJsonMetadata:{pcb_via_id:via.pcb_via_id}},...stub.route],physicalContextMetadata:{pcb_via_id:via.pcb_via_id,pcb_trace_id:physicalStub.pcb_trace_id,source_net_id:via.source_net_id,geometryPreservingSerialization:true}}
  })
  if (new Set(provenance.map((entry) => entry.pcbViaId)).size !== 2) throw Error("One-to-one physical via identity required")
  const native = {
    ...complete,
    allowedLayers: ["top", "bottom"],
    connections: complete.connections.filter(
      (c: any) => c.name in metadata.signalNames,
    ),
  }
  if (
    sourceIds.size !== 194 ||
    complete.obstacles.length !== 856 ||
    complete.connections.length !== 117 ||
    native.connections.length !== 49
  )
    throw Error("Capture lost components, pads or required connections")
  // NEW derived placement capture only. Original fixture stays immutable.
  if (!sourceArgument) throw Error("Explicit fresh source required")
  const outputRoot = resolve(import.meta.dir, "output")
  const { mkdirSync, writeFileSync, existsSync } = await import("node:fs")
  if (existsSync(outputRoot)) throw Error("Fresh derived output required")
  mkdirSync(outputRoot)
  const files = { "circuit.json": circuit, "native-input.json": complete, "ddr-input.json": native, "core-original-reference-stubs.json": coreStubs, "reference-serialization-provenance.json": provenance }
  const hashes: Record<string,string> = {}
  for (const [name,value] of Object.entries(files)) {
    const bytes=JSON.stringify(value,null,2)+"\n"
    writeFileSync(resolve(outputRoot,name),bytes)
    hashes[name]=createHash("sha256").update(bytes).digest("hex")
  }
  writeFileSync(resolve(outputRoot,"manifest.json"),JSON.stringify({schemaVersion:1,sourceCaptureSha256:createHash("sha256").update(bytes).digest("hex"),filesSha256:hashes,originalCaptureScriptSha256:"80ec02f4d8ef40e04dbb0597520d1b0b7c63557215428a99346a1b4d22d12fae",components:194,pads:854,viaObstacles:2,physicalViaIds:provenance.map((entry) => entry.pcbViaId),physicalUniqueViaCount:2,serializedViaReferences:2,ddrSignals:49,supportNets:68,allSourceLogicHeld:true,newV7RamRigidTranslation:true,allowedLayers:["top","bottom"],numLayers:4,referencePlaneStackQualified:false,hardwareRoutingPerformed:false,referenceGeometrySerializedOnly:true,fabricationReady:false},null,2)+"\n")
  console.log(
    JSON.stringify({
      verified: true,
      components: 194,
      pads: 854,
      ddrSignals: 49,
      supportNets: 68,
      core: corePackage.version,
    }),
  )
}
